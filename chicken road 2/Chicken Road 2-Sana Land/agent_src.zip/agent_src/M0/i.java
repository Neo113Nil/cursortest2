package M0;

import D.C0019u;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class i implements d {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ A.j f747e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0019u f748f;

    public i(A.j jVar, C0019u c0019u) {
        this.f747e = jVar;
        this.f748f = c0019u;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00a0 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // M0.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object t(e eVar, w0.c cVar) {
        h hVar;
        int i2;
        x0.a aVar;
        i iVar;
        t tVar;
        C0019u c0019u;
        N0.l lVar;
        Throwable th;
        N0.l lVar2;
        C0019u c0019u2;
        try {
            if (cVar instanceof h) {
                hVar = (h) cVar;
                int i3 = hVar.f743i;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    hVar.f743i = i3 - Integer.MIN_VALUE;
                    Object obj = hVar.f742h;
                    i2 = hVar.f743i;
                    aVar = x0.a.f3053e;
                    if (i2 != 0) {
                        AbstractC0230j.A(obj);
                        try {
                            A.j jVar = this.f747e;
                            hVar.f745k = this;
                            hVar.f746l = eVar;
                            hVar.f743i = 1;
                            if (jVar.t(eVar, hVar) != aVar) {
                                iVar = this;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            iVar = this;
                            tVar = new t(th);
                            c0019u = iVar.f748f;
                            hVar.f745k = th;
                            hVar.f746l = null;
                            hVar.f743i = 2;
                            if (r.a(tVar, c0019u, th, hVar) != aVar) {
                                return aVar;
                            }
                            throw th;
                        }
                        return aVar;
                    }
                    if (i2 != 1) {
                        if (i2 == 2) {
                            Throwable th3 = (Throwable) hVar.f745k;
                            AbstractC0230j.A(obj);
                            throw th3;
                        }
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        lVar2 = (N0.l) hVar.f745k;
                        try {
                            AbstractC0230j.A(obj);
                            lVar2.o();
                            return u0.g.f2964a;
                        } catch (Throwable th4) {
                            th = th4;
                            lVar2.o();
                            throw th;
                        }
                    }
                    eVar = hVar.f746l;
                    iVar = (i) hVar.f745k;
                    try {
                        AbstractC0230j.A(obj);
                    } catch (Throwable th5) {
                        th = th5;
                        tVar = new t(th);
                        c0019u = iVar.f748f;
                        hVar.f745k = th;
                        hVar.f746l = null;
                        hVar.f743i = 2;
                        if (r.a(tVar, c0019u, th, hVar) != aVar) {
                        }
                    }
                    w0.h hVar2 = hVar.f3057f;
                    E0.i.b(hVar2);
                    lVar = new N0.l(eVar, hVar2);
                    c0019u2 = iVar.f748f;
                    hVar.f745k = lVar;
                    hVar.f746l = null;
                    hVar.f743i = 3;
                    if (c0019u2.f(lVar, null, hVar) != aVar) {
                        lVar2 = lVar;
                        lVar2.o();
                        return u0.g.f2964a;
                    }
                    return aVar;
                }
            }
            c0019u2 = iVar.f748f;
            hVar.f745k = lVar;
            hVar.f746l = null;
            hVar.f743i = 3;
            if (c0019u2.f(lVar, null, hVar) != aVar) {
            }
            return aVar;
        } catch (Throwable th6) {
            th = th6;
            lVar2 = lVar;
            lVar2.o();
            throw th;
        }
        hVar = new h(this, cVar);
        Object obj2 = hVar.f742h;
        i2 = hVar.f743i;
        aVar = x0.a.f3053e;
        if (i2 != 0) {
        }
        w0.h hVar22 = hVar.f3057f;
        E0.i.b(hVar22);
        lVar = new N0.l(eVar, hVar22);
    }
}
