package M0;

import J0.C0031g;
import J0.N;
import J0.W;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class q extends N0.b implements d, e, N0.i {

    /* renamed from: i, reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f785i = AtomicReferenceFieldUpdater.newUpdater(q.class, Object.class, "_state$volatile");
    private volatile /* synthetic */ Object _state$volatile;

    /* renamed from: h, reason: collision with root package name */
    public int f786h;

    public q(Object obj) {
        this._state$volatile = obj;
    }

    public final boolean a(Object obj, Object obj2) {
        int i2;
        s[] sVarArr;
        A.j jVar;
        synchronized (this) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f785i;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj != null && !E0.i.a(obj3, obj)) {
                return false;
            }
            if (E0.i.a(obj3, obj2)) {
                return true;
            }
            atomicReferenceFieldUpdater.set(this, obj2);
            int i3 = this.f786h;
            if ((i3 & 1) != 0) {
                this.f786h = i3 + 2;
                return true;
            }
            int i4 = i3 + 1;
            this.f786h = i4;
            s[] sVarArr2 = this.f792e;
            while (true) {
                if (sVarArr2 != null) {
                    for (s sVar : sVarArr2) {
                        if (sVar != null) {
                            AtomicReference atomicReference = sVar.f789a;
                            while (true) {
                                Object obj4 = atomicReference.get();
                                if (obj4 != null && obj4 != (jVar = r.f788b)) {
                                    A.j jVar2 = r.f787a;
                                    if (obj4 != jVar2) {
                                        while (!atomicReference.compareAndSet(obj4, jVar2)) {
                                            if (atomicReference.get() != obj4) {
                                                break;
                                            }
                                        }
                                        ((C0031g) obj4).g(u0.g.f2964a);
                                        break;
                                    }
                                    while (!atomicReference.compareAndSet(obj4, jVar)) {
                                        if (atomicReference.get() != obj4) {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                synchronized (this) {
                    i2 = this.f786h;
                    if (i2 == i4) {
                        this.f786h = i4 + 1;
                        return true;
                    }
                    sVarArr = this.f792e;
                }
                sVarArr2 = sVarArr;
                i4 = i2;
            }
        }
    }

    @Override // M0.e
    public final Object j(Object obj, w0.c cVar) {
        if (obj == null) {
            obj = N0.k.f812a;
        }
        a(null, obj);
        return u0.g.f2964a;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x00e3, code lost:
    
        if (r0.equals(r4) != false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x0145, code lost:
    
        if (r5 == r3) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0148, code lost:
    
        if (r4 != r3) goto L83;
     */
    /* JADX WARN: Removed duplicated region for block: B:18:0x00cf A[Catch: all -> 0x003f, TryCatch #2 {all -> 0x003f, blocks: (B:13:0x0039, B:16:0x00c7, B:18:0x00cf, B:21:0x00d6, B:22:0x00dc, B:26:0x00df, B:28:0x0100, B:31:0x0110, B:32:0x012c, B:39:0x013c, B:34:0x0133, B:38:0x0139, B:47:0x00e5, B:50:0x00ec, B:58:0x0054, B:60:0x005f, B:61:0x00b7), top: B:7:0x0027 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0110 A[Catch: all -> 0x003f, TryCatch #2 {all -> 0x003f, blocks: (B:13:0x0039, B:16:0x00c7, B:18:0x00cf, B:21:0x00d6, B:22:0x00dc, B:26:0x00df, B:28:0x0100, B:31:0x0110, B:32:0x012c, B:39:0x013c, B:34:0x0133, B:38:0x0139, B:47:0x00e5, B:50:0x00ec, B:58:0x0054, B:60:0x005f, B:61:0x00b7), top: B:7:0x0027 }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0029  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x010f -> B:16:0x00c7). Please report as a decompilation issue!!! */
    @Override // M0.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object t(e eVar, w0.c cVar) {
        p pVar;
        x0.a aVar;
        int i2;
        s sVar;
        AtomicReference atomicReference;
        e eVar2;
        q qVar;
        s sVar2;
        N n2;
        e eVar3;
        Object obj;
        Object obj2;
        Object andSet;
        Object obj3;
        try {
            if (cVar instanceof p) {
                pVar = (p) cVar;
                int i3 = pVar.f784o;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    pVar.f784o = i3 - Integer.MIN_VALUE;
                    Object obj4 = pVar.f782m;
                    aVar = x0.a.f3053e;
                    i2 = pVar.f784o;
                    int i4 = 3;
                    int i5 = 2;
                    if (i2 != 0) {
                        AbstractC0230j.A(obj4);
                        synchronized (this) {
                            try {
                                s[] sVarArr = this.f792e;
                                if (sVarArr == null) {
                                    sVarArr = new s[2];
                                    this.f792e = sVarArr;
                                } else if (this.f793f >= sVarArr.length) {
                                    Object[] copyOf = Arrays.copyOf(sVarArr, sVarArr.length * 2);
                                    E0.i.d(copyOf, "copyOf(...)");
                                    this.f792e = (s[]) copyOf;
                                    sVarArr = (s[]) copyOf;
                                }
                                int i6 = this.f794g;
                                do {
                                    sVar = sVarArr[i6];
                                    if (sVar == null) {
                                        sVar = new s();
                                        sVarArr[i6] = sVar;
                                    }
                                    i6++;
                                    if (i6 >= sVarArr.length) {
                                        i6 = 0;
                                    }
                                    atomicReference = sVar.f789a;
                                } while (atomicReference.get() != null);
                                atomicReference.set(r.f787a);
                                this.f794g = i6;
                                this.f793f++;
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                        eVar2 = eVar;
                        qVar = this;
                        sVar2 = sVar;
                    } else if (i2 == 1) {
                        sVar2 = pVar.f779j;
                        eVar2 = pVar.f778i;
                        qVar = pVar.f777h;
                        AbstractC0230j.A(obj4);
                    } else if (i2 == 2) {
                        obj2 = pVar.f781l;
                        n2 = pVar.f780k;
                        sVar2 = pVar.f779j;
                        eVar3 = pVar.f778i;
                        qVar = pVar.f777h;
                        AbstractC0230j.A(obj4);
                        obj = obj2;
                        AtomicReference atomicReference2 = sVar2.f789a;
                        A.j jVar = r.f787a;
                        andSet = atomicReference2.getAndSet(jVar);
                        E0.i.b(andSet);
                        if (andSet == r.f788b) {
                        }
                    } else {
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        Object obj5 = pVar.f781l;
                        n2 = pVar.f780k;
                        sVar2 = pVar.f779j;
                        eVar3 = pVar.f778i;
                        qVar = pVar.f777h;
                        AbstractC0230j.A(obj4);
                        obj = obj5;
                        i4 = 3;
                        i5 = 2;
                        obj2 = f785i.get(qVar);
                        if (n2 != null && !n2.a()) {
                            throw ((W) n2).y();
                        }
                        obj3 = obj2 != N0.k.f812a ? null : obj2;
                        pVar.f777h = qVar;
                        pVar.f778i = eVar3;
                        pVar.f779j = sVar2;
                        pVar.f780k = n2;
                        pVar.f781l = obj2;
                        pVar.f784o = i5;
                        if (eVar3.j(obj3, pVar) == aVar) {
                            return aVar;
                        }
                        obj = obj2;
                        AtomicReference atomicReference22 = sVar2.f789a;
                        A.j jVar2 = r.f787a;
                        andSet = atomicReference22.getAndSet(jVar2);
                        E0.i.b(andSet);
                        if (andSet == r.f788b) {
                            obj2 = f785i.get(qVar);
                            if (n2 != null) {
                                throw ((W) n2).y();
                            }
                            if (obj2 != N0.k.f812a) {
                            }
                            pVar.f777h = qVar;
                            pVar.f778i = eVar3;
                            pVar.f779j = sVar2;
                            pVar.f780k = n2;
                            pVar.f781l = obj2;
                            pVar.f784o = i5;
                            if (eVar3.j(obj3, pVar) == aVar) {
                            }
                            obj = obj2;
                            AtomicReference atomicReference222 = sVar2.f789a;
                            A.j jVar22 = r.f787a;
                            andSet = atomicReference222.getAndSet(jVar22);
                            E0.i.b(andSet);
                            if (andSet == r.f788b) {
                                pVar.f777h = qVar;
                                pVar.f778i = eVar3;
                                pVar.f779j = sVar2;
                                pVar.f780k = n2;
                                pVar.f781l = obj;
                                pVar.f784o = i4;
                                u0.g gVar = u0.g.f2964a;
                                C0031g c0031g = new C0031g(1, AbstractC0230j.q(pVar));
                                c0031g.u();
                                AtomicReference atomicReference3 = sVar2.f789a;
                                while (true) {
                                    if (atomicReference3.compareAndSet(jVar22, c0031g)) {
                                        break;
                                    }
                                    if (atomicReference3.get() != jVar22) {
                                        c0031g.g(gVar);
                                        break;
                                    }
                                }
                                Object t2 = c0031g.t();
                                if (t2 == x0.a.f3053e) {
                                }
                            }
                        }
                    }
                    w0.h hVar = pVar.f3057f;
                    E0.i.b(hVar);
                    n2 = (N) hVar.h(J0.r.f506f);
                    eVar3 = eVar2;
                    obj = null;
                    obj2 = f785i.get(qVar);
                    if (n2 != null) {
                    }
                    if (obj2 != N0.k.f812a) {
                    }
                    pVar.f777h = qVar;
                    pVar.f778i = eVar3;
                    pVar.f779j = sVar2;
                    pVar.f780k = n2;
                    pVar.f781l = obj2;
                    pVar.f784o = i5;
                    if (eVar3.j(obj3, pVar) == aVar) {
                    }
                    obj = obj2;
                    AtomicReference atomicReference2222 = sVar2.f789a;
                    A.j jVar222 = r.f787a;
                    andSet = atomicReference2222.getAndSet(jVar222);
                    E0.i.b(andSet);
                    if (andSet == r.f788b) {
                    }
                }
            }
            if (i2 != 0) {
            }
            w0.h hVar2 = pVar.f3057f;
            E0.i.b(hVar2);
            n2 = (N) hVar2.h(J0.r.f506f);
            eVar3 = eVar2;
            obj = null;
            obj2 = f785i.get(qVar);
            if (n2 != null) {
            }
            if (obj2 != N0.k.f812a) {
            }
            pVar.f777h = qVar;
            pVar.f778i = eVar3;
            pVar.f779j = sVar2;
            pVar.f780k = n2;
            pVar.f781l = obj2;
            pVar.f784o = i5;
            if (eVar3.j(obj3, pVar) == aVar) {
            }
            obj = obj2;
            AtomicReference atomicReference22222 = sVar2.f789a;
            A.j jVar2222 = r.f787a;
            andSet = atomicReference22222.getAndSet(jVar2222);
            E0.i.b(andSet);
            if (andSet == r.f788b) {
            }
        } catch (Throwable th2) {
            synchronized (qVar) {
                try {
                    int i7 = qVar.f793f - 1;
                    qVar.f793f = i7;
                    if (i7 == 0) {
                        qVar.f794g = 0;
                    }
                    E0.i.c(sVar2, "null cannot be cast to non-null type kotlinx.coroutines.flow.internal.AbstractSharedFlowSlot<kotlin.Any>");
                    sVar2.f789a.set(null);
                    throw th2;
                } catch (Throwable th3) {
                    throw th3;
                }
            }
        }
        pVar = new p(this, cVar);
        Object obj42 = pVar.f782m;
        aVar = x0.a.f3053e;
        i2 = pVar.f784o;
        int i42 = 3;
        int i52 = 2;
    }
}
