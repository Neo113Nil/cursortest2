package M0;

import D.C0018t;
import m0.AbstractC0230j;
import s0.J;
import s0.K;

/* loaded from: classes.dex */
public final class l implements e {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f760e = 0;

    /* renamed from: f, reason: collision with root package name */
    public final Object f761f;

    /* renamed from: g, reason: collision with root package name */
    public final Object f762g;

    /* renamed from: h, reason: collision with root package name */
    public final Object f763h;

    public l(E0.n nVar, e eVar, C0018t c0018t) {
        this.f761f = nVar;
        this.f762g = eVar;
        this.f763h = c0018t;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00e4  */
    /* JADX WARN: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00b2  */
    @Override // M0.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object j(Object obj, w0.c cVar) {
        k kVar;
        Object obj2;
        int i2;
        l lVar;
        s0.q qVar;
        int i3;
        switch (this.f760e) {
            case 0:
                if (cVar instanceof k) {
                    kVar = (k) cVar;
                    int i4 = kVar.f759l;
                    if ((i4 & Integer.MIN_VALUE) != 0) {
                        kVar.f759l = i4 - Integer.MIN_VALUE;
                        obj2 = kVar.f757j;
                        i2 = kVar.f759l;
                        u0.g gVar = u0.g.f2964a;
                        x0.a aVar = x0.a.f3053e;
                        if (i2 == 0) {
                            if (i2 != 1) {
                                if (i2 == 2) {
                                    obj = kVar.f756i;
                                    lVar = kVar.f755h;
                                    AbstractC0230j.A(obj2);
                                } else if (i2 != 3) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            }
                            AbstractC0230j.A(obj2);
                            return gVar;
                        }
                        AbstractC0230j.A(obj2);
                        if (((E0.n) this.f761f).f298e) {
                            e eVar = (e) this.f762g;
                            kVar.f759l = 1;
                            if (eVar.j(obj, kVar) != aVar) {
                                return gVar;
                            }
                        } else {
                            C0018t c0018t = (C0018t) this.f763h;
                            kVar.f755h = this;
                            kVar.f756i = obj;
                            kVar.f759l = 2;
                            obj2 = c0018t.h(obj, kVar);
                            if (obj2 != aVar) {
                                lVar = this;
                            }
                        }
                        return aVar;
                        if (!((Boolean) obj2).booleanValue()) {
                            return gVar;
                        }
                        ((E0.n) lVar.f761f).f298e = true;
                        e eVar2 = (e) lVar.f762g;
                        kVar.f755h = null;
                        kVar.f756i = null;
                        kVar.f759l = 3;
                        if (eVar2.j(obj, kVar) != aVar) {
                            return gVar;
                        }
                        return aVar;
                    }
                }
                kVar = new k(this, cVar);
                obj2 = kVar.f757j;
                i2 = kVar.f759l;
                u0.g gVar2 = u0.g.f2964a;
                x0.a aVar2 = x0.a.f3053e;
                if (i2 == 0) {
                }
                if (!((Boolean) obj2).booleanValue()) {
                }
            case 1:
                Object b2 = N0.k.b((w0.h) this.f761f, obj, this.f762g, (N0.r) this.f763h, cVar);
                return b2 == x0.a.f3053e ? b2 : u0.g.f2964a;
            default:
                if (cVar instanceof s0.q) {
                    qVar = (s0.q) cVar;
                    int i5 = qVar.f2885i;
                    if ((i5 & Integer.MIN_VALUE) != 0) {
                        qVar.f2885i = i5 - Integer.MIN_VALUE;
                        Object obj3 = qVar.f2884h;
                        i3 = qVar.f2885i;
                        if (i3 != 0) {
                            AbstractC0230j.A(obj3);
                            e eVar3 = (e) this.f762g;
                            Double d2 = (Double) K.c(((G.a) obj).c((G.c) this.f761f), ((J) this.f763h).f2835g);
                            qVar.f2885i = 1;
                            Object j2 = eVar3.j(d2, qVar);
                            x0.a aVar3 = x0.a.f3053e;
                            if (j2 == aVar3) {
                                return aVar3;
                            }
                        } else {
                            if (i3 != 1) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            AbstractC0230j.A(obj3);
                        }
                        return u0.g.f2964a;
                    }
                }
                qVar = new s0.q(this, cVar);
                Object obj32 = qVar.f2884h;
                i3 = qVar.f2885i;
                if (i3 != 0) {
                }
                return u0.g.f2964a;
        }
    }

    public l(e eVar, G.c cVar, J j2) {
        this.f762g = eVar;
        this.f761f = cVar;
        this.f763h = j2;
    }

    public l(e eVar, w0.h hVar) {
        this.f761f = hVar;
        this.f762g = O0.a.k(hVar);
        this.f763h = new N0.r(eVar, null);
    }
}
