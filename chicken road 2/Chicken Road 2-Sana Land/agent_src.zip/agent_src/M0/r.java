package M0;

import D.C0019u;
import D.D;
import java.util.concurrent.CancellationException;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class r {

    /* renamed from: a, reason: collision with root package name */
    public static final A.j f787a;

    /* renamed from: b, reason: collision with root package name */
    public static final A.j f788b;

    static {
        int i2 = 11;
        f787a = new A.j(i2, "NONE");
        f788b = new A.j(i2, "PENDING");
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object a(t tVar, C0019u c0019u, Throwable th, y0.c cVar) {
        g gVar;
        int i2;
        try {
            if (cVar instanceof g) {
                gVar = (g) cVar;
                int i3 = gVar.f741j;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    gVar.f741j = i3 - Integer.MIN_VALUE;
                    Object obj = gVar.f740i;
                    i2 = gVar.f741j;
                    if (i2 != 0) {
                        AbstractC0230j.A(obj);
                        gVar.f739h = th;
                        gVar.f741j = 1;
                        Object f2 = c0019u.f(tVar, th, gVar);
                        Object obj2 = x0.a.f3053e;
                        if (f2 == obj2) {
                            return obj2;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        th = gVar.f739h;
                        AbstractC0230j.A(obj);
                    }
                    return u0.g.f2964a;
                }
            }
            if (i2 != 0) {
            }
            return u0.g.f2964a;
        } catch (Throwable th2) {
            if (th != null && th != th2) {
                AbstractC0230j.a(th2, th);
            }
            throw th2;
        }
        gVar = new g(cVar);
        Object obj3 = gVar.f740i;
        i2 = gVar.f741j;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0094, code lost:
    
        if (r1.j(r11, r0) == r5) goto L37;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x007a A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:12:0x002f, B:14:0x005e, B:20:0x0072, B:22:0x007a, B:24:0x0080, B:26:0x0086, B:28:0x0097, B:29:0x009f, B:30:0x00a0, B:31:0x00a7, B:39:0x0049, B:42:0x0054), top: B:7:0x0021 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /* JADX WARN: Type inference failed for: r9v4, types: [L0.s] */
    /* JADX WARN: Type inference failed for: r9v6, types: [L0.s] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:27:0x0094 -> B:13:0x0032). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object b(e eVar, L0.q qVar, boolean z2, y0.c cVar) {
        f fVar;
        int i2;
        L0.b bVar;
        L0.q qVar2;
        L0.b bVar2;
        e eVar2;
        L0.q qVar3;
        try {
            if (cVar instanceof f) {
                fVar = (f) cVar;
                int i3 = fVar.f738m;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    fVar.f738m = i3 - Integer.MIN_VALUE;
                    Object obj = fVar.f737l;
                    i2 = fVar.f738m;
                    x0.a aVar = x0.a.f3053e;
                    if (i2 != 0) {
                        AbstractC0230j.A(obj);
                        if (eVar instanceof t) {
                            throw ((t) eVar).f790e;
                        }
                        L0.c cVar2 = qVar.f716h;
                        cVar2.getClass();
                        bVar = new L0.b(cVar2);
                        qVar3 = qVar;
                        fVar.f733h = eVar;
                        fVar.f734i = qVar3;
                        fVar.f735j = bVar;
                        fVar.f736k = z2;
                        fVar.f738m = 1;
                        obj = bVar.b(fVar);
                        if (obj != aVar) {
                        }
                    } else if (i2 == 1) {
                        z2 = fVar.f736k;
                        bVar2 = fVar.f735j;
                        ?? r9 = fVar.f734i;
                        eVar2 = fVar.f733h;
                        AbstractC0230j.A(obj);
                        qVar2 = r9;
                        if (!((Boolean) obj).booleanValue()) {
                        }
                    } else {
                        if (i2 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        z2 = fVar.f736k;
                        bVar2 = fVar.f735j;
                        ?? r92 = fVar.f734i;
                        eVar2 = fVar.f733h;
                        AbstractC0230j.A(obj);
                        L0.q qVar4 = r92;
                        e eVar3 = eVar2;
                        bVar = bVar2;
                        eVar = eVar3;
                        qVar3 = qVar4;
                        fVar.f733h = eVar;
                        fVar.f734i = qVar3;
                        fVar.f735j = bVar;
                        fVar.f736k = z2;
                        fVar.f738m = 1;
                        obj = bVar.b(fVar);
                        if (obj != aVar) {
                            return aVar;
                        }
                        L0.b bVar3 = bVar;
                        eVar2 = eVar;
                        bVar2 = bVar3;
                        qVar2 = qVar3;
                        if (!((Boolean) obj).booleanValue()) {
                            if (z2) {
                                qVar2.b(null);
                            }
                            return u0.g.f2964a;
                        }
                        Object obj2 = bVar2.f672e;
                        A.j jVar = L0.e.f701p;
                        if (obj2 == jVar) {
                            throw new IllegalStateException("`hasNext()` has not been invoked");
                        }
                        bVar2.f672e = jVar;
                        if (obj2 == L0.e.f697l) {
                            Throwable n2 = bVar2.f674g.n();
                            int i4 = O0.t.f870a;
                            throw n2;
                        }
                        fVar.f733h = eVar2;
                        fVar.f734i = qVar2;
                        fVar.f735j = bVar2;
                        fVar.f736k = z2;
                        fVar.f738m = 2;
                        qVar4 = qVar2;
                    }
                }
            }
            if (i2 != 0) {
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                if (z2) {
                    CancellationException cancellationException = th instanceof CancellationException ? th : null;
                    if (cancellationException == null) {
                        cancellationException = new CancellationException("Channel was consumed, consumer had failed");
                        cancellationException.initCause(th);
                    }
                    qVar.b(cancellationException);
                }
                throw th2;
            }
        }
        fVar = new f(cVar);
        Object obj3 = fVar.f737l;
        i2 = fVar.f738m;
        x0.a aVar2 = x0.a.f3053e;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object c(d dVar, y0.c cVar) {
        o oVar;
        int i2;
        E0.p pVar;
        N0.a e2;
        D d2;
        if (cVar instanceof o) {
            oVar = (o) cVar;
            int i3 = oVar.f776k;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                oVar.f776k = i3 - Integer.MIN_VALUE;
                Object obj = oVar.f775j;
                i2 = oVar.f776k;
                if (i2 != 0) {
                    AbstractC0230j.A(obj);
                    E0.p pVar2 = new E0.p();
                    D d3 = new D(1, pVar2);
                    try {
                        oVar.f773h = pVar2;
                        oVar.f774i = d3;
                        oVar.f776k = 1;
                        Object t2 = dVar.t(d3, oVar);
                        Object obj2 = x0.a.f3053e;
                        if (t2 == obj2) {
                            return obj2;
                        }
                        pVar = pVar2;
                    } catch (N0.a e3) {
                        pVar = pVar2;
                        e2 = e3;
                        d2 = d3;
                        if (e2.f791e != d2) {
                        }
                        return pVar.f300e;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    d2 = oVar.f774i;
                    pVar = oVar.f773h;
                    try {
                        AbstractC0230j.A(obj);
                    } catch (N0.a e4) {
                        e2 = e4;
                        if (e2.f791e != d2) {
                            throw e2;
                        }
                        return pVar.f300e;
                    }
                }
                return pVar.f300e;
            }
        }
        oVar = new o(cVar);
        Object obj3 = oVar.f775j;
        i2 = oVar.f776k;
        if (i2 != 0) {
        }
        return pVar.f300e;
    }
}
