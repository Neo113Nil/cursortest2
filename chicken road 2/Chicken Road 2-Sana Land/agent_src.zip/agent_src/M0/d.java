package M0;

/* loaded from: classes.dex */
public interface d {
    Object t(e eVar, w0.c cVar);
}
