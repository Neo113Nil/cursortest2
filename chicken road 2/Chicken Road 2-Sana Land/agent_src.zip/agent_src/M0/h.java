package M0;

/* loaded from: classes.dex */
public final class h extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f742h;

    /* renamed from: i, reason: collision with root package name */
    public int f743i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ i f744j;

    /* renamed from: k, reason: collision with root package name */
    public Object f745k;

    /* renamed from: l, reason: collision with root package name */
    public e f746l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(i iVar, w0.c cVar) {
        super(cVar);
        this.f744j = iVar;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f742h = obj;
        this.f743i |= Integer.MIN_VALUE;
        return this.f744j.t(null, this);
    }
}
