package M0;

/* loaded from: classes.dex */
public final class g extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public Throwable f739h;

    /* renamed from: i, reason: collision with root package name */
    public /* synthetic */ Object f740i;

    /* renamed from: j, reason: collision with root package name */
    public int f741j;

    @Override // y0.a
    public final Object n(Object obj) {
        this.f740i = obj;
        this.f741j |= Integer.MIN_VALUE;
        return r.a(null, null, null, this);
    }
}
