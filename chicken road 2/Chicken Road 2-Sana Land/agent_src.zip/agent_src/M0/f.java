package M0;

/* loaded from: classes.dex */
public final class f extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public e f733h;

    /* renamed from: i, reason: collision with root package name */
    public L0.s f734i;

    /* renamed from: j, reason: collision with root package name */
    public L0.b f735j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f736k;

    /* renamed from: l, reason: collision with root package name */
    public /* synthetic */ Object f737l;

    /* renamed from: m, reason: collision with root package name */
    public int f738m;

    @Override // y0.a
    public final Object n(Object obj) {
        this.f737l = obj;
        this.f738m |= Integer.MIN_VALUE;
        return r.b(null, null, false, this);
    }
}
