package M0;

import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: a, reason: collision with root package name */
    public final AtomicReference f789a = new AtomicReference(null);
}
