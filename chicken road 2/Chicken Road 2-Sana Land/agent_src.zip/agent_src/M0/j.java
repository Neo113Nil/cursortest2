package M0;

import L.Q;

/* loaded from: classes.dex */
public final class j extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f749h;

    /* renamed from: i, reason: collision with root package name */
    public int f750i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Q f751j;

    /* renamed from: k, reason: collision with root package name */
    public Q f752k;

    /* renamed from: l, reason: collision with root package name */
    public e f753l;

    /* renamed from: m, reason: collision with root package name */
    public N0.l f754m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(Q q2, w0.c cVar) {
        super(cVar);
        this.f751j = q2;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f749h = obj;
        this.f750i |= Integer.MIN_VALUE;
        return this.f751j.t(null, this);
    }
}
