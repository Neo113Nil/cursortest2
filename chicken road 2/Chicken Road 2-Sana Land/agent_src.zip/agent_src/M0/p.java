package M0;

import J0.N;

/* loaded from: classes.dex */
public final class p extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public q f777h;

    /* renamed from: i, reason: collision with root package name */
    public e f778i;

    /* renamed from: j, reason: collision with root package name */
    public s f779j;

    /* renamed from: k, reason: collision with root package name */
    public N f780k;

    /* renamed from: l, reason: collision with root package name */
    public Object f781l;

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ Object f782m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ q f783n;

    /* renamed from: o, reason: collision with root package name */
    public int f784o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(q qVar, w0.c cVar) {
        super(cVar);
        this.f783n = qVar;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f782m = obj;
        this.f784o |= Integer.MIN_VALUE;
        this.f783n.t(null, this);
        return x0.a.f3053e;
    }
}
