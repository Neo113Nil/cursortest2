package M0;

import L.Q;
import s0.C0267n;

/* loaded from: classes.dex */
public final class m extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f764h;

    /* renamed from: i, reason: collision with root package name */
    public int f765i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Q f766j;

    /* renamed from: k, reason: collision with root package name */
    public C0267n f767k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(Q q2, w0.c cVar) {
        super(cVar);
        this.f766j = q2;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f764h = obj;
        this.f765i |= Integer.MIN_VALUE;
        return this.f766j.t(null, this);
    }
}
