package M0;

/* loaded from: classes.dex */
public final class t implements e {

    /* renamed from: e, reason: collision with root package name */
    public final Throwable f790e;

    public t(Throwable th) {
        this.f790e = th;
    }

    @Override // M0.e
    public final Object j(Object obj, w0.c cVar) {
        throw this.f790e;
    }
}
