package M0;

import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class c extends N0.e {

    /* renamed from: h, reason: collision with root package name */
    public final U.k f731h;

    /* renamed from: i, reason: collision with root package name */
    public final U.k f732i;

    public c(U.k kVar, w0.h hVar, int i2, L0.a aVar) {
        super(hVar, i2, aVar);
        this.f731h = kVar;
        this.f732i = kVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0053 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // N0.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object a(L0.r rVar, w0.c cVar) {
        b bVar;
        int i2;
        if (cVar instanceof b) {
            bVar = (b) cVar;
            int i3 = bVar.f730k;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                bVar.f730k = i3 - Integer.MIN_VALUE;
                Object obj = bVar.f728i;
                i2 = bVar.f730k;
                u0.g gVar = u0.g.f2964a;
                if (i2 != 0) {
                    AbstractC0230j.A(obj);
                    bVar.f727h = rVar;
                    bVar.f730k = 1;
                    Object h2 = this.f731h.h(rVar, bVar);
                    x0.a aVar = x0.a.f3053e;
                    if (h2 != aVar) {
                        h2 = gVar;
                    }
                    if (h2 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    rVar = bVar.f727h;
                    AbstractC0230j.A(obj);
                }
                if (((L0.q) rVar).f716h.s()) {
                    throw new IllegalStateException("'awaitClose { yourCallbackOrListener.cancel() }' should be used in the end of callbackFlow block.\nOtherwise, a callback/listener may leak in case of external cancellation.\nSee callbackFlow API documentation for the details.");
                }
                return gVar;
            }
        }
        bVar = new b(this, (y0.c) cVar);
        Object obj2 = bVar.f728i;
        i2 = bVar.f730k;
        u0.g gVar2 = u0.g.f2964a;
        if (i2 != 0) {
        }
        if (((L0.q) rVar).f716h.s()) {
        }
    }

    @Override // N0.e
    public final String toString() {
        return "block[" + this.f731h + "] -> " + super.toString();
    }
}
