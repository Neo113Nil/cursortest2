package M0;

/* loaded from: classes.dex */
public final class a extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public N0.l f723h;

    /* renamed from: i, reason: collision with root package name */
    public /* synthetic */ Object f724i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ A.j f725j;

    /* renamed from: k, reason: collision with root package name */
    public int f726k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(A.j jVar, w0.c cVar) {
        super(cVar);
        this.f725j = jVar;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f724i = obj;
        this.f726k |= Integer.MIN_VALUE;
        return this.f725j.t(null, this);
    }
}
