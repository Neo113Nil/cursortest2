package M0;

/* loaded from: classes.dex */
public interface e {
    Object j(Object obj, w0.c cVar);
}
