package M0;

import s0.C0267n;

/* loaded from: classes.dex */
public final class n extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public C0267n f768h;

    /* renamed from: i, reason: collision with root package name */
    public /* synthetic */ Object f769i;

    /* renamed from: j, reason: collision with root package name */
    public int f770j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ C0267n f771k;

    /* renamed from: l, reason: collision with root package name */
    public Object f772l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(C0267n c0267n, w0.c cVar) {
        super(cVar);
        this.f771k = c0267n;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f769i = obj;
        this.f770j |= Integer.MIN_VALUE;
        return this.f771k.j(null, this);
    }
}
