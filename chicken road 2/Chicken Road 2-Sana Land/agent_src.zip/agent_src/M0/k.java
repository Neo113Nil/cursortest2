package M0;

/* loaded from: classes.dex */
public final class k extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public l f755h;

    /* renamed from: i, reason: collision with root package name */
    public Object f756i;

    /* renamed from: j, reason: collision with root package name */
    public /* synthetic */ Object f757j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ l f758k;

    /* renamed from: l, reason: collision with root package name */
    public int f759l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(l lVar, w0.c cVar) {
        super(cVar);
        this.f758k = lVar;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f757j = obj;
        this.f759l |= Integer.MIN_VALUE;
        return this.f758k.j(null, this);
    }
}
