package M0;

/* loaded from: classes.dex */
public final class b extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public L0.r f727h;

    /* renamed from: i, reason: collision with root package name */
    public /* synthetic */ Object f728i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ c f729j;

    /* renamed from: k, reason: collision with root package name */
    public int f730k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(c cVar, y0.c cVar2) {
        super(cVar2);
        this.f729j = cVar;
    }

    @Override // y0.a
    public final Object n(Object obj) {
        this.f728i = obj;
        this.f730k |= Integer.MIN_VALUE;
        return this.f729j.a(null, this);
    }
}
