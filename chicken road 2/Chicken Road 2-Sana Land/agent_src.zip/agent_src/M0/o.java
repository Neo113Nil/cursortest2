package M0;

import D.D;

/* loaded from: classes.dex */
public final class o extends y0.c {

    /* renamed from: h, reason: collision with root package name */
    public E0.p f773h;

    /* renamed from: i, reason: collision with root package name */
    public D f774i;

    /* renamed from: j, reason: collision with root package name */
    public /* synthetic */ Object f775j;

    /* renamed from: k, reason: collision with root package name */
    public int f776k;

    @Override // y0.a
    public final Object n(Object obj) {
        this.f775j = obj;
        this.f776k |= Integer.MIN_VALUE;
        return r.c(null, this);
    }
}
