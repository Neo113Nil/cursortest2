package B;

import F.j;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.Settings;
import c0.s;
import h.f0;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.view.i;

/* loaded from: classes.dex */
public final class a extends ContentObserver {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f40a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f41b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(Object obj, Handler handler, int i2) {
        super(handler);
        this.f40a = i2;
        this.f41b = obj;
    }

    @Override // android.database.ContentObserver
    public boolean deliverSelfNotifications() {
        switch (this.f40a) {
            case 0:
                return true;
            case 1:
                return true;
            default:
                return super.deliverSelfNotifications();
        }
    }

    @Override // android.database.ContentObserver
    public final void onChange(boolean z2) {
        Cursor cursor;
        switch (this.f40a) {
            case 0:
                f0 f0Var = (f0) this.f41b;
                if (f0Var.f45f && (cursor = f0Var.f46g) != null && !cursor.isClosed()) {
                    f0Var.f44e = f0Var.f46g.requery();
                    break;
                }
                break;
            case 1:
                super.onChange(z2);
                s sVar = (s) this.f41b;
                if (sVar.f1726n != null) {
                    sVar.d();
                    break;
                }
                break;
            default:
                onChange(z2, null);
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(f0 f0Var) {
        super(new Handler());
        this.f40a = 0;
        this.f41b = f0Var;
    }

    @Override // android.database.ContentObserver
    public void onChange(boolean z2, Uri uri) {
        switch (this.f40a) {
            case j.FLOAT_FIELD_NUMBER /* 2 */:
                i iVar = (i) this.f41b;
                if (!iVar.f2572t) {
                    if (Settings.Global.getFloat(iVar.f2559f, "transition_animation_scale", 1.0f) == 0.0f) {
                        iVar.f2564k |= 4;
                    } else {
                        iVar.f2564k &= -5;
                    }
                    ((FlutterJNI) iVar.f2555b.f583f).setAccessibilityFeatures(iVar.f2564k);
                    break;
                }
                break;
            default:
                super.onChange(z2, uri);
                break;
        }
    }
}
