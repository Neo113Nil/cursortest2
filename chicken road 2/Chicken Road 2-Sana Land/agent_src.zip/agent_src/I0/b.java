package I0;

import a.AbstractC0068a;

/* loaded from: classes.dex */
public abstract class b extends AbstractC0068a {
}
