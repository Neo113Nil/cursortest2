package l;

/* renamed from: l.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0195a {

    /* renamed from: b, reason: collision with root package name */
    public static final C0195a f2635b;

    /* renamed from: c, reason: collision with root package name */
    public static final C0195a f2636c;

    /* renamed from: a, reason: collision with root package name */
    public final Throwable f2637a;

    static {
        if (AbstractFutureC0201g.f2648h) {
            f2636c = null;
            f2635b = null;
        } else {
            f2636c = new C0195a(null, false);
            f2635b = new C0195a(null, true);
        }
    }

    public C0195a(Throwable th, boolean z2) {
        this.f2637a = th;
    }
}
