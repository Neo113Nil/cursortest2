package l;

import a.AbstractC0068a;

/* renamed from: l.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0199e extends AbstractC0068a {
    @Override // a.AbstractC0068a
    public final void A(C0200f c0200f, C0200f c0200f2) {
        c0200f.f2647b = c0200f2;
    }

    @Override // a.AbstractC0068a
    public final void B(C0200f c0200f, Thread thread) {
        c0200f.f2646a = thread;
    }

    @Override // a.AbstractC0068a
    public final boolean f(AbstractFutureC0201g abstractFutureC0201g, C0197c c0197c) {
        C0197c c0197c2 = C0197c.f2638b;
        synchronized (abstractFutureC0201g) {
            try {
                if (abstractFutureC0201g.f2653f != c0197c) {
                    return false;
                }
                abstractFutureC0201g.f2653f = c0197c2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // a.AbstractC0068a
    public final boolean g(AbstractFutureC0201g abstractFutureC0201g, Object obj, Object obj2) {
        synchronized (abstractFutureC0201g) {
            try {
                if (abstractFutureC0201g.f2652e != obj) {
                    return false;
                }
                abstractFutureC0201g.f2652e = obj2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // a.AbstractC0068a
    public final boolean h(AbstractFutureC0201g abstractFutureC0201g, C0200f c0200f, C0200f c0200f2) {
        synchronized (abstractFutureC0201g) {
            try {
                if (abstractFutureC0201g.f2654g != c0200f) {
                    return false;
                }
                abstractFutureC0201g.f2654g = c0200f2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
