package l;

/* renamed from: l.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0197c {

    /* renamed from: b, reason: collision with root package name */
    public static final C0197c f2638b = new C0197c();

    /* renamed from: a, reason: collision with root package name */
    public C0197c f2639a;
}
