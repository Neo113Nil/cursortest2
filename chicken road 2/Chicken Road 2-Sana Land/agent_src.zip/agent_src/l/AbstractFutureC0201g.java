package l;

import a.AbstractC0068a;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: l.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractFutureC0201g implements Future {

    /* renamed from: h, reason: collision with root package name */
    public static final boolean f2648h = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* renamed from: i, reason: collision with root package name */
    public static final Logger f2649i = Logger.getLogger(AbstractFutureC0201g.class.getName());

    /* renamed from: j, reason: collision with root package name */
    public static final AbstractC0068a f2650j;

    /* renamed from: k, reason: collision with root package name */
    public static final Object f2651k;

    /* renamed from: e, reason: collision with root package name */
    public volatile Object f2652e;

    /* renamed from: f, reason: collision with root package name */
    public volatile C0197c f2653f;

    /* renamed from: g, reason: collision with root package name */
    public volatile C0200f f2654g;

    static {
        AbstractC0068a c0199e;
        try {
            c0199e = new C0198d(AtomicReferenceFieldUpdater.newUpdater(C0200f.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(C0200f.class, C0200f.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0201g.class, C0200f.class, "g"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0201g.class, C0197c.class, "f"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0201g.class, Object.class, "e"));
            th = null;
        } catch (Throwable th) {
            th = th;
            c0199e = new C0199e();
        }
        f2650j = c0199e;
        if (th != null) {
            f2649i.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        f2651k = new Object();
    }

    public static void b(AbstractFutureC0201g abstractFutureC0201g) {
        C0200f c0200f;
        C0197c c0197c;
        do {
            c0200f = abstractFutureC0201g.f2654g;
        } while (!f2650j.h(abstractFutureC0201g, c0200f, C0200f.f2645c));
        while (c0200f != null) {
            Thread thread = c0200f.f2646a;
            if (thread != null) {
                c0200f.f2646a = null;
                LockSupport.unpark(thread);
            }
            c0200f = c0200f.f2647b;
        }
        do {
            c0197c = abstractFutureC0201g.f2653f;
        } while (!f2650j.f(abstractFutureC0201g, c0197c));
        C0197c c0197c2 = null;
        while (c0197c != null) {
            C0197c c0197c3 = c0197c.f2639a;
            c0197c.f2639a = c0197c2;
            c0197c2 = c0197c;
            c0197c = c0197c3;
        }
        while (c0197c2 != null) {
            c0197c2 = c0197c2.f2639a;
            try {
                throw null;
            } catch (RuntimeException e2) {
                f2649i.log(Level.SEVERE, "RuntimeException while executing runnable null with executor null", (Throwable) e2);
            }
        }
    }

    public static Object c(Object obj) {
        if (obj instanceof C0195a) {
            Throwable th = ((C0195a) obj).f2637a;
            CancellationException cancellationException = new CancellationException("Task was cancelled.");
            cancellationException.initCause(th);
            throw cancellationException;
        }
        if (obj instanceof AbstractC0196b) {
            ((AbstractC0196b) obj).getClass();
            throw new ExecutionException((Throwable) null);
        }
        if (obj == f2651k) {
            return null;
        }
        return obj;
    }

    public static Object d(AbstractFutureC0201g abstractFutureC0201g) {
        Object obj;
        boolean z2 = false;
        while (true) {
            try {
                obj = abstractFutureC0201g.get();
                break;
            } catch (InterruptedException unused) {
                z2 = true;
            } catch (Throwable th) {
                if (z2) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z2) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(StringBuilder sb) {
        try {
            Object d2 = d(this);
            sb.append("SUCCESS, result=[");
            sb.append(d2 == this ? "this future" : String.valueOf(d2));
            sb.append("]");
        } catch (CancellationException unused) {
            sb.append("CANCELLED");
        } catch (RuntimeException e2) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e2.getClass());
            sb.append(" thrown from get()]");
        } catch (ExecutionException e3) {
            sb.append("FAILURE, cause=[");
            sb.append(e3.getCause());
            sb.append("]");
        }
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z2) {
        Object obj = this.f2652e;
        if (obj != null) {
            return false;
        }
        if (!f2650j.g(this, obj, f2648h ? new C0195a(new CancellationException("Future.cancel() was called."), z2) : z2 ? C0195a.f2635b : C0195a.f2636c)) {
            return false;
        }
        b(this);
        return true;
    }

    public final void e(C0200f c0200f) {
        c0200f.f2646a = null;
        while (true) {
            C0200f c0200f2 = this.f2654g;
            if (c0200f2 == C0200f.f2645c) {
                return;
            }
            C0200f c0200f3 = null;
            while (c0200f2 != null) {
                C0200f c0200f4 = c0200f2.f2647b;
                if (c0200f2.f2646a != null) {
                    c0200f3 = c0200f2;
                } else if (c0200f3 != null) {
                    c0200f3.f2647b = c0200f4;
                    if (c0200f3.f2646a == null) {
                        break;
                    }
                } else if (!f2650j.h(this, c0200f2, c0200f4)) {
                    break;
                }
                c0200f2 = c0200f4;
            }
            return;
        }
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j2, TimeUnit timeUnit) {
        C0200f c0200f = C0200f.f2645c;
        long nanos = timeUnit.toNanos(j2);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f2652e;
        if (obj != null) {
            return c(obj);
        }
        long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            C0200f c0200f2 = this.f2654g;
            if (c0200f2 != c0200f) {
                C0200f c0200f3 = new C0200f();
                do {
                    AbstractC0068a abstractC0068a = f2650j;
                    abstractC0068a.A(c0200f3, c0200f2);
                    if (abstractC0068a.h(this, c0200f2, c0200f3)) {
                        do {
                            LockSupport.parkNanos(this, nanos);
                            if (Thread.interrupted()) {
                                e(c0200f3);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f2652e;
                            if (obj2 != null) {
                                return c(obj2);
                            }
                            nanos = nanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        e(c0200f3);
                    } else {
                        c0200f2 = this.f2654g;
                    }
                } while (c0200f2 != c0200f);
            }
            return c(this.f2652e);
        }
        while (nanos > 0) {
            Object obj3 = this.f2652e;
            if (obj3 != null) {
                return c(obj3);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = nanoTime - System.nanoTime();
        }
        String abstractFutureC0201g = toString();
        String obj4 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = obj4.toLowerCase(locale);
        String str = "Waited " + j2 + " " + timeUnit.toString().toLowerCase(locale);
        if (nanos + 1000 < 0) {
            String str2 = str + " (plus ";
            long j3 = -nanos;
            long convert = timeUnit.convert(j3, TimeUnit.NANOSECONDS);
            long nanos2 = j3 - timeUnit.toNanos(convert);
            boolean z2 = convert == 0 || nanos2 > 1000;
            if (convert > 0) {
                String str3 = str2 + convert + " " + lowerCase;
                if (z2) {
                    str3 = str3 + ",";
                }
                str2 = str3 + " ";
            }
            if (z2) {
                str2 = str2 + nanos2 + " nanoseconds ";
            }
            str = str2 + "delay)";
        }
        if (isDone()) {
            throw new TimeoutException(str + " but future completed as timeout expired");
        }
        throw new TimeoutException(str + " for " + abstractFutureC0201g);
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f2652e instanceof C0195a;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return this.f2652e != null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (this.f2652e instanceof C0195a) {
            sb.append("CANCELLED");
        } else if (isDone()) {
            a(sb);
        } else {
            try {
                if (this instanceof ScheduledFuture) {
                    str = "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
                } else {
                    str = null;
                }
            } catch (RuntimeException e2) {
                str = "Exception thrown from implementation: " + e2.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb.append("PENDING, info=[");
                sb.append(str);
                sb.append("]");
            } else if (isDone()) {
                a(sb);
            } else {
                sb.append("PENDING");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        Object obj;
        C0200f c0200f = C0200f.f2645c;
        if (!Thread.interrupted()) {
            Object obj2 = this.f2652e;
            if (obj2 != null) {
                return c(obj2);
            }
            C0200f c0200f2 = this.f2654g;
            if (c0200f2 != c0200f) {
                C0200f c0200f3 = new C0200f();
                do {
                    AbstractC0068a abstractC0068a = f2650j;
                    abstractC0068a.A(c0200f3, c0200f2);
                    if (abstractC0068a.h(this, c0200f2, c0200f3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f2652e;
                            } else {
                                e(c0200f3);
                                throw new InterruptedException();
                            }
                        } while (obj == null);
                        return c(obj);
                    }
                    c0200f2 = this.f2654g;
                } while (c0200f2 != c0200f);
            }
            return c(this.f2652e);
        }
        throw new InterruptedException();
    }
}
