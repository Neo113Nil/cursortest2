package l;

import a.AbstractC0068a;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* renamed from: l.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0198d extends AbstractC0068a {

    /* renamed from: i, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2640i;

    /* renamed from: j, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2641j;

    /* renamed from: k, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2642k;

    /* renamed from: l, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2643l;

    /* renamed from: m, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2644m;

    public C0198d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f2640i = atomicReferenceFieldUpdater;
        this.f2641j = atomicReferenceFieldUpdater2;
        this.f2642k = atomicReferenceFieldUpdater3;
        this.f2643l = atomicReferenceFieldUpdater4;
        this.f2644m = atomicReferenceFieldUpdater5;
    }

    @Override // a.AbstractC0068a
    public final void A(C0200f c0200f, C0200f c0200f2) {
        this.f2641j.lazySet(c0200f, c0200f2);
    }

    @Override // a.AbstractC0068a
    public final void B(C0200f c0200f, Thread thread) {
        this.f2640i.lazySet(c0200f, thread);
    }

    @Override // a.AbstractC0068a
    public final boolean f(AbstractFutureC0201g abstractFutureC0201g, C0197c c0197c) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f2643l;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0201g, c0197c, C0197c.f2638b)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0201g) == c0197c);
        return false;
    }

    @Override // a.AbstractC0068a
    public final boolean g(AbstractFutureC0201g abstractFutureC0201g, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f2644m;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0201g, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0201g) == obj);
        return false;
    }

    @Override // a.AbstractC0068a
    public final boolean h(AbstractFutureC0201g abstractFutureC0201g, C0200f c0200f, C0200f c0200f2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f2642k;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0201g, c0200f, c0200f2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0201g) == c0200f);
        return false;
    }
}
