package l;

/* renamed from: l.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0200f {

    /* renamed from: c, reason: collision with root package name */
    public static final C0200f f2645c = new C0200f();

    /* renamed from: a, reason: collision with root package name */
    public volatile Thread f2646a;

    /* renamed from: b, reason: collision with root package name */
    public volatile C0200f f2647b;

    public C0200f() {
        AbstractFutureC0201g.f2650j.B(this, Thread.currentThread());
    }
}
