package p;

import L.Q;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import h.C0177s;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import l0.C0206d;
import m0.AbstractC0230j;
import t.k;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final AbstractC0230j f2767a;

    /* renamed from: b, reason: collision with root package name */
    public static final k.d f2768b;

    static {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 29) {
            f2767a = new i();
        } else if (i2 >= 28) {
            f2767a = new h();
        } else if (i2 >= 26) {
            f2767a = new g();
        } else {
            Method method = f.f2776c;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                f2767a = new f();
            } else {
                f2767a = new e();
            }
        }
        f2768b = new k.d(16);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0027, code lost:
    
        if (r1.equals(r3) == false) goto L15;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Typeface a(Context context, o.b bVar, Resources resources, int i2, String str, int i3, int i4, C0177s c0177s) {
        Typeface g2;
        Typeface typeface;
        if (bVar instanceof o.e) {
            o.e eVar = (o.e) bVar;
            String str2 = eVar.f2757d;
            g2 = null;
            boolean z2 = false;
            Object[] objArr = 0;
            Object[] objArr2 = 0;
            if (str2 != null && !str2.isEmpty()) {
                typeface = Typeface.create(str2, 0);
                Typeface create = Typeface.create(Typeface.DEFAULT, 0);
                if (typeface != null) {
                }
            }
            typeface = null;
            if (typeface != null) {
                new Handler(Looper.getMainLooper()).post(new o.f(c0177s, typeface));
                return typeface;
            }
            int i5 = 1;
            Object[] objArr3 = eVar.f2756c == 0;
            int i6 = eVar.f2755b;
            Handler handler = new Handler(Looper.getMainLooper());
            C0206d c0206d = new C0206d();
            c0206d.f2662f = c0177s;
            t.c cVar = eVar.f2754a;
            Q q2 = new Q(25, c0206d, handler);
            int i7 = 3;
            if (objArr3 == true) {
                k.d dVar = t.g.f2940a;
                String str3 = cVar.f2930e + "-" + i4;
                Typeface typeface2 = (Typeface) t.g.f2940a.a(str3);
                if (typeface2 != null) {
                    handler.post(new O0.g(c0206d, typeface2, i7, z2));
                    g2 = typeface2;
                } else if (i6 == -1) {
                    t.f a2 = t.g.a(str3, context, cVar, i4);
                    q2.A(a2);
                    g2 = a2.f2938a;
                } else {
                    try {
                        try {
                            try {
                                try {
                                    t.f fVar = (t.f) t.g.f2941b.submit(new t.d(str3, context, cVar, i4, 0)).get(i6, TimeUnit.MILLISECONDS);
                                    q2.A(fVar);
                                    g2 = fVar.f2938a;
                                } catch (TimeoutException unused) {
                                    throw new InterruptedException("timeout");
                                }
                            } catch (InterruptedException e2) {
                                throw e2;
                            }
                        } catch (ExecutionException e3) {
                            throw new RuntimeException(e3);
                        }
                    } catch (InterruptedException unused2) {
                        ((Handler) q2.f579g).post(new A.b((C0206d) q2.f578f, -3));
                    }
                }
            } else {
                k.d dVar2 = t.g.f2940a;
                String str4 = cVar.f2930e + "-" + i4;
                Typeface typeface3 = (Typeface) t.g.f2940a.a(str4);
                if (typeface3 != null) {
                    handler.post(new O0.g(c0206d, typeface3, i7, objArr2 == true ? 1 : 0));
                    g2 = typeface3;
                } else {
                    t.e eVar2 = new t.e(objArr == true ? 1 : 0, q2);
                    synchronized (t.g.f2942c) {
                        try {
                            k.i iVar = t.g.f2943d;
                            ArrayList arrayList = (ArrayList) iVar.getOrDefault(str4, null);
                            if (arrayList != null) {
                                arrayList.add(eVar2);
                            } else {
                                ArrayList arrayList2 = new ArrayList();
                                arrayList2.add(eVar2);
                                iVar.put(str4, arrayList2);
                                t.d dVar3 = new t.d(str4, context, cVar, i4, 1);
                                ThreadPoolExecutor threadPoolExecutor = t.g.f2941b;
                                t.e eVar3 = new t.e(i5, str4);
                                Handler handler2 = Looper.myLooper() == null ? new Handler(Looper.getMainLooper()) : new Handler();
                                k kVar = new k();
                                kVar.f2950e = dVar3;
                                kVar.f2951f = eVar3;
                                kVar.f2952g = handler2;
                                threadPoolExecutor.execute(kVar);
                            }
                        } finally {
                        }
                    }
                }
            }
        } else {
            g2 = f2767a.g(context, (o.c) bVar, resources, i4);
            if (g2 != null) {
                new Handler(Looper.getMainLooper()).post(new o.f(c0177s, g2));
            } else {
                c0177s.a();
            }
        }
        if (g2 != null) {
            f2768b.b(b(resources, i2, str, i3, i4), g2);
        }
        return g2;
    }

    public static String b(Resources resources, int i2, String str, int i3, int i4) {
        return resources.getResourcePackageName(i2) + '-' + str + '-' + i3 + '-' + i2 + '-' + i4;
    }
}
