package p;

import android.graphics.Insets;

/* renamed from: p.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0245c {

    /* renamed from: e, reason: collision with root package name */
    public static final C0245c f2762e = new C0245c(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f2763a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2764b;

    /* renamed from: c, reason: collision with root package name */
    public final int f2765c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2766d;

    public C0245c(int i2, int i3, int i4, int i5) {
        this.f2763a = i2;
        this.f2764b = i3;
        this.f2765c = i4;
        this.f2766d = i5;
    }

    public static C0245c a(int i2, int i3, int i4, int i5) {
        return (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? f2762e : new C0245c(i2, i3, i4, i5);
    }

    public static C0245c b(Insets insets) {
        int i2;
        int i3;
        int i4;
        int i5;
        i2 = insets.left;
        i3 = insets.top;
        i4 = insets.right;
        i5 = insets.bottom;
        return a(i2, i3, i4, i5);
    }

    public final Insets c() {
        return AbstractC0244b.a(this.f2763a, this.f2764b, this.f2765c, this.f2766d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0245c.class != obj.getClass()) {
            return false;
        }
        C0245c c0245c = (C0245c) obj;
        return this.f2766d == c0245c.f2766d && this.f2763a == c0245c.f2763a && this.f2765c == c0245c.f2765c && this.f2764b == c0245c.f2764b;
    }

    public final int hashCode() {
        return (((((this.f2763a * 31) + this.f2764b) * 31) + this.f2765c) * 31) + this.f2766d;
    }

    public final String toString() {
        return "Insets{left=" + this.f2763a + ", top=" + this.f2764b + ", right=" + this.f2765c + ", bottom=" + this.f2766d + '}';
    }
}
