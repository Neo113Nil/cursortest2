package p;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public class g extends e {

    /* renamed from: f, reason: collision with root package name */
    public final Class f2778f;

    /* renamed from: g, reason: collision with root package name */
    public final Constructor f2779g;

    /* renamed from: h, reason: collision with root package name */
    public final Method f2780h;

    /* renamed from: i, reason: collision with root package name */
    public final Method f2781i;

    /* renamed from: j, reason: collision with root package name */
    public final Method f2782j;

    /* renamed from: k, reason: collision with root package name */
    public final Method f2783k;

    /* renamed from: l, reason: collision with root package name */
    public final Method f2784l;

    public g() {
        Method method;
        Constructor<?> constructor;
        Method method2;
        Method method3;
        Method method4;
        Method method5;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            method2 = K(cls2);
            Class cls3 = Integer.TYPE;
            method3 = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method4 = cls2.getMethod("freeze", null);
            method5 = cls2.getMethod("abortCreation", null);
            method = L(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e2.getClass().getName()), e2);
            method = null;
            constructor = null;
            method2 = null;
            method3 = null;
            method4 = null;
            method5 = null;
        }
        this.f2778f = cls;
        this.f2779g = constructor;
        this.f2780h = method2;
        this.f2781i = method3;
        this.f2782j = method4;
        this.f2783k = method5;
        this.f2784l = method;
    }

    public static Method K(Class cls) {
        Class cls2 = Boolean.TYPE;
        Class cls3 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls3, cls2, cls3, cls3, cls3, FontVariationAxis[].class);
    }

    public final boolean H(Context context, Object obj, String str, int i2, int i3, int i4, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f2780h.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Typeface I(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) this.f2778f, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.f2784l.invoke(null, newInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean J(Object obj) {
        try {
            return ((Boolean) this.f2782j.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Method L(Class cls) {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    @Override // p.e, m0.AbstractC0230j
    public final Typeface g(Context context, o.c cVar, Resources resources, int i2) {
        Object obj;
        Method method = this.f2780h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.g(context, cVar, resources, i2);
        }
        try {
            obj = this.f2779g.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            o.d[] dVarArr = cVar.f2747a;
            int length = dVarArr.length;
            int i3 = 0;
            while (true) {
                if (i3 < length) {
                    o.d dVar = dVarArr[i3];
                    Context context2 = context;
                    if (H(context2, obj, dVar.f2748a, dVar.f2752e, dVar.f2749b, dVar.f2750c ? 1 : 0, FontVariationAxis.fromFontVariationSettings(dVar.f2751d))) {
                        i3++;
                        context = context2;
                    } else {
                        try {
                            this.f2783k.invoke(obj, null);
                            break;
                        } catch (IllegalAccessException | InvocationTargetException unused2) {
                        }
                    }
                } else if (J(obj)) {
                    return I(obj);
                }
            }
        }
        return null;
    }

    @Override // p.e, m0.AbstractC0230j
    public final Typeface h(Context context, t.h[] hVarArr, int i2) {
        Object obj;
        Typeface I2;
        boolean z2;
        if (hVarArr.length >= 1) {
            Method method = this.f2780h;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            try {
                if (method != null) {
                    HashMap hashMap = new HashMap();
                    for (t.h hVar : hVarArr) {
                        if (hVar.f2948e == 0) {
                            Uri uri = hVar.f2944a;
                            if (!hashMap.containsKey(uri)) {
                                hashMap.put(uri, AbstractC0230j.u(context, uri));
                            }
                        }
                    }
                    Map unmodifiableMap = Collections.unmodifiableMap(hashMap);
                    try {
                        obj = this.f2779g.newInstance(null);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                        obj = null;
                    }
                    if (obj != null) {
                        int length = hVarArr.length;
                        int i3 = 0;
                        boolean z3 = false;
                        while (true) {
                            Method method2 = this.f2783k;
                            if (i3 < length) {
                                t.h hVar2 = hVarArr[i3];
                                ByteBuffer byteBuffer = (ByteBuffer) unmodifiableMap.get(hVar2.f2944a);
                                if (byteBuffer != null) {
                                    try {
                                        z2 = ((Boolean) this.f2781i.invoke(obj, byteBuffer, Integer.valueOf(hVar2.f2945b), null, Integer.valueOf(hVar2.f2946c), Integer.valueOf(hVar2.f2947d ? 1 : 0))).booleanValue();
                                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                                        z2 = false;
                                    }
                                    if (!z2) {
                                        method2.invoke(obj, null);
                                        break;
                                    }
                                    z3 = true;
                                }
                                i3++;
                                z3 = z3;
                            } else if (!z3) {
                                method2.invoke(obj, null);
                            } else if (J(obj) && (I2 = I(obj)) != null) {
                                return Typeface.create(I2, i2);
                            }
                        }
                    }
                } else {
                    t.h l2 = l(hVarArr, i2);
                    ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(l2.f2944a, "r", null);
                    if (openFileDescriptor != null) {
                        try {
                            Typeface build = new Typeface.Builder(openFileDescriptor.getFileDescriptor()).setWeight(l2.f2946c).setItalic(l2.f2947d).build();
                            openFileDescriptor.close();
                            return build;
                        } finally {
                        }
                    }
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                        return null;
                    }
                }
            } catch (IOException | IllegalAccessException | InvocationTargetException unused3) {
            }
        }
        return null;
    }

    @Override // m0.AbstractC0230j
    public final Typeface j(Context context, Resources resources, int i2, String str, int i3) {
        Object obj;
        Method method = this.f2780h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.j(context, resources, i2, str, i3);
        }
        try {
            obj = this.f2779g.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            if (!H(context, obj, str, 0, -1, -1, null)) {
                try {
                    this.f2783k.invoke(obj, null);
                } catch (IllegalAccessException | InvocationTargetException unused2) {
                }
            } else if (J(obj)) {
                return I(obj);
            }
        }
        return null;
    }
}
