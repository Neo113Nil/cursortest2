package p;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class f extends AbstractC0230j {

    /* renamed from: a, reason: collision with root package name */
    public static final Class f2774a;

    /* renamed from: b, reason: collision with root package name */
    public static final Constructor f2775b;

    /* renamed from: c, reason: collision with root package name */
    public static final Method f2776c;

    /* renamed from: d, reason: collision with root package name */
    public static final Method f2777d;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            Class cls2 = Integer.TYPE;
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi24Impl", e2.getClass().getName(), e2);
            cls = null;
            method = null;
            method2 = null;
        }
        f2775b = constructor;
        f2774a = cls;
        f2776c = method2;
        f2777d = method;
    }

    public static boolean F(Object obj, ByteBuffer byteBuffer, int i2, int i3, boolean z2) {
        try {
            return ((Boolean) f2776c.invoke(obj, byteBuffer, Integer.valueOf(i2), null, Integer.valueOf(i3), Boolean.valueOf(z2))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public static Typeface G(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) f2774a, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) f2777d.invoke(null, newInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    @Override // m0.AbstractC0230j
    public final Typeface g(Context context, o.c cVar, Resources resources, int i2) {
        Object obj;
        int i3;
        MappedByteBuffer mappedByteBuffer;
        FileInputStream fileInputStream;
        try {
            obj = f2775b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            for (o.d dVar : cVar.f2747a) {
                int i4 = dVar.f2753f;
                File p2 = AbstractC0230j.p(context);
                if (p2 != null) {
                    try {
                        if (AbstractC0230j.d(p2, resources, i4)) {
                            try {
                                fileInputStream = new FileInputStream(p2);
                            } catch (IOException unused2) {
                                mappedByteBuffer = null;
                            }
                            try {
                                FileChannel channel = fileInputStream.getChannel();
                                mappedByteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                                fileInputStream.close();
                                i3 = (mappedByteBuffer != null && F(obj, mappedByteBuffer, dVar.f2752e, dVar.f2749b, dVar.f2750c)) ? i3 + 1 : 0;
                            } finally {
                            }
                        }
                    } finally {
                        p2.delete();
                    }
                }
                mappedByteBuffer = null;
                if (mappedByteBuffer != null) {
                }
            }
            return G(obj);
        }
        return null;
    }

    @Override // m0.AbstractC0230j
    public final Typeface h(Context context, t.h[] hVarArr, int i2) {
        Object obj;
        try {
            obj = f2775b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            k.i iVar = new k.i();
            int length = hVarArr.length;
            int i3 = 0;
            while (true) {
                if (i3 < length) {
                    t.h hVar = hVarArr[i3];
                    Uri uri = hVar.f2944a;
                    ByteBuffer byteBuffer = (ByteBuffer) iVar.getOrDefault(uri, null);
                    if (byteBuffer == null) {
                        byteBuffer = AbstractC0230j.u(context, uri);
                        iVar.put(uri, byteBuffer);
                    }
                    if (byteBuffer == null || !F(obj, byteBuffer, hVar.f2945b, hVar.f2946c, hVar.f2947d)) {
                        break;
                    }
                    i3++;
                } else {
                    Typeface G2 = G(obj);
                    if (G2 != null) {
                        return Typeface.create(G2, i2);
                    }
                }
            }
        }
        return null;
    }
}
