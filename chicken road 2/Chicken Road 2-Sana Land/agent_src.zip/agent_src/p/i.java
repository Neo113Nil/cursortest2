package p;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.os.ParcelFileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class i extends AbstractC0230j {
    public static Font F(FontFamily fontFamily, int i2) {
        FontStyle fontStyle = new FontStyle((i2 & 1) != 0 ? 700 : 400, (i2 & 2) != 0 ? 1 : 0);
        Font font = fontFamily.getFont(0);
        int G2 = G(fontStyle, font.getStyle());
        for (int i3 = 1; i3 < fontFamily.getSize(); i3++) {
            Font font2 = fontFamily.getFont(i3);
            int G3 = G(fontStyle, font2.getStyle());
            if (G3 < G2) {
                font = font2;
                G2 = G3;
            }
        }
        return font;
    }

    public static int G(FontStyle fontStyle, FontStyle fontStyle2) {
        return (Math.abs(fontStyle.getWeight() - fontStyle2.getWeight()) / 100) + (fontStyle.getSlant() == fontStyle2.getSlant() ? 0 : 2);
    }

    @Override // m0.AbstractC0230j
    public final Typeface g(Context context, o.c cVar, Resources resources, int i2) {
        try {
            FontFamily.Builder builder = null;
            for (o.d dVar : cVar.f2747a) {
                try {
                    Font build = new Font.Builder(resources, dVar.f2753f).setWeight(dVar.f2749b).setSlant(dVar.f2750c ? 1 : 0).setTtcIndex(dVar.f2752e).setFontVariationSettings(dVar.f2751d).build();
                    if (builder == null) {
                        builder = new FontFamily.Builder(build);
                    } else {
                        builder.addFont(build);
                    }
                } catch (IOException unused) {
                }
            }
            if (builder == null) {
                return null;
            }
            FontFamily build2 = builder.build();
            return new Typeface.CustomFallbackBuilder(build2).setStyle(F(build2, i2).getStyle()).build();
        } catch (Exception unused2) {
            return null;
        }
    }

    @Override // m0.AbstractC0230j
    public final Typeface h(Context context, t.h[] hVarArr, int i2) {
        int i3;
        ParcelFileDescriptor openFileDescriptor;
        ContentResolver contentResolver = context.getContentResolver();
        try {
            int length = hVarArr.length;
            FontFamily.Builder builder = null;
            while (i3 < length) {
                t.h hVar = hVarArr[i3];
                try {
                    openFileDescriptor = contentResolver.openFileDescriptor(hVar.f2944a, "r", null);
                } catch (IOException unused) {
                }
                if (openFileDescriptor == null) {
                    i3 = openFileDescriptor == null ? i3 + 1 : 0;
                } else {
                    try {
                        Font build = new Font.Builder(openFileDescriptor).setWeight(hVar.f2946c).setSlant(hVar.f2947d ? 1 : 0).setTtcIndex(hVar.f2945b).build();
                        if (builder == null) {
                            builder = new FontFamily.Builder(build);
                        } else {
                            builder.addFont(build);
                        }
                    } catch (Throwable th) {
                        try {
                            openFileDescriptor.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                }
                openFileDescriptor.close();
            }
            if (builder != null) {
                FontFamily build2 = builder.build();
                return new Typeface.CustomFallbackBuilder(build2).setStyle(F(build2, i2).getStyle()).build();
            }
        } catch (Exception unused2) {
        }
        return null;
    }

    @Override // m0.AbstractC0230j
    public final Typeface i(Context context, InputStream inputStream) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    @Override // m0.AbstractC0230j
    public final Typeface j(Context context, Resources resources, int i2, String str, int i3) {
        try {
            Font build = new Font.Builder(resources, i2).build();
            return new Typeface.CustomFallbackBuilder(new FontFamily.Builder(build).build()).setStyle(build.getStyle()).build();
        } catch (Exception unused) {
            return null;
        }
    }

    @Override // m0.AbstractC0230j
    public final t.h l(t.h[] hVarArr, int i2) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
}
