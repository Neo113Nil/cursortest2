package p;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public class e extends AbstractC0230j {

    /* renamed from: a, reason: collision with root package name */
    public static Class f2769a = null;

    /* renamed from: b, reason: collision with root package name */
    public static Constructor f2770b = null;

    /* renamed from: c, reason: collision with root package name */
    public static Method f2771c = null;

    /* renamed from: d, reason: collision with root package name */
    public static Method f2772d = null;

    /* renamed from: e, reason: collision with root package name */
    public static boolean f2773e = false;

    public static boolean F(Object obj, String str, int i2, boolean z2) {
        G();
        try {
            return ((Boolean) f2771c.invoke(obj, str, Integer.valueOf(i2), Boolean.valueOf(z2))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public static void G() {
        Method method;
        Class<?> cls;
        Method method2;
        if (f2773e) {
            return;
        }
        f2773e = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi21Impl", e2.getClass().getName(), e2);
            method = null;
            cls = null;
            method2 = null;
        }
        f2770b = constructor;
        f2769a = cls;
        f2771c = method2;
        f2772d = method;
    }

    @Override // m0.AbstractC0230j
    public Typeface g(Context context, o.c cVar, Resources resources, int i2) {
        G();
        try {
            Object newInstance = f2770b.newInstance(null);
            for (o.d dVar : cVar.f2747a) {
                File p2 = AbstractC0230j.p(context);
                if (p2 == null) {
                    return null;
                }
                try {
                    if (!AbstractC0230j.d(p2, resources, dVar.f2753f)) {
                        return null;
                    }
                    if (!F(newInstance, p2.getPath(), dVar.f2749b, dVar.f2750c)) {
                        return null;
                    }
                    p2.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    p2.delete();
                }
            }
            G();
            try {
                Object newInstance2 = Array.newInstance((Class<?>) f2769a, 1);
                Array.set(newInstance2, 0, newInstance);
                return (Typeface) f2772d.invoke(null, newInstance2);
            } catch (IllegalAccessException | InvocationTargetException e2) {
                throw new RuntimeException(e2);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    @Override // m0.AbstractC0230j
    public Typeface h(Context context, t.h[] hVarArr, int i2) {
        File file;
        String readlink;
        if (hVarArr.length >= 1) {
            try {
                ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(l(hVarArr, i2).f2944a, "r", null);
                if (openFileDescriptor != null) {
                    try {
                        try {
                            readlink = Os.readlink("/proc/self/fd/" + openFileDescriptor.getFd());
                        } finally {
                        }
                    } catch (ErrnoException unused) {
                    }
                    try {
                        if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                            file = new File(readlink);
                            if (file != null && file.canRead()) {
                                Typeface createFromFile = Typeface.createFromFile(file);
                                openFileDescriptor.close();
                                return createFromFile;
                            }
                            FileInputStream fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                            Typeface i3 = i(context, fileInputStream);
                            fileInputStream.close();
                            openFileDescriptor.close();
                            return i3;
                        }
                        Typeface i32 = i(context, fileInputStream);
                        fileInputStream.close();
                        openFileDescriptor.close();
                        return i32;
                    } finally {
                    }
                    file = null;
                    if (file != null) {
                        Typeface createFromFile2 = Typeface.createFromFile(file);
                        openFileDescriptor.close();
                        return createFromFile2;
                    }
                    FileInputStream fileInputStream2 = new FileInputStream(openFileDescriptor.getFileDescriptor());
                } else if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                    return null;
                }
            } catch (IOException unused2) {
            }
        }
        return null;
    }
}
