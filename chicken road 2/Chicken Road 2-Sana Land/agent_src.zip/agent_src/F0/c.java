package F0;

/* loaded from: classes.dex */
public final class c extends a {
    static {
        new c(1, 0, 1);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        if (isEmpty() && ((c) obj).isEmpty()) {
            return true;
        }
        c cVar = (c) obj;
        return this.f310e == cVar.f310e && this.f311f == cVar.f311f;
    }

    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.f310e * 31) + this.f311f;
    }

    public final boolean isEmpty() {
        return this.f310e > this.f311f;
    }

    public final String toString() {
        return this.f310e + ".." + this.f311f;
    }
}
