package r0;

import D.C0016q;
import F.j;
import L.Q;
import android.content.Context;
import android.util.Log;
import j0.InterfaceC0193a;
import java.io.File;
import java.util.ArrayList;
import m0.AbstractC0230j;
import m0.C0229i;
import m0.InterfaceC0222b;
import m0.InterfaceC0226f;

/* renamed from: r0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0252d implements InterfaceC0193a {

    /* renamed from: e, reason: collision with root package name */
    public Context f2797e;

    public static void c(InterfaceC0226f interfaceC0226f, final C0252d c0252d) {
        E.a n2 = interfaceC0226f.n(new C0229i());
        C0250b c0250b = C0250b.f2794d;
        C0016q c0016q = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getTemporaryPath", c0250b, n2);
        if (c0252d != null) {
            final int i2 = 0;
            c0016q.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i2) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q.j(null);
        }
        C0016q c0016q2 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getApplicationSupportPath", c0250b, n2);
        if (c0252d != null) {
            final int i3 = 1;
            c0016q2.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i3) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q2.j(null);
        }
        C0016q c0016q3 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getApplicationDocumentsPath", c0250b, n2);
        if (c0252d != null) {
            final int i4 = 2;
            c0016q3.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i4) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q3.j(null);
        }
        C0016q c0016q4 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getApplicationCachePath", c0250b, n2);
        if (c0252d != null) {
            final int i5 = 3;
            c0016q4.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i5) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q4.j(null);
        }
        C0016q c0016q5 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getExternalStoragePath", c0250b, n2);
        if (c0252d != null) {
            final int i6 = 4;
            c0016q5.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i6) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q5.j(null);
        }
        C0016q c0016q6 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getExternalCachePaths", c0250b, n2);
        if (c0252d != null) {
            final int i7 = 5;
            c0016q6.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i7) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        } else {
            c0016q6.j(null);
        }
        C0016q c0016q7 = new C0016q(interfaceC0226f, "dev.flutter.pigeon.path_provider_android.PathProviderApi.getExternalStoragePaths", c0250b, n2);
        if (c0252d == null) {
            c0016q7.j(null);
        } else {
            final int i8 = 6;
            c0016q7.j(new InterfaceC0222b(c0252d) { // from class: r0.a

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ C0252d f2793f;

                {
                    this.f2793f = c0252d;
                }

                @Override // m0.InterfaceC0222b
                public final void l(Object obj, Q q2) {
                    switch (i8) {
                        case 0:
                            C0252d c0252d2 = this.f2793f;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, c0252d2.f2797e.getCacheDir().getPath());
                            } catch (Throwable th) {
                                arrayList = AbstractC0230j.C(th);
                            }
                            q2.n(arrayList);
                            break;
                        case 1:
                            C0252d c0252d3 = this.f2793f;
                            ArrayList arrayList2 = new ArrayList();
                            try {
                                Context context = c0252d3.f2797e;
                                File filesDir = context.getFilesDir();
                                if (filesDir == null) {
                                    filesDir = new File(context.getDataDir().getPath(), "files");
                                }
                                arrayList2.add(0, filesDir.getPath());
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0230j.C(th2);
                            }
                            q2.n(arrayList2);
                            break;
                        case j.FLOAT_FIELD_NUMBER /* 2 */:
                            C0252d c0252d4 = this.f2793f;
                            ArrayList arrayList3 = new ArrayList();
                            try {
                                Context context2 = c0252d4.f2797e;
                                File dir = context2.getDir("flutter", 0);
                                if (dir == null) {
                                    dir = new File(context2.getDataDir().getPath(), "app_flutter");
                                }
                                arrayList3.add(0, dir.getPath());
                            } catch (Throwable th3) {
                                arrayList3 = AbstractC0230j.C(th3);
                            }
                            q2.n(arrayList3);
                            break;
                        case j.INTEGER_FIELD_NUMBER /* 3 */:
                            C0252d c0252d5 = this.f2793f;
                            ArrayList arrayList4 = new ArrayList();
                            try {
                                arrayList4.add(0, c0252d5.f2797e.getCacheDir().getPath());
                            } catch (Throwable th4) {
                                arrayList4 = AbstractC0230j.C(th4);
                            }
                            q2.n(arrayList4);
                            break;
                        case j.LONG_FIELD_NUMBER /* 4 */:
                            C0252d c0252d6 = this.f2793f;
                            ArrayList arrayList5 = new ArrayList();
                            try {
                                String str = null;
                                File externalFilesDir = c0252d6.f2797e.getExternalFilesDir(null);
                                if (externalFilesDir != null) {
                                    str = externalFilesDir.getAbsolutePath();
                                }
                                arrayList5.add(0, str);
                            } catch (Throwable th5) {
                                arrayList5 = AbstractC0230j.C(th5);
                            }
                            q2.n(arrayList5);
                            break;
                        case j.STRING_FIELD_NUMBER /* 5 */:
                            C0252d c0252d7 = this.f2793f;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                c0252d7.getClass();
                                ArrayList arrayList7 = new ArrayList();
                                for (File file : c0252d7.f2797e.getExternalCacheDirs()) {
                                    if (file != null) {
                                        arrayList7.add(file.getAbsolutePath());
                                    }
                                }
                                arrayList6.add(0, arrayList7);
                            } catch (Throwable th6) {
                                arrayList6 = AbstractC0230j.C(th6);
                            }
                            q2.n(arrayList6);
                            break;
                        default:
                            C0252d c0252d8 = this.f2793f;
                            ArrayList arrayList8 = new ArrayList();
                            try {
                                arrayList8.add(0, c0252d8.b((EnumC0251c) ((ArrayList) obj).get(0)));
                            } catch (Throwable th7) {
                                arrayList8 = AbstractC0230j.C(th7);
                            }
                            q2.n(arrayList8);
                            break;
                    }
                }
            });
        }
    }

    @Override // j0.InterfaceC0193a
    public final void a(Q q2) {
        c((InterfaceC0226f) q2.f579g, null);
    }

    public final ArrayList b(EnumC0251c enumC0251c) {
        String str;
        ArrayList arrayList = new ArrayList();
        Context context = this.f2797e;
        switch (enumC0251c.ordinal()) {
            case 0:
                str = null;
                break;
            case 1:
                str = "music";
                break;
            case j.FLOAT_FIELD_NUMBER /* 2 */:
                str = "podcasts";
                break;
            case j.INTEGER_FIELD_NUMBER /* 3 */:
                str = "ringtones";
                break;
            case j.LONG_FIELD_NUMBER /* 4 */:
                str = "alarms";
                break;
            case j.STRING_FIELD_NUMBER /* 5 */:
                str = "notifications";
                break;
            case j.STRING_SET_FIELD_NUMBER /* 6 */:
                str = "pictures";
                break;
            case j.DOUBLE_FIELD_NUMBER /* 7 */:
                str = "movies";
                break;
            case j.BYTES_FIELD_NUMBER /* 8 */:
                str = "downloads";
                break;
            case 9:
                str = "dcim";
                break;
            case 10:
                str = "documents";
                break;
            default:
                throw new RuntimeException("Unrecognized directory: " + enumC0251c);
        }
        for (File file : context.getExternalFilesDirs(str)) {
            if (file != null) {
                arrayList.add(file.getAbsolutePath());
            }
        }
        return arrayList;
    }

    @Override // j0.InterfaceC0193a
    public final void n(Q q2) {
        InterfaceC0226f interfaceC0226f = (InterfaceC0226f) q2.f579g;
        Context context = (Context) q2.f578f;
        try {
            c(interfaceC0226f, this);
        } catch (Exception e2) {
            Log.e("PathProviderPlugin", "Received exception while setting up PathProviderPlugin", e2);
        }
        this.f2797e = context;
    }
}
