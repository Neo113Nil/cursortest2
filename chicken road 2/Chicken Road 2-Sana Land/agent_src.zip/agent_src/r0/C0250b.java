package r0;

import java.nio.ByteBuffer;
import m0.C0234n;
import m0.C0235o;

/* renamed from: r0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0250b extends C0235o {

    /* renamed from: d, reason: collision with root package name */
    public static final C0250b f2794d = new C0250b();

    @Override // m0.C0235o
    public final Object f(byte b2, ByteBuffer byteBuffer) {
        if (b2 != -127) {
            return super.f(b2, byteBuffer);
        }
        Object e2 = e(byteBuffer);
        if (e2 == null) {
            return null;
        }
        return EnumC0251c.values()[((Long) e2).intValue()];
    }

    @Override // m0.C0235o
    public final void k(C0234n c0234n, Object obj) {
        if (!(obj instanceof EnumC0251c)) {
            super.k(c0234n, obj);
        } else {
            c0234n.write(129);
            k(c0234n, obj == null ? null : Integer.valueOf(((EnumC0251c) obj).f2796e));
        }
    }
}
