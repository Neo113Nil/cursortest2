package r0;

/* renamed from: r0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0251c {
    /* JADX INFO: Fake field, exist only in values array */
    ROOT(0),
    /* JADX INFO: Fake field, exist only in values array */
    MUSIC(1),
    /* JADX INFO: Fake field, exist only in values array */
    PODCASTS(2),
    /* JADX INFO: Fake field, exist only in values array */
    RINGTONES(3),
    /* JADX INFO: Fake field, exist only in values array */
    ALARMS(4),
    /* JADX INFO: Fake field, exist only in values array */
    NOTIFICATIONS(5),
    /* JADX INFO: Fake field, exist only in values array */
    PICTURES(6),
    /* JADX INFO: Fake field, exist only in values array */
    MOVIES(7),
    /* JADX INFO: Fake field, exist only in values array */
    DOWNLOADS(8),
    /* JADX INFO: Fake field, exist only in values array */
    DCIM(9),
    /* JADX INFO: Fake field, exist only in values array */
    DOCUMENTS(10);


    /* renamed from: e, reason: collision with root package name */
    public final int f2796e;

    EnumC0251c(int i2) {
        this.f2796e = i2;
    }
}
