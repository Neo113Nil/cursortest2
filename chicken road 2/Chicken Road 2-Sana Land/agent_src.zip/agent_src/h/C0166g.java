package h;

import g.AbstractC0144b;

/* renamed from: h.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0166g extends AbstractC0144b {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0168i f2152a;

    public C0166g(C0168i c0168i) {
        this.f2152a = c0168i;
    }
}
