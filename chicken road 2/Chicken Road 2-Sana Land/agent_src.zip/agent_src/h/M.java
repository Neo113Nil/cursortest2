package h;

import android.os.Build;
import android.util.Log;
import android.view.MenuItem;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public final class M extends J implements K {

    /* renamed from: D, reason: collision with root package name */
    public static final Method f2090D;

    /* renamed from: C, reason: collision with root package name */
    public A.j f2091C;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f2090D = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    @Override // h.K
    public final void g(g.j jVar, g.k kVar) {
        A.j jVar2 = this.f2091C;
        if (jVar2 != null) {
            jVar2.g(jVar, kVar);
        }
    }

    @Override // h.K
    public final void h(g.j jVar, MenuItem menuItem) {
        A.j jVar2 = this.f2091C;
        if (jVar2 != null) {
            jVar2.h(jVar, menuItem);
        }
    }
}
