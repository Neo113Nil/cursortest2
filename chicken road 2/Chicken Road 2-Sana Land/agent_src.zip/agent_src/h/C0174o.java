package h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.util.Log;
import d0.C0116d;

/* renamed from: h.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0174o {

    /* renamed from: b, reason: collision with root package name */
    public static final PorterDuff.Mode f2209b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    public static C0174o f2210c;

    /* renamed from: a, reason: collision with root package name */
    public O f2211a;

    public static synchronized void b() {
        synchronized (C0174o.class) {
            if (f2210c == null) {
                C0174o c0174o = new C0174o();
                f2210c = c0174o;
                c0174o.f2211a = O.b();
                O o2 = f2210c.f2211a;
                C0116d c0116d = new C0116d();
                synchronized (o2) {
                    o2.f2099e = c0116d;
                }
            }
        }
    }

    public static void c(Drawable drawable, j0 j0Var, int[] iArr) {
        PorterDuff.Mode mode = O.f2092f;
        if (AbstractC0183y.a(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        boolean z2 = j0Var.f2186d;
        if (!z2 && !j0Var.f2185c) {
            drawable.clearColorFilter();
            return;
        }
        PorterDuffColorFilter porterDuffColorFilter = null;
        ColorStateList colorStateList = z2 ? j0Var.f2183a : null;
        PorterDuff.Mode mode2 = j0Var.f2185c ? j0Var.f2184b : O.f2092f;
        if (colorStateList != null && mode2 != null) {
            porterDuffColorFilter = O.e(colorStateList.getColorForState(iArr, 0), mode2);
        }
        drawable.setColorFilter(porterDuffColorFilter);
    }

    public final synchronized Drawable a(Context context, int i2) {
        return this.f2211a.c(context, i2);
    }
}
