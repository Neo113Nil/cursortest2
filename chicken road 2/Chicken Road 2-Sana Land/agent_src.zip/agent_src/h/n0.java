package h;

import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class n0 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public int f2207a;

    /* renamed from: b, reason: collision with root package name */
    public int f2208b;

    public n0(n0 n0Var) {
        super((ViewGroup.MarginLayoutParams) n0Var);
        this.f2207a = 0;
        this.f2207a = n0Var.f2207a;
    }

    public n0(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f2207a = 0;
    }
}
