package h;

import a.AbstractC0068a;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import d.AbstractC0112a;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import m0.AbstractC0230j;
import u.AbstractC0269b;
import u.C0268a;

/* renamed from: h.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0179u extends TextView implements A.c {

    /* renamed from: e, reason: collision with root package name */
    public final C0173n f2267e;

    /* renamed from: f, reason: collision with root package name */
    public final C0178t f2268f;

    /* renamed from: g, reason: collision with root package name */
    public final L.Q f2269g;

    /* renamed from: h, reason: collision with root package name */
    public Future f2270h;

    public C0179u(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0173n c0173n = this.f2267e;
        if (c0173n != null) {
            c0173n.a();
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (A.c.f11a) {
            return super.getAutoSizeMaxTextSize();
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            return Math.round(c0178t.f2255i.f2278e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (A.c.f11a) {
            return super.getAutoSizeMinTextSize();
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            return Math.round(c0178t.f2255i.f2277d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (A.c.f11a) {
            return super.getAutoSizeStepGranularity();
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            return Math.round(c0178t.f2255i.f2276c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (A.c.f11a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0178t c0178t = this.f2268f;
        return c0178t != null ? c0178t.f2255i.f2279f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (A.c.f11a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            return c0178t.f2255i.f2274a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        j0 j0Var;
        C0173n c0173n = this.f2267e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2183a;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        j0 j0Var;
        C0173n c0173n = this.f2267e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2184b;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        j0 j0Var = this.f2268f.f2254h;
        if (j0Var != null) {
            return j0Var.f2183a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        j0 j0Var = this.f2268f.f2254h;
        if (j0Var != null) {
            return j0Var.f2184b;
        }
        return null;
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        Future future = this.f2270h;
        if (future != null) {
            try {
                this.f2270h = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                AbstractC0068a.u(this);
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        L.Q q2;
        if (Build.VERSION.SDK_INT >= 28 || (q2 = this.f2269g) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) q2.f579g;
        if (textClassifier != null) {
            return textClassifier;
        }
        TextClassificationManager textClassificationManager = (TextClassificationManager) ((C0179u) q2.f578f).getContext().getSystemService(TextClassificationManager.class);
        return textClassificationManager != null ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }

    public C0268a getTextMetricsParamsCompat() {
        return AbstractC0068a.u(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        if (onCreateInputConnection != null && editorInfo.hintText == null) {
            for (ViewParent parent = getParent(); parent instanceof View; parent = parent.getParent()) {
            }
        }
        return onCreateInputConnection;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        C0178t c0178t = this.f2268f;
        if (c0178t == null || A.c.f11a) {
            return;
        }
        c0178t.f2255i.a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i2, int i3) {
        Future future = this.f2270h;
        if (future != null) {
            try {
                this.f2270h = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                AbstractC0068a.u(this);
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i2, i3);
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        C0178t c0178t = this.f2268f;
        if (c0178t == null || A.c.f11a) {
            return;
        }
        C0180v c0180v = c0178t.f2255i;
        if (c0180v.f2274a != 0) {
            c0180v.a();
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (A.c.f11a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            C0180v c0180v = c0178t.f2255i;
            DisplayMetrics displayMetrics = c0180v.f2283j.getResources().getDisplayMetrics();
            c0180v.i(TypedValue.applyDimension(i5, i2, displayMetrics), TypedValue.applyDimension(i5, i3, displayMetrics), TypedValue.applyDimension(i5, i4, displayMetrics));
            if (c0180v.g()) {
                c0180v.a();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (A.c.f11a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            C0180v c0180v = c0178t.f2255i;
            c0180v.getClass();
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i2 == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = c0180v.f2283j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArr2[i3] = Math.round(TypedValue.applyDimension(i2, iArr[i3], displayMetrics));
                    }
                }
                c0180v.f2279f = C0180v.b(iArr2);
                if (!c0180v.h()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                c0180v.f2280g = false;
            }
            if (c0180v.g()) {
                c0180v.a();
            }
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (A.c.f11a) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            C0180v c0180v = c0178t.f2255i;
            if (i2 == 0) {
                c0180v.f2274a = 0;
                c0180v.f2277d = -1.0f;
                c0180v.f2278e = -1.0f;
                c0180v.f2276c = -1.0f;
                c0180v.f2279f = new int[0];
                c0180v.f2275b = false;
                return;
            }
            if (i2 != 1) {
                c0180v.getClass();
                throw new IllegalArgumentException(E0.h.e("Unknown auto-size text type: ", i2));
            }
            DisplayMetrics displayMetrics = c0180v.f2283j.getResources().getDisplayMetrics();
            c0180v.i(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (c0180v.g()) {
                c0180v.a();
            }
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0173n c0173n = this.f2267e;
        if (c0173n != null) {
            c0173n.f2203c = -1;
            c0173n.d(null);
            c0173n.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0173n c0173n = this.f2267e;
        if (c0173n != null) {
            c0173n.c(i2);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(AbstractC0068a.M(callback, this));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i2);
        } else {
            AbstractC0068a.F(this, i2);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i2);
        } else {
            AbstractC0068a.G(this, i2);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException();
        }
        if (i2 != getPaint().getFontMetricsInt(null)) {
            setLineSpacing(i2 - r0, 1.0f);
        }
    }

    public void setPrecomputedText(AbstractC0269b abstractC0269b) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        AbstractC0068a.u(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0173n c0173n = this.f2267e;
        if (c0173n != null) {
            c0173n.e(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0173n c0173n = this.f2267e;
        if (c0173n != null) {
            c0173n.f(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0178t c0178t = this.f2268f;
        if (c0178t.f2254h == null) {
            c0178t.f2254h = new j0();
        }
        j0 j0Var = c0178t.f2254h;
        j0Var.f2183a = colorStateList;
        j0Var.f2186d = colorStateList != null;
        c0178t.f2248b = j0Var;
        c0178t.f2249c = j0Var;
        c0178t.f2250d = j0Var;
        c0178t.f2251e = j0Var;
        c0178t.f2252f = j0Var;
        c0178t.f2253g = j0Var;
        c0178t.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0178t c0178t = this.f2268f;
        if (c0178t.f2254h == null) {
            c0178t.f2254h = new j0();
        }
        j0 j0Var = c0178t.f2254h;
        j0Var.f2184b = mode;
        j0Var.f2185c = mode != null;
        c0178t.f2248b = j0Var;
        c0178t.f2249c = j0Var;
        c0178t.f2250d = j0Var;
        c0178t.f2251e = j0Var;
        c0178t.f2252f = j0Var;
        c0178t.f2253g = j0Var;
        c0178t.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.e(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        L.Q q2;
        if (Build.VERSION.SDK_INT >= 28 || (q2 = this.f2269g) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            q2.f579g = textClassifier;
        }
    }

    public void setTextFuture(Future<AbstractC0269b> future) {
        this.f2270h = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C0268a c0268a) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = c0268a.f2954b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i2 = 1;
        if (textDirectionHeuristic2 != textDirectionHeuristic3 && textDirectionHeuristic2 != (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i2 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        getPaint().set(c0268a.f2953a);
        A.o.e(this, c0268a.f2955c);
        A.o.h(this, c0268a.f2956d);
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i2, float f2) {
        boolean z2 = A.c.f11a;
        if (z2) {
            super.setTextSize(i2, f2);
            return;
        }
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            C0180v c0180v = c0178t.f2255i;
            if (z2 || c0180v.f2274a != 0) {
                return;
            }
            c0180v.f(i2, f2);
        }
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i2) {
        Typeface typeface2;
        if (typeface == null || i2 <= 0) {
            typeface2 = null;
        } else {
            Context context = getContext();
            AbstractC0230j abstractC0230j = p.d.f2767a;
            if (context == null) {
                throw new IllegalArgumentException("Context cannot be null");
            }
            typeface2 = Typeface.create(typeface, i2);
        }
        if (typeface2 != null) {
            typeface = typeface2;
        }
        super.setTypeface(typeface, i2);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0179u(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        i0.a(context);
        C0173n c0173n = new C0173n(this);
        this.f2267e = c0173n;
        c0173n.b(attributeSet, i2);
        C0178t c0178t = new C0178t(this);
        this.f2268f = c0178t;
        c0178t.d(attributeSet, i2);
        c0178t.b();
        L.Q q2 = new L.Q(10, false);
        q2.f578f = this;
        this.f2269g = q2;
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i2 != 0 ? AbstractC0112a.a(context, i2) : null, i3 != 0 ? AbstractC0112a.a(context, i3) : null, i4 != 0 ? AbstractC0112a.a(context, i4) : null, i5 != 0 ? AbstractC0112a.a(context, i5) : null);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i2 != 0 ? AbstractC0112a.a(context, i2) : null, i3 != 0 ? AbstractC0112a.a(context, i3) : null, i4 != 0 ? AbstractC0112a.a(context, i4) : null, i5 != 0 ? AbstractC0112a.a(context, i5) : null);
        C0178t c0178t = this.f2268f;
        if (c0178t != null) {
            c0178t.b();
        }
    }
}
