package h;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import com.grid.of.lights.R;

/* loaded from: classes.dex */
public final class t0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f2260a;

    /* renamed from: b, reason: collision with root package name */
    public final View f2261b;

    /* renamed from: c, reason: collision with root package name */
    public final TextView f2262c;

    /* renamed from: d, reason: collision with root package name */
    public final WindowManager.LayoutParams f2263d;

    /* renamed from: e, reason: collision with root package name */
    public final Rect f2264e;

    /* renamed from: f, reason: collision with root package name */
    public final int[] f2265f;

    /* renamed from: g, reason: collision with root package name */
    public final int[] f2266g;

    public t0(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f2263d = layoutParams;
        this.f2264e = new Rect();
        this.f2265f = new int[2];
        this.f2266g = new int[2];
        this.f2260a = context;
        View inflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
        this.f2261b = inflate;
        this.f2262c = (TextView) inflate.findViewById(R.id.message);
        layoutParams.setTitle(t0.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = R.style.Animation_AppCompat_Tooltip;
        layoutParams.flags = 24;
    }
}
