package h;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import com.grid.of.lights.R;
import java.util.ArrayList;

/* renamed from: h.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0168i implements g.p {

    /* renamed from: e, reason: collision with root package name */
    public final Context f2161e;

    /* renamed from: f, reason: collision with root package name */
    public Context f2162f;

    /* renamed from: g, reason: collision with root package name */
    public g.j f2163g;

    /* renamed from: h, reason: collision with root package name */
    public final LayoutInflater f2164h;

    /* renamed from: i, reason: collision with root package name */
    public g.o f2165i;

    /* renamed from: k, reason: collision with root package name */
    public ActionMenuView f2167k;

    /* renamed from: l, reason: collision with root package name */
    public C0167h f2168l;

    /* renamed from: m, reason: collision with root package name */
    public Drawable f2169m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f2170n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f2171o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f2172p;

    /* renamed from: q, reason: collision with root package name */
    public int f2173q;
    public int r;

    /* renamed from: s, reason: collision with root package name */
    public int f2174s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f2175t;

    /* renamed from: v, reason: collision with root package name */
    public C0165f f2177v;

    /* renamed from: w, reason: collision with root package name */
    public C0165f f2178w;

    /* renamed from: x, reason: collision with root package name */
    public O0.g f2179x;

    /* renamed from: y, reason: collision with root package name */
    public C0166g f2180y;

    /* renamed from: j, reason: collision with root package name */
    public final int f2166j = R.layout.abc_action_menu_item_layout;

    /* renamed from: u, reason: collision with root package name */
    public final SparseBooleanArray f2176u = new SparseBooleanArray();

    /* renamed from: z, reason: collision with root package name */
    public final A.j f2181z = new A.j(20, this);

    public C0168i(Context context) {
        this.f2161e = context;
        this.f2164h = LayoutInflater.from(context);
    }

    @Override // g.p
    public final void a(g.j jVar, boolean z2) {
        i();
        C0165f c0165f = this.f2178w;
        if (c0165f != null && c0165f.b()) {
            c0165f.f1994i.dismiss();
        }
        g.o oVar = this.f2165i;
        if (oVar != null) {
            oVar.a(jVar, z2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v0, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r7v4, types: [g.q] */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r7v8 */
    public final View b(g.k kVar, View view, ActionMenuView actionMenuView) {
        View view2 = kVar.f1983z;
        View view3 = view2 != null ? view2 : null;
        if (view3 == null || ((kVar.f1982y & 8) != 0 && view2 != null)) {
            ActionMenuItemView actionMenuItemView = view instanceof g.q ? (g.q) view : (g.q) this.f2164h.inflate(this.f2166j, (ViewGroup) actionMenuView, false);
            actionMenuItemView.a(kVar);
            ActionMenuItemView actionMenuItemView2 = actionMenuItemView;
            actionMenuItemView2.setItemInvoker(this.f2167k);
            if (this.f2180y == null) {
                this.f2180y = new C0166g(this);
            }
            actionMenuItemView2.setPopupCallback(this.f2180y);
            view3 = actionMenuItemView;
        }
        view3.setVisibility(kVar.f1958B ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        actionMenuView.getClass();
        if (!(layoutParams instanceof C0170k)) {
            view3.setLayoutParams(ActionMenuView.i(layoutParams));
        }
        return view3;
    }

    @Override // g.p
    public final void c(g.o oVar) {
        throw null;
    }

    @Override // g.p
    public final boolean d(g.k kVar) {
        return false;
    }

    @Override // g.p
    public final boolean e(g.k kVar) {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // g.p
    public final void f() {
        int i2;
        ActionMenuView actionMenuView = this.f2167k;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (actionMenuView != null) {
            g.j jVar = this.f2163g;
            if (jVar != null) {
                jVar.i();
                ArrayList k2 = this.f2163g.k();
                int size = k2.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    g.k kVar = (g.k) k2.get(i3);
                    if ((kVar.f1981x & 32) == 32) {
                        View childAt = actionMenuView.getChildAt(i2);
                        g.k itemData = childAt instanceof g.q ? ((g.q) childAt).getItemData() : null;
                        View b2 = b(kVar, childAt, actionMenuView);
                        if (kVar != itemData) {
                            b2.setPressed(false);
                            b2.jumpDrawablesToCurrentState();
                        }
                        if (b2 != childAt) {
                            ViewGroup viewGroup = (ViewGroup) b2.getParent();
                            if (viewGroup != null) {
                                viewGroup.removeView(b2);
                            }
                            this.f2167k.addView(b2, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < actionMenuView.getChildCount()) {
                if (actionMenuView.getChildAt(i2) == this.f2168l) {
                    i2++;
                } else {
                    actionMenuView.removeViewAt(i2);
                }
            }
        }
        this.f2167k.requestLayout();
        g.j jVar2 = this.f2163g;
        if (jVar2 != null) {
            jVar2.i();
            ArrayList arrayList2 = jVar2.f1946i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                ((g.k) arrayList2.get(i4)).getClass();
            }
        }
        g.j jVar3 = this.f2163g;
        if (jVar3 != null) {
            jVar3.i();
            arrayList = jVar3.f1947j;
        }
        if (this.f2171o && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((g.k) arrayList.get(0)).f1958B;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f2168l == null) {
                this.f2168l = new C0167h(this, this.f2161e);
            }
            ViewGroup viewGroup2 = (ViewGroup) this.f2168l.getParent();
            if (viewGroup2 != this.f2167k) {
                if (viewGroup2 != null) {
                    viewGroup2.removeView(this.f2168l);
                }
                ActionMenuView actionMenuView2 = this.f2167k;
                C0167h c0167h = this.f2168l;
                actionMenuView2.getClass();
                C0170k h2 = ActionMenuView.h();
                h2.f2187c = true;
                actionMenuView2.addView(c0167h, h2);
            }
        } else {
            C0167h c0167h2 = this.f2168l;
            if (c0167h2 != null) {
                ViewParent parent = c0167h2.getParent();
                ActionMenuView actionMenuView3 = this.f2167k;
                if (parent == actionMenuView3) {
                    actionMenuView3.removeView(this.f2168l);
                }
            }
        }
        this.f2167k.setOverflowReserved(this.f2171o);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // g.p
    public final boolean g(g.t tVar) {
        boolean z2;
        if (tVar.hasVisibleItems()) {
            g.t tVar2 = tVar;
            while (true) {
                g.j jVar = tVar2.f2015v;
                if (jVar == this.f2163g) {
                    break;
                }
                tVar2 = (g.t) jVar;
            }
            g.k kVar = tVar2.f2016w;
            ActionMenuView actionMenuView = this.f2167k;
            View view = null;
            if (actionMenuView != null) {
                int childCount = actionMenuView.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = actionMenuView.getChildAt(i2);
                    if ((childAt instanceof g.q) && ((g.q) childAt).getItemData() == kVar) {
                        view = childAt;
                        break;
                    }
                    i2++;
                }
            }
            if (view != null) {
                tVar.f2016w.getClass();
                int size = tVar.f1943f.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        z2 = false;
                        break;
                    }
                    MenuItem item = tVar.getItem(i3);
                    if (item.isVisible() && item.getIcon() != null) {
                        z2 = true;
                        break;
                    }
                    i3++;
                }
                C0165f c0165f = new C0165f(this, this.f2162f, tVar, view);
                this.f2178w = c0165f;
                c0165f.f1992g = z2;
                g.l lVar = c0165f.f1994i;
                if (lVar != null) {
                    lVar.o(z2);
                }
                C0165f c0165f2 = this.f2178w;
                if (!c0165f2.b()) {
                    if (c0165f2.f1990e == null) {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                    c0165f2.d(0, 0, false, false);
                }
                g.o oVar = this.f2165i;
                if (oVar != null) {
                    oVar.o(tVar);
                }
                return true;
            }
        }
        return false;
    }

    @Override // g.p
    public final boolean h() {
        int i2;
        ArrayList arrayList;
        int i3;
        boolean z2;
        C0168i c0168i = this;
        g.j jVar = c0168i.f2163g;
        if (jVar != null) {
            arrayList = jVar.k();
            i2 = arrayList.size();
        } else {
            i2 = 0;
            arrayList = null;
        }
        int i4 = c0168i.f2174s;
        int i5 = c0168i.r;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ActionMenuView actionMenuView = c0168i.f2167k;
        int i6 = 0;
        boolean z3 = false;
        int i7 = 0;
        int i8 = 0;
        while (true) {
            i3 = 2;
            z2 = true;
            if (i6 >= i2) {
                break;
            }
            g.k kVar = (g.k) arrayList.get(i6);
            int i9 = kVar.f1982y;
            if ((i9 & 2) == 2) {
                i7++;
            } else if ((i9 & 1) == 1) {
                i8++;
            } else {
                z3 = true;
            }
            if (c0168i.f2175t && kVar.f1958B) {
                i4 = 0;
            }
            i6++;
        }
        if (c0168i.f2171o && (z3 || i8 + i7 > i4)) {
            i4--;
        }
        int i10 = i4 - i7;
        SparseBooleanArray sparseBooleanArray = c0168i.f2176u;
        sparseBooleanArray.clear();
        int i11 = 0;
        int i12 = 0;
        while (i11 < i2) {
            g.k kVar2 = (g.k) arrayList.get(i11);
            int i13 = kVar2.f1982y;
            boolean z4 = (i13 & 2) == i3 ? z2 : false;
            int i14 = kVar2.f1960b;
            if (z4) {
                View b2 = c0168i.b(kVar2, null, actionMenuView);
                b2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = b2.getMeasuredWidth();
                i5 -= measuredWidth;
                if (i12 == 0) {
                    i12 = measuredWidth;
                }
                if (i14 != 0) {
                    sparseBooleanArray.put(i14, z2);
                }
                kVar2.d(z2);
            } else if ((i13 & 1) == z2) {
                boolean z5 = sparseBooleanArray.get(i14);
                boolean z6 = ((i10 > 0 || z5) && i5 > 0) ? z2 : false;
                if (z6) {
                    View b3 = c0168i.b(kVar2, null, actionMenuView);
                    b3.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = b3.getMeasuredWidth();
                    i5 -= measuredWidth2;
                    if (i12 == 0) {
                        i12 = measuredWidth2;
                    }
                    z6 &= i5 + i12 > 0;
                }
                if (z6 && i14 != 0) {
                    sparseBooleanArray.put(i14, true);
                } else if (z5) {
                    sparseBooleanArray.put(i14, false);
                    for (int i15 = 0; i15 < i11; i15++) {
                        g.k kVar3 = (g.k) arrayList.get(i15);
                        if (kVar3.f1960b == i14) {
                            if ((kVar3.f1981x & 32) == 32) {
                                i10++;
                            }
                            kVar3.d(false);
                        }
                    }
                }
                if (z6) {
                    i10--;
                }
                kVar2.d(z6);
            } else {
                kVar2.d(false);
                i11++;
                i3 = 2;
                c0168i = this;
                z2 = true;
            }
            i11++;
            i3 = 2;
            c0168i = this;
            z2 = true;
        }
        return z2;
    }

    public final boolean i() {
        ActionMenuView actionMenuView;
        O0.g gVar = this.f2179x;
        if (gVar != null && (actionMenuView = this.f2167k) != null) {
            actionMenuView.removeCallbacks(gVar);
            this.f2179x = null;
            return true;
        }
        C0165f c0165f = this.f2177v;
        if (c0165f == null) {
            return false;
        }
        if (c0165f.b()) {
            c0165f.f1994i.dismiss();
        }
        return true;
    }

    public final boolean j() {
        g.j jVar;
        if (!this.f2171o) {
            return false;
        }
        C0165f c0165f = this.f2177v;
        if ((c0165f != null && c0165f.b()) || (jVar = this.f2163g) == null || this.f2167k == null || this.f2179x != null) {
            return false;
        }
        jVar.i();
        if (jVar.f1947j.isEmpty()) {
            return false;
        }
        O0.g gVar = new O0.g(1, this, new C0165f(this, this.f2162f, this.f2163g, this.f2168l));
        this.f2179x = gVar;
        this.f2167k.post(gVar);
        g.o oVar = this.f2165i;
        if (oVar == null) {
            return true;
        }
        oVar.o(null);
        return true;
    }

    @Override // g.p
    public final void k(Context context, g.j jVar) {
        this.f2162f = context;
        LayoutInflater.from(context);
        this.f2163g = jVar;
        Resources resources = context.getResources();
        if (!this.f2172p) {
            this.f2171o = true;
        }
        int i2 = 2;
        this.f2173q = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.f2174s = i2;
        int i5 = this.f2173q;
        if (this.f2171o) {
            if (this.f2168l == null) {
                C0167h c0167h = new C0167h(this, this.f2161e);
                this.f2168l = c0167h;
                if (this.f2170n) {
                    c0167h.setImageDrawable(this.f2169m);
                    this.f2169m = null;
                    this.f2170n = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f2168l.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i5 -= this.f2168l.getMeasuredWidth();
        } else {
            this.f2168l = null;
        }
        this.r = i5;
        float f2 = resources.getDisplayMetrics().density;
    }
}
