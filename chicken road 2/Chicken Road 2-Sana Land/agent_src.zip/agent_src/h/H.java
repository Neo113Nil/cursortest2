package h;

import android.widget.AbsListView;

/* loaded from: classes.dex */
public final class H implements AbsListView.OnScrollListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ J f2062a;

    public H(J j2) {
        this.f2062a = j2;
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScrollStateChanged(AbsListView absListView, int i2) {
        J j2 = this.f2062a;
        RunnableC0159G runnableC0159G = j2.r;
        if (i2 != 1 || j2.f2086z.getInputMethodMode() == 2 || j2.f2086z.getContentView() == null) {
            return;
        }
        j2.f2082v.removeCallbacks(runnableC0159G);
        runnableC0159G.run();
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScroll(AbsListView absListView, int i2, int i3, int i4) {
    }
}
