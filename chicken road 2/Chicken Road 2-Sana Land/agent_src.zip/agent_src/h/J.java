package h;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import c.AbstractC0096a;
import d.AbstractC0112a;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public abstract class J implements g.r {

    /* renamed from: A, reason: collision with root package name */
    public static final Method f2064A;

    /* renamed from: B, reason: collision with root package name */
    public static final Method f2065B;

    /* renamed from: e, reason: collision with root package name */
    public final Context f2066e;

    /* renamed from: f, reason: collision with root package name */
    public ListAdapter f2067f;

    /* renamed from: g, reason: collision with root package name */
    public L f2068g;

    /* renamed from: i, reason: collision with root package name */
    public int f2070i;

    /* renamed from: j, reason: collision with root package name */
    public int f2071j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f2072k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f2073l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f2074m;

    /* renamed from: o, reason: collision with root package name */
    public B.b f2076o;

    /* renamed from: p, reason: collision with root package name */
    public View f2077p;

    /* renamed from: q, reason: collision with root package name */
    public g.l f2078q;

    /* renamed from: v, reason: collision with root package name */
    public final Handler f2082v;

    /* renamed from: x, reason: collision with root package name */
    public Rect f2084x;

    /* renamed from: y, reason: collision with root package name */
    public boolean f2085y;

    /* renamed from: z, reason: collision with root package name */
    public final r f2086z;

    /* renamed from: h, reason: collision with root package name */
    public int f2069h = -2;

    /* renamed from: n, reason: collision with root package name */
    public int f2075n = 0;
    public final RunnableC0159G r = new RunnableC0159G(this, 1);

    /* renamed from: s, reason: collision with root package name */
    public final I f2079s = new I(this);

    /* renamed from: t, reason: collision with root package name */
    public final H f2080t = new H(this);

    /* renamed from: u, reason: collision with root package name */
    public final RunnableC0159G f2081u = new RunnableC0159G(this, 0);

    /* renamed from: w, reason: collision with root package name */
    public final Rect f2083w = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f2064A = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f2065B = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    public J(Context context, int i2) {
        int resourceId;
        this.f2066e = context;
        this.f2082v = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, AbstractC0096a.f1622k, i2, 0);
        this.f2070i = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f2071j = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f2072k = true;
        }
        obtainStyledAttributes.recycle();
        r rVar = new r(context, null, i2, 0);
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(null, AbstractC0096a.f1626o, i2, 0);
        if (obtainStyledAttributes2.hasValue(2)) {
            A.n.c(rVar, obtainStyledAttributes2.getBoolean(2, false));
        }
        rVar.setBackgroundDrawable((!obtainStyledAttributes2.hasValue(0) || (resourceId = obtainStyledAttributes2.getResourceId(0, 0)) == 0) ? obtainStyledAttributes2.getDrawable(0) : AbstractC0112a.a(context, resourceId));
        obtainStyledAttributes2.recycle();
        this.f2086z = rVar;
        rVar.setInputMethodMode(1);
    }

    public final void a(ListAdapter listAdapter) {
        B.b bVar = this.f2076o;
        if (bVar == null) {
            this.f2076o = new B.b(1, this);
        } else {
            ListAdapter listAdapter2 = this.f2067f;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(bVar);
            }
        }
        this.f2067f = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f2076o);
        }
        L l2 = this.f2068g;
        if (l2 != null) {
            l2.setAdapter(this.f2067f);
        }
    }

    @Override // g.r
    public final void b() {
        int i2;
        L l2;
        L l3 = this.f2068g;
        Context context = this.f2066e;
        r rVar = this.f2086z;
        if (l3 == null) {
            L l4 = new L(context, !this.f2085y);
            l4.setHoverListener((M) this);
            this.f2068g = l4;
            l4.setAdapter(this.f2067f);
            this.f2068g.setOnItemClickListener(this.f2078q);
            this.f2068g.setFocusable(true);
            this.f2068g.setFocusableInTouchMode(true);
            this.f2068g.setOnItemSelectedListener(new C0158F(r4, this));
            this.f2068g.setOnScrollListener(this.f2080t);
            rVar.setContentView(this.f2068g);
        }
        Drawable background = rVar.getBackground();
        Rect rect = this.f2083w;
        if (background != null) {
            background.getPadding(rect);
            int i3 = rect.top;
            i2 = rect.bottom + i3;
            if (!this.f2072k) {
                this.f2071j = -i3;
            }
        } else {
            rect.setEmpty();
            i2 = 0;
        }
        int maxAvailableHeight = rVar.getMaxAvailableHeight(this.f2077p, this.f2071j, rVar.getInputMethodMode() == 2);
        int i4 = this.f2069h;
        int a2 = this.f2068g.a(i4 != -2 ? i4 != -1 ? View.MeasureSpec.makeMeasureSpec(i4, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), maxAvailableHeight);
        int paddingBottom = a2 + (a2 > 0 ? this.f2068g.getPaddingBottom() + this.f2068g.getPaddingTop() + i2 : 0);
        this.f2086z.getInputMethodMode();
        A.n.d(rVar, 1002);
        if (rVar.isShowing()) {
            View view = this.f2077p;
            Field field = w.x.f3034a;
            if (view.isAttachedToWindow()) {
                int i5 = this.f2069h;
                if (i5 == -1) {
                    i5 = -1;
                } else if (i5 == -2) {
                    i5 = this.f2077p.getWidth();
                }
                rVar.setOutsideTouchable(true);
                rVar.update(this.f2077p, this.f2070i, this.f2071j, i5 < 0 ? -1 : i5, paddingBottom < 0 ? -1 : paddingBottom);
                return;
            }
            return;
        }
        int i6 = this.f2069h;
        if (i6 == -1) {
            i6 = -1;
        } else if (i6 == -2) {
            i6 = this.f2077p.getWidth();
        }
        rVar.setWidth(i6);
        rVar.setHeight(paddingBottom);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f2064A;
            if (method != null) {
                try {
                    method.invoke(rVar, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            rVar.setIsClippedToScreen(true);
        }
        rVar.setOutsideTouchable(true);
        rVar.setTouchInterceptor(this.f2079s);
        if (this.f2074m) {
            A.n.c(rVar, this.f2073l);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f2065B;
            if (method2 != null) {
                try {
                    method2.invoke(rVar, this.f2084x);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            rVar.setEpicenterBounds(this.f2084x);
        }
        rVar.showAsDropDown(this.f2077p, this.f2070i, this.f2071j, this.f2075n);
        this.f2068g.setSelection(-1);
        if ((!this.f2085y || this.f2068g.isInTouchMode()) && (l2 = this.f2068g) != null) {
            l2.setListSelectionHidden(true);
            l2.requestLayout();
        }
        if (this.f2085y) {
            return;
        }
        this.f2082v.post(this.f2081u);
    }

    @Override // g.r
    public final void dismiss() {
        r rVar = this.f2086z;
        rVar.dismiss();
        rVar.setContentView(null);
        this.f2068g = null;
        this.f2082v.removeCallbacks(this.r);
    }

    @Override // g.r
    public final ListView i() {
        return this.f2068g;
    }

    @Override // g.r
    public final boolean j() {
        return this.f2086z.isShowing();
    }
}
