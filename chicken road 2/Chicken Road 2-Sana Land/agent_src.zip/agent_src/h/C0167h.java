package h;

import a.AbstractC0068a;
import android.content.Context;
import android.graphics.drawable.Drawable;
import com.grid.of.lights.R;
import g.ViewOnTouchListenerC0143a;
import q.AbstractC0246a;

/* renamed from: h.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0167h extends C0176q implements InterfaceC0169j {

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ C0168i f2153g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0167h(C0168i c0168i, Context context) {
        super(context, R.attr.actionOverflowButtonStyle);
        this.f2153g = c0168i;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        AbstractC0068a.H(this, getContentDescription());
        setOnTouchListener(new ViewOnTouchListenerC0143a(this, this));
    }

    @Override // h.InterfaceC0169j
    public final boolean b() {
        return false;
    }

    @Override // h.InterfaceC0169j
    public final boolean c() {
        return false;
    }

    @Override // android.view.View
    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.f2153g.j();
        return true;
    }

    @Override // android.widget.ImageView
    public final boolean setFrame(int i2, int i3, int i4, int i5) {
        boolean frame = super.setFrame(i2, i3, i4, i5);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (drawable != null && background != null) {
            int width = getWidth();
            int height = getHeight();
            int max = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            AbstractC0246a.f(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
        }
        return frame;
    }
}
