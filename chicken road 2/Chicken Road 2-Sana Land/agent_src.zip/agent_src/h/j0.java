package h;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: classes.dex */
public final class j0 {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f2183a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f2184b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f2185c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f2186d;
}
