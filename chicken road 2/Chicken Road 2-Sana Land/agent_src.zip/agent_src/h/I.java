package h;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public final class I implements View.OnTouchListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ J f2063a;

    public I(J j2) {
        this.f2063a = j2;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        r rVar;
        J j2 = this.f2063a;
        RunnableC0159G runnableC0159G = j2.r;
        Handler handler = j2.f2082v;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        if (action == 0 && (rVar = j2.f2086z) != null && rVar.isShowing() && x2 >= 0 && x2 < j2.f2086z.getWidth() && y2 >= 0 && y2 < j2.f2086z.getHeight()) {
            handler.postDelayed(runnableC0159G, 250L);
            return false;
        }
        if (action != 1) {
            return false;
        }
        handler.removeCallbacks(runnableC0159G);
        return false;
    }
}
