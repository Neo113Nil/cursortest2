package h;

import java.lang.reflect.Method;

/* loaded from: classes.dex */
public final class Y {

    /* renamed from: a, reason: collision with root package name */
    public Method f2115a;

    /* renamed from: b, reason: collision with root package name */
    public Method f2116b;

    /* renamed from: c, reason: collision with root package name */
    public Method f2117c;

    public Y(Method method, Method method2, Method method3) {
        this.f2115a = method;
        this.f2116b = method2;
        this.f2117c = method3;
    }
}
