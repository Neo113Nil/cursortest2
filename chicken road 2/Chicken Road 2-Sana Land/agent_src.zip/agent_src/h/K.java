package h;

import android.view.MenuItem;

/* loaded from: classes.dex */
public interface K {
    void g(g.j jVar, g.k kVar);

    void h(g.j jVar, MenuItem menuItem);
}
