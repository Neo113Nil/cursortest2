package h;

import java.lang.reflect.Field;

/* renamed from: h.G, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0159G implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f2060e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ J f2061f;

    public /* synthetic */ RunnableC0159G(J j2, int i2) {
        this.f2060e = i2;
        this.f2061f = j2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f2060e;
        J j2 = this.f2061f;
        switch (i2) {
            case 0:
                L l2 = j2.f2068g;
                if (l2 != null) {
                    l2.setListSelectionHidden(true);
                    l2.requestLayout();
                    break;
                }
                break;
            default:
                L l3 = j2.f2068g;
                if (l3 != null) {
                    Field field = w.x.f3034a;
                    if (l3.isAttachedToWindow() && j2.f2068g.getCount() > j2.f2068g.getChildCount() && j2.f2068g.getChildCount() <= Integer.MAX_VALUE) {
                        j2.f2086z.setInputMethodMode(2);
                        j2.b();
                        break;
                    }
                }
                break;
        }
    }
}
