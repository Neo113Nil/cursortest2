package h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;

/* loaded from: classes.dex */
public final class L extends AbstractC0153A {
    public final int r;

    /* renamed from: s, reason: collision with root package name */
    public final int f2087s;

    /* renamed from: t, reason: collision with root package name */
    public K f2088t;

    /* renamed from: u, reason: collision with root package name */
    public g.k f2089u;

    public L(Context context, boolean z2) {
        super(context, z2);
        if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
            this.r = 21;
            this.f2087s = 22;
        } else {
            this.r = 22;
            this.f2087s = 21;
        }
    }

    @Override // h.AbstractC0153A, android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        g.h hVar;
        int i2;
        int pointToPosition;
        int i3;
        if (this.f2088t != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                i2 = headerViewListAdapter.getHeadersCount();
                hVar = (g.h) headerViewListAdapter.getWrappedAdapter();
            } else {
                hVar = (g.h) adapter;
                i2 = 0;
            }
            g.k item = (motionEvent.getAction() == 10 || (pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i3 = pointToPosition - i2) < 0 || i3 >= hVar.getCount()) ? null : hVar.getItem(i3);
            g.k kVar = this.f2089u;
            if (kVar != item) {
                g.j jVar = hVar.f1931e;
                if (kVar != null) {
                    this.f2088t.h(jVar, kVar);
                }
                this.f2089u = item;
                if (item != null) {
                    this.f2088t.g(jVar, item);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i2 == this.r) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        }
        if (listMenuItemView == null || i2 != this.f2087s) {
            return super.onKeyDown(i2, keyEvent);
        }
        setSelection(-1);
        ((g.h) getAdapter()).f1931e.c(false);
        return true;
    }

    public void setHoverListener(K k2) {
        this.f2088t = k2;
    }

    @Override // h.AbstractC0153A, android.widget.AbsListView
    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
