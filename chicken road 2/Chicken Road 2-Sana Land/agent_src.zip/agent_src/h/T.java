package h;

import androidx.appcompat.widget.SearchView;

/* loaded from: classes.dex */
public final class T implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f2109e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ SearchView f2110f;

    public /* synthetic */ T(SearchView searchView, int i2) {
        this.f2109e = i2;
        this.f2110f = searchView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f2109e) {
            case 0:
                this.f2110f.q();
                break;
            default:
                B.c cVar = this.f2110f.f1165S;
                if (cVar instanceof f0) {
                    cVar.b(null);
                    break;
                }
                break;
        }
    }
}
