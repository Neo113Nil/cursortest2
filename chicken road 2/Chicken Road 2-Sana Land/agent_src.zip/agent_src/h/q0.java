package h;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;

/* loaded from: classes.dex */
public final class q0 implements InterfaceC0182x {

    /* renamed from: a, reason: collision with root package name */
    public Toolbar f2218a;

    /* renamed from: b, reason: collision with root package name */
    public int f2219b;

    /* renamed from: c, reason: collision with root package name */
    public View f2220c;

    /* renamed from: d, reason: collision with root package name */
    public Drawable f2221d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f2222e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f2223f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2224g;

    /* renamed from: h, reason: collision with root package name */
    public CharSequence f2225h;

    /* renamed from: i, reason: collision with root package name */
    public CharSequence f2226i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f2227j;

    /* renamed from: k, reason: collision with root package name */
    public Window.Callback f2228k;

    /* renamed from: l, reason: collision with root package name */
    public int f2229l;

    /* renamed from: m, reason: collision with root package name */
    public Drawable f2230m;

    public final void a(int i2) {
        View view;
        Toolbar toolbar = this.f2218a;
        int i3 = this.f2219b ^ i2;
        this.f2219b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    b();
                }
                Toolbar toolbar2 = this.f2218a;
                if ((this.f2219b & 4) != 0) {
                    Drawable drawable = this.f2223f;
                    if (drawable == null) {
                        drawable = this.f2230m;
                    }
                    toolbar2.setNavigationIcon(drawable);
                } else {
                    toolbar2.setNavigationIcon((Drawable) null);
                }
            }
            if ((i3 & 3) != 0) {
                c();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    toolbar.setTitle(this.f2225h);
                    toolbar.setSubtitle(this.f2226i);
                } else {
                    toolbar.setTitle((CharSequence) null);
                    toolbar.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f2220c) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                toolbar.addView(view);
            } else {
                toolbar.removeView(view);
            }
        }
    }

    public final void b() {
        Toolbar toolbar = this.f2218a;
        if ((this.f2219b & 4) != 0) {
            if (TextUtils.isEmpty(this.f2227j)) {
                toolbar.setNavigationContentDescription(this.f2229l);
            } else {
                toolbar.setNavigationContentDescription(this.f2227j);
            }
        }
    }

    public final void c() {
        Drawable drawable;
        int i2 = this.f2219b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) != 0) {
            drawable = this.f2222e;
            if (drawable == null) {
                drawable = this.f2221d;
            }
        } else {
            drawable = this.f2221d;
        }
        this.f2218a.setLogo(drawable);
    }
}
