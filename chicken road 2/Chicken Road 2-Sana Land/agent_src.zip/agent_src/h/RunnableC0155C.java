package h;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import g.ViewOnTouchListenerC0143a;

/* renamed from: h.C, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0155C implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f2040e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ ViewOnTouchListenerC0143a f2041f;

    public /* synthetic */ RunnableC0155C(ViewOnTouchListenerC0143a viewOnTouchListenerC0143a, int i2) {
        this.f2040e = i2;
        this.f2041f = viewOnTouchListenerC0143a;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f2040e) {
            case 0:
                ViewParent parent = this.f2041f.f1888d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    break;
                }
                break;
            default:
                ViewOnTouchListenerC0143a viewOnTouchListenerC0143a = this.f2041f;
                viewOnTouchListenerC0143a.a();
                View view = viewOnTouchListenerC0143a.f1888d;
                if (view.isEnabled() && !view.isLongClickable() && viewOnTouchListenerC0143a.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(obtain);
                    obtain.recycle();
                    viewOnTouchListenerC0143a.f1891g = true;
                    break;
                }
                break;
        }
    }
}
