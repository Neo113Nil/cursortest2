package h;

import android.content.Context;
import android.view.View;
import com.grid.of.lights.R;

/* renamed from: h.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0165f extends g.n {

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f2134l = 1;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0168i f2135m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0165f(C0168i c0168i, Context context, g.j jVar, View view) {
        super(context, jVar, view, true, R.attr.actionOverflowMenuStyle, 0);
        this.f2135m = c0168i;
        this.f1991f = 8388613;
        A.j jVar2 = c0168i.f2181z;
        this.f1993h = jVar2;
        g.l lVar = this.f1994i;
        if (lVar != null) {
            lVar.c(jVar2);
        }
    }

    @Override // g.n
    public final void c() {
        switch (this.f2134l) {
            case 0:
                C0168i c0168i = this.f2135m;
                c0168i.f2178w = null;
                c0168i.getClass();
                super.c();
                break;
            default:
                C0168i c0168i2 = this.f2135m;
                g.j jVar = c0168i2.f2163g;
                if (jVar != null) {
                    jVar.c(true);
                }
                c0168i2.f2177v = null;
                super.c();
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0165f(C0168i c0168i, Context context, g.t tVar, View view) {
        super(context, tVar, view, false, R.attr.actionOverflowMenuStyle, 0);
        this.f2135m = c0168i;
        if ((tVar.f2016w.f1981x & 32) != 32) {
            View view2 = c0168i.f2168l;
            this.f1990e = view2 == null ? c0168i.f2167k : view2;
        }
        A.j jVar = c0168i.f2181z;
        this.f1993h = jVar;
        g.l lVar = this.f1994i;
        if (lVar != null) {
            lVar.c(jVar);
        }
    }
}
