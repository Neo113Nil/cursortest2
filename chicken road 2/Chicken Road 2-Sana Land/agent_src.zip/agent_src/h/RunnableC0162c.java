package h;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* renamed from: h.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0162c implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f2120e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ ActionBarOverlayLayout f2121f;

    public /* synthetic */ RunnableC0162c(ActionBarOverlayLayout actionBarOverlayLayout, int i2) {
        this.f2120e = i2;
        this.f2121f = actionBarOverlayLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f2120e) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.f2121f;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f1125x = actionBarOverlayLayout.f1109g.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f1126y);
                break;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.f2121f;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f1125x = actionBarOverlayLayout2.f1109g.animate().translationY(-actionBarOverlayLayout2.f1109g.getHeight()).setListener(actionBarOverlayLayout2.f1126y);
                break;
        }
    }
}
