package h;

/* loaded from: classes.dex */
public final class P {

    /* renamed from: a, reason: collision with root package name */
    public int f2100a;

    /* renamed from: b, reason: collision with root package name */
    public int f2101b;

    /* renamed from: c, reason: collision with root package name */
    public int f2102c;

    /* renamed from: d, reason: collision with root package name */
    public int f2103d;

    /* renamed from: e, reason: collision with root package name */
    public int f2104e;

    /* renamed from: f, reason: collision with root package name */
    public int f2105f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2106g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2107h;

    public final void a(int i2, int i3) {
        this.f2102c = i2;
        this.f2103d = i3;
        this.f2107h = true;
        if (this.f2106g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f2100a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f2101b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f2100a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f2101b = i3;
        }
    }
}
