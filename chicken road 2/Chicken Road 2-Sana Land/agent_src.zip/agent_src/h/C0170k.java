package h;

/* renamed from: h.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0170k extends C0156D {

    /* renamed from: c, reason: collision with root package name */
    public boolean f2187c;

    /* renamed from: d, reason: collision with root package name */
    public int f2188d;

    /* renamed from: e, reason: collision with root package name */
    public int f2189e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2190f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2191g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2192h;
}
