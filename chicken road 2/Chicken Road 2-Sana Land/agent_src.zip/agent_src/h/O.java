package h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import com.grid.of.lights.R;
import d0.C0116d;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import n.AbstractC0238a;
import q.AbstractC0246a;

/* loaded from: classes.dex */
public final class O {

    /* renamed from: g, reason: collision with root package name */
    public static O f2093g;

    /* renamed from: a, reason: collision with root package name */
    public WeakHashMap f2095a;

    /* renamed from: b, reason: collision with root package name */
    public final WeakHashMap f2096b = new WeakHashMap(0);

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f2097c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f2098d;

    /* renamed from: e, reason: collision with root package name */
    public C0116d f2099e;

    /* renamed from: f, reason: collision with root package name */
    public static final PorterDuff.Mode f2092f = PorterDuff.Mode.SRC_IN;

    /* renamed from: h, reason: collision with root package name */
    public static final N f2094h = new N(6);

    public static synchronized O b() {
        O o2;
        synchronized (O.class) {
            try {
                if (f2093g == null) {
                    f2093g = new O();
                }
                o2 = f2093g;
            } catch (Throwable th) {
                throw th;
            }
        }
        return o2;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        synchronized (O.class) {
            N n2 = f2094h;
            n2.getClass();
            int i3 = (31 + i2) * 31;
            porterDuffColorFilter = (PorterDuffColorFilter) n2.a(Integer.valueOf(mode.hashCode() + i3));
            if (porterDuffColorFilter == null) {
                porterDuffColorFilter = new PorterDuffColorFilter(i2, mode);
            }
        }
        return porterDuffColorFilter;
    }

    public final Drawable a(Context context, int i2) {
        Drawable drawable;
        Object obj;
        if (this.f2097c == null) {
            this.f2097c = new TypedValue();
        }
        TypedValue typedValue = this.f2097c;
        context.getResources().getValue(i2, typedValue, true);
        long j2 = (typedValue.assetCookie << 32) | typedValue.data;
        synchronized (this) {
            k.c cVar = (k.c) this.f2096b.get(context);
            drawable = null;
            if (cVar != null) {
                int b2 = k.b.b(cVar.f2604f, cVar.f2606h, j2);
                if (b2 < 0 || (obj = cVar.f2605g[b2]) == k.c.f2602i) {
                    obj = null;
                }
                WeakReference weakReference = (WeakReference) obj;
                if (weakReference != null) {
                    Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
                    if (constantState != null) {
                        drawable = constantState.newDrawable(context.getResources());
                    } else {
                        int b3 = k.b.b(cVar.f2604f, cVar.f2606h, j2);
                        if (b3 >= 0) {
                            Object[] objArr = cVar.f2605g;
                            Object obj2 = objArr[b3];
                            Object obj3 = k.c.f2602i;
                            if (obj2 != obj3) {
                                objArr[b3] = obj3;
                                cVar.f2603e = true;
                            }
                        }
                    }
                }
            }
        }
        if (drawable != null) {
            return drawable;
        }
        LayerDrawable layerDrawable = null;
        if (this.f2099e != null && i2 == R.drawable.abc_cab_background_top_material) {
            layerDrawable = new LayerDrawable(new Drawable[]{c(context, R.drawable.abc_cab_background_internal_bg), c(context, 2131165201)});
        }
        if (layerDrawable == null) {
            return layerDrawable;
        }
        layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
        synchronized (this) {
            try {
                Drawable.ConstantState constantState2 = layerDrawable.getConstantState();
                if (constantState2 != null) {
                    k.c cVar2 = (k.c) this.f2096b.get(context);
                    if (cVar2 == null) {
                        cVar2 = new k.c();
                        this.f2096b.put(context, cVar2);
                    }
                    cVar2.b(j2, new WeakReference(constantState2));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return layerDrawable;
    }

    public final synchronized Drawable c(Context context, int i2) {
        return d(context, i2);
    }

    public final synchronized Drawable d(Context context, int i2) {
        Drawable a2;
        try {
            if (!this.f2098d) {
                this.f2098d = true;
                Drawable c2 = c(context, R.drawable.abc_vector_test);
                if (c2 == null || (!(c2 instanceof O.a) && !"android.graphics.drawable.VectorDrawable".equals(c2.getClass().getName()))) {
                    this.f2098d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            a2 = a(context, i2);
            if (a2 == null) {
                a2 = AbstractC0238a.b(context, i2);
            }
            if (a2 != null) {
                a2 = g(context, i2, a2);
            }
            if (a2 != null) {
                Rect rect = AbstractC0183y.f2285a;
            }
        } catch (Throwable th) {
            throw th;
        }
        return a2;
    }

    public final synchronized ColorStateList f(Context context, int i2) {
        ColorStateList colorStateList;
        int i3;
        k.j jVar;
        Object obj;
        WeakHashMap weakHashMap = this.f2095a;
        ColorStateList colorStateList2 = null;
        if (weakHashMap == null || (jVar = (k.j) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            int a2 = k.b.a(jVar.f2634g, i2, jVar.f2632e);
            if (a2 < 0 || (obj = jVar.f2633f[a2]) == k.j.f2631h) {
                obj = null;
            }
            colorStateList = (ColorStateList) obj;
        }
        if (colorStateList == null) {
            C0116d c0116d = this.f2099e;
            if (c0116d != null) {
                colorStateList2 = c0116d.c(context, i2);
            }
            if (colorStateList2 != null) {
                if (this.f2095a == null) {
                    this.f2095a = new WeakHashMap();
                }
                k.j jVar2 = (k.j) this.f2095a.get(context);
                if (jVar2 == null) {
                    jVar2 = new k.j();
                    int i4 = 4;
                    while (true) {
                        i3 = 40;
                        if (i4 >= 32) {
                            break;
                        }
                        int i5 = (1 << i4) - 12;
                        if (40 <= i5) {
                            i3 = i5;
                            break;
                        }
                        i4++;
                    }
                    int i6 = i3 / 4;
                    jVar2.f2632e = new int[i6];
                    jVar2.f2633f = new Object[i6];
                    this.f2095a.put(context, jVar2);
                }
                jVar2.a(i2, colorStateList2);
            }
            colorStateList = colorStateList2;
        }
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x00ee  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Drawable g(Context context, int i2, Drawable drawable) {
        int i3;
        int round;
        PorterDuffColorFilter e2;
        ColorStateList f2 = f(context, i2);
        if (f2 != null) {
            if (AbstractC0183y.a(drawable)) {
                drawable = drawable.mutate();
            }
            AbstractC0246a.h(drawable, f2);
            PorterDuff.Mode mode = null;
            if (this.f2099e != null && i2 == R.drawable.abc_switch_thumb_material) {
                mode = PorterDuff.Mode.MULTIPLY;
            }
            if (mode != null) {
                AbstractC0246a.i(drawable, mode);
            }
            return drawable;
        }
        if (this.f2099e != null) {
            if (i2 == R.drawable.abc_seekbar_track_material) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId = layerDrawable.findDrawableByLayerId(android.R.id.background);
                int b2 = h0.b(context, R.attr.colorControlNormal);
                PorterDuff.Mode mode2 = C0174o.f2209b;
                C0116d.e(findDrawableByLayerId, b2, mode2);
                C0116d.e(layerDrawable.findDrawableByLayerId(android.R.id.secondaryProgress), h0.b(context, R.attr.colorControlNormal), mode2);
                C0116d.e(layerDrawable.findDrawableByLayerId(android.R.id.progress), h0.b(context, R.attr.colorControlActivated), mode2);
                return drawable;
            }
            if (i2 == R.drawable.abc_ratingbar_material || i2 == R.drawable.abc_ratingbar_indicator_material || i2 == R.drawable.abc_ratingbar_small_material) {
                LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(android.R.id.background);
                int a2 = h0.a(context, R.attr.colorControlNormal);
                PorterDuff.Mode mode3 = C0174o.f2209b;
                C0116d.e(findDrawableByLayerId2, a2, mode3);
                C0116d.e(layerDrawable2.findDrawableByLayerId(android.R.id.secondaryProgress), h0.b(context, R.attr.colorControlActivated), mode3);
                C0116d.e(layerDrawable2.findDrawableByLayerId(android.R.id.progress), h0.b(context, R.attr.colorControlActivated), mode3);
                return drawable;
            }
        }
        C0116d c0116d = this.f2099e;
        if (c0116d != null) {
            PorterDuff.Mode mode4 = C0174o.f2209b;
            boolean z2 = true;
            if (C0116d.a((int[]) c0116d.f1783a, i2)) {
                i3 = R.attr.colorControlNormal;
            } else if (C0116d.a((int[]) c0116d.f1785c, i2)) {
                i3 = R.attr.colorControlActivated;
            } else {
                if (C0116d.a((int[]) c0116d.f1786d, i2)) {
                    mode4 = PorterDuff.Mode.MULTIPLY;
                } else if (i2 == 2131165227) {
                    round = Math.round(40.8f);
                    i3 = 16842800;
                    if (z2) {
                        Drawable mutate = AbstractC0183y.a(drawable) ? drawable.mutate() : drawable;
                        int b3 = h0.b(context, i3);
                        synchronized (C0174o.class) {
                            e2 = e(b3, mode4);
                        }
                        mutate.setColorFilter(e2);
                        if (round != -1) {
                            mutate.setAlpha(round);
                        }
                    }
                } else if (i2 != R.drawable.abc_dialog_material_background) {
                    z2 = false;
                    i3 = 0;
                }
                i3 = 16842801;
            }
            round = -1;
            if (z2) {
            }
        }
        return drawable;
    }
}
