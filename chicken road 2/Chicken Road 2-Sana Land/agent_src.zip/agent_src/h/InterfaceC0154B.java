package h;

/* renamed from: h.B, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0154B {
}
