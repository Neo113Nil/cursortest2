package h;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;

/* renamed from: h.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0177s {

    /* renamed from: a, reason: collision with root package name */
    public final int f2233a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2234b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f2235c;

    public C0177s(int i2, String str, double d2, double d3, double d4, double d5, int i3, int i4, ByteBuffer byteBuffer) {
        this.f2233a = i2;
        this.f2235c = str;
        this.f2234b = i3;
    }

    public void a() {
        new Handler(Looper.getMainLooper()).post(new androidx.lifecycle.k(4, this));
    }

    public void b(Typeface typeface) {
        int i2;
        WeakReference weakReference = (WeakReference) this.f2235c;
        C0178t c0178t = (C0178t) weakReference.get();
        if (c0178t == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f2233a) != -1) {
            typeface = Typeface.create(typeface, i2, (this.f2234b & 2) != 0);
        }
        c0178t.f2247a.post(new O0.g(weakReference, typeface, 2, false));
    }

    public C0177s(C0178t c0178t, int i2, int i3) {
        this.f2235c = new WeakReference(c0178t);
        this.f2233a = i2;
        this.f2234b = i3;
    }
}
