package h;

import L.C0051b;
import a.AbstractC0068a;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import d.AbstractC0112a;

/* renamed from: h.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0172m extends AutoCompleteTextView {

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f2195g = {R.attr.popupBackground};

    /* renamed from: e, reason: collision with root package name */
    public final C0173n f2196e;

    /* renamed from: f, reason: collision with root package name */
    public final C0178t f2197f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AbstractC0172m(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.grid.of.lights.R.attr.autoCompleteTextViewStyle);
        i0.a(context);
        C0051b C2 = C0051b.C(getContext(), attributeSet, f2195g, com.grid.of.lights.R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) C2.f583f).hasValue(0)) {
            setDropDownBackgroundDrawable(C2.v(0));
        }
        C2.F();
        C0173n c0173n = new C0173n(this);
        this.f2196e = c0173n;
        c0173n.b(attributeSet, com.grid.of.lights.R.attr.autoCompleteTextViewStyle);
        C0178t c0178t = new C0178t(this);
        this.f2197f = c0178t;
        c0178t.d(attributeSet, com.grid.of.lights.R.attr.autoCompleteTextViewStyle);
        c0178t.b();
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0173n c0173n = this.f2196e;
        if (c0173n != null) {
            c0173n.a();
        }
        C0178t c0178t = this.f2197f;
        if (c0178t != null) {
            c0178t.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        j0 j0Var;
        C0173n c0173n = this.f2196e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2183a;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        j0 j0Var;
        C0173n c0173n = this.f2196e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2184b;
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        if (onCreateInputConnection != null && editorInfo.hintText == null) {
            for (ViewParent parent = getParent(); parent instanceof View; parent = parent.getParent()) {
            }
        }
        return onCreateInputConnection;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0173n c0173n = this.f2196e;
        if (c0173n != null) {
            c0173n.f2203c = -1;
            c0173n.d(null);
            c0173n.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0173n c0173n = this.f2196e;
        if (c0173n != null) {
            c0173n.c(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(AbstractC0068a.M(callback, this));
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i2) {
        setDropDownBackgroundDrawable(AbstractC0112a.a(getContext(), i2));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0173n c0173n = this.f2196e;
        if (c0173n != null) {
            c0173n.e(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0173n c0173n = this.f2196e;
        if (c0173n != null) {
            c0173n.f(mode);
        }
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        C0178t c0178t = this.f2197f;
        if (c0178t != null) {
            c0178t.e(context, i2);
        }
    }
}
