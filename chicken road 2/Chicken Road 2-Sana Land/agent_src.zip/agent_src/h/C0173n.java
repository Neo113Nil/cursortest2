package h;

import L.C0051b;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import c.AbstractC0096a;
import java.lang.reflect.Field;
import w.AbstractC0292p;

/* renamed from: h.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0173n {

    /* renamed from: a, reason: collision with root package name */
    public final View f2201a;

    /* renamed from: b, reason: collision with root package name */
    public final C0174o f2202b;

    /* renamed from: c, reason: collision with root package name */
    public int f2203c = -1;

    /* renamed from: d, reason: collision with root package name */
    public j0 f2204d;

    /* renamed from: e, reason: collision with root package name */
    public j0 f2205e;

    /* renamed from: f, reason: collision with root package name */
    public j0 f2206f;

    public C0173n(View view) {
        C0174o c0174o;
        this.f2201a = view;
        PorterDuff.Mode mode = C0174o.f2209b;
        synchronized (C0174o.class) {
            try {
                if (C0174o.f2210c == null) {
                    C0174o.b();
                }
                c0174o = C0174o.f2210c;
            } catch (Throwable th) {
                throw th;
            }
        }
        this.f2202b = c0174o;
    }

    public final void a() {
        View view = this.f2201a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f2204d != null) {
                if (this.f2206f == null) {
                    this.f2206f = new j0();
                }
                j0 j0Var = this.f2206f;
                j0Var.f2183a = null;
                j0Var.f2186d = false;
                j0Var.f2184b = null;
                j0Var.f2185c = false;
                Field field = w.x.f3034a;
                ColorStateList g2 = AbstractC0292p.g(view);
                if (g2 != null) {
                    j0Var.f2186d = true;
                    j0Var.f2183a = g2;
                }
                PorterDuff.Mode h2 = AbstractC0292p.h(view);
                if (h2 != null) {
                    j0Var.f2185c = true;
                    j0Var.f2184b = h2;
                }
                if (j0Var.f2186d || j0Var.f2185c) {
                    C0174o.c(background, j0Var, view.getDrawableState());
                    return;
                }
            }
            j0 j0Var2 = this.f2205e;
            if (j0Var2 != null) {
                C0174o.c(background, j0Var2, view.getDrawableState());
                return;
            }
            j0 j0Var3 = this.f2204d;
            if (j0Var3 != null) {
                C0174o.c(background, j0Var3, view.getDrawableState());
            }
        }
    }

    public final void b(AttributeSet attributeSet, int i2) {
        ColorStateList f2;
        View view = this.f2201a;
        C0051b C2 = C0051b.C(view.getContext(), attributeSet, AbstractC0096a.f1631u, i2);
        TypedArray typedArray = (TypedArray) C2.f583f;
        try {
            if (typedArray.hasValue(0)) {
                this.f2203c = typedArray.getResourceId(0, -1);
                C0174o c0174o = this.f2202b;
                Context context = view.getContext();
                int i3 = this.f2203c;
                synchronized (c0174o) {
                    f2 = c0174o.f2211a.f(context, i3);
                }
                if (f2 != null) {
                    d(f2);
                }
            }
            if (typedArray.hasValue(1)) {
                ColorStateList u2 = C2.u(1);
                Field field = w.x.f3034a;
                AbstractC0292p.q(view, u2);
            }
            if (typedArray.hasValue(2)) {
                PorterDuff.Mode c2 = AbstractC0183y.c(typedArray.getInt(2, -1), null);
                Field field2 = w.x.f3034a;
                AbstractC0292p.r(view, c2);
            }
        } finally {
            C2.F();
        }
    }

    public final void c(int i2) {
        ColorStateList colorStateList;
        this.f2203c = i2;
        C0174o c0174o = this.f2202b;
        if (c0174o != null) {
            Context context = this.f2201a.getContext();
            synchronized (c0174o) {
                colorStateList = c0174o.f2211a.f(context, i2);
            }
        } else {
            colorStateList = null;
        }
        d(colorStateList);
        a();
    }

    public final void d(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f2204d == null) {
                this.f2204d = new j0();
            }
            j0 j0Var = this.f2204d;
            j0Var.f2183a = colorStateList;
            j0Var.f2186d = true;
        } else {
            this.f2204d = null;
        }
        a();
    }

    public final void e(ColorStateList colorStateList) {
        if (this.f2205e == null) {
            this.f2205e = new j0();
        }
        j0 j0Var = this.f2205e;
        j0Var.f2183a = colorStateList;
        j0Var.f2186d = true;
        a();
    }

    public final void f(PorterDuff.Mode mode) {
        if (this.f2205e == null) {
            this.f2205e = new j0();
        }
        j0 j0Var = this.f2205e;
        j0Var.f2184b = mode;
        j0Var.f2185c = true;
        a();
    }
}
