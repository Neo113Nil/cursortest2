package h;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class p0 extends C.c {
    public static final Parcelable.Creator<p0> CREATOR = new C.b(3);

    /* renamed from: g, reason: collision with root package name */
    public int f2214g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2215h;

    public p0(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f2214g = parcel.readInt();
        this.f2215h = parcel.readInt() != 0;
    }

    @Override // C.c, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeInt(this.f2214g);
        parcel.writeInt(this.f2215h ? 1 : 0);
    }
}
