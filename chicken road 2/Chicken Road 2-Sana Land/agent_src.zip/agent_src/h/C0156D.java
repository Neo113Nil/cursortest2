package h;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;
import c.AbstractC0096a;

/* renamed from: h.D, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0156D extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public final float f2042a;

    /* renamed from: b, reason: collision with root package name */
    public int f2043b;

    public C0156D(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2043b = -1;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0096a.f1621j);
        this.f2042a = obtainStyledAttributes.getFloat(3, 0.0f);
        this.f2043b = obtainStyledAttributes.getInt(0, -1);
        obtainStyledAttributes.recycle();
    }

    public C0156D(int i2) {
        super(i2, -2);
        this.f2043b = -1;
        this.f2042a = 0.0f;
    }

    public C0156D(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f2043b = -1;
    }
}
