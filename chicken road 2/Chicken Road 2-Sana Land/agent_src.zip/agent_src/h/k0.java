package h;

import android.content.res.Resources;

/* loaded from: classes.dex */
public abstract class k0 extends Resources {
}
