package h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.widget.ImageButton;
import android.widget.ImageView;
import com.grid.of.lights.R;
import d.AbstractC0112a;

/* renamed from: h.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0175p extends ImageButton {

    /* renamed from: e, reason: collision with root package name */
    public final C0173n f2212e;

    /* renamed from: f, reason: collision with root package name */
    public final L.Q f2213f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0175p(Context context) {
        super(context, null, R.attr.toolbarNavigationButtonStyle);
        i0.a(context);
        C0173n c0173n = new C0173n(this);
        this.f2212e = c0173n;
        c0173n.b(null, R.attr.toolbarNavigationButtonStyle);
        L.Q q2 = new L.Q(this);
        this.f2213f = q2;
        q2.z(R.attr.toolbarNavigationButtonStyle);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0173n c0173n = this.f2212e;
        if (c0173n != null) {
            c0173n.a();
        }
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            q2.w();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        j0 j0Var;
        C0173n c0173n = this.f2212e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2183a;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        j0 j0Var;
        C0173n c0173n = this.f2212e;
        if (c0173n == null || (j0Var = c0173n.f2205e) == null) {
            return null;
        }
        return j0Var.f2184b;
    }

    public ColorStateList getSupportImageTintList() {
        j0 j0Var;
        L.Q q2 = this.f2213f;
        if (q2 == null || (j0Var = (j0) q2.f579g) == null) {
            return null;
        }
        return j0Var.f2183a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        j0 j0Var;
        L.Q q2 = this.f2213f;
        if (q2 == null || (j0Var = (j0) q2.f579g) == null) {
            return null;
        }
        return j0Var.f2184b;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(((ImageView) this.f2213f.f578f).getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0173n c0173n = this.f2212e;
        if (c0173n != null) {
            c0173n.f2203c = -1;
            c0173n.d(null);
            c0173n.a();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0173n c0173n = this.f2212e;
        if (c0173n != null) {
            c0173n.c(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            q2.w();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            q2.w();
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        L.Q q2 = this.f2213f;
        ImageView imageView = (ImageView) q2.f578f;
        if (i2 != 0) {
            Drawable a2 = AbstractC0112a.a(imageView.getContext(), i2);
            if (a2 != null) {
                Rect rect = AbstractC0183y.f2285a;
            }
            imageView.setImageDrawable(a2);
        } else {
            imageView.setImageDrawable(null);
        }
        q2.w();
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            q2.w();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0173n c0173n = this.f2212e;
        if (c0173n != null) {
            c0173n.e(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0173n c0173n = this.f2212e;
        if (c0173n != null) {
            c0173n.f(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            if (((j0) q2.f579g) == null) {
                q2.f579g = new j0();
            }
            j0 j0Var = (j0) q2.f579g;
            j0Var.f2183a = colorStateList;
            j0Var.f2186d = true;
            q2.w();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        L.Q q2 = this.f2213f;
        if (q2 != null) {
            if (((j0) q2.f579g) == null) {
                q2.f579g = new j0();
            }
            j0 j0Var = (j0) q2.f579g;
            j0Var.f2184b = mode;
            j0Var.f2185c = true;
            q2.w();
        }
    }
}
