package h;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import f.InterfaceC0138a;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class m0 implements g.p {

    /* renamed from: e, reason: collision with root package name */
    public g.j f2198e;

    /* renamed from: f, reason: collision with root package name */
    public g.k f2199f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Toolbar f2200g;

    public m0(Toolbar toolbar) {
        this.f2200g = toolbar;
    }

    @Override // g.p
    public final boolean d(g.k kVar) {
        Toolbar toolbar = this.f2200g;
        toolbar.c();
        ViewParent parent = toolbar.f1250l.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f1250l);
            }
            toolbar.addView(toolbar.f1250l);
        }
        View view = kVar.f1983z;
        if (view == null) {
            view = null;
        }
        toolbar.f1251m = view;
        this.f2199f = kVar;
        ViewParent parent2 = view.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f1251m);
            }
            n0 g2 = Toolbar.g();
            g2.f2207a = (toolbar.r & 112) | 8388611;
            g2.f2208b = 2;
            toolbar.f1251m.setLayoutParams(g2);
            toolbar.addView(toolbar.f1251m);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((n0) childAt.getLayoutParams()).f2208b != 2 && childAt != toolbar.f1243e) {
                toolbar.removeViewAt(childCount);
                toolbar.f1236I.add(childAt);
            }
        }
        toolbar.requestLayout();
        kVar.f1958B = true;
        kVar.f1972n.o(false);
        KeyEvent.Callback callback = toolbar.f1251m;
        if (callback instanceof InterfaceC0138a) {
            SearchView searchView = (SearchView) ((InterfaceC0138a) callback);
            SearchView.SearchAutoComplete searchAutoComplete = searchView.f1178t;
            if (!searchView.f1172d0) {
                searchView.f1172d0 = true;
                int imeOptions = searchAutoComplete.getImeOptions();
                searchView.f1173e0 = imeOptions;
                searchAutoComplete.setImeOptions(imeOptions | 33554432);
                searchAutoComplete.setText("");
                searchView.setIconified(false);
            }
        }
        return true;
    }

    @Override // g.p
    public final boolean e(g.k kVar) {
        Toolbar toolbar = this.f2200g;
        KeyEvent.Callback callback = toolbar.f1251m;
        if (callback instanceof InterfaceC0138a) {
            SearchView searchView = (SearchView) ((InterfaceC0138a) callback);
            SearchView.SearchAutoComplete searchAutoComplete = searchView.f1178t;
            searchAutoComplete.setText("");
            searchAutoComplete.setSelection(searchAutoComplete.length());
            searchView.f1171c0 = "";
            searchView.clearFocus();
            searchView.u(true);
            searchAutoComplete.setImeOptions(searchView.f1173e0);
            searchView.f1172d0 = false;
        }
        toolbar.removeView(toolbar.f1251m);
        toolbar.removeView(toolbar.f1250l);
        toolbar.f1251m = null;
        ArrayList arrayList = toolbar.f1236I;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.f2199f = null;
        toolbar.requestLayout();
        kVar.f1958B = false;
        kVar.f1972n.o(false);
        return true;
    }

    @Override // g.p
    public final void f() {
        if (this.f2199f != null) {
            g.j jVar = this.f2198e;
            if (jVar != null) {
                int size = jVar.f1943f.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (this.f2198e.getItem(i2) == this.f2199f) {
                        return;
                    }
                }
            }
            e(this.f2199f);
        }
    }

    @Override // g.p
    public final boolean g(g.t tVar) {
        return false;
    }

    @Override // g.p
    public final boolean h() {
        return false;
    }

    @Override // g.p
    public final void k(Context context, g.j jVar) {
        g.k kVar;
        g.j jVar2 = this.f2198e;
        if (jVar2 != null && (kVar = this.f2199f) != null) {
            jVar2.d(kVar);
        }
        this.f2198e = jVar;
    }

    @Override // g.p
    public final void a(g.j jVar, boolean z2) {
    }
}
