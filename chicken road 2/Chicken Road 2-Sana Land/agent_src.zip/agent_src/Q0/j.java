package Q0;

import J0.AbstractC0044u;

/* loaded from: classes.dex */
public final class j extends i {

    /* renamed from: g, reason: collision with root package name */
    public final Runnable f922g;

    public j(Runnable runnable, long j2, boolean z2) {
        super(j2, z2);
        this.f922g = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f922g.run();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Task[");
        Runnable runnable = this.f922g;
        sb.append(runnable.getClass().getSimpleName());
        sb.append('@');
        sb.append(AbstractC0044u.b(runnable));
        sb.append(", ");
        sb.append(this.f920e);
        sb.append(", ");
        sb.append(this.f921f ? "Blocking" : "Non-blocking");
        sb.append(']');
        return sb.toString();
    }
}
