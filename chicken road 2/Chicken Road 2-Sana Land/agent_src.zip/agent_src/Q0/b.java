package Q0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: e, reason: collision with root package name */
    public static final b f898e;

    /* renamed from: f, reason: collision with root package name */
    public static final b f899f;

    /* renamed from: g, reason: collision with root package name */
    public static final b f900g;

    /* renamed from: h, reason: collision with root package name */
    public static final b f901h;

    /* renamed from: i, reason: collision with root package name */
    public static final b f902i;

    /* renamed from: j, reason: collision with root package name */
    public static final /* synthetic */ b[] f903j;

    static {
        b bVar = new b("CPU_ACQUIRED", 0);
        f898e = bVar;
        b bVar2 = new b("BLOCKING", 1);
        f899f = bVar2;
        b bVar3 = new b("PARKING", 2);
        f900g = bVar3;
        b bVar4 = new b("DORMANT", 3);
        f901h = bVar4;
        b bVar5 = new b("TERMINATED", 4);
        f902i = bVar5;
        f903j = new b[]{bVar, bVar2, bVar3, bVar4, bVar5};
    }

    public static b valueOf(String str) {
        return (b) Enum.valueOf(b.class, str);
    }

    public static b[] values() {
        return (b[]) f903j.clone();
    }
}
