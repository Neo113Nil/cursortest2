package Q0;

/* loaded from: classes.dex */
public final class e extends h {

    /* renamed from: h, reason: collision with root package name */
    public static final e f917h;

    static {
        int i2 = k.f925c;
        int i3 = k.f926d;
        long j2 = k.f927e;
        String str = k.f923a;
        e eVar = new e();
        eVar.f919g = new c(i2, i3, j2, str);
        f917h = eVar;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    @Override // J0.AbstractC0041q
    public final String toString() {
        return "Dispatchers.Default";
    }
}
