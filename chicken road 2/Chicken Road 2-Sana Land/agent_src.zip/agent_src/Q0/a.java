package Q0;

import E0.p;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;

/* loaded from: classes.dex */
public final class a extends Thread {

    /* renamed from: m, reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f889m = AtomicIntegerFieldUpdater.newUpdater(a.class, "workerCtl$volatile");

    /* renamed from: e, reason: collision with root package name */
    public final m f890e;

    /* renamed from: f, reason: collision with root package name */
    public final p f891f;

    /* renamed from: g, reason: collision with root package name */
    public b f892g;

    /* renamed from: h, reason: collision with root package name */
    public long f893h;

    /* renamed from: i, reason: collision with root package name */
    public long f894i;
    private volatile int indexInArray;

    /* renamed from: j, reason: collision with root package name */
    public int f895j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f896k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ c f897l;
    private volatile Object nextParkedWorker;
    private volatile /* synthetic */ int workerCtl$volatile;

    public a(c cVar, int i2) {
        this.f897l = cVar;
        setDaemon(true);
        setContextClassLoader(c.class.getClassLoader());
        this.f890e = new m();
        this.f891f = new p();
        this.f892g = b.f901h;
        this.nextParkedWorker = c.f907o;
        int nanoTime = (int) System.nanoTime();
        this.f895j = nanoTime == 0 ? 42 : nanoTime;
        f(i2);
    }

    public final i a(boolean z2) {
        i e2;
        i e3;
        long j2;
        b bVar = this.f892g;
        c cVar = this.f897l;
        i iVar = null;
        m mVar = this.f890e;
        b bVar2 = b.f898e;
        if (bVar != bVar2) {
            AtomicLongFieldUpdater atomicLongFieldUpdater = c.f905m;
            do {
                j2 = atomicLongFieldUpdater.get(cVar);
                if (((int) ((9223367638808264704L & j2) >> 42)) == 0) {
                    mVar.getClass();
                    loop1: while (true) {
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = m.f930b;
                        i iVar2 = (i) atomicReferenceFieldUpdater.get(mVar);
                        if (iVar2 != null && iVar2.f921f) {
                            while (!atomicReferenceFieldUpdater.compareAndSet(mVar, iVar2, null)) {
                                if (atomicReferenceFieldUpdater.get(mVar) != iVar2) {
                                    break;
                                }
                            }
                            iVar = iVar2;
                            break loop1;
                        }
                    }
                    int i2 = m.f932d.get(mVar);
                    int i3 = m.f931c.get(mVar);
                    while (true) {
                        if (i2 == i3 || m.f933e.get(mVar) == 0) {
                            break;
                        }
                        i3--;
                        i b2 = mVar.b(i3, true);
                        if (b2 != null) {
                            iVar = b2;
                            break;
                        }
                    }
                    if (iVar != null) {
                        return iVar;
                    }
                    i iVar3 = (i) cVar.f913j.d();
                    return iVar3 == null ? i(1) : iVar3;
                }
            } while (!c.f905m.compareAndSet(cVar, j2, j2 - 4398046511104L));
            this.f892g = bVar2;
        }
        if (z2) {
            boolean z3 = d(cVar.f908e * 2) == 0;
            if (z3 && (e3 = e()) != null) {
                return e3;
            }
            mVar.getClass();
            i iVar4 = (i) m.f930b.getAndSet(mVar, null);
            if (iVar4 == null) {
                iVar4 = mVar.a();
            }
            if (iVar4 != null) {
                return iVar4;
            }
            if (!z3 && (e2 = e()) != null) {
                return e2;
            }
        } else {
            i e4 = e();
            if (e4 != null) {
                return e4;
            }
        }
        return i(3);
    }

    public final int b() {
        return this.indexInArray;
    }

    public final Object c() {
        return this.nextParkedWorker;
    }

    public final int d(int i2) {
        int i3 = this.f895j;
        int i4 = i3 ^ (i3 << 13);
        int i5 = i4 ^ (i4 >> 17);
        int i6 = i5 ^ (i5 << 5);
        this.f895j = i6;
        int i7 = i2 - 1;
        return (i7 & i2) == 0 ? i6 & i7 : (i6 & Integer.MAX_VALUE) % i2;
    }

    public final i e() {
        int d2 = d(2);
        c cVar = this.f897l;
        if (d2 == 0) {
            i iVar = (i) cVar.f912i.d();
            return iVar != null ? iVar : (i) cVar.f913j.d();
        }
        i iVar2 = (i) cVar.f913j.d();
        return iVar2 != null ? iVar2 : (i) cVar.f912i.d();
    }

    public final void f(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f897l.f911h);
        sb.append("-worker-");
        sb.append(i2 == 0 ? "TERMINATED" : String.valueOf(i2));
        setName(sb.toString());
        this.indexInArray = i2;
    }

    public final void g(Object obj) {
        this.nextParkedWorker = obj;
    }

    public final boolean h(b bVar) {
        b bVar2 = this.f892g;
        boolean z2 = bVar2 == b.f898e;
        if (z2) {
            c.f905m.addAndGet(this.f897l, 4398046511104L);
        }
        if (bVar2 != bVar) {
            this.f892g = bVar;
        }
        return z2;
    }

    public final i i(int i2) {
        long j2;
        i iVar;
        long j3;
        long j4;
        i iVar2;
        AtomicLongFieldUpdater atomicLongFieldUpdater = c.f905m;
        c cVar = this.f897l;
        int i3 = (int) (atomicLongFieldUpdater.get(cVar) & 2097151);
        i iVar3 = null;
        if (i3 < 2) {
            return null;
        }
        int d2 = d(i3);
        int i4 = 0;
        long j5 = Long.MAX_VALUE;
        while (i4 < i3) {
            d2++;
            if (d2 > i3) {
                d2 = 1;
            }
            a aVar = (a) cVar.f914k.b(d2);
            if (aVar != null && aVar != this) {
                m mVar = aVar.f890e;
                if (i2 == 3) {
                    iVar = mVar.a();
                    j2 = 0;
                } else {
                    mVar.getClass();
                    int i5 = m.f932d.get(mVar);
                    int i6 = m.f931c.get(mVar);
                    boolean z2 = i2 == 1;
                    while (true) {
                        if (i5 == i6) {
                            j2 = 0;
                            break;
                        }
                        j2 = 0;
                        if (!z2 || m.f933e.get(mVar) != 0) {
                            int i7 = i5 + 1;
                            iVar = mVar.b(i5, z2);
                            if (iVar != null) {
                                break;
                            }
                            i5 = i7;
                        } else {
                            break;
                        }
                    }
                    iVar = iVar3;
                }
                p pVar = this.f891f;
                if (iVar != null) {
                    pVar.f300e = iVar;
                    iVar2 = iVar3;
                    j4 = -1;
                    j3 = -1;
                } else {
                    while (true) {
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = m.f930b;
                        i iVar4 = (i) atomicReferenceFieldUpdater.get(mVar);
                        if (iVar4 == null) {
                            j3 = -1;
                            break;
                        }
                        j3 = -1;
                        if (((iVar4.f921f ? 1 : 2) & i2) == 0) {
                            break;
                        }
                        k.f928f.getClass();
                        m mVar2 = mVar;
                        long nanoTime = System.nanoTime() - iVar4.f920e;
                        long j6 = k.f924b;
                        if (nanoTime < j6) {
                            j4 = j6 - nanoTime;
                            iVar2 = null;
                            break;
                        }
                        do {
                            iVar2 = null;
                            if (atomicReferenceFieldUpdater.compareAndSet(mVar2, iVar4, null)) {
                                pVar.f300e = iVar4;
                                j4 = -1;
                                break;
                            }
                        } while (atomicReferenceFieldUpdater.get(mVar2) == iVar4);
                        mVar = mVar2;
                        iVar3 = null;
                    }
                    j4 = -2;
                    iVar2 = iVar3;
                }
                if (j4 == j3) {
                    i iVar5 = (i) pVar.f300e;
                    pVar.f300e = iVar2;
                    return iVar5;
                }
                if (j4 > j2) {
                    j5 = Math.min(j5, j4);
                }
            }
            i4++;
            iVar3 = null;
        }
        if (j5 == Long.MAX_VALUE) {
            j5 = 0;
        }
        this.f894i = j5;
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:80:0x0004, code lost:
    
        continue;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x0004, code lost:
    
        continue;
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x0004, code lost:
    
        continue;
     */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        long j2;
        loop0: while (true) {
            boolean z2 = false;
            while (c.f906n.get(this.f897l) == 0) {
                b bVar = this.f892g;
                b bVar2 = b.f902i;
                if (bVar == bVar2) {
                    break loop0;
                }
                i a2 = a(this.f896k);
                if (a2 != null) {
                    this.f894i = 0L;
                    c cVar = this.f897l;
                    this.f893h = 0L;
                    if (this.f892g == b.f900g) {
                        this.f892g = b.f899f;
                    }
                    if (a2.f921f) {
                        if (h(b.f899f) && !cVar.e() && !cVar.d(c.f905m.get(cVar))) {
                            cVar.e();
                        }
                        try {
                            a2.run();
                        } catch (Throwable th) {
                            Thread currentThread = Thread.currentThread();
                            currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, th);
                        }
                        c.f905m.addAndGet(cVar, -2097152L);
                        if (this.f892g != bVar2) {
                            this.f892g = b.f901h;
                        }
                    } else {
                        try {
                            a2.run();
                        } catch (Throwable th2) {
                            Thread currentThread2 = Thread.currentThread();
                            currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th2);
                        }
                    }
                } else {
                    this.f896k = false;
                    if (this.f894i == 0) {
                        Object obj = this.nextParkedWorker;
                        A.j jVar = c.f907o;
                        if (obj != jVar) {
                            f889m.set(this, -1);
                            while (this.nextParkedWorker != c.f907o) {
                                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f889m;
                                if (atomicIntegerFieldUpdater.get(this) == -1) {
                                    c cVar2 = this.f897l;
                                    AtomicIntegerFieldUpdater atomicIntegerFieldUpdater2 = c.f906n;
                                    if (atomicIntegerFieldUpdater2.get(cVar2) != 0) {
                                        break;
                                    }
                                    b bVar3 = this.f892g;
                                    b bVar4 = b.f902i;
                                    if (bVar3 == bVar4) {
                                        break;
                                    }
                                    h(b.f900g);
                                    Thread.interrupted();
                                    if (this.f893h == 0) {
                                        j2 = 2097151;
                                        this.f893h = System.nanoTime() + this.f897l.f910g;
                                    } else {
                                        j2 = 2097151;
                                    }
                                    LockSupport.parkNanos(this.f897l.f910g);
                                    if (System.nanoTime() - this.f893h >= 0) {
                                        this.f893h = 0L;
                                        c cVar3 = this.f897l;
                                        synchronized (cVar3.f914k) {
                                            try {
                                                if (!(atomicIntegerFieldUpdater2.get(cVar3) != 0)) {
                                                    AtomicLongFieldUpdater atomicLongFieldUpdater = c.f905m;
                                                    if (((int) (atomicLongFieldUpdater.get(cVar3) & j2)) > cVar3.f908e) {
                                                        if (atomicIntegerFieldUpdater.compareAndSet(this, -1, 1)) {
                                                            int i2 = this.indexInArray;
                                                            f(0);
                                                            cVar3.c(this, i2, 0);
                                                            int andDecrement = (int) (atomicLongFieldUpdater.getAndDecrement(cVar3) & j2);
                                                            if (andDecrement != i2) {
                                                                Object b2 = cVar3.f914k.b(andDecrement);
                                                                E0.i.b(b2);
                                                                a aVar = (a) b2;
                                                                cVar3.f914k.c(i2, aVar);
                                                                aVar.f(i2);
                                                                cVar3.c(aVar, andDecrement, i2);
                                                            }
                                                            cVar3.f914k.c(andDecrement, null);
                                                            this.f892g = bVar4;
                                                        }
                                                    }
                                                }
                                            } catch (Throwable th3) {
                                                throw th3;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            c cVar4 = this.f897l;
                            if (this.nextParkedWorker == jVar) {
                                AtomicLongFieldUpdater atomicLongFieldUpdater2 = c.f904l;
                                while (true) {
                                    long j3 = atomicLongFieldUpdater2.get(cVar4);
                                    int i3 = this.indexInArray;
                                    this.nextParkedWorker = cVar4.f914k.b((int) (j3 & 2097151));
                                    c cVar5 = cVar4;
                                    if (c.f904l.compareAndSet(cVar5, j3, ((j3 + 2097152) & (-2097152)) | i3)) {
                                        break;
                                    } else {
                                        cVar4 = cVar5;
                                    }
                                }
                            }
                        }
                    } else if (z2) {
                        h(b.f900g);
                        Thread.interrupted();
                        LockSupport.parkNanos(this.f894i);
                        this.f894i = 0L;
                    } else {
                        z2 = true;
                    }
                }
            }
            break loop0;
        }
        h(b.f902i);
    }
}
