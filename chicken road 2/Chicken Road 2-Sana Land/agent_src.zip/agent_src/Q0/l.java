package Q0;

import J0.AbstractC0041q;

/* loaded from: classes.dex */
public final class l extends AbstractC0041q {

    /* renamed from: g, reason: collision with root package name */
    public static final l f929g = new l();

    @Override // J0.AbstractC0041q
    public final void c(w0.h hVar, Runnable runnable) {
        e.f917h.f919g.b(runnable, true);
    }

    @Override // J0.AbstractC0041q
    public final AbstractC0041q e(int i2) {
        O0.a.a(i2);
        return i2 >= k.f926d ? this : super.e(i2);
    }

    @Override // J0.AbstractC0041q
    public final String toString() {
        return "Dispatchers.IO";
    }
}
