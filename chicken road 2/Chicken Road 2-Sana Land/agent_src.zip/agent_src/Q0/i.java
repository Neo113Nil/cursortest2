package Q0;

/* loaded from: classes.dex */
public abstract class i implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public long f920e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f921f;

    public i(long j2, boolean z2) {
        this.f920e = j2;
        this.f921f = z2;
    }
}
