package Q0;

import O0.u;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public abstract class k {

    /* renamed from: a, reason: collision with root package name */
    public static final String f923a;

    /* renamed from: b, reason: collision with root package name */
    public static final long f924b;

    /* renamed from: c, reason: collision with root package name */
    public static final int f925c;

    /* renamed from: d, reason: collision with root package name */
    public static final int f926d;

    /* renamed from: e, reason: collision with root package name */
    public static final long f927e;

    /* renamed from: f, reason: collision with root package name */
    public static final g f928f;

    static {
        String str;
        int i2 = u.f871a;
        try {
            str = System.getProperty("kotlinx.coroutines.scheduler.default.name");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str == null) {
            str = "DefaultDispatcher";
        }
        f923a = str;
        f924b = O0.a.i("kotlinx.coroutines.scheduler.resolution.ns", 100000L, 1L, Long.MAX_VALUE);
        int i3 = u.f871a;
        if (i3 < 2) {
            i3 = 2;
        }
        f925c = O0.a.j("kotlinx.coroutines.scheduler.core.pool.size", i3, 8);
        f926d = O0.a.j("kotlinx.coroutines.scheduler.max.pool.size", 2097150, 4);
        f927e = TimeUnit.SECONDS.toNanos(O0.a.i("kotlinx.coroutines.scheduler.keep.alive.sec", 60L, 1L, Long.MAX_VALUE));
        f928f = g.f918a;
    }
}
