package Q0;

import J0.H;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;

/* loaded from: classes.dex */
public abstract class h extends H {

    /* renamed from: g, reason: collision with root package name */
    public c f919g;

    @Override // J0.AbstractC0041q
    public final void c(w0.h hVar, Runnable runnable) {
        c cVar = this.f919g;
        AtomicLongFieldUpdater atomicLongFieldUpdater = c.f904l;
        cVar.b(runnable, false);
    }
}
