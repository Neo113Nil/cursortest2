package Q0;

import J0.AbstractC0041q;
import J0.H;
import O0.u;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class d extends H implements Executor {

    /* renamed from: g, reason: collision with root package name */
    public static final d f915g = new d();

    /* renamed from: h, reason: collision with root package name */
    public static final AbstractC0041q f916h;

    static {
        l lVar = l.f929g;
        int i2 = u.f871a;
        if (64 >= i2) {
            i2 = 64;
        }
        f916h = lVar.e(O0.a.j("kotlinx.coroutines.io.parallelism", i2, 12));
    }

    @Override // J0.AbstractC0041q
    public final void c(w0.h hVar, Runnable runnable) {
        f916h.c(hVar, runnable);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO");
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        c(w0.i.f3040e, runnable);
    }

    @Override // J0.AbstractC0041q
    public final String toString() {
        return "Dispatchers.IO";
    }
}
