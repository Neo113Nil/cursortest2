package R;

import E0.q;
import E0.s;
import a.AbstractC0068a;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Map;

/* loaded from: classes.dex */
public final class c implements InvocationHandler {

    /* renamed from: a, reason: collision with root package name */
    public final E0.e f940a;

    /* renamed from: b, reason: collision with root package name */
    public final W.b f941b;

    public c(E0.e eVar, W.b bVar) {
        this.f940a = eVar;
        this.f941b = bVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.reflect.InvocationHandler
    public final Object invoke(Object obj, Method method, Object[] objArr) {
        boolean isInstance;
        String b2;
        E0.i.e(obj, "obj");
        E0.i.e(method, "method");
        boolean a2 = E0.i.a(method.getName(), "accept");
        W.b bVar = this.f941b;
        r2 = null;
        r2 = null;
        r2 = null;
        String str = null;
        if (!a2 || objArr == null || objArr.length != 1) {
            if ((E0.i.a(method.getName(), "equals") && method.getReturnType().equals(Boolean.TYPE) && objArr != null && objArr.length == 1) == true) {
                return Boolean.valueOf(obj == (objArr != null ? objArr[0] : null));
            }
            if ((E0.i.a(method.getName(), "hashCode") && method.getReturnType().equals(Integer.TYPE) && objArr == null) == true) {
                return Integer.valueOf(bVar.hashCode());
            }
            if (E0.i.a(method.getName(), "toString") && method.getReturnType().equals(String.class) && objArr == null) {
                r3 = true;
            }
            if (r3) {
                return bVar.toString();
            }
            throw new UnsupportedOperationException("Unexpected method call object:" + obj + ", method: " + method + ", args: " + objArr);
        }
        Object obj2 = objArr[0];
        Class cls = this.f940a.f291a;
        E0.i.e(cls, "jClass");
        Map map = E0.e.f290b;
        E0.i.c(map, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
        Integer num = (Integer) map.get(cls);
        if (num != null) {
            isInstance = s.c(num.intValue(), obj2);
        } else {
            isInstance = (cls.isPrimitive() ? AbstractC0068a.t(q.a(cls)) : cls).isInstance(obj2);
        }
        if (isInstance) {
            E0.i.c(obj2, "null cannot be cast to non-null type T of kotlin.reflect.KClasses.cast");
            bVar.i(obj2);
            return u0.g.f2964a;
        }
        StringBuilder sb = new StringBuilder("Value cannot be cast to ");
        if (!cls.isAnonymousClass() && !cls.isLocalClass()) {
            if (cls.isArray()) {
                Class<?> componentType = cls.getComponentType();
                if (componentType.isPrimitive() && (b2 = s.b(componentType.getName())) != null) {
                    str = b2.concat("Array");
                }
                if (str == null) {
                    str = "kotlin.Array";
                }
            } else {
                str = s.b(cls.getName());
                if (str == null) {
                    str = cls.getCanonicalName();
                }
            }
        }
        sb.append(str);
        throw new ClassCastException(sb.toString());
    }
}
