package R;

import J0.C0039o;
import a.AbstractC0068a;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collection;
import m0.AbstractC0230j;
import v0.l;

/* loaded from: classes.dex */
public final class f extends AbstractC0068a {

    /* renamed from: i, reason: collision with root package name */
    public final Object f945i;

    /* renamed from: j, reason: collision with root package name */
    public final String f946j;

    /* renamed from: k, reason: collision with root package name */
    public final int f947k;

    /* renamed from: l, reason: collision with root package name */
    public final i f948l;

    public f(Object obj, String str, a aVar, int i2) {
        Collection collection;
        E0.i.e(obj, "value");
        E0.h.i("verificationMode", i2);
        this.f945i = obj;
        this.f946j = str;
        this.f947k = i2;
        String n2 = AbstractC0068a.n(obj, str);
        E0.i.e(n2, "message");
        i iVar = new i(n2);
        StackTraceElement[] stackTrace = iVar.getStackTrace();
        E0.i.d(stackTrace, "stackTrace");
        int length = stackTrace.length - 2;
        length = length < 0 ? 0 : length;
        if (length < 0) {
            throw new IllegalArgumentException(("Requested element count " + length + " is less than zero.").toString());
        }
        if (length != 0) {
            int length2 = stackTrace.length;
            if (length >= length2) {
                int length3 = stackTrace.length;
                if (length3 != 0) {
                    collection = length3 != 1 ? new ArrayList(new v0.a(stackTrace, false)) : AbstractC0230j.r(stackTrace[0]);
                }
            } else if (length == 1) {
                collection = AbstractC0230j.r(stackTrace[length2 - 1]);
            } else {
                ArrayList arrayList = new ArrayList(length);
                for (int i3 = length2 - length; i3 < length2; i3++) {
                    arrayList.add(stackTrace[i3]);
                }
                collection = arrayList;
            }
            iVar.setStackTrace((StackTraceElement[]) collection.toArray(new StackTraceElement[0]));
            this.f948l = iVar;
        }
        collection = l.f2972e;
        iVar.setStackTrace((StackTraceElement[]) collection.toArray(new StackTraceElement[0]));
        this.f948l = iVar;
    }

    @Override // a.AbstractC0068a
    public final Object j() {
        int a2 = F.i.a(this.f947k);
        if (a2 == 0) {
            throw this.f948l;
        }
        if (a2 != 1) {
            if (a2 == 2) {
                return null;
            }
            throw new C0039o();
        }
        String n2 = AbstractC0068a.n(this.f945i, this.f946j);
        E0.i.e(n2, "message");
        Log.d("g", n2);
        return null;
    }

    @Override // a.AbstractC0068a
    public final AbstractC0068a E(String str, D0.l lVar) {
        return this;
    }
}
