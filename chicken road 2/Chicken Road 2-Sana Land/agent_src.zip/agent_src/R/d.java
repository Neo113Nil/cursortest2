package R;

import java.lang.reflect.Method;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Method f942a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f943b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f944c;

    public d(Method method, Object obj, Object obj2) {
        this.f942a = method;
        this.f943b = obj;
        this.f944c = obj2;
    }
}
