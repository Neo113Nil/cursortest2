package R;

import java.math.BigInteger;

/* loaded from: classes.dex */
public final class h implements Comparable {

    /* renamed from: j, reason: collision with root package name */
    public static final h f952j;

    /* renamed from: e, reason: collision with root package name */
    public final int f953e;

    /* renamed from: f, reason: collision with root package name */
    public final int f954f;

    /* renamed from: g, reason: collision with root package name */
    public final int f955g;

    /* renamed from: h, reason: collision with root package name */
    public final String f956h;

    /* renamed from: i, reason: collision with root package name */
    public final u0.e f957i = new u0.e(new Q.a(1, this));

    static {
        new h(0, 0, 0, "");
        f952j = new h(0, 1, 0, "");
        new h(1, 0, 0, "");
    }

    public h(int i2, int i3, int i4, String str) {
        this.f953e = i2;
        this.f954f = i3;
        this.f955g = i4;
        this.f956h = str;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        h hVar = (h) obj;
        E0.i.e(hVar, "other");
        Object a2 = this.f957i.a();
        E0.i.d(a2, "<get-bigInteger>(...)");
        Object a3 = hVar.f957i.a();
        E0.i.d(a3, "<get-bigInteger>(...)");
        return ((BigInteger) a2).compareTo((BigInteger) a3);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        return this.f953e == hVar.f953e && this.f954f == hVar.f954f && this.f955g == hVar.f955g;
    }

    public final int hashCode() {
        return ((((527 + this.f953e) * 31) + this.f954f) * 31) + this.f955g;
    }

    public final String toString() {
        String str;
        String str2 = this.f956h;
        if (I0.h.Q(str2)) {
            str = "";
        } else {
            str = "-" + str2;
        }
        return this.f953e + '.' + this.f954f + '.' + this.f955g + str;
    }
}
