package R;

import D0.l;
import a.AbstractC0068a;

/* loaded from: classes.dex */
public final class g extends AbstractC0068a {

    /* renamed from: i, reason: collision with root package name */
    public final Object f949i;

    /* renamed from: j, reason: collision with root package name */
    public final int f950j;

    /* renamed from: k, reason: collision with root package name */
    public final a f951k;

    public g(Object obj, int i2, a aVar) {
        E0.i.e(obj, "value");
        E0.h.i("verificationMode", i2);
        this.f949i = obj;
        this.f950j = i2;
        this.f951k = aVar;
    }

    @Override // a.AbstractC0068a
    public final AbstractC0068a E(String str, l lVar) {
        Object obj = this.f949i;
        return ((Boolean) lVar.i(obj)).booleanValue() ? this : new f(obj, str, this.f951k, this.f950j);
    }

    @Override // a.AbstractC0068a
    public final Object j() {
        return this.f949i;
    }
}
