package R;

import android.graphics.Rect;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final int f936a;

    /* renamed from: b, reason: collision with root package name */
    public final int f937b;

    /* renamed from: c, reason: collision with root package name */
    public final int f938c;

    /* renamed from: d, reason: collision with root package name */
    public final int f939d;

    public b(Rect rect) {
        int i2 = rect.left;
        int i3 = rect.top;
        int i4 = rect.right;
        int i5 = rect.bottom;
        this.f936a = i2;
        this.f937b = i3;
        this.f938c = i4;
        this.f939d = i5;
        if (i2 > i4) {
            throw new IllegalArgumentException(E0.h.f("Left must be less than or equal to right, left: ", i2, ", right: ", i4).toString());
        }
        if (i3 > i5) {
            throw new IllegalArgumentException(E0.h.f("top must be less than or equal to bottom, top: ", i3, ", bottom: ", i5).toString());
        }
    }

    public final Rect a() {
        return new Rect(this.f936a, this.f937b, this.f938c, this.f939d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!b.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        E0.i.c(obj, "null cannot be cast to non-null type androidx.window.core.Bounds");
        b bVar = (b) obj;
        return this.f936a == bVar.f936a && this.f937b == bVar.f937b && this.f938c == bVar.f938c && this.f939d == bVar.f939d;
    }

    public final int hashCode() {
        return (((((this.f936a * 31) + this.f937b) * 31) + this.f938c) * 31) + this.f939d;
    }

    public final String toString() {
        return b.class.getSimpleName() + " { [" + this.f936a + ',' + this.f937b + ',' + this.f938c + ',' + this.f939d + "] }";
    }
}
