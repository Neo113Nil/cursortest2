package H;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final long f343a;

    /* renamed from: b, reason: collision with root package name */
    public final long f344b;

    public e(long j2, long j3) {
        if (j3 == 0) {
            this.f343a = 0L;
            this.f344b = 1L;
        } else {
            this.f343a = j2;
            this.f344b = j3;
        }
    }

    public final String toString() {
        return this.f343a + "/" + this.f344b;
    }
}
