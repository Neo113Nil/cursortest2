package H;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final int f339a;

    /* renamed from: b, reason: collision with root package name */
    public final String f340b;

    /* renamed from: c, reason: collision with root package name */
    public final int f341c;

    /* renamed from: d, reason: collision with root package name */
    public final int f342d;

    public d(String str, int i2, int i3) {
        this.f340b = str;
        this.f339a = i2;
        this.f341c = i3;
        this.f342d = -1;
    }

    public d(int i2, int i3, int i4, String str) {
        this.f340b = str;
        this.f339a = i2;
        this.f341c = i3;
        this.f342d = i4;
    }
}
