package c0;

import android.view.KeyCharacterMap;

/* renamed from: c0.A, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0097A {

    /* renamed from: a, reason: collision with root package name */
    public int f1633a = 0;

    public final Character a(int i2) {
        char c2 = (char) i2;
        if ((Integer.MIN_VALUE & i2) != 0) {
            int i3 = i2 & Integer.MAX_VALUE;
            int i4 = this.f1633a;
            if (i4 != 0) {
                this.f1633a = KeyCharacterMap.getDeadChar(i4, i3);
            } else {
                this.f1633a = i3;
            }
        } else {
            int i5 = this.f1633a;
            if (i5 != 0) {
                int deadChar = KeyCharacterMap.getDeadChar(i5, i2);
                if (deadChar > 0) {
                    c2 = (char) deadChar;
                }
                this.f1633a = 0;
            }
        }
        return Character.valueOf(c2);
    }
}
