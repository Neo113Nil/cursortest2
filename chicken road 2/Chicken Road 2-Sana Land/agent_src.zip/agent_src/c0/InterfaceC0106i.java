package c0;

/* renamed from: c0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0106i {
}
