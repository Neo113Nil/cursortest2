package c0;

import android.graphics.SurfaceTexture;
import android.view.Surface;
import android.view.TextureView;

/* renamed from: c0.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class TextureViewSurfaceTextureListenerC0111n implements TextureView.SurfaceTextureListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o f1700a;

    public TextureViewSurfaceTextureListenerC0111n(o oVar) {
        this.f1700a = oVar;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i2, int i3) {
        o oVar = this.f1700a;
        oVar.f1701e = true;
        if (oVar.f1703g == null || oVar.f1702f) {
            return;
        }
        oVar.e();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        o oVar = this.f1700a;
        oVar.f1701e = false;
        io.flutter.embedding.engine.renderer.h hVar = oVar.f1703g;
        if (hVar != null && !oVar.f1702f) {
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            Surface surface = oVar.f1704h;
            if (surface != null) {
                surface.release();
                oVar.f1704h = null;
            }
        }
        Surface surface2 = oVar.f1704h;
        if (surface2 == null) {
            return true;
        }
        surface2.release();
        oVar.f1704h = null;
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i2, int i3) {
        o oVar = this.f1700a;
        io.flutter.embedding.engine.renderer.h hVar = oVar.f1703g;
        if (hVar == null || oVar.f1702f) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2346a.onSurfaceChanged(i2, i3);
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
    }
}
