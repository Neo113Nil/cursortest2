package c0;

import D.C0016q;
import J0.AbstractC0025a;
import J0.AbstractC0044u;
import J0.EnumC0043t;
import J0.P;
import J0.b0;
import L.C0051b;
import L.C0063n;
import L.Q;
import a.AbstractC0068a;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.LocaleList;
import android.os.Looper;
import android.provider.Settings;
import android.text.Selection;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.DisplayCutout;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewStructure;
import android.view.Window;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textservice.SpellCheckerInfo;
import android.view.textservice.SpellCheckerSession;
import android.view.textservice.TextServicesManager;
import android.widget.FrameLayout;
import d0.C0115c;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import l0.C0206d;
import l0.C0215m;
import l0.C0216n;
import l0.C0217o;
import l0.C0218p;
import l0.C0219q;
import m0.AbstractC0230j;
import m0.InterfaceC0226f;
import n0.C0240b;
import o0.InterfaceC0242a;
import s.ExecutorC0253a;

/* loaded from: classes.dex */
public final class s extends FrameLayout implements InterfaceC0242a, E {

    /* renamed from: A, reason: collision with root package name */
    public final B.a f1710A;

    /* renamed from: B, reason: collision with root package name */
    public final q f1711B;

    /* renamed from: C, reason: collision with root package name */
    public final C0104g f1712C;

    /* renamed from: D, reason: collision with root package name */
    public U.i f1713D;

    /* renamed from: E, reason: collision with root package name */
    public int f1714E;

    /* renamed from: F, reason: collision with root package name */
    public int f1715F;

    /* renamed from: G, reason: collision with root package name */
    public u f1716G;

    /* renamed from: e, reason: collision with root package name */
    public final AtomicBoolean f1717e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1718f;

    /* renamed from: g, reason: collision with root package name */
    public final C0110m f1719g;

    /* renamed from: h, reason: collision with root package name */
    public final o f1720h;

    /* renamed from: i, reason: collision with root package name */
    public C0108k f1721i;

    /* renamed from: j, reason: collision with root package name */
    public View f1722j;

    /* renamed from: k, reason: collision with root package name */
    public View f1723k;

    /* renamed from: l, reason: collision with root package name */
    public final HashSet f1724l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1725m;

    /* renamed from: n, reason: collision with root package name */
    public C0115c f1726n;

    /* renamed from: o, reason: collision with root package name */
    public final HashSet f1727o;

    /* renamed from: p, reason: collision with root package name */
    public Q f1728p;

    /* renamed from: q, reason: collision with root package name */
    public io.flutter.plugin.editing.l f1729q;
    public io.flutter.plugin.editing.h r;

    /* renamed from: s, reason: collision with root package name */
    public C0240b f1730s;

    /* renamed from: t, reason: collision with root package name */
    public C0051b f1731t;

    /* renamed from: u, reason: collision with root package name */
    public C0099b f1732u;

    /* renamed from: v, reason: collision with root package name */
    public io.flutter.view.i f1733v;

    /* renamed from: w, reason: collision with root package name */
    public TextServicesManager f1734w;

    /* renamed from: x, reason: collision with root package name */
    public A.j f1735x;

    /* renamed from: y, reason: collision with root package name */
    public final io.flutter.embedding.engine.renderer.g f1736y;

    /* renamed from: z, reason: collision with root package name */
    public final A.j f1737z;

    public s(AbstractActivityC0103f abstractActivityC0103f, C0110m c0110m) {
        super(abstractActivityC0103f, null);
        this.f1717e = new AtomicBoolean(true);
        this.f1718f = false;
        this.f1724l = new HashSet();
        this.f1727o = new HashSet();
        this.f1736y = new io.flutter.embedding.engine.renderer.g();
        this.f1737z = new A.j(14, this);
        this.f1710A = new B.a(this, new Handler(Looper.getMainLooper()), 1);
        this.f1711B = new q(this);
        this.f1712C = new C0104g(1, this);
        this.f1716G = new u();
        this.f1719g = c0110m;
        this.f1722j = c0110m;
        b();
    }

    /* JADX WARN: Type inference failed for: r0v38, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final void a() {
        Objects.toString(this.f1726n);
        if (c()) {
            Iterator it = this.f1727o.iterator();
            if (it.hasNext()) {
                it.next().getClass();
                throw new ClassCastException();
            }
            getContext().getContentResolver().unregisterContentObserver(this.f1710A);
            io.flutter.plugin.platform.k kVar = this.f1726n.f1777s;
            SparseArray sparseArray = kVar.f2447o;
            SparseArray sparseArray2 = kVar.f2448p;
            SparseArray sparseArray3 = kVar.r;
            for (int i2 = 0; i2 < sparseArray3.size(); i2++) {
                kVar.f2439g.removeView((io.flutter.plugin.platform.g) sparseArray3.valueAt(i2));
            }
            for (int i3 = 0; i3 < sparseArray2.size(); i3++) {
                if (sparseArray2.valueAt(i3) != null) {
                    throw new ClassCastException();
                }
                kVar.f2439g.removeView(null);
            }
            kVar.c();
            SparseArray sparseArray4 = kVar.f2449q;
            if (kVar.f2439g == null) {
                Log.e("PlatformViewsController", "removeOverlaySurfaces called while flutter view is null");
            } else {
                for (int i4 = 0; i4 < sparseArray4.size(); i4++) {
                    kVar.f2439g.removeView((View) sparseArray4.valueAt(i4));
                }
                sparseArray4.clear();
            }
            kVar.f2439g = null;
            kVar.f2451t = false;
            if (sparseArray.size() > 0) {
                sparseArray.valueAt(0).getClass();
                throw new ClassCastException();
            }
            io.flutter.plugin.platform.j jVar = this.f1726n.f1778t;
            SparseArray sparseArray5 = jVar.f2430k;
            SparseArray sparseArray6 = jVar.f2431l;
            for (int i5 = 0; i5 < sparseArray6.size(); i5++) {
                if (sparseArray6.valueAt(i5) != null) {
                    throw new ClassCastException();
                }
                jVar.f2426g.removeView(null);
            }
            Surface surface = jVar.f2434o;
            if (surface != null) {
                surface.release();
                jVar.f2434o = null;
                jVar.f2435p = null;
            }
            jVar.f2426g = null;
            if (sparseArray5.size() > 0) {
                sparseArray5.valueAt(0).getClass();
                throw new ClassCastException();
            }
            this.f1726n.f1777s.j();
            this.f1726n.f1778t.j();
            io.flutter.view.i iVar = this.f1733v;
            iVar.f2572t = true;
            iVar.f2558e.j();
            iVar.r = null;
            AccessibilityManager accessibilityManager = iVar.f2556c;
            accessibilityManager.removeAccessibilityStateChangeListener(iVar.f2573u);
            accessibilityManager.removeTouchExplorationStateChangeListener(iVar.f2574v);
            iVar.f2559f.unregisterContentObserver(iVar.f2575w);
            C0051b c0051b = iVar.f2555b;
            c0051b.f585h = null;
            ((FlutterJNI) c0051b.f583f).setAccessibilityDelegate(null);
            this.f1733v = null;
            this.f1729q.f2398b.restartInput(this);
            this.f1729q.b();
            int size = ((HashSet) this.f1731t.f583f).size();
            if (size > 0) {
                Log.w("KeyboardManager", "A KeyboardManager was destroyed with " + size + " unhandled redispatch event(s).");
            }
            io.flutter.plugin.editing.h hVar = this.r;
            if (hVar != null) {
                hVar.f2381a.f2662f = null;
                SpellCheckerSession spellCheckerSession = hVar.f2383c;
                if (spellCheckerSession != null) {
                    spellCheckerSession.close();
                }
            }
            Q q2 = this.f1728p;
            if (q2 != null) {
                ((C0206d) q2.f579g).f2662f = null;
            }
            io.flutter.embedding.engine.renderer.h hVar2 = this.f1726n.f1761b;
            this.f1725m = false;
            hVar2.c(this.f1712C);
            FlutterJNI flutterJNI = hVar2.f2346a;
            if (this.f1718f) {
                flutterJNI.removeResizingFlutterUiListener(this.f1711B);
            }
            hVar2.e();
            flutterJNI.setSemanticsEnabled(false);
            View view = this.f1723k;
            if (view != null && this.f1722j == this.f1721i) {
                this.f1722j = view;
            }
            this.f1722j.a();
            C0108k c0108k = this.f1721i;
            if (c0108k != null) {
                c0108k.f1687e.close();
                removeView(this.f1721i);
                this.f1721i = null;
            }
            this.f1723k = null;
            this.f1726n = null;
        }
    }

    @Override // android.view.View
    public final void autofill(SparseArray sparseArray) {
        C0016q c0016q;
        C0016q c0016q2;
        CharSequence textValue;
        io.flutter.plugin.editing.l lVar = this.f1729q;
        if (Build.VERSION.SDK_INT < 26) {
            lVar.getClass();
            return;
        }
        C0217o c0217o = lVar.f2402f;
        if (c0217o == null || lVar.f2403g == null || (c0016q = c0217o.f2718j) == null) {
            return;
        }
        HashMap hashMap = new HashMap();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            C0217o c0217o2 = (C0217o) lVar.f2403g.get(sparseArray.keyAt(i2));
            if (c0217o2 != null && (c0016q2 = c0217o2.f2718j) != null) {
                String str = (String) c0016q2.f246a;
                textValue = AbstractC0098a.g(sparseArray.valueAt(i2)).getTextValue();
                String charSequence = textValue.toString();
                C0219q c0219q = new C0219q(charSequence, charSequence.length(), charSequence.length(), -1, -1);
                if (str.equals((String) c0016q.f246a)) {
                    lVar.f2404h.f(c0219q);
                } else {
                    hashMap.put(str, c0219q);
                }
            }
        }
        Q q2 = lVar.f2400d;
        int i3 = lVar.f2401e.f642c;
        q2.getClass();
        hashMap.size();
        HashMap hashMap2 = new HashMap();
        for (Map.Entry entry : hashMap.entrySet()) {
            C0219q c0219q2 = (C0219q) entry.getValue();
            hashMap2.put((String) entry.getKey(), Q.x(c0219q2.f2725a, c0219q2.f2726b, c0219q2.f2727c, -1, -1));
        }
        ((C0051b) q2.f578f).B("TextInputClient.updateEditingStateWithTag", Arrays.asList(Integer.valueOf(i3), hashMap2), null);
    }

    public final void b() {
        C0110m c0110m = this.f1719g;
        if (c0110m != null) {
            addView(c0110m);
        } else {
            o oVar = this.f1720h;
            if (oVar != null) {
                addView(oVar);
            } else {
                addView(this.f1721i);
            }
        }
        this.f1718f = AbstractC0068a.w(getContext());
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) {
            setImportantForAutofill(1);
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final boolean c() {
        C0115c c0115c = this.f1726n;
        return c0115c != null && c0115c.f1761b == this.f1722j.getAttachedRenderer();
    }

    @Override // android.view.View
    public final boolean checkInputConnectionProxy(View view) {
        C0115c c0115c = this.f1726n;
        if (c0115c == null) {
            return super.checkInputConnectionProxy(view);
        }
        HashMap hashMap = c0115c.f1777s.f2446n;
        if (view == null || !hashMap.containsKey(view.getContext())) {
            return false;
        }
        View view2 = (View) hashMap.get(view.getContext());
        if (view2 == view) {
            return true;
        }
        return view2.checkInputConnectionProxy(view);
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x004a, code lost:
    
        if (r1 != false) goto L20;
     */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d() {
        boolean z2;
        C0016q c0016q;
        HashMap hashMap;
        String str;
        List enabledSpellCheckerInfos;
        boolean z3;
        boolean isSpellCheckerEnabled;
        char c2 = (getResources().getConfiguration().uiMode & 48) == 32 ? (char) 2 : (char) 1;
        TextServicesManager textServicesManager = this.f1734w;
        if (textServicesManager != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                enabledSpellCheckerInfos = textServicesManager.getEnabledSpellCheckerInfos();
                Iterator it = enabledSpellCheckerInfos.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        z3 = false;
                        break;
                    } else if (((SpellCheckerInfo) it.next()).getPackageName().equals("com.google.android.inputmethod.latin")) {
                        z3 = true;
                        break;
                    }
                }
                isSpellCheckerEnabled = this.f1734w.isSpellCheckerEnabled();
                if (isSpellCheckerEnabled) {
                }
            }
            z2 = true;
            C0216n c0216n = this.f1726n.f1774o;
            c0216n.getClass();
            c0016q = c0216n.f2708b;
            hashMap = new HashMap();
            hashMap.put("textScaleFactor", Float.valueOf(getResources().getConfiguration().fontScale));
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            hashMap.put("nativeSpellCheckServiceDefined", Boolean.valueOf(z2));
            hashMap.put("brieflyShowPassword", Boolean.valueOf(Settings.System.getInt(getContext().getContentResolver(), "show_password", 1) == 1));
            hashMap.put("alwaysUse24HourFormat", Boolean.valueOf(DateFormat.is24HourFormat(getContext())));
            if (c2 != 1) {
                str = "light";
            } else {
                if (c2 != 2) {
                    throw null;
                }
                str = "dark";
            }
            hashMap.put("platformBrightness", str);
            Objects.toString(hashMap.get("textScaleFactor"));
            Objects.toString(hashMap.get("alwaysUse24HourFormat"));
            Objects.toString(hashMap.get("platformBrightness"));
            if (Build.VERSION.SDK_INT >= 34 || displayMetrics == null) {
                c0016q.i(hashMap, null);
            }
            C0215m c0215m = new C0215m(displayMetrics);
            C0051b c0051b = c0216n.f2707a;
            ((ConcurrentLinkedQueue) c0051b.f584g).add(c0215m);
            C0215m c0215m2 = (C0215m) c0051b.f585h;
            c0051b.f585h = c0215m;
            Q q2 = c0215m2 != null ? new Q(c0051b, c0215m2, 18, false) : null;
            hashMap.put("configurationId", Integer.valueOf(c0215m.f2705a));
            c0016q.i(hashMap, q2);
            return;
        }
        z2 = false;
        C0216n c0216n2 = this.f1726n.f1774o;
        c0216n2.getClass();
        c0016q = c0216n2.f2708b;
        hashMap = new HashMap();
        hashMap.put("textScaleFactor", Float.valueOf(getResources().getConfiguration().fontScale));
        DisplayMetrics displayMetrics2 = getResources().getDisplayMetrics();
        hashMap.put("nativeSpellCheckServiceDefined", Boolean.valueOf(z2));
        hashMap.put("brieflyShowPassword", Boolean.valueOf(Settings.System.getInt(getContext().getContentResolver(), "show_password", 1) == 1));
        hashMap.put("alwaysUse24HourFormat", Boolean.valueOf(DateFormat.is24HourFormat(getContext())));
        if (c2 != 1) {
        }
        hashMap.put("platformBrightness", str);
        Objects.toString(hashMap.get("textScaleFactor"));
        Objects.toString(hashMap.get("alwaysUse24HourFormat"));
        Objects.toString(hashMap.get("platformBrightness"));
        if (Build.VERSION.SDK_INT >= 34) {
        }
        c0016q.i(hashMap, null);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            getKeyDispatcherState().startTracking(keyEvent, this);
        } else if (keyEvent.getAction() == 1) {
            getKeyDispatcherState().handleUpEvent(keyEvent);
        }
        return (c() && this.f1731t.z(keyEvent)) || super.dispatchKeyEvent(keyEvent);
    }

    public final void e() {
        if (!c()) {
            Log.w("FlutterView", "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine.");
            return;
        }
        float f2 = getResources().getDisplayMetrics().density;
        io.flutter.embedding.engine.renderer.g gVar = this.f1736y;
        gVar.f2325a = f2;
        gVar.f2343t = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        io.flutter.embedding.engine.renderer.h hVar = this.f1726n.f1761b;
        hVar.getClass();
        int i2 = gVar.f2326b;
        ArrayList arrayList = gVar.f2345v;
        ArrayList arrayList2 = gVar.f2344u;
        if (i2 == 0) {
            int i3 = gVar.f2328d;
            int i4 = gVar.f2329e;
            if (i3 <= 0 && i4 <= 0) {
                return;
            }
        } else {
            int i5 = gVar.f2327c;
            if (i5 == 0) {
                int i6 = gVar.f2330f;
                int i7 = gVar.f2331g;
                if (i6 <= 0 && i7 <= 0) {
                    return;
                }
            } else if (i2 <= 0 || i5 <= 0 || gVar.f2325a <= 0.0f) {
                return;
            }
        }
        arrayList2.size();
        arrayList.size();
        int size = arrayList.size() + arrayList2.size();
        int[] iArr = new int[size * 4];
        int[] iArr2 = new int[size];
        int[] iArr3 = new int[size];
        for (int i8 = 0; i8 < arrayList2.size(); i8++) {
            io.flutter.embedding.engine.renderer.a aVar = (io.flutter.embedding.engine.renderer.a) arrayList2.get(i8);
            int i9 = i8 * 4;
            Rect rect = aVar.f2312a;
            iArr[i9] = rect.left;
            iArr[i9 + 1] = rect.top;
            iArr[i9 + 2] = rect.right;
            iArr[i9 + 3] = rect.bottom;
            iArr2[i8] = F.i.a(aVar.f2313b);
            iArr3[i8] = F.i.a(aVar.f2314c);
        }
        int size2 = arrayList2.size() * 4;
        for (int i10 = 0; i10 < arrayList.size(); i10++) {
            io.flutter.embedding.engine.renderer.a aVar2 = (io.flutter.embedding.engine.renderer.a) arrayList.get(i10);
            int i11 = (i10 * 4) + size2;
            Rect rect2 = aVar2.f2312a;
            iArr[i11] = rect2.left;
            iArr[i11 + 1] = rect2.top;
            iArr[i11 + 2] = rect2.right;
            iArr[i11 + 3] = rect2.bottom;
            iArr2[arrayList2.size() + i10] = F.i.a(aVar2.f2313b);
            iArr3[arrayList2.size() + i10] = F.i.a(aVar2.f2314c);
        }
        hVar.f2346a.setViewportMetrics(gVar.f2325a, gVar.f2326b, gVar.f2327c, gVar.f2332h, gVar.f2333i, gVar.f2334j, gVar.f2335k, gVar.f2336l, gVar.f2337m, gVar.f2338n, gVar.f2339o, gVar.f2340p, gVar.f2341q, gVar.r, gVar.f2342s, gVar.f2343t, iArr, iArr2, iArr3, gVar.f2328d, gVar.f2329e, gVar.f2330f, gVar.f2331g);
    }

    @Override // android.view.View
    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        io.flutter.view.i iVar = this.f1733v;
        if (iVar == null || !iVar.f2556c.isEnabled()) {
            return null;
        }
        return this.f1733v;
    }

    public C0115c getAttachedFlutterEngine() {
        return this.f1726n;
    }

    public InterfaceC0226f getBinaryMessenger() {
        return this.f1726n.f1762c;
    }

    public C0108k getCurrentImageSurface() {
        return this.f1721i;
    }

    public io.flutter.embedding.engine.renderer.g getViewportMetrics() {
        return this.f1736y;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x01b5, code lost:
    
        r1 = r18.getDisplayCutout();
     */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x017e A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01a1  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x01a3  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0174  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x013d  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        char c2;
        double d2;
        int i2;
        int captionBar;
        List boundingRects;
        Window window;
        DisplayCutout displayCutout;
        List<Rect> boundingRects2;
        int systemBars;
        Insets insets;
        int i3;
        int i4;
        int i5;
        int i6;
        int ime;
        Insets insets2;
        int i7;
        int i8;
        int i9;
        int i10;
        int systemGestures;
        Insets insets3;
        int i11;
        int i12;
        int i13;
        int i14;
        DisplayCutout displayCutout2;
        Insets waterfallInsets;
        int i15;
        int safeInsetTop;
        int i16;
        int safeInsetRight;
        int i17;
        int safeInsetBottom;
        int i18;
        int safeInsetLeft;
        Insets systemGestureInsets;
        int i19;
        int i20;
        int i21;
        int i22;
        WindowInsets onApplyWindowInsets = super.onApplyWindowInsets(windowInsets);
        int i23 = Build.VERSION.SDK_INT;
        io.flutter.embedding.engine.renderer.g gVar = this.f1736y;
        if (i23 == 29) {
            systemGestureInsets = windowInsets.getSystemGestureInsets();
            i19 = systemGestureInsets.top;
            gVar.f2340p = i19;
            i20 = systemGestureInsets.right;
            gVar.f2341q = i20;
            i21 = systemGestureInsets.bottom;
            gVar.r = i21;
            i22 = systemGestureInsets.left;
            gVar.f2342s = i22;
        }
        boolean z2 = (getWindowSystemUiVisibility() & 4) == 0;
        boolean z3 = (getWindowSystemUiVisibility() & 2) == 0;
        if (i23 >= 30) {
            systemBars = WindowInsets.Type.systemBars();
            insets = windowInsets.getInsets(systemBars);
            i3 = insets.top;
            gVar.f2332h = i3;
            i4 = insets.right;
            gVar.f2333i = i4;
            i5 = insets.bottom;
            gVar.f2334j = i5;
            i6 = insets.left;
            gVar.f2335k = i6;
            ime = WindowInsets.Type.ime();
            insets2 = windowInsets.getInsets(ime);
            i7 = insets2.top;
            gVar.f2336l = i7;
            i8 = insets2.right;
            gVar.f2337m = i8;
            i9 = insets2.bottom;
            gVar.f2338n = i9;
            i10 = insets2.left;
            gVar.f2339o = i10;
            systemGestures = WindowInsets.Type.systemGestures();
            insets3 = windowInsets.getInsets(systemGestures);
            i11 = insets3.top;
            gVar.f2340p = i11;
            i12 = insets3.right;
            gVar.f2341q = i12;
            i13 = insets3.bottom;
            gVar.r = i13;
            i14 = insets3.left;
            gVar.f2342s = i14;
            displayCutout2 = windowInsets.getDisplayCutout();
            if (displayCutout2 != null) {
                waterfallInsets = displayCutout2.getWaterfallInsets();
                int i24 = gVar.f2332h;
                i15 = waterfallInsets.top;
                int max = Math.max(i24, i15);
                safeInsetTop = displayCutout2.getSafeInsetTop();
                gVar.f2332h = Math.max(max, safeInsetTop);
                int i25 = gVar.f2333i;
                i16 = waterfallInsets.right;
                int max2 = Math.max(i25, i16);
                safeInsetRight = displayCutout2.getSafeInsetRight();
                gVar.f2333i = Math.max(max2, safeInsetRight);
                int i26 = gVar.f2334j;
                i17 = waterfallInsets.bottom;
                int max3 = Math.max(i26, i17);
                safeInsetBottom = displayCutout2.getSafeInsetBottom();
                gVar.f2334j = Math.max(max3, safeInsetBottom);
                int i27 = gVar.f2335k;
                i18 = waterfallInsets.left;
                int max4 = Math.max(i27, i18);
                safeInsetLeft = displayCutout2.getSafeInsetLeft();
                gVar.f2335k = Math.max(max4, safeInsetLeft);
            }
        } else {
            if (!z3) {
                Context context = getContext();
                if (context.getResources().getConfiguration().orientation == 2) {
                    int rotation = ((DisplayManager) context.getSystemService("display")).getDisplay(0).getRotation();
                    if (rotation == 1) {
                        c2 = 3;
                    } else if (rotation == 3) {
                        c2 = 2;
                    } else if (rotation == 0 || rotation == 2) {
                        c2 = 4;
                    }
                    gVar.f2332h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
                    gVar.f2333i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
                    if (z3) {
                        d2 = 0.18d;
                    } else {
                        d2 = 0.18d;
                        if ((((double) windowInsets.getSystemWindowInsetBottom()) < ((double) getRootView().getHeight()) * 0.18d ? 0 : windowInsets.getSystemWindowInsetBottom()) == 0) {
                            i2 = windowInsets.getSystemWindowInsetBottom();
                            gVar.f2334j = i2;
                            gVar.f2335k = (c2 != 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
                            gVar.f2336l = 0;
                            gVar.f2337m = 0;
                            gVar.f2338n = ((double) windowInsets.getSystemWindowInsetBottom()) < ((double) getRootView().getHeight()) * d2 ? 0 : windowInsets.getSystemWindowInsetBottom();
                            gVar.f2339o = 0;
                        }
                    }
                    i2 = 0;
                    gVar.f2334j = i2;
                    gVar.f2335k = (c2 != 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
                    gVar.f2336l = 0;
                    gVar.f2337m = 0;
                    gVar.f2338n = ((double) windowInsets.getSystemWindowInsetBottom()) < ((double) getRootView().getHeight()) * d2 ? 0 : windowInsets.getSystemWindowInsetBottom();
                    gVar.f2339o = 0;
                }
            }
            c2 = 1;
            gVar.f2332h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
            gVar.f2333i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
            if (z3) {
            }
            i2 = 0;
            gVar.f2334j = i2;
            gVar.f2335k = (c2 != 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
            gVar.f2336l = 0;
            gVar.f2337m = 0;
            gVar.f2338n = ((double) windowInsets.getSystemWindowInsetBottom()) < ((double) getRootView().getHeight()) * d2 ? 0 : windowInsets.getSystemWindowInsetBottom();
            gVar.f2339o = 0;
        }
        ArrayList arrayList = new ArrayList();
        if (i23 >= 28 && displayCutout != null) {
            boundingRects2 = displayCutout.getBoundingRects();
            for (Rect rect : boundingRects2) {
                rect.toString();
                arrayList.add(new io.flutter.embedding.engine.renderer.a(rect, 4, 1));
            }
        }
        ArrayList arrayList2 = gVar.f2345v;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        if (Build.VERSION.SDK_INT >= 35) {
            u uVar = this.f1716G;
            Context context2 = getContext();
            uVar.getClass();
            Activity n2 = AbstractC0230j.n(context2);
            WindowInsets windowInsets2 = null;
            if (n2 != null && (window = n2.getWindow()) != null) {
                windowInsets2 = window.getDecorView().getRootWindowInsets();
            }
            if (windowInsets2 == null) {
                boundingRects = Collections.EMPTY_LIST;
            } else {
                captionBar = WindowInsets.Type.captionBar();
                boundingRects = windowInsets2.getBoundingRects(captionBar);
            }
            int i28 = gVar.f2332h;
            Iterator it = boundingRects.iterator();
            while (it.hasNext()) {
                i28 = Math.max(i28, ((Rect) it.next()).bottom);
            }
            gVar.f2332h = i28;
        }
        e();
        return onApplyWindowInsets;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v11, types: [M0.d] */
    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        A.j jVar;
        super.onAttachedToWindow();
        try {
            U.g gVar = U.h.f1002c;
            Context context = getContext();
            gVar.getClass();
            jVar = new A.j(15, new Q(U.g.a(context)));
        } catch (NoClassDefFoundError unused) {
            jVar = null;
        }
        this.f1735x = jVar;
        Activity n2 = AbstractC0230j.n(getContext());
        A.j jVar2 = this.f1735x;
        if (jVar2 == null || n2 == null) {
            return;
        }
        this.f1713D = new U.i(1, this);
        Context context2 = getContext();
        Executor a2 = Build.VERSION.SDK_INT >= 28 ? n.b.a(context2) : new ExecutorC0253a(new Handler(context2.getMainLooper()));
        U.i iVar = this.f1713D;
        Q q2 = (Q) jVar2.f30f;
        E0.i.e(a2, "executor");
        E0.i.e(iVar, "consumer");
        Q q3 = (Q) q2.f579g;
        U.b bVar = (U.b) q2.f578f;
        bVar.getClass();
        U.k kVar = new U.k(bVar, n2, null);
        L0.a aVar = L0.a.f668e;
        w0.i iVar2 = w0.i.f3040e;
        M0.c cVar = new M0.c(kVar, iVar2, -2, aVar);
        Q0.e eVar = J0.A.f445a;
        K0.c cVar2 = O0.o.f865a;
        if (cVar2.h(J0.r.f506f) != null) {
            throw new IllegalArgumentException(("Flow context cannot contain job in it. Had " + cVar2).toString());
        }
        M0.c cVar3 = cVar;
        if (!cVar2.equals(iVar2)) {
            cVar3 = N0.k.a(cVar, cVar2, 0, null, 6);
        }
        LinkedHashMap linkedHashMap = (LinkedHashMap) q3.f579g;
        ReentrantLock reentrantLock = (ReentrantLock) q3.f578f;
        reentrantLock.lock();
        try {
            if (linkedHashMap.get(iVar) == null) {
                w0.h i2 = new J0.I(a2);
                if (i2.h(J0.r.f506f) == null) {
                    i2 = i2.n(new P());
                }
                S.a aVar2 = new S.a(cVar3, iVar, null);
                EnumC0043t enumC0043t = EnumC0043t.f507e;
                w0.h a3 = AbstractC0044u.a(i2, iVar2, true);
                Q0.e eVar2 = J0.A.f445a;
                if (a3 != eVar2 && a3.h(w0.d.f3039e) == null) {
                    a3 = a3.n(eVar2);
                }
                AbstractC0025a b0Var = new b0(a3, true);
                b0Var.V(enumC0043t, b0Var, aVar2);
                linkedHashMap.put(iVar, b0Var);
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f1726n != null) {
            this.f1730s.b(configuration);
            d();
            AbstractC0230j.b(getContext(), this.f1726n);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:29:0x0057, code lost:
    
        if (r2.f2724c != false) goto L32;
     */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00b3  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        int i2;
        if (!c()) {
            return super.onCreateInputConnection(editorInfo);
        }
        io.flutter.plugin.editing.l lVar = this.f1729q;
        C0051b c0051b = this.f1731t;
        C0063n c0063n = lVar.f2401e;
        int i3 = c0063n.f641b;
        if (i3 == 1) {
            lVar.f2406j = null;
            return null;
        }
        int i4 = 4;
        if (i3 == 4) {
            return null;
        }
        if (i3 == 3) {
            if (lVar.f2412p) {
                return lVar.f2406j;
            }
            lVar.f2407k.g(c0063n.f642c);
            throw null;
        }
        C0217o c0217o = lVar.f2402f;
        C0218p c0218p = c0217o.f2715g;
        boolean z2 = c0217o.f2709a;
        boolean z3 = c0217o.f2710b;
        boolean z4 = c0217o.f2711c;
        boolean z5 = c0217o.f2712d;
        int i5 = c0217o.f2714f;
        int i6 = c0218p.f2722a;
        if (i6 != 2) {
            if (i6 == 5) {
                i4 = c0218p.f2723b ? 4098 : 2;
            } else if (i6 == 6) {
                i4 = 3;
            } else if (i6 == 11) {
                i4 = 0;
            } else {
                int i7 = i6 == 7 ? 131073 : (i6 == 8 || i6 == 13) ? 33 : (i6 == 9 || i6 == 12) ? 17 : i6 == 10 ? 145 : i6 == 3 ? 97 : i6 == 4 ? 113 : 1;
                if (!z2) {
                    if (z3) {
                        i7 |= 32768;
                    }
                    i2 = z4 ? 524416 : 524432;
                    i4 = i7;
                    if (i5 != 1) {
                        i4 |= 4096;
                    } else {
                        if (i5 != 2) {
                            if (i5 == 3) {
                                i4 |= 16384;
                            }
                        }
                        i4 |= 8192;
                    }
                }
                i7 |= i2;
                i4 = i7;
                if (i5 != 1) {
                }
            }
        }
        editorInfo.inputType = i4;
        editorInfo.imeOptions = 33554432;
        int i8 = Build.VERSION.SDK_INT;
        if (i8 >= 26 && !z5) {
            editorInfo.imeOptions = 50331648;
        }
        int intValue = c0217o.f2716h.intValue();
        C0217o c0217o2 = lVar.f2402f;
        String str = c0217o2.f2717i;
        if (str != null) {
            editorInfo.actionLabel = str;
            editorInfo.actionId = intValue;
        }
        editorInfo.imeOptions = intValue | editorInfo.imeOptions;
        if (c0217o2.f2721m != null) {
            editorInfo.hintLocales = new LocaleList(lVar.f2402f.f2721m);
        }
        String[] strArr = lVar.f2402f.f2719k;
        if (strArr != null) {
            editorInfo.contentMimeTypes = strArr;
        }
        if (i8 >= 34) {
            if (editorInfo.extras == null) {
                editorInfo.extras = new Bundle();
            }
            editorInfo.extras.putBoolean("androidx.core.view.inputmethod.EditorInfoCompat.STYLUS_HANDWRITING_ENABLED", true);
        }
        io.flutter.plugin.editing.c cVar = new io.flutter.plugin.editing.c(this, lVar.f2401e.f642c, lVar.f2400d, c0051b, lVar.f2404h, editorInfo);
        io.flutter.plugin.editing.f fVar = lVar.f2404h;
        fVar.getClass();
        editorInfo.initialSelStart = Selection.getSelectionStart(fVar);
        io.flutter.plugin.editing.f fVar2 = lVar.f2404h;
        fVar2.getClass();
        editorInfo.initialSelEnd = Selection.getSelectionEnd(fVar2);
        lVar.f2406j = cVar;
        return cVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        U.i iVar;
        A.j jVar = this.f1735x;
        if (jVar != null && (iVar = this.f1713D) != null) {
            Q q2 = (Q) ((Q) jVar.f30f).f579g;
            LinkedHashMap linkedHashMap = (LinkedHashMap) q2.f579g;
            ReentrantLock reentrantLock = (ReentrantLock) q2.f578f;
            reentrantLock.lock();
            try {
                J0.N n2 = (J0.N) linkedHashMap.get(iVar);
                if (n2 != null) {
                    n2.b(null);
                }
                reentrantLock.unlock();
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
        this.f1713D = null;
        this.f1735x = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (c()) {
            C0099b c0099b = this.f1732u;
            Context context = getContext();
            c0099b.getClass();
            boolean isFromSource = motionEvent.isFromSource(2);
            boolean z2 = motionEvent.getActionMasked() == 7 || motionEvent.getActionMasked() == 8;
            if (isFromSource && z2) {
                int b2 = C0099b.b(motionEvent.getActionMasked());
                ByteBuffer allocateDirect = ByteBuffer.allocateDirect(motionEvent.getPointerCount() * 288);
                allocateDirect.order(ByteOrder.LITTLE_ENDIAN);
                c0099b.a(motionEvent, motionEvent.getActionIndex(), b2, 0, C0099b.f1658f, allocateDirect, context);
                if (allocateDirect.position() % 288 != 0) {
                    throw new AssertionError("Packet position is not on field boundary.");
                }
                c0099b.f1659a.f2346a.dispatchPointerDataPacket(allocateDirect, allocateDirect.position());
                return true;
            }
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        return !c() ? super.onHoverEvent(motionEvent) : this.f1733v.e(motionEvent, false);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        this.f1714E = View.MeasureSpec.getMode(i2);
        this.f1715F = View.MeasureSpec.getMode(i3);
        super.onMeasure(i2, i3);
    }

    @Override // android.view.View
    public final void onProvideAutofillVirtualStructure(ViewStructure viewStructure, int i2) {
        Rect rect;
        super.onProvideAutofillVirtualStructure(viewStructure, i2);
        io.flutter.plugin.editing.l lVar = this.f1729q;
        if (Build.VERSION.SDK_INT < 26) {
            lVar.getClass();
            return;
        }
        if (lVar.f2403g != null) {
            String str = (String) lVar.f2402f.f2718j.f246a;
            AutofillId autofillId = viewStructure.getAutofillId();
            for (int i3 = 0; i3 < lVar.f2403g.size(); i3++) {
                int keyAt = lVar.f2403g.keyAt(i3);
                C0016q c0016q = ((C0217o) lVar.f2403g.valueAt(i3)).f2718j;
                if (c0016q != null) {
                    viewStructure.addChildCount(1);
                    ViewStructure newChild = viewStructure.newChild(i3);
                    newChild.setAutofillId(autofillId, keyAt);
                    String[] strArr = (String[]) c0016q.f247b;
                    if (strArr.length > 0) {
                        newChild.setAutofillHints(strArr);
                    }
                    newChild.setAutofillType(1);
                    newChild.setVisibility(0);
                    String str2 = (String) c0016q.f249d;
                    if (str2 != null) {
                        newChild.setHint(str2);
                    }
                    if (str.hashCode() != keyAt || (rect = lVar.f2409m) == null) {
                        newChild.setDimens(0, 0, 0, 0, 1, 1);
                        newChild.setAutofillValue(AutofillValue.forText(((C0219q) c0016q.f248c).f2725a));
                    } else {
                        newChild.setDimens(rect.left, rect.top, 0, 0, rect.width(), lVar.f2409m.height());
                        newChild.setAutofillValue(AutofillValue.forText(lVar.f2404h));
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        io.flutter.embedding.engine.renderer.g gVar = this.f1736y;
        gVar.f2326b = i2;
        gVar.f2327c = i3;
        boolean z2 = this.f1718f;
        if (z2 && this.f1715F == 0) {
            gVar.f2330f = 0;
            gVar.f2331g = 8192;
        } else {
            gVar.f2330f = i3;
            gVar.f2331g = i3;
        }
        if (z2 && this.f1714E == 0) {
            gVar.f2328d = 0;
            gVar.f2329e = 8192;
        } else {
            gVar.f2328d = i2;
            gVar.f2329e = i2;
        }
        if (this.f1717e.compareAndSet(false, true)) {
            return;
        }
        e();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ByteBuffer byteBuffer;
        if (!c()) {
            return super.onTouchEvent(motionEvent);
        }
        requestUnbufferedDispatch(motionEvent);
        C0099b c0099b = this.f1732u;
        Matrix matrix = C0099b.f1658f;
        c0099b.getClass();
        int actionMasked = motionEvent.getActionMasked();
        int b2 = C0099b.b(motionEvent.getActionMasked());
        char c2 = 5;
        boolean z2 = actionMasked == 0 || actionMasked == 5;
        boolean z3 = !z2 && (actionMasked == 1 || actionMasked == 6);
        int toolType = motionEvent.getToolType(motionEvent.getActionIndex());
        if (toolType == 1) {
            c2 = 0;
        } else if (toolType == 2) {
            c2 = 2;
        } else if (toolType == 3) {
            c2 = 1;
        } else if (toolType == 4) {
            c2 = 3;
        }
        int i2 = (z3 && c2 == 0) ? 1 : 0;
        int pointerCount = motionEvent.getPointerCount();
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect((pointerCount + i2) * 288);
        allocateDirect.order(ByteOrder.LITTLE_ENDIAN);
        if (z2) {
            byteBuffer = allocateDirect;
            c0099b.a(motionEvent, motionEvent.getActionIndex(), b2, 0, matrix, byteBuffer, null);
        } else {
            byteBuffer = allocateDirect;
            if (z3) {
                for (int i3 = 0; i3 < pointerCount; i3++) {
                    if (i3 != motionEvent.getActionIndex() && motionEvent.getToolType(i3) == 1) {
                        c0099b.a(motionEvent, i3, 5, 1, matrix, byteBuffer, null);
                    }
                }
                c0099b.a(motionEvent, motionEvent.getActionIndex(), b2, 0, matrix, byteBuffer, null);
                if (i2 != 0) {
                    c0099b.a(motionEvent, motionEvent.getActionIndex(), 2, 0, matrix, byteBuffer, null);
                }
            } else {
                for (int i4 = 0; i4 < pointerCount; i4++) {
                    c0099b.a(motionEvent, i4, b2, (pointerCount << 8) | 2, matrix, byteBuffer, null);
                }
            }
        }
        if (byteBuffer.position() % 288 != 0) {
            throw new AssertionError("Packet position is not on field boundary");
        }
        c0099b.f1659a.f2346a.dispatchPointerDataPacket(byteBuffer, byteBuffer.position());
        return true;
    }

    public void setDelegate(u uVar) {
        this.f1716G = uVar;
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        View view = this.f1722j;
        if (view instanceof C0110m) {
            ((C0110m) view).setVisibility(i2);
        }
    }

    /* JADX WARN: Type inference failed for: r9v1, types: [java.lang.Object, java.util.List] */
    public void setWindowInfoListenerDisplayFeatures(U.l lVar) {
        U.b bVar = U.b.f983h;
        ?? r9 = lVar.f1011a;
        ArrayList arrayList = new ArrayList();
        for (U.c cVar : r9) {
            cVar.f990a.a().toString();
            R.b bVar2 = cVar.f990a;
            int i2 = 2;
            int i3 = ((bVar2.f938c - bVar2.f936a == 0 || bVar2.f939d - bVar2.f937b == 0) ? U.b.f982g : bVar) == bVar ? 3 : 2;
            U.b bVar3 = cVar.f992c;
            if (bVar3 != U.b.f984i) {
                i2 = bVar3 == U.b.f985j ? 3 : 1;
            }
            arrayList.add(new io.flutter.embedding.engine.renderer.a(bVar2.a(), i3, i2));
        }
        ArrayList arrayList2 = this.f1736y.f2344u;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        e();
    }

    public s(AbstractActivityC0103f abstractActivityC0103f, o oVar) {
        super(abstractActivityC0103f, null);
        this.f1717e = new AtomicBoolean(true);
        this.f1718f = false;
        this.f1724l = new HashSet();
        this.f1727o = new HashSet();
        this.f1736y = new io.flutter.embedding.engine.renderer.g();
        this.f1737z = new A.j(14, this);
        this.f1710A = new B.a(this, new Handler(Looper.getMainLooper()), 1);
        this.f1711B = new q(this);
        this.f1712C = new C0104g(1, this);
        this.f1716G = new u();
        this.f1720h = oVar;
        this.f1722j = oVar;
        b();
    }
}
