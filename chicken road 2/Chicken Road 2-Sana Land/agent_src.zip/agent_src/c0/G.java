package c0;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: a, reason: collision with root package name */
    public final long f1640a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1641b;

    public G(long j2, long j3) {
        this.f1640a = j2;
        this.f1641b = j3;
    }
}
