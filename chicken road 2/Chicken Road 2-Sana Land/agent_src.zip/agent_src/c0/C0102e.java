package c0;

import android.util.Log;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import d0.C0115c;
import l0.C0203a;

/* renamed from: c0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0102e implements OnBackAnimationCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AbstractActivityC0103f f1665a;

    public C0102e(AbstractActivityC0103f abstractActivityC0103f) {
        this.f1665a = abstractActivityC0103f;
    }

    public final void onBackCancelled() {
        AbstractActivityC0103f abstractActivityC0103f = this.f1665a;
        if (abstractActivityC0103f.k("cancelBackGesture")) {
            C0107j c0107j = abstractActivityC0103f.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1769j.f2655a.B("cancelBackGesture", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked cancelBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackInvoked() {
        AbstractActivityC0103f abstractActivityC0103f = this.f1665a;
        if (abstractActivityC0103f.k("commitBackGesture")) {
            C0107j c0107j = abstractActivityC0103f.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1769j.f2655a.B("commitBackGesture", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked commitBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackProgressed(BackEvent backEvent) {
        AbstractActivityC0103f abstractActivityC0103f = this.f1665a;
        if (abstractActivityC0103f.k("updateBackGestureProgress")) {
            C0107j c0107j = abstractActivityC0103f.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1769j.f2655a.B("updateBackGestureProgress", C0203a.a(backEvent), null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked updateBackGestureProgress() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackStarted(BackEvent backEvent) {
        AbstractActivityC0103f abstractActivityC0103f = this.f1665a;
        if (abstractActivityC0103f.k("startBackGesture")) {
            C0107j c0107j = abstractActivityC0103f.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1769j.f2655a.B("startBackGesture", C0203a.a(backEvent), null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked startBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }
}
