package c0;

import android.os.Build;
import android.view.SurfaceHolder;

/* loaded from: classes.dex */
public final class N implements SurfaceHolder.Callback2 {

    /* renamed from: a, reason: collision with root package name */
    public final C0110m f1653a;

    /* renamed from: b, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1654b;

    /* renamed from: c, reason: collision with root package name */
    public final SurfaceHolderCallbackC0109l f1655c;

    /* renamed from: d, reason: collision with root package name */
    public final C0104g f1656d = new C0104g(2, this);

    /* renamed from: e, reason: collision with root package name */
    public final M f1657e;

    public N(SurfaceHolderCallbackC0109l surfaceHolderCallbackC0109l, C0110m c0110m, io.flutter.embedding.engine.renderer.h hVar) {
        boolean z2 = Build.VERSION.SDK_INT < 26;
        this.f1657e = z2 ? new M(this, 1) : new M(this, 0);
        this.f1655c = surfaceHolderCallbackC0109l;
        this.f1654b = hVar;
        this.f1653a = c0110m;
        if (z2) {
            c0110m.setAlpha(0.0f);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        SurfaceHolderCallbackC0109l surfaceHolderCallbackC0109l = this.f1655c;
        if (surfaceHolderCallbackC0109l != null) {
            surfaceHolderCallbackC0109l.surfaceChanged(surfaceHolder, i2, i3, i4);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        SurfaceHolderCallbackC0109l surfaceHolderCallbackC0109l = this.f1655c;
        if (surfaceHolderCallbackC0109l != null) {
            surfaceHolderCallbackC0109l.surfaceCreated(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        SurfaceHolderCallbackC0109l surfaceHolderCallbackC0109l = this.f1655c;
        if (surfaceHolderCallbackC0109l != null) {
            surfaceHolderCallbackC0109l.surfaceDestroyed(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeededAsync(SurfaceHolder surfaceHolder, Runnable runnable) {
        io.flutter.embedding.engine.renderer.h hVar = this.f1654b;
        if (hVar == null) {
            return;
        }
        hVar.a(new L(this, runnable));
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeeded(SurfaceHolder surfaceHolder) {
    }
}
