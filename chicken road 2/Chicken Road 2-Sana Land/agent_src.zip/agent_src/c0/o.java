package c0;

import a.AbstractC0068a;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import io.flutter.embedding.engine.FlutterJNI;

/* loaded from: classes.dex */
public final class o extends TextureView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: e, reason: collision with root package name */
    public boolean f1701e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1702f;

    /* renamed from: g, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1703g;

    /* renamed from: h, reason: collision with root package name */
    public Surface f1704h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f1705i;

    public o(AbstractActivityC0103f abstractActivityC0103f) {
        super(abstractActivityC0103f, null);
        this.f1701e = false;
        this.f1702f = false;
        this.f1705i = false;
        setSurfaceTextureListener(new TextureViewSurfaceTextureListenerC0111n(this));
        this.f1705i = AbstractC0068a.w(getContext());
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1703g == null) {
            Log.w("FlutterTextureView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1703g;
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            Surface surface = this.f1704h;
            if (surface != null) {
                surface.release();
                this.f1704h = null;
            }
        }
        this.f1703g = null;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1703g == null) {
            Log.w("FlutterTextureView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (this.f1701e) {
            e();
        }
        this.f1702f = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1703g;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1703g = hVar;
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1703g == null) {
            Log.w("FlutterTextureView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1702f = true;
        }
    }

    public final void e() {
        if (this.f1703g == null || getSurfaceTexture() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getSurfaceTexture() are non-null.");
        }
        Surface surface = this.f1704h;
        if (surface != null) {
            surface.release();
            this.f1704h = null;
        }
        Surface surface2 = new Surface(getSurfaceTexture());
        this.f1704h = surface2;
        io.flutter.embedding.engine.renderer.h hVar = this.f1703g;
        boolean z2 = this.f1702f;
        FlutterJNI flutterJNI = hVar.f2346a;
        if (!z2) {
            hVar.e();
        }
        hVar.f2347b = surface2;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface2);
        } else {
            flutterJNI.onSurfaceCreated(surface2);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1703g;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1705i) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }

    public void setRenderSurface(Surface surface) {
        this.f1704h = surface;
    }
}
