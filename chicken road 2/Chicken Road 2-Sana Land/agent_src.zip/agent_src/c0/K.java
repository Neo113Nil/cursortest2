package c0;

import java.util.concurrent.atomic.AtomicLong;

/* loaded from: classes.dex */
public final class K {

    /* renamed from: a, reason: collision with root package name */
    public static final AtomicLong f1648a = new AtomicLong(0);
}
