package c0;

/* loaded from: classes.dex */
public final class q implements io.flutter.embedding.engine.renderer.j {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ s f1706a;

    public q(s sVar) {
        this.f1706a = sVar;
    }
}
