package c0;

import android.util.Log;
import android.view.KeyEvent;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import m0.InterfaceC0225e;
import m0.InterfaceC0226f;

/* loaded from: classes.dex */
public final class z implements D {

    /* renamed from: e, reason: collision with root package name */
    public final InterfaceC0226f f1752e;

    /* renamed from: f, reason: collision with root package name */
    public final HashMap f1753f = new HashMap();

    /* renamed from: g, reason: collision with root package name */
    public final HashMap f1754g;

    /* renamed from: h, reason: collision with root package name */
    public final C0097A f1755h;

    public z(InterfaceC0226f interfaceC0226f) {
        HashMap hashMap = new HashMap();
        this.f1754g = hashMap;
        this.f1755h = new C0097A();
        this.f1752e = interfaceC0226f;
        F f2 = J.f1645a;
        I i2 = new I();
        i2.f1644a = false;
        I i3 = new I[]{i2}[0];
        i3.getClass();
        hashMap.put(4294967556L, i3);
    }

    public final void a(w wVar, final B b2) {
        long j2;
        long j3;
        byte[] bArr = null;
        InterfaceC0225e interfaceC0225e = b2 == null ? null : new InterfaceC0225e() { // from class: c0.x
            @Override // m0.InterfaceC0225e
            public final void a(ByteBuffer byteBuffer) {
                Boolean bool = Boolean.FALSE;
                if (byteBuffer != null) {
                    byteBuffer.rewind();
                    if (byteBuffer.capacity() != 0) {
                        bool = Boolean.valueOf(byteBuffer.get() != 0);
                    }
                } else {
                    Log.w("KeyEmbedderResponder", "A null reply was received when sending a key event to the framework.");
                }
                B.this.a(bool.booleanValue());
            }
        };
        try {
            String str = wVar.f1745g;
            if (str != null) {
                bArr = str.getBytes("UTF-8");
            }
            int length = bArr == null ? 0 : bArr.length;
            ByteBuffer allocateDirect = ByteBuffer.allocateDirect(length + 56);
            allocateDirect.order(ByteOrder.LITTLE_ENDIAN);
            allocateDirect.putLong(length);
            allocateDirect.putLong(wVar.f1739a);
            int i2 = wVar.f1740b;
            if (i2 == 1) {
                j2 = 0;
            } else if (i2 == 2) {
                j2 = 1;
            } else {
                if (i2 != 3) {
                    throw null;
                }
                j2 = 2;
            }
            allocateDirect.putLong(j2);
            allocateDirect.putLong(wVar.f1741c);
            allocateDirect.putLong(wVar.f1742d);
            allocateDirect.putLong(wVar.f1743e ? 1L : 0L);
            int i3 = wVar.f1744f;
            if (i3 == 1) {
                j3 = 0;
            } else if (i3 == 2) {
                j3 = 1;
            } else if (i3 == 3) {
                j3 = 2;
            } else if (i3 == 4) {
                j3 = 3;
            } else {
                if (i3 != 5) {
                    throw null;
                }
                j3 = 4;
            }
            allocateDirect.putLong(j3);
            if (bArr != null) {
                allocateDirect.put(bArr);
            }
            this.f1752e.x("flutter/keydata", allocateDirect, interfaceC0225e);
        } catch (UnsupportedEncodingException unused) {
            throw new AssertionError("UTF-8 not supported");
        }
    }

    public final void b(boolean z2, Long l2, Long l3, long j2) {
        w wVar = new w();
        wVar.f1739a = j2;
        wVar.f1740b = z2 ? 1 : 2;
        wVar.f1742d = l2.longValue();
        wVar.f1741c = l3.longValue();
        wVar.f1745g = null;
        wVar.f1743e = true;
        wVar.f1744f = 1;
        if (l3.longValue() != 0 && l2.longValue() != 0) {
            if (!z2) {
                l2 = null;
            }
            c(l3, l2);
        }
        a(wVar, null);
    }

    public final void c(Long l2, Long l3) {
        HashMap hashMap = this.f1753f;
        if (l3 != null) {
            if (((Long) hashMap.put(l2, l3)) != null) {
                throw new AssertionError("The key was not empty");
            }
        } else if (((Long) hashMap.remove(l2)) == null) {
            throw new AssertionError("The key was empty");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:144:0x02c6  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x02d5  */
    @Override // c0.D
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void l(final KeyEvent keyEvent, B b2) {
        Long l2;
        boolean z2;
        Long l3;
        int i2;
        String str;
        int i3;
        int i4;
        I i5;
        int i6;
        HashMap hashMap;
        int i7;
        HashMap hashMap2;
        Boolean[] boolArr;
        int i8;
        final long j2;
        int i9;
        int i10;
        int i11;
        z zVar = this;
        if (keyEvent.getScanCode() != 0 || keyEvent.getKeyCode() != 0) {
            long scanCode = keyEvent.getScanCode();
            if (scanCode == 0) {
                l2 = Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            } else {
                l2 = (Long) J.f1645a.get(Long.valueOf(scanCode));
                if (l2 == null) {
                    l2 = Long.valueOf((keyEvent.getScanCode() & 4294967295L) | 73014444032L);
                }
            }
            Long l4 = l2;
            Long l5 = (Long) J.f1646b.get(Long.valueOf(keyEvent.getKeyCode()));
            if (l5 == null) {
                l5 = Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            }
            Long l6 = l5;
            ArrayList arrayList = new ArrayList();
            H[] hArr = J.f1647c;
            int length = hArr.length;
            int i12 = 0;
            while (true) {
                int i13 = 2;
                HashMap hashMap3 = zVar.f1753f;
                if (i12 >= length) {
                    HashMap hashMap4 = hashMap3;
                    Long l7 = l6;
                    HashMap hashMap5 = zVar.f1754g;
                    for (I i14 : hashMap5.values()) {
                        int metaState = keyEvent.getMetaState();
                        i14.getClass();
                        boolean z3 = (metaState & 1048576) != 0;
                        if (4294967556L == l7.longValue() || i14.f1644a == z3) {
                            hashMap = hashMap4;
                        } else {
                            hashMap = hashMap4;
                            boolean containsKey = hashMap.containsKey(458809L);
                            boolean z4 = !containsKey;
                            if (!containsKey) {
                                i14.f1644a = !i14.f1644a;
                            }
                            zVar.b(z4, 4294967556L, 458809L, keyEvent.getEventTime());
                            if (containsKey) {
                                i14.f1644a = !i14.f1644a;
                            }
                            b(containsKey, 4294967556L, 458809L, keyEvent.getEventTime());
                        }
                        zVar = this;
                        hashMap4 = hashMap;
                    }
                    HashMap hashMap6 = hashMap4;
                    int action = keyEvent.getAction();
                    if (action == 0) {
                        z2 = true;
                    } else if (action != 1) {
                        zVar = this;
                    } else {
                        z2 = false;
                    }
                    Long l8 = (Long) hashMap6.get(l4);
                    if (z2) {
                        if (l8 == null) {
                            i6 = 1;
                        } else if (keyEvent.getRepeatCount() > 0) {
                            i6 = 3;
                        } else {
                            zVar = this;
                            l3 = l4;
                            zVar.b(false, l8, l3, keyEvent.getEventTime());
                            i6 = 1;
                            char charValue = zVar.f1755h.a(keyEvent.getUnicodeChar()).charValue();
                            i2 = i6;
                            str = charValue == 0 ? "" + charValue : null;
                            i4 = 3;
                            i3 = 1;
                        }
                        zVar = this;
                        l3 = l4;
                        char charValue2 = zVar.f1755h.a(keyEvent.getUnicodeChar()).charValue();
                        if (charValue2 == 0) {
                        }
                        i2 = i6;
                        str = charValue2 == 0 ? "" + charValue2 : null;
                        i4 = 3;
                        i3 = 1;
                    } else {
                        zVar = this;
                        l3 = l4;
                        if (l8 != null) {
                            i2 = 2;
                            str = null;
                            i3 = 1;
                            i4 = 3;
                        }
                    }
                    if (i2 != i4) {
                        zVar.c(l3, z2 ? l7 : null);
                    }
                    if (i2 == i3 && (i5 = (I) hashMap5.get(l7)) != null) {
                        i5.f1644a = (i5.f1644a ? 1 : 0) ^ i3;
                    }
                    w wVar = new w();
                    int source = keyEvent.getSource();
                    if (source == 513) {
                        wVar.f1744f = 2;
                    } else if (source == 1025) {
                        wVar.f1744f = i4;
                    } else if (source == 16777232) {
                        wVar.f1744f = 4;
                    } else if (source != 33554433) {
                        wVar.f1744f = 1;
                    } else {
                        wVar.f1744f = 5;
                    }
                    wVar.f1739a = keyEvent.getEventTime();
                    wVar.f1740b = i2;
                    wVar.f1742d = l7.longValue();
                    wVar.f1741c = l3.longValue();
                    wVar.f1745g = str;
                    wVar.f1743e = false;
                    zVar.a(wVar, b2);
                    int size = arrayList.size();
                    int i15 = 0;
                    while (i15 < size) {
                        Object obj = arrayList.get(i15);
                        i15++;
                        ((Runnable) obj).run();
                    }
                    return;
                }
                H h2 = hArr[i12];
                boolean z5 = (h2.f1642a & keyEvent.getMetaState()) != 0;
                long longValue = l6.longValue();
                long longValue2 = l4.longValue();
                G[] gArr = (G[]) h2.f1643b;
                boolean[] zArr = new boolean[2];
                Boolean[] boolArr2 = new Boolean[2];
                int i16 = 0;
                boolean z6 = false;
                while (i16 < i13) {
                    final G g2 = gArr[i16];
                    boolean[] zArr2 = zArr;
                    boolean containsKey2 = hashMap3.containsKey(Long.valueOf(g2.f1640a));
                    zArr2[i16] = containsKey2;
                    Long l9 = l6;
                    if (g2.f1641b == longValue) {
                        boolean z7 = keyEvent.getRepeatCount() > 0;
                        int action2 = keyEvent.getAction();
                        if (action2 != 0) {
                            i10 = 1;
                            if (action2 != 1) {
                                throw new AssertionError("Unexpected event type");
                            }
                            i11 = 2;
                        } else {
                            i10 = 1;
                            i11 = z7 ? 3 : 1;
                        }
                        int a2 = F.i.a(i11);
                        if (a2 == 0) {
                            hashMap2 = hashMap3;
                            boolArr = boolArr2;
                            i8 = i16;
                            j2 = longValue2;
                            i9 = 2;
                            i7 = i12;
                            boolArr[i8] = Boolean.FALSE;
                            if (!z5) {
                                final int i17 = 0;
                                arrayList.add(new Runnable(this) { // from class: c0.y

                                    /* renamed from: f, reason: collision with root package name */
                                    public final /* synthetic */ z f1748f;

                                    {
                                        this.f1748f = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        switch (i17) {
                                            case 0:
                                                z zVar2 = this.f1748f;
                                                zVar2.getClass();
                                                zVar2.b(false, Long.valueOf(g2.f1641b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                z zVar3 = this.f1748f;
                                                zVar3.getClass();
                                                zVar3.b(false, Long.valueOf(g2.f1641b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                        } else if (a2 == i10) {
                            i7 = i12;
                            hashMap2 = hashMap3;
                            boolArr = boolArr2;
                            i8 = i16;
                            j2 = longValue2;
                            i9 = 2;
                            boolArr[i8] = Boolean.valueOf(zArr2[i8]);
                        } else if (a2 != 2) {
                            i7 = i12;
                            i9 = 2;
                            hashMap2 = hashMap3;
                            boolArr = boolArr2;
                            i8 = i16;
                            j2 = longValue2;
                        } else {
                            if (z5) {
                                i7 = i12;
                                i9 = 2;
                                hashMap2 = hashMap3;
                                boolArr = boolArr2;
                                i8 = i16;
                                j2 = longValue2;
                            } else {
                                int i18 = i16;
                                final int i19 = 1;
                                i8 = i18;
                                i9 = 2;
                                hashMap2 = hashMap3;
                                boolArr = boolArr2;
                                j2 = longValue2;
                                i7 = i12;
                                arrayList.add(new Runnable(this) { // from class: c0.y

                                    /* renamed from: f, reason: collision with root package name */
                                    public final /* synthetic */ z f1748f;

                                    {
                                        this.f1748f = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        switch (i19) {
                                            case 0:
                                                z zVar2 = this.f1748f;
                                                zVar2.getClass();
                                                zVar2.b(false, Long.valueOf(g2.f1641b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                z zVar3 = this.f1748f;
                                                zVar3.getClass();
                                                zVar3.b(false, Long.valueOf(g2.f1641b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                            boolArr[i8] = Boolean.valueOf(zArr2[i8]);
                        }
                        z6 = true;
                    } else {
                        i7 = i12;
                        hashMap2 = hashMap3;
                        boolArr = boolArr2;
                        i8 = i16;
                        j2 = longValue2;
                        i9 = 2;
                        z6 = z6 || containsKey2;
                    }
                    i16 = i8 + 1;
                    longValue2 = j2;
                    i13 = i9;
                    boolArr2 = boolArr;
                    i12 = i7;
                    zArr = zArr2;
                    l6 = l9;
                    hashMap3 = hashMap2;
                }
                int i20 = i12;
                int i21 = i13;
                boolean[] zArr3 = zArr;
                Long l10 = l6;
                Boolean[] boolArr3 = boolArr2;
                if (z5) {
                    for (int i22 = 0; i22 < i21; i22++) {
                        if (boolArr3[i22] == null) {
                            if (z6) {
                                boolArr3[i22] = Boolean.valueOf(zArr3[i22]);
                            } else {
                                boolArr3[i22] = Boolean.TRUE;
                                z6 = true;
                            }
                        }
                    }
                    if (!z6) {
                        boolArr3[0] = Boolean.TRUE;
                    }
                } else {
                    for (int i23 = 0; i23 < i21; i23++) {
                        if (boolArr3[i23] == null) {
                            boolArr3[i23] = Boolean.FALSE;
                        }
                    }
                }
                for (int i24 = 0; i24 < i21; i24++) {
                    if (zArr3[i24] != boolArr3[i24].booleanValue()) {
                        G g3 = gArr[i24];
                        b(boolArr3[i24].booleanValue(), Long.valueOf(g3.f1641b), Long.valueOf(g3.f1640a), keyEvent.getEventTime());
                    }
                }
                zVar = this;
                i12 = i20 + 1;
                l6 = l10;
            }
        }
        zVar.b(true, 0L, 0L, 0L);
        b2.a(true);
    }
}
