package c0;

import android.view.SurfaceHolder;

/* renamed from: c0.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class SurfaceHolderCallbackC0109l implements SurfaceHolder.Callback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0110m f1694a;

    public SurfaceHolderCallbackC0109l(C0110m c0110m) {
        this.f1694a = c0110m;
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        C0110m c0110m = this.f1694a;
        io.flutter.embedding.engine.renderer.h hVar = c0110m.f1697g;
        if (hVar == null || c0110m.f1696f) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2346a.onSurfaceChanged(i3, i4);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        C0110m c0110m = this.f1694a;
        c0110m.f1695e = true;
        if (c0110m.f1697g == null || c0110m.f1696f) {
            return;
        }
        c0110m.e();
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        C0110m c0110m = this.f1694a;
        c0110m.f1695e = false;
        io.flutter.embedding.engine.renderer.h hVar = c0110m.f1697g;
        if (hVar == null || c0110m.f1696f) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
        }
        hVar.e();
    }
}
