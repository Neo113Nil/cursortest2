package c0;

/* loaded from: classes.dex */
public final class L implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Runnable f1649a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ N f1650b;

    public L(N n2, Runnable runnable) {
        this.f1650b = n2;
        this.f1649a = runnable;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        this.f1649a.run();
        io.flutter.embedding.engine.renderer.h hVar = this.f1650b.f1654b;
        if (hVar != null) {
            hVar.c(this);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
    }
}
