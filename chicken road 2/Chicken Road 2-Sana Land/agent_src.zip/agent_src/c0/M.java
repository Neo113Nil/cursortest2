package c0;

/* loaded from: classes.dex */
public final class M {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1651a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ N f1652b;

    public /* synthetic */ M(N n2, int i2) {
        this.f1651a = i2;
        this.f1652b = n2;
    }

    private final void a() {
    }
}
