package c0;

import android.view.ViewTreeObserver;

/* renamed from: c0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ViewTreeObserverOnPreDrawListenerC0105h implements ViewTreeObserver.OnPreDrawListener {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ s f1673e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0107j f1674f;

    public ViewTreeObserverOnPreDrawListenerC0105h(C0107j c0107j, s sVar) {
        this.f1674f = c0107j;
        this.f1673e = sVar;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        C0107j c0107j = this.f1674f;
        if (c0107j.f1682h && c0107j.f1680f != null) {
            this.f1673e.getViewTreeObserver().removeOnPreDrawListener(this);
            c0107j.f1680f = null;
        }
        return c0107j.f1682h;
    }
}
