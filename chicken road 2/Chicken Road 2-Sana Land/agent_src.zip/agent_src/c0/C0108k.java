package c0;

import a.AbstractC0068a;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Paint;
import android.hardware.HardwareBuffer;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import java.nio.ByteBuffer;
import java.util.Locale;

/* renamed from: c0.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0108k extends View implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: e, reason: collision with root package name */
    public ImageReader f1687e;

    /* renamed from: f, reason: collision with root package name */
    public Image f1688f;

    /* renamed from: g, reason: collision with root package name */
    public Bitmap f1689g;

    /* renamed from: h, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1690h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f1691i;

    /* renamed from: j, reason: collision with root package name */
    public final int f1692j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1693k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0108k(Context context, int i2, int i3, int i4) {
        super(context, null);
        ImageReader f2 = f(i2, i3);
        this.f1691i = false;
        this.f1693k = false;
        this.f1687e = f2;
        this.f1692j = i4;
        setAlpha(0.0f);
        this.f1691i = AbstractC0068a.w(getContext());
    }

    public static ImageReader f(int i2, int i3) {
        ImageReader newInstance;
        if (i2 <= 0) {
            Locale locale = Locale.US;
            Log.w("FlutterImageView", "ImageReader width must be greater than 0, but given width=" + i2 + ", set width=1");
            i2 = 1;
        }
        if (i3 <= 0) {
            Locale locale2 = Locale.US;
            Log.w("FlutterImageView", "ImageReader height must be greater than 0, but given height=" + i3 + ", set height=1");
            i3 = 1;
        }
        if (Build.VERSION.SDK_INT < 29) {
            return ImageReader.newInstance(i2, i3, 1, 3);
        }
        newInstance = ImageReader.newInstance(i2, i3, 1, 3, 768L);
        return newInstance;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1693k) {
            setAlpha(0.0f);
            e();
            this.f1689g = null;
            Image image = this.f1688f;
            if (image != null) {
                image.close();
                this.f1688f = null;
            }
            invalidate();
            this.f1693k = false;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        if (F.i.a(this.f1692j) == 0) {
            Surface surface = this.f1687e.getSurface();
            hVar.f2347b = surface;
            hVar.f2346a.onSurfaceWindowChanged(surface);
        }
        setAlpha(1.0f);
        this.f1690h = hVar;
        this.f1693k = true;
    }

    public final boolean e() {
        if (!this.f1693k) {
            return false;
        }
        Image acquireLatestImage = this.f1687e.acquireLatestImage();
        if (acquireLatestImage != null) {
            Image image = this.f1688f;
            if (image != null) {
                image.close();
                this.f1688f = null;
            }
            this.f1688f = acquireLatestImage;
            invalidate();
        }
        return acquireLatestImage != null;
    }

    public final void g(int i2, int i3) {
        if (this.f1690h == null) {
            return;
        }
        if (i2 == this.f1687e.getWidth() && i3 == this.f1687e.getHeight()) {
            return;
        }
        Image image = this.f1688f;
        if (image != null) {
            image.close();
            this.f1688f = null;
        }
        this.f1687e.close();
        this.f1687e = f(i2, i3);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1690h;
    }

    public ImageReader getImageReader() {
        return this.f1687e;
    }

    public Surface getSurface() {
        return this.f1687e.getSurface();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        HardwareBuffer hardwareBuffer;
        ColorSpace colorSpace;
        Bitmap wrapHardwareBuffer;
        ColorSpace.Named unused;
        super.onDraw(canvas);
        Image image = this.f1688f;
        if (image != null) {
            if (Build.VERSION.SDK_INT >= 29) {
                hardwareBuffer = image.getHardwareBuffer();
                unused = ColorSpace.Named.SRGB;
                colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
                wrapHardwareBuffer = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace);
                this.f1689g = wrapHardwareBuffer;
                hardwareBuffer.close();
            } else {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length == 1) {
                    Image.Plane plane = planes[0];
                    int rowStride = plane.getRowStride() / plane.getPixelStride();
                    int height = this.f1688f.getHeight();
                    Bitmap bitmap = this.f1689g;
                    if (bitmap == null || bitmap.getWidth() != rowStride || this.f1689g.getHeight() != height) {
                        this.f1689g = Bitmap.createBitmap(rowStride, height, Bitmap.Config.ARGB_8888);
                    }
                    ByteBuffer buffer = plane.getBuffer();
                    buffer.rewind();
                    this.f1689g.copyPixelsFromBuffer(buffer);
                }
            }
        }
        Bitmap bitmap2 = this.f1689g;
        if (bitmap2 != null) {
            canvas.drawBitmap(bitmap2, 0.0f, 0.0f, (Paint) null);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1691i) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        if (!(i2 == this.f1687e.getWidth() && i3 == this.f1687e.getHeight()) && this.f1692j == 1 && this.f1693k) {
            g(i2, i3);
            io.flutter.embedding.engine.renderer.h hVar = this.f1690h;
            Surface surface = this.f1687e.getSurface();
            hVar.f2347b = surface;
            hVar.f2346a.onSurfaceWindowChanged(surface);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
    }
}
