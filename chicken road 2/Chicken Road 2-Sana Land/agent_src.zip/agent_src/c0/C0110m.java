package c0;

import a.AbstractC0068a;
import android.graphics.Region;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import io.flutter.embedding.engine.FlutterJNI;

/* renamed from: c0.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0110m extends SurfaceView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: e, reason: collision with root package name */
    public boolean f1695e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1696f;

    /* renamed from: g, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1697g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f1698h;

    /* renamed from: i, reason: collision with root package name */
    public final N f1699i;

    public C0110m(AbstractActivityC0103f abstractActivityC0103f, boolean z2) {
        super(abstractActivityC0103f, null);
        this.f1695e = false;
        this.f1696f = false;
        this.f1698h = false;
        N n2 = new N(new SurfaceHolderCallbackC0109l(this), this, this.f1697g);
        this.f1699i = n2;
        if (z2) {
            getHolder().setFormat(-2);
            setZOrderOnTop(true);
        }
        this.f1698h = AbstractC0068a.w(getContext());
        getHolder().addCallback(n2);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1697g == null) {
            Log.w("FlutterSurfaceView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1697g;
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
        }
        M m2 = this.f1699i.f1657e;
        switch (m2.f1651a) {
            case 0:
                m2.f1652b.f1654b = null;
                break;
            default:
                N n2 = m2.f1652b;
                n2.f1653a.setAlpha(0.0f);
                io.flutter.embedding.engine.renderer.h hVar2 = n2.f1654b;
                if (hVar2 != null) {
                    hVar2.c(n2.f1656d);
                }
                n2.f1654b = null;
                break;
        }
        this.f1697g = null;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1697g == null) {
            Log.w("FlutterSurfaceView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        M m2 = this.f1699i.f1657e;
        switch (m2.f1651a) {
            case 0:
                break;
            default:
                N n2 = m2.f1652b;
                io.flutter.embedding.engine.renderer.h hVar = n2.f1654b;
                if (hVar != null) {
                    hVar.a(n2.f1656d);
                    break;
                }
                break;
        }
        if (this.f1695e) {
            e();
        }
        this.f1696f = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1697g;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1697g = hVar;
        M m2 = this.f1699i.f1657e;
        switch (m2.f1651a) {
            case 0:
                m2.f1652b.f1654b = hVar;
                break;
            default:
                N n2 = m2.f1652b;
                io.flutter.embedding.engine.renderer.h hVar3 = n2.f1654b;
                if (hVar3 != null) {
                    hVar3.c(n2.f1656d);
                }
                n2.f1654b = hVar;
                break;
        }
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1697g == null) {
            Log.w("FlutterSurfaceView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1696f = true;
        }
    }

    public final void e() {
        if (this.f1697g == null || getHolder() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getHolder() are non-null.");
        }
        io.flutter.embedding.engine.renderer.h hVar = this.f1697g;
        Surface surface = getHolder().getSurface();
        boolean z2 = this.f1696f;
        FlutterJNI flutterJNI = hVar.f2346a;
        if (!z2) {
            hVar.e();
        }
        hVar.f2347b = surface;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface);
        } else {
            flutterJNI.onSurfaceCreated(surface);
        }
    }

    @Override // android.view.SurfaceView, android.view.View
    public final boolean gatherTransparentRegion(Region region) {
        if (getAlpha() < 1.0f) {
            return false;
        }
        int[] iArr = new int[2];
        getLocationInWindow(iArr);
        int i2 = iArr[0];
        region.op(i2, iArr[1], (getRight() + i2) - getLeft(), (getBottom() + iArr[1]) - getTop(), Region.Op.DIFFERENCE);
        return true;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1697g;
    }

    @Override // android.view.SurfaceView, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1698h) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }
}
