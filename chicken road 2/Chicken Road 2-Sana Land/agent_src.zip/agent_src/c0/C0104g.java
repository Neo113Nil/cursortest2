package c0;

import android.os.Build;
import java.util.Iterator;

/* renamed from: c0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0104g implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1671a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1672b;

    public /* synthetic */ C0104g(int i2, Object obj) {
        this.f1671a = i2;
        this.f1672b = obj;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
        switch (this.f1671a) {
            case 0:
                C0107j c0107j = (C0107j) this.f1672b;
                c0107j.f1675a.getClass();
                c0107j.f1682h = false;
                break;
            case 1:
                s sVar = (s) this.f1672b;
                sVar.f1725m = false;
                Iterator it = sVar.f1724l.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).a();
                }
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1672b).f2348c = false;
                break;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        switch (this.f1671a) {
            case 0:
                C0107j c0107j = (C0107j) this.f1672b;
                AbstractActivityC0103f abstractActivityC0103f = c0107j.f1675a;
                if (Build.VERSION.SDK_INT >= 29) {
                    abstractActivityC0103f.reportFullyDrawn();
                } else {
                    abstractActivityC0103f.getClass();
                }
                c0107j.f1682h = true;
                c0107j.f1683i = true;
                break;
            case 1:
                s sVar = (s) this.f1672b;
                sVar.f1725m = true;
                Iterator it = sVar.f1724l.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).b();
                }
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                N n2 = (N) this.f1672b;
                n2.f1653a.setAlpha(1.0f);
                io.flutter.embedding.engine.renderer.h hVar = n2.f1654b;
                if (hVar != null) {
                    hVar.c(this);
                    break;
                }
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1672b).f2348c = true;
                break;
        }
    }

    private final void c() {
    }
}
