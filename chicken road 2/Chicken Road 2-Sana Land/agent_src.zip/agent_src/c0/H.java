package c0;

/* loaded from: classes.dex */
public final class H {

    /* renamed from: a, reason: collision with root package name */
    public int f1642a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f1643b;

    public /* synthetic */ H(int i2, Object[] objArr) {
        this.f1642a = i2;
        this.f1643b = objArr;
    }

    public H(int i2) {
        if (i2 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f1643b = new Object[i2];
    }
}
