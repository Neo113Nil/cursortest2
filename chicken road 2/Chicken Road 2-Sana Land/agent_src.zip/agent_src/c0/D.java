package c0;

import android.view.KeyEvent;

/* loaded from: classes.dex */
public interface D {
    void l(KeyEvent keyEvent, B b2);
}
