package c0;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public long f1739a;

    /* renamed from: b, reason: collision with root package name */
    public int f1740b;

    /* renamed from: c, reason: collision with root package name */
    public long f1741c;

    /* renamed from: d, reason: collision with root package name */
    public long f1742d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1743e;

    /* renamed from: f, reason: collision with root package name */
    public int f1744f;

    /* renamed from: g, reason: collision with root package name */
    public String f1745g;
}
