package c0;

import L.C0051b;
import L.Q;
import a.AbstractC0068a;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.Window;
import android.view.accessibility.AccessibilityManager;
import android.view.textservice.TextServicesManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import d0.C0115c;
import d0.C0117e;
import d0.C0119g;
import d0.C0120h;
import d0.C0121i;
import e0.C0127a;
import h0.C0189e;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import l0.C0203a;
import l0.C0204b;
import l0.C0205c;
import l0.C0213k;
import l0.C0214l;
import q0.C0248a;

/* renamed from: c0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0103f extends Activity implements InterfaceC0106i, androidx.lifecycle.i {

    /* renamed from: i, reason: collision with root package name */
    public static final int f1666i = View.generateViewId();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1667e = false;

    /* renamed from: f, reason: collision with root package name */
    public C0107j f1668f;

    /* renamed from: g, reason: collision with root package name */
    public final androidx.lifecycle.j f1669g;

    /* renamed from: h, reason: collision with root package name */
    public final OnBackInvokedCallback f1670h;

    public AbstractActivityC0103f() {
        int i2 = Build.VERSION.SDK_INT;
        this.f1670h = i2 < 33 ? null : i2 >= 34 ? new C0102e(this) : new OnBackInvokedCallback() { // from class: c0.d
            public final void onBackInvoked() {
                AbstractActivityC0103f.this.onBackPressed();
            }
        };
        this.f1669g = new androidx.lifecycle.j(this);
    }

    @Override // androidx.lifecycle.i
    public final androidx.lifecycle.j a() {
        return this.f1669g;
    }

    public final String b() {
        String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int c() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final String d() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final String e() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle g2 = g();
            String string = g2 != null ? g2.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final String f() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle g2 = g();
            if (g2 != null) {
                return g2.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final Bundle g() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void h(boolean z2) {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        OnBackInvokedDispatcher onBackInvokedDispatcher2;
        if (z2 && !this.f1667e) {
            if (Build.VERSION.SDK_INT >= 33) {
                onBackInvokedDispatcher2 = getOnBackInvokedDispatcher();
                onBackInvokedDispatcher2.registerOnBackInvokedCallback(0, this.f1670h);
                this.f1667e = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1667e || Build.VERSION.SDK_INT < 33) {
            return;
        }
        onBackInvokedDispatcher = getOnBackInvokedDispatcher();
        onBackInvokedDispatcher.unregisterOnBackInvokedCallback(this.f1670h);
        this.f1667e = false;
    }

    public final boolean i() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (d() != null || this.f1668f.f1681g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean j() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : d() == null;
    }

    public final boolean k(String str) {
        C0107j c0107j = this.f1668f;
        if (c0107j == null) {
            Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0107j.f1684j) {
            return true;
        }
        Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        if (k("onActivityResult")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Objects.toString(intent);
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                c0117e.f1794f.d(i2, i3, intent);
                Trace.endSection();
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (k("onBackPressed")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1768i.f2655a.B("popRoute", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(36:117|118|(1:120)|121|122|(1:124)|125|(1:127)(1:256)|128|(2:130|(1:132)(2:133|(1:135)(1:136)))|137|(4:139|140|141|(1:143)(2:241|(1:243)(2:244|245)))(1:255)|144|(1:146)|147|(1:149)|(1:151)(1:240)|152|(3:154|(1:156)(1:234)|157)(3:235|(1:237)(1:239)|238)|158|(8:160|(1:162)|163|(2:165|(3:167|(1:169)|170)(2:171|172))|173|(1:175)|176|177)|178|(1:180)|181|182|183|184|(2:(1:230)(1:188)|189)(1:231)|190|(2:193|191)|194|195|(3:198|(1:200)(3:201|202|203)|196)|204|205|(5:207|(3:210|(1:212)(3:213|214|215)|208)|216|217|(2:219|(8:221|(1:223)|163|(0)|173|(0)|176|177)(2:224|225))(2:226|227))(2:228|229)) */
    /* JADX WARN: Code restructure failed: missing block: B:233:0x047f, code lost:
    
        android.util.Log.e("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
     */
    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:165:0x05bd  */
    /* JADX WARN: Removed duplicated region for block: B:175:0x0601  */
    /* JADX WARN: Type inference failed for: r10v1, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        byte[] bArr;
        int i2;
        try {
            Bundle g2 = g();
            if (g2 != null && (i2 = g2.getInt("io.flutter.embedding.android.NormalTheme", -1)) != -1) {
                setTheme(i2);
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.e("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
        super.onCreate(bundle);
        if (bundle != null) {
            h(bundle.getBoolean("enableOnBackInvokedCallbackState"));
        }
        C0107j c0107j = new C0107j(this);
        this.f1668f = c0107j;
        c0107j.c();
        if (c0107j.f1676b == null) {
            String d2 = c0107j.f1675a.d();
            if (d2 != null) {
                if (C0121i.f1806c == null) {
                    C0121i.f1806c = new C0121i(1);
                }
                C0115c c0115c = (C0115c) C0121i.f1806c.f1807a.get(d2);
                c0107j.f1676b = c0115c;
                c0107j.f1681g = true;
                if (c0115c == null) {
                    throw new IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + d2 + "'");
                }
            } else {
                c0107j.f1675a.getClass();
                c0107j.f1676b = null;
                String stringExtra = c0107j.f1675a.getIntent().getStringExtra("cached_engine_group_id");
                if (stringExtra != null) {
                    if (C0121i.f1805b == null) {
                        synchronized (C0121i.class) {
                            try {
                                if (C0121i.f1805b == null) {
                                    C0121i.f1805b = new C0121i(0);
                                }
                            } finally {
                            }
                        }
                    }
                    C0120h c0120h = (C0120h) C0121i.f1805b.f1807a.get(stringExtra);
                    if (c0120h == null) {
                        throw new IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + stringExtra + "'");
                    }
                    AbstractActivityC0103f abstractActivityC0103f = c0107j.f1675a;
                    abstractActivityC0103f.getClass();
                    C0119g c0119g = new C0119g(abstractActivityC0103f);
                    c0107j.a(c0119g);
                    c0107j.f1676b = c0120h.a(c0119g);
                    c0107j.f1681g = false;
                } else {
                    AbstractActivityC0103f abstractActivityC0103f2 = c0107j.f1675a;
                    abstractActivityC0103f2.getClass();
                    Intent intent = c0107j.f1675a.getIntent();
                    ArrayList arrayList = new ArrayList();
                    if (intent.getBooleanExtra("trace-startup", false)) {
                        arrayList.add("--trace-startup");
                    }
                    if (intent.getBooleanExtra("start-paused", false)) {
                        arrayList.add("--start-paused");
                    }
                    int intExtra = intent.getIntExtra("vm-service-port", 0);
                    if (intExtra > 0) {
                        arrayList.add("--vm-service-port=" + Integer.toString(intExtra));
                    }
                    if (intent.getBooleanExtra("disable-service-auth-codes", false)) {
                        arrayList.add("--disable-service-auth-codes");
                    }
                    if (intent.getBooleanExtra("endless-trace-buffer", false)) {
                        arrayList.add("--endless-trace-buffer");
                    }
                    if (intent.getBooleanExtra("use-test-fonts", false)) {
                        arrayList.add("--use-test-fonts");
                    }
                    if (intent.getBooleanExtra("enable-dart-profiling", false)) {
                        arrayList.add("--enable-dart-profiling");
                    }
                    if (intent.getBooleanExtra("profile-startup", false)) {
                        arrayList.add("--profile-startup");
                    }
                    if (intent.getBooleanExtra("enable-software-rendering", false)) {
                        arrayList.add("--enable-software-rendering");
                    }
                    if (intent.getBooleanExtra("skia-deterministic-rendering", false)) {
                        arrayList.add("--skia-deterministic-rendering");
                    }
                    if (intent.getBooleanExtra("trace-skia", false)) {
                        arrayList.add("--trace-skia");
                    }
                    String stringExtra2 = intent.getStringExtra("trace-skia-allowlist");
                    if (stringExtra2 != null) {
                        arrayList.add("--trace-skia-allowlist=".concat(stringExtra2));
                    }
                    if (intent.getBooleanExtra("trace-systrace", false)) {
                        arrayList.add("--trace-systrace");
                    }
                    if (intent.hasExtra("trace-to-file")) {
                        arrayList.add("--trace-to-file=" + intent.getStringExtra("trace-to-file"));
                    }
                    if (intent.hasExtra("profile-microtasks")) {
                        arrayList.add("--profile-microtasks");
                    }
                    if (intent.hasExtra("enable-impeller")) {
                        if (intent.getBooleanExtra("enable-impeller", false)) {
                            arrayList.add("--enable-impeller=true");
                        } else {
                            arrayList.add("--enable-impeller=false");
                        }
                    }
                    if (intent.getBooleanExtra("enable-vulkan-validation", false)) {
                        arrayList.add("--enable-vulkan-validation");
                    }
                    if (intent.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
                        arrayList.add("--dump-skp-on-shader-compilation");
                    }
                    if (intent.getBooleanExtra("cache-sksl", false)) {
                        arrayList.add("--cache-sksl");
                    }
                    if (intent.getBooleanExtra("purge-persistent-cache", false)) {
                        arrayList.add("--purge-persistent-cache");
                    }
                    if (intent.getBooleanExtra("verbose-logging", false)) {
                        arrayList.add("--verbose-logging");
                    }
                    if (intent.hasExtra("dart-flags")) {
                        arrayList.add("--dart-flags=" + intent.getStringExtra("dart-flags"));
                    }
                    HashSet hashSet = new HashSet(arrayList);
                    C0120h c0120h2 = new C0120h(abstractActivityC0103f2, (String[]) hashSet.toArray(new String[hashSet.size()]));
                    AbstractActivityC0103f abstractActivityC0103f3 = c0107j.f1675a;
                    abstractActivityC0103f3.getClass();
                    C0119g c0119g2 = new C0119g(abstractActivityC0103f3);
                    c0119g2.f1802e = false;
                    c0119g2.f1803f = c0107j.f1675a.j();
                    c0107j.a(c0119g2);
                    c0107j.f1676b = c0120h2.a(c0119g2);
                    c0107j.f1681g = false;
                }
            }
        }
        c0107j.f1675a.getClass();
        C0117e c0117e = c0107j.f1676b.f1763d;
        androidx.lifecycle.j jVar = c0107j.f1675a.f1669g;
        c0117e.getClass();
        t0.a.b("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            C0107j c0107j2 = c0117e.f1793e;
            if (c0107j2 != null) {
                c0107j2.b();
            }
            c0117e.e();
            c0117e.f1793e = c0107j;
            AbstractActivityC0103f abstractActivityC0103f4 = c0107j.f1675a;
            abstractActivityC0103f4.getClass();
            c0117e.b(abstractActivityC0103f4, jVar);
            Trace.endSection();
            AbstractActivityC0103f abstractActivityC0103f5 = c0107j.f1675a;
            abstractActivityC0103f5.getClass();
            AbstractActivityC0103f abstractActivityC0103f6 = c0107j.f1675a;
            C0115c c0115c2 = c0107j.f1676b;
            abstractActivityC0103f6.getClass();
            c0107j.f1678d = new io.flutter.plugin.platform.e(abstractActivityC0103f6, c0115c2.f1771l, abstractActivityC0103f6);
            AbstractActivityC0103f abstractActivityC0103f7 = c0107j.f1675a;
            C0115c c0115c3 = c0107j.f1676b;
            abstractActivityC0103f7.getClass();
            int i3 = f1666i;
            c0107j.f1679e = new C0248a(i3, abstractActivityC0103f5, c0115c3.f1773n);
            AbstractActivityC0103f abstractActivityC0103f8 = c0107j.f1675a;
            C0115c c0115c4 = c0107j.f1676b;
            if (!abstractActivityC0103f8.f1668f.f1681g) {
                AbstractC0068a.D(c0115c4);
            }
            c0107j.f1684j = true;
            C0107j c0107j3 = this.f1668f;
            c0107j3.c();
            if (bundle != null) {
                bundle.getBundle("plugins");
                bArr = bundle.getByteArray("framework");
            } else {
                bArr = null;
            }
            if (c0107j3.f1675a.j()) {
                C0214l c0214l = c0107j3.f1676b.f1770k;
                c0214l.f2702e = true;
                C0213k c0213k = c0214l.f2701d;
                if (c0213k != null) {
                    c0213k.d(C0214l.a(bArr));
                    c0214l.f2701d = null;
                    c0214l.f2699b = bArr;
                } else if (c0214l.f2703f) {
                    c0214l.f2700c.B("push", C0214l.a(bArr), new C0213k(0, c0214l, bArr));
                } else {
                    c0214l.f2699b = bArr;
                }
            }
            c0107j3.f1675a.getClass();
            C0117e c0117e2 = c0107j3.f1676b.f1763d;
            if (c0117e2.f()) {
                t0.a.b("FlutterEngineConnectionRegistry#onRestoreInstanceState");
                try {
                    Iterator it = ((HashSet) c0117e2.f1794f.f1788f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } finally {
                    try {
                        Trace.endSection();
                        throw th;
                    } catch (Throwable th) {
                        th.addSuppressed(th);
                    }
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
            }
            this.f1669g.a(androidx.lifecycle.d.ON_CREATE);
            if (c() == 2) {
                getWindow().setBackgroundDrawable(new ColorDrawable(0));
            }
            C0107j c0107j4 = this.f1668f;
            boolean z2 = (c() == 1 ? (char) 1 : (char) 2) == 1;
            c0107j4.c();
            if (c0107j4.f1675a.c() == 1) {
                AbstractActivityC0103f abstractActivityC0103f9 = c0107j4.f1675a;
                abstractActivityC0103f9.getClass();
                C0110m c0110m = new C0110m(abstractActivityC0103f9, c0107j4.f1675a.c() != 1);
                c0107j4.f1675a.getClass();
                AbstractActivityC0103f abstractActivityC0103f10 = c0107j4.f1675a;
                abstractActivityC0103f10.getClass();
                c0107j4.f1677c = new s(abstractActivityC0103f10, c0110m);
            } else {
                AbstractActivityC0103f abstractActivityC0103f11 = c0107j4.f1675a;
                abstractActivityC0103f11.getClass();
                o oVar = new o(abstractActivityC0103f11);
                oVar.setOpaque(c0107j4.f1675a.c() == 1);
                c0107j4.f1675a.getClass();
                AbstractActivityC0103f abstractActivityC0103f12 = c0107j4.f1675a;
                abstractActivityC0103f12.getClass();
                c0107j4.f1677c = new s(abstractActivityC0103f12, oVar);
            }
            c0107j4.f1677c.f1724l.add(c0107j4.f1686l);
            c0107j4.f1675a.getClass();
            s sVar = c0107j4.f1677c;
            C0115c c0115c5 = c0107j4.f1676b;
            C0104g c0104g = sVar.f1712C;
            Objects.toString(c0115c5);
            if (sVar.c()) {
                if (c0115c5 != sVar.f1726n) {
                    sVar.a();
                }
                c0107j4.f1677c.setId(i3);
                if (z2) {
                    s sVar2 = c0107j4.f1677c;
                    if (c0107j4.f1675a.c() != 1) {
                        throw new IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
                    }
                    if (c0107j4.f1680f != null) {
                        sVar2.getViewTreeObserver().removeOnPreDrawListener(c0107j4.f1680f);
                    }
                    c0107j4.f1680f = new ViewTreeObserverOnPreDrawListenerC0105h(c0107j4, sVar2);
                    sVar2.getViewTreeObserver().addOnPreDrawListener(c0107j4.f1680f);
                }
                setContentView(c0107j4.f1677c);
                Window window = getWindow();
                window.addFlags(Integer.MIN_VALUE);
                if (Build.VERSION.SDK_INT < 35) {
                    window.setStatusBarColor(1073741824);
                }
                window.getDecorView().setSystemUiVisibility(1280);
            }
            sVar.f1726n = c0115c5;
            io.flutter.embedding.engine.renderer.h hVar = c0115c5.f1761b;
            sVar.f1725m = hVar.f2348c;
            sVar.f1722j.c(hVar);
            hVar.a(c0104g);
            if (sVar.f1718f) {
                hVar.f2346a.addResizingFlutterUiListener(sVar.f1711B);
            }
            sVar.f1728p = new Q(sVar, sVar.f1726n.f1767h);
            C0115c c0115c6 = sVar.f1726n;
            sVar.f1729q = new io.flutter.plugin.editing.l(sVar, c0115c6.r, c0115c6.f1772m, c0115c6.f1777s, c0115c6.f1778t);
            TextServicesManager textServicesManager = (TextServicesManager) sVar.getContext().getSystemService("textservices");
            sVar.f1734w = textServicesManager;
            sVar.r = new io.flutter.plugin.editing.h(textServicesManager, sVar.f1726n.f1775p);
            new Q(sVar, sVar.f1729q.f2398b, sVar.f1726n.f1772m);
            sVar.f1730s = sVar.f1726n.f1764e;
            sVar.f1731t = new C0051b(sVar);
            sVar.f1732u = new C0099b(sVar.f1726n.f1761b, false);
            io.flutter.view.i iVar = new io.flutter.view.i(sVar, c0115c5.f1765f, (AccessibilityManager) sVar.getContext().getSystemService("accessibility"), sVar.getContext().getContentResolver(), c0115c5.f1779u);
            sVar.f1733v = iVar;
            iVar.r = sVar.f1737z;
            boolean isEnabled = iVar.f2556c.isEnabled();
            boolean isTouchExplorationEnabled = sVar.f1733v.f2556c.isTouchExplorationEnabled();
            if (sVar.f1726n.f1761b.f2346a.getIsSoftwareRenderingEnabled()) {
                sVar.setWillNotDraw(false);
            } else {
                sVar.setWillNotDraw((isEnabled || isTouchExplorationEnabled) ? false : true);
            }
            C0115c c0115c7 = sVar.f1726n;
            c0115c7.f1777s.f2444l.f2413a = sVar.f1733v;
            new C0099b(c0115c7.f1761b, true);
            C0115c c0115c8 = sVar.f1726n;
            c0115c8.f1778t.f2429j.f2413a = sVar.f1733v;
            new C0099b(c0115c8.f1761b, true);
            sVar.f1729q.f2398b.restartInput(sVar);
            sVar.d();
            sVar.getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, sVar.f1710A);
            sVar.e();
            io.flutter.plugin.platform.k kVar = c0115c5.f1777s;
            SparseArray sparseArray = kVar.f2447o;
            SparseArray sparseArray2 = kVar.f2448p;
            SparseArray sparseArray3 = kVar.r;
            kVar.f2439g = sVar;
            for (int i4 = 0; i4 < sparseArray3.size(); i4++) {
                kVar.f2439g.addView((io.flutter.plugin.platform.g) sparseArray3.valueAt(i4));
            }
            for (int i5 = 0; i5 < sparseArray2.size(); i5++) {
                if (sparseArray2.valueAt(i5) != null) {
                    throw new ClassCastException();
                }
                kVar.f2439g.addView(null);
            }
            if (sparseArray.size() > 0) {
                sparseArray.valueAt(0).getClass();
                throw new ClassCastException();
            }
            io.flutter.plugin.platform.j jVar2 = c0115c5.f1778t;
            SparseArray sparseArray4 = jVar2.f2430k;
            SparseArray sparseArray5 = jVar2.f2431l;
            jVar2.f2426g = sVar;
            for (int i6 = 0; i6 < sparseArray5.size(); i6++) {
                if (sparseArray5.valueAt(i6) != null) {
                    throw new ClassCastException();
                }
                jVar2.f2426g.addView(null);
            }
            if (sparseArray4.size() > 0) {
                sparseArray4.valueAt(0).getClass();
                throw new ClassCastException();
            }
            Iterator it2 = sVar.f1727o.iterator();
            if (it2.hasNext()) {
                it2.next().getClass();
                throw new ClassCastException();
            }
            if (sVar.f1725m) {
                c0104g.b();
            }
            c0107j4.f1677c.setId(i3);
            if (z2) {
            }
            setContentView(c0107j4.f1677c);
            Window window2 = getWindow();
            window2.addFlags(Integer.MIN_VALUE);
            if (Build.VERSION.SDK_INT < 35) {
            }
            window2.getDecorView().setSystemUiVisibility(1280);
        } catch (Throwable th2) {
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        super.onDestroy();
        if (k("onDestroy")) {
            this.f1668f.e();
            this.f1668f.f();
        }
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher = getOnBackInvokedDispatcher();
            onBackInvokedDispatcher.unregisterOnBackInvokedCallback(this.f1670h);
            this.f1667e = false;
        }
        C0107j c0107j = this.f1668f;
        if (c0107j != null) {
            c0107j.f1675a = null;
            c0107j.f1676b = null;
            c0107j.f1677c = null;
            c0107j.f1678d = null;
            c0107j.f1679e = null;
            this.f1668f = null;
        }
        this.f1669g.a(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (k("onNewIntent")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0117e c0117e = c0115c.f1763d;
            if (c0117e.f()) {
                t0.a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    Iterator it = ((HashSet) c0117e.f1794f.f1786d).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            String d2 = c0107j.d(intent);
            if (d2 == null || d2.isEmpty()) {
                return;
            }
            C0203a c0203a = c0107j.f1676b.f1768i;
            c0203a.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("location", d2);
            c0203a.f2655a.B("pushRouteInformation", hashMap, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (k("onPause")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(3, c0205c.f2659c);
            }
        }
        this.f1669g.a(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (k("onPostResume")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0107j.f1678d;
            if (eVar != null) {
                eVar.b();
            }
            Iterator it = c0107j.f1676b.f1777s.f2445m.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (k("onRequestPermissionsResult")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Arrays.toString(strArr);
            Arrays.toString(iArr);
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                Iterator it = ((HashSet) c0117e.f1794f.f1784b).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1669g.a(androidx.lifecycle.d.ON_RESUME);
        if (k("onResume")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1676b.f1761b.d();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(2, c0205c.f2659c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (k("onSaveInstanceState")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1675a.j()) {
                bundle.putByteArray("framework", c0107j.f1676b.f1770k.f2699b);
            }
            c0107j.f1675a.getClass();
            Bundle bundle2 = new Bundle();
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (c0117e.f()) {
                t0.a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    Iterator it = ((HashSet) c0117e.f1794f.f1788f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0107j.f1675a.d() == null || c0107j.f1675a.i()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0107j.f1675a.f1667e);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0090  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onStart() {
        String str;
        String b2;
        Bundle g2;
        super.onStart();
        this.f1669g.a(androidx.lifecycle.d.ON_START);
        if (k("onStart")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1675a.d() == null && !c0107j.f1676b.f1762c.f1818j) {
                String f2 = c0107j.f1675a.f();
                if (f2 == null) {
                    AbstractActivityC0103f abstractActivityC0103f = c0107j.f1675a;
                    abstractActivityC0103f.getClass();
                    f2 = c0107j.d(abstractActivityC0103f.getIntent());
                    if (f2 == null) {
                        f2 = "/";
                    }
                }
                AbstractActivityC0103f abstractActivityC0103f2 = c0107j.f1675a;
                abstractActivityC0103f2.getClass();
                try {
                    g2 = abstractActivityC0103f2.g();
                } catch (PackageManager.NameNotFoundException unused) {
                }
                if (g2 != null) {
                    str = g2.getString("io.flutter.EntrypointUri");
                    c0107j.f1675a.e();
                    c0107j.f1676b.f1768i.f2655a.B("setInitialRoute", f2, null);
                    b2 = c0107j.f1675a.b();
                    if (b2 != null || b2.isEmpty()) {
                        b2 = ((C0189e) C0051b.A().f584g).f2305d.f2294b;
                    }
                    c0107j.f1676b.f1762c.a(str != null ? new C0127a(b2, c0107j.f1675a.e()) : new C0127a(b2, str, c0107j.f1675a.e()), (List) c0107j.f1675a.getIntent().getSerializableExtra("dart_entrypoint_args"));
                }
                str = null;
                c0107j.f1675a.e();
                c0107j.f1676b.f1768i.f2655a.B("setInitialRoute", f2, null);
                b2 = c0107j.f1675a.b();
                if (b2 != null) {
                }
                b2 = ((C0189e) C0051b.A().f584g).f2305d.f2294b;
                c0107j.f1676b.f1762c.a(str != null ? new C0127a(b2, c0107j.f1675a.e()) : new C0127a(b2, str, c0107j.f1675a.e()), (List) c0107j.f1675a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            Integer num = c0107j.f1685k;
            if (num != null) {
                c0107j.f1677c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (k("onStop")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(5, c0205c.f2659c);
            }
            c0107j.f1685k = Integer.valueOf(c0107j.f1677c.getVisibility());
            c0107j.f1677c.setVisibility(8);
            C0115c c0115c2 = c0107j.f1676b;
            if (c0115c2 != null) {
                c0115c2.f1761b.b(40);
            }
        }
        this.f1669g.a(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (k("onTrimMemory")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                if (c0107j.f1683i && i2 >= 10) {
                    FlutterJNI flutterJNI = c0115c.f1762c.f1813e;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    C0204b c0204b = c0107j.f1676b.f1776q;
                    c0204b.getClass();
                    HashMap hashMap = new HashMap(1);
                    hashMap.put("type", "memoryPressure");
                    c0204b.f2656a.i(hashMap, null);
                }
                c0107j.f1676b.f1761b.b(i2);
                io.flutter.plugin.platform.k kVar = c0107j.f1676b.f1777s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                Iterator it = kVar.f2445m.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (k("onUserLeaveHint")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0117e c0117e = c0115c.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                Iterator it = ((HashSet) c0117e.f1794f.f1787e).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (k("onWindowFocusChanged")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                if (z2) {
                    c0205c.a(c0205c.f2657a, true);
                } else {
                    c0205c.a(c0205c.f2657a, false);
                }
            }
        }
    }
}
