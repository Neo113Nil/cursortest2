package c0;

import L.C0051b;
import android.view.KeyEvent;

/* loaded from: classes.dex */
public final class C {

    /* renamed from: a, reason: collision with root package name */
    public final KeyEvent f1636a;

    /* renamed from: b, reason: collision with root package name */
    public int f1637b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1638c = false;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0051b f1639d;

    public C(C0051b c0051b, KeyEvent keyEvent) {
        this.f1639d = c0051b;
        this.f1637b = ((D[]) c0051b.f584g).length;
        this.f1636a = keyEvent;
    }
}
