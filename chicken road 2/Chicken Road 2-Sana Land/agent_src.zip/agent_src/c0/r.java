package c0;

/* loaded from: classes.dex */
public final class r implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ io.flutter.embedding.engine.renderer.h f1707a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ androidx.lifecycle.k f1708b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ s f1709c;

    public r(s sVar, io.flutter.embedding.engine.renderer.h hVar, androidx.lifecycle.k kVar) {
        this.f1709c = sVar;
        this.f1707a = hVar;
        this.f1708b = kVar;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        C0108k c0108k;
        this.f1707a.c(this);
        this.f1708b.run();
        s sVar = this.f1709c;
        if ((sVar.f1722j instanceof C0108k) || (c0108k = sVar.f1721i) == null) {
            return;
        }
        c0108k.a();
        C0108k c0108k2 = sVar.f1721i;
        if (c0108k2 != null) {
            c0108k2.f1687e.close();
            sVar.removeView(sVar.f1721i);
            sVar.f1721i = null;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
    }
}
