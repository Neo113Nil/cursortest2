package c0;

/* loaded from: classes.dex */
public final class B {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1634a = false;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C f1635b;

    public B(C c2) {
        this.f1635b = c2;
    }

    public final void a(boolean z2) {
        if (this.f1634a) {
            throw new IllegalStateException("The onKeyEventHandledCallback should be called exactly once.");
        }
        this.f1634a = true;
        C c2 = this.f1635b;
        int i2 = c2.f1637b - 1;
        c2.f1637b = i2;
        boolean z3 = z2 | c2.f1638c;
        c2.f1638c = z3;
        if (i2 != 0 || z3) {
            return;
        }
        c2.f1639d.D(c2.f1636a);
    }
}
