package c0;

import L.C0051b;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import android.util.Log;
import android.util.SparseArray;
import d0.C0115c;
import d0.C0117e;
import d0.C0119g;
import d0.C0121i;
import d0.InterfaceC0114b;
import e0.C0127a;
import h0.C0189e;
import io.flutter.embedding.engine.FlutterJNI;
import j0.InterfaceC0193a;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import l0.C0205c;
import q0.C0248a;

/* renamed from: c0.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0107j {

    /* renamed from: a, reason: collision with root package name */
    public AbstractActivityC0103f f1675a;

    /* renamed from: b, reason: collision with root package name */
    public C0115c f1676b;

    /* renamed from: c, reason: collision with root package name */
    public s f1677c;

    /* renamed from: d, reason: collision with root package name */
    public io.flutter.plugin.platform.e f1678d;

    /* renamed from: e, reason: collision with root package name */
    public C0248a f1679e;

    /* renamed from: f, reason: collision with root package name */
    public ViewTreeObserverOnPreDrawListenerC0105h f1680f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1681g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1682h;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1684j;

    /* renamed from: k, reason: collision with root package name */
    public Integer f1685k;

    /* renamed from: l, reason: collision with root package name */
    public final C0104g f1686l = new C0104g(0, this);

    /* renamed from: i, reason: collision with root package name */
    public boolean f1683i = false;

    public C0107j(AbstractActivityC0103f abstractActivityC0103f) {
        this.f1675a = abstractActivityC0103f;
    }

    public final void a(C0119g c0119g) {
        String b2 = this.f1675a.b();
        if (b2 == null || b2.isEmpty()) {
            b2 = ((C0189e) C0051b.A().f584g).f2305d.f2294b;
        }
        C0127a c0127a = new C0127a(b2, this.f1675a.e());
        String f2 = this.f1675a.f();
        if (f2 == null) {
            AbstractActivityC0103f abstractActivityC0103f = this.f1675a;
            abstractActivityC0103f.getClass();
            f2 = d(abstractActivityC0103f.getIntent());
            if (f2 == null) {
                f2 = "/";
            }
        }
        c0119g.f1799b = c0127a;
        c0119g.f1800c = f2;
        c0119g.f1801d = (List) this.f1675a.getIntent().getSerializableExtra("dart_entrypoint_args");
    }

    public final void b() {
        if (this.f1675a.i()) {
            throw new AssertionError("The internal FlutterEngine created by " + this.f1675a + " has been attached to by another activity. To persist a FlutterEngine beyond the ownership of this activity, explicitly create a FlutterEngine");
        }
        AbstractActivityC0103f abstractActivityC0103f = this.f1675a;
        abstractActivityC0103f.getClass();
        Log.w("FlutterActivity", "FlutterActivity " + abstractActivityC0103f + " connection to the engine " + abstractActivityC0103f.f1668f.f1676b + " evicted by another attaching activity");
        C0107j c0107j = abstractActivityC0103f.f1668f;
        if (c0107j != null) {
            c0107j.e();
            abstractActivityC0103f.f1668f.f();
        }
    }

    public final void c() {
        if (this.f1675a == null) {
            throw new IllegalStateException("Cannot execute method on a destroyed FlutterActivityAndFragmentDelegate.");
        }
    }

    public final String d(Intent intent) {
        boolean z2;
        Uri data;
        AbstractActivityC0103f abstractActivityC0103f = this.f1675a;
        abstractActivityC0103f.getClass();
        try {
            Bundle g2 = abstractActivityC0103f.g();
            z2 = (g2 == null || !g2.containsKey("flutter_deeplinking_enabled")) ? true : g2.getBoolean("flutter_deeplinking_enabled");
        } catch (PackageManager.NameNotFoundException unused) {
            z2 = false;
        }
        if (!z2 || (data = intent.getData()) == null) {
            return null;
        }
        return data.toString();
    }

    public final void e() {
        c();
        if (this.f1680f != null) {
            this.f1677c.getViewTreeObserver().removeOnPreDrawListener(this.f1680f);
            this.f1680f = null;
        }
        s sVar = this.f1677c;
        if (sVar != null) {
            sVar.a();
            s sVar2 = this.f1677c;
            sVar2.f1724l.remove(this.f1686l);
        }
    }

    public final void f() {
        if (this.f1684j) {
            c();
            this.f1675a.getClass();
            this.f1675a.getClass();
            AbstractActivityC0103f abstractActivityC0103f = this.f1675a;
            abstractActivityC0103f.getClass();
            if (abstractActivityC0103f.isChangingConfigurations()) {
                C0117e c0117e = this.f1676b.f1763d;
                if (c0117e.f()) {
                    t0.a.b("FlutterEngineConnectionRegistry#detachFromActivityForConfigChanges");
                    try {
                        c0117e.f1795g = true;
                        for (p0.a aVar : c0117e.f1792d.values()) {
                            ((HashSet) aVar.f2786f.f1785c).remove(aVar);
                            aVar.f2786f = null;
                        }
                        c0117e.d();
                        Trace.endSection();
                    } finally {
                    }
                } else {
                    Log.e("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
                }
            } else {
                this.f1676b.f1763d.c();
            }
            io.flutter.plugin.platform.e eVar = this.f1678d;
            if (eVar != null) {
                eVar.f2420b.f579g = null;
                this.f1678d = null;
            }
            C0248a c0248a = this.f1679e;
            if (c0248a != null) {
                c0248a.f2791c.f2662f = null;
                c0248a.f2789a = null;
                this.f1679e = null;
            }
            this.f1675a.getClass();
            C0115c c0115c = this.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(1, c0205c.f2659c);
            }
            if (this.f1675a.i()) {
                C0115c c0115c2 = this.f1676b;
                FlutterJNI flutterJNI = c0115c2.f1760a;
                Iterator it = c0115c2.f1780v.iterator();
                while (it.hasNext()) {
                    ((InterfaceC0114b) it.next()).a();
                }
                C0117e c0117e2 = c0115c2.f1763d;
                c0117e2.e();
                HashMap hashMap = c0117e2.f1789a;
                Iterator it2 = new HashSet(hashMap.keySet()).iterator();
                while (it2.hasNext()) {
                    Class cls = (Class) it2.next();
                    InterfaceC0193a interfaceC0193a = (InterfaceC0193a) hashMap.get(cls);
                    if (interfaceC0193a != null) {
                        t0.a.b("FlutterEngineConnectionRegistry#remove ".concat(cls.getSimpleName()));
                        try {
                            if (interfaceC0193a instanceof p0.a) {
                                if (c0117e2.f()) {
                                    p0.a aVar2 = (p0.a) interfaceC0193a;
                                    ((HashSet) aVar2.f2786f.f1785c).remove(aVar2);
                                    aVar2.f2786f = null;
                                }
                                c0117e2.f1792d.remove(cls);
                            }
                            interfaceC0193a.a(c0117e2.f1791c);
                            hashMap.remove(cls);
                            Trace.endSection();
                        } finally {
                        }
                    }
                }
                hashMap.clear();
                io.flutter.plugin.platform.k kVar = c0115c2.f1777s;
                SparseArray sparseArray = kVar.f2447o;
                while (sparseArray.size() > 0) {
                    kVar.f2456y.u(sparseArray.keyAt(0));
                }
                io.flutter.plugin.platform.j jVar = c0115c2.f1778t;
                SparseArray sparseArray2 = jVar.f2430k;
                while (sparseArray2.size() > 0) {
                    jVar.f2436q.u(sparseArray2.keyAt(0));
                }
                c0115c2.f1762c.f1813e.setPlatformMessageHandler(null);
                flutterJNI.removeEngineLifecycleListener(c0115c2.f1782x);
                flutterJNI.setDeferredComponentManager(null);
                flutterJNI.detachFromNativeAndReleaseResources();
                C0051b.A().getClass();
                C0115c.f1759z.remove(Long.valueOf(c0115c2.f1781w));
                if (this.f1675a.d() != null) {
                    if (C0121i.f1806c == null) {
                        C0121i.f1806c = new C0121i(1);
                    }
                    C0121i c0121i = C0121i.f1806c;
                    c0121i.f1807a.remove(this.f1675a.d());
                }
                this.f1676b = null;
            }
            this.f1684j = false;
        }
    }
}
