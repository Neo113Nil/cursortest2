package w;

import android.graphics.Insets;
import android.view.WindowInsets;
import p.C0245c;

/* loaded from: classes.dex */
public class M extends L {

    /* renamed from: n, reason: collision with root package name */
    public C0245c f2998n;

    /* renamed from: o, reason: collision with root package name */
    public C0245c f2999o;

    /* renamed from: p, reason: collision with root package name */
    public C0245c f3000p;

    public M(Q q2, WindowInsets windowInsets) {
        super(q2, windowInsets);
        this.f2998n = null;
        this.f2999o = null;
        this.f3000p = null;
    }

    @Override // w.O
    public C0245c f() {
        Insets mandatorySystemGestureInsets;
        if (this.f2999o == null) {
            mandatorySystemGestureInsets = this.f2992c.getMandatorySystemGestureInsets();
            this.f2999o = C0245c.b(mandatorySystemGestureInsets);
        }
        return this.f2999o;
    }

    @Override // w.O
    public C0245c h() {
        Insets systemGestureInsets;
        if (this.f2998n == null) {
            systemGestureInsets = this.f2992c.getSystemGestureInsets();
            this.f2998n = C0245c.b(systemGestureInsets);
        }
        return this.f2998n;
    }

    @Override // w.O
    public C0245c j() {
        Insets tappableElementInsets;
        if (this.f3000p == null) {
            tappableElementInsets = this.f2992c.getTappableElementInsets();
            this.f3000p = C0245c.b(tappableElementInsets);
        }
        return this.f3000p;
    }

    @Override // w.J, w.O
    public void p(C0245c c0245c) {
    }
}
