package w;

import android.view.WindowInsets;
import p.C0245c;

/* renamed from: w.F, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0276F extends H {

    /* renamed from: a, reason: collision with root package name */
    public final WindowInsets.Builder f2986a = io.flutter.plugin.platform.i.c();

    @Override // w.H
    public Q b() {
        WindowInsets build;
        a();
        build = this.f2986a.build();
        Q a2 = Q.a(build, null);
        a2.f3004a.n(null);
        return a2;
    }

    @Override // w.H
    public void c(C0245c c0245c) {
        this.f2986a.setStableInsets(c0245c.c());
    }

    @Override // w.H
    public void d(C0245c c0245c) {
        this.f2986a.setSystemWindowInsets(c0245c.c());
    }
}
