package w;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* loaded from: classes.dex */
public class L extends J {
    public L(Q q2, WindowInsets windowInsets) {
        super(q2, windowInsets);
    }

    @Override // w.O
    public Q a() {
        WindowInsets consumeDisplayCutout;
        consumeDisplayCutout = this.f2992c.consumeDisplayCutout();
        return Q.a(consumeDisplayCutout, null);
    }

    @Override // w.O
    public C0281e e() {
        DisplayCutout displayCutout;
        displayCutout = this.f2992c.getDisplayCutout();
        if (displayCutout == null) {
            return null;
        }
        return new C0281e(displayCutout);
    }

    @Override // w.I, w.O
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof L)) {
            return false;
        }
        L l2 = (L) obj;
        return Objects.equals(this.f2992c, l2.f2992c) && Objects.equals(this.f2996g, l2.f2996g);
    }

    @Override // w.O
    public int hashCode() {
        return this.f2992c.hashCode();
    }
}
