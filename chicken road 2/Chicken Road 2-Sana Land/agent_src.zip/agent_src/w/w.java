package w;

/* loaded from: classes.dex */
public interface w {
}
