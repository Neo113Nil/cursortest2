package w;

import android.view.View;
import com.grid.of.lights.R;
import java.util.Objects;
import y.AbstractC0310a;

/* renamed from: w.t, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0295t {
    public static void a(View view, w wVar) {
        k.i iVar = (k.i) view.getTag(R.id.tag_unhandled_key_listeners);
        if (iVar == null) {
            iVar = new k.i();
            view.setTag(R.id.tag_unhandled_key_listeners, iVar);
        }
        Objects.requireNonNull(wVar);
        View.OnUnhandledKeyEventListener viewOnUnhandledKeyEventListenerC0294s = new ViewOnUnhandledKeyEventListenerC0294s();
        iVar.put(wVar, viewOnUnhandledKeyEventListenerC0294s);
        view.addOnUnhandledKeyEventListener(viewOnUnhandledKeyEventListenerC0294s);
    }

    public static CharSequence b(View view) {
        return view.getAccessibilityPaneTitle();
    }

    public static boolean c(View view) {
        return view.isAccessibilityHeading();
    }

    public static boolean d(View view) {
        return view.isScreenReaderFocusable();
    }

    public static void e(View view, w wVar) {
        View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
        k.i iVar = (k.i) view.getTag(R.id.tag_unhandled_key_listeners);
        if (iVar == null || (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) iVar.getOrDefault(wVar, null)) == null) {
            return;
        }
        view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
    }

    public static <T> T f(View view, int i2) {
        return (T) view.requireViewById(i2);
    }

    public static void g(View view, boolean z2) {
        view.setAccessibilityHeading(z2);
    }

    public static void h(View view, CharSequence charSequence) {
        view.setAccessibilityPaneTitle(charSequence);
    }

    public static void i(View view, AbstractC0310a abstractC0310a) {
        view.setAutofillId(null);
    }

    public static void j(View view, boolean z2) {
        view.setScreenReaderFocusable(z2);
    }
}
