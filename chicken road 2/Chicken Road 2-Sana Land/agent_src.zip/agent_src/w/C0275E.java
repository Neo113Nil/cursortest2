package w;

import android.graphics.Rect;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import p.C0245c;

/* renamed from: w.E, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0275E extends H {

    /* renamed from: c, reason: collision with root package name */
    public static Field f2980c = null;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f2981d = false;

    /* renamed from: e, reason: collision with root package name */
    public static Constructor f2982e = null;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f2983f = false;

    /* renamed from: a, reason: collision with root package name */
    public WindowInsets f2984a = e();

    /* renamed from: b, reason: collision with root package name */
    public C0245c f2985b;

    private static WindowInsets e() {
        if (!f2981d) {
            try {
                f2980c = WindowInsets.class.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e2) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
            }
            f2981d = true;
        }
        Field field = f2980c;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get(null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e3) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
            }
        }
        if (!f2983f) {
            try {
                f2982e = WindowInsets.class.getConstructor(Rect.class);
            } catch (ReflectiveOperationException e4) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
            }
            f2983f = true;
        }
        Constructor constructor = f2982e;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Rect());
            } catch (ReflectiveOperationException e5) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
            }
        }
        return null;
    }

    @Override // w.H
    public Q b() {
        a();
        Q a2 = Q.a(this.f2984a, null);
        O o2 = a2.f3004a;
        o2.n(null);
        o2.p(this.f2985b);
        return a2;
    }

    @Override // w.H
    public void c(C0245c c0245c) {
        this.f2985b = c0245c;
    }

    @Override // w.H
    public void d(C0245c c0245c) {
        WindowInsets windowInsets = this.f2984a;
        if (windowInsets != null) {
            this.f2984a = windowInsets.replaceSystemWindowInsets(c0245c.f2763a, c0245c.f2764b, c0245c.f2765c, c0245c.f2766d);
        }
    }
}
