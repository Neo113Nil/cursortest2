package w;

import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;

/* renamed from: w.D, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0274D {

    /* renamed from: a, reason: collision with root package name */
    public static final Field f2976a;

    /* renamed from: b, reason: collision with root package name */
    public static final Field f2977b;

    /* renamed from: c, reason: collision with root package name */
    public static final Field f2978c;

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f2979d;

    static {
        try {
            Field declaredField = View.class.getDeclaredField("mAttachInfo");
            f2976a = declaredField;
            declaredField.setAccessible(true);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            Field declaredField2 = cls.getDeclaredField("mStableInsets");
            f2977b = declaredField2;
            declaredField2.setAccessible(true);
            Field declaredField3 = cls.getDeclaredField("mContentInsets");
            f2978c = declaredField3;
            declaredField3.setAccessible(true);
            f2979d = true;
        } catch (ReflectiveOperationException e2) {
            Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e2.getMessage(), e2);
        }
    }
}
