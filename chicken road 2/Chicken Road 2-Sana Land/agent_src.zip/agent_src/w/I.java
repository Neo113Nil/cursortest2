package w;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import p.C0245c;

/* loaded from: classes.dex */
public abstract class I extends O {

    /* renamed from: h, reason: collision with root package name */
    public static boolean f2987h = false;

    /* renamed from: i, reason: collision with root package name */
    public static Method f2988i;

    /* renamed from: j, reason: collision with root package name */
    public static Class f2989j;

    /* renamed from: k, reason: collision with root package name */
    public static Field f2990k;

    /* renamed from: l, reason: collision with root package name */
    public static Field f2991l;

    /* renamed from: c, reason: collision with root package name */
    public final WindowInsets f2992c;

    /* renamed from: d, reason: collision with root package name */
    public C0245c[] f2993d;

    /* renamed from: e, reason: collision with root package name */
    public C0245c f2994e;

    /* renamed from: f, reason: collision with root package name */
    public Q f2995f;

    /* renamed from: g, reason: collision with root package name */
    public C0245c f2996g;

    public I(Q q2, WindowInsets windowInsets) {
        super(q2);
        this.f2994e = null;
        this.f2992c = windowInsets;
    }

    private C0245c r() {
        Q q2 = this.f2995f;
        return q2 != null ? q2.f3004a.g() : C0245c.f2762e;
    }

    private C0245c s(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
        if (!f2987h) {
            u();
        }
        Method method = f2988i;
        if (method != null && f2989j != null && f2990k != null) {
            try {
                Object invoke = method.invoke(view, null);
                if (invoke == null) {
                    Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    return null;
                }
                Rect rect = (Rect) f2990k.get(f2991l.get(invoke));
                if (rect != null) {
                    return C0245c.a(rect.left, rect.top, rect.right, rect.bottom);
                }
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
        }
        return null;
    }

    private static void u() {
        try {
            f2988i = View.class.getDeclaredMethod("getViewRootImpl", null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f2989j = cls;
            f2990k = cls.getDeclaredField("mVisibleInsets");
            f2991l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f2990k.setAccessible(true);
            f2991l.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f2987h = true;
    }

    @Override // w.O
    public void d(View view) {
        C0245c s2 = s(view);
        if (s2 == null) {
            s2 = C0245c.f2762e;
        }
        v(s2);
    }

    @Override // w.O
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            return Objects.equals(this.f2996g, ((I) obj).f2996g);
        }
        return false;
    }

    @Override // w.O
    public final C0245c i() {
        if (this.f2994e == null) {
            WindowInsets windowInsets = this.f2992c;
            this.f2994e = C0245c.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f2994e;
    }

    @Override // w.O
    public boolean l() {
        return this.f2992c.isRound();
    }

    @Override // w.O
    public boolean m(int i2) {
        for (int i3 = 1; i3 <= 256; i3 <<= 1) {
            if ((i2 & i3) != 0 && !t(i3)) {
                return false;
            }
        }
        return true;
    }

    @Override // w.O
    public void n(C0245c[] c0245cArr) {
        this.f2993d = c0245cArr;
    }

    @Override // w.O
    public void o(Q q2) {
        this.f2995f = q2;
    }

    public C0245c q(int i2, boolean z2) {
        C0245c g2;
        int i3;
        if (i2 == 1) {
            return z2 ? C0245c.a(0, Math.max(r().f2764b, i().f2764b), 0, 0) : C0245c.a(0, i().f2764b, 0, 0);
        }
        if (i2 == 2) {
            if (z2) {
                C0245c r = r();
                C0245c g3 = g();
                return C0245c.a(Math.max(r.f2763a, g3.f2763a), 0, Math.max(r.f2765c, g3.f2765c), Math.max(r.f2766d, g3.f2766d));
            }
            C0245c i4 = i();
            Q q2 = this.f2995f;
            g2 = q2 != null ? q2.f3004a.g() : null;
            int i5 = i4.f2766d;
            if (g2 != null) {
                i5 = Math.min(i5, g2.f2766d);
            }
            return C0245c.a(i4.f2763a, 0, i4.f2765c, i5);
        }
        C0245c c0245c = C0245c.f2762e;
        if (i2 == 8) {
            C0245c[] c0245cArr = this.f2993d;
            g2 = c0245cArr != null ? c0245cArr[3] : null;
            if (g2 != null) {
                return g2;
            }
            C0245c i6 = i();
            C0245c r2 = r();
            int i7 = i6.f2766d;
            if (i7 > r2.f2766d) {
                return C0245c.a(0, 0, 0, i7);
            }
            C0245c c0245c2 = this.f2996g;
            if (c0245c2 != null && !c0245c2.equals(c0245c) && (i3 = this.f2996g.f2766d) > r2.f2766d) {
                return C0245c.a(0, 0, 0, i3);
            }
        } else {
            if (i2 == 16) {
                return h();
            }
            if (i2 == 32) {
                return f();
            }
            if (i2 == 64) {
                return j();
            }
            if (i2 == 128) {
                Q q3 = this.f2995f;
                C0281e e2 = q3 != null ? q3.f3004a.e() : e();
                if (e2 != null) {
                    int i8 = Build.VERSION.SDK_INT;
                    return C0245c.a(i8 >= 28 ? AbstractC0280d.d(e2.f3020a) : 0, i8 >= 28 ? AbstractC0280d.f(e2.f3020a) : 0, i8 >= 28 ? AbstractC0280d.e(e2.f3020a) : 0, i8 >= 28 ? AbstractC0280d.c(e2.f3020a) : 0);
                }
            }
        }
        return c0245c;
    }

    public boolean t(int i2) {
        if (i2 != 1 && i2 != 2) {
            if (i2 == 4) {
                return false;
            }
            if (i2 != 8 && i2 != 128) {
                return true;
            }
        }
        return !q(i2, false).equals(C0245c.f2762e);
    }

    public void v(C0245c c0245c) {
        this.f2996g = c0245c;
    }
}
