package w;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: w.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0288l {

    /* renamed from: a, reason: collision with root package name */
    public static final Map f3026a = Collections.synchronizedMap(new WeakHashMap());
}
