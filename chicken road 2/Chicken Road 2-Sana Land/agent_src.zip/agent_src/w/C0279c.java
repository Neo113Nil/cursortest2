package w;

import android.content.Context;
import android.view.VelocityTracker;

/* renamed from: w.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0279c {

    /* renamed from: a, reason: collision with root package name */
    public final Context f3012a;

    /* renamed from: b, reason: collision with root package name */
    public final A.j f3013b;

    /* renamed from: c, reason: collision with root package name */
    public VelocityTracker f3014c;

    /* renamed from: d, reason: collision with root package name */
    public float f3015d;

    /* renamed from: e, reason: collision with root package name */
    public int f3016e = -1;

    /* renamed from: f, reason: collision with root package name */
    public int f3017f = -1;

    /* renamed from: g, reason: collision with root package name */
    public int f3018g = -1;

    /* renamed from: h, reason: collision with root package name */
    public final int[] f3019h = {Integer.MAX_VALUE, 0};

    public C0279c(Context context, A.j jVar) {
        this.f3012a = context;
        this.f3013b = jVar;
    }
}
