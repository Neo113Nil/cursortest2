package w;

import android.view.WindowInsets;
import p.C0245c;

/* loaded from: classes.dex */
public class J extends I {

    /* renamed from: m, reason: collision with root package name */
    public C0245c f2997m;

    public J(Q q2, WindowInsets windowInsets) {
        super(q2, windowInsets);
        this.f2997m = null;
    }

    @Override // w.O
    public Q b() {
        return Q.a(this.f2992c.consumeStableInsets(), null);
    }

    @Override // w.O
    public Q c() {
        return Q.a(this.f2992c.consumeSystemWindowInsets(), null);
    }

    @Override // w.O
    public final C0245c g() {
        if (this.f2997m == null) {
            WindowInsets windowInsets = this.f2992c;
            this.f2997m = C0245c.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f2997m;
    }

    @Override // w.O
    public boolean k() {
        return this.f2992c.isConsumed();
    }

    @Override // w.O
    public void p(C0245c c0245c) {
        this.f2997m = c0245c;
    }
}
