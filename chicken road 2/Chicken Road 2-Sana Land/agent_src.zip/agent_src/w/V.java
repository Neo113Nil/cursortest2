package w;

import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class V extends AbstractC0230j {

    /* renamed from: a, reason: collision with root package name */
    public final WindowInsetsController f3006a;

    /* renamed from: b, reason: collision with root package name */
    public final Window f3007b;

    public V(Window window) {
        WindowInsetsController insetsController;
        insetsController = window.getInsetsController();
        this.f3006a = insetsController;
        this.f3007b = window;
    }

    @Override // m0.AbstractC0230j
    public final void x(boolean z2) {
        Window window = this.f3007b;
        if (z2) {
            if (window != null) {
                View decorView = window.getDecorView();
                decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 16);
            }
            this.f3006a.setSystemBarsAppearance(16, 16);
            return;
        }
        if (window != null) {
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() & (-17));
        }
        this.f3006a.setSystemBarsAppearance(0, 16);
    }

    @Override // m0.AbstractC0230j
    public final void y(boolean z2) {
        Window window = this.f3007b;
        if (z2) {
            if (window != null) {
                View decorView = window.getDecorView();
                decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 8192);
            }
            this.f3006a.setSystemBarsAppearance(8, 8);
            return;
        }
        if (window != null) {
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() & (-8193));
        }
        this.f3006a.setSystemBarsAppearance(0, 8);
    }
}
