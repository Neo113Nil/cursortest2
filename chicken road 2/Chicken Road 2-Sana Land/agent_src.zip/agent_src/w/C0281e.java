package w;

import android.view.DisplayCutout;
import java.util.Objects;

/* renamed from: w.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0281e {

    /* renamed from: a, reason: collision with root package name */
    public final DisplayCutout f3020a;

    public C0281e(DisplayCutout displayCutout) {
        this.f3020a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0281e.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f3020a, ((C0281e) obj).f3020a);
    }

    public final int hashCode() {
        int hashCode;
        hashCode = this.f3020a.hashCode();
        return hashCode;
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f3020a + "}";
    }
}
