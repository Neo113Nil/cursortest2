package w;

import android.view.View;
import android.view.Window;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public class S extends AbstractC0230j {

    /* renamed from: a, reason: collision with root package name */
    public final Window f3005a;

    public S(Window window) {
        this.f3005a = window;
    }

    @Override // m0.AbstractC0230j
    public final void y(boolean z2) {
        Window window = this.f3005a;
        if (!z2) {
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & (-8193));
        } else {
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() | 8192);
        }
    }
}
