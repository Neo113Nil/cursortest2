package w;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/* renamed from: w.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ViewOnApplyWindowInsetsListenerC0291o implements View.OnApplyWindowInsetsListener {

    /* renamed from: a, reason: collision with root package name */
    public Q f3032a = null;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f3033b;

    public ViewOnApplyWindowInsetsListenerC0291o(View view, InterfaceC0286j interfaceC0286j) {
        this.f3033b = view;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        Q a2 = Q.a(windowInsets, view);
        if (Build.VERSION.SDK_INT < 30) {
            AbstractC0292p.a(windowInsets, this.f3033b);
            if (a2.equals(this.f3032a)) {
                throw null;
            }
        }
        this.f3032a = a2;
        throw null;
    }
}
