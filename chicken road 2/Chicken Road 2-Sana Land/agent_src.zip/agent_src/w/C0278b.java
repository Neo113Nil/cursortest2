package w;

import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.grid.of.lights.R;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import x.C0300c;
import x.C0305h;

/* renamed from: w.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0278b {

    /* renamed from: c, reason: collision with root package name */
    public static final View.AccessibilityDelegate f3009c = new View.AccessibilityDelegate();

    /* renamed from: a, reason: collision with root package name */
    public final View.AccessibilityDelegate f3010a = f3009c;

    /* renamed from: b, reason: collision with root package name */
    public final C0277a f3011b = new C0277a(this);

    public void a(View view, AccessibilityEvent accessibilityEvent) {
        this.f3010a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void b(View view, C0305h c0305h) {
        this.f3010a.onInitializeAccessibilityNodeInfo(view, c0305h.f3052a);
    }

    public boolean c(View view, int i2, Bundle bundle) {
        WeakReference weakReference;
        ClickableSpan clickableSpan;
        List list = (List) view.getTag(R.id.tag_accessibility_actions);
        if (list == null) {
            list = Collections.EMPTY_LIST;
        }
        for (int i3 = 0; i3 < list.size() && ((AccessibilityNodeInfo.AccessibilityAction) ((C0300c) list.get(i3)).f3048a).getId() != i2; i3++) {
        }
        boolean performAccessibilityAction = this.f3010a.performAccessibilityAction(view, i2, bundle);
        if (performAccessibilityAction || i2 != R.id.accessibility_action_clickable_span || bundle == null) {
            return performAccessibilityAction;
        }
        int i4 = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
        SparseArray sparseArray = (SparseArray) view.getTag(R.id.tag_accessibility_clickable_spans);
        if (sparseArray != null && (weakReference = (WeakReference) sparseArray.get(i4)) != null && (clickableSpan = (ClickableSpan) weakReference.get()) != null) {
            CharSequence text = view.createAccessibilityNodeInfo().getText();
            ClickableSpan[] clickableSpanArr = text instanceof Spanned ? (ClickableSpan[]) ((Spanned) text).getSpans(0, text.length(), ClickableSpan.class) : null;
            for (int i5 = 0; clickableSpanArr != null && i5 < clickableSpanArr.length; i5++) {
                if (clickableSpan.equals(clickableSpanArr[i5])) {
                    clickableSpan.onClick(view);
                    return true;
                }
            }
        }
        return false;
    }
}
