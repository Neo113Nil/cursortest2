package w;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import java.lang.reflect.Field;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public abstract class x {

    /* renamed from: a, reason: collision with root package name */
    public static Field f3034a = null;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f3035b = false;

    static {
        new WeakHashMap();
    }

    public static void a(ViewGroup viewGroup, C0278b c0278b) {
        View.AccessibilityDelegate accessibilityDelegate;
        if (c0278b == null) {
            if (Build.VERSION.SDK_INT >= 29) {
                accessibilityDelegate = AbstractC0296u.a(viewGroup);
            } else {
                if (!f3035b) {
                    if (f3034a == null) {
                        try {
                            Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                            f3034a = declaredField;
                            declaredField.setAccessible(true);
                        } catch (Throwable unused) {
                            f3035b = true;
                        }
                    }
                    try {
                        Object obj = f3034a.get(viewGroup);
                        if (obj instanceof View.AccessibilityDelegate) {
                            accessibilityDelegate = (View.AccessibilityDelegate) obj;
                        }
                    } catch (Throwable unused2) {
                        f3035b = true;
                    }
                }
                accessibilityDelegate = null;
            }
            if (accessibilityDelegate instanceof C0277a) {
                c0278b = new C0278b();
            }
        }
        if (viewGroup.getImportantForAccessibility() == 0) {
            viewGroup.setImportantForAccessibility(1);
        }
        viewGroup.setAccessibilityDelegate(c0278b != null ? c0278b.f3011b : null);
    }
}
