package w;

import p.C0245c;

/* loaded from: classes.dex */
public abstract class H {
    public H() {
        this(new Q());
    }

    public abstract Q b();

    public abstract void c(C0245c c0245c);

    public abstract void d(C0245c c0245c);

    public H(Q q2) {
    }

    public final void a() {
    }
}
