package u0;

import E0.i;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class c implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final Throwable f2959e;

    public c(Throwable th) {
        i.e(th, "exception");
        this.f2959e = th;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof c) {
            return i.a(this.f2959e, ((c) obj).f2959e);
        }
        return false;
    }

    public final int hashCode() {
        return this.f2959e.hashCode();
    }

    public final String toString() {
        return "Failure(" + this.f2959e + ')';
    }
}
