package u0;

import E0.i;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class e implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public D0.a f2960e;

    /* renamed from: f, reason: collision with root package name */
    public volatile Object f2961f = f.f2963a;

    /* renamed from: g, reason: collision with root package name */
    public final Object f2962g = this;

    public e(D0.a aVar) {
        this.f2960e = aVar;
    }

    public final Object a() {
        Object obj;
        Object obj2 = this.f2961f;
        f fVar = f.f2963a;
        if (obj2 != fVar) {
            return obj2;
        }
        synchronized (this.f2962g) {
            obj = this.f2961f;
            if (obj == fVar) {
                D0.a aVar = this.f2960e;
                i.b(aVar);
                obj = aVar.b();
                this.f2961f = obj;
                this.f2960e = null;
            }
        }
        return obj;
    }

    public final String toString() {
        return this.f2961f != f.f2963a ? String.valueOf(a()) : "Lazy value not initialized yet.";
    }
}
