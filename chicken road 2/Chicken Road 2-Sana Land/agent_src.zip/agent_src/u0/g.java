package u0;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public static final g f2964a = new g();

    public final String toString() {
        return "kotlin.Unit";
    }
}
