package u0;

import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class d implements Serializable {
    public static final Throwable a(Object obj) {
        if (obj instanceof c) {
            return ((c) obj).f2959e;
        }
        return null;
    }
}
