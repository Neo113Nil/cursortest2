package u0;

import E0.i;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class b implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final Object f2957e;

    /* renamed from: f, reason: collision with root package name */
    public final Object f2958f;

    public b(Object obj, Object obj2) {
        this.f2957e = obj;
        this.f2958f = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return i.a(this.f2957e, bVar.f2957e) && i.a(this.f2958f, bVar.f2958f);
    }

    public final int hashCode() {
        Object obj = this.f2957e;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f2958f;
        return hashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        return "(" + this.f2957e + ", " + this.f2958f + ')';
    }
}
