package q0;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import c0.AbstractActivityC0103f;
import l0.C0206d;

/* renamed from: q0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0248a {

    /* renamed from: a, reason: collision with root package name */
    public Activity f2789a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2790b;

    /* renamed from: c, reason: collision with root package name */
    public final C0206d f2791c;

    public C0248a(int i2, AbstractActivityC0103f abstractActivityC0103f, C0206d c0206d) {
        this.f2789a = abstractActivityC0103f;
        this.f2790b = i2;
        this.f2791c = c0206d;
        c0206d.f2662f = this;
    }

    public final int a() {
        int contentSensitivity;
        if (Build.VERSION.SDK_INT < 35) {
            return 2;
        }
        Activity activity = this.f2789a;
        int i2 = this.f2790b;
        View findViewById = activity.findViewById(i2);
        if (findViewById != null) {
            contentSensitivity = findViewById.getContentSensitivity();
            return contentSensitivity;
        }
        throw new IllegalArgumentException("FlutterView with ID " + i2 + "not found");
    }

    public final void b(int i2) {
        int contentSensitivity;
        if (Build.VERSION.SDK_INT < 35) {
            throw new IllegalStateException("isSupported() should be called before attempting to set content sensitivity as it is not supported on this device.");
        }
        Activity activity = this.f2789a;
        int i3 = this.f2790b;
        View findViewById = activity.findViewById(i3);
        if (findViewById == null) {
            throw new IllegalArgumentException("FlutterView with ID " + i3 + "not found");
        }
        contentSensitivity = findViewById.getContentSensitivity();
        if (contentSensitivity == i2) {
            return;
        }
        findViewById.setContentSensitivity(i2);
        findViewById.invalidate();
    }
}
