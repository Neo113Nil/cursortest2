package L;

import android.view.animation.Interpolator;
import android.widget.OverScroller;
import androidx.recyclerview.widget.RecyclerView;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public final class I implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public int f542e;

    /* renamed from: f, reason: collision with root package name */
    public int f543f;

    /* renamed from: g, reason: collision with root package name */
    public OverScroller f544g;

    /* renamed from: h, reason: collision with root package name */
    public Interpolator f545h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f546i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f547j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f548k;

    public I(RecyclerView recyclerView) {
        this.f548k = recyclerView;
        r rVar = RecyclerView.f1540o0;
        this.f545h = rVar;
        this.f546i = false;
        this.f547j = false;
        this.f544g = new OverScroller(recyclerView.getContext(), rVar);
    }

    public final void a() {
        if (this.f546i) {
            this.f547j = true;
            return;
        }
        RecyclerView recyclerView = this.f548k;
        recyclerView.removeCallbacks(this);
        Field field = w.x.f3034a;
        recyclerView.postOnAnimation(this);
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2;
        int i3;
        boolean awakenScrollBars;
        RecyclerView recyclerView = this.f548k;
        if (recyclerView.f1580m == null) {
            recyclerView.removeCallbacks(this);
            this.f544g.abortAnimation();
            return;
        }
        this.f547j = false;
        this.f546i = true;
        recyclerView.d();
        OverScroller overScroller = this.f544g;
        recyclerView.f1580m.getClass();
        if (overScroller.computeScrollOffset()) {
            int[] iArr = recyclerView.f1574h0;
            int currX = overScroller.getCurrX();
            int currY = overScroller.getCurrY();
            int i4 = currX - this.f542e;
            int i5 = currY - this.f543f;
            this.f542e = currX;
            this.f543f = currY;
            if (recyclerView.f(i4, i5, iArr, null, 1)) {
                i2 = i4 - iArr[0];
                i3 = i5 - iArr[1];
            } else {
                i2 = i4;
                i3 = i5;
            }
            if (!recyclerView.f1581n.isEmpty()) {
                recyclerView.invalidate();
            }
            if (recyclerView.getOverScrollMode() != 2) {
                recyclerView.c(i2, i3);
            }
            recyclerView.g(null, 1);
            awakenScrollBars = recyclerView.awakenScrollBars();
            if (!awakenScrollBars) {
                recyclerView.invalidate();
            }
            boolean z2 = (i2 == 0 && i3 == 0) || (i2 != 0 && recyclerView.f1580m.b() && i2 == 0) || (i3 != 0 && recyclerView.f1580m.c() && i3 == 0);
            if (overScroller.isFinished() || !(z2 || recyclerView.k())) {
                recyclerView.setScrollState(0);
                C0059j c0059j = recyclerView.f1563a0;
                c0059j.getClass();
                c0059j.f628c = 0;
                recyclerView.s(1);
            } else {
                a();
                RunnableC0061l runnableC0061l = recyclerView.f1562W;
                if (runnableC0061l != null) {
                    runnableC0061l.a(recyclerView, i2, i3);
                }
            }
        }
        this.f546i = false;
        if (this.f547j) {
            a();
        }
    }
}
