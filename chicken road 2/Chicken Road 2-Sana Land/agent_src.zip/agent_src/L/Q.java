package L;

import D.C0016q;
import D.C0017s;
import D.C0018t;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import c.AbstractC0096a;
import c0.C0097A;
import d.AbstractC0112a;
import d0.C0122j;
import e0.C0128b;
import e0.C0133g;
import h.AbstractC0183y;
import h.C0174o;
import h.C0177s;
import h.j0;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.ReentrantLock;
import l0.C0204b;
import l0.C0206d;
import l0.C0208f;
import l0.C0210h;
import l0.C0211i;
import l0.C0213k;
import l0.C0215m;
import l0.EnumC0209g;
import l0.InterfaceC0212j;
import m0.AbstractC0230j;
import m0.C0229i;
import m0.C0236p;
import m0.InterfaceC0222b;
import m0.InterfaceC0223c;
import m0.InterfaceC0224d;
import m0.InterfaceC0231k;
import m0.InterfaceC0232l;
import m0.InterfaceC0233m;
import o0.InterfaceC0242a;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import s0.C0267n;

/* loaded from: classes.dex */
public final class Q implements M0.d, U.h, c0.D, io.flutter.plugin.platform.h, InterfaceC0212j, InterfaceC0232l, InterfaceC0223c, InterfaceC0224d {

    /* renamed from: h, reason: collision with root package name */
    public static Q f575h;

    /* renamed from: i, reason: collision with root package name */
    public static c0.F f576i;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f577e;

    /* renamed from: f, reason: collision with root package name */
    public Object f578f;

    /* renamed from: g, reason: collision with root package name */
    public Object f579g;

    public /* synthetic */ Q(int i2, Object obj, Object obj2) {
        this.f577e = i2;
        this.f578f = obj;
        this.f579g = obj2;
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x0081 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0080 A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int o(Q q2, JSONArray jSONArray) {
        String str;
        int i2 = 0;
        int i3 = 0;
        for (int i4 = 0; i4 < jSONArray.length(); i4++) {
            String string = jSONArray.getString(i4);
            for (int i5 : F.i.b(4)) {
                if (i5 == 1) {
                    str = "DeviceOrientation.portraitUp";
                } else if (i5 == 2) {
                    str = "DeviceOrientation.portraitDown";
                } else if (i5 == 3) {
                    str = "DeviceOrientation.landscapeLeft";
                } else {
                    if (i5 != 4) {
                        throw null;
                    }
                    str = "DeviceOrientation.landscapeRight";
                }
                if (str.equals(string)) {
                    int a2 = F.i.a(i5);
                    if (a2 == 0) {
                        i2 |= 1;
                    } else if (a2 == 1) {
                        i2 |= 4;
                    } else if (a2 == 2) {
                        i2 |= 2;
                    } else if (a2 == 3) {
                        i2 |= 8;
                    }
                    if (i3 == 0) {
                        i3 = i2;
                    }
                }
            }
            throw new NoSuchFieldException(E0.h.g("No such DeviceOrientation: ", string));
        }
        if (i2 == 0) {
            return -1;
        }
        switch (i2) {
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                return 0;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
            case 9:
            case 12:
            case 13:
            case 14:
                if (i3 == 2) {
                    return 0;
                }
                if (i3 != 4) {
                    return i3 != 8 ? 1 : 8;
                }
                return 9;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                return 9;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                return 12;
            case 10:
                return 11;
            case 11:
                return 2;
            case 15:
                return 13;
        }
    }

    public static ArrayList p(Q q2, JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            String string = jSONArray.getString(i2);
            for (EnumC0209g enumC0209g : EnumC0209g.values()) {
                if (enumC0209g.f2675e.equals(string)) {
                    int ordinal = enumC0209g.ordinal();
                    if (ordinal == 0) {
                        arrayList.add(EnumC0209g.f2672f);
                    } else if (ordinal == 1) {
                        arrayList.add(EnumC0209g.f2673g);
                    }
                }
            }
            throw new NoSuchFieldException(E0.h.g("No such SystemUiOverlay: ", string));
        }
        return arrayList;
    }

    public static int r(Q q2, String str) {
        String str2;
        for (int i2 : F.i.b(4)) {
            if (i2 == 1) {
                str2 = "SystemUiMode.leanBack";
            } else if (i2 == 2) {
                str2 = "SystemUiMode.immersive";
            } else if (i2 == 3) {
                str2 = "SystemUiMode.immersiveSticky";
            } else {
                if (i2 != 4) {
                    throw null;
                }
                str2 = "SystemUiMode.edgeToEdge";
            }
            if (str2.equals(str)) {
                int a2 = F.i.a(i2);
                if (a2 == 0) {
                    return 1;
                }
                if (a2 != 1) {
                    return a2 != 2 ? 4 : 3;
                }
                return 2;
            }
        }
        throw new NoSuchFieldException(E0.h.g("No such SystemUiMode: ", str));
    }

    public static C0208f s(Q q2, JSONObject jSONObject) {
        return new C0208f(!jSONObject.isNull("statusBarColor") ? Integer.valueOf(jSONObject.getInt("statusBarColor")) : null, !jSONObject.isNull("statusBarIconBrightness") ? E0.h.a(jSONObject.getString("statusBarIconBrightness")) : 0, !jSONObject.isNull("systemStatusBarContrastEnforced") ? Boolean.valueOf(jSONObject.getBoolean("systemStatusBarContrastEnforced")) : null, !jSONObject.isNull("systemNavigationBarColor") ? Integer.valueOf(jSONObject.getInt("systemNavigationBarColor")) : null, jSONObject.isNull("systemNavigationBarIconBrightness") ? 0 : E0.h.a(jSONObject.getString("systemNavigationBarIconBrightness")), !jSONObject.isNull("systemNavigationBarDividerColor") ? Integer.valueOf(jSONObject.getInt("systemNavigationBarDividerColor")) : null, jSONObject.isNull("systemNavigationBarContrastEnforced") ? null : Boolean.valueOf(jSONObject.getBoolean("systemNavigationBarContrastEnforced")));
    }

    public static HashMap x(String str, int i2, int i3, int i4, int i5) {
        HashMap hashMap = new HashMap();
        hashMap.put("text", str);
        hashMap.put("selectionBase", Integer.valueOf(i2));
        hashMap.put("selectionExtent", Integer.valueOf(i3));
        hashMap.put("composingBase", Integer.valueOf(i4));
        hashMap.put("composingExtent", Integer.valueOf(i5));
        return hashMap;
    }

    public void A(t.f fVar) {
        Handler handler = (Handler) this.f579g;
        C0206d c0206d = (C0206d) this.f578f;
        int i2 = fVar.f2939b;
        if (i2 == 0) {
            handler.post(new O0.g(c0206d, fVar.f2938a, 3, false));
        } else {
            handler.post(new A.b(c0206d, i2));
        }
    }

    @Override // io.flutter.plugin.platform.h
    public void a(io.flutter.view.i iVar) {
        ((io.flutter.plugin.platform.k) this.f578f).f2444l.f2413a = iVar;
        ((io.flutter.plugin.platform.j) this.f579g).f2429j.f2413a = iVar;
    }

    @Override // l0.InterfaceC0212j
    public long b(C0177s c0177s) {
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.b(c0177s);
        throw null;
    }

    @Override // l0.InterfaceC0212j
    public void c(boolean z2) {
        ((io.flutter.plugin.platform.k) ((io.flutter.plugin.platform.k) this.f578f).f2456y.f30f).f2452u = z2;
    }

    @Override // io.flutter.plugin.platform.h
    public boolean d(int i2) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        return ((io.flutter.plugin.platform.k) this.f578f).d(i2);
    }

    @Override // l0.InterfaceC0212j
    public void e(int i2, double d2, double d3) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.e(i2, d2, d3);
    }

    @Override // l0.InterfaceC0212j
    public void f(int i2, int i3) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.f(i2, i3);
    }

    @Override // io.flutter.plugin.platform.h
    public void g(int i2) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        ((io.flutter.plugin.platform.k) this.f578f).g(i2);
    }

    @Override // m0.InterfaceC0224d
    public void h(ByteBuffer byteBuffer, C0133g c0133g) {
        switch (this.f577e) {
            case 21:
                C0016q c0016q = (C0016q) this.f579g;
                try {
                    ((InterfaceC0222b) this.f578f).l(((InterfaceC0231k) c0016q.f248c).b(byteBuffer), new Q(this, c0133g, 20, false));
                    break;
                } catch (RuntimeException e2) {
                    Log.e("BasicMessageChannel#" + ((String) c0016q.f247b), "Failed to handle message", e2);
                    c0133g.a(null);
                    return;
                }
            default:
                C0051b c0051b = (C0051b) this.f579g;
                InterfaceC0233m interfaceC0233m = (InterfaceC0233m) c0051b.f585h;
                try {
                    ((InterfaceC0232l) this.f578f).q(interfaceC0233m.e(byteBuffer), new C0213k(1, this, c0133g));
                    break;
                } catch (RuntimeException e3) {
                    Log.e("MethodChannel#".concat((String) c0051b.f583f), "Failed to handle method call", e3);
                    c0133g.a(interfaceC0233m.b(e3.getMessage(), Log.getStackTraceString(e3)));
                }
        }
    }

    @Override // l0.InterfaceC0212j
    public void i(C0211i c0211i, C0122j c0122j) {
        ((io.flutter.plugin.platform.j) this.f579g).g(c0211i.f2692a);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.i(c0211i, c0122j);
    }

    @Override // io.flutter.plugin.platform.h
    public void j() {
        ((io.flutter.plugin.platform.k) this.f578f).j();
        ((io.flutter.plugin.platform.j) this.f579g).j();
    }

    @Override // l0.InterfaceC0212j
    public void k(C0210h c0210h) {
        ((io.flutter.plugin.platform.j) this.f579g).g(c0210h.f2676a);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.k(c0210h);
    }

    @Override // c0.D
    public void l(KeyEvent keyEvent, final c0.B b2) {
        int action = keyEvent.getAction();
        if (action != 0 && action != 1) {
            b2.a(false);
            return;
        }
        Character a2 = ((C0097A) this.f579g).a(keyEvent.getUnicodeChar());
        boolean z2 = action != 0;
        C0204b c0204b = (C0204b) this.f578f;
        final InterfaceC0223c interfaceC0223c = new InterfaceC0223c() { // from class: c0.v
            @Override // m0.InterfaceC0223c
            public void n(Object obj) {
                v vVar = (v) b2;
                boolean z3 = false;
                if (obj != null) {
                    try {
                        z3 = ((JSONObject) obj).getBoolean("handled");
                    } catch (JSONException e2) {
                        Log.e("KeyEventChannel", "Unable to unpack JSON message: " + e2);
                    }
                }
                ((B) b2).a(z3);
            }
        };
        C0016q c0016q = c0204b.f2656a;
        HashMap hashMap = new HashMap();
        hashMap.put("type", z2 ? "keyup" : "keydown");
        hashMap.put("keymap", "android");
        hashMap.put("flags", Integer.valueOf(keyEvent.getFlags()));
        hashMap.put("plainCodePoint", Integer.valueOf(keyEvent.getUnicodeChar(0)));
        hashMap.put("codePoint", Integer.valueOf(keyEvent.getUnicodeChar()));
        hashMap.put("keyCode", Integer.valueOf(keyEvent.getKeyCode()));
        hashMap.put("scanCode", Integer.valueOf(keyEvent.getScanCode()));
        hashMap.put("metaState", Integer.valueOf(keyEvent.getMetaState()));
        hashMap.put("character", a2.toString());
        hashMap.put("source", Integer.valueOf(keyEvent.getSource()));
        hashMap.put("deviceId", Integer.valueOf(keyEvent.getDeviceId()));
        hashMap.put("repeatCount", Integer.valueOf(keyEvent.getRepeatCount()));
        c0016q.i(hashMap, new InterfaceC0223c() { // from class: c0.v
            @Override // m0.InterfaceC0223c
            public void n(Object obj) {
                v vVar = (v) interfaceC0223c;
                boolean z3 = false;
                if (obj != null) {
                    try {
                        z3 = ((JSONObject) obj).getBoolean("handled");
                    } catch (JSONException e2) {
                        Log.e("KeyEventChannel", "Unable to unpack JSON message: " + e2);
                    }
                }
                ((B) interfaceC0223c).a(z3);
            }
        });
    }

    @Override // l0.InterfaceC0212j
    public void m(int i2) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.m(i2);
    }

    @Override // m0.InterfaceC0223c
    public void n(Object obj) {
        switch (this.f577e) {
            case 18:
                C0051b c0051b = (C0051b) this.f579g;
                ConcurrentLinkedQueue concurrentLinkedQueue = (ConcurrentLinkedQueue) c0051b.f584g;
                C0215m c0215m = (C0215m) this.f578f;
                concurrentLinkedQueue.remove(c0215m);
                if (!((ConcurrentLinkedQueue) c0051b.f584g).isEmpty()) {
                    Log.e("SettingsChannel", "The queue becomes empty after removing config generation " + c0215m.f2705a);
                    break;
                }
                break;
            default:
                ((C0133g) this.f578f).a(((InterfaceC0231k) ((C0016q) ((Q) this.f579g).f579g).f248c).a(obj));
                break;
        }
    }

    @Override // m0.InterfaceC0232l
    public void q(Q q2, C0213k c0213k) {
        A.j jVar = (A.j) this.f579g;
        if (((C0051b) jVar.f30f) == null) {
            c0213k.d((Map) this.f578f);
            return;
        }
        String str = (String) q2.f578f;
        str.getClass();
        if (!str.equals("getKeyboardState")) {
            c0213k.b();
            return;
        }
        try {
            this.f578f = Collections.unmodifiableMap(((c0.z) ((c0.D[]) ((C0051b) jVar.f30f).f584g)[0]).f1753f);
        } catch (IllegalStateException e2) {
            c0213k.a("error", e2.getMessage(), null);
        }
        c0213k.d((Map) this.f578f);
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:58:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00b9  */
    @Override // M0.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object t(M0.e eVar, w0.c cVar) {
        M0.j jVar;
        int i2;
        x0.a aVar;
        Throwable th;
        N0.l lVar;
        Q q2;
        M0.e eVar2;
        M0.d dVar;
        M0.m mVar;
        int i3;
        C0267n c0267n;
        switch (this.f577e) {
            case 1:
                if (cVar instanceof M0.j) {
                    jVar = (M0.j) cVar;
                    int i4 = jVar.f750i;
                    if ((i4 & Integer.MIN_VALUE) != 0) {
                        jVar.f750i = i4 - Integer.MIN_VALUE;
                        Object obj = jVar.f749h;
                        i2 = jVar.f750i;
                        aVar = x0.a.f3053e;
                        if (i2 != 0) {
                            AbstractC0230j.A(obj);
                            w0.h hVar = jVar.f3057f;
                            E0.i.b(hVar);
                            N0.l lVar2 = new N0.l(eVar, hVar);
                            try {
                                D.r rVar = (D.r) this.f578f;
                                jVar.f752k = this;
                                jVar.f753l = eVar;
                                jVar.f754m = lVar2;
                                jVar.f750i = 1;
                                if (rVar.h(lVar2, jVar) == aVar) {
                                    return aVar;
                                }
                                q2 = this;
                                eVar2 = eVar;
                                lVar = lVar2;
                            } catch (Throwable th2) {
                                th = th2;
                                lVar = lVar2;
                                lVar.o();
                                throw th;
                            }
                        } else {
                            if (i2 != 1) {
                                if (i2 != 2) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                AbstractC0230j.A(obj);
                                return u0.g.f2964a;
                            }
                            lVar = jVar.f754m;
                            eVar2 = jVar.f753l;
                            q2 = jVar.f752k;
                            try {
                                AbstractC0230j.A(obj);
                            } catch (Throwable th3) {
                                th = th3;
                                lVar.o();
                                throw th;
                            }
                        }
                        lVar.o();
                        dVar = (M0.d) q2.f579g;
                        jVar.f752k = null;
                        jVar.f753l = null;
                        jVar.f754m = null;
                        jVar.f750i = 2;
                        if (dVar.t(eVar2, jVar) == aVar) {
                            return aVar;
                        }
                        return u0.g.f2964a;
                    }
                }
                jVar = new M0.j(this, cVar);
                Object obj2 = jVar.f749h;
                i2 = jVar.f750i;
                aVar = x0.a.f3053e;
                if (i2 != 0) {
                }
                lVar.o();
                dVar = (M0.d) q2.f579g;
                jVar.f752k = null;
                jVar.f753l = null;
                jVar.f754m = null;
                jVar.f750i = 2;
                if (dVar.t(eVar2, jVar) == aVar) {
                }
                return u0.g.f2964a;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                Object t2 = ((Q) this.f578f).t(new M0.l(new E0.n(), eVar, (C0018t) this.f579g), cVar);
                return t2 == x0.a.f3053e ? t2 : u0.g.f2964a;
            default:
                if (cVar instanceof M0.m) {
                    mVar = (M0.m) cVar;
                    int i5 = mVar.f765i;
                    if ((i5 & Integer.MIN_VALUE) != 0) {
                        mVar.f765i = i5 - Integer.MIN_VALUE;
                        Object obj3 = mVar.f764h;
                        i3 = mVar.f765i;
                        if (i3 != 0) {
                            AbstractC0230j.A(obj3);
                            Q q3 = (Q) this.f578f;
                            C0267n c0267n2 = new C0267n((C0017s) this.f579g, eVar);
                            try {
                                mVar.f767k = c0267n2;
                                mVar.f765i = 1;
                                Object t3 = q3.t(c0267n2, mVar);
                                x0.a aVar2 = x0.a.f3053e;
                                if (t3 == aVar2) {
                                    return aVar2;
                                }
                            } catch (N0.a e2) {
                                e = e2;
                                c0267n = c0267n2;
                                if (e.f791e != c0267n) {
                                    throw e;
                                }
                                return u0.g.f2964a;
                            }
                        } else {
                            if (i3 != 1) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            c0267n = mVar.f767k;
                            try {
                                AbstractC0230j.A(obj3);
                            } catch (N0.a e3) {
                                e = e3;
                                if (e.f791e != c0267n) {
                                }
                                return u0.g.f2964a;
                            }
                        }
                        return u0.g.f2964a;
                    }
                }
                mVar = new M0.m(this, cVar);
                Object obj32 = mVar.f764h;
                i3 = mVar.f765i;
                if (i3 != 0) {
                }
                return u0.g.f2964a;
        }
    }

    @Override // l0.InterfaceC0212j
    public void u(int i2) {
        ((io.flutter.plugin.platform.j) this.f579g).g(i2);
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.u(i2);
    }

    @Override // l0.InterfaceC0212j
    public void v(C0177s c0177s) {
        ((io.flutter.plugin.platform.k) this.f578f).f2456y.v(c0177s);
        throw null;
    }

    public void w() {
        j0 j0Var;
        ImageView imageView = (ImageView) this.f578f;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            Rect rect = AbstractC0183y.f2285a;
        }
        if (drawable == null || (j0Var = (j0) this.f579g) == null) {
            return;
        }
        C0174o.c(drawable, j0Var, imageView.getDrawableState());
    }

    public View y(int i2, int i3, int i4, int i5) {
        int s2;
        int i6;
        int t2;
        View o2;
        int left;
        int i7;
        int right;
        int i8;
        P p2 = (P) this.f579g;
        w wVar = (w) this.f578f;
        switch (wVar.f657a) {
            case 0:
                s2 = wVar.f658b.s();
                break;
            default:
                s2 = wVar.f658b.u();
                break;
        }
        switch (wVar.f657a) {
            case 0:
                x xVar = wVar.f658b;
                i6 = xVar.f664f;
                t2 = xVar.t();
                break;
            default:
                x xVar2 = wVar.f658b;
                i6 = xVar2.f665g;
                t2 = xVar2.r();
                break;
        }
        int i9 = i6 - t2;
        int i10 = i3 > i2 ? 1 : -1;
        View view = null;
        while (i2 != i3) {
            switch (wVar.f657a) {
                case 0:
                    o2 = wVar.f658b.o(i2);
                    break;
                default:
                    o2 = wVar.f658b.o(i2);
                    break;
            }
            switch (wVar.f657a) {
                case 0:
                    y yVar = (y) o2.getLayoutParams();
                    left = o2.getLeft() - ((y) o2.getLayoutParams()).f666a.left;
                    i7 = ((ViewGroup.MarginLayoutParams) yVar).leftMargin;
                    break;
                default:
                    y yVar2 = (y) o2.getLayoutParams();
                    left = o2.getTop() - ((y) o2.getLayoutParams()).f666a.top;
                    i7 = ((ViewGroup.MarginLayoutParams) yVar2).topMargin;
                    break;
            }
            int i11 = left - i7;
            switch (wVar.f657a) {
                case 0:
                    y yVar3 = (y) o2.getLayoutParams();
                    right = o2.getRight() + ((y) o2.getLayoutParams()).f666a.right;
                    i8 = ((ViewGroup.MarginLayoutParams) yVar3).rightMargin;
                    break;
                default:
                    y yVar4 = (y) o2.getLayoutParams();
                    right = o2.getBottom() + ((y) o2.getLayoutParams()).f666a.bottom;
                    i8 = ((ViewGroup.MarginLayoutParams) yVar4).bottomMargin;
                    break;
            }
            int i12 = right + i8;
            p2.f571b = s2;
            p2.f572c = i9;
            p2.f573d = i11;
            p2.f574e = i12;
            if (i4 != 0) {
                p2.f570a = i4;
                if (p2.a()) {
                    return o2;
                }
            }
            if (i5 != 0) {
                p2.f570a = i5;
                if (p2.a()) {
                    view = o2;
                }
            }
            i2 += i10;
        }
        return view;
    }

    public void z(int i2) {
        int resourceId;
        ImageView imageView = (ImageView) this.f578f;
        C0051b C2 = C0051b.C(imageView.getContext(), null, AbstractC0096a.f1616e, i2);
        TypedArray typedArray = (TypedArray) C2.f583f;
        try {
            Drawable drawable = imageView.getDrawable();
            if (drawable == null && (resourceId = typedArray.getResourceId(1, -1)) != -1 && (drawable = AbstractC0112a.a(imageView.getContext(), resourceId)) != null) {
                imageView.setImageDrawable(drawable);
            }
            if (drawable != null) {
                Rect rect = AbstractC0183y.f2285a;
            }
            if (typedArray.hasValue(2)) {
                A.f.c(imageView, C2.u(2));
            }
            if (typedArray.hasValue(3)) {
                A.f.d(imageView, AbstractC0183y.c(typedArray.getInt(3, -1), null));
            }
            C2.F();
        } catch (Throwable th) {
            C2.F();
            throw th;
        }
    }

    public /* synthetic */ Q(int i2, boolean z2) {
        this.f577e = i2;
    }

    public /* synthetic */ Q(Object obj, Object obj2, int i2, boolean z2) {
        this.f577e = i2;
        this.f579g = obj;
        this.f578f = obj2;
    }

    public Q(InterfaceC0242a interfaceC0242a, C0206d c0206d) {
        this.f577e = 24;
        this.f578f = interfaceC0242a;
        this.f579g = c0206d;
        c0206d.f2662f = new C0206d(17, this);
    }

    public Q(C0204b c0204b) {
        this.f577e = 7;
        this.f579g = new C0097A();
        this.f578f = c0204b;
    }

    public Q(A.j jVar) {
        this.f577e = 14;
        this.f579g = jVar;
        this.f578f = new HashMap();
    }

    public Q(int i2) {
        this.f577e = i2;
        switch (i2) {
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                this.f578f = new LongSparseArray();
                this.f579g = new PriorityQueue();
                break;
            default:
                this.f578f = new ReentrantLock();
                this.f579g = new LinkedHashMap();
                break;
        }
    }

    public Q(View view, InputMethodManager inputMethodManager, C0206d c0206d) {
        this.f577e = 11;
        if (Build.VERSION.SDK_INT >= 33) {
            view.setAutoHandwritingEnabled(false);
        }
        this.f579g = view;
        this.f578f = inputMethodManager;
        c0206d.f2662f = this;
    }

    public Q(U.b bVar) {
        this.f577e = 5;
        Q q2 = new Q(4);
        this.f578f = bVar;
        this.f579g = q2;
    }

    public Q(ImageView imageView) {
        this.f577e = 9;
        this.f578f = imageView;
    }

    public Q(C0128b c0128b, int i2) {
        this.f577e = i2;
        switch (i2) {
            case 16:
                C0206d c0206d = new C0206d(2, this);
                C0051b c0051b = new C0051b(c0128b, "flutter/platform", C0229i.f2738a, 8);
                this.f578f = c0051b;
                c0051b.H(c0206d);
                break;
            case 19:
                C0206d c0206d2 = new C0206d(15, this);
                C0051b c0051b2 = new C0051b(c0128b, "flutter/textinput", C0229i.f2738a, 8);
                this.f578f = c0051b2;
                c0051b2.H(c0206d2);
                break;
            default:
                A.j jVar = new A.j(29, this);
                C0051b c0051b3 = new C0051b(c0128b, "flutter/localization", C0229i.f2738a, 8);
                this.f578f = c0051b3;
                c0051b3.H(jVar);
                break;
        }
    }

    public Q(C0128b c0128b, PackageManager packageManager) {
        this.f577e = 17;
        C0206d c0206d = new C0206d(7, this);
        this.f578f = packageManager;
        new C0051b(c0128b, "flutter/processtext", C0236p.f2742a, 8).H(c0206d);
    }

    public Q(w wVar) {
        this.f577e = 0;
        this.f578f = wVar;
        P p2 = new P();
        p2.f570a = 0;
        this.f579g = p2;
    }
}
