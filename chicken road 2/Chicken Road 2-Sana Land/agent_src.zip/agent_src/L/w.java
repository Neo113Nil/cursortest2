package L;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f657a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ x f658b;

    public /* synthetic */ w(x xVar, int i2) {
        this.f657a = i2;
        this.f658b = xVar;
    }
}
