package L;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: a, reason: collision with root package name */
    public int f537a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f538b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f539c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f540d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f541e;

    public final int a() {
        if (this.f539c) {
            return 0 - this.f537a;
        }
        return 0;
    }

    public final String toString() {
        return "State{mTargetPosition=-1, mData=null, mItemCount=0, mIsMeasuring=false, mPreviousLayoutItemCount=0, mDeletedInvisibleItemCountSincePreviousLayout=" + this.f537a + ", mStructureChanged=" + this.f538b + ", mInPreLayout=" + this.f539c + ", mRunSimpleAnimations=" + this.f540d + ", mRunPredictiveAnimations=" + this.f541e + '}';
    }
}
