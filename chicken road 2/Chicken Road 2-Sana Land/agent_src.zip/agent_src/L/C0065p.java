package L;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: L.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0065p implements Parcelable {
    public static final Parcelable.Creator<C0065p> CREATOR = new A.l(1);

    /* renamed from: e, reason: collision with root package name */
    public int f648e;

    /* renamed from: f, reason: collision with root package name */
    public int f649f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f650g;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f648e);
        parcel.writeInt(this.f649f);
        parcel.writeInt(this.f650g ? 1 : 0);
    }
}
