package L;

/* renamed from: L.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0064o {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f643a;

    /* renamed from: b, reason: collision with root package name */
    public int f644b;

    /* renamed from: c, reason: collision with root package name */
    public int f645c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f646d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f647e;

    public String toString() {
        switch (this.f643a) {
            case 0:
                return "AnchorInfo{mPosition=" + this.f644b + ", mCoordinate=" + this.f645c + ", mLayoutFromEnd=" + this.f646d + ", mValid=" + this.f647e + '}';
            default:
                return super.toString();
        }
    }
}
