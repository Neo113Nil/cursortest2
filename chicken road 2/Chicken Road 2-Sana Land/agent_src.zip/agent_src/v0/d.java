package v0;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class d extends j {
    public static final void G(Iterable iterable, StringBuilder sb, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, CharSequence charSequence4, D0.l lVar) {
        E0.i.e(iterable, "<this>");
        sb.append(charSequence2);
        Iterator it = iterable.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            Object next = it.next();
            i2++;
            if (i2 > 1) {
                sb.append(charSequence);
            }
            if (lVar != null) {
                sb.append((CharSequence) lVar.i(next));
            } else {
                if (next != null ? next instanceof CharSequence : true) {
                    sb.append((CharSequence) next);
                } else if (next instanceof Character) {
                    sb.append(((Character) next).charValue());
                } else {
                    sb.append((CharSequence) next.toString());
                }
            }
        }
        sb.append(charSequence3);
    }

    public static String H(Collection collection, String str, String str2, String str3, D0.l lVar, int i2) {
        String str4 = (i2 & 2) != 0 ? "" : str2;
        String str5 = (i2 & 4) != 0 ? "" : str3;
        if ((i2 & 32) != 0) {
            lVar = null;
        }
        E0.i.e(collection, "<this>");
        StringBuilder sb = new StringBuilder();
        G(collection, sb, str, str4, str5, "...", lVar);
        return sb.toString();
    }

    public static final void I(Iterable iterable, AbstractCollection abstractCollection) {
        E0.i.e(iterable, "<this>");
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            abstractCollection.add(it.next());
        }
    }

    public static List J(Iterable iterable) {
        ArrayList arrayList;
        E0.i.e(iterable, "<this>");
        boolean z2 = iterable instanceof Collection;
        if (z2) {
            Collection collection = (Collection) iterable;
            int size = collection.size();
            if (size != 0) {
                if (size != 1) {
                    return new ArrayList(collection);
                }
                return AbstractC0230j.r(iterable instanceof List ? ((List) iterable).get(0) : collection.iterator().next());
            }
        } else {
            if (z2) {
                arrayList = new ArrayList((Collection) iterable);
            } else {
                arrayList = new ArrayList();
                I(iterable, arrayList);
            }
            int size2 = arrayList.size();
            if (size2 != 0) {
                return size2 != 1 ? arrayList : AbstractC0230j.r(arrayList.get(0));
            }
        }
        return l.f2972e;
    }

    public static Set K(Collection collection) {
        E0.i.e(collection, "<this>");
        int size = collection.size();
        if (size == 0) {
            return n.f2974e;
        }
        if (size != 1) {
            LinkedHashSet linkedHashSet = new LinkedHashSet(AbstractC0230j.s(collection.size()));
            I(collection, linkedHashSet);
            return linkedHashSet;
        }
        Set singleton = Collections.singleton(collection instanceof List ? ((List) collection).get(0) : collection.iterator().next());
        E0.i.d(singleton, "singleton(...)");
        return singleton;
    }
}
