package v0;

import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class c extends AbstractC0230j {
    public static final void F(Object[] objArr, Object[] objArr2, int i2, int i3, int i4) {
        E0.i.e(objArr, "<this>");
        E0.i.e(objArr2, "destination");
        System.arraycopy(objArr, i3, objArr2, i2, i4 - i3);
    }
}
