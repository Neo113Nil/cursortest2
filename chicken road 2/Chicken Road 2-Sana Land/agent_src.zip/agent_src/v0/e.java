package v0;

import java.util.Arrays;
import java.util.List;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class e extends AbstractC0230j {
    public static List F(Object... objArr) {
        if (objArr.length <= 0) {
            return l.f2972e;
        }
        List asList = Arrays.asList(objArr);
        E0.i.d(asList, "asList(...)");
        return asList;
    }
}
