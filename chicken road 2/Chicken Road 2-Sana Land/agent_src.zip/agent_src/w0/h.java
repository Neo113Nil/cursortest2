package w0;

import D0.p;

/* loaded from: classes.dex */
public interface h {
    f h(g gVar);

    Object i(Object obj, p pVar);

    h l(g gVar);

    h n(h hVar);
}
