package w0;

/* loaded from: classes.dex */
public interface c {
    h e();

    void g(Object obj);
}
