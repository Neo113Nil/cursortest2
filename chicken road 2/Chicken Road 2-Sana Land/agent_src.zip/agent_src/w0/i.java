package w0;

import D0.p;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class i implements h, Serializable {

    /* renamed from: e, reason: collision with root package name */
    public static final i f3040e = new i();

    @Override // w0.h
    public final f h(g gVar) {
        E0.i.e(gVar, "key");
        return null;
    }

    public final int hashCode() {
        return 0;
    }

    @Override // w0.h
    public final h l(g gVar) {
        E0.i.e(gVar, "key");
        return this;
    }

    @Override // w0.h
    public final h n(h hVar) {
        E0.i.e(hVar, "context");
        return hVar;
    }

    public final String toString() {
        return "EmptyCoroutineContext";
    }

    @Override // w0.h
    public final Object i(Object obj, p pVar) {
        return obj;
    }
}
