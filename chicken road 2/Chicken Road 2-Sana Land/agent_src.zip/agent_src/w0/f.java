package w0;

/* loaded from: classes.dex */
public interface f extends h {
    g getKey();
}
