package w0;

import D.C0011l;
import D0.p;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class b implements h, Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final h f3037e;

    /* renamed from: f, reason: collision with root package name */
    public final f f3038f;

    public b(h hVar, f fVar) {
        E0.i.e(hVar, "left");
        E0.i.e(fVar, "element");
        this.f3037e = hVar;
        this.f3038f = fVar;
    }

    public final boolean equals(Object obj) {
        boolean z2;
        if (this == obj) {
            return true;
        }
        if (obj instanceof b) {
            b bVar = (b) obj;
            bVar.getClass();
            int i2 = 2;
            b bVar2 = bVar;
            int i3 = 2;
            while (true) {
                h hVar = bVar2.f3037e;
                bVar2 = hVar instanceof b ? (b) hVar : null;
                if (bVar2 == null) {
                    break;
                }
                i3++;
            }
            b bVar3 = this;
            while (true) {
                h hVar2 = bVar3.f3037e;
                bVar3 = hVar2 instanceof b ? (b) hVar2 : null;
                if (bVar3 == null) {
                    break;
                }
                i2++;
            }
            if (i3 == i2) {
                b bVar4 = this;
                while (true) {
                    f fVar = bVar4.f3038f;
                    if (!E0.i.a(bVar.h(fVar.getKey()), fVar)) {
                        z2 = false;
                        break;
                    }
                    h hVar3 = bVar4.f3037e;
                    if (!(hVar3 instanceof b)) {
                        E0.i.c(hVar3, "null cannot be cast to non-null type kotlin.coroutines.CoroutineContext.Element");
                        f fVar2 = (f) hVar3;
                        z2 = E0.i.a(bVar.h(fVar2.getKey()), fVar2);
                        break;
                    }
                    bVar4 = (b) hVar3;
                }
                if (z2) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // w0.h
    public final f h(g gVar) {
        E0.i.e(gVar, "key");
        b bVar = this;
        while (true) {
            f h2 = bVar.f3038f.h(gVar);
            if (h2 != null) {
                return h2;
            }
            h hVar = bVar.f3037e;
            if (!(hVar instanceof b)) {
                return hVar.h(gVar);
            }
            bVar = (b) hVar;
        }
    }

    public final int hashCode() {
        return this.f3038f.hashCode() + this.f3037e.hashCode();
    }

    @Override // w0.h
    public final Object i(Object obj, p pVar) {
        return pVar.h(this.f3037e.i(obj, pVar), this.f3038f);
    }

    @Override // w0.h
    public final h l(g gVar) {
        E0.i.e(gVar, "key");
        f fVar = this.f3038f;
        f h2 = fVar.h(gVar);
        h hVar = this.f3037e;
        if (h2 != null) {
            return hVar;
        }
        h l2 = hVar.l(gVar);
        return l2 == hVar ? this : l2 == i.f3040e ? fVar : new b(l2, fVar);
    }

    @Override // w0.h
    public final h n(h hVar) {
        E0.i.e(hVar, "context");
        return hVar == i.f3040e ? this : (h) hVar.i(this, new C0011l(9));
    }

    public final String toString() {
        return "[" + ((String) i("", new C0011l(8))) + ']';
    }
}
