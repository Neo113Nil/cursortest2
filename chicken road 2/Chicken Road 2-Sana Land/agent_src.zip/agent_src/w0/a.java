package w0;

import D.C0011l;
import D0.p;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class a implements f {

    /* renamed from: e, reason: collision with root package name */
    public final g f3036e;

    public a(g gVar) {
        this.f3036e = gVar;
    }

    @Override // w0.f
    public final g getKey() {
        return this.f3036e;
    }

    @Override // w0.h
    public /* bridge */ f h(g gVar) {
        return AbstractC0230j.m(this, gVar);
    }

    @Override // w0.h
    public final Object i(Object obj, p pVar) {
        return pVar.h(obj, this);
    }

    @Override // w0.h
    public /* bridge */ h l(g gVar) {
        return AbstractC0230j.t(this, gVar);
    }

    @Override // w0.h
    public final h n(h hVar) {
        E0.i.e(hVar, "context");
        return hVar == i.f3040e ? this : (h) hVar.i(this, new C0011l(9));
    }
}
