package w0;

/* loaded from: classes.dex */
public final class d implements g {

    /* renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ d f3039e = new d();
}
