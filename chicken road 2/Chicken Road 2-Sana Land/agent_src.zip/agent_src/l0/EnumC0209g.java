package l0;

/* renamed from: l0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0209g {
    f2672f("SystemUiOverlay.top"),
    f2673g("SystemUiOverlay.bottom");


    /* renamed from: e, reason: collision with root package name */
    public final String f2675e;

    EnumC0209g(String str) {
        this.f2675e = str;
    }
}
