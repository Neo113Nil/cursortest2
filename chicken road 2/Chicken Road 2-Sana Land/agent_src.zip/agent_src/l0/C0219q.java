package l0;

import org.json.JSONObject;

/* renamed from: l0.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0219q {

    /* renamed from: a, reason: collision with root package name */
    public final String f2725a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2726b;

    /* renamed from: c, reason: collision with root package name */
    public final int f2727c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2728d;

    /* renamed from: e, reason: collision with root package name */
    public final int f2729e;

    public C0219q(String str, int i2, int i3, int i4, int i5) {
        if (!(i2 == -1 && i3 == -1) && (i2 < 0 || i3 < 0)) {
            throw new IndexOutOfBoundsException("invalid selection: (" + i2 + ", " + i3 + ")");
        }
        if (!(i4 == -1 && i5 == -1) && (i4 < 0 || i4 > i5)) {
            throw new IndexOutOfBoundsException("invalid composing range: (" + i4 + ", " + i5 + ")");
        }
        if (i5 > str.length()) {
            throw new IndexOutOfBoundsException(E0.h.e("invalid composing start: ", i4));
        }
        if (i2 > str.length()) {
            throw new IndexOutOfBoundsException(E0.h.e("invalid selection start: ", i2));
        }
        if (i3 > str.length()) {
            throw new IndexOutOfBoundsException(E0.h.e("invalid selection end: ", i3));
        }
        this.f2725a = str;
        this.f2726b = i2;
        this.f2727c = i3;
        this.f2728d = i4;
        this.f2729e = i5;
    }

    public static C0219q a(JSONObject jSONObject) {
        return new C0219q(jSONObject.getString("text"), jSONObject.getInt("selectionBase"), jSONObject.getInt("selectionExtent"), jSONObject.getInt("composingBase"), jSONObject.getInt("composingExtent"));
    }
}
