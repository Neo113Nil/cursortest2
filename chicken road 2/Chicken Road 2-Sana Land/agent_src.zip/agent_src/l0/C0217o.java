package l0;

import D.C0016q;
import java.util.Locale;

/* renamed from: l0.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0217o {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f2709a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f2710b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f2711c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f2712d;

    /* renamed from: e, reason: collision with root package name */
    public final boolean f2713e;

    /* renamed from: f, reason: collision with root package name */
    public final int f2714f;

    /* renamed from: g, reason: collision with root package name */
    public final C0218p f2715g;

    /* renamed from: h, reason: collision with root package name */
    public final Integer f2716h;

    /* renamed from: i, reason: collision with root package name */
    public final String f2717i;

    /* renamed from: j, reason: collision with root package name */
    public final C0016q f2718j;

    /* renamed from: k, reason: collision with root package name */
    public final String[] f2719k;

    /* renamed from: l, reason: collision with root package name */
    public final C0217o[] f2720l;

    /* renamed from: m, reason: collision with root package name */
    public final Locale[] f2721m;

    public C0217o(boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, int i2, C0218p c0218p, Integer num, String str, C0016q c0016q, String[] strArr, C0217o[] c0217oArr, Locale[] localeArr) {
        this.f2709a = z2;
        this.f2710b = z3;
        this.f2711c = z4;
        this.f2712d = z5;
        this.f2713e = z6;
        this.f2714f = i2;
        this.f2715g = c0218p;
        this.f2716h = num;
        this.f2717i = str;
        this.f2718j = c0016q;
        this.f2719k = strArr;
        this.f2720l = c0217oArr;
        this.f2721m = localeArr;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 l0.o, still in use, count: 2, list:
          (r8v1 l0.o) from 0x021e: PHI (r8v2 l0.o) = (r8v1 l0.o), (r8v4 l0.o) binds: [B:68:0x0211, B:75:0x04fc] A[DONT_GENERATE, DONT_INLINE]
          (r8v1 l0.o) from 0x01e8: MOVE (r30v5 l0.o) = (r8v1 l0.o) (LINE:489)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:447)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:96)
        */
    public static l0.C0217o a(org.json.JSONObject r35) {
        /*
            Method dump skipped, instructions count: 1748
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.C0217o.a(org.json.JSONObject):l0.o");
    }
}
