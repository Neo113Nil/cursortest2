package l0;

/* renamed from: l0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0210h {

    /* renamed from: a, reason: collision with root package name */
    public final int f2676a;

    /* renamed from: b, reason: collision with root package name */
    public final Number f2677b;

    /* renamed from: c, reason: collision with root package name */
    public final Number f2678c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2679d;

    /* renamed from: e, reason: collision with root package name */
    public final int f2680e;

    /* renamed from: f, reason: collision with root package name */
    public final Object f2681f;

    /* renamed from: g, reason: collision with root package name */
    public final Object f2682g;

    /* renamed from: h, reason: collision with root package name */
    public final int f2683h;

    /* renamed from: i, reason: collision with root package name */
    public final int f2684i;

    /* renamed from: j, reason: collision with root package name */
    public final float f2685j;

    /* renamed from: k, reason: collision with root package name */
    public final float f2686k;

    /* renamed from: l, reason: collision with root package name */
    public final int f2687l;

    /* renamed from: m, reason: collision with root package name */
    public final int f2688m;

    /* renamed from: n, reason: collision with root package name */
    public final int f2689n;

    /* renamed from: o, reason: collision with root package name */
    public final int f2690o;

    /* renamed from: p, reason: collision with root package name */
    public final long f2691p;

    public C0210h(int i2, Number number, Number number2, int i3, int i4, Object obj, Object obj2, int i5, int i6, float f2, float f3, int i7, int i8, int i9, int i10, long j2) {
        this.f2676a = i2;
        this.f2677b = number;
        this.f2678c = number2;
        this.f2679d = i3;
        this.f2680e = i4;
        this.f2681f = obj;
        this.f2682g = obj2;
        this.f2683h = i5;
        this.f2684i = i6;
        this.f2685j = f2;
        this.f2686k = f3;
        this.f2687l = i7;
        this.f2688m = i8;
        this.f2689n = i9;
        this.f2690o = i10;
        this.f2691p = j2;
    }
}
