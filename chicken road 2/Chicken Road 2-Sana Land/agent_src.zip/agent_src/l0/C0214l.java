package l0;

import L.C0051b;
import e0.C0128b;
import java.util.HashMap;
import m0.C0236p;

/* renamed from: l0.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0214l {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f2698a;

    /* renamed from: b, reason: collision with root package name */
    public byte[] f2699b;

    /* renamed from: c, reason: collision with root package name */
    public final C0051b f2700c;

    /* renamed from: d, reason: collision with root package name */
    public C0213k f2701d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f2702e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2703f;

    public C0214l(C0128b c0128b, boolean z2) {
        C0051b c0051b = new C0051b(c0128b, "flutter/restoration", C0236p.f2742a, 8);
        this.f2702e = false;
        this.f2703f = false;
        C0206d c0206d = new C0206d(8, this);
        this.f2700c = c0051b;
        this.f2698a = z2;
        c0051b.H(c0206d);
    }

    public static HashMap a(byte[] bArr) {
        HashMap hashMap = new HashMap();
        hashMap.put("enabled", Boolean.TRUE);
        hashMap.put("data", bArr);
        return hashMap;
    }
}
