package l0;

import D.C0016q;
import e0.C0128b;
import m0.C0228h;
import m0.InterfaceC0226f;

/* renamed from: l0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0204b {

    /* renamed from: a, reason: collision with root package name */
    public final C0016q f2656a;

    public C0204b(C0128b c0128b) {
        this.f2656a = new C0016q(c0128b, "flutter/system", C0228h.f2737a, null);
    }

    public C0204b(InterfaceC0226f interfaceC0226f) {
        this.f2656a = new C0016q(interfaceC0226f, "flutter/keyevent", C0228h.f2737a, null);
    }
}
