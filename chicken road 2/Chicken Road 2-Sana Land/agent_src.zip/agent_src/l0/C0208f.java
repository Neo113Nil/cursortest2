package l0;

/* renamed from: l0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0208f {

    /* renamed from: a, reason: collision with root package name */
    public final Integer f2665a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2666b;

    /* renamed from: c, reason: collision with root package name */
    public final Boolean f2667c;

    /* renamed from: d, reason: collision with root package name */
    public final Integer f2668d;

    /* renamed from: e, reason: collision with root package name */
    public final int f2669e;

    /* renamed from: f, reason: collision with root package name */
    public final Integer f2670f;

    /* renamed from: g, reason: collision with root package name */
    public final Boolean f2671g;

    public C0208f(Integer num, int i2, Boolean bool, Integer num2, int i3, Integer num3, Boolean bool2) {
        this.f2665a = num;
        this.f2666b = i2;
        this.f2667c = bool;
        this.f2668d = num2;
        this.f2669e = i3;
        this.f2670f = num3;
        this.f2671g = bool2;
    }
}
