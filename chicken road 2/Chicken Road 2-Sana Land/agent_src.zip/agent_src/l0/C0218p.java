package l0;

/* renamed from: l0.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0218p {

    /* renamed from: a, reason: collision with root package name */
    public final int f2722a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f2723b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f2724c;

    public C0218p(int i2, boolean z2, boolean z3) {
        this.f2722a = i2;
        this.f2723b = z2;
        this.f2724c = z3;
    }
}
