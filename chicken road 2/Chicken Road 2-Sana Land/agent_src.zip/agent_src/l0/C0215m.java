package l0;

import android.util.DisplayMetrics;

/* renamed from: l0.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0215m {

    /* renamed from: c, reason: collision with root package name */
    public static int f2704c = Integer.MIN_VALUE;

    /* renamed from: a, reason: collision with root package name */
    public final int f2705a;

    /* renamed from: b, reason: collision with root package name */
    public final DisplayMetrics f2706b;

    public C0215m(DisplayMetrics displayMetrics) {
        int i2 = f2704c;
        f2704c = i2 + 1;
        this.f2705a = i2;
        this.f2706b = displayMetrics;
    }
}
