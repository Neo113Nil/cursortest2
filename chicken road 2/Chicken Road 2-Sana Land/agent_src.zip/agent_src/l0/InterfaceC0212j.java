package l0;

import d0.C0122j;
import h.C0177s;

/* renamed from: l0.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0212j {
    long b(C0177s c0177s);

    void c(boolean z2);

    void e(int i2, double d2, double d3);

    void f(int i2, int i3);

    void i(C0211i c0211i, C0122j c0122j);

    void k(C0210h c0210h);

    void m(int i2);

    void u(int i2);

    void v(C0177s c0177s);
}
