package l0;

/* renamed from: l0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0211i {

    /* renamed from: a, reason: collision with root package name */
    public final int f2692a;

    /* renamed from: b, reason: collision with root package name */
    public final double f2693b;

    /* renamed from: c, reason: collision with root package name */
    public final double f2694c;

    public C0211i(int i2, double d2, double d3) {
        this.f2692a = i2;
        this.f2693b = d2;
        this.f2694c = d3;
    }
}
