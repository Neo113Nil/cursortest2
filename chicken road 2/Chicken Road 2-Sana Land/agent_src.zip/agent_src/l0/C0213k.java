package l0;

import L.C0051b;
import L.Q;
import android.util.Log;
import e0.C0133g;
import m0.InterfaceC0233m;

/* renamed from: l0.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0213k {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f2695a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f2696b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f2697c;

    public /* synthetic */ C0213k(int i2, Object obj, Object obj2) {
        this.f2695a = i2;
        this.f2697c = obj;
        this.f2696b = obj2;
    }

    public final void a(String str, String str2, Object obj) {
        switch (this.f2695a) {
            case 0:
                Log.e("RestorationChannel", "Error " + str + " while sending restoration data to framework: " + str2);
                break;
            default:
                ((C0133g) this.f2696b).a(((InterfaceC0233m) ((C0051b) ((Q) this.f2697c).f579g).f585h).c(str, str2, obj));
                break;
        }
    }

    public final void b() {
        switch (this.f2695a) {
            case 0:
                break;
            default:
                ((C0133g) this.f2696b).a(null);
                break;
        }
    }

    public final void d(Object obj) {
        switch (this.f2695a) {
            case 0:
                ((C0214l) this.f2697c).f2699b = (byte[]) this.f2696b;
                break;
            default:
                ((C0133g) this.f2696b).a(((InterfaceC0233m) ((C0051b) ((Q) this.f2697c).f579g).f585h).a(obj));
                break;
        }
    }

    private final void c() {
    }
}
