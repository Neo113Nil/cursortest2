package l0;

import D.C0016q;
import e0.C0128b;
import java.util.Locale;
import m0.C0237q;

/* renamed from: l0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0205c {

    /* renamed from: a, reason: collision with root package name */
    public int f2657a;

    /* renamed from: b, reason: collision with root package name */
    public int f2658b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f2659c;

    /* renamed from: d, reason: collision with root package name */
    public final C0016q f2660d;

    public C0205c(C0128b c0128b) {
        C0016q c0016q = new C0016q(c0128b, "flutter/lifecycle", C0237q.f2744b, null);
        this.f2657a = 0;
        this.f2658b = 0;
        this.f2659c = true;
        this.f2660d = c0016q;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0032 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0033  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(int i2, boolean z2) {
        int i3;
        String str;
        int i4 = this.f2657a;
        if (i4 == i2 && z2 == this.f2659c) {
            return;
        }
        if (i2 == 0 && i4 == 0) {
            this.f2659c = z2;
            return;
        }
        int a2 = F.i.a(i2);
        if (a2 != 0) {
            if (a2 == 1) {
                i3 = z2 ? 2 : 3;
            } else if (a2 != 2 && a2 != 3 && a2 != 4) {
                i3 = 0;
            }
            this.f2657a = i2;
            this.f2659c = z2;
            if (i3 != this.f2658b) {
                return;
            }
            StringBuilder sb = new StringBuilder("AppLifecycleState.");
            if (i3 == 1) {
                str = "DETACHED";
            } else if (i3 == 2) {
                str = "RESUMED";
            } else if (i3 == 3) {
                str = "INACTIVE";
            } else if (i3 == 4) {
                str = "HIDDEN";
            } else {
                if (i3 != 5) {
                    throw null;
                }
                str = "PAUSED";
            }
            sb.append(str.toLowerCase(Locale.ROOT));
            this.f2660d.i(sb.toString(), null);
            this.f2658b = i3;
            return;
        }
        i3 = i2;
        this.f2657a = i2;
        this.f2659c = z2;
        if (i3 != this.f2658b) {
        }
    }
}
