package l0;

import L.C0051b;
import android.window.BackEvent;
import e0.C0128b;
import java.util.Arrays;
import java.util.HashMap;
import m0.C0229i;
import m0.C0236p;

/* renamed from: l0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0203a {

    /* renamed from: a, reason: collision with root package name */
    public final C0051b f2655a;

    public C0203a(C0128b c0128b, int i2) {
        switch (i2) {
            case 1:
                E.a aVar = new E.a(24);
                C0051b c0051b = new C0051b(c0128b, "flutter/navigation", C0229i.f2738a, 8);
                this.f2655a = c0051b;
                c0051b.H(aVar);
                break;
            default:
                E.a aVar2 = new E.a(21);
                C0051b c0051b2 = new C0051b(c0128b, "flutter/backgesture", C0236p.f2742a, 8);
                this.f2655a = c0051b2;
                c0051b2.H(aVar2);
                break;
        }
    }

    public static HashMap a(BackEvent backEvent) {
        float touchX;
        float touchY;
        float progress;
        int swipeEdge;
        HashMap hashMap = new HashMap(3);
        touchX = backEvent.getTouchX();
        touchY = backEvent.getTouchY();
        hashMap.put("touchOffset", (Float.isNaN(touchX) || Float.isNaN(touchY)) ? null : Arrays.asList(Float.valueOf(touchX), Float.valueOf(touchY)));
        progress = backEvent.getProgress();
        hashMap.put("progress", Float.valueOf(progress));
        swipeEdge = backEvent.getSwipeEdge();
        hashMap.put("swipeEdge", Integer.valueOf(swipeEdge));
        return hashMap;
    }
}
