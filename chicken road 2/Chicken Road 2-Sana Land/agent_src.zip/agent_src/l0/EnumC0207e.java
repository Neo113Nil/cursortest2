package l0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* renamed from: l0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0207e {

    /* renamed from: e, reason: collision with root package name */
    public static final EnumC0207e f2663e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ EnumC0207e[] f2664f;

    static {
        EnumC0207e enumC0207e = new EnumC0207e("PLAIN_TEXT", 0);
        f2663e = enumC0207e;
        f2664f = new EnumC0207e[]{enumC0207e};
    }

    public static EnumC0207e a(String str) {
        for (EnumC0207e enumC0207e : values()) {
            enumC0207e.getClass();
            if ("text/plain".equals(str)) {
                return enumC0207e;
            }
        }
        throw new NoSuchFieldException(E0.h.g("No such ClipboardContentFormat: ", str));
    }

    public static EnumC0207e valueOf(String str) {
        return (EnumC0207e) Enum.valueOf(EnumC0207e.class, str);
    }

    public static EnumC0207e[] values() {
        return (EnumC0207e[]) f2664f.clone();
    }
}
