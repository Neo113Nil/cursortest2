package l0;

import D.C0016q;
import L.C0051b;
import e0.C0128b;
import m0.C0228h;

/* renamed from: l0.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0216n {

    /* renamed from: a, reason: collision with root package name */
    public final C0051b f2707a = new C0051b(7);

    /* renamed from: b, reason: collision with root package name */
    public final C0016q f2708b;

    public C0216n(C0128b c0128b) {
        this.f2708b = new C0016q(c0128b, "flutter/settings", C0228h.f2737a, null);
    }
}
