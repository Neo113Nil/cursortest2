package l0;

import D.C0021w;
import L.C0051b;
import L.C0063n;
import L.Q;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.PointerIcon;
import android.view.View;
import android.view.autofill.AutofillManager;
import android.view.inputmethod.InputMethodManager;
import c0.AbstractActivityC0103f;
import c0.F;
import c0.InterfaceC0106i;
import c0.s;
import d0.C0122j;
import e0.C0128b;
import h.C0177s;
import io.flutter.embedding.engine.FlutterJNI;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import m0.C0229i;
import m0.C0236p;
import m0.InterfaceC0232l;
import n0.C0240b;
import o0.InterfaceC0242a;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import q0.C0248a;
import w.AbstractC0293q;
import w.x;

/* renamed from: l0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0206d implements InterfaceC0232l, M0.d {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f2661e;

    /* renamed from: f, reason: collision with root package name */
    public Object f2662f;

    public /* synthetic */ C0206d() {
        this.f2661e = 18;
    }

    public static int a(C0206d c0206d, int i2) {
        if (i2 == 0) {
            return 0;
        }
        if (i2 == 1) {
            return 1;
        }
        if (i2 == 2) {
            return 2;
        }
        throw new IllegalArgumentException("contentSensitivityIndex " + i2 + " not known to the SensitiveContentChannel.");
    }

    private final void d(Q q2, C0213k c0213k) {
        Object obj;
        boolean z2;
        C0206d c0206d = (C0206d) this.f2662f;
        if (((InterfaceC0212j) c0206d.f2662f) == null) {
            return;
        }
        String str = (String) q2.f578f;
        obj = q2.f579g;
        str.getClass();
        z2 = false;
        switch (str) {
            case "create":
                Map map = (Map) obj;
                boolean z3 = map.containsKey("hybrid") && ((Boolean) map.get("hybrid")).booleanValue();
                ByteBuffer wrap = map.containsKey("params") ? ByteBuffer.wrap((byte[]) map.get("params")) : null;
                try {
                    if (z3) {
                        ((InterfaceC0212j) c0206d.f2662f).v(new C0177s(((Integer) map.get("id")).intValue(), (String) map.get("viewType"), 0.0d, 0.0d, 0.0d, 0.0d, ((Integer) map.get("direction")).intValue(), 3, wrap));
                        throw null;
                    }
                    if (map.containsKey("hybridFallback") && ((Boolean) map.get("hybridFallback")).booleanValue()) {
                        z2 = true;
                    }
                    ((InterfaceC0212j) c0206d.f2662f).b(new C0177s(((Integer) map.get("id")).intValue(), (String) map.get("viewType"), map.containsKey("top") ? ((Double) map.get("top")).doubleValue() : 0.0d, map.containsKey("left") ? ((Double) map.get("left")).doubleValue() : 0.0d, ((Double) map.get("width")).doubleValue(), ((Double) map.get("height")).doubleValue(), ((Integer) map.get("direction")).intValue(), z2 ? 2 : 1, wrap));
                    throw null;
                } catch (IllegalStateException e2) {
                    c0213k.a("error", Log.getStackTraceString(e2), null);
                    return;
                }
            case "offset":
                Map map2 = (Map) obj;
                try {
                    ((InterfaceC0212j) c0206d.f2662f).e(((Integer) map2.get("id")).intValue(), ((Double) map2.get("top")).doubleValue(), ((Double) map2.get("left")).doubleValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e3) {
                    c0213k.a("error", Log.getStackTraceString(e3), null);
                    return;
                }
            case "resize":
                Map map3 = (Map) obj;
                try {
                    ((InterfaceC0212j) c0206d.f2662f).i(new C0211i(((Integer) map3.get("id")).intValue(), ((Double) map3.get("width")).doubleValue(), ((Double) map3.get("height")).doubleValue()), new C0122j());
                    return;
                } catch (IllegalStateException e4) {
                    c0213k.a("error", Log.getStackTraceString(e4), null);
                    return;
                }
            case "clearFocus":
                try {
                    ((InterfaceC0212j) c0206d.f2662f).m(((Integer) obj).intValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e5) {
                    c0213k.a("error", Log.getStackTraceString(e5), null);
                    return;
                }
            case "synchronizeToNativeViewHierarchy":
                try {
                    ((InterfaceC0212j) c0206d.f2662f).c(((Boolean) obj).booleanValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e6) {
                    c0213k.a("error", Log.getStackTraceString(e6), null);
                    return;
                }
            case "touch":
                List list = (List) obj;
                try {
                    ((InterfaceC0212j) c0206d.f2662f).k(new C0210h(((Integer) list.get(0)).intValue(), (Number) list.get(1), (Number) list.get(2), ((Integer) list.get(3)).intValue(), ((Integer) list.get(4)).intValue(), list.get(5), list.get(6), ((Integer) list.get(7)).intValue(), ((Integer) list.get(8)).intValue(), (float) ((Double) list.get(9)).doubleValue(), (float) ((Double) list.get(10)).doubleValue(), ((Integer) list.get(11)).intValue(), ((Integer) list.get(12)).intValue(), ((Integer) list.get(13)).intValue(), ((Integer) list.get(14)).intValue(), ((Number) list.get(15)).longValue()));
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e7) {
                    c0213k.a("error", Log.getStackTraceString(e7), null);
                    return;
                }
            case "setDirection":
                Map map4 = (Map) obj;
                try {
                    ((InterfaceC0212j) c0206d.f2662f).f(((Integer) map4.get("id")).intValue(), ((Integer) map4.get("direction")).intValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e8) {
                    c0213k.a("error", Log.getStackTraceString(e8), null);
                    return;
                }
            case "dispose":
                try {
                    ((InterfaceC0212j) c0206d.f2662f).u(((Integer) ((Map) obj).get("id")).intValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e9) {
                    c0213k.a("error", Log.getStackTraceString(e9), null);
                    return;
                }
            default:
                c0213k.b();
                return;
        }
    }

    private final void e(Q q2, C0213k c0213k) {
        Object obj;
        C0206d c0206d = (C0206d) this.f2662f;
        if (((A.j) c0206d.f2662f) == null) {
            return;
        }
        String str = (String) q2.f578f;
        obj = q2.f579g;
        str.getClass();
        switch (str) {
            case "create":
                Map map = (Map) obj;
                if (map.containsKey("params")) {
                    ByteBuffer.wrap((byte[]) map.get("params"));
                }
                try {
                    ((Integer) map.get("id")).getClass();
                    String str2 = (String) map.get("viewType");
                    ((Integer) map.get("direction")).getClass();
                    if (((io.flutter.plugin.platform.j) ((A.j) c0206d.f2662f).f30f).f2424e.f1807a.get(str2) != null) {
                        throw new ClassCastException();
                    }
                    throw new IllegalStateException("Trying to create a platform view of unregistered type: " + str2);
                } catch (IllegalStateException e2) {
                    c0213k.a("error", Log.getStackTraceString(e2), null);
                    return;
                }
            case "clearFocus":
                int intValue = ((Integer) obj).intValue();
                try {
                    if (((io.flutter.plugin.platform.j) ((A.j) c0206d.f2662f).f30f).f2430k.get(intValue) != null) {
                        throw new ClassCastException();
                    }
                    Log.e("PlatformViewsController2", "Clearing focus on an unknown view with id: " + intValue);
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e3) {
                    c0213k.a("error", Log.getStackTraceString(e3), null);
                    return;
                }
            case "touch":
                List list = (List) obj;
                int intValue2 = ((Integer) list.get(0)).intValue();
                ((Integer) list.get(3)).getClass();
                ((Integer) list.get(4)).getClass();
                list.get(5);
                list.get(6);
                ((Integer) list.get(7)).getClass();
                ((Integer) list.get(8)).getClass();
                ((Double) list.get(9)).getClass();
                ((Double) list.get(10)).getClass();
                ((Integer) list.get(11)).getClass();
                ((Integer) list.get(12)).getClass();
                ((Integer) list.get(13)).getClass();
                ((Integer) list.get(14)).getClass();
                ((Number) list.get(15)).longValue();
                try {
                    A.j jVar = (A.j) c0206d.f2662f;
                    jVar.getClass();
                    io.flutter.plugin.platform.j jVar2 = (io.flutter.plugin.platform.j) jVar.f30f;
                    float f2 = jVar2.f2425f.getResources().getDisplayMetrics().density;
                    if (jVar2.f2430k.get(intValue2) != null) {
                        throw new ClassCastException();
                    }
                    Log.e("PlatformViewsController2", "Sending touch to an unknown view with id: " + intValue2);
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e4) {
                    c0213k.a("error", Log.getStackTraceString(e4), null);
                    return;
                }
            case "setDirection":
                Map map2 = (Map) obj;
                int intValue3 = ((Integer) map2.get("id")).intValue();
                ((Integer) map2.get("direction")).getClass();
                try {
                    if (((io.flutter.plugin.platform.j) ((A.j) c0206d.f2662f).f30f).f2430k.get(intValue3) != null) {
                        throw new ClassCastException();
                    }
                    Log.e("PlatformViewsController2", "Setting direction to an unknown view with id: " + intValue3);
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e5) {
                    c0213k.a("error", Log.getStackTraceString(e5), null);
                    return;
                }
            case "isSurfaceControlEnabled":
                FlutterJNI flutterJNI = ((io.flutter.plugin.platform.j) ((A.j) c0206d.f2662f).f30f).f2427h;
                c0213k.d(Boolean.valueOf(flutterJNI != null ? flutterJNI.IsSurfaceControlEnabled() : false));
                return;
            case "dispose":
                try {
                    ((A.j) c0206d.f2662f).u(((Integer) ((Map) obj).get("id")).intValue());
                    c0213k.d(null);
                    return;
                } catch (IllegalStateException e6) {
                    c0213k.a("error", Log.getStackTraceString(e6), null);
                    return;
                }
            default:
                c0213k.b();
                return;
        }
    }

    private final void f(Q q2, C0213k c0213k) {
        Q q3 = (Q) this.f2662f;
        if (((p0.a) q3.f579g) == null) {
            return;
        }
        String str = (String) q2.f578f;
        Object obj = q2.f579g;
        str.getClass();
        if (!str.equals("ProcessText.processTextAction")) {
            if (!str.equals("ProcessText.queryTextActions")) {
                c0213k.b();
                return;
            }
            try {
                c0213k.d(((p0.a) q3.f579g).c());
                return;
            } catch (IllegalStateException e2) {
                c0213k.a("error", e2.getMessage(), null);
                return;
            }
        }
        try {
            ArrayList arrayList = (ArrayList) obj;
            ((p0.a) q3.f579g).b((String) arrayList.get(0), (String) arrayList.get(1), ((Boolean) arrayList.get(2)).booleanValue(), c0213k);
        } catch (IllegalStateException e3) {
            c0213k.a("error", e3.getMessage(), null);
        }
    }

    private final void g(Q q2, C0213k c0213k) {
        boolean z2;
        boolean isStylusHandwritingAvailable;
        boolean isStylusHandwritingAvailable2;
        C0206d c0206d = (C0206d) this.f2662f;
        if (((Q) c0206d.f2662f) == null) {
            return;
        }
        String str = (String) q2.f578f;
        str.getClass();
        z2 = true;
        switch (str) {
            case "Scribe.isFeatureAvailable":
                try {
                    Q q3 = (Q) c0206d.f2662f;
                    if (Build.VERSION.SDK_INT >= 34) {
                        isStylusHandwritingAvailable = ((InputMethodManager) q3.f578f).isStylusHandwritingAvailable();
                        if (isStylusHandwritingAvailable) {
                            c0213k.d(Boolean.valueOf(z2));
                            break;
                        }
                    } else {
                        q3.getClass();
                    }
                    z2 = false;
                    c0213k.d(Boolean.valueOf(z2));
                } catch (IllegalStateException e2) {
                    c0213k.a("error", e2.getMessage(), null);
                    return;
                }
            case "Scribe.startStylusHandwriting":
                if (Build.VERSION.SDK_INT < 33) {
                    c0213k.a("error", "Requires API level 33 or higher.", null);
                    break;
                } else {
                    try {
                        Q q4 = (Q) c0206d.f2662f;
                        ((InputMethodManager) q4.f578f).startStylusHandwriting((View) q4.f579g);
                        c0213k.d(null);
                        break;
                    } catch (IllegalStateException e3) {
                        c0213k.a("error", e3.getMessage(), null);
                        return;
                    }
                }
            case "Scribe.isStylusHandwritingAvailable":
                if (Build.VERSION.SDK_INT < 34) {
                    c0213k.a("error", "Requires API level 34 or higher.", null);
                    break;
                } else {
                    try {
                        isStylusHandwritingAvailable2 = ((InputMethodManager) ((Q) c0206d.f2662f).f578f).isStylusHandwritingAvailable();
                        c0213k.d(Boolean.valueOf(isStylusHandwritingAvailable2));
                        break;
                    } catch (IllegalStateException e4) {
                        c0213k.a("error", e4.getMessage(), null);
                        return;
                    }
                }
            default:
                c0213k.b();
                break;
        }
    }

    private final void h(Q q2, C0213k c0213k) {
        int i2;
        C0206d c0206d = (C0206d) this.f2662f;
        if (((C0248a) c0206d.f2662f) == null) {
            return;
        }
        String str = (String) q2.f578f;
        str.getClass();
        i2 = 2;
        switch (str) {
            case "SensitiveContent.getContentSensitivity":
                try {
                    int a2 = ((C0248a) c0206d.f2662f).a();
                    if (a2 == 0) {
                        i2 = 0;
                    } else if (a2 == 1) {
                        i2 = 1;
                    } else if (a2 != 2) {
                        i2 = 3;
                    }
                    c0213k.d(Integer.valueOf(i2));
                    break;
                } catch (IllegalArgumentException | IllegalStateException e2) {
                    c0213k.a("error", e2.getMessage(), null);
                    return;
                }
            case "SensitiveContent.setContentSensitivity":
                try {
                    ((C0248a) c0206d.f2662f).b(a(c0206d, ((Integer) q2.f579g).intValue()));
                    break;
                } catch (IllegalArgumentException | IllegalStateException e3) {
                    c0213k.a("error", e3.getMessage(), null);
                    return;
                }
            case "SensitiveContent.isSupported":
                ((C0248a) c0206d.f2662f).getClass();
                c0213k.d(Boolean.valueOf(Build.VERSION.SDK_INT >= 35));
                break;
            default:
                c0213k.b();
                break;
        }
    }

    private final void i(Q q2, C0213k c0213k) {
        C0206d c0206d = (C0206d) this.f2662f;
        if (((io.flutter.plugin.editing.h) c0206d.f2662f) == null) {
            return;
        }
        String str = (String) q2.f578f;
        Object obj = q2.f579g;
        str.getClass();
        if (!str.equals("SpellCheck.initiateSpellCheck")) {
            c0213k.b();
            return;
        }
        try {
            ArrayList arrayList = (ArrayList) obj;
            ((io.flutter.plugin.editing.h) c0206d.f2662f).a((String) arrayList.get(0), (String) arrayList.get(1), c0213k);
        } catch (IllegalStateException e2) {
            c0213k.a("error", e2.getMessage(), null);
        }
    }

    public void b(String str) {
        InterfaceC0242a interfaceC0242a = (InterfaceC0242a) ((Q) this.f2662f).f578f;
        if (Q.f576i == null) {
            F f2 = new F();
            f2.put("alias", 1010);
            f2.put("allScroll", 1013);
            f2.put("basic", 1000);
            f2.put("cell", 1006);
            f2.put("click", 1002);
            f2.put("contextMenu", 1001);
            f2.put("copy", 1011);
            f2.put("forbidden", 1012);
            f2.put("grab", 1020);
            f2.put("grabbing", 1021);
            f2.put("help", 1003);
            f2.put("move", 1013);
            f2.put("none", 0);
            f2.put("noDrop", 1012);
            f2.put("precise", 1007);
            f2.put("text", 1008);
            f2.put("resizeColumn", 1014);
            f2.put("resizeDown", 1015);
            f2.put("resizeUpLeft", 1016);
            f2.put("resizeDownRight", 1017);
            f2.put("resizeLeft", 1014);
            f2.put("resizeLeftRight", 1014);
            f2.put("resizeRight", 1014);
            f2.put("resizeRow", 1015);
            f2.put("resizeUp", 1015);
            f2.put("resizeUpDown", 1015);
            f2.put("resizeUpLeft", 1017);
            f2.put("resizeUpRight", 1016);
            f2.put("resizeUpLeftDownRight", 1017);
            f2.put("resizeUpRightDownLeft", 1016);
            f2.put("verticalText", 1009);
            f2.put("wait", 1004);
            f2.put("zoomIn", 1018);
            f2.put("zoomOut", 1019);
            Q.f576i = f2;
        }
        interfaceC0242a.setPointerIcon(PointerIcon.getSystemIcon(((s) interfaceC0242a).getContext(), ((Integer) Q.f576i.getOrDefault(str, 1000)).intValue()));
    }

    public String c(String str, String str2) {
        C0240b c0240b = (C0240b) this.f2662f;
        Context context = c0240b.f2746b;
        if (str2 != null) {
            Locale a2 = C0240b.a(str2);
            Configuration configuration = new Configuration(c0240b.f2746b.getResources().getConfiguration());
            configuration.setLocale(a2);
            context = c0240b.f2746b.createConfigurationContext(configuration);
        }
        int identifier = context.getResources().getIdentifier(str, "string", c0240b.f2746b.getPackageName());
        if (identifier != 0) {
            return context.getResources().getString(identifier);
        }
        return null;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:195:0x0467 A[Catch: JSONException -> 0x0324, TryCatch #5 {JSONException -> 0x0324, blocks: (B:169:0x0310, B:170:0x0314, B:175:0x03c4, B:177:0x03c9, B:179:0x03f5, B:182:0x0419, B:184:0x040c, B:187:0x0413, B:188:0x0428, B:190:0x044c, B:200:0x0450, B:193:0x045d, B:195:0x0467, B:197:0x0474, B:202:0x0455, B:203:0x0479, B:205:0x048b, B:207:0x049d, B:208:0x04a2, B:210:0x04c9, B:212:0x04d9, B:215:0x05b9, B:236:0x05d3, B:238:0x05e3, B:239:0x05f0, B:283:0x04c0, B:262:0x052c, B:269:0x054a, B:233:0x058e, B:276:0x05b1, B:219:0x05cb, B:243:0x05f5, B:285:0x0319, B:288:0x0327, B:291:0x0332, B:294:0x033c, B:297:0x0347, B:300:0x0352, B:303:0x035e, B:306:0x0368, B:309:0x0372, B:312:0x037c, B:315:0x0386, B:318:0x0390, B:321:0x039b, B:324:0x03a6, B:327:0x03b1, B:222:0x0553, B:224:0x055d, B:225:0x0560, B:227:0x0576, B:228:0x0588, B:231:0x057f), top: B:168:0x0310, inners: #0, #17, #18, #19 }] */
    /* JADX WARN: Removed duplicated region for block: B:197:0x0474 A[Catch: JSONException -> 0x0324, TryCatch #5 {JSONException -> 0x0324, blocks: (B:169:0x0310, B:170:0x0314, B:175:0x03c4, B:177:0x03c9, B:179:0x03f5, B:182:0x0419, B:184:0x040c, B:187:0x0413, B:188:0x0428, B:190:0x044c, B:200:0x0450, B:193:0x045d, B:195:0x0467, B:197:0x0474, B:202:0x0455, B:203:0x0479, B:205:0x048b, B:207:0x049d, B:208:0x04a2, B:210:0x04c9, B:212:0x04d9, B:215:0x05b9, B:236:0x05d3, B:238:0x05e3, B:239:0x05f0, B:283:0x04c0, B:262:0x052c, B:269:0x054a, B:233:0x058e, B:276:0x05b1, B:219:0x05cb, B:243:0x05f5, B:285:0x0319, B:288:0x0327, B:291:0x0332, B:294:0x033c, B:297:0x0347, B:300:0x0352, B:303:0x035e, B:306:0x0368, B:309:0x0372, B:312:0x037c, B:315:0x0386, B:318:0x0390, B:321:0x039b, B:324:0x03a6, B:327:0x03b1, B:222:0x0553, B:224:0x055d, B:225:0x0560, B:227:0x0576, B:228:0x0588, B:231:0x057f), top: B:168:0x0310, inners: #0, #17, #18, #19 }] */
    @Override // m0.InterfaceC0232l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void q(Q q2, C0213k c0213k) {
        int i2;
        EnumC0207e a2;
        CharSequence z2;
        ClipDescription primaryClipDescription;
        char c2;
        Bundle bundle;
        char c3 = 11;
        boolean z3 = false;
        z3 = false;
        switch (this.f2661e) {
            case 0:
                C0206d c0206d = (C0206d) this.f2662f;
                if (((C0206d) c0206d.f2662f) != null) {
                    String str = (String) q2.f578f;
                    try {
                        if (str.hashCode() == -1307105544 && str.equals("activateSystemCursor")) {
                            try {
                                ((C0206d) c0206d.f2662f).b((String) ((HashMap) q2.f579g).get("kind"));
                                c0213k.d(Boolean.TRUE);
                            } catch (Exception e2) {
                                c0213k.a("error", "Error when setting cursors: " + e2.getMessage(), null);
                            }
                        }
                    } catch (Exception e3) {
                        c0213k.a("error", "Unhandled error: " + e3.getMessage(), null);
                        return;
                    }
                }
                break;
            case 1:
            case F.j.STRING_FIELD_NUMBER /* 5 */:
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
            case 10:
            case 12:
            default:
                Q q3 = (Q) this.f2662f;
                if (((io.flutter.plugin.editing.j) q3.f579g) != null) {
                    String str2 = (String) q2.f578f;
                    Object obj = q2.f579g;
                    str2.getClass();
                    switch (str2.hashCode()) {
                        case -1779068172:
                            if (str2.equals("TextInput.setPlatformViewClient")) {
                                c2 = 0;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case -1015421462:
                            if (str2.equals("TextInput.setEditingState")) {
                                c2 = 1;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case -37561188:
                            if (str2.equals("TextInput.setClient")) {
                                c2 = 2;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 270476819:
                            if (str2.equals("TextInput.hide")) {
                                c2 = 3;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 270803918:
                            if (str2.equals("TextInput.show")) {
                                c2 = 4;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 649192816:
                            if (str2.equals("TextInput.sendAppPrivateCommand")) {
                                c2 = 5;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1204752139:
                            if (str2.equals("TextInput.setEditableSizeAndTransform")) {
                                c2 = 6;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1727570905:
                            if (str2.equals("TextInput.finishAutofillContext")) {
                                c2 = 7;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1904427655:
                            if (str2.equals("TextInput.clearClient")) {
                                c2 = '\b';
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 2113369584:
                            if (str2.equals("TextInput.requestAutofill")) {
                                c2 = '\t';
                                break;
                            }
                            c2 = 65535;
                            break;
                        default:
                            c2 = 65535;
                            break;
                    }
                    switch (c2) {
                        case 0:
                            try {
                                JSONObject jSONObject = (JSONObject) obj;
                                int i3 = jSONObject.getInt("platformViewId");
                                boolean optBoolean = jSONObject.optBoolean("usesVirtualDisplay", false);
                                io.flutter.plugin.editing.l lVar = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                                View view = lVar.f2397a;
                                if (optBoolean) {
                                    view.requestFocus();
                                    lVar.f2401e = new C0063n(3, i3);
                                    lVar.f2398b.restartInput(view);
                                    lVar.f2405i = false;
                                } else {
                                    lVar.f2401e = new C0063n(4, i3);
                                    lVar.f2406j = null;
                                }
                                c0213k.d(null);
                                break;
                            } catch (JSONException e4) {
                                c0213k.a("error", e4.getMessage(), null);
                            }
                        case 1:
                            try {
                                ((io.flutter.plugin.editing.j) q3.f579g).c(C0219q.a((JSONObject) obj));
                                c0213k.d(null);
                                break;
                            } catch (JSONException e5) {
                                c0213k.a("error", e5.getMessage(), null);
                                return;
                            }
                        case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                            try {
                                JSONArray jSONArray = (JSONArray) obj;
                                ((io.flutter.plugin.editing.j) q3.f579g).a(jSONArray.getInt(0), C0217o.a(jSONArray.getJSONObject(1)));
                                c0213k.d(null);
                                break;
                            } catch (NoSuchFieldException | JSONException e6) {
                                c0213k.a("error", e6.getMessage(), null);
                                return;
                            }
                        case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                            io.flutter.plugin.editing.l lVar2 = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                            if (lVar2.f2401e.f641b == 4) {
                                lVar2.c();
                            } else {
                                View view2 = lVar2.f2397a;
                                lVar2.c();
                                lVar2.f2398b.hideSoftInputFromWindow(view2.getApplicationWindowToken(), 0);
                            }
                            c0213k.d(null);
                            break;
                        case F.j.LONG_FIELD_NUMBER /* 4 */:
                            io.flutter.plugin.editing.l lVar3 = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                            InputMethodManager inputMethodManager = lVar3.f2398b;
                            View view3 = lVar3.f2397a;
                            C0217o c0217o = lVar3.f2402f;
                            if (c0217o == null || c0217o.f2715g.f2722a != 11) {
                                view3.requestFocus();
                                inputMethodManager.showSoftInput(view3, 0);
                            } else {
                                lVar3.c();
                                inputMethodManager.hideSoftInputFromWindow(view3.getApplicationWindowToken(), 0);
                            }
                            c0213k.d(null);
                            break;
                        case F.j.STRING_FIELD_NUMBER /* 5 */:
                            try {
                                JSONObject jSONObject2 = (JSONObject) obj;
                                String string = jSONObject2.getString("action");
                                String string2 = jSONObject2.getString("data");
                                if (string2 == null || string2.isEmpty()) {
                                    bundle = null;
                                } else {
                                    bundle = new Bundle();
                                    bundle.putString("data", string2);
                                }
                                io.flutter.plugin.editing.l lVar4 = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                                lVar4.f2398b.sendAppPrivateCommand(lVar4.f2397a, string, bundle);
                                c0213k.d(null);
                                break;
                            } catch (JSONException e7) {
                                c0213k.a("error", e7.getMessage(), null);
                                return;
                            }
                            break;
                        case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                            try {
                                JSONObject jSONObject3 = (JSONObject) obj;
                                double d2 = jSONObject3.getDouble("width");
                                double d3 = jSONObject3.getDouble("height");
                                JSONArray jSONArray2 = jSONObject3.getJSONArray("transform");
                                double[] dArr = new double[16];
                                for (int i4 = 0; i4 < 16; i4++) {
                                    dArr[i4] = jSONArray2.getDouble(i4);
                                }
                                ((io.flutter.plugin.editing.j) q3.f579g).b(d2, d3, dArr);
                                c0213k.d(null);
                                break;
                            } catch (JSONException e8) {
                                c0213k.a("error", e8.getMessage(), null);
                                return;
                            }
                        case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                            io.flutter.plugin.editing.j jVar = (io.flutter.plugin.editing.j) q3.f579g;
                            boolean booleanValue = ((Boolean) obj).booleanValue();
                            if (Build.VERSION.SDK_INT >= 26) {
                                AutofillManager autofillManager = jVar.f2393a.f2399c;
                                if (autofillManager != null) {
                                    if (booleanValue) {
                                        autofillManager.commit();
                                    } else {
                                        autofillManager.cancel();
                                    }
                                }
                            } else {
                                jVar.getClass();
                            }
                            c0213k.d(null);
                            break;
                        case F.j.BYTES_FIELD_NUMBER /* 8 */:
                            io.flutter.plugin.editing.l lVar5 = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                            View view4 = lVar5.f2397a;
                            if (lVar5.f2401e.f641b != 3) {
                                lVar5.f2404h.e(lVar5);
                                lVar5.c();
                                lVar5.f2402f = null;
                                lVar5.d(null);
                                lVar5.f2401e = new C0063n(1, 0);
                                lVar5.f2409m = null;
                                Field field = x.f3034a;
                                w.Q a3 = AbstractC0293q.a(view4);
                                if (a3 != null && !a3.f3004a.m(8)) {
                                    lVar5.f2398b.restartInput(view4);
                                }
                            }
                            c0213k.d(null);
                            break;
                        case '\t':
                            io.flutter.plugin.editing.l lVar6 = ((io.flutter.plugin.editing.j) q3.f579g).f2393a;
                            View view5 = lVar6.f2397a;
                            if (Build.VERSION.SDK_INT >= 26 && lVar6.f2399c != null && lVar6.f2403g != null) {
                                String str3 = (String) lVar6.f2402f.f2718j.f246a;
                                int[] iArr = new int[2];
                                view5.getLocationOnScreen(iArr);
                                Rect rect = new Rect(lVar6.f2409m);
                                rect.offset(iArr[0], iArr[1]);
                                lVar6.f2399c.notifyViewEntered(view5, str3.hashCode(), rect);
                            }
                            c0213k.d(null);
                            break;
                        default:
                            c0213k.b();
                            break;
                    }
                }
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                Q q4 = (Q) this.f2662f;
                if (((A.j) q4.f579g) != null) {
                    String str4 = (String) q2.f578f;
                    Object obj2 = q2.f579g;
                    try {
                        switch (str4.hashCode()) {
                            case -1501580720:
                                if (str4.equals("SystemNavigator.setFrameworkHandlesBack")) {
                                    c3 = '\t';
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -931781241:
                                if (str4.equals("Share.invoke")) {
                                    c3 = 14;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -766342101:
                                if (str4.equals("SystemNavigator.pop")) {
                                    c3 = '\n';
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -720677196:
                                if (str4.equals("Clipboard.setData")) {
                                    c3 = '\f';
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -577225884:
                                if (str4.equals("SystemChrome.setSystemUIChangeListener")) {
                                    c3 = 6;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -548468504:
                                if (str4.equals("SystemChrome.setApplicationSwitcherDescription")) {
                                    c3 = 3;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -247230243:
                                if (str4.equals("HapticFeedback.vibrate")) {
                                    c3 = 1;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case -215273374:
                                if (str4.equals("SystemSound.play")) {
                                    c3 = 0;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 241845679:
                                if (str4.equals("SystemChrome.restoreSystemUIOverlays")) {
                                    c3 = 7;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 875995648:
                                if (str4.equals("Clipboard.hasStrings")) {
                                    c3 = '\r';
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 1128339786:
                                if (str4.equals("SystemChrome.setEnabledSystemUIMode")) {
                                    c3 = 5;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 1390477857:
                                if (str4.equals("SystemChrome.setSystemUIOverlayStyle")) {
                                    c3 = '\b';
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 1514180520:
                                if (str4.equals("Clipboard.getData")) {
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 1674312266:
                                if (str4.equals("SystemChrome.setEnabledSystemUIOverlays")) {
                                    c3 = 4;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            case 2119655719:
                                if (str4.equals("SystemChrome.setPreferredOrientations")) {
                                    c3 = 2;
                                    break;
                                }
                                c3 = 65535;
                                break;
                            default:
                                c3 = 65535;
                                break;
                        }
                        switch (c3) {
                            case 0:
                                try {
                                    int c4 = E0.h.c((String) obj2);
                                    io.flutter.plugin.platform.e eVar = (io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f;
                                    if (c4 == 1) {
                                        eVar.f2419a.getWindow().getDecorView().playSoundEffect(0);
                                    }
                                    c0213k.d(null);
                                    break;
                                } catch (NoSuchFieldException e9) {
                                    c0213k.a("error", e9.getMessage(), null);
                                    return;
                                }
                            case 1:
                                try {
                                    ((A.j) q4.f579g).F(E0.h.b((String) obj2));
                                    c0213k.d(null);
                                    break;
                                } catch (NoSuchFieldException e10) {
                                    c0213k.a("error", e10.getMessage(), null);
                                    return;
                                }
                            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                                try {
                                    ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2419a.setRequestedOrientation(Q.o(q4, (JSONArray) obj2));
                                    c0213k.d(null);
                                    break;
                                } catch (NoSuchFieldException | JSONException e11) {
                                    c0213k.a("error", e11.getMessage(), null);
                                    return;
                                }
                            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                                try {
                                    JSONObject jSONObject4 = (JSONObject) obj2;
                                    int i5 = jSONObject4.getInt("primaryColor");
                                    if (i5 != 0) {
                                        i5 |= -16777216;
                                    }
                                    String string3 = jSONObject4.getString("label");
                                    Activity activity = ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2419a;
                                    if (Build.VERSION.SDK_INT < 28) {
                                        activity.setTaskDescription(new ActivityManager.TaskDescription(string3, (Bitmap) null, i5));
                                    } else {
                                        activity.setTaskDescription(J.j.c(string3, i5));
                                    }
                                    c0213k.d(null);
                                    break;
                                } catch (JSONException e12) {
                                    c0213k.a("error", e12.getMessage(), null);
                                    return;
                                }
                            case F.j.LONG_FIELD_NUMBER /* 4 */:
                                try {
                                    ((A.j) q4.f579g).D(Q.p(q4, (JSONArray) obj2));
                                    c0213k.d(null);
                                    break;
                                } catch (NoSuchFieldException | JSONException e13) {
                                    c0213k.a("error", e13.getMessage(), null);
                                    return;
                                }
                            case F.j.STRING_FIELD_NUMBER /* 5 */:
                                try {
                                    int r = Q.r(q4, (String) obj2);
                                    io.flutter.plugin.platform.e eVar2 = (io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f;
                                    if (r == 1) {
                                        i2 = 1798;
                                    } else if (r == 2) {
                                        i2 = 3846;
                                    } else if (r != 3) {
                                        if (r == 4 && Build.VERSION.SDK_INT >= 29) {
                                            i2 = 1792;
                                        }
                                        c0213k.d(null);
                                        break;
                                    } else {
                                        i2 = 5894;
                                    }
                                    eVar2.f2423e = i2;
                                    eVar2.b();
                                    c0213k.d(null);
                                } catch (NoSuchFieldException | JSONException e14) {
                                    c0213k.a("error", e14.getMessage(), null);
                                    return;
                                }
                                break;
                            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                                io.flutter.plugin.platform.e eVar3 = (io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f;
                                View decorView = eVar3.f2419a.getWindow().getDecorView();
                                decorView.setOnSystemUiVisibilityChangeListener(new io.flutter.plugin.platform.d(eVar3, decorView));
                                c0213k.d(null);
                                break;
                            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                                ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).b();
                                c0213k.d(null);
                                break;
                            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                                try {
                                    ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).a(Q.s(q4, (JSONObject) obj2));
                                    c0213k.d(null);
                                    break;
                                } catch (NoSuchFieldException | JSONException e15) {
                                    c0213k.a("error", e15.getMessage(), null);
                                    return;
                                }
                            case '\t':
                                boolean booleanValue2 = ((Boolean) obj2).booleanValue();
                                InterfaceC0106i interfaceC0106i = ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2421c;
                                if (interfaceC0106i != null) {
                                    ((AbstractActivityC0103f) interfaceC0106i).h(booleanValue2);
                                }
                                c0213k.d(null);
                                break;
                            case '\n':
                                ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2419a.finish();
                                c0213k.d(null);
                                break;
                            case 11:
                                String str5 = (String) obj2;
                                if (str5 != null) {
                                    try {
                                        a2 = EnumC0207e.a(str5);
                                    } catch (NoSuchFieldException unused) {
                                        c0213k.a("error", "No such clipboard content format: ".concat(str5), null);
                                    }
                                    z2 = ((A.j) q4.f579g).z(a2);
                                    if (z2 == null) {
                                        JSONObject jSONObject5 = new JSONObject();
                                        jSONObject5.put("text", z2);
                                        c0213k.d(jSONObject5);
                                        break;
                                    } else {
                                        c0213k.d(null);
                                        break;
                                    }
                                }
                                a2 = null;
                                z2 = ((A.j) q4.f579g).z(a2);
                                if (z2 == null) {
                                }
                            case '\f':
                                ((ClipboardManager) ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2419a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("text label?", ((JSONObject) obj2).getString("text")));
                                c0213k.d(null);
                                break;
                            case '\r':
                                ClipboardManager clipboardManager = (ClipboardManager) ((io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f).f2419a.getSystemService("clipboard");
                                if (clipboardManager.hasPrimaryClip() && (primaryClipDescription = clipboardManager.getPrimaryClipDescription()) != null) {
                                    z3 = primaryClipDescription.hasMimeType("text/*");
                                }
                                JSONObject jSONObject6 = new JSONObject();
                                jSONObject6.put("value", z3);
                                c0213k.d(jSONObject6);
                                break;
                            case 14:
                                io.flutter.plugin.platform.e eVar4 = (io.flutter.plugin.platform.e) ((A.j) q4.f579g).f30f;
                                Intent intent = new Intent();
                                intent.setAction("android.intent.action.SEND");
                                intent.setType("text/plain");
                                intent.putExtra("android.intent.extra.TEXT", (String) obj2);
                                eVar4.f2419a.startActivity(Intent.createChooser(intent, null));
                                c0213k.d(null);
                                break;
                            default:
                                c0213k.b();
                                break;
                        }
                    } catch (JSONException e16) {
                        c0213k.a("error", "JSON error: " + e16.getMessage(), null);
                        return;
                    }
                    c0213k.a("error", "JSON error: " + e16.getMessage(), null);
                }
                break;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                d(q2, c0213k);
                break;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                e(q2, c0213k);
                break;
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                f(q2, c0213k);
                break;
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                C0214l c0214l = (C0214l) this.f2662f;
                String str6 = (String) q2.f578f;
                Object obj3 = q2.f579g;
                str6.getClass();
                if (str6.equals("get")) {
                    c0214l.f2703f = true;
                    if (c0214l.f2702e || !c0214l.f2698a) {
                        c0213k.d(C0214l.a(c0214l.f2699b));
                        break;
                    } else {
                        c0214l.f2701d = c0213k;
                        break;
                    }
                } else if (str6.equals("put")) {
                    c0214l.f2699b = (byte[]) obj3;
                    c0213k.d(null);
                    break;
                } else {
                    c0213k.b();
                    break;
                }
            case 9:
                g(q2, c0213k);
                break;
            case 11:
                h(q2, c0213k);
                break;
            case 13:
                i(q2, c0213k);
                break;
        }
    }

    @Override // M0.d
    public Object t(M0.e eVar, w0.c cVar) {
        Object t2 = ((M0.d) this.f2662f).t(new C0021w(eVar, 1), cVar);
        return t2 == x0.a.f3053e ? t2 : u0.g.f2964a;
    }

    public /* synthetic */ C0206d(int i2, Object obj) {
        this.f2661e = i2;
        this.f2662f = obj;
    }

    public C0206d(C0128b c0128b, int i2) {
        this.f2661e = i2;
        switch (i2) {
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                new C0051b(c0128b, "flutter/platform_views_2", C0236p.f2742a, 8).H(new C0206d(4, this));
                break;
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                new C0051b(c0128b, "flutter/platform_views", C0236p.f2742a, 8).H(new C0206d(3, this));
                break;
            case 10:
                new C0051b(c0128b, "flutter/scribe", C0229i.f2738a, 8).H(new C0206d(9, this));
                break;
            case 12:
                new C0051b(c0128b, "flutter/sensitivecontent", C0236p.f2742a, 8).H(new C0206d(11, this));
                break;
            case 14:
                new C0051b(c0128b, "flutter/spellcheck", C0236p.f2742a, 8).H(new C0206d(13, this));
                break;
            default:
                new C0051b(c0128b, "flutter/mousecursor", C0236p.f2742a, 8).H(new C0206d(0, this));
                break;
        }
    }
}
