package j;

import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;

/* renamed from: j.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0191a implements Iterable {

    /* renamed from: e, reason: collision with root package name */
    public final WeakHashMap f2598e = new WeakHashMap();

    public C0191a() {
        new HashMap();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0191a)) {
            return false;
        }
        C0191a c0191a = (C0191a) obj;
        c0191a.getClass();
        iterator();
        c0191a.iterator();
        return true;
    }

    public final int hashCode() {
        iterator();
        return 0;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        C0192b c0192b = new C0192b();
        this.f2598e.put(c0192b, Boolean.FALSE);
        return c0192b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("[");
        iterator();
        sb.append("]");
        return sb.toString();
    }
}
