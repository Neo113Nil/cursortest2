package androidx.recyclerview.widget;

import A.b;
import A.j;
import E.a;
import L.C0064o;
import L.C0066q;
import L.D;
import L.G;
import L.L;
import L.N;
import L.O;
import L.x;
import L.y;
import a.AbstractC0068a;
import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.util.BitSet;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends x {

    /* renamed from: h, reason: collision with root package name */
    public final int f1593h;

    /* renamed from: i, reason: collision with root package name */
    public final O[] f1594i;

    /* renamed from: j, reason: collision with root package name */
    public final C0066q f1595j;

    /* renamed from: k, reason: collision with root package name */
    public final C0066q f1596k;

    /* renamed from: l, reason: collision with root package name */
    public final int f1597l;

    /* renamed from: m, reason: collision with root package name */
    public final boolean f1598m;

    /* renamed from: n, reason: collision with root package name */
    public final boolean f1599n = false;

    /* renamed from: o, reason: collision with root package name */
    public final j f1600o;

    /* renamed from: p, reason: collision with root package name */
    public final int f1601p;

    /* renamed from: q, reason: collision with root package name */
    public N f1602q;
    public final boolean r;

    /* renamed from: s, reason: collision with root package name */
    public final b f1603s;

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f1593h = -1;
        this.f1598m = false;
        j jVar = new j(9, false);
        this.f1600o = jVar;
        this.f1601p = 2;
        new Rect();
        new a(11, this);
        this.r = true;
        this.f1603s = new b(3, this);
        C0064o w2 = x.w(context, attributeSet, i2, i3);
        int i4 = w2.f644b;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        a(null);
        if (i4 != this.f1597l) {
            this.f1597l = i4;
            C0066q c0066q = this.f1595j;
            this.f1595j = this.f1596k;
            this.f1596k = c0066q;
            H();
        }
        int i5 = w2.f645c;
        a(null);
        if (i5 != this.f1593h) {
            jVar.f30f = null;
            H();
            this.f1593h = i5;
            new BitSet(this.f1593h);
            this.f1594i = new O[this.f1593h];
            for (int i6 = 0; i6 < this.f1593h; i6++) {
                this.f1594i[i6] = new O(this, i6);
            }
            H();
        }
        boolean z2 = w2.f646d;
        a(null);
        N n2 = this.f1602q;
        if (n2 != null && n2.f562l != z2) {
            n2.f562l = z2;
        }
        this.f1598m = z2;
        H();
        this.f1595j = C0066q.a(this, this.f1597l);
        this.f1596k = C0066q.a(this, 1 - this.f1597l);
    }

    @Override // L.x
    public final void A(AccessibilityEvent accessibilityEvent) {
        super.A(accessibilityEvent);
        if (p() > 0) {
            View M2 = M(false);
            View L2 = L(false);
            if (M2 == null || L2 == null) {
                return;
            }
            ((y) M2.getLayoutParams()).getClass();
            throw null;
        }
    }

    @Override // L.x
    public final void B(Parcelable parcelable) {
        if (parcelable instanceof N) {
            this.f1602q = (N) parcelable;
            H();
        }
    }

    @Override // L.x
    public final Parcelable C() {
        N n2 = this.f1602q;
        if (n2 != null) {
            N n3 = new N();
            n3.f557g = n2.f557g;
            n3.f555e = n2.f555e;
            n3.f556f = n2.f556f;
            n3.f558h = n2.f558h;
            n3.f559i = n2.f559i;
            n3.f560j = n2.f560j;
            n3.f562l = n2.f562l;
            n3.f563m = n2.f563m;
            n3.f564n = n2.f564n;
            n3.f561k = n2.f561k;
            return n3;
        }
        N n4 = new N();
        n4.f562l = this.f1598m;
        n4.f563m = false;
        n4.f564n = false;
        n4.f559i = 0;
        if (p() <= 0) {
            n4.f555e = -1;
            n4.f556f = -1;
            n4.f557g = 0;
            return n4;
        }
        N();
        n4.f555e = 0;
        View L2 = this.f1599n ? L(true) : M(true);
        if (L2 != null) {
            ((y) L2.getLayoutParams()).getClass();
            throw null;
        }
        n4.f556f = -1;
        int i2 = this.f1593h;
        n4.f557g = i2;
        n4.f558h = new int[i2];
        for (int i3 = 0; i3 < this.f1593h; i3++) {
            O o2 = this.f1594i[i3];
            int i4 = o2.f566b;
            if (i4 == Integer.MIN_VALUE) {
                if (o2.f565a.size() == 0) {
                    i4 = Integer.MIN_VALUE;
                } else {
                    View view = (View) o2.f565a.get(0);
                    L l2 = (L) view.getLayoutParams();
                    o2.f566b = o2.f569e.f1595j.c(view);
                    l2.getClass();
                    i4 = o2.f566b;
                }
            }
            if (i4 != Integer.MIN_VALUE) {
                i4 -= this.f1595j.e();
            }
            n4.f558h[i3] = i4;
        }
        return n4;
    }

    @Override // L.x
    public final void D(int i2) {
        if (i2 == 0) {
            J();
        }
    }

    public final boolean J() {
        if (p() == 0 || this.f1601p == 0 || !this.f663e) {
            return false;
        }
        boolean z2 = this.f1599n;
        if (z2) {
            O();
            N();
        } else {
            N();
            O();
        }
        int p2 = p();
        int i2 = p2 - 1;
        int i3 = this.f1593h;
        new BitSet(i3).set(0, i3, true);
        if (this.f1597l == 1) {
            RecyclerView recyclerView = this.f660b;
            Field field = w.x.f3034a;
            if (recyclerView.getLayoutDirection() != 1) {
            }
        }
        if (z2) {
            p2 = -1;
        } else {
            i2 = 0;
        }
        if (i2 == p2) {
            return false;
        }
        ((L) o(i2).getLayoutParams()).getClass();
        throw null;
    }

    public final void K(G g2) {
        if (p() == 0) {
            return;
        }
        boolean z2 = !this.r;
        View M2 = M(z2);
        View L2 = L(z2);
        if (p() == 0 || g2.a() == 0 || M2 == null || L2 == null) {
            return;
        }
        ((y) M2.getLayoutParams()).getClass();
        throw null;
    }

    public final View L(boolean z2) {
        int e2 = this.f1595j.e();
        int d2 = this.f1595j.d();
        View view = null;
        for (int p2 = p() - 1; p2 >= 0; p2--) {
            View o2 = o(p2);
            int c2 = this.f1595j.c(o2);
            int b2 = this.f1595j.b(o2);
            if (b2 > e2 && c2 < d2) {
                if (b2 <= d2 || !z2) {
                    return o2;
                }
                if (view == null) {
                    view = o2;
                }
            }
        }
        return view;
    }

    public final View M(boolean z2) {
        int e2 = this.f1595j.e();
        int d2 = this.f1595j.d();
        int p2 = p();
        View view = null;
        for (int i2 = 0; i2 < p2; i2++) {
            View o2 = o(i2);
            int c2 = this.f1595j.c(o2);
            if (this.f1595j.b(o2) > e2 && c2 < d2) {
                if (c2 >= e2 || !z2) {
                    return o2;
                }
                if (view == null) {
                    view = o2;
                }
            }
        }
        return view;
    }

    public final void N() {
        if (p() == 0) {
            return;
        }
        x.v(o(0));
        throw null;
    }

    public final void O() {
        int p2 = p();
        if (p2 == 0) {
            return;
        }
        x.v(o(p2 - 1));
        throw null;
    }

    @Override // L.x
    public final void a(String str) {
        RecyclerView recyclerView;
        if (this.f1602q != null || (recyclerView = this.f660b) == null) {
            return;
        }
        recyclerView.b(str);
    }

    @Override // L.x
    public final boolean b() {
        return this.f1597l == 0;
    }

    @Override // L.x
    public final boolean c() {
        return this.f1597l == 1;
    }

    @Override // L.x
    public final boolean d(y yVar) {
        return yVar instanceof L;
    }

    @Override // L.x
    public final int f(G g2) {
        if (p() == 0) {
            return 0;
        }
        boolean z2 = !this.r;
        return AbstractC0068a.k(g2, this.f1595j, M(z2), L(z2), this, this.r);
    }

    @Override // L.x
    public final void g(G g2) {
        K(g2);
    }

    @Override // L.x
    public final int h(G g2) {
        if (p() == 0) {
            return 0;
        }
        boolean z2 = !this.r;
        return AbstractC0068a.l(g2, this.f1595j, M(z2), L(z2), this, this.r);
    }

    @Override // L.x
    public final int i(G g2) {
        if (p() == 0) {
            return 0;
        }
        boolean z2 = !this.r;
        return AbstractC0068a.k(g2, this.f1595j, M(z2), L(z2), this, this.r);
    }

    @Override // L.x
    public final void j(G g2) {
        K(g2);
    }

    @Override // L.x
    public final int k(G g2) {
        if (p() == 0) {
            return 0;
        }
        boolean z2 = !this.r;
        return AbstractC0068a.l(g2, this.f1595j, M(z2), L(z2), this, this.r);
    }

    @Override // L.x
    public final y l() {
        return this.f1597l == 0 ? new L(-2, -1) : new L(-1, -2);
    }

    @Override // L.x
    public final y m(Context context, AttributeSet attributeSet) {
        return new L(context, attributeSet);
    }

    @Override // L.x
    public final y n(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new L((ViewGroup.MarginLayoutParams) layoutParams) : new L(layoutParams);
    }

    @Override // L.x
    public final int q(D d2, G g2) {
        if (this.f1597l == 1) {
            return this.f1593h;
        }
        super.q(d2, g2);
        return 1;
    }

    @Override // L.x
    public final int x(D d2, G g2) {
        if (this.f1597l == 0) {
            return this.f1593h;
        }
        super.x(d2, g2);
        return 1;
    }

    @Override // L.x
    public final boolean y() {
        return this.f1601p != 0;
    }

    @Override // L.x
    public final void z(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f660b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.f1603s);
        }
        for (int i2 = 0; i2 < this.f1593h; i2++) {
            O o2 = this.f1594i[i2];
            o2.f565a.clear();
            o2.f566b = Integer.MIN_VALUE;
            o2.f567c = Integer.MIN_VALUE;
        }
        recyclerView.requestLayout();
    }
}
