package androidx.recyclerview.widget;

import A.b;
import A.d;
import A.j;
import E.a;
import E0.i;
import L.A;
import L.AbstractC0067s;
import L.B;
import L.C;
import L.C0051b;
import L.C0052c;
import L.C0053d;
import L.C0057h;
import L.C0059j;
import L.D;
import L.E;
import L.F;
import L.G;
import L.I;
import L.K;
import L.RunnableC0061l;
import L.S;
import L.r;
import L.t;
import L.u;
import L.v;
import L.x;
import L.z;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import c0.H;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import w.AbstractC0272B;
import w.AbstractC0292p;
import w.C0283g;
import w.y;

/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup {

    /* renamed from: l0, reason: collision with root package name */
    public static final int[] f1537l0 = {R.attr.nestedScrollingEnabled};

    /* renamed from: m0, reason: collision with root package name */
    public static final int[] f1538m0 = {R.attr.clipToPadding};

    /* renamed from: n0, reason: collision with root package name */
    public static final Class[] f1539n0;

    /* renamed from: o0, reason: collision with root package name */
    public static final r f1540o0;

    /* renamed from: A, reason: collision with root package name */
    public int f1541A;

    /* renamed from: B, reason: collision with root package name */
    public final int f1542B;

    /* renamed from: C, reason: collision with root package name */
    public u f1543C;

    /* renamed from: D, reason: collision with root package name */
    public EdgeEffect f1544D;

    /* renamed from: E, reason: collision with root package name */
    public EdgeEffect f1545E;

    /* renamed from: F, reason: collision with root package name */
    public EdgeEffect f1546F;

    /* renamed from: G, reason: collision with root package name */
    public EdgeEffect f1547G;

    /* renamed from: H, reason: collision with root package name */
    public v f1548H;

    /* renamed from: I, reason: collision with root package name */
    public int f1549I;

    /* renamed from: J, reason: collision with root package name */
    public int f1550J;

    /* renamed from: K, reason: collision with root package name */
    public VelocityTracker f1551K;

    /* renamed from: L, reason: collision with root package name */
    public int f1552L;

    /* renamed from: M, reason: collision with root package name */
    public int f1553M;

    /* renamed from: N, reason: collision with root package name */
    public int f1554N;

    /* renamed from: O, reason: collision with root package name */
    public int f1555O;

    /* renamed from: P, reason: collision with root package name */
    public int f1556P;

    /* renamed from: Q, reason: collision with root package name */
    public final int f1557Q;

    /* renamed from: R, reason: collision with root package name */
    public final int f1558R;

    /* renamed from: S, reason: collision with root package name */
    public final float f1559S;
    public final float T;

    /* renamed from: U, reason: collision with root package name */
    public boolean f1560U;

    /* renamed from: V, reason: collision with root package name */
    public final I f1561V;

    /* renamed from: W, reason: collision with root package name */
    public RunnableC0061l f1562W;

    /* renamed from: a0, reason: collision with root package name */
    public final C0059j f1563a0;

    /* renamed from: b0, reason: collision with root package name */
    public final G f1564b0;

    /* renamed from: c0, reason: collision with root package name */
    public ArrayList f1565c0;

    /* renamed from: d0, reason: collision with root package name */
    public final a f1566d0;

    /* renamed from: e, reason: collision with root package name */
    public final D f1567e;

    /* renamed from: e0, reason: collision with root package name */
    public K f1568e0;

    /* renamed from: f, reason: collision with root package name */
    public F f1569f;

    /* renamed from: f0, reason: collision with root package name */
    public C0283g f1570f0;

    /* renamed from: g, reason: collision with root package name */
    public final C0051b f1571g;

    /* renamed from: g0, reason: collision with root package name */
    public final int[] f1572g0;

    /* renamed from: h, reason: collision with root package name */
    public final C0051b f1573h;

    /* renamed from: h0, reason: collision with root package name */
    public final int[] f1574h0;

    /* renamed from: i, reason: collision with root package name */
    public final a f1575i;
    public final int[] i0;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1576j;

    /* renamed from: j0, reason: collision with root package name */
    public final ArrayList f1577j0;

    /* renamed from: k, reason: collision with root package name */
    public final Rect f1578k;
    public final b k0;

    /* renamed from: l, reason: collision with root package name */
    public final Rect f1579l;

    /* renamed from: m, reason: collision with root package name */
    public x f1580m;

    /* renamed from: n, reason: collision with root package name */
    public final ArrayList f1581n;

    /* renamed from: o, reason: collision with root package name */
    public final ArrayList f1582o;

    /* renamed from: p, reason: collision with root package name */
    public C0057h f1583p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f1584q;
    public boolean r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f1585s;

    /* renamed from: t, reason: collision with root package name */
    public int f1586t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1587u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f1588v;

    /* renamed from: w, reason: collision with root package name */
    public int f1589w;

    /* renamed from: x, reason: collision with root package name */
    public final AccessibilityManager f1590x;

    /* renamed from: y, reason: collision with root package name */
    public boolean f1591y;

    /* renamed from: z, reason: collision with root package name */
    public boolean f1592z;

    static {
        Class cls = Integer.TYPE;
        f1539n0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f1540o0 = new r();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        float a2;
        Constructor constructor;
        this.f1567e = new D(this);
        this.f1575i = new a();
        this.f1578k = new Rect();
        this.f1579l = new Rect();
        new RectF();
        this.f1581n = new ArrayList();
        this.f1582o = new ArrayList();
        this.f1586t = 0;
        this.f1591y = false;
        this.f1592z = false;
        this.f1541A = 0;
        this.f1542B = 0;
        this.f1543C = new u();
        C0053d c0053d = new C0053d();
        Object[] objArr = null;
        c0053d.f653a = null;
        c0053d.f654b = new ArrayList();
        c0053d.f655c = 250L;
        c0053d.f656d = 250L;
        c0053d.f588e = new ArrayList();
        c0053d.f589f = new ArrayList();
        c0053d.f590g = new ArrayList();
        c0053d.f591h = new ArrayList();
        c0053d.f592i = new ArrayList();
        c0053d.f593j = new ArrayList();
        c0053d.f594k = new ArrayList();
        c0053d.f595l = new ArrayList();
        c0053d.f596m = new ArrayList();
        c0053d.f597n = new ArrayList();
        c0053d.f598o = new ArrayList();
        this.f1548H = c0053d;
        this.f1549I = 0;
        this.f1550J = -1;
        this.f1559S = Float.MIN_VALUE;
        this.T = Float.MIN_VALUE;
        boolean z2 = true;
        this.f1560U = true;
        this.f1561V = new I(this);
        this.f1563a0 = new C0059j();
        G g2 = new G();
        g2.f537a = 0;
        g2.f538b = false;
        g2.f539c = false;
        g2.f540d = false;
        g2.f541e = false;
        this.f1564b0 = g2;
        a aVar = new a(10);
        this.f1566d0 = aVar;
        this.f1572g0 = new int[2];
        this.f1574h0 = new int[2];
        this.i0 = new int[2];
        this.f1577j0 = new ArrayList();
        this.k0 = new b(2, this);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1538m0, 0, 0);
            this.f1576j = obtainStyledAttributes.getBoolean(0, true);
            obtainStyledAttributes.recycle();
        } else {
            this.f1576j = true;
        }
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f1556P = viewConfiguration.getScaledTouchSlop();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            Method method = AbstractC0272B.f2975a;
            a2 = y.a(viewConfiguration);
        } else {
            a2 = AbstractC0272B.a(viewConfiguration, context);
        }
        this.f1559S = a2;
        this.T = i2 >= 26 ? y.b(viewConfiguration) : AbstractC0272B.a(viewConfiguration, context);
        this.f1557Q = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1558R = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.f1548H.f653a = aVar;
        this.f1571g = new C0051b(new a(9, this));
        this.f1573h = new C0051b(new j(8, this));
        Field field = w.x.f3034a;
        if ((i2 >= 26 ? w.r.c(this) : 0) == 0 && i2 >= 26) {
            w.r.m(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f1590x = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new K(this));
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, K.a.f524a, 0, 0);
            String string = obtainStyledAttributes2.getString(7);
            if (obtainStyledAttributes2.getInt(1, -1) == -1) {
                setDescendantFocusability(262144);
            }
            if (obtainStyledAttributes2.getBoolean(2, false)) {
                StateListDrawable stateListDrawable = (StateListDrawable) obtainStyledAttributes2.getDrawable(5);
                Drawable drawable = obtainStyledAttributes2.getDrawable(6);
                StateListDrawable stateListDrawable2 = (StateListDrawable) obtainStyledAttributes2.getDrawable(3);
                Drawable drawable2 = obtainStyledAttributes2.getDrawable(4);
                if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                    throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + h());
                }
                Resources resources = getContext().getResources();
                new C0057h(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(com.grid.of.lights.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(com.grid.of.lights.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(com.grid.of.lights.R.dimen.fastscroll_margin));
            }
            obtainStyledAttributes2.recycle();
            if (string != null) {
                String trim = string.trim();
                if (!trim.isEmpty()) {
                    if (trim.charAt(0) == '.') {
                        trim = context.getPackageName() + trim;
                    } else if (!trim.contains(".")) {
                        trim = RecyclerView.class.getPackage().getName() + '.' + trim;
                    }
                    String str = trim;
                    try {
                        Class<? extends U> asSubclass = (isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).loadClass(str).asSubclass(x.class);
                        try {
                            constructor = asSubclass.getConstructor(f1539n0);
                            objArr = new Object[]{context, attributeSet, 0, 0};
                        } catch (NoSuchMethodException e2) {
                            try {
                                constructor = asSubclass.getConstructor(null);
                            } catch (NoSuchMethodException e3) {
                                e3.initCause(e2);
                                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e3);
                            }
                        }
                        constructor.setAccessible(true);
                        setLayoutManager((x) constructor.newInstance(objArr));
                    } catch (ClassCastException e4) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e4);
                    } catch (ClassNotFoundException e5) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e5);
                    } catch (IllegalAccessException e6) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e6);
                    } catch (InstantiationException e7) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e7);
                    } catch (InvocationTargetException e8) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e8);
                    }
                }
            }
            TypedArray obtainStyledAttributes3 = context.obtainStyledAttributes(attributeSet, f1537l0, 0, 0);
            z2 = obtainStyledAttributes3.getBoolean(0, true);
            obtainStyledAttributes3.recycle();
        } else {
            setDescendantFocusability(262144);
        }
        setNestedScrollingEnabled(z2);
    }

    private C0283g getScrollingChildHelper() {
        if (this.f1570f0 == null) {
            this.f1570f0 = new C0283g(this);
        }
        return this.f1570f0;
    }

    public static void j(View view) {
        if (view == null) {
            return;
        }
        ((L.y) view.getLayoutParams()).getClass();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i2, int i3) {
        x xVar = this.f1580m;
        if (xVar != null) {
            xVar.getClass();
        }
        super.addFocusables(arrayList, i2, i3);
    }

    public final void b(String str) {
        if (this.f1541A > 0) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + h());
        }
        if (this.f1542B > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException("" + h()));
        }
    }

    public final void c(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.f1544D;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.f1544D.onRelease();
            z2 = this.f1544D.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f1546F;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.f1546F.onRelease();
            z2 |= this.f1546F.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f1545E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.f1545E.onRelease();
            z2 |= this.f1545E.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f1547G;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.f1547G.onRelease();
            z2 |= this.f1547G.isFinished();
        }
        if (z2) {
            Field field = w.x.f3034a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof L.y) && this.f1580m.d((L.y) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.b()) {
            return this.f1580m.f(this.f1564b0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.b()) {
            this.f1580m.g(this.f1564b0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.b()) {
            return this.f1580m.h(this.f1564b0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.c()) {
            return this.f1580m.i(this.f1564b0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.c()) {
            this.f1580m.j(this.f1564b0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        x xVar = this.f1580m;
        if (xVar != null && xVar.c()) {
            return this.f1580m.k(this.f1564b0);
        }
        return 0;
    }

    public final void d() {
        if (!this.f1585s || this.f1591y) {
            int i2 = s.b.f2799a;
            Trace.beginSection("RV FullInvalidate");
            Log.e("RecyclerView", "No adapter attached; skipping layout");
            Trace.endSection();
            return;
        }
        C0051b c0051b = this.f1571g;
        if (((ArrayList) c0051b.f583f).size() > 0) {
            c0051b.getClass();
            if (((ArrayList) c0051b.f583f).size() > 0) {
                int i3 = s.b.f2799a;
                Trace.beginSection("RV FullInvalidate");
                Log.e("RecyclerView", "No adapter attached; skipping layout");
                Trace.endSection();
            }
        }
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().b(f2, f3);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().d(i2, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        ArrayList arrayList = this.f1581n;
        int size = arrayList.size();
        boolean z3 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            C0057h c0057h = (C0057h) arrayList.get(i2);
            if (c0057h.f615l != c0057h.f617n.getWidth() || c0057h.f616m != c0057h.f617n.getHeight()) {
                c0057h.f615l = c0057h.f617n.getWidth();
                c0057h.f616m = c0057h.f617n.getHeight();
                c0057h.e(0);
            } else if (c0057h.f624v != 0) {
                if (c0057h.f618o) {
                    int i3 = c0057h.f615l;
                    int i4 = c0057h.f607d;
                    int i5 = i3 - i4;
                    int i6 = 0 - (0 / 2);
                    StateListDrawable stateListDrawable = c0057h.f605b;
                    stateListDrawable.setBounds(0, 0, i4, 0);
                    Drawable drawable = c0057h.f606c;
                    drawable.setBounds(0, 0, c0057h.f608e, c0057h.f616m);
                    RecyclerView recyclerView = c0057h.f617n;
                    Field field = w.x.f3034a;
                    if (recyclerView.getLayoutDirection() == 1) {
                        drawable.draw(canvas);
                        canvas.translate(i4, i6);
                        canvas.scale(-1.0f, 1.0f);
                        stateListDrawable.draw(canvas);
                        canvas.scale(1.0f, 1.0f);
                        canvas.translate(-i4, -i6);
                    } else {
                        canvas.translate(i5, 0.0f);
                        drawable.draw(canvas);
                        canvas.translate(0.0f, i6);
                        stateListDrawable.draw(canvas);
                        canvas.translate(-i5, -i6);
                    }
                }
                if (c0057h.f619p) {
                    int i7 = c0057h.f616m;
                    int i8 = c0057h.f611h;
                    int i9 = i7 - i8;
                    StateListDrawable stateListDrawable2 = c0057h.f609f;
                    stateListDrawable2.setBounds(0, 0, 0, i8);
                    Drawable drawable2 = c0057h.f610g;
                    drawable2.setBounds(0, 0, c0057h.f615l, c0057h.f612i);
                    canvas.translate(0.0f, i9);
                    drawable2.draw(canvas);
                    canvas.translate(0 - (0 / 2), 0.0f);
                    stateListDrawable2.draw(canvas);
                    canvas.translate(-r8, -i9);
                }
            }
            i2++;
        }
        EdgeEffect edgeEffect = this.f1544D;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f1576j ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f1544D;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.f1545E;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.f1576j) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f1545E;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.f1546F;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f1576j ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(-paddingTop, -width);
            EdgeEffect edgeEffect6 = this.f1546F;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.f1547G;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f1576j) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f1547G;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if ((z2 || this.f1548H == null || arrayList.size() <= 0 || !this.f1548H.b()) ? z2 : true) {
            Field field2 = w.x.f3034a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public final void e(int i2, int i3) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        Field field = w.x.f3034a;
        setMeasuredDimension(x.e(i2, paddingRight, getMinimumWidth()), x.e(i3, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public final boolean f(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, i4);
    }

    /* JADX WARN: Code restructure failed: missing block: B:48:0x00c2, code lost:
    
        if (r4 > 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00e0, code lost:
    
        if (r7 > 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00e3, code lost:
    
        if (r4 < 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00e6, code lost:
    
        if (r7 < 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00ee, code lost:
    
        if ((r7 * r1) < 0) goto L83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00f6, code lost:
    
        if ((r7 * r1) > 0) goto L83;
     */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View focusSearch(View view, int i2) {
        int i3;
        this.f1580m.getClass();
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i2);
        if (findNextFocus != null && !findNextFocus.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i2);
            }
            o(findNextFocus, null);
            return view;
        }
        if (findNextFocus != null && findNextFocus != this && i(findNextFocus) != null) {
            if (view != null && i(view) != null) {
                int width = view.getWidth();
                int height = view.getHeight();
                Rect rect = this.f1578k;
                char c2 = 0;
                rect.set(0, 0, width, height);
                int width2 = findNextFocus.getWidth();
                int height2 = findNextFocus.getHeight();
                Rect rect2 = this.f1579l;
                rect2.set(0, 0, width2, height2);
                offsetDescendantRectToMyCoords(view, rect);
                offsetDescendantRectToMyCoords(findNextFocus, rect2);
                RecyclerView recyclerView = this.f1580m.f660b;
                Field field = w.x.f3034a;
                int i4 = recyclerView.getLayoutDirection() == 1 ? -1 : 1;
                int i5 = rect.left;
                int i6 = rect2.left;
                if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
                    i3 = 1;
                } else {
                    int i7 = rect.right;
                    int i8 = rect2.right;
                    i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
                }
                int i9 = rect.top;
                int i10 = rect2.top;
                if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
                    c2 = 1;
                } else {
                    int i11 = rect.bottom;
                    int i12 = rect2.bottom;
                    if ((i11 > i12 || i9 >= i12) && i9 > i10) {
                        c2 = 65535;
                    }
                }
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 17) {
                            if (i2 != 33) {
                                if (i2 != 66) {
                                    if (i2 != 130) {
                                        throw new IllegalArgumentException("Invalid direction: " + i2 + h());
                                    }
                                }
                            }
                        }
                    } else if (c2 <= 0) {
                        if (c2 == 0) {
                        }
                    }
                } else if (c2 >= 0) {
                    if (c2 == 0) {
                    }
                }
            }
            return findNextFocus;
        }
        return super.focusSearch(view, i2);
    }

    public final boolean g(int[] iArr, int i2) {
        return getScrollingChildHelper().d(0, 0, 0, 0, iArr, i2, null);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        x xVar = this.f1580m;
        if (xVar != null) {
            return xVar.l();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        x xVar = this.f1580m;
        if (xVar != null) {
            return xVar.m(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    public AbstractC0067s getAdapter() {
        return null;
    }

    @Override // android.view.View
    public int getBaseline() {
        x xVar = this.f1580m;
        if (xVar == null) {
            return super.getBaseline();
        }
        xVar.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i2, int i3) {
        return super.getChildDrawingOrder(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f1576j;
    }

    public K getCompatAccessibilityDelegate() {
        return this.f1568e0;
    }

    public u getEdgeEffectFactory() {
        return this.f1543C;
    }

    public v getItemAnimator() {
        return this.f1548H;
    }

    public int getItemDecorationCount() {
        return this.f1581n.size();
    }

    public x getLayoutManager() {
        return this.f1580m;
    }

    public int getMaxFlingVelocity() {
        return this.f1558R;
    }

    public int getMinFlingVelocity() {
        return this.f1557Q;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public z getOnFlingListener() {
        return null;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f1560U;
    }

    public C getRecycledViewPool() {
        D d2 = this.f1567e;
        if (d2.f534e == null) {
            C c2 = new C();
            c2.f528a = new SparseArray();
            c2.f529b = 0;
            d2.f534e = c2;
        }
        return d2.f534e;
    }

    public int getScrollState() {
        return this.f1549I;
    }

    public final String h() {
        return " " + super.toString() + ", adapter:null, layout:" + this.f1580m + ", context:" + getContext();
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0016, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View i(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        return null;
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f1584q;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f3024d;
    }

    public final boolean k() {
        return getScrollingChildHelper().f(1);
    }

    public final boolean l() {
        return !this.f1585s || this.f1591y || ((ArrayList) this.f1571g.f583f).size() > 0;
    }

    public final void m() {
        int y2 = this.f1573h.y();
        for (int i2 = 0; i2 < y2; i2++) {
            ((L.y) this.f1573h.x(i2).getLayoutParams()).f667b = true;
        }
        ArrayList arrayList = this.f1567e.f531b;
        if (arrayList.size() <= 0) {
            return;
        }
        arrayList.get(0).getClass();
        throw new ClassCastException();
    }

    public final void n(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1550J) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f1550J = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.f1554N = x2;
            this.f1552L = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.f1555O = y2;
            this.f1553M = y2;
        }
    }

    public final void o(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f1578k;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof L.y) {
            L.y yVar = (L.y) layoutParams;
            if (!yVar.f667b) {
                Rect rect2 = yVar.f666a;
                rect.left -= rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f1580m.G(this, view, this.f1578k, !this.f1585s, view2 == null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0053, code lost:
    
        if (r1 >= 30.0f) goto L19;
     */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onAttachedToWindow() {
        float f2;
        super.onAttachedToWindow();
        boolean z2 = false;
        this.f1541A = 0;
        this.f1584q = true;
        if (this.f1585s && !isLayoutRequested()) {
            z2 = true;
        }
        this.f1585s = z2;
        x xVar = this.f1580m;
        if (xVar != null) {
            xVar.f663e = true;
        }
        ThreadLocal threadLocal = RunnableC0061l.f634i;
        RunnableC0061l runnableC0061l = (RunnableC0061l) threadLocal.get();
        this.f1562W = runnableC0061l;
        if (runnableC0061l == null) {
            RunnableC0061l runnableC0061l2 = new RunnableC0061l();
            runnableC0061l2.f636e = new ArrayList();
            runnableC0061l2.f639h = new ArrayList();
            this.f1562W = runnableC0061l2;
            Field field = w.x.f3034a;
            Display display = getDisplay();
            if (!isInEditMode() && display != null) {
                f2 = display.getRefreshRate();
            }
            f2 = 60.0f;
            RunnableC0061l runnableC0061l3 = this.f1562W;
            runnableC0061l3.f638g = (long) (1.0E9f / f2);
            threadLocal.set(runnableC0061l3);
        }
        this.f1562W.f636e.add(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        Object obj;
        super.onDetachedFromWindow();
        v vVar = this.f1548H;
        if (vVar != null) {
            vVar.a();
        }
        setScrollState(0);
        I i2 = this.f1561V;
        i2.f548k.removeCallbacks(i2);
        i2.f544g.abortAnimation();
        this.f1584q = false;
        x xVar = this.f1580m;
        if (xVar != null) {
            xVar.f663e = false;
            xVar.z(this);
        }
        this.f1577j0.clear();
        removeCallbacks(this.k0);
        this.f1575i.getClass();
        do {
            H h2 = S.f580a;
            Object[] objArr = h2.f1643b;
            int i3 = h2.f1642a;
            obj = null;
            if (i3 > 0) {
                int i4 = i3 - 1;
                Object obj2 = objArr[i4];
                i.c(obj2, "null cannot be cast to non-null type T of androidx.core.util.Pools.SimplePool");
                objArr[i4] = null;
                h2.f1642a--;
                obj = obj2;
            }
        } while (obj != null);
        RunnableC0061l runnableC0061l = this.f1562W;
        if (runnableC0061l != null) {
            runnableC0061l.f636e.remove(this);
            this.f1562W = null;
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f1581n;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((C0057h) arrayList.get(i2)).getClass();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x006a  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f2;
        float f3;
        if (this.f1580m != null && !this.f1587u && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.f1580m.c() ? -motionEvent.getAxisValue(9) : 0.0f;
                if (this.f1580m.b()) {
                    f3 = motionEvent.getAxisValue(10);
                    if (f2 == 0.0f || f3 != 0.0f) {
                        q((int) (f3 * this.f1559S), (int) (f2 * this.T), motionEvent);
                    }
                }
                f3 = 0.0f;
                if (f2 == 0.0f) {
                }
                q((int) (f3 * this.f1559S), (int) (f2 * this.T), motionEvent);
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.f1580m.c()) {
                        f2 = -axisValue;
                        f3 = 0.0f;
                        if (f2 == 0.0f) {
                        }
                        q((int) (f3 * this.f1559S), (int) (f2 * this.T), motionEvent);
                    } else if (this.f1580m.b()) {
                        f3 = axisValue;
                        f2 = 0.0f;
                        if (f2 == 0.0f) {
                        }
                        q((int) (f3 * this.f1559S), (int) (f2 * this.T), motionEvent);
                    }
                }
                f2 = 0.0f;
                f3 = 0.0f;
                if (f2 == 0.0f) {
                }
                q((int) (f3 * this.f1559S), (int) (f2 * this.T), motionEvent);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (!this.f1587u) {
            int action = motionEvent.getAction();
            if (action == 3 || action == 0) {
                this.f1583p = null;
            }
            ArrayList arrayList = this.f1582o;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0057h c0057h = (C0057h) arrayList.get(i2);
                if (c0057h.c(motionEvent) && action != 3) {
                    this.f1583p = c0057h;
                    p();
                    setScrollState(0);
                    return true;
                }
            }
            x xVar = this.f1580m;
            if (xVar != null) {
                boolean b2 = xVar.b();
                boolean c2 = this.f1580m.c();
                if (this.f1551K == null) {
                    this.f1551K = VelocityTracker.obtain();
                }
                this.f1551K.addMovement(motionEvent);
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                if (actionMasked == 0) {
                    if (this.f1588v) {
                        this.f1588v = false;
                    }
                    this.f1550J = motionEvent.getPointerId(0);
                    int x2 = (int) (motionEvent.getX() + 0.5f);
                    this.f1554N = x2;
                    this.f1552L = x2;
                    int y2 = (int) (motionEvent.getY() + 0.5f);
                    this.f1555O = y2;
                    this.f1553M = y2;
                    if (this.f1549I == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        setScrollState(1);
                    }
                    int[] iArr = this.i0;
                    iArr[1] = 0;
                    iArr[0] = 0;
                    int i3 = b2;
                    if (c2) {
                        i3 = (b2 ? 1 : 0) | 2;
                    }
                    getScrollingChildHelper().g(i3, 0);
                } else if (actionMasked == 1) {
                    this.f1551K.clear();
                    s(0);
                } else if (actionMasked == 2) {
                    int findPointerIndex = motionEvent.findPointerIndex(this.f1550J);
                    if (findPointerIndex < 0) {
                        Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f1550J + " not found. Did any MotionEvents get skipped?");
                        return false;
                    }
                    int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                    int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                    if (this.f1549I != 1) {
                        int i4 = x3 - this.f1552L;
                        int i5 = y3 - this.f1553M;
                        if (b2 == 0 || Math.abs(i4) <= this.f1556P) {
                            z2 = false;
                        } else {
                            this.f1554N = x3;
                            z2 = true;
                        }
                        if (c2 && Math.abs(i5) > this.f1556P) {
                            this.f1555O = y3;
                            z2 = true;
                        }
                        if (z2) {
                            setScrollState(1);
                        }
                    }
                } else if (actionMasked == 3) {
                    p();
                    setScrollState(0);
                } else if (actionMasked == 5) {
                    this.f1550J = motionEvent.getPointerId(actionIndex);
                    int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.f1554N = x4;
                    this.f1552L = x4;
                    int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.f1555O = y4;
                    this.f1553M = y4;
                } else if (actionMasked == 6) {
                    n(motionEvent);
                }
                if (this.f1549I == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6 = s.b.f2799a;
        Trace.beginSection("RV OnLayout");
        Log.e("RecyclerView", "No adapter attached; skipping layout");
        Trace.endSection();
        this.f1585s = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        x xVar = this.f1580m;
        if (xVar == null) {
            e(i2, i3);
            return;
        }
        if (xVar.y()) {
            View.MeasureSpec.getMode(i2);
            View.MeasureSpec.getMode(i3);
            this.f1580m.f660b.e(i2, i3);
        } else {
            if (this.r) {
                this.f1580m.f660b.e(i2, i3);
                return;
            }
            G g2 = this.f1564b0;
            if (g2.f541e) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            g2.getClass();
            this.f1586t++;
            this.f1580m.f660b.e(i2, i3);
            if (this.f1586t < 1) {
                this.f1586t = 1;
            }
            this.f1586t--;
            g2.f539c = false;
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (this.f1541A > 0) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof F)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        F f2 = (F) parcelable;
        this.f1569f = f2;
        super.onRestoreInstanceState(f2.f55e);
        x xVar = this.f1580m;
        if (xVar == null || (parcelable2 = this.f1569f.f536g) == null) {
            return;
        }
        xVar.B(parcelable2);
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        F f2 = new F(super.onSaveInstanceState());
        F f3 = this.f1569f;
        if (f3 != null) {
            f2.f536g = f3.f536g;
            return f2;
        }
        x xVar = this.f1580m;
        if (xVar != null) {
            f2.f536g = xVar.C();
            return f2;
        }
        f2.f536g = null;
        return f2;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        this.f1547G = null;
        this.f1545E = null;
        this.f1546F = null;
        this.f1544D = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0231  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x0241  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (!this.f1587u && !this.f1588v) {
            int action = motionEvent.getAction();
            C0057h c0057h = this.f1583p;
            if (c0057h != null) {
                if (action != 0) {
                    int i2 = c0057h.f604a;
                    if (c0057h.f620q != 0) {
                        if (motionEvent.getAction() == 0) {
                            boolean b2 = c0057h.b(motionEvent.getX(), motionEvent.getY());
                            boolean a2 = c0057h.a(motionEvent.getX(), motionEvent.getY());
                            if (b2 || a2) {
                                if (a2) {
                                    c0057h.r = 1;
                                    c0057h.f614k = (int) motionEvent.getX();
                                } else if (b2) {
                                    c0057h.r = 2;
                                    c0057h.f613j = (int) motionEvent.getY();
                                }
                                c0057h.e(2);
                            }
                        } else if (motionEvent.getAction() == 1 && c0057h.f620q == 2) {
                            c0057h.f613j = 0.0f;
                            c0057h.f614k = 0.0f;
                            c0057h.e(1);
                            c0057h.r = 0;
                        } else if (motionEvent.getAction() == 2 && c0057h.f620q == 2) {
                            c0057h.f();
                            if (c0057h.r == 1) {
                                float x2 = motionEvent.getX();
                                int[] iArr = c0057h.f622t;
                                iArr[0] = i2;
                                int i3 = c0057h.f615l - i2;
                                iArr[1] = i3;
                                float max = Math.max(i2, Math.min(i3, x2));
                                if (Math.abs(0 - max) >= 2.0f) {
                                    float f2 = c0057h.f614k;
                                    int computeHorizontalScrollRange = c0057h.f617n.computeHorizontalScrollRange();
                                    c0057h.f617n.computeHorizontalScrollOffset();
                                    int d2 = C0057h.d(f2, max, iArr, computeHorizontalScrollRange, 0, c0057h.f615l);
                                    if (d2 != 0) {
                                        c0057h.f617n.scrollBy(d2, 0);
                                    }
                                    c0057h.f614k = max;
                                }
                            }
                            if (c0057h.r == 2) {
                                float y2 = motionEvent.getY();
                                int[] iArr2 = c0057h.f621s;
                                iArr2[0] = i2;
                                int i4 = c0057h.f616m - i2;
                                iArr2[1] = i4;
                                float max2 = Math.max(i2, Math.min(i4, y2));
                                if (Math.abs(0 - max2) >= 2.0f) {
                                    float f3 = c0057h.f613j;
                                    int computeVerticalScrollRange = c0057h.f617n.computeVerticalScrollRange();
                                    c0057h.f617n.computeVerticalScrollOffset();
                                    int d3 = C0057h.d(f3, max2, iArr2, computeVerticalScrollRange, 0, c0057h.f616m);
                                    if (d3 != 0) {
                                        c0057h.f617n.scrollBy(0, d3);
                                    }
                                    c0057h.f613j = max2;
                                }
                            }
                        }
                    }
                    if (action == 3 || action == 1) {
                        this.f1583p = null;
                    }
                    p();
                    setScrollState(0);
                    return true;
                }
                this.f1583p = null;
            }
            if (action != 0) {
                ArrayList arrayList = this.f1582o;
                int size = arrayList.size();
                for (int i5 = 0; i5 < size; i5++) {
                    C0057h c0057h2 = (C0057h) arrayList.get(i5);
                    if (c0057h2.c(motionEvent)) {
                        this.f1583p = c0057h2;
                        p();
                        setScrollState(0);
                        return true;
                    }
                }
            }
            x xVar = this.f1580m;
            if (xVar != null) {
                boolean b3 = xVar.b();
                boolean c2 = this.f1580m.c();
                if (this.f1551K == null) {
                    this.f1551K = VelocityTracker.obtain();
                }
                MotionEvent obtain = MotionEvent.obtain(motionEvent);
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                int[] iArr3 = this.i0;
                if (actionMasked == 0) {
                    iArr3[1] = 0;
                    iArr3[0] = 0;
                }
                obtain.offsetLocation(iArr3[0], iArr3[1]);
                if (actionMasked == 0) {
                    this.f1550J = motionEvent.getPointerId(0);
                    int x3 = (int) (motionEvent.getX() + 0.5f);
                    this.f1554N = x3;
                    this.f1552L = x3;
                    int y3 = (int) (motionEvent.getY() + 0.5f);
                    this.f1555O = y3;
                    this.f1553M = y3;
                    int i6 = b3;
                    if (c2) {
                        i6 = (b3 ? 1 : 0) | 2;
                    }
                    getScrollingChildHelper().g(i6, 0);
                } else {
                    if (actionMasked == 1) {
                        this.f1551K.addMovement(obtain);
                        VelocityTracker velocityTracker = this.f1551K;
                        int i7 = this.f1558R;
                        velocityTracker.computeCurrentVelocity(1000, i7);
                        float f4 = b3 != 0 ? -this.f1551K.getXVelocity(this.f1550J) : 0.0f;
                        float f5 = c2 ? -this.f1551K.getYVelocity(this.f1550J) : 0.0f;
                        if (f4 != 0.0f || f5 != 0.0f) {
                            int i8 = (int) f4;
                            int i9 = (int) f5;
                            x xVar2 = this.f1580m;
                            if (xVar2 == null) {
                                Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                            } else if (!this.f1587u) {
                                boolean b4 = xVar2.b();
                                boolean c3 = this.f1580m.c();
                                int i10 = this.f1557Q;
                                if (b4 == 0 || Math.abs(i8) < i10) {
                                    i8 = 0;
                                }
                                if (!c3 || Math.abs(i9) < i10) {
                                    i9 = 0;
                                }
                                if (i8 != 0 || i9 != 0) {
                                    float f6 = i8;
                                    float f7 = i9;
                                    if (!dispatchNestedPreFling(f6, f7)) {
                                        boolean z3 = b4 != 0 || c3;
                                        dispatchNestedFling(f6, f7, z3);
                                        int i11 = b4;
                                        if (z3) {
                                            if (c3) {
                                                i11 = (b4 ? 1 : 0) | 2;
                                            }
                                            getScrollingChildHelper().g(i11, 1);
                                            int i12 = -i7;
                                            int max3 = Math.max(i12, Math.min(i8, i7));
                                            int max4 = Math.max(i12, Math.min(i9, i7));
                                            I i13 = this.f1561V;
                                            i13.f548k.setScrollState(2);
                                            i13.f543f = 0;
                                            i13.f542e = 0;
                                            i13.f544g.fling(0, 0, max3, max4, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                            i13.a();
                                            p();
                                            obtain.recycle();
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                        setScrollState(0);
                        p();
                        obtain.recycle();
                        return true;
                    }
                    if (actionMasked == 2) {
                        int findPointerIndex = motionEvent.findPointerIndex(this.f1550J);
                        if (findPointerIndex < 0) {
                            Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f1550J + " not found. Did any MotionEvents get skipped?");
                            return false;
                        }
                        int x4 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                        int y4 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                        int i14 = this.f1554N - x4;
                        int i15 = this.f1555O - y4;
                        boolean f8 = f(i14, i15, this.f1574h0, this.f1572g0, 0);
                        int[] iArr4 = this.f1572g0;
                        if (f8) {
                            int[] iArr5 = this.f1574h0;
                            i14 -= iArr5[0];
                            i15 -= iArr5[1];
                            obtain.offsetLocation(iArr4[0], iArr4[1]);
                            iArr3[0] = iArr3[0] + iArr4[0];
                            iArr3[1] = iArr3[1] + iArr4[1];
                        }
                        if (this.f1549I != 1) {
                            if (b3 != 0) {
                                int abs = Math.abs(i14);
                                int i16 = this.f1556P;
                                if (abs > i16) {
                                    i14 = i14 > 0 ? i14 - i16 : i14 + i16;
                                    z2 = true;
                                    if (c2) {
                                        int abs2 = Math.abs(i15);
                                        int i17 = this.f1556P;
                                        if (abs2 > i17) {
                                            i15 = i15 > 0 ? i15 - i17 : i15 + i17;
                                            z2 = true;
                                        }
                                    }
                                    if (z2) {
                                        setScrollState(1);
                                    }
                                }
                            }
                            z2 = false;
                            if (c2) {
                            }
                            if (z2) {
                            }
                        }
                        if (this.f1549I == 1) {
                            this.f1554N = x4 - iArr4[0];
                            this.f1555O = y4 - iArr4[1];
                            q(b3 != 0 ? i14 : 0, c2 ? i15 : 0, obtain);
                            RunnableC0061l runnableC0061l = this.f1562W;
                            if (runnableC0061l != null && (i14 != 0 || i15 != 0)) {
                                runnableC0061l.a(this, i14, i15);
                            }
                        }
                    } else if (actionMasked == 3) {
                        p();
                        setScrollState(0);
                    } else if (actionMasked == 5) {
                        this.f1550J = motionEvent.getPointerId(actionIndex);
                        int x5 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                        this.f1554N = x5;
                        this.f1552L = x5;
                        int y5 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                        this.f1555O = y5;
                        this.f1553M = y5;
                    } else if (actionMasked == 6) {
                        n(motionEvent);
                    }
                }
                this.f1551K.addMovement(obtain);
                obtain.recycle();
                return true;
            }
        }
        return false;
    }

    public final void p() {
        VelocityTracker velocityTracker = this.f1551K;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z2 = false;
        s(0);
        EdgeEffect edgeEffect = this.f1544D;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.f1544D.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f1545E;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.f1545E.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f1546F;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.f1546F.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f1547G;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.f1547G.isFinished();
        }
        if (z2) {
            Field field = w.x.f3034a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0171  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void q(int i2, int i3, MotionEvent motionEvent) {
        d();
        if (!this.f1581n.isEmpty()) {
            invalidate();
        }
        int[] iArr = this.f1572g0;
        boolean z2 = false;
        boolean z3 = true;
        if (g(iArr, 0)) {
            int i4 = this.f1554N;
            int i5 = iArr[0];
            this.f1554N = i4 - i5;
            int i6 = this.f1555O;
            int i7 = iArr[1];
            this.f1555O = i6 - i7;
            if (motionEvent != null) {
                motionEvent.offsetLocation(i5, i7);
            }
            int[] iArr2 = this.i0;
            iArr2[0] = iArr2[0] + iArr[0];
            iArr2[1] = iArr2[1] + iArr[1];
        } else if (getOverScrollMode() != 2) {
            if (motionEvent != null && (motionEvent.getSource() & 8194) != 8194) {
                float x2 = motionEvent.getX();
                float f2 = 0;
                float y2 = motionEvent.getY();
                if (f2 < 0.0f) {
                    if (this.f1544D == null) {
                        this.f1543C.getClass();
                        EdgeEffect edgeEffect = new EdgeEffect(getContext());
                        this.f1544D = edgeEffect;
                        if (this.f1576j) {
                            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
                        } else {
                            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
                        }
                    }
                    d.a(this.f1544D, (-f2) / getWidth(), 1.0f - (y2 / getHeight()));
                } else {
                    if (f2 > 0.0f) {
                        if (this.f1546F == null) {
                            this.f1543C.getClass();
                            EdgeEffect edgeEffect2 = new EdgeEffect(getContext());
                            this.f1546F = edgeEffect2;
                            if (this.f1576j) {
                                edgeEffect2.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
                            } else {
                                edgeEffect2.setSize(getMeasuredHeight(), getMeasuredWidth());
                            }
                        }
                        d.a(this.f1546F, f2 / getWidth(), y2 / getHeight());
                    }
                    if (f2 >= 0.0f) {
                        if (this.f1545E == null) {
                            this.f1543C.getClass();
                            EdgeEffect edgeEffect3 = new EdgeEffect(getContext());
                            this.f1545E = edgeEffect3;
                            if (this.f1576j) {
                                edgeEffect3.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
                            } else {
                                edgeEffect3.setSize(getMeasuredWidth(), getMeasuredHeight());
                            }
                        }
                        d.a(this.f1545E, (-f2) / getHeight(), x2 / getWidth());
                    } else if (f2 > 0.0f) {
                        if (this.f1547G == null) {
                            this.f1543C.getClass();
                            EdgeEffect edgeEffect4 = new EdgeEffect(getContext());
                            this.f1547G = edgeEffect4;
                            if (this.f1576j) {
                                edgeEffect4.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
                            } else {
                                edgeEffect4.setSize(getMeasuredWidth(), getMeasuredHeight());
                            }
                        }
                        d.a(this.f1547G, f2 / getHeight(), 1.0f - (x2 / getWidth()));
                    } else {
                        z3 = z2;
                    }
                    if (!z3 || f2 != 0.0f || f2 != 0.0f) {
                        Field field = w.x.f3034a;
                        postInvalidateOnAnimation();
                    }
                }
                z2 = true;
                if (f2 >= 0.0f) {
                }
                if (!z3) {
                }
                Field field2 = w.x.f3034a;
                postInvalidateOnAnimation();
            }
            c(i2, i3);
        }
        if (awakenScrollBars()) {
            return;
        }
        invalidate();
    }

    public final void r(int i2, int i3) {
        int i4;
        x xVar = this.f1580m;
        if (xVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f1587u) {
            return;
        }
        int i5 = !xVar.b() ? 0 : i2;
        int i6 = !this.f1580m.c() ? 0 : i3;
        if (i5 == 0 && i6 == 0) {
            return;
        }
        I i7 = this.f1561V;
        RecyclerView recyclerView = i7.f548k;
        int abs = Math.abs(i5);
        int abs2 = Math.abs(i6);
        boolean z2 = abs > abs2;
        int sqrt = (int) Math.sqrt(0);
        int sqrt2 = (int) Math.sqrt((i6 * i6) + (i5 * i5));
        int width = z2 ? recyclerView.getWidth() : recyclerView.getHeight();
        int i8 = width / 2;
        float f2 = width;
        float f3 = i8;
        float sin = (((float) Math.sin((Math.min(1.0f, (sqrt2 * 1.0f) / f2) - 0.5f) * 0.47123894f)) * f3) + f3;
        if (sqrt > 0) {
            i4 = Math.round(Math.abs(sin / sqrt) * 1000.0f) * 4;
        } else {
            if (!z2) {
                abs = abs2;
            }
            i4 = (int) (((abs / f2) + 1.0f) * 300.0f);
        }
        int min = Math.min(i4, 2000);
        Interpolator interpolator = i7.f545h;
        r rVar = f1540o0;
        if (interpolator != rVar) {
            i7.f545h = rVar;
            i7.f544g = new OverScroller(recyclerView.getContext(), rVar);
        }
        recyclerView.setScrollState(2);
        i7.f543f = 0;
        i7.f542e = 0;
        i7.f544g.startScroll(0, 0, i5, i6, min);
        i7.a();
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z2) {
        j(view);
        view.clearAnimation();
        j(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        this.f1580m.getClass();
        if (this.f1541A <= 0 && view2 != null) {
            o(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f1580m.G(this, view, rect, z2, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        ArrayList arrayList = this.f1582o;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((C0057h) arrayList.get(i2)).getClass();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f1586t != 0 || this.f1587u) {
            return;
        }
        super.requestLayout();
    }

    public final void s(int i2) {
        getScrollingChildHelper().h(i2);
    }

    @Override // android.view.View
    public final void scrollBy(int i2, int i3) {
        x xVar = this.f1580m;
        if (xVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f1587u) {
            return;
        }
        boolean b2 = xVar.b();
        boolean c2 = this.f1580m.c();
        if (b2 || c2) {
            if (!b2) {
                i2 = 0;
            }
            if (!c2) {
                i3 = 0;
            }
            q(i2, i3, null);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (this.f1541A <= 0) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.f1589w |= contentChangeTypes != 0 ? contentChangeTypes : 0;
        }
    }

    public void setAccessibilityDelegateCompat(K k2) {
        this.f1568e0 = k2;
        w.x.a(this, k2);
    }

    public void setAdapter(AbstractC0067s abstractC0067s) {
        setLayoutFrozen(false);
        v vVar = this.f1548H;
        if (vVar != null) {
            vVar.a();
        }
        x xVar = this.f1580m;
        D d2 = this.f1567e;
        if (xVar != null) {
            xVar.E();
            this.f1580m.F(d2);
        }
        d2.f530a.clear();
        ArrayList arrayList = d2.f531b;
        int size = arrayList.size() - 1;
        if (size >= 0) {
            arrayList.get(size).getClass();
            throw new ClassCastException();
        }
        arrayList.clear();
        C0059j c0059j = d2.f535f.f1563a0;
        c0059j.getClass();
        c0059j.f628c = 0;
        C0051b c0051b = this.f1571g;
        c0051b.G((ArrayList) c0051b.f583f);
        c0051b.G((ArrayList) c0051b.f585h);
        ArrayList arrayList2 = d2.f530a;
        RecyclerView recyclerView = d2.f535f;
        ArrayList arrayList3 = d2.f531b;
        arrayList2.clear();
        int size2 = arrayList3.size() - 1;
        if (size2 >= 0) {
            arrayList3.get(size2).getClass();
            throw new ClassCastException();
        }
        arrayList3.clear();
        C0059j c0059j2 = recyclerView.f1563a0;
        c0059j2.getClass();
        c0059j2.f628c = 0;
        if (d2.f534e == null) {
            C c2 = new C();
            c2.f528a = new SparseArray();
            c2.f529b = 0;
            d2.f534e = c2;
        }
        C c3 = d2.f534e;
        if (c3.f529b == 0) {
            SparseArray sparseArray = c3.f528a;
            if (sparseArray.size() > 0) {
                ((B) sparseArray.valueAt(0)).getClass();
                throw null;
            }
        }
        this.f1564b0.f538b = true;
        this.f1592z = this.f1592z;
        this.f1591y = true;
        int y2 = this.f1573h.y();
        for (int i2 = 0; i2 < y2; i2++) {
            j(this.f1573h.x(i2));
        }
        m();
        int size3 = arrayList3.size();
        for (int i3 = 0; i3 < size3; i3++) {
            if (arrayList3.get(i3) != null) {
                throw new ClassCastException();
            }
        }
        int size4 = arrayList3.size() - 1;
        if (size4 >= 0) {
            arrayList3.get(size4).getClass();
            throw new ClassCastException();
        }
        arrayList3.clear();
        C0059j c0059j3 = recyclerView.f1563a0;
        c0059j3.getClass();
        c0059j3.f628c = 0;
        requestLayout();
    }

    public void setChildDrawingOrderCallback(t tVar) {
        if (tVar == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.f1576j) {
            this.f1547G = null;
            this.f1545E = null;
            this.f1546F = null;
            this.f1544D = null;
        }
        this.f1576j = z2;
        super.setClipToPadding(z2);
        if (this.f1585s) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(u uVar) {
        uVar.getClass();
        this.f1543C = uVar;
        this.f1547G = null;
        this.f1545E = null;
        this.f1546F = null;
        this.f1544D = null;
    }

    public void setHasFixedSize(boolean z2) {
        this.r = z2;
    }

    public void setItemAnimator(v vVar) {
        v vVar2 = this.f1548H;
        if (vVar2 != null) {
            vVar2.a();
            this.f1548H.f653a = null;
        }
        this.f1548H = vVar;
        if (vVar != null) {
            vVar.f653a = this.f1566d0;
        }
    }

    public void setItemViewCacheSize(int i2) {
        D d2 = this.f1567e;
        d2.f532c = i2;
        d2.b();
    }

    public void setLayoutFrozen(boolean z2) {
        if (z2 != this.f1587u) {
            b("Do not setLayoutFrozen in layout or scroll");
            if (!z2) {
                this.f1587u = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f1587u = true;
            this.f1588v = true;
            setScrollState(0);
            I i2 = this.f1561V;
            i2.f548k.removeCallbacks(i2);
            i2.f544g.abortAnimation();
        }
    }

    public void setLayoutManager(x xVar) {
        if (xVar == this.f1580m) {
            return;
        }
        setScrollState(0);
        I i2 = this.f1561V;
        i2.f548k.removeCallbacks(i2);
        i2.f544g.abortAnimation();
        x xVar2 = this.f1580m;
        D d2 = this.f1567e;
        if (xVar2 != null) {
            v vVar = this.f1548H;
            if (vVar != null) {
                vVar.a();
            }
            this.f1580m.E();
            this.f1580m.F(d2);
            d2.f530a.clear();
            ArrayList arrayList = d2.f531b;
            int size = arrayList.size() - 1;
            if (size >= 0) {
                arrayList.get(size).getClass();
                throw new ClassCastException();
            }
            arrayList.clear();
            C0059j c0059j = d2.f535f.f1563a0;
            c0059j.getClass();
            c0059j.f628c = 0;
            if (this.f1584q) {
                x xVar3 = this.f1580m;
                xVar3.f663e = false;
                xVar3.z(this);
            }
            this.f1580m.I(null);
            this.f1580m = null;
        } else {
            d2.f530a.clear();
            ArrayList arrayList2 = d2.f531b;
            int size2 = arrayList2.size() - 1;
            if (size2 >= 0) {
                arrayList2.get(size2).getClass();
                throw new ClassCastException();
            }
            arrayList2.clear();
            C0059j c0059j2 = d2.f535f.f1563a0;
            c0059j2.getClass();
            c0059j2.f628c = 0;
        }
        C0051b c0051b = this.f1573h;
        j jVar = (j) c0051b.f584g;
        ((C0052c) c0051b.f585h).c();
        ArrayList arrayList3 = (ArrayList) c0051b.f583f;
        for (int size3 = arrayList3.size() - 1; size3 >= 0; size3--) {
            j((View) arrayList3.get(size3));
            arrayList3.remove(size3);
        }
        RecyclerView recyclerView = (RecyclerView) jVar.f30f;
        int childCount = recyclerView.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = recyclerView.getChildAt(i3);
            j(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f1580m = xVar;
        if (xVar != null) {
            if (xVar.f660b != null) {
                throw new IllegalArgumentException("LayoutManager " + xVar + " is already attached to a RecyclerView:" + xVar.f660b.h());
            }
            xVar.I(this);
            if (this.f1584q) {
                this.f1580m.f663e = true;
            }
        }
        d2.b();
        requestLayout();
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        C0283g scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f3024d) {
            ViewGroup viewGroup = scrollingChildHelper.f3023c;
            Field field = w.x.f3034a;
            AbstractC0292p.z(viewGroup);
        }
        scrollingChildHelper.f3024d = z2;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f1560U = z2;
    }

    public void setRecycledViewPool(C c2) {
        D d2 = this.f1567e;
        if (d2.f534e != null) {
            r1.f529b--;
        }
        d2.f534e = c2;
        if (c2 != null) {
            d2.f535f.getAdapter();
        }
    }

    public void setScrollState(int i2) {
        if (i2 == this.f1549I) {
            return;
        }
        this.f1549I = i2;
        if (i2 != 2) {
            I i3 = this.f1561V;
            i3.f548k.removeCallbacks(i3);
            i3.f544g.abortAnimation();
        }
        x xVar = this.f1580m;
        if (xVar != null) {
            xVar.D(i2);
        }
        ArrayList arrayList = this.f1565c0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((A) this.f1565c0.get(size)).getClass();
            }
        }
    }

    public void setScrollingTouchSlop(int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                this.f1556P = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
        }
        this.f1556P = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(L.H h2) {
        this.f1567e.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().g(i2, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        x xVar = this.f1580m;
        if (xVar != null) {
            return xVar.n(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    public void setOnFlingListener(z zVar) {
    }

    @Deprecated
    public void setOnScrollListener(A a2) {
    }

    public void setRecyclerListener(E e2) {
    }
}
