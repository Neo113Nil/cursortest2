package androidx.core.graphics.drawable;

import F.j;
import P.a;
import P.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i2 = iconCompat.f1278a;
        if (aVar.e(1)) {
            i2 = ((b) aVar).f879e.readInt();
        }
        iconCompat.f1278a = i2;
        byte[] bArr = iconCompat.f1280c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f879e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f1280c = bArr;
        iconCompat.f1281d = aVar.f(iconCompat.f1281d, 3);
        int i3 = iconCompat.f1282e;
        if (aVar.e(4)) {
            i3 = ((b) aVar).f879e.readInt();
        }
        iconCompat.f1282e = i3;
        int i4 = iconCompat.f1283f;
        if (aVar.e(5)) {
            i4 = ((b) aVar).f879e.readInt();
        }
        iconCompat.f1283f = i4;
        iconCompat.f1284g = (ColorStateList) aVar.f(iconCompat.f1284g, 6);
        String str = iconCompat.f1286i;
        if (aVar.e(7)) {
            str = ((b) aVar).f879e.readString();
        }
        iconCompat.f1286i = str;
        String str2 = iconCompat.f1287j;
        if (aVar.e(8)) {
            str2 = ((b) aVar).f879e.readString();
        }
        iconCompat.f1287j = str2;
        iconCompat.f1285h = PorterDuff.Mode.valueOf(iconCompat.f1286i);
        switch (iconCompat.f1278a) {
            case -1:
                Parcelable parcelable = iconCompat.f1281d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f1279b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case j.STRING_FIELD_NUMBER /* 5 */:
                Parcelable parcelable2 = iconCompat.f1281d;
                if (parcelable2 != null) {
                    iconCompat.f1279b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f1280c;
                iconCompat.f1279b = bArr3;
                iconCompat.f1278a = 3;
                iconCompat.f1282e = 0;
                iconCompat.f1283f = bArr3.length;
                return iconCompat;
            case j.FLOAT_FIELD_NUMBER /* 2 */:
            case j.LONG_FIELD_NUMBER /* 4 */:
            case j.STRING_SET_FIELD_NUMBER /* 6 */:
                String str3 = new String(iconCompat.f1280c, Charset.forName("UTF-16"));
                iconCompat.f1279b = str3;
                if (iconCompat.f1278a == 2 && iconCompat.f1287j == null) {
                    iconCompat.f1287j = str3.split(":", -1)[0];
                }
                return iconCompat;
            case j.INTEGER_FIELD_NUMBER /* 3 */:
                iconCompat.f1279b = iconCompat.f1280c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f1286i = iconCompat.f1285h.name();
        switch (iconCompat.f1278a) {
            case -1:
                iconCompat.f1281d = (Parcelable) iconCompat.f1279b;
                break;
            case 1:
            case j.STRING_FIELD_NUMBER /* 5 */:
                iconCompat.f1281d = (Parcelable) iconCompat.f1279b;
                break;
            case j.FLOAT_FIELD_NUMBER /* 2 */:
                iconCompat.f1280c = ((String) iconCompat.f1279b).getBytes(Charset.forName("UTF-16"));
                break;
            case j.INTEGER_FIELD_NUMBER /* 3 */:
                iconCompat.f1280c = (byte[]) iconCompat.f1279b;
                break;
            case j.LONG_FIELD_NUMBER /* 4 */:
            case j.STRING_SET_FIELD_NUMBER /* 6 */:
                iconCompat.f1280c = iconCompat.f1279b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f1278a;
        if (-1 != i2) {
            aVar.h(1);
            ((b) aVar).f879e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f1280c;
        if (bArr != null) {
            aVar.h(2);
            Parcel parcel = ((b) aVar).f879e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1281d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f879e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f1282e;
        if (i3 != 0) {
            aVar.h(4);
            ((b) aVar).f879e.writeInt(i3);
        }
        int i4 = iconCompat.f1283f;
        if (i4 != 0) {
            aVar.h(5);
            ((b) aVar).f879e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f1284g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f879e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f1286i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f879e.writeString(str);
        }
        String str2 = iconCompat.f1287j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f879e.writeString(str2);
        }
    }
}
