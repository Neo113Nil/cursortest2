package androidx.core.app;

import P.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f1271a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f1272b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f1273c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f1274d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1275e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1276f;
}
