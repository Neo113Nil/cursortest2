package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import com.grid.of.lights.R;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public class PreferenceCategory extends PreferenceGroup {
    public PreferenceCategory(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, AbstractC0230j.o(context, R.attr.preferenceCategoryStyle, android.R.attr.preferenceCategoryStyle), 0);
    }
}
