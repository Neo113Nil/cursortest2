package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import com.grid.of.lights.R;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {
    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, AbstractC0230j.o(context, R.attr.preferenceScreenStyle, android.R.attr.preferenceScreenStyle), 0);
    }
}
