package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* loaded from: classes.dex */
public final class m extends androidx.lifecycle.a {
    final /* synthetic */ n this$0;

    public static final class a extends androidx.lifecycle.a {
        final /* synthetic */ n this$0;

        public a(n nVar) {
            this.this$0 = nVar;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            E0.i.e(activity, "activity");
            this.this$0.b();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            E0.i.e(activity, "activity");
            n nVar = this.this$0;
            int i2 = nVar.f1503e + 1;
            nVar.f1503e = i2;
            if (i2 == 1 && nVar.f1506h) {
                nVar.f1508j.a(d.ON_START);
                nVar.f1506h = false;
            }
        }
    }

    public m(n nVar) {
        this.this$0 = nVar;
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        E0.i.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i2 = r.f1511f;
            Fragment findFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            E0.i.c(findFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((r) findFragmentByTag).f1512e = this.this$0.f1510l;
        }
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        E0.i.e(activity, "activity");
        n nVar = this.this$0;
        int i2 = nVar.f1504f - 1;
        nVar.f1504f = i2;
        if (i2 == 0) {
            Handler handler = nVar.f1507i;
            E0.i.b(handler);
            handler.postDelayed(nVar.f1509k, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        E0.i.e(activity, "activity");
        l.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        E0.i.e(activity, "activity");
        n nVar = this.this$0;
        int i2 = nVar.f1503e - 1;
        nVar.f1503e = i2;
        if (i2 == 0 && nVar.f1505g) {
            nVar.f1508j.a(d.ON_STOP);
            nVar.f1506h = true;
        }
    }
}
