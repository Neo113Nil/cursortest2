package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* loaded from: classes.dex */
public class r extends Fragment {

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ int f1511f = 0;

    /* renamed from: e, reason: collision with root package name */
    public A.j f1512e;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final q Companion = new q();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            E0.i.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            E0.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            E0.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            E0.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            E0.i.e(activity, "activity");
            int i2 = r.f1511f;
            o.a(activity, d.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            E0.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            E0.i.e(activity, "activity");
            E0.i.e(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            E0.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            E0.i.e(activity, "activity");
        }
    }

    public final void a(d dVar) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            E0.i.d(activity, "activity");
            o.a(activity, dVar);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(d.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(d.ON_DESTROY);
        this.f1512e = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(d.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        A.j jVar = this.f1512e;
        if (jVar != null) {
            ((n) jVar.f30f).b();
        }
        a(d.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        A.j jVar = this.f1512e;
        if (jVar != null) {
            n nVar = (n) jVar.f30f;
            int i2 = nVar.f1503e + 1;
            nVar.f1503e = i2;
            if (i2 == 1 && nVar.f1506h) {
                nVar.f1508j.a(d.ON_START);
                nVar.f1506h = false;
            }
        }
        a(d.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(d.ON_STOP);
    }
}
