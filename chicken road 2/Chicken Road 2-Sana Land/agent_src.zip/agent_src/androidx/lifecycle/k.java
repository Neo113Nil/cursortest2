package androidx.lifecycle;

import e0.C0134h;
import h.C0177s;
import h0.CallableC0187c;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final /* synthetic */ class k implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1500e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1501f;

    public /* synthetic */ k(int i2, Object obj) {
        this.f1500e = i2;
        this.f1501f = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean isEmpty;
        switch (this.f1500e) {
            case 0:
                n nVar = (n) this.f1501f;
                j jVar = nVar.f1508j;
                if (nVar.f1504f == 0) {
                    nVar.f1505g = true;
                    jVar.a(d.ON_PAUSE);
                }
                if (nVar.f1503e == 0 && nVar.f1505g) {
                    jVar.a(d.ON_STOP);
                    nVar.f1506h = true;
                    return;
                }
                return;
            case 1:
                C0134h c0134h = (C0134h) this.f1501f;
                ExecutorService executorService = c0134h.f1833a;
                ConcurrentLinkedQueue concurrentLinkedQueue = c0134h.f1834b;
                AtomicBoolean atomicBoolean = c0134h.f1835c;
                if (atomicBoolean.compareAndSet(false, true)) {
                    try {
                        Runnable runnable = (Runnable) concurrentLinkedQueue.poll();
                        if (runnable != null) {
                            runnable.run();
                        }
                        if (isEmpty) {
                            return;
                        } else {
                            return;
                        }
                    } finally {
                        atomicBoolean.set(false);
                        if (!concurrentLinkedQueue.isEmpty()) {
                            executorService.execute(new k(1, c0134h));
                        }
                    }
                }
                return;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                ((CallableC0187c) this.f1501f).f2299b.f2306e.prefetchDefaultFontManager();
                return;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                ((io.flutter.plugin.platform.k) this.f1501f).e(false);
                return;
            default:
                ((C0177s) this.f1501f).getClass();
                return;
        }
    }
}
