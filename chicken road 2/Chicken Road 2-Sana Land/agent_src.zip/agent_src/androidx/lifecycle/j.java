package androidx.lifecycle;

import android.os.Looper;
import i.C0190a;
import j.C0191a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class j extends f {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f1494a;

    /* renamed from: b, reason: collision with root package name */
    public C0191a f1495b;

    /* renamed from: c, reason: collision with root package name */
    public e f1496c;

    /* renamed from: d, reason: collision with root package name */
    public final WeakReference f1497d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1498e;

    /* renamed from: f, reason: collision with root package name */
    public final M0.q f1499f;

    public j(i iVar) {
        new AtomicReference();
        this.f1494a = true;
        this.f1495b = new C0191a();
        e eVar = e.f1488f;
        this.f1496c = eVar;
        new ArrayList();
        this.f1497d = new WeakReference(iVar);
        this.f1499f = new M0.q(eVar);
    }

    public final void a(d dVar) {
        e eVar;
        C0190a c0190a;
        e eVar2 = e.f1487e;
        E0.i.e(dVar, "event");
        if (this.f1494a) {
            if (C0190a.f2309j != null) {
                c0190a = C0190a.f2309j;
            } else {
                synchronized (C0190a.class) {
                    try {
                        if (C0190a.f2309j == null) {
                            C0190a.f2309j = new C0190a(0);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                c0190a = C0190a.f2309j;
            }
            ((C0190a) c0190a.f2310i).getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException("Method handleLifecycleEvent must be called on the main thread");
            }
        }
        switch (c.f1486a[dVar.ordinal()]) {
            case 1:
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                eVar = e.f1489g;
                break;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                eVar = e.f1490h;
                break;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                eVar = e.f1491i;
                break;
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                eVar = eVar2;
                break;
            default:
                throw new IllegalArgumentException(dVar + " has no target state");
        }
        WeakReference weakReference = this.f1497d;
        e eVar3 = this.f1496c;
        if (eVar3 == eVar) {
            return;
        }
        if (eVar3 == e.f1488f && eVar == eVar2) {
            throw new IllegalStateException(("no event down from " + this.f1496c + " in component " + weakReference.get()).toString());
        }
        this.f1496c = eVar;
        if (this.f1498e) {
            return;
        }
        this.f1498e = true;
        if (((i) weakReference.get()) == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        this.f1495b.getClass();
        M0.q qVar = this.f1499f;
        Object obj = this.f1496c;
        qVar.getClass();
        if (obj == null) {
            obj = N0.k.f812a;
        }
        qVar.a(null, obj);
        this.f1498e = false;
        if (this.f1496c == eVar2) {
            this.f1495b = new C0191a();
        }
    }
}
