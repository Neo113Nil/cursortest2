package androidx.lifecycle;

import android.os.Handler;

/* loaded from: classes.dex */
public final class n implements i {

    /* renamed from: m, reason: collision with root package name */
    public static final n f1502m = new n();

    /* renamed from: e, reason: collision with root package name */
    public int f1503e;

    /* renamed from: f, reason: collision with root package name */
    public int f1504f;

    /* renamed from: i, reason: collision with root package name */
    public Handler f1507i;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1505g = true;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1506h = true;

    /* renamed from: j, reason: collision with root package name */
    public final j f1508j = new j(this);

    /* renamed from: k, reason: collision with root package name */
    public final k f1509k = new k(0, this);

    /* renamed from: l, reason: collision with root package name */
    public final A.j f1510l = new A.j(13, this);

    @Override // androidx.lifecycle.i
    public final j a() {
        return this.f1508j;
    }

    public final void b() {
        int i2 = this.f1504f + 1;
        this.f1504f = i2;
        if (i2 == 1) {
            if (this.f1505g) {
                this.f1508j.a(d.ON_RESUME);
                this.f1505g = false;
            } else {
                Handler handler = this.f1507i;
                E0.i.b(handler);
                handler.removeCallbacks(this.f1509k);
            }
        }
    }
}
