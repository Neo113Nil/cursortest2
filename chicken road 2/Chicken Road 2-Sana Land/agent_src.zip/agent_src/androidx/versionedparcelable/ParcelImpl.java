package androidx.versionedparcelable;

import A.l;
import P.b;
import P.c;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new l(4);

    /* renamed from: e, reason: collision with root package name */
    public final c f1604e;

    public ParcelImpl(Parcel parcel) {
        this.f1604e = new b(parcel).g();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        new b(parcel).i(this.f1604e);
    }
}
