package androidx.appcompat.view.menu;

import a.AbstractC0068a;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import c.AbstractC0096a;
import g.AbstractC0144b;
import g.ViewOnTouchListenerC0143a;
import g.i;
import g.j;
import g.k;
import g.q;
import h.C0179u;
import h.InterfaceC0169j;

/* loaded from: classes.dex */
public class ActionMenuItemView extends C0179u implements q, View.OnClickListener, InterfaceC0169j {

    /* renamed from: i, reason: collision with root package name */
    public k f1056i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1057j;

    /* renamed from: k, reason: collision with root package name */
    public Drawable f1058k;

    /* renamed from: l, reason: collision with root package name */
    public i f1059l;

    /* renamed from: m, reason: collision with root package name */
    public ViewOnTouchListenerC0143a f1060m;

    /* renamed from: n, reason: collision with root package name */
    public AbstractC0144b f1061n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1062o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f1063p;

    /* renamed from: q, reason: collision with root package name */
    public final int f1064q;
    public int r;

    /* renamed from: s, reason: collision with root package name */
    public final int f1065s;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f1062o = d();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0096a.f1614c, 0, 0);
        this.f1064q = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f1065s = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.r = -1;
        setSaveEnabled(false);
    }

    @Override // g.q
    public final void a(k kVar) {
        this.f1056i = kVar;
        setIcon(kVar.getIcon());
        setTitle(kVar.getTitleCondensed());
        setId(kVar.f1959a);
        setVisibility(kVar.isVisible() ? 0 : 8);
        setEnabled(kVar.isEnabled());
        if (kVar.hasSubMenu() && this.f1060m == null) {
            this.f1060m = new ViewOnTouchListenerC0143a(this);
        }
    }

    @Override // h.InterfaceC0169j
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // h.InterfaceC0169j
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f1056i.getIcon() == null;
    }

    public final boolean d() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (i2 < 480) {
            return (i2 >= 640 && i3 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void e() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f1057j);
        if (this.f1058k != null && ((this.f1056i.f1982y & 4) != 4 || (!this.f1062o && !this.f1063p))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        setText(z4 ? this.f1057j : null);
        CharSequence charSequence = this.f1056i.f1975q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z4 ? null : this.f1056i.f1963e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f1056i.r;
        if (TextUtils.isEmpty(charSequence2)) {
            AbstractC0068a.H(this, z4 ? null : this.f1056i.f1963e);
        } else {
            AbstractC0068a.H(this, charSequence2);
        }
    }

    @Override // g.q
    public k getItemData() {
        return this.f1056i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i iVar = this.f1059l;
        if (iVar != null) {
            iVar.a(this.f1056i);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1062o = d();
        e();
    }

    @Override // h.C0179u, android.widget.TextView, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        boolean isEmpty = TextUtils.isEmpty(getText());
        if (!isEmpty && (i4 = this.r) >= 0) {
            super.setPadding(i4, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        int i5 = this.f1064q;
        int min = mode == Integer.MIN_VALUE ? Math.min(size, i5) : i5;
        if (mode != 1073741824 && i5 > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i3);
        }
        if (!isEmpty || this.f1058k == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1058k.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewOnTouchListenerC0143a viewOnTouchListenerC0143a;
        if (this.f1056i.hasSubMenu() && (viewOnTouchListenerC0143a = this.f1060m) != null && viewOnTouchListenerC0143a.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f1063p != z2) {
            this.f1063p = z2;
            k kVar = this.f1056i;
            if (kVar != null) {
                j jVar = kVar.f1972n;
                jVar.f1948k = true;
                jVar.o(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1058k = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.f1065s;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (intrinsicHeight * (i2 / intrinsicWidth));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (intrinsicWidth * (i2 / intrinsicHeight));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, null, null, null);
        e();
    }

    public void setItemInvoker(i iVar) {
        this.f1059l = iVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i2, int i3, int i4, int i5) {
        this.r = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(AbstractC0144b abstractC0144b) {
        this.f1061n = abstractC0144b;
    }

    public void setTitle(CharSequence charSequence) {
        this.f1057j = charSequence;
        e();
    }
}
