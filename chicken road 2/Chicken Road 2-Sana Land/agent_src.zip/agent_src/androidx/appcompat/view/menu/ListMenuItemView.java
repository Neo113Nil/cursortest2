package androidx.appcompat.view.menu;

import L.C0051b;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import c.AbstractC0096a;
import com.grid.of.lights.R;
import g.j;
import g.k;
import g.q;
import java.lang.reflect.Field;
import w.x;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements q, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: e, reason: collision with root package name */
    public k f1067e;

    /* renamed from: f, reason: collision with root package name */
    public ImageView f1068f;

    /* renamed from: g, reason: collision with root package name */
    public RadioButton f1069g;

    /* renamed from: h, reason: collision with root package name */
    public TextView f1070h;

    /* renamed from: i, reason: collision with root package name */
    public CheckBox f1071i;

    /* renamed from: j, reason: collision with root package name */
    public TextView f1072j;

    /* renamed from: k, reason: collision with root package name */
    public ImageView f1073k;

    /* renamed from: l, reason: collision with root package name */
    public ImageView f1074l;

    /* renamed from: m, reason: collision with root package name */
    public LinearLayout f1075m;

    /* renamed from: n, reason: collision with root package name */
    public final Drawable f1076n;

    /* renamed from: o, reason: collision with root package name */
    public final int f1077o;

    /* renamed from: p, reason: collision with root package name */
    public final Context f1078p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f1079q;
    public final Drawable r;

    /* renamed from: s, reason: collision with root package name */
    public final boolean f1080s;

    /* renamed from: t, reason: collision with root package name */
    public LayoutInflater f1081t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1082u;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0051b C2 = C0051b.C(getContext(), attributeSet, AbstractC0096a.f1625n, R.attr.listMenuViewStyle);
        this.f1076n = C2.v(5);
        TypedArray typedArray = (TypedArray) C2.f583f;
        this.f1077o = typedArray.getResourceId(1, -1);
        this.f1079q = typedArray.getBoolean(7, false);
        this.f1078p = context;
        this.r = C2.v(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f1080s = obtainStyledAttributes.hasValue(0);
        C2.F();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f1081t == null) {
            this.f1081t = LayoutInflater.from(getContext());
        }
        return this.f1081t;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f1073k;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x005b, code lost:
    
        if (r0 == false) goto L28;
     */
    /* JADX WARN: Removed duplicated region for block: B:13:0x003f  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0121  */
    @Override // g.q
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(k kVar) {
        boolean z2;
        String sb;
        boolean z3;
        this.f1067e = kVar;
        int i2 = 0;
        setVisibility(kVar.isVisible() ? 0 : 8);
        setTitle(kVar.f1963e);
        setCheckable(kVar.isCheckable());
        if (kVar.f1972n.n()) {
            if ((kVar.f1972n.m() ? kVar.f1968j : kVar.f1966h) != 0) {
                z2 = true;
                kVar.f1972n.m();
                if (z2) {
                    k kVar2 = this.f1067e;
                    if (kVar2.f1972n.n()) {
                        if ((kVar2.f1972n.m() ? kVar2.f1968j : kVar2.f1966h) != 0) {
                            z3 = true;
                        }
                    }
                    z3 = false;
                }
                i2 = 8;
                if (i2 == 0) {
                    TextView textView = this.f1072j;
                    k kVar3 = this.f1067e;
                    j jVar = kVar3.f1972n;
                    Context context = jVar.f1938a;
                    char c2 = jVar.m() ? kVar3.f1968j : kVar3.f1966h;
                    if (c2 == 0) {
                        sb = "";
                    } else {
                        Resources resources = context.getResources();
                        StringBuilder sb2 = new StringBuilder();
                        if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                            sb2.append(resources.getString(R.string.abc_prepend_shortcut_label));
                        }
                        int i3 = jVar.m() ? kVar3.f1969k : kVar3.f1967i;
                        k.a(sb2, i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                        k.a(sb2, i3, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                        k.a(sb2, i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                        k.a(sb2, i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                        k.a(sb2, i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                        k.a(sb2, i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                        if (c2 == '\b') {
                            sb2.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                        } else if (c2 == '\n') {
                            sb2.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                        } else if (c2 != ' ') {
                            sb2.append(c2);
                        } else {
                            sb2.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                        }
                        sb = sb2.toString();
                    }
                    textView.setText(sb);
                }
                if (this.f1072j.getVisibility() != i2) {
                    this.f1072j.setVisibility(i2);
                }
                setIcon(kVar.getIcon());
                setEnabled(kVar.isEnabled());
                setSubMenuArrowVisible(kVar.hasSubMenu());
                setContentDescription(kVar.f1975q);
            }
        }
        z2 = false;
        kVar.f1972n.m();
        if (z2) {
        }
        i2 = 8;
        if (i2 == 0) {
        }
        if (this.f1072j.getVisibility() != i2) {
        }
        setIcon(kVar.getIcon());
        setEnabled(kVar.isEnabled());
        setSubMenuArrowVisible(kVar.hasSubMenu());
        setContentDescription(kVar.f1975q);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f1074l;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1074l.getLayoutParams();
        rect.top = this.f1074l.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // g.q
    public k getItemData() {
        return this.f1067e;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        Field field = x.f3034a;
        setBackground(this.f1076n);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f1070h = textView;
        int i2 = this.f1077o;
        if (i2 != -1) {
            textView.setTextAppearance(this.f1078p, i2);
        }
        this.f1072j = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f1073k = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.r);
        }
        this.f1074l = (ImageView) findViewById(R.id.group_divider);
        this.f1075m = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (this.f1068f != null && this.f1079q) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1068f.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        View view;
        if (!z2 && this.f1069g == null && this.f1071i == null) {
            return;
        }
        if ((this.f1067e.f1981x & 4) != 0) {
            if (this.f1069g == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1069g = radioButton;
                LinearLayout linearLayout = this.f1075m;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1069g;
            view = this.f1071i;
        } else {
            if (this.f1071i == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1071i = checkBox;
                LinearLayout linearLayout2 = this.f1075m;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1071i;
            view = this.f1069g;
        }
        if (z2) {
            compoundButton.setChecked(this.f1067e.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f1071i;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f1069g;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if ((this.f1067e.f1981x & 4) != 0) {
            if (this.f1069g == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1069g = radioButton;
                LinearLayout linearLayout = this.f1075m;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1069g;
        } else {
            if (this.f1071i == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1071i = checkBox;
                LinearLayout linearLayout2 = this.f1075m;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1071i;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f1082u = z2;
        this.f1079q = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f1074l;
        if (imageView != null) {
            imageView.setVisibility((this.f1080s || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        j jVar = this.f1067e.f1972n;
        boolean z2 = this.f1082u;
        if (z2 || this.f1079q) {
            ImageView imageView = this.f1068f;
            if (imageView == null && drawable == null && !this.f1079q) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f1068f = imageView2;
                LinearLayout linearLayout = this.f1075m;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f1079q) {
                this.f1068f.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f1068f;
            if (!z2) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f1068f.getVisibility() != 0) {
                this.f1068f.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f1070h.getVisibility() != 8) {
                this.f1070h.setVisibility(8);
            }
        } else {
            this.f1070h.setText(charSequence);
            if (this.f1070h.getVisibility() != 0) {
                this.f1070h.setVisibility(0);
            }
        }
    }
}
