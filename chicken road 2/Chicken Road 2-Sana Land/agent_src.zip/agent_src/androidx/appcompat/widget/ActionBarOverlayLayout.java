package androidx.appcompat.widget;

import L.C0063n;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import com.grid.of.lights.R;
import d.AbstractC0112a;
import h.C0161b;
import h.C0164e;
import h.InterfaceC0163d;
import h.InterfaceC0182x;
import h.RunnableC0162c;
import h.q0;
import h.w0;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import w.AbstractC0290n;
import w.InterfaceC0284h;
import w.InterfaceC0285i;
import w.x;

/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC0284h, InterfaceC0285i {

    /* renamed from: C, reason: collision with root package name */
    public static final int[] f1104C = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* renamed from: A, reason: collision with root package name */
    public final RunnableC0162c f1105A;

    /* renamed from: B, reason: collision with root package name */
    public final C0063n f1106B;

    /* renamed from: e, reason: collision with root package name */
    public int f1107e;

    /* renamed from: f, reason: collision with root package name */
    public ContentFrameLayout f1108f;

    /* renamed from: g, reason: collision with root package name */
    public ActionBarContainer f1109g;

    /* renamed from: h, reason: collision with root package name */
    public InterfaceC0182x f1110h;

    /* renamed from: i, reason: collision with root package name */
    public Drawable f1111i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1112j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1113k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f1114l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1115m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f1116n;

    /* renamed from: o, reason: collision with root package name */
    public int f1117o;

    /* renamed from: p, reason: collision with root package name */
    public final Rect f1118p;

    /* renamed from: q, reason: collision with root package name */
    public final Rect f1119q;
    public final Rect r;

    /* renamed from: s, reason: collision with root package name */
    public final Rect f1120s;

    /* renamed from: t, reason: collision with root package name */
    public final Rect f1121t;

    /* renamed from: u, reason: collision with root package name */
    public final Rect f1122u;

    /* renamed from: v, reason: collision with root package name */
    public final Rect f1123v;

    /* renamed from: w, reason: collision with root package name */
    public OverScroller f1124w;

    /* renamed from: x, reason: collision with root package name */
    public ViewPropertyAnimator f1125x;

    /* renamed from: y, reason: collision with root package name */
    public final C0161b f1126y;

    /* renamed from: z, reason: collision with root package name */
    public final RunnableC0162c f1127z;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1118p = new Rect();
        this.f1119q = new Rect();
        this.r = new Rect();
        this.f1120s = new Rect();
        this.f1121t = new Rect();
        this.f1122u = new Rect();
        this.f1123v = new Rect();
        this.f1126y = new C0161b(this);
        this.f1127z = new RunnableC0162c(this, 0);
        this.f1105A = new RunnableC0162c(this, 1);
        i(context);
        this.f1106B = new C0063n();
    }

    public static boolean g(View view, Rect rect, boolean z2) {
        boolean z3;
        C0164e c0164e = (C0164e) view.getLayoutParams();
        int i2 = ((ViewGroup.MarginLayoutParams) c0164e).leftMargin;
        int i3 = rect.left;
        if (i2 != i3) {
            ((ViewGroup.MarginLayoutParams) c0164e).leftMargin = i3;
            z3 = true;
        } else {
            z3 = false;
        }
        int i4 = ((ViewGroup.MarginLayoutParams) c0164e).topMargin;
        int i5 = rect.top;
        if (i4 != i5) {
            ((ViewGroup.MarginLayoutParams) c0164e).topMargin = i5;
            z3 = true;
        }
        int i6 = ((ViewGroup.MarginLayoutParams) c0164e).rightMargin;
        int i7 = rect.right;
        if (i6 != i7) {
            ((ViewGroup.MarginLayoutParams) c0164e).rightMargin = i7;
            z3 = true;
        }
        if (z2) {
            int i8 = ((ViewGroup.MarginLayoutParams) c0164e).bottomMargin;
            int i9 = rect.bottom;
            if (i8 != i9) {
                ((ViewGroup.MarginLayoutParams) c0164e).bottomMargin = i9;
                return true;
            }
        }
        return z3;
    }

    @Override // w.InterfaceC0284h
    public final void a(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // w.InterfaceC0284h
    public final void b(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(viewGroup, i2, i3, i4, i5);
        }
    }

    @Override // w.InterfaceC0284h
    public final void c(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0164e;
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.f1111i == null || this.f1112j) {
            return;
        }
        if (this.f1109g.getVisibility() == 0) {
            i2 = (int) (this.f1109g.getTranslationY() + this.f1109g.getBottom() + 0.5f);
        } else {
            i2 = 0;
        }
        this.f1111i.setBounds(0, i2, getWidth(), this.f1111i.getIntrinsicHeight() + i2);
        this.f1111i.draw(canvas);
    }

    @Override // w.InterfaceC0285i
    public final void e(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        b(viewGroup, i2, i3, i4, i5, i6);
    }

    @Override // w.InterfaceC0284h
    public final boolean f(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        j();
        Field field = x.f3034a;
        getWindowSystemUiVisibility();
        boolean g2 = g(this.f1109g, rect, false);
        Rect rect2 = this.f1120s;
        rect2.set(rect);
        Method method = w0.f2284a;
        Rect rect3 = this.f1118p;
        if (method != null) {
            try {
                method.invoke(this, rect2, rect3);
            } catch (Exception e2) {
                Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e2);
            }
        }
        Rect rect4 = this.f1121t;
        if (!rect4.equals(rect2)) {
            rect4.set(rect2);
            g2 = true;
        }
        Rect rect5 = this.f1119q;
        if (!rect5.equals(rect3)) {
            rect5.set(rect3);
            g2 = true;
        }
        if (g2) {
            requestLayout();
        }
        return true;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0164e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0164e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1109g;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0063n c0063n = this.f1106B;
        return c0063n.f642c | c0063n.f641b;
    }

    public CharSequence getTitle() {
        j();
        return ((q0) this.f1110h).f2218a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f1127z);
        removeCallbacks(this.f1105A);
        ViewPropertyAnimator viewPropertyAnimator = this.f1125x;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f1104C);
        this.f1107e = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f1111i = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        this.f1112j = context.getApplicationInfo().targetSdkVersion < 19;
        this.f1124w = new OverScroller(context);
    }

    public final void j() {
        InterfaceC0182x wrapper;
        if (this.f1108f == null) {
            this.f1108f = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f1109g = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof InterfaceC0182x) {
                wrapper = (InterfaceC0182x) findViewById;
            } else {
                if (!(findViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(findViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) findViewById).getWrapper();
            }
            this.f1110h = wrapper;
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        Field field = x.f3034a;
        AbstractC0290n.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                C0164e c0164e = (C0164e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) c0164e).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) c0164e).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        j();
        measureChildWithMargins(this.f1109g, i2, 0, i3, 0);
        C0164e c0164e = (C0164e) this.f1109g.getLayoutParams();
        int i4 = 0;
        int max = Math.max(0, this.f1109g.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0164e).leftMargin + ((ViewGroup.MarginLayoutParams) c0164e).rightMargin);
        int max2 = Math.max(0, this.f1109g.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0164e).topMargin + ((ViewGroup.MarginLayoutParams) c0164e).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f1109g.getMeasuredState());
        Field field = x.f3034a;
        boolean z2 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z2) {
            i4 = this.f1107e;
            if (this.f1114l && this.f1109g.getTabContainer() != null) {
                i4 += this.f1107e;
            }
        } else if (this.f1109g.getVisibility() != 8) {
            i4 = this.f1109g.getMeasuredHeight();
        }
        Rect rect = this.f1118p;
        Rect rect2 = this.r;
        rect2.set(rect);
        Rect rect3 = this.f1120s;
        Rect rect4 = this.f1122u;
        rect4.set(rect3);
        if (this.f1113k || z2) {
            rect4.top += i4;
            rect4.bottom = rect4.bottom;
        } else {
            rect2.top += i4;
            rect2.bottom = rect2.bottom;
        }
        g(this.f1108f, rect2, true);
        Rect rect5 = this.f1123v;
        if (!rect5.equals(rect4)) {
            rect5.set(rect4);
            this.f1108f.a(rect4);
        }
        measureChildWithMargins(this.f1108f, i2, 0, i3, 0);
        C0164e c0164e2 = (C0164e) this.f1108f.getLayoutParams();
        int max3 = Math.max(max, this.f1108f.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0164e2).leftMargin + ((ViewGroup.MarginLayoutParams) c0164e2).rightMargin);
        int max4 = Math.max(max2, this.f1108f.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0164e2).topMargin + ((ViewGroup.MarginLayoutParams) c0164e2).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f1108f.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.f1115m || !z2) {
            return false;
        }
        this.f1124w.fling(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f1124w.getFinalY() > this.f1109g.getHeight()) {
            h();
            this.f1105A.run();
        } else {
            h();
            this.f1127z.run();
        }
        this.f1116n = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f1117o + i3;
        this.f1117o = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1106B.f641b = i2;
        this.f1117o = getActionBarHideOffset();
        h();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f1109g.getVisibility() != 0) {
            return false;
        }
        return this.f1115m;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f1115m || this.f1116n) {
            return;
        }
        if (this.f1117o <= this.f1109g.getHeight()) {
            h();
            postDelayed(this.f1127z, 600L);
        } else {
            h();
            postDelayed(this.f1105A, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        j();
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
    }

    public void setActionBarHideOffset(int i2) {
        h();
        this.f1109g.setTranslationY(-Math.max(0, Math.min(i2, this.f1109g.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC0163d interfaceC0163d) {
        if (getWindowToken() != null) {
            throw null;
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f1114l = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f1115m) {
            this.f1115m = z2;
            if (z2) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        j();
        q0 q0Var = (q0) this.f1110h;
        q0Var.f2221d = i2 != 0 ? AbstractC0112a.a(q0Var.f2218a.getContext(), i2) : null;
        q0Var.c();
    }

    public void setLogo(int i2) {
        j();
        q0 q0Var = (q0) this.f1110h;
        q0Var.f2222e = i2 != 0 ? AbstractC0112a.a(q0Var.f2218a.getContext(), i2) : null;
        q0Var.c();
    }

    public void setOverlayMode(boolean z2) {
        this.f1113k = z2;
        this.f1112j = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    public void setWindowCallback(Window.Callback callback) {
        j();
        ((q0) this.f1110h).f2228k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        j();
        q0 q0Var = (q0) this.f1110h;
        if (q0Var.f2224g) {
            return;
        }
        q0Var.f2225h = charSequence;
        if ((q0Var.f2219b & 8) != 0) {
            q0Var.f2218a.setTitle(charSequence);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0164e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        j();
        q0 q0Var = (q0) this.f1110h;
        q0Var.f2221d = drawable;
        q0Var.c();
    }

    @Override // w.InterfaceC0284h
    public final void d(int i2, int i3, int[] iArr, int i4) {
    }
}
