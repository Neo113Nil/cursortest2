package androidx.appcompat.widget;

import A.j;
import L.C0051b;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import c.AbstractC0096a;
import com.grid.of.lights.R;
import d.AbstractC0112a;
import f.C0141d;
import g.k;
import h.C0165f;
import h.C0168i;
import h.C0175p;
import h.C0176q;
import h.C0179u;
import h.InterfaceC0182x;
import h.P;
import h.l0;
import h.m0;
import h.n0;
import h.o0;
import h.p0;
import h.q0;
import h.w0;
import java.lang.reflect.Field;
import java.util.ArrayList;
import w.x;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* renamed from: A, reason: collision with root package name */
    public final int f1228A;

    /* renamed from: B, reason: collision with root package name */
    public CharSequence f1229B;

    /* renamed from: C, reason: collision with root package name */
    public CharSequence f1230C;

    /* renamed from: D, reason: collision with root package name */
    public ColorStateList f1231D;

    /* renamed from: E, reason: collision with root package name */
    public ColorStateList f1232E;

    /* renamed from: F, reason: collision with root package name */
    public boolean f1233F;

    /* renamed from: G, reason: collision with root package name */
    public boolean f1234G;

    /* renamed from: H, reason: collision with root package name */
    public final ArrayList f1235H;

    /* renamed from: I, reason: collision with root package name */
    public final ArrayList f1236I;

    /* renamed from: J, reason: collision with root package name */
    public final int[] f1237J;

    /* renamed from: K, reason: collision with root package name */
    public final j f1238K;

    /* renamed from: L, reason: collision with root package name */
    public q0 f1239L;

    /* renamed from: M, reason: collision with root package name */
    public m0 f1240M;

    /* renamed from: N, reason: collision with root package name */
    public boolean f1241N;

    /* renamed from: O, reason: collision with root package name */
    public final A.b f1242O;

    /* renamed from: e, reason: collision with root package name */
    public ActionMenuView f1243e;

    /* renamed from: f, reason: collision with root package name */
    public C0179u f1244f;

    /* renamed from: g, reason: collision with root package name */
    public C0179u f1245g;

    /* renamed from: h, reason: collision with root package name */
    public C0175p f1246h;

    /* renamed from: i, reason: collision with root package name */
    public C0176q f1247i;

    /* renamed from: j, reason: collision with root package name */
    public final Drawable f1248j;

    /* renamed from: k, reason: collision with root package name */
    public final CharSequence f1249k;

    /* renamed from: l, reason: collision with root package name */
    public C0175p f1250l;

    /* renamed from: m, reason: collision with root package name */
    public View f1251m;

    /* renamed from: n, reason: collision with root package name */
    public Context f1252n;

    /* renamed from: o, reason: collision with root package name */
    public int f1253o;

    /* renamed from: p, reason: collision with root package name */
    public int f1254p;

    /* renamed from: q, reason: collision with root package name */
    public int f1255q;
    public final int r;

    /* renamed from: s, reason: collision with root package name */
    public final int f1256s;

    /* renamed from: t, reason: collision with root package name */
    public int f1257t;

    /* renamed from: u, reason: collision with root package name */
    public int f1258u;

    /* renamed from: v, reason: collision with root package name */
    public int f1259v;

    /* renamed from: w, reason: collision with root package name */
    public int f1260w;

    /* renamed from: x, reason: collision with root package name */
    public P f1261x;

    /* renamed from: y, reason: collision with root package name */
    public int f1262y;

    /* renamed from: z, reason: collision with root package name */
    public int f1263z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f1228A = 8388627;
        this.f1235H = new ArrayList();
        this.f1236I = new ArrayList();
        this.f1237J = new int[2];
        this.f1238K = new j(22, this);
        this.f1242O = new A.b(5, this);
        C0051b C2 = C0051b.C(getContext(), attributeSet, AbstractC0096a.f1630t, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) C2.f583f;
        this.f1254p = typedArray.getResourceId(28, 0);
        this.f1255q = typedArray.getResourceId(19, 0);
        this.f1228A = typedArray.getInteger(0, 8388627);
        this.r = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f1260w = dimensionPixelOffset;
        this.f1259v = dimensionPixelOffset;
        this.f1258u = dimensionPixelOffset;
        this.f1257t = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f1257t = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f1258u = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f1259v = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f1260w = dimensionPixelOffset5;
        }
        this.f1256s = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        P p2 = this.f1261x;
        p2.f2107h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            p2.f2104e = dimensionPixelSize;
            p2.f2100a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            p2.f2105f = dimensionPixelSize2;
            p2.f2101b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            p2.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f1262y = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f1263z = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f1248j = C2.v(4);
        this.f1249k = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f1252n = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable v2 = C2.v(16);
        if (v2 != null) {
            setNavigationIcon(v2);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable v3 = C2.v(11);
        if (v3 != null) {
            setLogo(v3);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(C2.u(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(C2.u(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        C2.F();
    }

    public static n0 g() {
        n0 n0Var = new n0(-2, -2);
        n0Var.f2208b = 0;
        n0Var.f2207a = 8388627;
        return n0Var;
    }

    private MenuInflater getMenuInflater() {
        return new C0141d(getContext());
    }

    public static n0 h(ViewGroup.LayoutParams layoutParams) {
        boolean z2 = layoutParams instanceof n0;
        if (z2) {
            n0 n0Var = (n0) layoutParams;
            n0 n0Var2 = new n0(n0Var);
            n0Var2.f2208b = 0;
            n0Var2.f2208b = n0Var.f2208b;
            return n0Var2;
        }
        if (z2) {
            n0 n0Var3 = new n0((n0) layoutParams);
            n0Var3.f2208b = 0;
            return n0Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            n0 n0Var4 = new n0(layoutParams);
            n0Var4.f2208b = 0;
            return n0Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        n0 n0Var5 = new n0(marginLayoutParams);
        n0Var5.f2208b = 0;
        ((ViewGroup.MarginLayoutParams) n0Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) n0Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) n0Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) n0Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return n0Var5;
    }

    public static int j(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i2) {
        Field field = x.f3034a;
        boolean z2 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        arrayList.clear();
        if (!z2) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                n0 n0Var = (n0) childAt.getLayoutParams();
                if (n0Var.f2208b == 0 && q(childAt)) {
                    int i4 = n0Var.f2207a;
                    Field field2 = x.f3034a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i4, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i5 = childCount - 1; i5 >= 0; i5--) {
            View childAt2 = getChildAt(i5);
            n0 n0Var2 = (n0) childAt2.getLayoutParams();
            if (n0Var2.f2208b == 0 && q(childAt2)) {
                int i6 = n0Var2.f2207a;
                Field field3 = x.f3034a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i6, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        n0 g2 = layoutParams == null ? g() : !checkLayoutParams(layoutParams) ? h(layoutParams) : (n0) layoutParams;
        g2.f2208b = 1;
        if (!z2 || this.f1251m == null) {
            addView(view, g2);
        } else {
            view.setLayoutParams(g2);
            this.f1236I.add(view);
        }
    }

    public final void c() {
        if (this.f1250l == null) {
            C0175p c0175p = new C0175p(getContext());
            this.f1250l = c0175p;
            c0175p.setImageDrawable(this.f1248j);
            this.f1250l.setContentDescription(this.f1249k);
            n0 g2 = g();
            g2.f2207a = (this.r & 112) | 8388611;
            g2.f2208b = 2;
            this.f1250l.setLayoutParams(g2);
            this.f1250l.setOnClickListener(new l0(this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof n0);
    }

    public final void d() {
        if (this.f1261x == null) {
            P p2 = new P();
            p2.f2100a = 0;
            p2.f2101b = 0;
            p2.f2102c = Integer.MIN_VALUE;
            p2.f2103d = Integer.MIN_VALUE;
            p2.f2104e = 0;
            p2.f2105f = 0;
            p2.f2106g = false;
            p2.f2107h = false;
            this.f1261x = p2;
        }
    }

    public final void e() {
        if (this.f1243e == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f1243e = actionMenuView;
            actionMenuView.setPopupTheme(this.f1253o);
            this.f1243e.setOnMenuItemClickListener(this.f1238K);
            this.f1243e.getClass();
            n0 g2 = g();
            g2.f2207a = (this.r & 112) | 8388613;
            this.f1243e.setLayoutParams(g2);
            b(this.f1243e, false);
        }
        ActionMenuView actionMenuView2 = this.f1243e;
        if (actionMenuView2.f1130t == null) {
            g.j jVar = (g.j) actionMenuView2.getMenu();
            if (this.f1240M == null) {
                this.f1240M = new m0(this);
            }
            this.f1243e.setExpandedActionViewsExclusive(true);
            jVar.b(this.f1240M, this.f1252n);
        }
    }

    public final void f() {
        if (this.f1246h == null) {
            this.f1246h = new C0175p(getContext());
            n0 g2 = g();
            g2.f2207a = (this.r & 112) | 8388611;
            this.f1246h.setLayoutParams(g2);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0175p c0175p = this.f1250l;
        if (c0175p != null) {
            return c0175p.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0175p c0175p = this.f1250l;
        if (c0175p != null) {
            return c0175p.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        P p2 = this.f1261x;
        if (p2 != null) {
            return p2.f2106g ? p2.f2100a : p2.f2101b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f1263z;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        P p2 = this.f1261x;
        if (p2 != null) {
            return p2.f2100a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        P p2 = this.f1261x;
        if (p2 != null) {
            return p2.f2101b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        P p2 = this.f1261x;
        if (p2 != null) {
            return p2.f2106g ? p2.f2101b : p2.f2100a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f1262y;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        g.j jVar;
        ActionMenuView actionMenuView = this.f1243e;
        return (actionMenuView == null || (jVar = actionMenuView.f1130t) == null || !jVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f1263z, 0));
    }

    public int getCurrentContentInsetLeft() {
        Field field = x.f3034a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        Field field = x.f3034a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1262y, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        C0176q c0176q = this.f1247i;
        if (c0176q != null) {
            return c0176q.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C0176q c0176q = this.f1247i;
        if (c0176q != null) {
            return c0176q.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f1243e.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        C0175p c0175p = this.f1246h;
        if (c0175p != null) {
            return c0175p.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0175p c0175p = this.f1246h;
        if (c0175p != null) {
            return c0175p.getDrawable();
        }
        return null;
    }

    public C0168i getOuterActionMenuPresenter() {
        return null;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f1243e.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f1252n;
    }

    public int getPopupTheme() {
        return this.f1253o;
    }

    public CharSequence getSubtitle() {
        return this.f1230C;
    }

    public final TextView getSubtitleTextView() {
        return this.f1245g;
    }

    public CharSequence getTitle() {
        return this.f1229B;
    }

    public int getTitleMarginBottom() {
        return this.f1260w;
    }

    public int getTitleMarginEnd() {
        return this.f1258u;
    }

    public int getTitleMarginStart() {
        return this.f1257t;
    }

    public int getTitleMarginTop() {
        return this.f1259v;
    }

    public final TextView getTitleTextView() {
        return this.f1244f;
    }

    public InterfaceC0182x getWrapper() {
        Drawable drawable;
        if (this.f1239L == null) {
            q0 q0Var = new q0();
            q0Var.f2229l = 0;
            q0Var.f2218a = this;
            q0Var.f2225h = getTitle();
            q0Var.f2226i = getSubtitle();
            q0Var.f2224g = q0Var.f2225h != null;
            q0Var.f2223f = getNavigationIcon();
            C0051b C2 = C0051b.C(getContext(), null, AbstractC0096a.f1612a, R.attr.actionBarStyle);
            TypedArray typedArray = (TypedArray) C2.f583f;
            q0Var.f2230m = C2.v(15);
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                q0Var.f2224g = true;
                q0Var.f2225h = text;
                if ((q0Var.f2219b & 8) != 0) {
                    q0Var.f2218a.setTitle(text);
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                q0Var.f2226i = text2;
                if ((q0Var.f2219b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable v2 = C2.v(20);
            if (v2 != null) {
                q0Var.f2222e = v2;
                q0Var.c();
            }
            Drawable v3 = C2.v(17);
            if (v3 != null) {
                q0Var.f2221d = v3;
                q0Var.c();
            }
            if (q0Var.f2223f == null && (drawable = q0Var.f2230m) != null) {
                q0Var.f2223f = drawable;
                Toolbar toolbar = q0Var.f2218a;
                if ((q0Var.f2219b & 4) != 0) {
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            q0Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View inflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = q0Var.f2220c;
                if (view != null && (q0Var.f2219b & 16) != 0) {
                    removeView(view);
                }
                q0Var.f2220c = inflate;
                if (inflate != null && (q0Var.f2219b & 16) != 0) {
                    addView(inflate);
                }
                q0Var.a(q0Var.f2219b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int max = Math.max(dimensionPixelOffset, 0);
                int max2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f1261x.a(max, max2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f1254p = resourceId2;
                C0179u c0179u = this.f1244f;
                if (c0179u != null) {
                    c0179u.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f1255q = resourceId3;
                C0179u c0179u2 = this.f1245g;
                if (c0179u2 != null) {
                    c0179u2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            C2.F();
            if (R.string.abc_action_bar_up_description != q0Var.f2229l) {
                q0Var.f2229l = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i2 = q0Var.f2229l;
                    q0Var.f2227j = i2 != 0 ? getContext().getString(i2) : null;
                    q0Var.b();
                }
            }
            q0Var.f2227j = getNavigationContentDescription();
            setNavigationOnClickListener(new l0(q0Var));
            this.f1239L = q0Var;
        }
        return this.f1239L;
    }

    public final int i(View view, int i2) {
        n0 n0Var = (n0) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = n0Var.f2207a & 112;
        if (i4 != 16 && i4 != 48 && i4 != 80) {
            i4 = this.f1228A & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) n0Var).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = ((ViewGroup.MarginLayoutParams) n0Var).topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = ((ViewGroup.MarginLayoutParams) n0Var).bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final boolean l(View view) {
        return view.getParent() == this || this.f1236I.contains(view);
    }

    public final int m(View view, int i2, int i3, int[] iArr) {
        n0 n0Var = (n0) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) n0Var).leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int i5 = i(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, i5, max + measuredWidth, view.getMeasuredHeight() + i5);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) n0Var).rightMargin + max;
    }

    public final int n(View view, int i2, int i3, int[] iArr) {
        n0 n0Var = (n0) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) n0Var).rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int i5 = i(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, i5, max, view.getMeasuredHeight() + i5);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) n0Var).leftMargin);
    }

    public final int o(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f1242O);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1234G = false;
        }
        if (!this.f1234G) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1234G = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f1234G = false;
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:110:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x028f A[LOOP:0: B:39:0x028d->B:40:0x028f, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x02a7 A[LOOP:1: B:43:0x02a5->B:44:0x02a7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x02c7 A[LOOP:2: B:47:0x02c5->B:48:0x02c7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x030d  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x031a A[LOOP:3: B:56:0x0318->B:57:0x031a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x012e  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0164  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0218  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int max;
        boolean q2;
        boolean q3;
        boolean z3;
        int i8;
        int i9;
        int paddingTop;
        int i10;
        int i11;
        int i12;
        int i13;
        int size;
        int i14;
        int i15;
        int size2;
        int i16;
        int size3;
        int i17;
        int i18;
        int i19;
        int size4;
        Field field = x.f3034a;
        boolean z4 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i20 = width - paddingRight;
        int[] iArr = this.f1237J;
        iArr[1] = 0;
        iArr[0] = 0;
        int minimumHeight = getMinimumHeight();
        int min = minimumHeight >= 0 ? Math.min(minimumHeight, i5 - i3) : 0;
        if (!q(this.f1246h)) {
            i6 = paddingLeft;
        } else {
            if (z4) {
                i7 = n(this.f1246h, i20, min, iArr);
                i6 = paddingLeft;
                if (q(this.f1250l)) {
                    if (z4) {
                        i7 = n(this.f1250l, i7, min, iArr);
                    } else {
                        i6 = m(this.f1250l, i6, min, iArr);
                    }
                }
                if (q(this.f1243e)) {
                    if (z4) {
                        i6 = m(this.f1243e, i6, min, iArr);
                    } else {
                        i7 = n(this.f1243e, i7, min, iArr);
                    }
                }
                int currentContentInsetLeft = getCurrentContentInsetLeft();
                int currentContentInsetRight = getCurrentContentInsetRight();
                iArr[0] = Math.max(0, currentContentInsetLeft - i6);
                iArr[1] = Math.max(0, currentContentInsetRight - (i20 - i7));
                max = Math.max(i6, currentContentInsetLeft);
                int min2 = Math.min(i7, i20 - currentContentInsetRight);
                if (q(this.f1251m)) {
                    if (z4) {
                        min2 = n(this.f1251m, min2, min, iArr);
                    } else {
                        max = m(this.f1251m, max, min, iArr);
                    }
                }
                if (q(this.f1247i)) {
                    if (z4) {
                        min2 = n(this.f1247i, min2, min, iArr);
                    } else {
                        max = m(this.f1247i, max, min, iArr);
                    }
                }
                q2 = q(this.f1244f);
                q3 = q(this.f1245g);
                if (q2) {
                    z3 = z4;
                    i8 = 0;
                } else {
                    n0 n0Var = (n0) this.f1244f.getLayoutParams();
                    z3 = z4;
                    i8 = this.f1244f.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) n0Var).topMargin + ((ViewGroup.MarginLayoutParams) n0Var).bottomMargin;
                }
                if (!q3) {
                    n0 n0Var2 = (n0) this.f1245g.getLayoutParams();
                    i8 = this.f1245g.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) n0Var2).topMargin + ((ViewGroup.MarginLayoutParams) n0Var2).bottomMargin + i8;
                }
                if (!q2 || q3) {
                    C0179u c0179u = !q2 ? this.f1244f : this.f1245g;
                    C0179u c0179u2 = !q3 ? this.f1245g : this.f1244f;
                    n0 n0Var3 = (n0) c0179u.getLayoutParams();
                    n0 n0Var4 = (n0) c0179u2.getLayoutParams();
                    int i21 = i8;
                    boolean z5 = (!q2 && this.f1244f.getMeasuredWidth() > 0) || (q3 && this.f1245g.getMeasuredWidth() > 0);
                    i9 = this.f1228A & 112;
                    int i22 = max;
                    if (i9 != 48) {
                        paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) n0Var3).topMargin + this.f1259v;
                    } else if (i9 != 80) {
                        int i23 = (((height - paddingTop2) - paddingBottom) - i21) / 2;
                        int i24 = ((ViewGroup.MarginLayoutParams) n0Var3).topMargin + this.f1259v;
                        if (i23 < i24) {
                            i23 = i24;
                        } else {
                            int i25 = (((height - paddingBottom) - i21) - i23) - paddingTop2;
                            int i26 = ((ViewGroup.MarginLayoutParams) n0Var3).bottomMargin;
                            int i27 = this.f1260w;
                            if (i25 < i26 + i27) {
                                i23 = Math.max(0, i23 - ((((ViewGroup.MarginLayoutParams) n0Var4).bottomMargin + i27) - i25));
                            }
                        }
                        paddingTop = paddingTop2 + i23;
                    } else {
                        paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) n0Var4).bottomMargin) - this.f1260w) - i21;
                    }
                    if (z3) {
                        int i28 = (z5 ? this.f1257t : 0) - iArr[0];
                        max = Math.max(0, i28) + i22;
                        iArr[0] = Math.max(0, -i28);
                        if (q2) {
                            n0 n0Var5 = (n0) this.f1244f.getLayoutParams();
                            int measuredWidth = this.f1244f.getMeasuredWidth() + max;
                            int measuredHeight = this.f1244f.getMeasuredHeight() + paddingTop;
                            this.f1244f.layout(max, paddingTop, measuredWidth, measuredHeight);
                            i10 = measuredWidth + this.f1258u;
                            paddingTop = measuredHeight + ((ViewGroup.MarginLayoutParams) n0Var5).bottomMargin;
                        } else {
                            i10 = max;
                        }
                        if (q3) {
                            int i29 = paddingTop + ((ViewGroup.MarginLayoutParams) ((n0) this.f1245g.getLayoutParams())).topMargin;
                            int measuredWidth2 = this.f1245g.getMeasuredWidth() + max;
                            this.f1245g.layout(max, i29, measuredWidth2, this.f1245g.getMeasuredHeight() + i29);
                            i11 = measuredWidth2 + this.f1258u;
                        } else {
                            i11 = max;
                        }
                        if (z5) {
                            max = Math.max(i10, i11);
                        }
                    } else {
                        int i30 = (z5 ? this.f1257t : 0) - iArr[1];
                        min2 -= Math.max(0, i30);
                        iArr[1] = Math.max(0, -i30);
                        if (q2) {
                            n0 n0Var6 = (n0) this.f1244f.getLayoutParams();
                            int measuredWidth3 = min2 - this.f1244f.getMeasuredWidth();
                            int measuredHeight2 = this.f1244f.getMeasuredHeight() + paddingTop;
                            this.f1244f.layout(measuredWidth3, paddingTop, min2, measuredHeight2);
                            i12 = measuredWidth3 - this.f1258u;
                            paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) n0Var6).bottomMargin;
                        } else {
                            i12 = min2;
                        }
                        if (q3) {
                            int i31 = paddingTop + ((ViewGroup.MarginLayoutParams) ((n0) this.f1245g.getLayoutParams())).topMargin;
                            this.f1245g.layout(min2 - this.f1245g.getMeasuredWidth(), i31, min2, this.f1245g.getMeasuredHeight() + i31);
                            i13 = min2 - this.f1258u;
                        } else {
                            i13 = min2;
                        }
                        if (z5) {
                            min2 = Math.min(i12, i13);
                        }
                        max = i22;
                    }
                }
                ArrayList arrayList = this.f1235H;
                a(arrayList, 3);
                size = arrayList.size();
                i14 = max;
                for (i15 = 0; i15 < size; i15++) {
                    i14 = m((View) arrayList.get(i15), i14, min, iArr);
                }
                a(arrayList, 5);
                size2 = arrayList.size();
                for (i16 = 0; i16 < size2; i16++) {
                    min2 = n((View) arrayList.get(i16), min2, min, iArr);
                }
                a(arrayList, 1);
                int i32 = iArr[0];
                int i33 = iArr[1];
                size3 = arrayList.size();
                int i34 = i32;
                i17 = 0;
                int i35 = 0;
                while (i17 < size3) {
                    View view = (View) arrayList.get(i17);
                    n0 n0Var7 = (n0) view.getLayoutParams();
                    int i36 = i33;
                    int i37 = ((ViewGroup.MarginLayoutParams) n0Var7).leftMargin - i34;
                    int i38 = ((ViewGroup.MarginLayoutParams) n0Var7).rightMargin - i36;
                    int max2 = Math.max(0, i37);
                    int max3 = Math.max(0, i38);
                    int max4 = Math.max(0, -i37);
                    int max5 = Math.max(0, -i38);
                    i35 += view.getMeasuredWidth() + max2 + max3;
                    i17++;
                    i34 = max4;
                    i33 = max5;
                }
                i19 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (i35 / 2);
                int i39 = i35 + i19;
                if (i19 >= i14) {
                    i14 = i39 > min2 ? i19 - (i39 - min2) : i19;
                }
                size4 = arrayList.size();
                for (i18 = 0; i18 < size4; i18++) {
                    i14 = m((View) arrayList.get(i18), i14, min, iArr);
                }
                arrayList.clear();
            }
            i6 = m(this.f1246h, paddingLeft, min, iArr);
        }
        i7 = i20;
        if (q(this.f1250l)) {
        }
        if (q(this.f1243e)) {
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - i6);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i20 - i7));
        max = Math.max(i6, currentContentInsetLeft2);
        int min22 = Math.min(i7, i20 - currentContentInsetRight2);
        if (q(this.f1251m)) {
        }
        if (q(this.f1247i)) {
        }
        q2 = q(this.f1244f);
        q3 = q(this.f1245g);
        if (q2) {
        }
        if (!q3) {
        }
        if (!q2) {
        }
        if (!q2) {
        }
        if (!q3) {
        }
        n0 n0Var32 = (n0) c0179u.getLayoutParams();
        n0 n0Var42 = (n0) c0179u2.getLayoutParams();
        int i212 = i8;
        if (q2) {
        }
        i9 = this.f1228A & 112;
        int i222 = max;
        if (i9 != 48) {
        }
        if (z3) {
        }
        ArrayList arrayList2 = this.f1235H;
        a(arrayList2, 3);
        size = arrayList2.size();
        i14 = max;
        while (i15 < size) {
        }
        a(arrayList2, 5);
        size2 = arrayList2.size();
        while (i16 < size2) {
        }
        a(arrayList2, 1);
        int i322 = iArr[0];
        int i332 = iArr[1];
        size3 = arrayList2.size();
        int i342 = i322;
        i17 = 0;
        int i352 = 0;
        while (i17 < size3) {
        }
        i19 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (i352 / 2);
        int i392 = i352 + i19;
        if (i19 >= i14) {
        }
        size4 = arrayList2.size();
        while (i18 < size4) {
        }
        arrayList2.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        boolean a2 = w0.a(this);
        int i11 = !a2 ? 1 : 0;
        int i12 = 0;
        if (q(this.f1246h)) {
            p(this.f1246h, i2, 0, i3, this.f1256s);
            i4 = j(this.f1246h) + this.f1246h.getMeasuredWidth();
            i5 = Math.max(0, k(this.f1246h) + this.f1246h.getMeasuredHeight());
            i6 = View.combineMeasuredStates(0, this.f1246h.getMeasuredState());
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
        }
        if (q(this.f1250l)) {
            p(this.f1250l, i2, 0, i3, this.f1256s);
            i4 = j(this.f1250l) + this.f1250l.getMeasuredWidth();
            i5 = Math.max(i5, k(this.f1250l) + this.f1250l.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f1250l.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i4);
        int max2 = Math.max(0, currentContentInsetStart - i4);
        int[] iArr = this.f1237J;
        iArr[a2 ? 1 : 0] = max2;
        if (q(this.f1243e)) {
            p(this.f1243e, i2, max, i3, this.f1256s);
            i7 = j(this.f1243e) + this.f1243e.getMeasuredWidth();
            i5 = Math.max(i5, k(this.f1243e) + this.f1243e.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f1243e.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max3 = max + Math.max(currentContentInsetEnd, i7);
        iArr[i11] = Math.max(0, currentContentInsetEnd - i7);
        if (q(this.f1251m)) {
            max3 += o(this.f1251m, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, k(this.f1251m) + this.f1251m.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f1251m.getMeasuredState());
        }
        if (q(this.f1247i)) {
            max3 += o(this.f1247i, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, k(this.f1247i) + this.f1247i.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f1247i.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (((n0) childAt.getLayoutParams()).f2208b == 0 && q(childAt)) {
                max3 += o(childAt, i2, max3, i3, 0, iArr);
                int max4 = Math.max(i5, k(childAt) + childAt.getMeasuredHeight());
                i6 = View.combineMeasuredStates(i6, childAt.getMeasuredState());
                i5 = max4;
            } else {
                max3 = max3;
            }
        }
        int i14 = max3;
        int i15 = this.f1259v + this.f1260w;
        int i16 = this.f1257t + this.f1258u;
        if (q(this.f1244f)) {
            o(this.f1244f, i2, i14 + i16, i3, i15, iArr);
            int j2 = j(this.f1244f) + this.f1244f.getMeasuredWidth();
            i8 = k(this.f1244f) + this.f1244f.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i6, this.f1244f.getMeasuredState());
            i10 = j2;
        } else {
            i8 = 0;
            i9 = i6;
            i10 = 0;
        }
        if (q(this.f1245g)) {
            i10 = Math.max(i10, o(this.f1245g, i2, i14 + i16, i3, i15 + i8, iArr));
            i8 += k(this.f1245g) + this.f1245g.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i9, this.f1245g.getMeasuredState());
        }
        int max5 = Math.max(i5, i8);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i14 + i10;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max5;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i2, (-16777216) & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, i9 << 16);
        if (this.f1241N) {
            int childCount2 = getChildCount();
            for (int i17 = 0; i17 < childCount2; i17++) {
                View childAt2 = getChildAt(i17);
                if (!q(childAt2) || childAt2.getMeasuredWidth() <= 0 || childAt2.getMeasuredHeight() <= 0) {
                }
            }
            setMeasuredDimension(resolveSizeAndState, i12);
        }
        i12 = resolveSizeAndState2;
        setMeasuredDimension(resolveSizeAndState, i12);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof p0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        p0 p0Var = (p0) parcelable;
        super.onRestoreInstanceState(p0Var.f55e);
        ActionMenuView actionMenuView = this.f1243e;
        g.j jVar = actionMenuView != null ? actionMenuView.f1130t : null;
        int i2 = p0Var.f2214g;
        if (i2 != 0 && this.f1240M != null && jVar != null && (findItem = jVar.findItem(i2)) != null) {
            findItem.expandActionView();
        }
        if (p0Var.f2215h) {
            A.b bVar = this.f1242O;
            removeCallbacks(bVar);
            post(bVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        P p2 = this.f1261x;
        boolean z2 = i2 == 1;
        if (z2 == p2.f2106g) {
            return;
        }
        p2.f2106g = z2;
        if (!p2.f2107h) {
            p2.f2100a = p2.f2104e;
            p2.f2101b = p2.f2105f;
            return;
        }
        if (z2) {
            int i3 = p2.f2103d;
            if (i3 == Integer.MIN_VALUE) {
                i3 = p2.f2104e;
            }
            p2.f2100a = i3;
            int i4 = p2.f2102c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = p2.f2105f;
            }
            p2.f2101b = i4;
            return;
        }
        int i5 = p2.f2102c;
        if (i5 == Integer.MIN_VALUE) {
            i5 = p2.f2104e;
        }
        p2.f2100a = i5;
        int i6 = p2.f2103d;
        if (i6 == Integer.MIN_VALUE) {
            i6 = p2.f2105f;
        }
        p2.f2101b = i6;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C0168i c0168i;
        C0165f c0165f;
        k kVar;
        p0 p0Var = new p0(super.onSaveInstanceState());
        m0 m0Var = this.f1240M;
        if (m0Var != null && (kVar = m0Var.f2199f) != null) {
            p0Var.f2214g = kVar.f1959a;
        }
        ActionMenuView actionMenuView = this.f1243e;
        p0Var.f2215h = (actionMenuView == null || (c0168i = actionMenuView.f1133w) == null || (c0165f = c0168i.f2177v) == null || !c0165f.b()) ? false : true;
        return p0Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1233F = false;
        }
        if (!this.f1233F) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1233F = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f1233F = false;
        return true;
    }

    public final void p(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean q(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(AbstractC0112a.a(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f1241N = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f1263z) {
            this.f1263z = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f1262y) {
            this.f1262y = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(AbstractC0112a.a(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(AbstractC0112a.a(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        f();
        this.f1246h.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f1243e.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f1253o != i2) {
            this.f1253o = i2;
            if (i2 == 0) {
                this.f1252n = getContext();
            } else {
                this.f1252n = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f1260w = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f1258u = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f1257t = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f1259v = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        n0 n0Var = new n0(context, attributeSet);
        n0Var.f2207a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0096a.f1613b);
        n0Var.f2207a = obtainStyledAttributes.getInt(0, 0);
        obtainStyledAttributes.recycle();
        n0Var.f2208b = 0;
        return n0Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0175p c0175p = this.f1250l;
        if (c0175p != null) {
            c0175p.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f1250l.setImageDrawable(drawable);
        } else {
            C0175p c0175p = this.f1250l;
            if (c0175p != null) {
                c0175p.setImageDrawable(this.f1248j);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f1247i == null) {
                this.f1247i = new C0176q(getContext(), 0);
            }
            if (!l(this.f1247i)) {
                b(this.f1247i, true);
            }
        } else {
            C0176q c0176q = this.f1247i;
            if (c0176q != null && l(c0176q)) {
                removeView(this.f1247i);
                this.f1236I.remove(this.f1247i);
            }
        }
        C0176q c0176q2 = this.f1247i;
        if (c0176q2 != null) {
            c0176q2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f1247i == null) {
            this.f1247i = new C0176q(getContext(), 0);
        }
        C0176q c0176q = this.f1247i;
        if (c0176q != null) {
            c0176q.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            f();
        }
        C0175p c0175p = this.f1246h;
        if (c0175p != null) {
            c0175p.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            f();
            if (!l(this.f1246h)) {
                b(this.f1246h, true);
            }
        } else {
            C0175p c0175p = this.f1246h;
            if (c0175p != null && l(c0175p)) {
                removeView(this.f1246h);
                this.f1236I.remove(this.f1246h);
            }
        }
        C0175p c0175p2 = this.f1246h;
        if (c0175p2 != null) {
            c0175p2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0179u c0179u = this.f1245g;
            if (c0179u != null && l(c0179u)) {
                removeView(this.f1245g);
                this.f1236I.remove(this.f1245g);
            }
        } else {
            if (this.f1245g == null) {
                Context context = getContext();
                C0179u c0179u2 = new C0179u(context, null);
                this.f1245g = c0179u2;
                c0179u2.setSingleLine();
                this.f1245g.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f1255q;
                if (i2 != 0) {
                    this.f1245g.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f1232E;
                if (colorStateList != null) {
                    this.f1245g.setTextColor(colorStateList);
                }
            }
            if (!l(this.f1245g)) {
                b(this.f1245g, true);
            }
        }
        C0179u c0179u3 = this.f1245g;
        if (c0179u3 != null) {
            c0179u3.setText(charSequence);
        }
        this.f1230C = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f1232E = colorStateList;
        C0179u c0179u = this.f1245g;
        if (c0179u != null) {
            c0179u.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0179u c0179u = this.f1244f;
            if (c0179u != null && l(c0179u)) {
                removeView(this.f1244f);
                this.f1236I.remove(this.f1244f);
            }
        } else {
            if (this.f1244f == null) {
                Context context = getContext();
                C0179u c0179u2 = new C0179u(context, null);
                this.f1244f = c0179u2;
                c0179u2.setSingleLine();
                this.f1244f.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f1254p;
                if (i2 != 0) {
                    this.f1244f.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f1231D;
                if (colorStateList != null) {
                    this.f1244f.setTextColor(colorStateList);
                }
            }
            if (!l(this.f1244f)) {
                b(this.f1244f, true);
            }
        }
        C0179u c0179u3 = this.f1244f;
        if (c0179u3 != null) {
            c0179u3.setText(charSequence);
        }
        this.f1229B = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f1231D = colorStateList;
        C0179u c0179u = this.f1244f;
        if (c0179u != null) {
            c0179u.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(o0 o0Var) {
    }
}
