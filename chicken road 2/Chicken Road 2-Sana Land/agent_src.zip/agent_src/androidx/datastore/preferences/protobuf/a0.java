package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class a0 implements Iterator {

    /* renamed from: e, reason: collision with root package name */
    public int f1387e = -1;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1388f;

    /* renamed from: g, reason: collision with root package name */
    public Iterator f1389g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Y f1390h;

    public a0(Y y2) {
        this.f1390h = y2;
    }

    public final Iterator a() {
        if (this.f1389g == null) {
            this.f1389g = this.f1390h.f1380f.entrySet().iterator();
        }
        return this.f1389g;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i2 = this.f1387e + 1;
        Y y2 = this.f1390h;
        return i2 < y2.f1379e.size() || (!y2.f1380f.isEmpty() && a().hasNext());
    }

    @Override // java.util.Iterator
    public final Object next() {
        this.f1388f = true;
        int i2 = this.f1387e + 1;
        this.f1387e = i2;
        Y y2 = this.f1390h;
        return i2 < y2.f1379e.size() ? (Map.Entry) y2.f1379e.get(this.f1387e) : (Map.Entry) a().next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f1388f) {
            throw new IllegalStateException("remove() was called before next()");
        }
        this.f1388f = false;
        int i2 = Y.f1378j;
        Y y2 = this.f1390h;
        y2.b();
        if (this.f1387e >= y2.f1379e.size()) {
            a().remove();
            return;
        }
        int i3 = this.f1387e;
        this.f1387e = i3 - 1;
        y2.h(i3);
    }
}
