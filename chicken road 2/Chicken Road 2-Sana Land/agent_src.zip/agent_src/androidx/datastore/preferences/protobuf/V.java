package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class V {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0070a f1371a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1372b;

    /* renamed from: c, reason: collision with root package name */
    public final Object[] f1373c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1374d;

    public V(AbstractC0091w abstractC0091w, String str, Object[] objArr) {
        this.f1371a = abstractC0091w;
        this.f1372b = str;
        this.f1373c = objArr;
        char charAt = str.charAt(0);
        if (charAt < 55296) {
            this.f1374d = charAt;
            return;
        }
        int i2 = charAt & 8191;
        int i3 = 13;
        int i4 = 1;
        while (true) {
            int i5 = i4 + 1;
            char charAt2 = str.charAt(i4);
            if (charAt2 < 55296) {
                this.f1374d = i2 | (charAt2 << i3);
                return;
            } else {
                i2 |= (charAt2 & 8191) << i3;
                i3 += 13;
                i4 = i5;
            }
        }
    }

    public final int a() {
        int i2 = this.f1374d;
        if ((i2 & 1) != 0) {
            return 1;
        }
        return (i2 & 4) == 4 ? 3 : 2;
    }
}
