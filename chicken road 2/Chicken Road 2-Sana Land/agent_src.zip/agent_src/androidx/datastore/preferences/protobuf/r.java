package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class r {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f1455c = 0;

    /* renamed from: a, reason: collision with root package name */
    public final Y f1456a = Y.f();

    /* renamed from: b, reason: collision with root package name */
    public boolean f1457b;

    static {
        new r(0);
    }

    public r() {
    }

    public static void b(C0082m c0082m, r0 r0Var, int i2, Object obj) {
        if (r0Var == r0.f1459h) {
            c0082m.p0(i2, 3);
            ((AbstractC0070a) obj).b(c0082m);
            c0082m.p0(i2, 4);
        }
        c0082m.p0(i2, r0Var.f1463f);
        switch (r0Var.ordinal()) {
            case 0:
                c0082m.j0(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                c0082m.h0(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                c0082m.t0(((Long) obj).longValue());
                break;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                c0082m.t0(((Long) obj).longValue());
                break;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                c0082m.l0(((Integer) obj).intValue());
                break;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                c0082m.j0(((Long) obj).longValue());
                break;
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                c0082m.h0(((Integer) obj).intValue());
                break;
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                c0082m.b0(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                if (!(obj instanceof C0076g)) {
                    c0082m.o0((String) obj);
                    break;
                } else {
                    c0082m.f0((C0076g) obj);
                    break;
                }
            case 9:
                ((AbstractC0070a) obj).b(c0082m);
                break;
            case 10:
                AbstractC0070a abstractC0070a = (AbstractC0070a) obj;
                c0082m.getClass();
                c0082m.r0(((AbstractC0091w) abstractC0070a).a(null));
                abstractC0070a.b(c0082m);
                break;
            case 11:
                if (!(obj instanceof C0076g)) {
                    byte[] bArr = (byte[]) obj;
                    int length = bArr.length;
                    c0082m.r0(length);
                    c0082m.c0(bArr, 0, length);
                    break;
                } else {
                    c0082m.f0((C0076g) obj);
                    break;
                }
            case 12:
                c0082m.r0(((Integer) obj).intValue());
                break;
            case 13:
                c0082m.l0(((Integer) obj).intValue());
                break;
            case 14:
                c0082m.h0(((Integer) obj).intValue());
                break;
            case 15:
                c0082m.j0(((Long) obj).longValue());
                break;
            case 16:
                int intValue = ((Integer) obj).intValue();
                c0082m.r0((intValue >> 31) ^ (intValue << 1));
                break;
            case 17:
                long longValue = ((Long) obj).longValue();
                c0082m.t0((longValue >> 63) ^ (longValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f1457b) {
            return;
        }
        Y y2 = this.f1456a;
        int size = y2.f1379e.size();
        for (int i2 = 0; i2 < size; i2++) {
            Map.Entry c2 = y2.c(i2);
            if (c2.getValue() instanceof AbstractC0091w) {
                AbstractC0091w abstractC0091w = (AbstractC0091w) c2.getValue();
                abstractC0091w.getClass();
                T t2 = T.f1365c;
                t2.getClass();
                t2.a(abstractC0091w.getClass()).d(abstractC0091w);
                abstractC0091w.h();
            }
        }
        if (!y2.f1381g) {
            if (y2.f1379e.size() > 0) {
                y2.c(0).getKey().getClass();
                throw new ClassCastException();
            }
            Iterator it = y2.d().iterator();
            if (it.hasNext()) {
                ((Map.Entry) it.next()).getKey().getClass();
                throw new ClassCastException();
            }
        }
        if (!y2.f1381g) {
            y2.f1380f = y2.f1380f.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y2.f1380f);
            y2.f1383i = y2.f1383i.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y2.f1383i);
            y2.f1381g = true;
        }
        this.f1457b = true;
    }

    public final Object clone() {
        r rVar = new r();
        Y y2 = this.f1456a;
        if (y2.f1379e.size() > 0) {
            Map.Entry c2 = y2.c(0);
            if (c2.getKey() != null) {
                throw new ClassCastException();
            }
            c2.getValue();
            throw null;
        }
        Iterator it = y2.d().iterator();
        if (!it.hasNext()) {
            return rVar;
        }
        Map.Entry entry = (Map.Entry) it.next();
        if (entry.getKey() != null) {
            throw new ClassCastException();
        }
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof r) {
            return this.f1456a.equals(((r) obj).f1456a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f1456a.hashCode();
    }

    public r(int i2) {
        a();
        a();
    }
}
