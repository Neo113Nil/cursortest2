package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF0' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: androidx.datastore.preferences.protobuf.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0087s {

    /* renamed from: f, reason: collision with root package name */
    public static final EnumC0087s f1464f;

    /* renamed from: g, reason: collision with root package name */
    public static final EnumC0087s f1465g;

    /* renamed from: h, reason: collision with root package name */
    public static final EnumC0087s[] f1466h;

    /* renamed from: i, reason: collision with root package name */
    public static final /* synthetic */ EnumC0087s[] f1467i;

    /* renamed from: e, reason: collision with root package name */
    public final int f1468e;

    /* JADX INFO: Fake field, exist only in values array */
    EnumC0087s EF0;

    static {
        B b2 = B.DOUBLE;
        EnumC0087s enumC0087s = new EnumC0087s("DOUBLE", 0, 0, 1, b2);
        B b3 = B.FLOAT;
        EnumC0087s enumC0087s2 = new EnumC0087s("FLOAT", 1, 1, 1, b3);
        B b4 = B.LONG;
        EnumC0087s enumC0087s3 = new EnumC0087s("INT64", 2, 2, 1, b4);
        EnumC0087s enumC0087s4 = new EnumC0087s("UINT64", 3, 3, 1, b4);
        B b5 = B.INT;
        EnumC0087s enumC0087s5 = new EnumC0087s("INT32", 4, 4, 1, b5);
        EnumC0087s enumC0087s6 = new EnumC0087s("FIXED64", 5, 5, 1, b4);
        EnumC0087s enumC0087s7 = new EnumC0087s("FIXED32", 6, 6, 1, b5);
        B b6 = B.BOOLEAN;
        EnumC0087s enumC0087s8 = new EnumC0087s("BOOL", 7, 7, 1, b6);
        B b7 = B.STRING;
        EnumC0087s enumC0087s9 = new EnumC0087s("STRING", 8, 8, 1, b7);
        B b8 = B.MESSAGE;
        EnumC0087s enumC0087s10 = new EnumC0087s("MESSAGE", 9, 9, 1, b8);
        B b9 = B.BYTE_STRING;
        EnumC0087s enumC0087s11 = new EnumC0087s("BYTES", 10, 10, 1, b9);
        EnumC0087s enumC0087s12 = new EnumC0087s("UINT32", 11, 11, 1, b5);
        B b10 = B.ENUM;
        EnumC0087s enumC0087s13 = new EnumC0087s("ENUM", 12, 12, 1, b10);
        EnumC0087s enumC0087s14 = new EnumC0087s("SFIXED32", 13, 13, 1, b5);
        EnumC0087s enumC0087s15 = new EnumC0087s("SFIXED64", 14, 14, 1, b4);
        EnumC0087s enumC0087s16 = new EnumC0087s("SINT32", 15, 15, 1, b5);
        EnumC0087s enumC0087s17 = new EnumC0087s("SINT64", 16, 16, 1, b4);
        EnumC0087s enumC0087s18 = new EnumC0087s("GROUP", 17, 17, 1, b8);
        EnumC0087s enumC0087s19 = new EnumC0087s("DOUBLE_LIST", 18, 18, 2, b2);
        EnumC0087s enumC0087s20 = new EnumC0087s("FLOAT_LIST", 19, 19, 2, b3);
        EnumC0087s enumC0087s21 = new EnumC0087s("INT64_LIST", 20, 20, 2, b4);
        EnumC0087s enumC0087s22 = new EnumC0087s("UINT64_LIST", 21, 21, 2, b4);
        EnumC0087s enumC0087s23 = new EnumC0087s("INT32_LIST", 22, 22, 2, b5);
        EnumC0087s enumC0087s24 = new EnumC0087s("FIXED64_LIST", 23, 23, 2, b4);
        EnumC0087s enumC0087s25 = new EnumC0087s("FIXED32_LIST", 24, 24, 2, b5);
        EnumC0087s enumC0087s26 = new EnumC0087s("BOOL_LIST", 25, 25, 2, b6);
        EnumC0087s enumC0087s27 = new EnumC0087s("STRING_LIST", 26, 26, 2, b7);
        EnumC0087s enumC0087s28 = new EnumC0087s("MESSAGE_LIST", 27, 27, 2, b8);
        EnumC0087s enumC0087s29 = new EnumC0087s("BYTES_LIST", 28, 28, 2, b9);
        EnumC0087s enumC0087s30 = new EnumC0087s("UINT32_LIST", 29, 29, 2, b5);
        EnumC0087s enumC0087s31 = new EnumC0087s("ENUM_LIST", 30, 30, 2, b10);
        EnumC0087s enumC0087s32 = new EnumC0087s("SFIXED32_LIST", 31, 31, 2, b5);
        EnumC0087s enumC0087s33 = new EnumC0087s("SFIXED64_LIST", 32, 32, 2, b4);
        EnumC0087s enumC0087s34 = new EnumC0087s("SINT32_LIST", 33, 33, 2, b5);
        EnumC0087s enumC0087s35 = new EnumC0087s("SINT64_LIST", 34, 34, 2, b4);
        EnumC0087s enumC0087s36 = new EnumC0087s("DOUBLE_LIST_PACKED", 35, 35, 3, b2);
        f1464f = enumC0087s36;
        EnumC0087s enumC0087s37 = new EnumC0087s("FLOAT_LIST_PACKED", 36, 36, 3, b3);
        EnumC0087s enumC0087s38 = new EnumC0087s("INT64_LIST_PACKED", 37, 37, 3, b4);
        EnumC0087s enumC0087s39 = new EnumC0087s("UINT64_LIST_PACKED", 38, 38, 3, b4);
        EnumC0087s enumC0087s40 = new EnumC0087s("INT32_LIST_PACKED", 39, 39, 3, b5);
        EnumC0087s enumC0087s41 = new EnumC0087s("FIXED64_LIST_PACKED", 40, 40, 3, b4);
        EnumC0087s enumC0087s42 = new EnumC0087s("FIXED32_LIST_PACKED", 41, 41, 3, b5);
        EnumC0087s enumC0087s43 = new EnumC0087s("BOOL_LIST_PACKED", 42, 42, 3, b6);
        EnumC0087s enumC0087s44 = new EnumC0087s("UINT32_LIST_PACKED", 43, 43, 3, b5);
        EnumC0087s enumC0087s45 = new EnumC0087s("ENUM_LIST_PACKED", 44, 44, 3, b10);
        EnumC0087s enumC0087s46 = new EnumC0087s("SFIXED32_LIST_PACKED", 45, 45, 3, b5);
        EnumC0087s enumC0087s47 = new EnumC0087s("SFIXED64_LIST_PACKED", 46, 46, 3, b4);
        EnumC0087s enumC0087s48 = new EnumC0087s("SINT32_LIST_PACKED", 47, 47, 3, b5);
        EnumC0087s enumC0087s49 = new EnumC0087s("SINT64_LIST_PACKED", 48, 48, 3, b4);
        f1465g = enumC0087s49;
        f1467i = new EnumC0087s[]{enumC0087s, enumC0087s2, enumC0087s3, enumC0087s4, enumC0087s5, enumC0087s6, enumC0087s7, enumC0087s8, enumC0087s9, enumC0087s10, enumC0087s11, enumC0087s12, enumC0087s13, enumC0087s14, enumC0087s15, enumC0087s16, enumC0087s17, enumC0087s18, enumC0087s19, enumC0087s20, enumC0087s21, enumC0087s22, enumC0087s23, enumC0087s24, enumC0087s25, enumC0087s26, enumC0087s27, enumC0087s28, enumC0087s29, enumC0087s30, enumC0087s31, enumC0087s32, enumC0087s33, enumC0087s34, enumC0087s35, enumC0087s36, enumC0087s37, enumC0087s38, enumC0087s39, enumC0087s40, enumC0087s41, enumC0087s42, enumC0087s43, enumC0087s44, enumC0087s45, enumC0087s46, enumC0087s47, enumC0087s48, enumC0087s49, new EnumC0087s("GROUP_LIST", 49, 49, 2, b8), new EnumC0087s("MAP", 50, 50, 4, B.VOID)};
        EnumC0087s[] values = values();
        f1466h = new EnumC0087s[values.length];
        for (EnumC0087s enumC0087s50 : values) {
            f1466h[enumC0087s50.f1468e] = enumC0087s50;
        }
    }

    public EnumC0087s(String str, int i2, int i3, int i4, B b2) {
        this.f1468e = i3;
        int a2 = F.i.a(i4);
        if (a2 == 1) {
            b2.getClass();
        } else if (a2 == 3) {
            b2.getClass();
        }
        if (i4 == 1) {
            b2.ordinal();
        }
    }

    public static EnumC0087s valueOf(String str) {
        return (EnumC0087s) Enum.valueOf(EnumC0087s.class, str);
    }

    public static EnumC0087s[] values() {
        return (EnumC0087s[]) f1467i.clone();
    }
}
