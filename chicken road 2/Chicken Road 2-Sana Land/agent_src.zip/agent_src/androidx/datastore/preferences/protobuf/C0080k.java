package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* renamed from: androidx.datastore.preferences.protobuf.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0080k {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0079j f1437a;

    /* renamed from: b, reason: collision with root package name */
    public int f1438b;

    /* renamed from: c, reason: collision with root package name */
    public int f1439c;

    /* renamed from: d, reason: collision with root package name */
    public int f1440d = 0;

    public C0080k(AbstractC0079j abstractC0079j) {
        Charset charset = AbstractC0093y.f1484a;
        this.f1437a = abstractC0079j;
        abstractC0079j.f1429b = this;
    }

    public final int a() {
        int i2 = this.f1440d;
        if (i2 != 0) {
            this.f1438b = i2;
            this.f1440d = 0;
        } else {
            this.f1438b = this.f1437a.u();
        }
        int i3 = this.f1438b;
        if (i3 == 0 || i3 == this.f1439c) {
            return Integer.MAX_VALUE;
        }
        return i3 >>> 3;
    }

    public final void b(Object obj, W w2, C0084o c0084o) {
        int i2 = this.f1439c;
        this.f1439c = ((this.f1438b >>> 3) << 3) | 4;
        try {
            w2.g(obj, this, c0084o);
            if (this.f1438b == this.f1439c) {
            } else {
                throw new A("Failed to parse the message.");
            }
        } finally {
            this.f1439c = i2;
        }
    }

    public final void c(Object obj, W w2, C0084o c0084o) {
        AbstractC0079j abstractC0079j = this.f1437a;
        int v2 = abstractC0079j.v();
        if (abstractC0079j.f1428a >= 100) {
            throw new A("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        int e2 = abstractC0079j.e(v2);
        abstractC0079j.f1428a++;
        w2.g(obj, this, c0084o);
        abstractC0079j.a(0);
        abstractC0079j.f1428a--;
        abstractC0079j.d(e2);
    }

    public final void d(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Boolean.valueOf(abstractC0079j.f()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Boolean.valueOf(abstractC0079j.f()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final C0076g e() {
        w(2);
        return this.f1437a.g();
    }

    public final void f(InterfaceC0092x interfaceC0092x) {
        int u2;
        if ((this.f1438b & 7) != 2) {
            throw A.b();
        }
        do {
            ((U) interfaceC0092x).add(e());
            AbstractC0079j abstractC0079j = this.f1437a;
            if (abstractC0079j.c()) {
                return;
            } else {
                u2 = abstractC0079j.u();
            }
        } while (u2 == this.f1438b);
        this.f1440d = u2;
    }

    public final void g(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0092x).add(Double.valueOf(abstractC0079j.h()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0079j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0079j.b() + v2;
        do {
            ((U) interfaceC0092x).add(Double.valueOf(abstractC0079j.h()));
        } while (abstractC0079j.b() < b2);
    }

    public final void h(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.i()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.i()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final Object i(r0 r0Var, Class cls, C0084o c0084o) {
        int ordinal = r0Var.ordinal();
        AbstractC0079j abstractC0079j = this.f1437a;
        switch (ordinal) {
            case 0:
                w(1);
                return Double.valueOf(abstractC0079j.h());
            case 1:
                w(5);
                return Float.valueOf(abstractC0079j.l());
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                w(0);
                return Long.valueOf(abstractC0079j.n());
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                w(0);
                return Long.valueOf(abstractC0079j.w());
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                w(0);
                return Integer.valueOf(abstractC0079j.m());
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                w(1);
                return Long.valueOf(abstractC0079j.k());
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                w(5);
                return Integer.valueOf(abstractC0079j.j());
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                w(0);
                return Boolean.valueOf(abstractC0079j.f());
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                w(2);
                return abstractC0079j.t();
            case 9:
            default:
                throw new IllegalArgumentException("unsupported field type.");
            case 10:
                w(2);
                W a2 = T.f1365c.a(cls);
                AbstractC0091w i2 = a2.i();
                c(i2, a2, c0084o);
                a2.d(i2);
                return i2;
            case 11:
                return e();
            case 12:
                w(0);
                return Integer.valueOf(abstractC0079j.v());
            case 13:
                w(0);
                return Integer.valueOf(abstractC0079j.i());
            case 14:
                w(5);
                return Integer.valueOf(abstractC0079j.o());
            case 15:
                w(1);
                return Long.valueOf(abstractC0079j.p());
            case 16:
                w(0);
                return Integer.valueOf(abstractC0079j.q());
            case 17:
                w(0);
                return Long.valueOf(abstractC0079j.r());
        }
    }

    public final void j(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 2) {
            int v2 = abstractC0079j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0079j.b() + v2;
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.j()));
            } while (abstractC0079j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.j()));
            if (abstractC0079j.c()) {
                return;
            } else {
                u2 = abstractC0079j.u();
            }
        } while (u2 == this.f1438b);
        this.f1440d = u2;
    }

    public final void k(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.k()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0079j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0079j.b() + v2;
        do {
            ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.k()));
        } while (abstractC0079j.b() < b2);
    }

    public final void l(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 2) {
            int v2 = abstractC0079j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0079j.b() + v2;
            do {
                ((U) interfaceC0092x).add(Float.valueOf(abstractC0079j.l()));
            } while (abstractC0079j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0092x).add(Float.valueOf(abstractC0079j.l()));
            if (abstractC0079j.c()) {
                return;
            } else {
                u2 = abstractC0079j.u();
            }
        } while (u2 == this.f1438b);
        this.f1440d = u2;
    }

    public final void m(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.m()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.m()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void n(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.n()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.n()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void o(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 2) {
            int v2 = abstractC0079j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0079j.b() + v2;
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.o()));
            } while (abstractC0079j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.o()));
            if (abstractC0079j.c()) {
                return;
            } else {
                u2 = abstractC0079j.u();
            }
        } while (u2 == this.f1438b);
        this.f1440d = u2;
    }

    public final void p(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.p()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0079j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0079j.b() + v2;
        do {
            ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.p()));
        } while (abstractC0079j.b() < b2);
    }

    public final void q(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.q()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.q()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void r(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.r()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.r()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void s(InterfaceC0092x interfaceC0092x, boolean z2) {
        String s2;
        int u2;
        if ((this.f1438b & 7) != 2) {
            throw A.b();
        }
        do {
            AbstractC0079j abstractC0079j = this.f1437a;
            if (z2) {
                w(2);
                s2 = abstractC0079j.t();
            } else {
                w(2);
                s2 = abstractC0079j.s();
            }
            ((U) interfaceC0092x).add(s2);
            if (abstractC0079j.c()) {
                return;
            } else {
                u2 = abstractC0079j.u();
            }
        } while (u2 == this.f1438b);
        this.f1440d = u2;
    }

    public final void t(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.v()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Integer.valueOf(abstractC0079j.v()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void u(InterfaceC0092x interfaceC0092x) {
        int u2;
        int i2 = this.f1438b & 7;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.w()));
                if (abstractC0079j.c()) {
                    return;
                } else {
                    u2 = abstractC0079j.u();
                }
            } while (u2 == this.f1438b);
            this.f1440d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0079j.b() + abstractC0079j.v();
        do {
            ((U) interfaceC0092x).add(Long.valueOf(abstractC0079j.w()));
        } while (abstractC0079j.b() < b2);
        v(b2);
    }

    public final void v(int i2) {
        if (this.f1437a.b() != i2) {
            throw A.e();
        }
    }

    public final void w(int i2) {
        if ((this.f1438b & 7) != i2) {
            throw A.b();
        }
    }

    public final boolean x() {
        int i2;
        AbstractC0079j abstractC0079j = this.f1437a;
        if (abstractC0079j.c() || (i2 = this.f1438b) == this.f1439c) {
            return false;
        }
        return abstractC0079j.x(i2);
    }
}
