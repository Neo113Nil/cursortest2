package androidx.datastore.preferences.protobuf;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: androidx.datastore.preferences.protobuf.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0091w extends AbstractC0070a {
    private static final int MEMOIZED_SERIALIZED_SIZE_MASK = Integer.MAX_VALUE;
    private static final int MUTABLE_FLAG_MASK = Integer.MIN_VALUE;
    static final int UNINITIALIZED_HASH_CODE = 0;
    static final int UNINITIALIZED_SERIALIZED_SIZE = Integer.MAX_VALUE;
    private static Map<Object, AbstractC0091w> defaultInstanceMap = new ConcurrentHashMap();
    private int memoizedSerializedSize;
    protected d0 unknownFields;

    public AbstractC0091w() {
        this.memoizedHashCode = UNINITIALIZED_HASH_CODE;
        this.memoizedSerializedSize = -1;
        this.unknownFields = d0.f1398f;
    }

    public static AbstractC0091w d(Class cls) {
        AbstractC0091w abstractC0091w = defaultInstanceMap.get(cls);
        if (abstractC0091w == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                abstractC0091w = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e2) {
                throw new IllegalStateException("Class initialization cannot fail.", e2);
            }
        }
        if (abstractC0091w != null) {
            return abstractC0091w;
        }
        AbstractC0091w abstractC0091w2 = (AbstractC0091w) ((AbstractC0091w) j0.d(cls)).c(6);
        if (abstractC0091w2 == null) {
            throw new IllegalStateException();
        }
        defaultInstanceMap.put(cls, abstractC0091w2);
        return abstractC0091w2;
    }

    public static Object e(Method method, AbstractC0091w abstractC0091w, Object... objArr) {
        try {
            return method.invoke(abstractC0091w, objArr);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e2);
        } catch (InvocationTargetException e3) {
            Throwable cause = e3.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
        }
    }

    public static final boolean f(AbstractC0091w abstractC0091w, boolean z2) {
        byte byteValue = ((Byte) abstractC0091w.c(1)).byteValue();
        if (byteValue == 1) {
            return true;
        }
        if (byteValue == 0) {
            return false;
        }
        T t2 = T.f1365c;
        t2.getClass();
        boolean e2 = t2.a(abstractC0091w.getClass()).e(abstractC0091w);
        if (z2) {
            abstractC0091w.c(2);
        }
        return e2;
    }

    public static void j(Class cls, AbstractC0091w abstractC0091w) {
        abstractC0091w.h();
        defaultInstanceMap.put(cls, abstractC0091w);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0070a
    public final int a(W w2) {
        int h2;
        int h3;
        if (g()) {
            if (w2 == null) {
                T t2 = T.f1365c;
                t2.getClass();
                h3 = t2.a(getClass()).h(this);
            } else {
                h3 = w2.h(this);
            }
            if (h3 >= 0) {
                return h3;
            }
            throw new IllegalStateException(E0.h.e("serialized size must be non-negative, was ", h3));
        }
        int i2 = this.memoizedSerializedSize;
        if ((i2 & Integer.MAX_VALUE) != Integer.MAX_VALUE) {
            return i2 & Integer.MAX_VALUE;
        }
        if (w2 == null) {
            T t3 = T.f1365c;
            t3.getClass();
            h2 = t3.a(getClass()).h(this);
        } else {
            h2 = w2.h(this);
        }
        k(h2);
        return h2;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0070a
    public final void b(C0082m c0082m) {
        T t2 = T.f1365c;
        t2.getClass();
        W a2 = t2.a(getClass());
        F f2 = c0082m.f1444i;
        if (f2 == null) {
            f2 = new F(c0082m);
        }
        a2.b(this, f2);
    }

    public abstract Object c(int i2);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        T t2 = T.f1365c;
        t2.getClass();
        return t2.a(getClass()).f(this, (AbstractC0091w) obj);
    }

    public final boolean g() {
        return (this.memoizedSerializedSize & MUTABLE_FLAG_MASK) != 0;
    }

    public final void h() {
        this.memoizedSerializedSize &= Integer.MAX_VALUE;
    }

    public final int hashCode() {
        if (g()) {
            T t2 = T.f1365c;
            t2.getClass();
            return t2.a(getClass()).c(this);
        }
        if (this.memoizedHashCode == 0) {
            T t3 = T.f1365c;
            t3.getClass();
            this.memoizedHashCode = t3.a(getClass()).c(this);
        }
        return this.memoizedHashCode;
    }

    public final AbstractC0091w i() {
        return (AbstractC0091w) c(4);
    }

    public final void k(int i2) {
        if (i2 < 0) {
            throw new IllegalStateException(E0.h.e("serialized size must be non-negative, was ", i2));
        }
        this.memoizedSerializedSize = (i2 & Integer.MAX_VALUE) | (this.memoizedSerializedSize & MUTABLE_FLAG_MASK);
    }

    public final String toString() {
        String obj = super.toString();
        char[] cArr = M.f1344a;
        StringBuilder sb = new StringBuilder();
        sb.append("# ");
        sb.append(obj);
        M.c(this, sb, UNINITIALIZED_HASH_CODE);
        return sb.toString();
    }
}
