package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: androidx.datastore.preferences.protobuf.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0073d implements Iterator {

    /* renamed from: e, reason: collision with root package name */
    public int f1395e = 0;

    /* renamed from: f, reason: collision with root package name */
    public final int f1396f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ C0076g f1397g;

    public C0073d(C0076g c0076g) {
        this.f1397g = c0076g;
        this.f1396f = c0076g.size();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f1395e < this.f1396f;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i2 = this.f1395e;
        if (i2 >= this.f1396f) {
            throw new NoSuchElementException();
        }
        this.f1395e = i2 + 1;
        return Byte.valueOf(this.f1397g.f(i2));
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
