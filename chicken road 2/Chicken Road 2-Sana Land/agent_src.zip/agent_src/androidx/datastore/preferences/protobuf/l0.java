package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class l0 extends IllegalArgumentException {
    public l0(int i2, int i3) {
        super(E0.h.f("Unpaired surrogate at index ", i2, " of ", i3));
    }
}
