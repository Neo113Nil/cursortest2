package androidx.datastore.preferences.protobuf;

import java.util.Map;

/* loaded from: classes.dex */
public final class Z implements Map.Entry, Comparable {

    /* renamed from: e, reason: collision with root package name */
    public final Comparable f1384e;

    /* renamed from: f, reason: collision with root package name */
    public Object f1385f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Y f1386g;

    public Z(Y y2, Comparable comparable, Object obj) {
        this.f1386g = y2;
        this.f1384e = comparable;
        this.f1385f = obj;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.f1384e.compareTo(((Z) obj).f1384e);
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof Map.Entry) {
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                Comparable comparable = this.f1384e;
                if (comparable == null ? key == null : comparable.equals(key)) {
                    Object obj2 = this.f1385f;
                    Object value = entry.getValue();
                    if (obj2 == null ? value == null : obj2.equals(value)) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f1384e;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f1385f;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Comparable comparable = this.f1384e;
        int hashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f1385f;
        return (obj != null ? obj.hashCode() : 0) ^ hashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        this.f1386g.b();
        Object obj2 = this.f1385f;
        this.f1385f = obj;
        return obj2;
    }

    public final String toString() {
        return this.f1384e + "=" + this.f1385f;
    }
}
