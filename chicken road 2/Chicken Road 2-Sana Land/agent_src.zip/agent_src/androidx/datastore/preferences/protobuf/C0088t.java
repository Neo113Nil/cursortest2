package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.t, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0088t implements L {

    /* renamed from: b, reason: collision with root package name */
    public static final C0088t f1480b = new C0088t(0);

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1481a;

    public /* synthetic */ C0088t(int i2) {
        this.f1481a = i2;
    }

    @Override // androidx.datastore.preferences.protobuf.L
    public final V a(Class cls) {
        switch (this.f1481a) {
            case 0:
                if (!AbstractC0091w.class.isAssignableFrom(cls)) {
                    throw new IllegalArgumentException("Unsupported message type: ".concat(cls.getName()));
                }
                try {
                    return (V) AbstractC0091w.d(cls.asSubclass(AbstractC0091w.class)).c(3);
                } catch (Exception e2) {
                    throw new RuntimeException("Unable to get message info for ".concat(cls.getName()), e2);
                }
            default:
                throw new IllegalStateException("This should never be called.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.L
    public final boolean b(Class cls) {
        switch (this.f1481a) {
            case 0:
                return AbstractC0091w.class.isAssignableFrom(cls);
            default:
                return false;
        }
    }
}
