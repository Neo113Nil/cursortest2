package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class e0 {
    public static d0 a(Object obj) {
        AbstractC0091w abstractC0091w = (AbstractC0091w) obj;
        d0 d0Var = abstractC0091w.unknownFields;
        if (d0Var != d0.f1398f) {
            return d0Var;
        }
        d0 d0Var2 = new d0(0, new int[8], new Object[8], true);
        abstractC0091w.unknownFields = d0Var2;
        return d0Var2;
    }

    public static boolean b(int i2, C0080k c0080k, Object obj) {
        AbstractC0079j abstractC0079j = c0080k.f1437a;
        int i3 = c0080k.f1438b;
        int i4 = i3 >>> 3;
        int i5 = i3 & 7;
        if (i5 == 0) {
            c0080k.w(0);
            ((d0) obj).c(i4 << 3, Long.valueOf(abstractC0079j.n()));
            return true;
        }
        if (i5 == 1) {
            c0080k.w(1);
            ((d0) obj).c((i4 << 3) | 1, Long.valueOf(abstractC0079j.k()));
            return true;
        }
        if (i5 == 2) {
            ((d0) obj).c((i4 << 3) | 2, c0080k.e());
            return true;
        }
        if (i5 != 3) {
            if (i5 == 4) {
                return false;
            }
            if (i5 != 5) {
                throw A.b();
            }
            c0080k.w(5);
            ((d0) obj).c(5 | (i4 << 3), Integer.valueOf(abstractC0079j.j()));
            return true;
        }
        d0 d0Var = new d0(0, new int[8], new Object[8], true);
        int i6 = i4 << 3;
        int i7 = i6 | 4;
        int i8 = i2 + 1;
        if (i8 >= 100) {
            throw new A("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        while (c0080k.a() != Integer.MAX_VALUE && b(i8, c0080k, d0Var)) {
        }
        if (i7 != c0080k.f1438b) {
            throw new A("Protocol message end-group tag did not match expected tag.");
        }
        if (d0Var.f1403e) {
            d0Var.f1403e = false;
        }
        ((d0) obj).c(i6 | 3, d0Var);
        return true;
    }
}
