package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class K {

    /* renamed from: a, reason: collision with root package name */
    public static final J f1342a;

    /* renamed from: b, reason: collision with root package name */
    public static final J f1343b;

    static {
        T t2 = T.f1365c;
        J j2 = null;
        try {
            j2 = (J) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1342a = j2;
        f1343b = new J();
    }
}
