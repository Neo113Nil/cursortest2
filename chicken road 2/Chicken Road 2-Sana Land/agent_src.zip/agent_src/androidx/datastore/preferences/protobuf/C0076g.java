package androidx.datastore.preferences.protobuf;

import a.AbstractC0068a;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;

/* renamed from: androidx.datastore.preferences.protobuf.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0076g implements Iterable, Serializable {

    /* renamed from: g, reason: collision with root package name */
    public static final C0076g f1407g = new C0076g(AbstractC0093y.f1485b);

    /* renamed from: h, reason: collision with root package name */
    public static final C0074e f1408h;

    /* renamed from: e, reason: collision with root package name */
    public int f1409e = 0;

    /* renamed from: f, reason: collision with root package name */
    public final byte[] f1410f;

    static {
        f1408h = AbstractC0072c.a() ? new C0074e(1) : new C0074e(0);
    }

    public C0076g(byte[] bArr) {
        bArr.getClass();
        this.f1410f = bArr;
    }

    public static int b(int i2, int i3, int i4) {
        int i5 = i3 - i2;
        if ((i2 | i3 | i5 | (i4 - i3)) >= 0) {
            return i5;
        }
        if (i2 >= 0) {
            if (i3 < i2) {
                throw new IndexOutOfBoundsException(E0.h.f("Beginning index larger than ending index: ", i2, ", ", i3));
            }
            throw new IndexOutOfBoundsException(E0.h.f("End index: ", i3, " >= ", i4));
        }
        throw new IndexOutOfBoundsException("Beginning index: " + i2 + " < 0");
    }

    public static C0076g c(byte[] bArr, int i2, int i3) {
        byte[] copyOfRange;
        b(i2, i2 + i3, bArr.length);
        switch (f1408h.f1404a) {
            case 0:
                copyOfRange = Arrays.copyOfRange(bArr, i2, i3 + i2);
                break;
            default:
                copyOfRange = new byte[i3];
                System.arraycopy(bArr, i2, copyOfRange, 0, i3);
                break;
        }
        return new C0076g(copyOfRange);
    }

    public byte a(int i2) {
        return this.f1410f[i2];
    }

    public void d(byte[] bArr, int i2) {
        System.arraycopy(this.f1410f, 0, bArr, 0, i2);
    }

    public int e() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0076g) || size() != ((C0076g) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof C0076g)) {
            return obj.equals(this);
        }
        C0076g c0076g = (C0076g) obj;
        int i2 = this.f1409e;
        int i3 = c0076g.f1409e;
        if (i2 != 0 && i3 != 0 && i2 != i3) {
            return false;
        }
        int size = size();
        if (size > c0076g.size()) {
            throw new IllegalArgumentException("Length too large: " + size + size());
        }
        if (size > c0076g.size()) {
            throw new IllegalArgumentException("Ran off end of other: 0, " + size + ", " + c0076g.size());
        }
        byte[] bArr = c0076g.f1410f;
        int e2 = e() + size;
        int e3 = e();
        int e4 = c0076g.e();
        while (e3 < e2) {
            if (this.f1410f[e3] != bArr[e4]) {
                return false;
            }
            e3++;
            e4++;
        }
        return true;
    }

    public byte f(int i2) {
        return this.f1410f[i2];
    }

    public final int hashCode() {
        int i2 = this.f1409e;
        if (i2 != 0) {
            return i2;
        }
        int size = size();
        int e2 = e();
        int i3 = size;
        for (int i4 = e2; i4 < e2 + size; i4++) {
            i3 = (i3 * 31) + this.f1410f[i4];
        }
        if (i3 == 0) {
            i3 = 1;
        }
        this.f1409e = i3;
        return i3;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new C0073d(this);
    }

    public int size() {
        return this.f1410f.length;
    }

    public final String toString() {
        String sb;
        Locale locale = Locale.ROOT;
        String hexString = Integer.toHexString(System.identityHashCode(this));
        int size = size();
        if (size() <= 50) {
            sb = AbstractC0068a.r(this);
        } else {
            StringBuilder sb2 = new StringBuilder();
            int b2 = b(0, 47, size());
            sb2.append(AbstractC0068a.r(b2 == 0 ? f1407g : new C0075f(this.f1410f, e(), b2)));
            sb2.append("...");
            sb = sb2.toString();
        }
        return "<ByteString@" + hexString + " size=" + size + " contents=\"" + sb + "\">";
    }
}
