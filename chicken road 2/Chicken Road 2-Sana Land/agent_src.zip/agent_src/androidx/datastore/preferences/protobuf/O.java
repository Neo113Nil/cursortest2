package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class O implements W {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0070a f1360a;

    /* renamed from: b, reason: collision with root package name */
    public final e0 f1361b;

    /* renamed from: c, reason: collision with root package name */
    public final C0085p f1362c;

    public O(e0 e0Var, C0085p c0085p, AbstractC0070a abstractC0070a) {
        this.f1361b = e0Var;
        c0085p.getClass();
        this.f1362c = c0085p;
        this.f1360a = abstractC0070a;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void a(Object obj, Object obj2) {
        X.k(this.f1361b, obj, obj2);
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void b(Object obj, F f2) {
        this.f1362c.getClass();
        E0.h.h(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final int c(AbstractC0091w abstractC0091w) {
        this.f1361b.getClass();
        return abstractC0091w.unknownFields.hashCode();
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void d(Object obj) {
        this.f1361b.getClass();
        d0 d0Var = ((AbstractC0091w) obj).unknownFields;
        if (d0Var.f1403e) {
            d0Var.f1403e = false;
        }
        this.f1362c.getClass();
        E0.h.h(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final boolean e(Object obj) {
        this.f1362c.getClass();
        E0.h.h(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final boolean f(AbstractC0091w abstractC0091w, AbstractC0091w abstractC0091w2) {
        this.f1361b.getClass();
        return abstractC0091w.unknownFields.equals(abstractC0091w2.unknownFields);
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void g(Object obj, C0080k c0080k, C0084o c0084o) {
        this.f1361b.getClass();
        e0.a(obj);
        this.f1362c.getClass();
        obj.getClass();
        throw new ClassCastException();
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final int h(AbstractC0091w abstractC0091w) {
        this.f1361b.getClass();
        d0 d0Var = abstractC0091w.unknownFields;
        int i2 = d0Var.f1402d;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int i4 = 0; i4 < d0Var.f1399a; i4++) {
            int i5 = d0Var.f1400b[i4] >>> 3;
            i3 += C0082m.U(3, (C0076g) d0Var.f1401c[i4]) + C0082m.X(i5) + C0082m.W(2) + (C0082m.W(1) * 2);
        }
        d0Var.f1402d = i3;
        return i3;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final AbstractC0091w i() {
        AbstractC0070a abstractC0070a = this.f1360a;
        return abstractC0070a instanceof AbstractC0091w ? ((AbstractC0091w) abstractC0070a).i() : ((AbstractC0089u) ((AbstractC0091w) abstractC0070a).c(5)).b();
    }
}
