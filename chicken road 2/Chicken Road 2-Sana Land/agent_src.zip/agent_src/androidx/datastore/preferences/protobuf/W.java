package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public interface W {
    void a(Object obj, Object obj2);

    void b(Object obj, F f2);

    int c(AbstractC0091w abstractC0091w);

    void d(Object obj);

    boolean e(Object obj);

    boolean f(AbstractC0091w abstractC0091w, AbstractC0091w abstractC0091w2);

    void g(Object obj, C0080k c0080k, C0084o c0084o);

    int h(AbstractC0091w abstractC0091w);

    AbstractC0091w i();
}
