package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class T {

    /* renamed from: c, reason: collision with root package name */
    public static final T f1365c = new T();

    /* renamed from: b, reason: collision with root package name */
    public final ConcurrentHashMap f1367b = new ConcurrentHashMap();

    /* renamed from: a, reason: collision with root package name */
    public final F f1366a = new F();

    public final W a(Class cls) {
        W w2;
        Class cls2;
        AbstractC0093y.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f1367b;
        W w3 = (W) concurrentHashMap.get(cls);
        if (w3 != null) {
            return w3;
        }
        F f2 = this.f1366a;
        f2.getClass();
        Class cls3 = X.f1375a;
        if (!AbstractC0091w.class.isAssignableFrom(cls) && (cls2 = X.f1375a) != null && !cls2.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
        }
        V a2 = ((E) f2.f1334a).a(cls);
        int i2 = a2.f1374d;
        AbstractC0070a abstractC0070a = a2.f1371a;
        if ((i2 & 2) == 2) {
            if (AbstractC0091w.class.isAssignableFrom(cls)) {
                w2 = new O(X.f1377c, AbstractC0086q.f1453a, abstractC0070a);
            } else {
                e0 e0Var = X.f1376b;
                C0085p c0085p = AbstractC0086q.f1454b;
                if (c0085p == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
                w2 = new O(e0Var, c0085p, abstractC0070a);
            }
        } else if (AbstractC0091w.class.isAssignableFrom(cls)) {
            C0085p c0085p2 = null;
            P p2 = Q.f1364b;
            C c2 = D.f1331b;
            e0 e0Var2 = X.f1377c;
            if (F.i.a(a2.a()) != 1) {
                c0085p2 = AbstractC0086q.f1453a;
            }
            C0085p c0085p3 = c0085p2;
            J j2 = K.f1343b;
            int[] iArr = N.f1345n;
            if (!(a2 instanceof V)) {
                a2.getClass();
                throw new ClassCastException();
            }
            w2 = N.w(a2, p2, c2, e0Var2, c0085p3, j2);
        } else {
            C0085p c0085p4 = null;
            P p3 = Q.f1363a;
            C c3 = D.f1330a;
            e0 e0Var3 = X.f1376b;
            if (F.i.a(a2.a()) != 1 && (c0085p4 = AbstractC0086q.f1454b) == null) {
                throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
            }
            C0085p c0085p5 = c0085p4;
            J j3 = K.f1342a;
            int[] iArr2 = N.f1345n;
            if (!(a2 instanceof V)) {
                a2.getClass();
                throw new ClassCastException();
            }
            w2 = N.w(a2, p3, c3, e0Var3, c0085p5, j3);
        }
        W w4 = (W) concurrentHashMap.putIfAbsent(cls, w2);
        return w4 != null ? w4 : w2;
    }
}
