package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* loaded from: classes.dex */
public final class F {

    /* renamed from: b, reason: collision with root package name */
    public static final C0088t f1333b = new C0088t(1);

    /* renamed from: a, reason: collision with root package name */
    public final Object f1334a;

    public F(C0082m c0082m) {
        AbstractC0093y.a(c0082m, "output");
        this.f1334a = c0082m;
        c0082m.f1444i = this;
    }

    public void a(int i2, Object obj, W w2) {
        C0082m c0082m = (C0082m) this.f1334a;
        c0082m.p0(i2, 3);
        w2.b((AbstractC0070a) obj, c0082m.f1444i);
        c0082m.p0(i2, 4);
    }

    public F() {
        L l2;
        T t2 = T.f1365c;
        try {
            l2 = (L) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
            l2 = f1333b;
        }
        L[] lArr = {C0088t.f1480b, l2};
        E e2 = new E();
        e2.f1332a = lArr;
        Charset charset = AbstractC0093y.f1484a;
        this.f1334a = e2;
    }
}
