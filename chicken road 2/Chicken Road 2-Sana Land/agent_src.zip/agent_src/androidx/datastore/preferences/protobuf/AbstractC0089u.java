package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0089u implements Cloneable {

    /* renamed from: e, reason: collision with root package name */
    public final AbstractC0091w f1482e;

    /* renamed from: f, reason: collision with root package name */
    public AbstractC0091w f1483f;

    public AbstractC0089u(AbstractC0091w abstractC0091w) {
        this.f1482e = abstractC0091w;
        if (abstractC0091w.g()) {
            throw new IllegalArgumentException("Default instance must be immutable.");
        }
        this.f1483f = abstractC0091w.i();
    }

    public final AbstractC0091w a() {
        AbstractC0091w b2 = b();
        b2.getClass();
        if (AbstractC0091w.f(b2, true)) {
            return b2;
        }
        throw new c0();
    }

    public final AbstractC0091w b() {
        if (!this.f1483f.g()) {
            return this.f1483f;
        }
        AbstractC0091w abstractC0091w = this.f1483f;
        abstractC0091w.getClass();
        T t2 = T.f1365c;
        t2.getClass();
        t2.a(abstractC0091w.getClass()).d(abstractC0091w);
        abstractC0091w.h();
        return this.f1483f;
    }

    public final void c() {
        if (this.f1483f.g()) {
            return;
        }
        AbstractC0091w i2 = this.f1482e.i();
        AbstractC0091w abstractC0091w = this.f1483f;
        T t2 = T.f1365c;
        t2.getClass();
        t2.a(i2.getClass()).a(i2, abstractC0091w);
        this.f1483f = i2;
    }

    public final Object clone() {
        AbstractC0089u abstractC0089u = (AbstractC0089u) this.f1482e.c(5);
        abstractC0089u.f1483f = b();
        return abstractC0089u;
    }
}
