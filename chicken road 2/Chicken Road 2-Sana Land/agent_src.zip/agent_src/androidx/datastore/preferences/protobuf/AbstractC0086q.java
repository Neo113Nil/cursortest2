package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0086q {

    /* renamed from: a, reason: collision with root package name */
    public static final C0085p f1453a = new C0085p();

    /* renamed from: b, reason: collision with root package name */
    public static final C0085p f1454b;

    static {
        T t2 = T.f1365c;
        C0085p c0085p = null;
        try {
            c0085p = (C0085p) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1454b = c0085p;
    }
}
