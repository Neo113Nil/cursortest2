package androidx.datastore.preferences.protobuf;

import a.AbstractC0068a;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: androidx.datastore.preferences.protobuf.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0082m extends AbstractC0068a {

    /* renamed from: n, reason: collision with root package name */
    public static final Logger f1442n = Logger.getLogger(C0082m.class.getName());

    /* renamed from: o, reason: collision with root package name */
    public static final boolean f1443o = j0.f1434e;

    /* renamed from: i, reason: collision with root package name */
    public F f1444i;

    /* renamed from: j, reason: collision with root package name */
    public final byte[] f1445j;

    /* renamed from: k, reason: collision with root package name */
    public final int f1446k;

    /* renamed from: l, reason: collision with root package name */
    public int f1447l;

    /* renamed from: m, reason: collision with root package name */
    public final D.r0 f1448m;

    public C0082m(D.r0 r0Var, int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("bufferSize must be >= 0");
        }
        int max = Math.max(i2, 20);
        this.f1445j = new byte[max];
        this.f1446k = max;
        this.f1448m = r0Var;
    }

    public static int U(int i2, C0076g c0076g) {
        int W2 = W(i2);
        int size = c0076g.size();
        return X(size) + size + W2;
    }

    public static int V(String str) {
        int length;
        try {
            length = m0.a(str);
        } catch (l0 unused) {
            length = str.getBytes(AbstractC0093y.f1484a).length;
        }
        return X(length) + length;
    }

    public static int W(int i2) {
        return X(i2 << 3);
    }

    public static int X(int i2) {
        return (352 - (Integer.numberOfLeadingZeros(i2) * 9)) >>> 6;
    }

    public static int Y(long j2) {
        return (640 - (Long.numberOfLeadingZeros(j2) * 9)) >>> 6;
    }

    @Override // a.AbstractC0068a
    public final void O(byte[] bArr, int i2, int i3) {
        c0(bArr, i2, i3);
    }

    public final void P(int i2) {
        int i3 = this.f1447l;
        int i4 = i3 + 1;
        this.f1447l = i4;
        byte[] bArr = this.f1445j;
        bArr[i3] = (byte) (i2 & 255);
        int i5 = i3 + 2;
        this.f1447l = i5;
        bArr[i4] = (byte) ((i2 >> 8) & 255);
        int i6 = i3 + 3;
        this.f1447l = i6;
        bArr[i5] = (byte) ((i2 >> 16) & 255);
        this.f1447l = i3 + 4;
        bArr[i6] = (byte) ((i2 >> 24) & 255);
    }

    public final void Q(long j2) {
        int i2 = this.f1447l;
        int i3 = i2 + 1;
        this.f1447l = i3;
        byte[] bArr = this.f1445j;
        bArr[i2] = (byte) (j2 & 255);
        int i4 = i2 + 2;
        this.f1447l = i4;
        bArr[i3] = (byte) ((j2 >> 8) & 255);
        int i5 = i2 + 3;
        this.f1447l = i5;
        bArr[i4] = (byte) ((j2 >> 16) & 255);
        int i6 = i2 + 4;
        this.f1447l = i6;
        bArr[i5] = (byte) (255 & (j2 >> 24));
        int i7 = i2 + 5;
        this.f1447l = i7;
        bArr[i6] = (byte) (((int) (j2 >> 32)) & 255);
        int i8 = i2 + 6;
        this.f1447l = i8;
        bArr[i7] = (byte) (((int) (j2 >> 40)) & 255);
        int i9 = i2 + 7;
        this.f1447l = i9;
        bArr[i8] = (byte) (((int) (j2 >> 48)) & 255);
        this.f1447l = i2 + 8;
        bArr[i9] = (byte) (((int) (j2 >> 56)) & 255);
    }

    public final void R(int i2, int i3) {
        S((i2 << 3) | i3);
    }

    public final void S(int i2) {
        boolean z2 = f1443o;
        byte[] bArr = this.f1445j;
        if (z2) {
            while ((i2 & (-128)) != 0) {
                int i3 = this.f1447l;
                this.f1447l = i3 + 1;
                j0.j(bArr, i3, (byte) ((i2 | 128) & 255));
                i2 >>>= 7;
            }
            int i4 = this.f1447l;
            this.f1447l = i4 + 1;
            j0.j(bArr, i4, (byte) i2);
            return;
        }
        while ((i2 & (-128)) != 0) {
            int i5 = this.f1447l;
            this.f1447l = i5 + 1;
            bArr[i5] = (byte) ((i2 | 128) & 255);
            i2 >>>= 7;
        }
        int i6 = this.f1447l;
        this.f1447l = i6 + 1;
        bArr[i6] = (byte) i2;
    }

    public final void T(long j2) {
        boolean z2 = f1443o;
        byte[] bArr = this.f1445j;
        if (z2) {
            while ((j2 & (-128)) != 0) {
                int i2 = this.f1447l;
                this.f1447l = i2 + 1;
                j0.j(bArr, i2, (byte) ((((int) j2) | 128) & 255));
                j2 >>>= 7;
            }
            int i3 = this.f1447l;
            this.f1447l = i3 + 1;
            j0.j(bArr, i3, (byte) j2);
            return;
        }
        while ((j2 & (-128)) != 0) {
            int i4 = this.f1447l;
            this.f1447l = i4 + 1;
            bArr[i4] = (byte) ((((int) j2) | 128) & 255);
            j2 >>>= 7;
        }
        int i5 = this.f1447l;
        this.f1447l = i5 + 1;
        bArr[i5] = (byte) j2;
    }

    public final void Z() {
        this.f1448m.write(this.f1445j, 0, this.f1447l);
        this.f1447l = 0;
    }

    public final void a0(int i2) {
        if (this.f1446k - this.f1447l < i2) {
            Z();
        }
    }

    public final void b0(byte b2) {
        if (this.f1447l == this.f1446k) {
            Z();
        }
        int i2 = this.f1447l;
        this.f1447l = i2 + 1;
        this.f1445j[i2] = b2;
    }

    public final void c0(byte[] bArr, int i2, int i3) {
        int i4 = this.f1447l;
        int i5 = this.f1446k;
        int i6 = i5 - i4;
        byte[] bArr2 = this.f1445j;
        if (i6 >= i3) {
            System.arraycopy(bArr, i2, bArr2, i4, i3);
            this.f1447l += i3;
            return;
        }
        System.arraycopy(bArr, i2, bArr2, i4, i6);
        int i7 = i2 + i6;
        int i8 = i3 - i6;
        this.f1447l = i5;
        Z();
        if (i8 > i5) {
            this.f1448m.write(bArr, i7, i8);
        } else {
            System.arraycopy(bArr, i7, bArr2, 0, i8);
            this.f1447l = i8;
        }
    }

    public final void d0(int i2, boolean z2) {
        a0(11);
        R(i2, 0);
        byte b2 = z2 ? (byte) 1 : (byte) 0;
        int i3 = this.f1447l;
        this.f1447l = i3 + 1;
        this.f1445j[i3] = b2;
    }

    public final void e0(int i2, C0076g c0076g) {
        p0(i2, 2);
        f0(c0076g);
    }

    public final void f0(C0076g c0076g) {
        r0(c0076g.size());
        O(c0076g.f1410f, c0076g.e(), c0076g.size());
    }

    public final void g0(int i2, int i3) {
        a0(14);
        R(i2, 5);
        P(i3);
    }

    public final void h0(int i2) {
        a0(4);
        P(i2);
    }

    public final void i0(long j2, int i2) {
        a0(18);
        R(i2, 1);
        Q(j2);
    }

    public final void j0(long j2) {
        a0(8);
        Q(j2);
    }

    public final void k0(int i2, int i3) {
        a0(20);
        R(i2, 0);
        if (i3 >= 0) {
            S(i3);
        } else {
            T(i3);
        }
    }

    public final void l0(int i2) {
        if (i2 >= 0) {
            r0(i2);
        } else {
            t0(i2);
        }
    }

    public final void m0(int i2, AbstractC0070a abstractC0070a, W w2) {
        p0(i2, 2);
        r0(abstractC0070a.a(w2));
        w2.b(abstractC0070a, this.f1444i);
    }

    public final void n0(String str, int i2) {
        p0(i2, 2);
        o0(str);
    }

    public final void o0(String str) {
        try {
            int length = str.length() * 3;
            int X2 = X(length);
            int i2 = X2 + length;
            int i3 = this.f1446k;
            if (i2 > i3) {
                byte[] bArr = new byte[length];
                int q2 = m0.f1449a.q(str, bArr, 0, length);
                r0(q2);
                c0(bArr, 0, q2);
                return;
            }
            if (i2 > i3 - this.f1447l) {
                Z();
            }
            int X3 = X(str.length());
            int i4 = this.f1447l;
            byte[] bArr2 = this.f1445j;
            try {
                try {
                    if (X3 == X2) {
                        int i5 = i4 + X3;
                        this.f1447l = i5;
                        int q3 = m0.f1449a.q(str, bArr2, i5, i3 - i5);
                        this.f1447l = i4;
                        S((q3 - i4) - X3);
                        this.f1447l = q3;
                    } else {
                        int a2 = m0.a(str);
                        S(a2);
                        this.f1447l = m0.f1449a.q(str, bArr2, this.f1447l, a2);
                    }
                } catch (ArrayIndexOutOfBoundsException e2) {
                    throw new C0081l(e2);
                }
            } catch (l0 e3) {
                this.f1447l = i4;
                throw e3;
            }
        } catch (l0 e4) {
            f1442n.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e4);
            byte[] bytes = str.getBytes(AbstractC0093y.f1484a);
            try {
                r0(bytes.length);
                O(bytes, 0, bytes.length);
            } catch (IndexOutOfBoundsException e5) {
                throw new C0081l(e5);
            }
        }
    }

    public final void p0(int i2, int i3) {
        r0((i2 << 3) | i3);
    }

    public final void q0(int i2, int i3) {
        a0(20);
        R(i2, 0);
        S(i3);
    }

    public final void r0(int i2) {
        a0(5);
        S(i2);
    }

    public final void s0(long j2, int i2) {
        a0(20);
        R(i2, 0);
        T(j2);
    }

    public final void t0(long j2) {
        a0(10);
        T(j2);
    }
}
