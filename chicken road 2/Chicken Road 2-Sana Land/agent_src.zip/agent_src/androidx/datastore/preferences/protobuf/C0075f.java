package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0075f extends C0076g {

    /* renamed from: i, reason: collision with root package name */
    public final int f1405i;

    /* renamed from: j, reason: collision with root package name */
    public final int f1406j;

    public C0075f(byte[] bArr, int i2, int i3) {
        super(bArr);
        C0076g.b(i2, i2 + i3, bArr.length);
        this.f1405i = i2;
        this.f1406j = i3;
    }

    @Override // androidx.datastore.preferences.protobuf.C0076g
    public final byte a(int i2) {
        int i3 = this.f1406j;
        if (((i3 - (i2 + 1)) | i2) >= 0) {
            return this.f1410f[this.f1405i + i2];
        }
        if (i2 < 0) {
            throw new ArrayIndexOutOfBoundsException(E0.h.e("Index < 0: ", i2));
        }
        throw new ArrayIndexOutOfBoundsException(E0.h.f("Index > length: ", i2, ", ", i3));
    }

    @Override // androidx.datastore.preferences.protobuf.C0076g
    public final void d(byte[] bArr, int i2) {
        System.arraycopy(this.f1410f, this.f1405i, bArr, 0, i2);
    }

    @Override // androidx.datastore.preferences.protobuf.C0076g
    public final int e() {
        return this.f1405i;
    }

    @Override // androidx.datastore.preferences.protobuf.C0076g
    public final byte f(int i2) {
        return this.f1410f[this.f1405i + i2];
    }

    @Override // androidx.datastore.preferences.protobuf.C0076g
    public final int size() {
        return this.f1406j;
    }
}
