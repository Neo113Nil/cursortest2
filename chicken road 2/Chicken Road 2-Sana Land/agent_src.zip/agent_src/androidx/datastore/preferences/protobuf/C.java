package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class C {
    public static InterfaceC0092x a(long j2, Object obj) {
        InterfaceC0092x interfaceC0092x = (InterfaceC0092x) j0.f1432c.h(j2, obj);
        if (((AbstractC0071b) interfaceC0092x).f1391e) {
            return interfaceC0092x;
        }
        U u2 = (U) interfaceC0092x;
        int i2 = u2.f1370g;
        U c2 = u2.c(i2 == 0 ? 10 : i2 * 2);
        j0.o(obj, j2, c2);
        return c2;
    }
}
