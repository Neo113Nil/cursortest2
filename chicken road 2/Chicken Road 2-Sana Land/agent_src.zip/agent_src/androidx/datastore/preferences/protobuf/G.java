package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: a, reason: collision with root package name */
    public final r0 f1335a;

    /* renamed from: b, reason: collision with root package name */
    public final r0 f1336b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f1337c;

    public G(r0 r0Var, r0 r0Var2, Object obj) {
        this.f1335a = r0Var;
        this.f1336b = r0Var2;
        this.f1337c = obj;
    }
}
