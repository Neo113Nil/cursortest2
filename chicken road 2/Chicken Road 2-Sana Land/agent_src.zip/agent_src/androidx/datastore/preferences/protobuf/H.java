package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class H {

    /* renamed from: a, reason: collision with root package name */
    public final G f1338a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f1339b;

    public H(r0 r0Var, r0 r0Var2, F.j jVar) {
        this.f1338a = new G(r0Var, r0Var2, jVar);
        this.f1339b = jVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0141  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x014e  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0174  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0181  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x018a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x01a0  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x01a6  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x01b2  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x01be  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x01c9  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x01d4  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x01db  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int a(G g2, Object obj, Object obj2) {
        int Y2;
        int size;
        int X2;
        r0 r0Var;
        int size2;
        int X3;
        r0 r0Var2 = g2.f1335a;
        int i2 = r.f1455c;
        int i3 = 1;
        int W2 = C0082m.W(1);
        o0 o0Var = r0.f1459h;
        if (r0Var2 == o0Var) {
            W2 *= 2;
        }
        switch (r0Var2.ordinal()) {
            case 0:
                ((Double) obj).getClass();
                Y2 = 8;
                int i4 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3 = C0082m.W(2);
                if (r0Var == o0Var) {
                    W3 *= 2;
                }
                switch (r0Var.ordinal()) {
                    case 0:
                        ((Double) obj2).getClass();
                        i3 = 8;
                        return i3 + W3 + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        i3 = 4;
                        return i3 + W3 + i4;
                    case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                        i3 = C0082m.Y(((Long) obj2).longValue());
                        return i3 + W3 + i4;
                    case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                        i3 = C0082m.Y(((Long) obj2).longValue());
                        return i3 + W3 + i4;
                    case F.j.LONG_FIELD_NUMBER /* 4 */:
                        i3 = C0082m.Y(((Integer) obj2).intValue());
                        return i3 + W3 + i4;
                    case F.j.STRING_FIELD_NUMBER /* 5 */:
                        ((Long) obj2).getClass();
                        i3 = 8;
                        return i3 + W3 + i4;
                    case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                        ((Integer) obj2).getClass();
                        i3 = 4;
                        return i3 + W3 + i4;
                    case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return i3 + W3 + i4;
                    case F.j.BYTES_FIELD_NUMBER /* 8 */:
                        if (!(obj2 instanceof C0076g)) {
                            i3 = C0082m.V((String) obj2);
                            return i3 + W3 + i4;
                        }
                        size2 = ((C0076g) obj2).size();
                        X3 = C0082m.X(size2);
                        i3 = X3 + size2;
                        return i3 + W3 + i4;
                    case 9:
                        i3 = ((AbstractC0091w) ((AbstractC0070a) obj2)).a(null);
                        return i3 + W3 + i4;
                    case 10:
                        size2 = ((AbstractC0091w) ((AbstractC0070a) obj2)).a(null);
                        X3 = C0082m.X(size2);
                        i3 = X3 + size2;
                        return i3 + W3 + i4;
                    case 11:
                        if (obj2 instanceof C0076g) {
                            size2 = ((C0076g) obj2).size();
                            X3 = C0082m.X(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            X3 = C0082m.X(size2);
                        }
                        i3 = X3 + size2;
                        return i3 + W3 + i4;
                    case 12:
                        i3 = C0082m.X(((Integer) obj2).intValue());
                        return i3 + W3 + i4;
                    case 13:
                        i3 = C0082m.Y(((Integer) obj2).intValue());
                        return i3 + W3 + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        i3 = 4;
                        return i3 + W3 + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        i3 = 8;
                        return i3 + W3 + i4;
                    case 16:
                        int intValue = ((Integer) obj2).intValue();
                        i3 = C0082m.X((intValue >> 31) ^ (intValue << 1));
                        return i3 + W3 + i4;
                    case 17:
                        long longValue = ((Long) obj2).longValue();
                        i3 = C0082m.Y((longValue >> 63) ^ (longValue << 1));
                        return i3 + W3 + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 1:
                ((Float) obj).getClass();
                Y2 = 4;
                int i42 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                Y2 = C0082m.Y(((Long) obj).longValue());
                int i422 = Y2 + W2;
                r0Var = g2.f1336b;
                int W322 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                Y2 = C0082m.Y(((Long) obj).longValue());
                int i4222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                Y2 = C0082m.Y(((Integer) obj).intValue());
                int i42222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                ((Long) obj).getClass();
                Y2 = 8;
                int i422222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W322222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                ((Integer) obj).getClass();
                Y2 = 4;
                int i4222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                ((Boolean) obj).getClass();
                Y2 = 1;
                int i42222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                if (obj instanceof C0076g) {
                    size = ((C0076g) obj).size();
                    X2 = C0082m.X(size);
                    Y2 = size + X2;
                    int i422222222 = Y2 + W2;
                    r0Var = g2.f1336b;
                    int W322222222 = C0082m.W(2);
                    if (r0Var == o0Var) {
                    }
                    switch (r0Var.ordinal()) {
                    }
                } else {
                    Y2 = C0082m.V((String) obj);
                    int i4222222222 = Y2 + W2;
                    r0Var = g2.f1336b;
                    int W3222222222 = C0082m.W(2);
                    if (r0Var == o0Var) {
                    }
                    switch (r0Var.ordinal()) {
                    }
                }
            case 9:
                Y2 = ((AbstractC0091w) ((AbstractC0070a) obj)).a(null);
                int i42222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 10:
                size = ((AbstractC0091w) ((AbstractC0070a) obj)).a(null);
                X2 = C0082m.X(size);
                Y2 = size + X2;
                int i422222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W322222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 11:
                if (obj instanceof C0076g) {
                    size = ((C0076g) obj).size();
                    X2 = C0082m.X(size);
                } else {
                    size = ((byte[]) obj).length;
                    X2 = C0082m.X(size);
                }
                Y2 = size + X2;
                int i4222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 12:
                Y2 = C0082m.X(((Integer) obj).intValue());
                int i42222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 13:
                Y2 = C0082m.Y(((Integer) obj).intValue());
                int i422222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W322222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 14:
                ((Integer) obj).getClass();
                Y2 = 4;
                int i4222222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3222222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 15:
                ((Long) obj).getClass();
                Y2 = 8;
                int i42222222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W32222222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 16:
                int intValue2 = ((Integer) obj).intValue();
                Y2 = C0082m.X((intValue2 >> 31) ^ (intValue2 << 1));
                int i422222222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W322222222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            case 17:
                long longValue2 = ((Long) obj).longValue();
                Y2 = C0082m.Y((longValue2 >> 63) ^ (longValue2 << 1));
                int i4222222222222222222 = Y2 + W2;
                r0Var = g2.f1336b;
                int W3222222222222222222 = C0082m.W(2);
                if (r0Var == o0Var) {
                }
                switch (r0Var.ordinal()) {
                }
            default:
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
        }
    }
}
