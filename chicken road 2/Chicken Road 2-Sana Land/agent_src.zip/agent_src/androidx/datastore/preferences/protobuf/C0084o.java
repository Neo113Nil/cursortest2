package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Map;

/* renamed from: androidx.datastore.preferences.protobuf.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0084o {

    /* renamed from: a, reason: collision with root package name */
    public static volatile C0084o f1451a;

    /* renamed from: b, reason: collision with root package name */
    public static final C0084o f1452b;

    static {
        C0084o c0084o = new C0084o();
        Map map = Collections.EMPTY_MAP;
        f1452b = c0084o;
    }

    public static C0084o a() {
        C0084o c0084o;
        T t2 = T.f1365c;
        C0084o c0084o2 = f1451a;
        if (c0084o2 != null) {
            return c0084o2;
        }
        synchronized (C0084o.class) {
            try {
                c0084o = f1451a;
                if (c0084o == null) {
                    Class cls = AbstractC0083n.f1450a;
                    C0084o c0084o3 = null;
                    if (cls != null) {
                        try {
                            c0084o3 = (C0084o) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                        } catch (Exception unused) {
                        }
                    }
                    c0084o = c0084o3 != null ? c0084o3 : f1452b;
                    f1451a = c0084o;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return c0084o;
    }
}
