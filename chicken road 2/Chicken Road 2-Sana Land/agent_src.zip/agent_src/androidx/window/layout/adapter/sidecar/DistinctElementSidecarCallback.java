package androidx.window.layout.adapter.sidecar;

import E0.i;
import X.b;
import X.g;
import android.os.IBinder;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarInterface;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class DistinctElementSidecarCallback implements SidecarInterface.SidecarCallback {

    /* renamed from: b, reason: collision with root package name */
    public SidecarDeviceState f1606b;

    /* renamed from: d, reason: collision with root package name */
    public final g f1608d;

    /* renamed from: e, reason: collision with root package name */
    public final SidecarInterface.SidecarCallback f1609e;

    /* renamed from: a, reason: collision with root package name */
    public final Object f1605a = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final WeakHashMap f1607c = new WeakHashMap();

    public DistinctElementSidecarCallback(g gVar, SidecarInterface.SidecarCallback sidecarCallback) {
        this.f1608d = gVar;
        this.f1609e = sidecarCallback;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x001f, code lost:
    
        if (X.b.b(r2) == X.b.b(r4)) goto L13;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onDeviceStateChanged(SidecarDeviceState sidecarDeviceState) {
        if (sidecarDeviceState == null) {
            return;
        }
        synchronized (this.f1605a) {
            try {
                g gVar = this.f1608d;
                SidecarDeviceState sidecarDeviceState2 = this.f1606b;
                gVar.getClass();
                if (!i.a(sidecarDeviceState2, sidecarDeviceState)) {
                    if (sidecarDeviceState2 == null) {
                    }
                    this.f1606b = sidecarDeviceState;
                    this.f1609e.onDeviceStateChanged(sidecarDeviceState);
                }
            } finally {
            }
        }
    }

    public void onWindowLayoutChanged(IBinder iBinder, SidecarWindowLayoutInfo sidecarWindowLayoutInfo) {
        boolean b2;
        synchronized (this.f1605a) {
            try {
                SidecarWindowLayoutInfo sidecarWindowLayoutInfo2 = (SidecarWindowLayoutInfo) this.f1607c.get(iBinder);
                this.f1608d.getClass();
                if (i.a(sidecarWindowLayoutInfo2, sidecarWindowLayoutInfo)) {
                    b2 = true;
                } else {
                    if (sidecarWindowLayoutInfo2 != null && sidecarWindowLayoutInfo != null) {
                        b2 = g.b(b.c(sidecarWindowLayoutInfo2), b.c(sidecarWindowLayoutInfo));
                    }
                    b2 = false;
                }
                if (b2) {
                    return;
                }
                this.f1607c.put(iBinder, sidecarWindowLayoutInfo);
                this.f1609e.onWindowLayoutChanged(iBinder, sidecarWindowLayoutInfo);
            } finally {
            }
        }
    }
}
