package K0;

import E0.i;
import J0.A;
import J0.AbstractC0041q;
import J0.InterfaceC0047x;
import J0.N;
import J0.r;
import O0.o;
import Q0.e;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.CancellationException;
import w0.h;

/* loaded from: classes.dex */
public final class c extends AbstractC0041q implements InterfaceC0047x {

    /* renamed from: g, reason: collision with root package name */
    public final Handler f525g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f526h;

    /* renamed from: i, reason: collision with root package name */
    public final c f527i;

    public c(Handler handler, boolean z2) {
        this.f525g = handler;
        this.f526h = z2;
        this.f527i = z2 ? this : new c(handler, true);
    }

    @Override // J0.AbstractC0041q
    public final void c(h hVar, Runnable runnable) {
        if (this.f525g.post(runnable)) {
            return;
        }
        CancellationException cancellationException = new CancellationException("The task was rejected, the handler underlying the dispatcher '" + this + "' was closed");
        N n2 = (N) hVar.h(r.f506f);
        if (n2 != null) {
            n2.b(cancellationException);
        }
        e eVar = A.f445a;
        Q0.d.f915g.c(hVar, runnable);
    }

    @Override // J0.AbstractC0041q
    public final boolean d(h hVar) {
        return (this.f526h && i.a(Looper.myLooper(), this.f525g.getLooper())) ? false : true;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return cVar.f525g == this.f525g && cVar.f526h == this.f526h;
    }

    public final int hashCode() {
        return System.identityHashCode(this.f525g) ^ (this.f526h ? 1231 : 1237);
    }

    @Override // J0.AbstractC0041q
    public final String toString() {
        c cVar;
        String str;
        e eVar = A.f445a;
        c cVar2 = o.f865a;
        if (this == cVar2) {
            str = "Dispatchers.Main";
        } else {
            try {
                cVar = cVar2.f527i;
            } catch (UnsupportedOperationException unused) {
                cVar = null;
            }
            str = this == cVar ? "Dispatchers.Main.immediate" : null;
        }
        if (str != null) {
            return str;
        }
        String handler = this.f525g.toString();
        if (!this.f526h) {
            return handler;
        }
        return handler + ".immediate";
    }
}
