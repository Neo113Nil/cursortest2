package Q;

import E0.i;
import E0.j;
import R.h;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigInteger;

/* loaded from: classes.dex */
public final class a extends j implements D0.a {

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f886f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f887g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(int i2, Object obj) {
        super(0);
        this.f886f = i2;
        this.f887g = obj;
    }

    @Override // D0.a
    public final Object b() {
        switch (this.f886f) {
            case 0:
                b bVar = (b) this.f887g;
                Class<?> loadClass = bVar.f888a.loadClass("androidx.window.extensions.WindowExtensionsProvider");
                i.d(loadClass, "loader.loadClass(WindowE…XTENSIONS_PROVIDER_CLASS)");
                Method declaredMethod = loadClass.getDeclaredMethod("getWindowExtensions", null);
                Class<?> loadClass2 = bVar.f888a.loadClass("androidx.window.extensions.WindowExtensions");
                i.d(loadClass2, "loader.loadClass(WindowE….WINDOW_EXTENSIONS_CLASS)");
                i.d(declaredMethod, "getWindowExtensionsMethod");
                return Boolean.valueOf(declaredMethod.getReturnType().equals(loadClass2) && Modifier.isPublic(declaredMethod.getModifiers()));
            default:
                h hVar = (h) this.f887g;
                return BigInteger.valueOf(hVar.f953e).shiftLeft(32).or(BigInteger.valueOf(hVar.f954f)).shiftLeft(32).or(BigInteger.valueOf(hVar.f955g));
        }
    }
}
