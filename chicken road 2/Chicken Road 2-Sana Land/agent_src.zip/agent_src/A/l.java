package A;

import L.C0065p;
import L.M;
import L.N;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.versionedparcelable.ParcelImpl;

/* loaded from: classes.dex */
public final class l implements Parcelable.Creator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f31a;

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f31a) {
            case 0:
                m mVar = new m(parcel);
                mVar.f32e = parcel.readInt();
                return mVar;
            case 1:
                C0065p c0065p = new C0065p();
                c0065p.f648e = parcel.readInt();
                c0065p.f649f = parcel.readInt();
                c0065p.f650g = parcel.readInt() == 1;
                return c0065p;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                M m2 = new M();
                m2.f551e = parcel.readInt();
                m2.f552f = parcel.readInt();
                m2.f554h = parcel.readInt() == 1;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    m2.f553g = iArr;
                    parcel.readIntArray(iArr);
                }
                return m2;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                N n2 = new N();
                n2.f555e = parcel.readInt();
                n2.f556f = parcel.readInt();
                int readInt2 = parcel.readInt();
                n2.f557g = readInt2;
                if (readInt2 > 0) {
                    int[] iArr2 = new int[readInt2];
                    n2.f558h = iArr2;
                    parcel.readIntArray(iArr2);
                }
                int readInt3 = parcel.readInt();
                n2.f559i = readInt3;
                if (readInt3 > 0) {
                    int[] iArr3 = new int[readInt3];
                    n2.f560j = iArr3;
                    parcel.readIntArray(iArr3);
                }
                n2.f562l = parcel.readInt() == 1;
                n2.f563m = parcel.readInt() == 1;
                n2.f564n = parcel.readInt() == 1;
                n2.f561k = parcel.readArrayList(M.class.getClassLoader());
                return n2;
            default:
                return new ParcelImpl(parcel);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i2) {
        switch (this.f31a) {
            case 0:
                return new m[i2];
            case 1:
                return new C0065p[i2];
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                return new M[i2];
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                return new N[i2];
            default:
                return new ParcelImpl[i2];
        }
    }
}
