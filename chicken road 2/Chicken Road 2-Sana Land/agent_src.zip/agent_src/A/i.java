package A;

import android.view.ViewGroup;

/* loaded from: classes.dex */
public abstract class i {
    public static boolean a(ViewGroup viewGroup) {
        return viewGroup.getClipToPadding();
    }
}
