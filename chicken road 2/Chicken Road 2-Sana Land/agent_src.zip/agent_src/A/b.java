package A;

import L.C0053d;
import L.C0057h;
import L.v;
import android.animation.ValueAnimator;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.animation.AnimationUtils;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import h.AbstractC0153A;
import h.C0168i;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import l0.C0206d;
import w.x;

/* loaded from: classes.dex */
public final class b implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f9e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f10f;

    public /* synthetic */ b(int i2, Object obj) {
        this.f9e = i2;
        this.f10f = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0168i c0168i;
        int i2 = this.f9e;
        Object obj = this.f10f;
        switch (i2) {
            case 0:
                g gVar = (g) obj;
                AbstractC0153A abstractC0153A = gVar.f14c;
                a aVar = gVar.f12a;
                if (gVar.f26o) {
                    if (gVar.f24m) {
                        gVar.f24m = false;
                        long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                        aVar.f4e = currentAnimationTimeMillis;
                        aVar.f6g = -1L;
                        aVar.f5f = currentAnimationTimeMillis;
                        aVar.f7h = 0.5f;
                    }
                    if ((aVar.f6g > 0 && AnimationUtils.currentAnimationTimeMillis() > aVar.f6g + aVar.f8i) || !gVar.e()) {
                        gVar.f26o = false;
                        return;
                    }
                    if (gVar.f25n) {
                        gVar.f25n = false;
                        long uptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                        abstractC0153A.onTouchEvent(obtain);
                        obtain.recycle();
                    }
                    if (aVar.f5f == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long currentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                    float a2 = aVar.a(currentAnimationTimeMillis2);
                    long j2 = currentAnimationTimeMillis2 - aVar.f5f;
                    aVar.f5f = currentAnimationTimeMillis2;
                    gVar.f28q.scrollListBy((int) (j2 * ((a2 * 4.0f) + ((-4.0f) * a2 * a2)) * aVar.f3d));
                    Field field = x.f3034a;
                    abstractC0153A.postOnAnimation(this);
                    return;
                }
                return;
            case 1:
                C0057h c0057h = (C0057h) obj;
                ValueAnimator valueAnimator = c0057h.f623u;
                int i3 = c0057h.f624v;
                if (i3 == 1) {
                    valueAnimator.cancel();
                } else if (i3 != 2) {
                    return;
                }
                c0057h.f624v = 3;
                valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
                valueAnimator.setDuration(500);
                valueAnimator.start();
                return;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                v vVar = ((RecyclerView) obj).f1548H;
                if (vVar != null) {
                    C0053d c0053d = (C0053d) vVar;
                    ArrayList arrayList = c0053d.f588e;
                    ArrayList arrayList2 = c0053d.f592i;
                    ArrayList arrayList3 = c0053d.f594k;
                    ArrayList arrayList4 = c0053d.f593j;
                    boolean isEmpty = arrayList.isEmpty();
                    ArrayList arrayList5 = c0053d.f590g;
                    boolean isEmpty2 = arrayList5.isEmpty();
                    ArrayList arrayList6 = c0053d.f591h;
                    boolean isEmpty3 = arrayList6.isEmpty();
                    ArrayList arrayList7 = c0053d.f589f;
                    boolean isEmpty4 = arrayList7.isEmpty();
                    if (isEmpty && isEmpty2 && isEmpty4 && isEmpty3) {
                        return;
                    }
                    Iterator it = arrayList.iterator();
                    if (it.hasNext()) {
                        it.next().getClass();
                        throw new ClassCastException();
                    }
                    arrayList.clear();
                    if (!isEmpty2) {
                        ArrayList arrayList8 = new ArrayList();
                        arrayList8.addAll(arrayList5);
                        arrayList4.add(arrayList8);
                        arrayList5.clear();
                        if (!isEmpty) {
                            E0.h.h(arrayList8.get(0));
                            throw null;
                        }
                        Iterator it2 = arrayList8.iterator();
                        if (it2.hasNext()) {
                            E0.h.h(it2.next());
                            throw null;
                        }
                        arrayList8.clear();
                        arrayList4.remove(arrayList8);
                    }
                    if (!isEmpty3) {
                        ArrayList arrayList9 = new ArrayList();
                        arrayList9.addAll(arrayList6);
                        arrayList3.add(arrayList9);
                        arrayList6.clear();
                        if (!isEmpty) {
                            E0.h.h(arrayList9.get(0));
                            throw null;
                        }
                        if (arrayList9.size() > 0) {
                            E0.h.h(arrayList9.get(0));
                            throw null;
                        }
                        arrayList9.clear();
                        arrayList3.remove(arrayList9);
                    }
                    if (isEmpty4) {
                        return;
                    }
                    ArrayList arrayList10 = new ArrayList();
                    arrayList10.addAll(arrayList7);
                    arrayList2.add(arrayList10);
                    arrayList7.clear();
                    if (!isEmpty || !isEmpty2 || !isEmpty3) {
                        Math.max(!isEmpty2 ? c0053d.f655c : 0L, isEmpty3 ? 0L : c0053d.f656d);
                        arrayList10.get(0).getClass();
                        throw new ClassCastException();
                    }
                    Iterator it3 = arrayList10.iterator();
                    if (it3.hasNext()) {
                        it3.next().getClass();
                        throw new ClassCastException();
                    }
                    arrayList10.clear();
                    arrayList2.remove(arrayList10);
                    return;
                }
                return;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                ((StaggeredGridLayoutManager) obj).J();
                return;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                AbstractC0153A abstractC0153A2 = (AbstractC0153A) obj;
                abstractC0153A2.f2039q = null;
                abstractC0153A2.drawableStateChanged();
                return;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                ActionMenuView actionMenuView = ((Toolbar) obj).f1243e;
                if (actionMenuView == null || (c0168i = actionMenuView.f1133w) == null) {
                    return;
                }
                c0168i.j();
                return;
            default:
                Object obj2 = ((C0206d) obj).f2662f;
                return;
        }
    }

    public b(C0206d c0206d, int i2) {
        this.f9e = 6;
        this.f10f = c0206d;
    }
}
