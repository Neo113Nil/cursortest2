package A;

import A.j;
import D.C0003d;
import D.C0021w;
import D.InterfaceC0008i;
import D.e0;
import D.g0;
import D.h0;
import D.p0;
import D.q0;
import J0.C0039o;
import L.C0051b;
import L.Q;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.profileinstaller.ProfileInstallReceiver;
import d0.C0121i;
import d0.C0122j;
import d0.C0123k;
import e0.C0135i;
import g.C0148f;
import g.RunnableC0147e;
import g.ViewOnKeyListenerC0149g;
import g.t;
import h.C0168i;
import h.C0177s;
import h.InterfaceC0171l;
import h.K;
import io.flutter.embedding.engine.FlutterJNI;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import l0.C0206d;
import l0.C0210h;
import l0.C0211i;
import l0.C0213k;
import l0.EnumC0207e;
import l0.EnumC0209g;
import l0.InterfaceC0212j;
import m0.AbstractC0230j;
import m0.C0229i;
import m0.C0236p;
import m0.InterfaceC0222b;
import m0.InterfaceC0224d;
import m0.InterfaceC0225e;
import m0.InterfaceC0226f;
import m0.InterfaceC0232l;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class j implements M0.d, InterfaceC0008i, J.e, InterfaceC0226f, K, g.o, InterfaceC0171l, InterfaceC0212j, InterfaceC0222b, InterfaceC0232l {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f29e;

    /* renamed from: f, reason: collision with root package name */
    public Object f30f;

    public /* synthetic */ j(int i2, Object obj) {
        this.f29e = i2;
        this.f30f = obj;
    }

    public static int B(int i2, int i3) {
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < i2; i6++) {
            i4++;
            if (i4 == i3) {
                i5++;
                i4 = 0;
            } else if (i4 > i3) {
                i5++;
                i4 = 1;
            }
        }
        return i4 + 1 > i3 ? i5 + 1 : i5;
    }

    public static boolean C(int i2) {
        return (48 <= i2 && i2 <= 57) || i2 == 35 || i2 == 42;
    }

    public p0 A() {
        M0.q qVar = (M0.q) this.f30f;
        qVar.getClass();
        Object obj = M0.q.f785i.get(qVar);
        if (obj == N0.k.f812a) {
            obj = null;
        }
        return (p0) obj;
    }

    public void D(ArrayList arrayList) {
        io.flutter.plugin.platform.e eVar = (io.flutter.plugin.platform.e) this.f30f;
        int i2 = arrayList.isEmpty() ? 5894 : 1798;
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            int ordinal = ((EnumC0209g) arrayList.get(i3)).ordinal();
            if (ordinal == 0) {
                i2 &= -5;
            } else if (ordinal == 1) {
                i2 &= -515;
            }
        }
        eVar.f2423e = i2;
        eVar.b();
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0032, code lost:
    
        if (r7.f245a > ((D.C0003d) r3).f245a) goto L25;
     */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void E(p0 p0Var) {
        Object obj;
        Object obj2;
        E0.i.e(p0Var, "newState");
        M0.q qVar = (M0.q) this.f30f;
        do {
            qVar.getClass();
            Object obj3 = M0.q.f785i.get(qVar);
            obj = N0.k.f812a;
            obj2 = obj3;
            if (obj3 == obj) {
                obj2 = null;
            }
            Object obj4 = (p0) obj2;
            if (!(obj4 instanceof h0) && !E0.i.a(obj4, q0.f250b)) {
                if (!(obj4 instanceof C0003d)) {
                    if (!(obj4 instanceof e0)) {
                        if (!(obj4 instanceof g0)) {
                            throw new C0039o();
                        }
                        throw new IllegalStateException("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                    }
                }
                if (obj2 == null) {
                    obj2 = obj;
                }
                if (obj4 != null) {
                    obj = obj4;
                }
            }
            obj4 = p0Var;
            if (obj2 == null) {
            }
            if (obj4 != null) {
            }
        } while (!qVar.a(obj2, obj));
    }

    public void F(int i2) {
        View decorView = ((io.flutter.plugin.platform.e) this.f30f).f2419a.getWindow().getDecorView();
        switch (F.i.a(i2)) {
            case 0:
                decorView.performHapticFeedback(0);
                break;
            case 1:
                decorView.performHapticFeedback(1);
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                decorView.performHapticFeedback(3);
                break;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                decorView.performHapticFeedback(6);
                break;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                decorView.performHapticFeedback(4);
                break;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                if (Build.VERSION.SDK_INT >= 30) {
                    decorView.performHapticFeedback(16);
                    break;
                }
                break;
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                if (Build.VERSION.SDK_INT >= 30) {
                    decorView.performHapticFeedback(3);
                    break;
                }
                break;
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                if (Build.VERSION.SDK_INT >= 30) {
                    decorView.performHapticFeedback(17);
                    break;
                }
                break;
        }
    }

    @Override // g.o
    public void a(g.j jVar, boolean z2) {
        if (jVar instanceof t) {
            ((t) jVar).f2015v.j().c(false);
        }
        g.o oVar = ((C0168i) this.f30f).f2165i;
        if (oVar != null) {
            oVar.a(jVar, z2);
        }
    }

    @Override // l0.InterfaceC0212j
    public long b(C0177s c0177s) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        io.flutter.plugin.platform.k.b(kVar, c0177s);
        int i2 = c0177s.f2233a;
        if (kVar.r.get(i2) != null) {
            throw new IllegalStateException(E0.h.e("Trying to create an already created platform view, view id: ", i2));
        }
        if (kVar.f2441i == null) {
            throw new IllegalStateException(E0.h.e("Texture registry is null. This means that platform views controller was detached, view id: ", i2));
        }
        if (kVar.f2439g == null) {
            throw new IllegalStateException(E0.h.e("Flutter view is null. This means the platform views controller doesn't have an attached view, view id: ", i2));
        }
        C0121i c0121i = kVar.f2437e;
        String str = (String) c0177s.f2235c;
        if (c0121i.f1807a.get(str) == null) {
            throw new IllegalStateException(E0.h.g("Trying to create a platform view of unregistered type: ", str));
        }
        throw new ClassCastException();
    }

    @Override // l0.InterfaceC0212j
    public void c(boolean z2) {
        ((io.flutter.plugin.platform.k) this.f30f).f2452u = z2;
    }

    @Override // D.InterfaceC0008i
    public Object d(D0.p pVar, y0.g gVar) {
        return ((InterfaceC0008i) this.f30f).d(new G.b(pVar, null), gVar);
    }

    @Override // l0.InterfaceC0212j
    public void e(int i2, double d2, double d3) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        if (kVar.d(i2)) {
            return;
        }
        Log.e("PlatformViewsController", "Setting offset for unknown platform view with id: " + i2);
    }

    @Override // l0.InterfaceC0212j
    public void f(int i2, int i3) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        if (i3 != 0 && i3 != 1) {
            throw new IllegalStateException("Trying to set unknown direction value: " + i3 + "(view id: " + i2 + ")");
        }
        if (kVar.d(i2)) {
            ((io.flutter.plugin.platform.q) kVar.f2445m.get(Integer.valueOf(i2))).getClass();
            Log.e("PlatformViewsController", "Setting direction to a null view with id: " + i2);
            return;
        }
        if (kVar.f2447o.get(i2) != null) {
            throw new ClassCastException();
        }
        Log.e("PlatformViewsController", "Setting direction to an unknown view with id: " + i2);
    }

    @Override // h.K
    public void g(g.j jVar, g.k kVar) {
        ViewOnKeyListenerC0149g viewOnKeyListenerC0149g = (ViewOnKeyListenerC0149g) this.f30f;
        Handler handler = viewOnKeyListenerC0149g.f1915j;
        handler.removeCallbacksAndMessages(null);
        ArrayList arrayList = viewOnKeyListenerC0149g.f1917l;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (jVar == ((C0148f) arrayList.get(i2)).f1905b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 == -1) {
            return;
        }
        int i3 = i2 + 1;
        handler.postAtTime(new RunnableC0147e(this, i3 < arrayList.size() ? (C0148f) arrayList.get(i3) : null, kVar, jVar), jVar, SystemClock.uptimeMillis() + 200);
    }

    @Override // h.K
    public void h(g.j jVar, MenuItem menuItem) {
        ((ViewOnKeyListenerC0149g) this.f30f).f1915j.removeCallbacksAndMessages(jVar);
    }

    @Override // l0.InterfaceC0212j
    public void i(C0211i c0211i, C0122j c0122j) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        int h2 = kVar.h(c0211i.f2693b);
        int h3 = kVar.h(c0211i.f2694c);
        int i2 = c0211i.f2692a;
        if (!kVar.d(i2)) {
            if (kVar.f2447o.get(i2) != null) {
                throw new ClassCastException();
            }
            Log.e("PlatformViewsController", "Resizing unknown platform view with id: " + i2);
            return;
        }
        float f2 = kVar.f2438f.getResources().getDisplayMetrics().density;
        io.flutter.plugin.platform.q qVar = (io.flutter.plugin.platform.q) kVar.f2445m.get(Integer.valueOf(i2));
        io.flutter.plugin.editing.l lVar = kVar.f2442j;
        if (lVar != null) {
            if (lVar.f2401e.f641b == 3) {
                lVar.f2412p = true;
            }
            qVar.getClass();
        }
        qVar.getClass();
        if (h2 == 0 && h3 == 0) {
            throw null;
        }
        if (Build.VERSION.SDK_INT < 31) {
            throw null;
        }
        throw null;
    }

    @Override // m0.InterfaceC0226f
    public void j(String str, InterfaceC0224d interfaceC0224d, E.a aVar) {
        ((C0135i) this.f30f).j(str, interfaceC0224d, aVar);
    }

    @Override // l0.InterfaceC0212j
    public void k(C0210h c0210h) {
        int i2 = c0210h.f2676a;
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        float f2 = kVar.f2438f.getResources().getDisplayMetrics().density;
        if (!kVar.d(i2)) {
            if (kVar.f2447o.get(i2) != null) {
                throw new ClassCastException();
            }
            Log.e("PlatformViewsController", "Sending touch to an unknown view with id: " + i2);
            return;
        }
        io.flutter.plugin.platform.q qVar = (io.flutter.plugin.platform.q) kVar.f2445m.get(Integer.valueOf(i2));
        long j2 = c0210h.f2691p;
        int i3 = c0210h.f2680e;
        Q q2 = kVar.f2455x;
        q2.getClass();
        LongSparseArray longSparseArray = (LongSparseArray) q2.f578f;
        PriorityQueue priorityQueue = (PriorityQueue) q2.f579g;
        while (!priorityQueue.isEmpty() && ((Long) priorityQueue.peek()).longValue() < j2) {
            longSparseArray.remove(((Long) priorityQueue.poll()).longValue());
        }
        if (!priorityQueue.isEmpty() && ((Long) priorityQueue.peek()).longValue() == j2) {
            priorityQueue.poll();
        }
        longSparseArray.remove(j2);
        List<List> list = (List) c0210h.f2682g;
        ArrayList arrayList = new ArrayList();
        for (List list2 : list) {
            MotionEvent.PointerCoords pointerCoords = new MotionEvent.PointerCoords();
            pointerCoords.orientation = (float) ((Double) list2.get(0)).doubleValue();
            pointerCoords.pressure = (float) ((Double) list2.get(1)).doubleValue();
            pointerCoords.size = (float) ((Double) list2.get(2)).doubleValue();
            double d2 = f2;
            pointerCoords.toolMajor = (float) (((Double) list2.get(3)).doubleValue() * d2);
            pointerCoords.toolMinor = (float) (((Double) list2.get(4)).doubleValue() * d2);
            pointerCoords.touchMajor = (float) (((Double) list2.get(5)).doubleValue() * d2);
            pointerCoords.touchMinor = (float) (((Double) list2.get(6)).doubleValue() * d2);
            pointerCoords.x = (float) (((Double) list2.get(7)).doubleValue() * d2);
            pointerCoords.y = (float) (((Double) list2.get(8)).doubleValue() * d2);
            arrayList.add(pointerCoords);
        }
        MotionEvent.PointerCoords[] pointerCoordsArr = (MotionEvent.PointerCoords[]) arrayList.toArray(new MotionEvent.PointerCoords[i3]);
        List<List> list3 = (List) c0210h.f2681f;
        ArrayList arrayList2 = new ArrayList();
        for (List list4 : list3) {
            MotionEvent.PointerProperties pointerProperties = new MotionEvent.PointerProperties();
            pointerProperties.id = ((Integer) list4.get(0)).intValue();
            pointerProperties.toolType = ((Integer) list4.get(1)).intValue();
            arrayList2.add(pointerProperties);
        }
        MotionEvent.obtain(c0210h.f2677b.longValue(), c0210h.f2678c.longValue(), c0210h.f2679d, c0210h.f2680e, (MotionEvent.PointerProperties[]) arrayList2.toArray(new MotionEvent.PointerProperties[i3]), pointerCoordsArr, c0210h.f2683h, c0210h.f2684i, c0210h.f2685j, c0210h.f2686k, c0210h.f2687l, c0210h.f2688m, c0210h.f2689n, c0210h.f2690o);
        qVar.getClass();
    }

    @Override // m0.InterfaceC0222b
    public void l(Object obj, Q q2) {
        HashMap hashMap;
        HashMap hashMap2;
        C0051b c0051b = (C0051b) this.f30f;
        if (((io.flutter.view.c) c0051b.f585h) == null) {
            q2.n(null);
            return;
        }
        hashMap = (HashMap) obj;
        String str = (String) hashMap.get("type");
        hashMap2 = (HashMap) hashMap.get("data");
        str.getClass();
        switch (str) {
            case "tooltip":
                String str2 = (String) hashMap2.get("message");
                if (str2 != null) {
                    io.flutter.view.i iVar = (io.flutter.view.i) ((io.flutter.view.c) c0051b.f585h).f2467a;
                    if (Build.VERSION.SDK_INT < 28) {
                        AccessibilityEvent d2 = iVar.d(0, 32);
                        d2.getText().add(str2);
                        iVar.h(d2);
                        break;
                    }
                }
                break;
            case "announce":
                String str3 = (String) hashMap2.get("message");
                if (str3 != null) {
                    io.flutter.view.c cVar = (io.flutter.view.c) c0051b.f585h;
                    if (Build.VERSION.SDK_INT >= 36) {
                        cVar.getClass();
                        Log.w("AccessibilityBridge", "Using AnnounceSemanticsEvent for accessibility is deprecated on Android. Migrate to using semantic properties for a more robust and accessible user experience.\nFlutter: If you are unsure why you are seeing this bug, it might be because you are using a widget that calls this method. See https://github.com/flutter/flutter/issues/165510 for more details.\nAndroid documentation: https://developer.android.com/reference/android/view/View#announceForAccessibility(java.lang.CharSequence)");
                    }
                    ((io.flutter.view.i) cVar.f2467a).f2554a.announceForAccessibility(str3);
                    break;
                }
                break;
            case "tap":
                Integer num = (Integer) hashMap.get("nodeId");
                if (num != null) {
                    io.flutter.view.c cVar2 = (io.flutter.view.c) c0051b.f585h;
                    ((io.flutter.view.i) cVar2.f2467a).g(num.intValue(), 1);
                    break;
                }
                break;
            case "focus":
                Integer num2 = (Integer) hashMap.get("nodeId");
                if (num2 != null) {
                    io.flutter.view.c cVar3 = (io.flutter.view.c) c0051b.f585h;
                    ((io.flutter.view.i) cVar3.f2467a).g(num2.intValue(), 8);
                    break;
                }
                break;
            case "longPress":
                Integer num3 = (Integer) hashMap.get("nodeId");
                if (num3 != null) {
                    io.flutter.view.c cVar4 = (io.flutter.view.c) c0051b.f585h;
                    ((io.flutter.view.i) cVar4.f2467a).g(num3.intValue(), 2);
                    break;
                }
                break;
        }
        q2.n(null);
    }

    @Override // l0.InterfaceC0212j
    public void m(int i2) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        if (kVar.d(i2)) {
            ((io.flutter.plugin.platform.q) kVar.f2445m.get(Integer.valueOf(i2))).getClass();
            Log.e("PlatformViewsController", "Clearing focus on a null view with id: " + i2);
            return;
        }
        if (kVar.f2447o.get(i2) != null) {
            throw new ClassCastException();
        }
        Log.e("PlatformViewsController", "Clearing focus on an unknown view with id: " + i2);
    }

    @Override // m0.InterfaceC0226f
    public E.a n(C0229i c0229i) {
        return ((C0135i) this.f30f).n(c0229i);
    }

    @Override // g.o
    public boolean o(g.j jVar) {
        C0168i c0168i = (C0168i) this.f30f;
        if (jVar == null) {
            return false;
        }
        ((t) jVar).f2016w.getClass();
        c0168i.getClass();
        g.o oVar = c0168i.f2165i;
        if (oVar != null) {
            return oVar.o(jVar);
        }
        return false;
    }

    @Override // m0.InterfaceC0226f
    public void p(String str, InterfaceC0224d interfaceC0224d) {
        ((C0135i) this.f30f).j(str, interfaceC0224d, null);
    }

    @Override // m0.InterfaceC0232l
    public void q(Q q2, C0213k c0213k) {
        Q q3 = (Q) this.f30f;
        if (((C0206d) q3.f579g) == null) {
            return;
        }
        String str = (String) q2.f578f;
        str.getClass();
        if (!str.equals("Localization.getStringResource")) {
            c0213k.b();
            return;
        }
        JSONObject jSONObject = (JSONObject) q2.f579g;
        try {
            c0213k.d(((C0206d) q3.f579g).c(jSONObject.getString("key"), jSONObject.has("locale") ? jSONObject.getString("locale") : null));
        } catch (JSONException e2) {
            c0213k.a("error", e2.getMessage(), null);
        }
    }

    @Override // J.e
    public void r() {
        Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    @Override // J.e
    public void s(int i2, Object obj) {
        String str;
        switch (i2) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case F.j.LONG_FIELD_NUMBER /* 4 */:
                str = "RESULT_NOT_WRITABLE";
                break;
            case F.j.STRING_FIELD_NUMBER /* 5 */:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case F.j.STRING_SET_FIELD_NUMBER /* 6 */:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                str = "RESULT_IO_EXCEPTION";
                break;
            case F.j.BYTES_FIELD_NUMBER /* 8 */:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 9:
            default:
                str = "";
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case 11:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i2 == 6 || i2 == 7 || i2 == 8) {
            Log.e("ProfileInstaller", str, (Throwable) obj);
        } else {
            Log.d("ProfileInstaller", str);
        }
        ((ProfileInstallReceiver) this.f30f).setResultCode(i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0038  */
    /* JADX WARN: Type inference failed for: r6v6, types: [D0.p, y0.g] */
    @Override // M0.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object t(M0.e eVar, w0.c cVar) {
        M0.a aVar;
        int i2;
        Throwable th;
        N0.l lVar;
        switch (this.f29e) {
            case F.j.FLOAT_FIELD_NUMBER /* 2 */:
                Object t2 = ((Q) this.f30f).t(new C0021w(eVar, 0), cVar);
                return t2 == x0.a.f3053e ? t2 : u0.g.f2964a;
            default:
                if (cVar instanceof M0.a) {
                    aVar = (M0.a) cVar;
                    int i3 = aVar.f726k;
                    if ((i3 & Integer.MIN_VALUE) != 0) {
                        aVar.f726k = i3 - Integer.MIN_VALUE;
                        Object obj = aVar.f724i;
                        i2 = aVar.f726k;
                        u0.g gVar = u0.g.f2964a;
                        if (i2 != 0) {
                            AbstractC0230j.A(obj);
                            w0.h hVar = aVar.f3057f;
                            E0.i.b(hVar);
                            N0.l lVar2 = new N0.l(eVar, hVar);
                            try {
                                aVar.f723h = lVar2;
                                aVar.f726k = 1;
                                Object h2 = ((y0.g) this.f30f).h(lVar2, aVar);
                                x0.a aVar2 = x0.a.f3053e;
                                if (h2 != aVar2) {
                                    h2 = gVar;
                                }
                                if (h2 == aVar2) {
                                    return aVar2;
                                }
                                lVar = lVar2;
                            } catch (Throwable th2) {
                                th = th2;
                                lVar = lVar2;
                                lVar.o();
                                throw th;
                            }
                        } else {
                            if (i2 != 1) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            lVar = aVar.f723h;
                            try {
                                AbstractC0230j.A(obj);
                            } catch (Throwable th3) {
                                th = th3;
                                lVar.o();
                                throw th;
                            }
                        }
                        lVar.o();
                        return gVar;
                    }
                }
                aVar = new M0.a(this, cVar);
                Object obj2 = aVar.f724i;
                i2 = aVar.f726k;
                u0.g gVar2 = u0.g.f2964a;
                if (i2 != 0) {
                }
                lVar.o();
                return gVar2;
        }
    }

    public String toString() {
        switch (this.f29e) {
            case 11:
                return "<" + ((String) this.f30f) + '>';
            default:
                return super.toString();
        }
    }

    @Override // l0.InterfaceC0212j
    public void u(int i2) {
        switch (this.f29e) {
            case 25:
                if (((io.flutter.plugin.platform.k) this.f30f).f2447o.get(i2) != null) {
                    throw new ClassCastException();
                }
                Log.e("PlatformViewsController", "Disposing unknown platform view with id: " + i2);
                return;
            default:
                if (((io.flutter.plugin.platform.j) this.f30f).f2430k.get(i2) != null) {
                    throw new ClassCastException();
                }
                Log.e("PlatformViewsController2", "Disposing unknown platform view with id: " + i2);
                return;
        }
    }

    @Override // l0.InterfaceC0212j
    public void v(C0177s c0177s) {
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) this.f30f;
        io.flutter.plugin.platform.k.b(kVar, c0177s);
        if (kVar.f2440h.IsSurfaceControlEnabled()) {
            throw new IllegalStateException("Trying to create a Hybrid Composition view with HC++ enabled.");
        }
        C0121i c0121i = kVar.f2437e;
        String str = (String) c0177s.f2235c;
        if (c0121i.f1807a.get(str) != null) {
            throw new ClassCastException();
        }
        throw new IllegalStateException(E0.h.g("Trying to create a platform view of unregistered type: ", str));
    }

    @Override // D.InterfaceC0008i
    public M0.d w() {
        return ((InterfaceC0008i) this.f30f).w();
    }

    @Override // m0.InterfaceC0226f
    public void x(String str, ByteBuffer byteBuffer, InterfaceC0225e interfaceC0225e) {
        ((C0135i) this.f30f).x(str, byteBuffer, interfaceC0225e);
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [g0.a] */
    public Bitmap y(ByteBuffer byteBuffer, g0.d dVar) {
        ImageDecoder.Source createSource;
        Bitmap decodeBitmap;
        createSource = ImageDecoder.createSource(byteBuffer);
        try {
            decodeBitmap = ImageDecoder.decodeBitmap(createSource, new ImageDecoder.OnHeaderDecodedListener() { // from class: g0.a
                @Override // android.graphics.ImageDecoder.OnHeaderDecodedListener
                public final void onHeaderDecoded(ImageDecoder imageDecoder, ImageDecoder.ImageInfo imageInfo, ImageDecoder.Source source) {
                    ColorSpace colorSpace;
                    Size size;
                    ColorSpace.Named unused;
                    j jVar = j.this;
                    unused = ColorSpace.Named.SRGB;
                    colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
                    imageDecoder.setTargetColorSpace(colorSpace);
                    imageDecoder.setAllocator(1);
                    C0123k c0123k = (C0123k) jVar.f30f;
                    if (c0123k != null) {
                        size = imageInfo.getSize();
                        FlutterJNI.nativeImageHeaderCallback(c0123k.f1808a, size.getWidth(), size.getHeight());
                    }
                }
            });
            return decodeBitmap;
        } catch (IOException e2) {
            Log.e("FlutterImageDecoderImplDefault", "Failed to decode image", e2);
            return null;
        }
    }

    public CharSequence z(EnumC0207e enumC0207e) {
        Activity activity = ((io.flutter.plugin.platform.e) this.f30f).f2419a;
        ClipboardManager clipboardManager = (ClipboardManager) activity.getSystemService("clipboard");
        CharSequence charSequence = null;
        if (clipboardManager.hasPrimaryClip()) {
            try {
                try {
                    ClipData primaryClip = clipboardManager.getPrimaryClip();
                    if (primaryClip != null) {
                        if (enumC0207e != null) {
                            if (enumC0207e == EnumC0207e.f2663e) {
                            }
                        }
                        ClipData.Item itemAt = primaryClip.getItemAt(0);
                        CharSequence text = itemAt.getText();
                        if (text != null) {
                            return text;
                        }
                        try {
                            Uri uri = itemAt.getUri();
                            if (uri == null) {
                                Log.w("PlatformPlugin", "Clipboard item contained no textual content nor a URI to retrieve it from.");
                                return null;
                            }
                            String scheme = uri.getScheme();
                            if (!scheme.equals("content")) {
                                Log.w("PlatformPlugin", "Clipboard item contains a Uri with scheme '" + scheme + "'that is unhandled.");
                                return null;
                            }
                            AssetFileDescriptor openTypedAssetFileDescriptor = activity.getContentResolver().openTypedAssetFileDescriptor(uri, "text/*", null);
                            CharSequence coerceToText = itemAt.coerceToText(activity);
                            if (openTypedAssetFileDescriptor == null) {
                                return coerceToText;
                            }
                            try {
                                openTypedAssetFileDescriptor.close();
                                return coerceToText;
                            } catch (IOException e2) {
                                charSequence = coerceToText;
                                e = e2;
                                Log.w("PlatformPlugin", "Failed to close AssetFileDescriptor while trying to read text from URI.", e);
                                return charSequence;
                            }
                        } catch (IOException e3) {
                            e = e3;
                            charSequence = text;
                        }
                    }
                } catch (IOException e4) {
                    e = e4;
                }
            } catch (FileNotFoundException unused) {
                Log.w("PlatformPlugin", "Clipboard text was unable to be received from content URI.");
                return charSequence;
            } catch (SecurityException e5) {
                Log.w("PlatformPlugin", "Attempted to get clipboard data that requires additional permission(s).\nSee the exception details for which permission(s) are required, and consider adding them to your Android Manifest as described in:\nhttps://developer.android.com/guide/topics/permissions/overview", e5);
                return charSequence;
            }
        }
        return null;
    }

    public /* synthetic */ j(int i2, boolean z2) {
        this.f29e = i2;
    }

    public j(int i2) {
        this.f29e = i2;
        switch (i2) {
            case F.j.INTEGER_FIELD_NUMBER /* 3 */:
                this.f30f = new M0.q(q0.f250b);
                break;
            case F.j.DOUBLE_FIELD_NUMBER /* 7 */:
                this.f30f = new SparseIntArray();
                break;
            default:
                this.f30f = new AtomicInteger(0);
                break;
        }
    }

    public j(boolean z2) {
        this.f29e = 4;
        this.f30f = new AtomicBoolean(z2);
    }

    public j(InterfaceC0226f interfaceC0226f) {
        this.f29e = 28;
        new C0051b(interfaceC0226f, "flutter/keyboard", C0236p.f2742a, 8).H(new Q(this));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public j(D0.p pVar) {
        this.f29e = 10;
        this.f30f = (y0.g) pVar;
    }
}
