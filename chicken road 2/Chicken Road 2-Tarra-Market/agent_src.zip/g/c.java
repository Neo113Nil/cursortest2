package g;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: b, reason: collision with root package name */
    public static final c f1053b = new c();

    /* renamed from: a, reason: collision with root package name */
    public c f1054a;
}
