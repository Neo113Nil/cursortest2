package io.flutter.view;

/* loaded from: classes.dex */
public final class j extends l {

    /* renamed from: d, reason: collision with root package name */
    public String f830d;
}
