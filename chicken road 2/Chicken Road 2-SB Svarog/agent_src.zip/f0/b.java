package f0;

/* loaded from: classes.dex */
public interface b extends W.a {
}
