package f0;

/* loaded from: classes.dex */
public interface i extends W.a {
}
