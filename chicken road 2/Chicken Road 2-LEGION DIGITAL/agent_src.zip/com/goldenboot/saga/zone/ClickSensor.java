package com.goldenboot.saga.zone;

import java.util.List;

/* compiled from: r8-map-id-8a937589efc37ca14c210e73e18b8757b60a107ea08aacc80d18a198c868531e */
/* loaded from: classes.dex */
public interface ClickSensor extends List {
    Object drawRequest(int i);

    void gatherAdapter(AbstractBucket abstractBucket);

    List popBlueprint();

    ClickSensor resetDelta();
}
