package X0;

/* loaded from: classes.dex */
public interface b {
}
