package R0;

/* loaded from: classes.dex */
public interface j {
}
