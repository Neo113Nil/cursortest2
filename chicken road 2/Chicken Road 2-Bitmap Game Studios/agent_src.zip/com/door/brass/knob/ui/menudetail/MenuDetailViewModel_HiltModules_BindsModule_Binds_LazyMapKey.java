package com.door.brass.knob.ui.menudetail;

/* compiled from: r8-map-id-24254e9e31496375de47ca9ce3233ebe3b0427ab0cb10649855f926fd35e5650 */
/* loaded from: classes.dex */
public final class MenuDetailViewModel_HiltModules_BindsModule_Binds_LazyMapKey {
    public static final /* synthetic */ int yzPsTade5rL7D3 = 0;
}
