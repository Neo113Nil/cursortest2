package com.door.brass.knob.di;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dagger.internal.Factory;

/* compiled from: r8-map-id-24254e9e31496375de47ca9ce3233ebe3b0427ab0cb10649855f926fd35e5650 */
/* loaded from: classes.dex */
public final class NetworkModule_ProvideGsonFactory implements Factory<Gson> {

    /* compiled from: r8-map-id-24254e9e31496375de47ca9ce3233ebe3b0427ab0cb10649855f926fd35e5650 */
    public static final class InstanceHolder {
    }

    @Override // javax.inject.Provider
    public final Object get() {
        return new Gson(new GsonBuilder());
    }
}
