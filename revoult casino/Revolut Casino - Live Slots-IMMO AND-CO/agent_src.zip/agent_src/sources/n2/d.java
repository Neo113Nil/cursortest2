package n2;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.lifecycle.v0;
import g2.q;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ d f2312a = new d();
    public static final p2.f b = new p2.f(new m2.d(2));

    public static void a(h2.f fVar, final v0 v0Var) {
        fVar.getClass();
        String strConcat = "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.canLaunchUrl".concat("");
        p2.f fVar2 = b;
        q qVar = new q(fVar, strConcat, (h2.j) fVar2.a(), null);
        if (v0Var != null) {
            final int i4 = 0;
            qVar.i(new h2.b() { // from class: n2.c
                @Override // h2.b
                public final void b(Object obj, e0.c cVar) {
                    List listR;
                    List listR2;
                    v0 v0Var2;
                    List listR3;
                    List listR4;
                    List listR5;
                    switch (i4) {
                        case 0:
                            e eVar = v0Var;
                            obj.getClass();
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            obj2.getClass();
                            String str = (String) obj2;
                            try {
                                v0 v0Var3 = (v0) eVar;
                                v0Var3.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((g2.c) v0Var3.f517g).f774f).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listR = a.a.F(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof b) {
                                    b bVar = th;
                                    listR = q2.e.R(bVar.f2308f, bVar.f2309g, null);
                                } else {
                                    listR = q2.e.R(th.getClass().getSimpleName(), th.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.u(listR);
                            return;
                        case 1:
                            e eVar2 = v0Var;
                            obj.getClass();
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            obj3.getClass();
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            obj4.getClass();
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            obj5.getClass();
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                v0Var2 = (v0) eVar2;
                            } catch (Throwable th2) {
                                if (th2 instanceof b) {
                                    b bVar2 = th2;
                                    listR2 = q2.e.R(bVar2.f2308f, bVar2.f2309g, null);
                                } else {
                                    listR2 = q2.e.R(th2.getClass().getSimpleName(), th2.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) v0Var2.f518h) == null) {
                                throw new b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", v0.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) v0Var2.f518h).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listR2 = a.a.F(Boolean.valueOf(z3));
                            cVar.u(listR2);
                            return;
                        case 2:
                            e eVar3 = v0Var;
                            obj.getClass();
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            obj6.getClass();
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            obj7.getClass();
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            obj8.getClass();
                            j jVar = (j) obj8;
                            Object obj9 = list2.get(3);
                            obj9.getClass();
                            try {
                                listR3 = a.a.F(Boolean.valueOf(((v0) eVar3).K(str3, zBooleanValue2, jVar, (a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof b) {
                                    b bVar3 = th3;
                                    listR3 = q2.e.R(bVar3.f2308f, bVar3.f2309g, null);
                                } else {
                                    listR3 = q2.e.R(th3.getClass().getSimpleName(), th3.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.u(listR3);
                            return;
                        case 3:
                            try {
                                listR4 = a.a.F(Boolean.valueOf(r.h.a((Context) ((v0) v0Var).f516f, Collections.EMPTY_LIST, false) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof b) {
                                    b bVar4 = th4;
                                    listR4 = q2.e.R(bVar4.f2308f, bVar4.f2309g, null);
                                } else {
                                    listR4 = q2.e.R(th4.getClass().getSimpleName(), th4.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.u(listR4);
                            return;
                        default:
                            try {
                                ((Context) ((v0) v0Var).f516f).sendBroadcast(new Intent("close action"));
                                listR5 = a.a.F(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof b) {
                                    b bVar5 = th5;
                                    listR5 = q2.e.R(bVar5.f2308f, bVar5.f2309g, null);
                                } else {
                                    listR5 = q2.e.R(th5.getClass().getSimpleName(), th5.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.u(listR5);
                            return;
                    }
                }
            });
        } else {
            qVar.i(null);
        }
        q qVar2 = new q(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.launchUrl".concat(""), (h2.j) fVar2.a(), null);
        if (v0Var != null) {
            final int i5 = 1;
            qVar2.i(new h2.b() { // from class: n2.c
                @Override // h2.b
                public final void b(Object obj, e0.c cVar) {
                    List listR;
                    List listR2;
                    v0 v0Var2;
                    List listR3;
                    List listR4;
                    List listR5;
                    switch (i5) {
                        case 0:
                            e eVar = v0Var;
                            obj.getClass();
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            obj2.getClass();
                            String str = (String) obj2;
                            try {
                                v0 v0Var3 = (v0) eVar;
                                v0Var3.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((g2.c) v0Var3.f517g).f774f).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listR = a.a.F(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof b) {
                                    b bVar = th;
                                    listR = q2.e.R(bVar.f2308f, bVar.f2309g, null);
                                } else {
                                    listR = q2.e.R(th.getClass().getSimpleName(), th.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.u(listR);
                            return;
                        case 1:
                            e eVar2 = v0Var;
                            obj.getClass();
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            obj3.getClass();
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            obj4.getClass();
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            obj5.getClass();
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                v0Var2 = (v0) eVar2;
                            } catch (Throwable th2) {
                                if (th2 instanceof b) {
                                    b bVar2 = th2;
                                    listR2 = q2.e.R(bVar2.f2308f, bVar2.f2309g, null);
                                } else {
                                    listR2 = q2.e.R(th2.getClass().getSimpleName(), th2.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) v0Var2.f518h) == null) {
                                throw new b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", v0.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) v0Var2.f518h).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listR2 = a.a.F(Boolean.valueOf(z3));
                            cVar.u(listR2);
                            return;
                        case 2:
                            e eVar3 = v0Var;
                            obj.getClass();
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            obj6.getClass();
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            obj7.getClass();
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            obj8.getClass();
                            j jVar = (j) obj8;
                            Object obj9 = list2.get(3);
                            obj9.getClass();
                            try {
                                listR3 = a.a.F(Boolean.valueOf(((v0) eVar3).K(str3, zBooleanValue2, jVar, (a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof b) {
                                    b bVar3 = th3;
                                    listR3 = q2.e.R(bVar3.f2308f, bVar3.f2309g, null);
                                } else {
                                    listR3 = q2.e.R(th3.getClass().getSimpleName(), th3.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.u(listR3);
                            return;
                        case 3:
                            try {
                                listR4 = a.a.F(Boolean.valueOf(r.h.a((Context) ((v0) v0Var).f516f, Collections.EMPTY_LIST, false) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof b) {
                                    b bVar4 = th4;
                                    listR4 = q2.e.R(bVar4.f2308f, bVar4.f2309g, null);
                                } else {
                                    listR4 = q2.e.R(th4.getClass().getSimpleName(), th4.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.u(listR4);
                            return;
                        default:
                            try {
                                ((Context) ((v0) v0Var).f516f).sendBroadcast(new Intent("close action"));
                                listR5 = a.a.F(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof b) {
                                    b bVar5 = th5;
                                    listR5 = q2.e.R(bVar5.f2308f, bVar5.f2309g, null);
                                } else {
                                    listR5 = q2.e.R(th5.getClass().getSimpleName(), th5.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.u(listR5);
                            return;
                    }
                }
            });
        } else {
            qVar2.i(null);
        }
        q qVar3 = new q(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.openUrlInApp".concat(""), (h2.j) fVar2.a(), null);
        if (v0Var != null) {
            final int i6 = 2;
            qVar3.i(new h2.b() { // from class: n2.c
                @Override // h2.b
                public final void b(Object obj, e0.c cVar) {
                    List listR;
                    List listR2;
                    v0 v0Var2;
                    List listR3;
                    List listR4;
                    List listR5;
                    switch (i6) {
                        case 0:
                            e eVar = v0Var;
                            obj.getClass();
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            obj2.getClass();
                            String str = (String) obj2;
                            try {
                                v0 v0Var3 = (v0) eVar;
                                v0Var3.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((g2.c) v0Var3.f517g).f774f).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listR = a.a.F(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof b) {
                                    b bVar = th;
                                    listR = q2.e.R(bVar.f2308f, bVar.f2309g, null);
                                } else {
                                    listR = q2.e.R(th.getClass().getSimpleName(), th.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.u(listR);
                            return;
                        case 1:
                            e eVar2 = v0Var;
                            obj.getClass();
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            obj3.getClass();
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            obj4.getClass();
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            obj5.getClass();
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                v0Var2 = (v0) eVar2;
                            } catch (Throwable th2) {
                                if (th2 instanceof b) {
                                    b bVar2 = th2;
                                    listR2 = q2.e.R(bVar2.f2308f, bVar2.f2309g, null);
                                } else {
                                    listR2 = q2.e.R(th2.getClass().getSimpleName(), th2.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) v0Var2.f518h) == null) {
                                throw new b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", v0.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) v0Var2.f518h).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listR2 = a.a.F(Boolean.valueOf(z3));
                            cVar.u(listR2);
                            return;
                        case 2:
                            e eVar3 = v0Var;
                            obj.getClass();
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            obj6.getClass();
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            obj7.getClass();
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            obj8.getClass();
                            j jVar = (j) obj8;
                            Object obj9 = list2.get(3);
                            obj9.getClass();
                            try {
                                listR3 = a.a.F(Boolean.valueOf(((v0) eVar3).K(str3, zBooleanValue2, jVar, (a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof b) {
                                    b bVar3 = th3;
                                    listR3 = q2.e.R(bVar3.f2308f, bVar3.f2309g, null);
                                } else {
                                    listR3 = q2.e.R(th3.getClass().getSimpleName(), th3.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.u(listR3);
                            return;
                        case 3:
                            try {
                                listR4 = a.a.F(Boolean.valueOf(r.h.a((Context) ((v0) v0Var).f516f, Collections.EMPTY_LIST, false) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof b) {
                                    b bVar4 = th4;
                                    listR4 = q2.e.R(bVar4.f2308f, bVar4.f2309g, null);
                                } else {
                                    listR4 = q2.e.R(th4.getClass().getSimpleName(), th4.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.u(listR4);
                            return;
                        default:
                            try {
                                ((Context) ((v0) v0Var).f516f).sendBroadcast(new Intent("close action"));
                                listR5 = a.a.F(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof b) {
                                    b bVar5 = th5;
                                    listR5 = q2.e.R(bVar5.f2308f, bVar5.f2309g, null);
                                } else {
                                    listR5 = q2.e.R(th5.getClass().getSimpleName(), th5.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.u(listR5);
                            return;
                    }
                }
            });
        } else {
            qVar3.i(null);
        }
        q qVar4 = new q(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.supportsCustomTabs".concat(""), (h2.j) fVar2.a(), null);
        if (v0Var != null) {
            final int i7 = 3;
            qVar4.i(new h2.b() { // from class: n2.c
                @Override // h2.b
                public final void b(Object obj, e0.c cVar) {
                    List listR;
                    List listR2;
                    v0 v0Var2;
                    List listR3;
                    List listR4;
                    List listR5;
                    switch (i7) {
                        case 0:
                            e eVar = v0Var;
                            obj.getClass();
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            obj2.getClass();
                            String str = (String) obj2;
                            try {
                                v0 v0Var3 = (v0) eVar;
                                v0Var3.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((g2.c) v0Var3.f517g).f774f).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listR = a.a.F(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof b) {
                                    b bVar = th;
                                    listR = q2.e.R(bVar.f2308f, bVar.f2309g, null);
                                } else {
                                    listR = q2.e.R(th.getClass().getSimpleName(), th.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.u(listR);
                            return;
                        case 1:
                            e eVar2 = v0Var;
                            obj.getClass();
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            obj3.getClass();
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            obj4.getClass();
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            obj5.getClass();
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                v0Var2 = (v0) eVar2;
                            } catch (Throwable th2) {
                                if (th2 instanceof b) {
                                    b bVar2 = th2;
                                    listR2 = q2.e.R(bVar2.f2308f, bVar2.f2309g, null);
                                } else {
                                    listR2 = q2.e.R(th2.getClass().getSimpleName(), th2.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) v0Var2.f518h) == null) {
                                throw new b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", v0.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) v0Var2.f518h).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listR2 = a.a.F(Boolean.valueOf(z3));
                            cVar.u(listR2);
                            return;
                        case 2:
                            e eVar3 = v0Var;
                            obj.getClass();
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            obj6.getClass();
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            obj7.getClass();
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            obj8.getClass();
                            j jVar = (j) obj8;
                            Object obj9 = list2.get(3);
                            obj9.getClass();
                            try {
                                listR3 = a.a.F(Boolean.valueOf(((v0) eVar3).K(str3, zBooleanValue2, jVar, (a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof b) {
                                    b bVar3 = th3;
                                    listR3 = q2.e.R(bVar3.f2308f, bVar3.f2309g, null);
                                } else {
                                    listR3 = q2.e.R(th3.getClass().getSimpleName(), th3.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.u(listR3);
                            return;
                        case 3:
                            try {
                                listR4 = a.a.F(Boolean.valueOf(r.h.a((Context) ((v0) v0Var).f516f, Collections.EMPTY_LIST, false) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof b) {
                                    b bVar4 = th4;
                                    listR4 = q2.e.R(bVar4.f2308f, bVar4.f2309g, null);
                                } else {
                                    listR4 = q2.e.R(th4.getClass().getSimpleName(), th4.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.u(listR4);
                            return;
                        default:
                            try {
                                ((Context) ((v0) v0Var).f516f).sendBroadcast(new Intent("close action"));
                                listR5 = a.a.F(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof b) {
                                    b bVar5 = th5;
                                    listR5 = q2.e.R(bVar5.f2308f, bVar5.f2309g, null);
                                } else {
                                    listR5 = q2.e.R(th5.getClass().getSimpleName(), th5.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.u(listR5);
                            return;
                    }
                }
            });
        } else {
            qVar4.i(null);
        }
        q qVar5 = new q(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.closeWebView".concat(""), (h2.j) fVar2.a(), null);
        if (v0Var == null) {
            qVar5.i(null);
        } else {
            final int i8 = 4;
            qVar5.i(new h2.b() { // from class: n2.c
                @Override // h2.b
                public final void b(Object obj, e0.c cVar) {
                    List listR;
                    List listR2;
                    v0 v0Var2;
                    List listR3;
                    List listR4;
                    List listR5;
                    switch (i8) {
                        case 0:
                            e eVar = v0Var;
                            obj.getClass();
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            obj2.getClass();
                            String str = (String) obj2;
                            try {
                                v0 v0Var3 = (v0) eVar;
                                v0Var3.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((g2.c) v0Var3.f517g).f774f).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listR = a.a.F(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof b) {
                                    b bVar = th;
                                    listR = q2.e.R(bVar.f2308f, bVar.f2309g, null);
                                } else {
                                    listR = q2.e.R(th.getClass().getSimpleName(), th.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.u(listR);
                            return;
                        case 1:
                            e eVar2 = v0Var;
                            obj.getClass();
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            obj3.getClass();
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            obj4.getClass();
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            obj5.getClass();
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                v0Var2 = (v0) eVar2;
                            } catch (Throwable th2) {
                                if (th2 instanceof b) {
                                    b bVar2 = th2;
                                    listR2 = q2.e.R(bVar2.f2308f, bVar2.f2309g, null);
                                } else {
                                    listR2 = q2.e.R(th2.getClass().getSimpleName(), th2.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) v0Var2.f518h) == null) {
                                throw new b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", v0.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) v0Var2.f518h).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listR2 = a.a.F(Boolean.valueOf(z3));
                            cVar.u(listR2);
                            return;
                        case 2:
                            e eVar3 = v0Var;
                            obj.getClass();
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            obj6.getClass();
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            obj7.getClass();
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            obj8.getClass();
                            j jVar = (j) obj8;
                            Object obj9 = list2.get(3);
                            obj9.getClass();
                            try {
                                listR3 = a.a.F(Boolean.valueOf(((v0) eVar3).K(str3, zBooleanValue2, jVar, (a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof b) {
                                    b bVar3 = th3;
                                    listR3 = q2.e.R(bVar3.f2308f, bVar3.f2309g, null);
                                } else {
                                    listR3 = q2.e.R(th3.getClass().getSimpleName(), th3.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.u(listR3);
                            return;
                        case 3:
                            try {
                                listR4 = a.a.F(Boolean.valueOf(r.h.a((Context) ((v0) v0Var).f516f, Collections.EMPTY_LIST, false) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof b) {
                                    b bVar4 = th4;
                                    listR4 = q2.e.R(bVar4.f2308f, bVar4.f2309g, null);
                                } else {
                                    listR4 = q2.e.R(th4.getClass().getSimpleName(), th4.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.u(listR4);
                            return;
                        default:
                            try {
                                ((Context) ((v0) v0Var).f516f).sendBroadcast(new Intent("close action"));
                                listR5 = a.a.F(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof b) {
                                    b bVar5 = th5;
                                    listR5 = q2.e.R(bVar5.f2308f, bVar5.f2309g, null);
                                } else {
                                    listR5 = q2.e.R(th5.getClass().getSimpleName(), th5.toString(), androidx.datastore.preferences.protobuf.e.i("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.u(listR5);
                            return;
                    }
                }
            });
        }
    }
}
