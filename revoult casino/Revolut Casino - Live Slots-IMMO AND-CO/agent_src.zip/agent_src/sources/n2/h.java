package n2;

import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class h extends WebViewClient {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ i f2315a;

    public h(i iVar) {
        this.f2315a = iVar;
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        this.f2315a.f2316a.f1333h.loadUrl(webResourceRequest.getUrl().toString());
        return true;
    }
}
