package n2;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f2307a;

    public a(boolean z2) {
        this.f2307a = z2;
    }

    public final boolean equals(Object obj) {
        if (obj == null || !obj.getClass().equals(a.class)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return r3.b.h(Boolean.valueOf(this.f2307a), Boolean.valueOf(((a) obj).f2307a));
    }

    public final int hashCode() {
        return r3.b.i(Boolean.valueOf(this.f2307a)) + (a.class.hashCode() * 31);
    }

    public final String toString() {
        return "BrowserOptions(showTitle=" + this.f2307a + ")";
    }
}
