package n2;

import java.util.Map;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f2317a;
    public final boolean b;

    /* renamed from: c, reason: collision with root package name */
    public final Map f2318c;

    public j(boolean z2, boolean z3, Map map) {
        this.f2317a = z2;
        this.b = z3;
        this.f2318c = map;
    }

    public final boolean equals(Object obj) {
        if (obj == null || !obj.getClass().equals(j.class)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        j jVar = (j) obj;
        return r3.b.h(Boolean.valueOf(this.f2317a), Boolean.valueOf(jVar.f2317a)) && r3.b.h(Boolean.valueOf(this.b), Boolean.valueOf(jVar.b)) && r3.b.h(this.f2318c, jVar.f2318c);
    }

    public final int hashCode() {
        return r3.b.i(this.f2318c) + ((r3.b.i(Boolean.valueOf(this.b)) + ((r3.b.i(Boolean.valueOf(this.f2317a)) + (j.class.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "WebViewOptions(enableJavaScript=" + this.f2317a + ", enableDomStorage=" + this.b + ", headers=" + this.f2318c + ")";
    }
}
