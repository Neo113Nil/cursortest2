package n2;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public interface e {

    /* renamed from: e, reason: collision with root package name */
    public static final d f2313e = d.f2312a;
}
