package n2;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class b extends RuntimeException {

    /* renamed from: f, reason: collision with root package name */
    public final String f2308f = "NO_ACTIVITY";

    /* renamed from: g, reason: collision with root package name */
    public final String f2309g = "Launching a URL requires a foreground activity.";

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.f2309g;
    }
}
