package n2;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import androidx.lifecycle.v0;
import o.t;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class f implements d2.c, e2.a {

    /* renamed from: f, reason: collision with root package name */
    public v0 f2314f;

    @Override // e2.a
    public final void onAttachedToActivity(e2.b bVar) {
        v0 v0Var = this.f2314f;
        if (v0Var == null) {
            Log.wtf("UrlLauncherPlugin", "urlLauncher was never set.");
        } else {
            v0Var.f518h = (Activity) ((t) bVar).f2588a;
        }
    }

    @Override // d2.c
    public final void onAttachedToEngine(d2.b bVar) {
        Context context = bVar.f662a;
        g2.c cVar = new g2.c(context);
        v0 v0Var = new v0();
        v0Var.f516f = context;
        v0Var.f517g = cVar;
        this.f2314f = v0Var;
        d dVar = e.f2313e;
        h2.f fVar = bVar.b;
        dVar.getClass();
        d.a(fVar, v0Var);
    }

    @Override // e2.a
    public final void onDetachedFromActivity() {
        v0 v0Var = this.f2314f;
        if (v0Var == null) {
            Log.wtf("UrlLauncherPlugin", "urlLauncher was never set.");
        } else {
            v0Var.f518h = null;
        }
    }

    @Override // e2.a
    public final void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // d2.c
    public final void onDetachedFromEngine(d2.b bVar) {
        if (this.f2314f == null) {
            Log.wtf("UrlLauncherPlugin", "Already detached from the engine.");
            return;
        }
        d dVar = e.f2313e;
        h2.f fVar = bVar.b;
        dVar.getClass();
        d.a(fVar, null);
        this.f2314f = null;
    }

    @Override // e2.a
    public final void onReattachedToActivityForConfigChanges(e2.b bVar) {
        onAttachedToActivity(bVar);
    }
}
