package io.flutter.plugins;

import android.util.Log;
import b1.b;
import com.pichillilorenzo.flutter_inappwebview_android.InAppWebViewFlutterPlugin;
import m2.d0;
import n2.f;
import u1.a;
import x1.c;
import x1.d;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(c cVar) {
        try {
            cVar.f3185d.a(new InAppWebViewFlutterPlugin());
        } catch (Exception e4) {
            Log.e(TAG, "Error registering plugin flutter_inappwebview_android, com.pichillilorenzo.flutter_inappwebview_android.InAppWebViewFlutterPlugin", e4);
        }
        try {
            cVar.f3185d.a(new a());
        } catch (Exception e5) {
            Log.e(TAG, "Error registering plugin image_preload_helper, i.love.my.images.image_preload_helper.ImagePreloadHelperPlugin", e5);
        }
        try {
            d dVar = cVar.f3185d;
            d0 d0Var = new d0();
            d0Var.f2050h = new b(12);
            dVar.a(d0Var);
        } catch (Exception e6) {
            Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e6);
        }
        try {
            cVar.f3185d.a(new f());
        } catch (Exception e7) {
            Log.e(TAG, "Error registering plugin url_launcher_android, io.flutter.plugins.urllauncher.UrlLauncherPlugin", e7);
        }
    }
}
