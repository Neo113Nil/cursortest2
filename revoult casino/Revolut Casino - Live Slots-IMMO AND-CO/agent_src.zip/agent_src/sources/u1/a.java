package u1;

import d2.b;
import d2.c;

/* compiled from: r8-map-id-b0296dbd8ed8c6cc599efa62ad222af798e72c00946dae07abbe37f22c74722e */
/* loaded from: classes.dex */
public final class a implements c {
    @Override // d2.c
    public final void onAttachedToEngine(b bVar) {
        bVar.getClass();
    }

    @Override // d2.c
    public final void onDetachedFromEngine(b bVar) {
        bVar.getClass();
    }
}
