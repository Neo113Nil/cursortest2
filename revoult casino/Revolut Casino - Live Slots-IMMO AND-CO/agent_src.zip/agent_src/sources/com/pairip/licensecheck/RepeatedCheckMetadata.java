package com.pairip.licensecheck;

/* loaded from: classes.dex */
public class RepeatedCheckMetadata {
    private final long durationToRetryMillis;
    private final long timeToRetryMillis;

    public RepeatedCheckMetadata(long j4, long j5) {
        if (j4 <= 0) {
            throw new IllegalArgumentException("Duration to retry must be positive.");
        }
        if (j5 <= 0) {
            throw new IllegalArgumentException("Time to retry must be positive.");
        }
        this.durationToRetryMillis = j4;
        this.timeToRetryMillis = j5;
    }

    public long getDurationToRetryMillis() {
        return this.durationToRetryMillis;
    }

    public long getTimeToRetryMillis() {
        return this.timeToRetryMillis;
    }
}
