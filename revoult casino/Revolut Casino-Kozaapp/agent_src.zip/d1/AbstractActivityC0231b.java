package d1;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.util.Log;
import android.view.View;
import android.window.OnBackInvokedCallback;
import androidx.lifecycle.AbstractC0156o;
import androidx.lifecycle.EnumC0154m;
import androidx.lifecycle.InterfaceC0160t;
import f1.C0251a;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.plugin.platform.C0288e;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import n.C1;
import n1.C0443a;
import u1.C0531q;
import x1.AbstractC0591a;

/* renamed from: d1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0231b extends Activity implements InterfaceC0234e, InterfaceC0160t {
    public static final int j = View.generateViewId();

    /* renamed from: f, reason: collision with root package name */
    public boolean f2730f = false;

    /* renamed from: g, reason: collision with root package name */
    public C0235f f2731g;

    /* renamed from: h, reason: collision with root package name */
    public final androidx.lifecycle.v f2732h;

    /* renamed from: i, reason: collision with root package name */
    public final OnBackInvokedCallback f2733i;

    public AbstractActivityC0231b() {
        int i2 = Build.VERSION.SDK_INT;
        this.f2733i = i2 < 33 ? null : i2 >= 34 ? new Y.k(1, this) : new Y.j(1, this);
        this.f2732h = new androidx.lifecycle.v(this);
    }

    public final String a() {
        String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int b() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final String c() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final String d() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle bundleF = f();
            String string = bundleF != null ? bundleF.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final String e() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle bundleF = f();
            if (bundleF != null) {
                return bundleF.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final Bundle f() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void g(boolean z2) {
        if (z2 && !this.f2730f) {
            if (Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f2733i);
                this.f2730f = true;
                return;
            }
            return;
        }
        if (z2 || !this.f2730f || Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f2733i);
        this.f2730f = false;
    }

    @Override // androidx.lifecycle.InterfaceC0160t
    public final AbstractC0156o getLifecycle() {
        return this.f2732h;
    }

    public final boolean h() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (c() != null || this.f2731g.f2744g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean i() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : c() == null;
    }

    public final boolean j(String str) {
        C0235f c0235f = this.f2731g;
        if (c0235f == null) {
            Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0235f.j) {
            return true;
        }
        Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        if (j("onActivityResult")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            if (c0235f.f2739b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Objects.toString(intent);
            e1.d dVar = c0235f.f2739b.f2858d;
            if (!dVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            AbstractC0591a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                C1 c12 = dVar.f2883f;
                c12.getClass();
                Iterator it = new HashSet((HashSet) c12.f3946d).iterator();
                while (true) {
                    boolean z2 = false;
                    while (it.hasNext()) {
                        if (((o1.q) it.next()).onActivityResult(i2, i3, intent) || z2) {
                            z2 = true;
                        }
                    }
                    Trace.endSection();
                    return;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (j("onBackPressed")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                cVar.f2863i.f4285a.a("popRoute", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:186:0x0452  */
    /* JADX WARN: Removed duplicated region for block: B:193:0x0504  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x050f  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x0569 A[LOOP:0: B:200:0x0563->B:202:0x0569, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:206:0x057e A[LOOP:1: B:204:0x0578->B:206:0x057e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:210:0x0593 A[LOOP:2: B:208:0x058d->B:210:0x0593, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:214:0x05b0 A[LOOP:3: B:212:0x05aa->B:214:0x05b0, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:217:0x05c4 A[LOOP:4: B:215:0x05be->B:217:0x05c4, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:220:0x05de  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x063f  */
    /* JADX WARN: Type inference failed for: r6v12, types: [android.view.View, io.flutter.embedding.engine.renderer.m] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onCreate(android.os.Bundle r15) throws java.lang.IllegalAccessException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        /*
            Method dump skipped, instructions count: 1621
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: d1.AbstractActivityC0231b.onCreate(android.os.Bundle):void");
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (j("onDestroy")) {
            this.f2731g.e();
            this.f2731g.f();
        }
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f2733i);
            this.f2730f = false;
        }
        C0235f c0235f = this.f2731g;
        if (c0235f != null) {
            c0235f.f2738a = null;
            c0235f.f2739b = null;
            c0235f.f2740c = null;
            c0235f.f2741d = null;
            c0235f.f2742e = null;
            this.f2731g = null;
        }
        this.f2732h.e(EnumC0154m.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (j("onNewIntent")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            e1.c cVar = c0235f.f2739b;
            if (cVar == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            e1.d dVar = cVar.f2858d;
            if (dVar.f()) {
                AbstractC0591a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    Iterator it = ((HashSet) dVar.f2883f.f3947e).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            String strD = c0235f.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            C0443a c0443a = c0235f.f2739b.f2863i;
            c0443a.getClass();
            HashMap map = new HashMap();
            map.put("location", strD);
            c0443a.f4285a.a("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (j("onPause")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            c0235f.f2738a.getClass();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                n1.d dVar = cVar.f2861g;
                dVar.a(3, dVar.f4291c);
            }
        }
        this.f2732h.e(EnumC0154m.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (j("onPostResume")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            if (c0235f.f2739b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0288e c0288e = c0235f.f2741d;
            if (c0288e != null) {
                c0288e.b();
            }
            c0235f.f2739b.f2872s.k();
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (j("onRequestPermissionsResult")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            if (c0235f.f2739b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Arrays.toString(strArr);
            Arrays.toString(iArr);
            e1.d dVar = c0235f.f2739b.f2858d;
            if (!dVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            AbstractC0591a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                Iterator it = ((HashSet) dVar.f2883f.f3945c).iterator();
                while (true) {
                    boolean z2 = false;
                    while (it.hasNext()) {
                        C0531q c0531q = (C0531q) it.next();
                        c0531q.getClass();
                        boolean z3 = iArr.length > 0 && iArr[0] == 0;
                        if (i2 != 2345) {
                            if (i2 != 2355) {
                                if (z2) {
                                    z2 = true;
                                }
                            } else if (z3) {
                                c0531q.i();
                            }
                        } else if (z3) {
                            c0531q.h();
                        }
                        if (!z3 && (i2 == 2345 || i2 == 2355)) {
                            c0531q.b("camera_access_denied", "The user did not allow camera access.");
                        }
                        z2 = true;
                    }
                    Trace.endSection();
                    return;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f2732h.e(EnumC0154m.ON_RESUME);
        if (j("onResume")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            c0235f.f2739b.f2856b.i();
            c0235f.f2738a.getClass();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                n1.d dVar = cVar.f2861g;
                dVar.a(2, dVar.f4291c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (j("onSaveInstanceState")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            if (c0235f.f2738a.i()) {
                bundle.putByteArray("framework", (byte[]) c0235f.f2739b.f2864k.f4222f);
            }
            c0235f.f2738a.getClass();
            Bundle bundle2 = new Bundle();
            e1.d dVar = c0235f.f2739b.f2858d;
            if (dVar.f()) {
                AbstractC0591a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    Iterator it = ((HashSet) dVar.f2883f.f3949g).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0235f.f2738a.c() == null || c0235f.f2738a.h()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0235f.f2738a.f2730f);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        Bundle bundleF;
        super.onStart();
        this.f2732h.e(EnumC0154m.ON_START);
        if (j("onStart")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            if (c0235f.f2738a.c() == null && !c0235f.f2739b.f2857c.f2912g) {
                String strE = c0235f.f2738a.e();
                if (strE == null) {
                    AbstractActivityC0231b abstractActivityC0231b = c0235f.f2738a;
                    abstractActivityC0231b.getClass();
                    strE = c0235f.d(abstractActivityC0231b.getIntent());
                    if (strE == null) {
                        strE = "/";
                    }
                }
                AbstractActivityC0231b abstractActivityC0231b2 = c0235f.f2738a;
                abstractActivityC0231b2.getClass();
                try {
                    bundleF = abstractActivityC0231b2.f();
                } catch (PackageManager.NameNotFoundException unused) {
                }
                String string = bundleF != null ? bundleF.getString("io.flutter.EntrypointUri") : null;
                c0235f.f2738a.d();
                c0235f.f2739b.f2863i.f4285a.a("setInitialRoute", strE, null);
                String strA = c0235f.f2738a.a();
                if (strA == null || strA.isEmpty()) {
                    strA = ((i1.e) E0.i.Y().f168h).f3209d.f3198b;
                }
                c0235f.f2739b.f2857c.c(string == null ? new C0251a(strA, c0235f.f2738a.d()) : new C0251a(strA, string, c0235f.f2738a.d()), (List) c0235f.f2738a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            Integer num = c0235f.f2747k;
            if (num != null) {
                c0235f.f2740c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (j("onStop")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            c0235f.f2738a.getClass();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                n1.d dVar = cVar.f2861g;
                dVar.a(5, dVar.f4291c);
            }
            c0235f.f2747k = Integer.valueOf(c0235f.f2740c.getVisibility());
            c0235f.f2740c.setVisibility(8);
            e1.c cVar2 = c0235f.f2739b;
            if (cVar2 != null) {
                cVar2.f2856b.f(40);
            }
        }
        this.f2732h.e(EnumC0154m.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (j("onTrimMemory")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                if (c0235f.f2746i && i2 >= 10) {
                    FlutterJNI flutterJNI = (FlutterJNI) cVar.f2857c.f2913h;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    n1.c cVar2 = c0235f.f2739b.f2870q;
                    cVar2.getClass();
                    HashMap map = new HashMap(1);
                    map.put("type", "memoryPressure");
                    cVar2.f4288a.q(map, null);
                }
                c0235f.f2739b.f2856b.f(i2);
                io.flutter.plugin.platform.s sVar = c0235f.f2739b.f2872s;
                if (i2 < 40) {
                    sVar.getClass();
                    return;
                }
                Iterator it = sVar.f3403o.values().iterator();
                while (it.hasNext()) {
                    ((io.flutter.plugin.platform.E) it.next()).f3343h.setSurface(null);
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (j("onUserLeaveHint")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            e1.c cVar = c0235f.f2739b;
            if (cVar == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            e1.d dVar = cVar.f2858d;
            if (!dVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            AbstractC0591a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                Iterator it = ((HashSet) dVar.f2883f.f3948f).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (j("onWindowFocusChanged")) {
            C0235f c0235f = this.f2731g;
            c0235f.c();
            c0235f.f2738a.getClass();
            e1.c cVar = c0235f.f2739b;
            if (cVar != null) {
                n1.d dVar = cVar.f2861g;
                if (z2) {
                    dVar.a(dVar.f4289a, true);
                } else {
                    dVar.a(dVar.f4289a, false);
                }
            }
        }
    }
}
