package com.north.window;

import d1.AbstractActivityC0231b;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0231b {

    /* renamed from: k, reason: collision with root package name */
    public static final /* synthetic */ int f2691k = 0;
}
