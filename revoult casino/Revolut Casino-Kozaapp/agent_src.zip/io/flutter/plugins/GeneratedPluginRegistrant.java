package io.flutter.plugins;

import T0.e;
import W0.o;
import Y0.b;
import Z0.a;
import a1.C0111a;
import android.util.Log;
import b1.C0166c;
import com.github.dart_lang.jni.JniPlugin;
import com.github.dart_lang.jni_flutter.JniFlutterPlugin;
import com.pichillilorenzo.flutter_inappwebview_android.InAppWebViewFlutterPlugin;
import e1.c;
import g.InterfaceC0252a;
import t1.C0509a;
import u1.C0533s;
import v1.C0545I;
import w1.C0580f;
import z0.d;

@InterfaceC0252a
/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(c cVar) {
        try {
            cVar.f2858d.a(new b());
        } catch (Exception e2) {
            Log.e(TAG, "Error registering plugin battery_plus, dev.fluttercommunity.plus.battery.BatteryPlusPlugin", e2);
        }
        try {
            cVar.f2858d.a(new a());
        } catch (Exception e3) {
            Log.e(TAG, "Error registering plugin device_info_plus, dev.fluttercommunity.plus.device_info.DeviceInfoPlusPlugin", e3);
        }
        try {
            cVar.f2858d.a(new d());
        } catch (Exception e4) {
            Log.e(TAG, "Error registering plugin flutter_custom_tabs_android, com.github.droibit.flutter.plugins.customtabs.CustomTabsPlugin", e4);
        }
        try {
            cVar.f2858d.a(new InAppWebViewFlutterPlugin());
        } catch (Exception e5) {
            Log.e(TAG, "Error registering plugin flutter_inappwebview_android, com.pichillilorenzo.flutter_inappwebview_android.InAppWebViewFlutterPlugin", e5);
        }
        try {
            cVar.f2858d.a(new C0509a());
        } catch (Exception e6) {
            Log.e(TAG, "Error registering plugin flutter_plugin_android_lifecycle, io.flutter.plugins.flutter_plugin_android_lifecycle.FlutterAndroidLifecyclePlugin", e6);
        }
        try {
            cVar.f2858d.a(new e());
        } catch (Exception e7) {
            Log.e(TAG, "Error registering plugin flutter_secure_storage, com.it_nomads.fluttersecurestorage.FlutterSecureStoragePlugin", e7);
        }
        try {
            cVar.f2858d.a(new C0533s());
        } catch (Exception e8) {
            Log.e(TAG, "Error registering plugin image_picker_android, io.flutter.plugins.imagepicker.ImagePickerPlugin", e8);
        }
        try {
            cVar.f2858d.a(new JniPlugin());
        } catch (Exception e9) {
            Log.e(TAG, "Error registering plugin jni, com.github.dart_lang.jni.JniPlugin", e9);
        }
        try {
            cVar.f2858d.a(new JniFlutterPlugin());
        } catch (Exception e10) {
            Log.e(TAG, "Error registering plugin jni_flutter, com.github.dart_lang.jni_flutter.JniFlutterPlugin", e10);
        }
        try {
            cVar.f2858d.a(new C0111a());
        } catch (Exception e11) {
            Log.e(TAG, "Error registering plugin package_info_plus, dev.fluttercommunity.plus.packageinfo.PackageInfoPlugin", e11);
        }
        try {
            cVar.f2858d.a(new C0166c());
        } catch (Exception e12) {
            Log.e(TAG, "Error registering plugin share_plus, dev.fluttercommunity.plus.share.SharePlusPlugin", e12);
        }
        try {
            cVar.f2858d.a(new C0545I());
        } catch (Exception e13) {
            Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e13);
        }
        try {
            cVar.f2858d.a(new o());
        } catch (Exception e14) {
            Log.e(TAG, "Error registering plugin sqflite_android, com.tekartik.sqflite.SqflitePlugin", e14);
        }
        try {
            cVar.f2858d.a(new C0580f());
        } catch (Exception e15) {
            Log.e(TAG, "Error registering plugin url_launcher_android, io.flutter.plugins.urllauncher.UrlLauncherPlugin", e15);
        }
    }
}
