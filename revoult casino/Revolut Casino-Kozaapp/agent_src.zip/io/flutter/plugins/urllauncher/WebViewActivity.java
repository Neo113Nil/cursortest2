package io.flutter.plugins.urllauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import i.w;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import n.AbstractC0436x;
import w1.C0581g;
import w1.C0583i;

/* loaded from: classes.dex */
public class WebViewActivity extends Activity {
    public static final /* synthetic */ int j = 0;

    /* renamed from: h, reason: collision with root package name */
    public WebView f3434h;

    /* renamed from: f, reason: collision with root package name */
    public final w f3432f = new w(1, this);

    /* renamed from: g, reason: collision with root package name */
    public final C0581g f3433g = new C0581g();

    /* renamed from: i, reason: collision with root package name */
    public final IntentFilter f3435i = new IntentFilter("close action");

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        Map<String, String> map;
        super.onCreate(bundle);
        WebView webView = new WebView(this);
        this.f3434h = webView;
        setContentView(webView);
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("url");
        boolean booleanExtra = intent.getBooleanExtra("enableJavaScript", false);
        boolean booleanExtra2 = intent.getBooleanExtra("enableDomStorage", false);
        Bundle bundleExtra = intent.getBundleExtra("com.android.browser.headers");
        if (bundleExtra == null) {
            map = Collections.EMPTY_MAP;
        } else {
            HashMap map2 = new HashMap();
            for (String str : bundleExtra.keySet()) {
                map2.put(str, bundleExtra.getString(str));
            }
            map = map2;
        }
        this.f3434h.loadUrl(stringExtra, map);
        this.f3434h.getSettings().setJavaScriptEnabled(booleanExtra);
        this.f3434h.getSettings().setDomStorageEnabled(booleanExtra2);
        this.f3434h.setWebViewClient(this.f3433g);
        this.f3434h.getSettings().setSupportMultipleWindows(true);
        this.f3434h.setWebChromeClient(new C0583i(this));
        AbstractC0436x.w(this, this.f3432f, this.f3435i, 2);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.f3432f);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 != 4 || !this.f3434h.canGoBack()) {
            return super.onKeyDown(i2, keyEvent);
        }
        this.f3434h.goBack();
        return true;
    }
}
