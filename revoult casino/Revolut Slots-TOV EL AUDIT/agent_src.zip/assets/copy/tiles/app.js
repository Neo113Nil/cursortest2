(function () {
  "use strict";

  var STORAGE_KEY = "perfora.plays";
  var INK_COLORS = ["#1a3a8f", "#8e1f1f", "#2e7d32", "#6a1b9a", "#b26a00", "#37474f"];

  var plays = loadPlays();
  var activeTab = "scoreboard";
  var editingId = null;

  var $ = function (id) { return document.getElementById(id); };

  var els = {
    app: $("app"),
    toast: $("toast"),
    monthCount: $("monthCount"),
    lastWinner: $("lastWinner"),
    recentList: $("recentList"),
    searchInput: $("searchInput"),
    journalList: $("journalList"),
    playForm: $("playForm"),
    playId: $("playId"),
    gameTitle: $("gameTitle"),
    playDate: $("playDate"),
    players: $("players"),
    scores: $("scores"),
    formError: $("formError"),
    submitBtn: $("submitBtn"),
    cancelEditBtn: $("cancelEditBtn"),
    totalPlays: $("totalPlays"),
    mostPlayed: $("mostPlayed")
  };

  /* ---------- Storage ---------- */

  function loadPlays() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return seedPlays();
  }

  function savePlays() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(plays));
    } catch (e) {
      toast("Could not save (storage full)");
    }
  }

  function seedPlays() {
    var d = new Date();
    var today = toDate(d);
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var prevMonth = m === "01" ? (y - 1) + "-12" : y + "-" + String(d.getMonth()).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    var monthDay = m + "-" + day;

    return [
      {
        id: uid(),
        game_title: "Catan",
        date: prevMonth + "-15",
        players: "Alice, Bob, Cara",
        scores: "Alice 95, Bob 82, Cara 104"
      },
      {
        id: uid(),
        game_title: "Wingspan",
        date: y + "-" + monthDay,
        players: "Mina, Jo, Tom",
        scores: "Mina 88, Jo 97, Tom 91"
      },
      {
        id: uid(),
        game_title: "Scrabble",
        date: today,
        players: "Sam, Rita",
        scores: "Sam 312, Rita 289"
      }
    ];
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function toDate(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return y + "-" + m + "-" + day;
  }

  /* ---------- Tabs ---------- */

  function initTabs() {
    var coils = document.querySelectorAll(".coil");
    coils.forEach(function (coil) {
      coil.addEventListener("click", function () {
        switchTab(coil.getAttribute("data-tab"));
      });
    });
  }

  function switchTab(tab) {
    activeTab = tab;
    document.querySelectorAll(".coil").forEach(function (c) {
      c.classList.toggle("active", c.getAttribute("data-tab") === tab);
    });
    document.querySelectorAll(".page").forEach(function (p) {
      p.classList.toggle("active", p.id === "tab-" + tab);
    });
    els.app.scrollTop = 0;
    render();
  }

  /* ---------- Helpers ---------- */

  function formatDate(s) {
    if (!s) return "";
    var parts = s.split("-");
    if (parts.length !== 3) return s;
    var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    var mi = parseInt(parts[1], 10) - 1;
    return (months[mi] || parts[1]) + " " + parseInt(parts[2], 10) + ", " + parts[0];
  }

  function inCurrentMonth(dateStr) {
    if (!dateStr) return false;
    var now = new Date();
    var prefix = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
    return dateStr.indexOf(prefix) === 0;
  }

  function highestNameScores(play) {
    var pairs = parseScorePairs(play.scores);
    if (!pairs.length) return { name: null, score: null };
    var best = pairs[0];
    pairs.forEach(function (p) { if (p.score > best.score) best = p; });
    return best;
  }

  function parseScorePairs(scores) {
    var out = [];
    var parts = String(scores || "").split(",");
    parts.forEach(function (part) {
      var m = part.trim().match(/^(.*?)\s+([-+]?\d+(?:\.\d+)?)$/);
      if (m) {
        out.push({ name: m[1].trim(), score: parseFloat(m[2]) });
      }
    });
    return out;
  }

  function mostPlayedTitle() {
    if (!plays.length) return "—";
    var counts = {};
    plays.forEach(function (p) { counts[p.game_title] = (counts[p.game_title] || 0) + 1; });
    var best = null;
    Object.keys(counts).forEach(function (k) {
      if (!best || counts[k] > counts[best]) best = k;
    });
    return best;
  }

  /* ---------- Rendering ---------- */

  function render() {
    if (activeTab === "scoreboard") renderScoreboard();
    if (activeTab === "journal") renderJournal();
    if (activeTab === "insights") renderInsights();
  }

  function renderScoreboard() {
    var monthCount = plays.filter(function (p) { return inCurrentMonth(p.date); }).length;
    els.monthCount.textContent = monthCount;

    var sorted = plays.slice().sort(function (a, b) {
      return String(b.date).localeCompare(String(a.date));
    });
    var latest = sorted[0];
    els.lastWinner.textContent = latest ? (highestNameScores(latest).name || "—") : "—";

    var recent = sorted.slice(0, 3);
    els.recentList.innerHTML = "";
    if (!recent.length) {
      els.recentList.innerHTML = '<div class="ghost"><div class="ghost-sheet"></div></div>';
      return;
    }
    recent.forEach(function (p) {
      var top = highestNameScores(p);
      var el = document.createElement("div");
      el.className = "mini-sheet";
      el.innerHTML =
        '<p class="mini-title">' + esc(p.game_title) + '</p>' +
        '<p class="mini-date">' + esc(formatDate(p.date)) + '</p>' +
        '<p class="mini-top">Top: <b>' + esc(top.name ? top.name : "—") + ' · ' + esc(top.score == null ? "—" : top.score) + '</b></p>';
      el.addEventListener("click", function () {
        openEdit(p.id);
      });
      els.recentList.appendChild(el);
    });
  }

  function renderJournal() {
    var q = (els.searchInput.value || "").trim().toLowerCase();
    var list = plays.slice();
    if (q) {
      list = list.filter(function (p) {
        return String(p.game_title).toLowerCase().indexOf(q) !== -1;
      });
    }
    list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });

    els.journalList.innerHTML = "";
    if (!list.length) {
      els.journalList.innerHTML =
        '<div class="ghost"><div class="ghost-sheet"></div><p>' + (q ? "No matches found" : "No plays yet") + '</p></div>';
      return;
    }
    list.forEach(function (p) {
      els.journalList.appendChild(sheetEl(p));
    });
  }

  function sheetEl(p) {
    var top = highestNameScores(p);
    var wrapper = document.createElement("div");
    wrapper.className = "perf-sheet";
    wrapper.setAttribute("data-id", p.id);

    var pairs = parseScorePairs(p.scores);
    var scoresHtml;
    if (pairs.length) {
      scoresHtml = pairs.map(function (pair, i) {
        var color = INK_COLORS[i % INK_COLORS.length];
        return '<span style="color:' + color + ';font-weight:700;">' + esc(pair.name) +
               ' <span style="font-weight:900;">' + esc(pair.score) + '</span></span>';
      }).join(' &nbsp;·&nbsp; ');
    } else {
      scoresHtml = esc(p.scores);
    }

    var sticker = top.score != null ? '<span class="sticker" title="Winner"></span>' : "";

    wrapper.innerHTML =
      '<div class="tear"></div>' +
      '<div class="sheet-body">' +
        sticker +
        '<p class="sheet-title">' + esc(p.game_title) + '</p>' +
        '<p class="sheet-date">' + esc(formatDate(p.date)) + '</p>' +
        '<p class="sheet-scores">' + scoresHtml + '</p>' +
      '</div>';

    var pressTimer = null;
    wrapper.addEventListener("touchstart", function (e) {
      pressTimer = setTimeout(function () { promptDelete(p); }, 600);
    });
    wrapper.addEventListener("touchend", function () { clearTimeout(pressTimer); });
    wrapper.addEventListener("touchmove", function () { clearTimeout(pressTimer); });
    wrapper.addEventListener("contextmenu", function (e) { e.preventDefault(); promptDelete(p); });
    wrapper.addEventListener("click", function () {
      openEdit(p.id);
    });

    return wrapper;
  }

  function renderInsights() {
    els.totalPlays.textContent = plays.length;
    els.mostPlayed.textContent = mostPlayedTitle();
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /* ---------- CRUD ---------- */

  function openEdit(id) {
    var p = plays.find(function (x) { return x.id === id; });
    if (!p) return;
    editingId = id;
    els.playId.value = id;
    els.gameTitle.value = p.game_title || "";
    els.playDate.value = p.date || "";
    els.players.value = p.players || "";
    els.scores.value = p.scores || "";
    els.formError.textContent = "";
    els.submitBtn.textContent = "Save sheet";
    els.cancelEditBtn.hidden = false;
    switchTab("record");
  }

  function resetForm() {
    editingId = null;
    els.playForm.reset();
    els.formError.textContent = "";
    els.submitBtn.textContent = "Tear off sheet";
    els.cancelEditBtn.hidden = true;
  }

  function validate() {
    var title = els.gameTitle.value.trim();
    var date = els.playDate.value;
    var players = els.players.value.trim();
    var scores = els.scores.value.trim();
    if (!title) return "Please enter a game title.";
    if (!date) return "Please pick a session date.";
    if (!players) return "Please list at least one player.";
    if (!parseScorePairs(scores).length) return "Add at least one name–score pair, e.g. “Alice 95”.";
    return null;
  }

  function submitPlay(e) {
    e.preventDefault();
    var err = validate();
    if (err) {
      els.formError.textContent = err;
      return;
    }
    var data = {
      id: editingId || uid(),
      game_title: els.gameTitle.value.trim(),
      date: els.playDate.value,
      players: els.players.value.trim(),
      scores: els.scores.value.trim()
    };
    if (editingId) {
      var idx = plays.findIndex(function (x) { return x.id === editingId; });
      if (idx !== -1) plays[idx] = data;
      toast("Sheet saved");
    } else {
      plays.push(data);
      toast("Added to journal");
    }
    savePlays();
    resetForm();
    render();
    switchTab("journal");
  }

  function promptDelete(p) {
    if (confirm("Delete the “" + p.game_title + "” sheet?")) {
      plays = plays.filter(function (x) { return x.id !== p.id; });
      if (editingId === p.id) resetForm();
      savePlays();
      render();
      toast("Sheet deleted");
    }
  }

  /* ---------- Toast ---------- */

  var toastTimer = null;
  function toast(msg) {
    els.toast.textContent = msg;
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { els.toast.classList.remove("show"); }, 1800);
  }

  /* ---------- Init ---------- */

  els.searchInput.addEventListener("input", renderJournal);

  els.playForm.addEventListener("submit", submitPlay);
  els.cancelEditBtn.addEventListener("click", function () {
    resetForm();
    render();
  });
  $("logQuickBtn").addEventListener("click", function () {
    resetForm();
    switchTab("record");
  });

  initTabs();
  render();

  if (editingId === null) resetForm();
})();