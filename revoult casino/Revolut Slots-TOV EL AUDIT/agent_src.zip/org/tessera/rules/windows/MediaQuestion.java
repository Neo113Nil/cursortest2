package org.tessera.rules.windows;

/* compiled from: PageMenus.groovy */
/* loaded from: classes.dex */
public final class MediaQuestion implements java.lang.Runnable {
    private final org.tessera.rules.windows.PlatformGrants grants;
    private final android.webkit.PermissionRequest request;
    private final android.webkit.WebView source;

    public MediaQuestion(org.tessera.rules.windows.PlatformGrants platformGrants, android.webkit.WebView webView, android.webkit.PermissionRequest permissionRequest) {
        this.grants = platformGrants;
        this.source = webView;
        this.request = permissionRequest;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.grants.askMedia(this.source, this.request);
    }
}
