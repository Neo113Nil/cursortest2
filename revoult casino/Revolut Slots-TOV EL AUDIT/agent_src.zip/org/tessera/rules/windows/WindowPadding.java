package org.tessera.rules.windows;

/* compiled from: WindowPadding.groovy */
/* loaded from: classes.dex */
public final class WindowPadding implements android.view.View.OnApplyWindowInsetsListener {
    @groovy.transform.Generated
    public WindowPadding() {
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public android.view.WindowInsets onApplyWindowInsets(android.view.View view, android.view.WindowInsets windowInsets) {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets insets = windowInsets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
            view.setPadding(insets.left, insets.top, insets.right, java.lang.Math.max(insets.bottom, windowInsets.getInsets(android.view.WindowInsets.Type.ime()).bottom));
            return windowInsets;
        }
        view.setPadding(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        return windowInsets;
    }
}
