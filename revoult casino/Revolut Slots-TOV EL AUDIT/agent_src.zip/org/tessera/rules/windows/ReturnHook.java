package org.tessera.rules.windows;

/* compiled from: WindowPadding.groovy */
/* loaded from: classes.dex */
public final class ReturnHook implements android.window.OnBackInvokedCallback, java.lang.Runnable {
    private final java.lang.Runnable action;
    private final android.window.OnBackInvokedDispatcher dispatcher;

    private ReturnHook(android.window.OnBackInvokedDispatcher onBackInvokedDispatcher, java.lang.Runnable runnable) {
        this.dispatcher = onBackInvokedDispatcher;
        this.action = runnable;
    }

    public static java.lang.Runnable bind(android.view.Window window, java.lang.Runnable runnable) {
        org.tessera.rules.windows.ReturnHook returnHook = new org.tessera.rules.windows.ReturnHook(window.getOnBackInvokedDispatcher(), runnable);
        returnHook.dispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, returnHook);
        return returnHook;
    }

    @Override // android.window.OnBackInvokedCallback
    public void onBackInvoked() {
        this.action.run();
    }

    @Override // java.lang.Runnable
    public void run() {
        this.dispatcher.unregisterOnBackInvokedCallback(this);
    }
}
