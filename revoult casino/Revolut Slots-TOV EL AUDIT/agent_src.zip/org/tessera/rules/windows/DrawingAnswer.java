package org.tessera.rules.windows;

/* compiled from: PageObservations.groovy */
/* loaded from: classes.dex */
public final class DrawingAnswer implements android.webkit.ValueCallback<java.lang.String> {
    private final java.util.function.BiConsumer<java.lang.String, java.lang.Boolean> answer;
    private final org.tessera.rules.EntryWindow room;

    public DrawingAnswer(org.tessera.rules.EntryWindow entryWindow, java.util.function.BiConsumer<java.lang.String, java.lang.Boolean> biConsumer) {
        this.room = entryWindow;
        this.answer = biConsumer;
    }

    @Override // android.webkit.ValueCallback
    public void onReceiveValue(java.lang.String str) {
        if (this.room.isRetired()) {
            return;
        }
        this.answer.accept(org.tessera.rules.EntryWindow.clean(this.room.getSheet().getUrl()), java.lang.Boolean.valueOf("true".equals(str)));
    }
}
