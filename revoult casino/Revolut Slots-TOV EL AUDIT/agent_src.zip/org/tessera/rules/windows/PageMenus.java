package org.tessera.rules.windows;

/* compiled from: PageMenus.groovy */
/* loaded from: classes.dex */
public final class PageMenus extends android.webkit.WebChromeClient {
    private final org.tessera.rules.EntryWindow room;
    private final android.webkit.WebView source;

    public PageMenus(org.tessera.rules.EntryWindow entryWindow, android.webkit.WebView webView) {
        this.room = entryWindow;
        this.source = webView;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onCreateWindow(android.webkit.WebView webView, boolean z, boolean z2, android.os.Message message) {
        return this.room.getDialogs().create(message);
    }

    @Override // android.webkit.WebChromeClient
    public void onCloseWindow(android.webkit.WebView webView) {
        this.room.getDialogs().discard(webView);
    }

    @Override // android.webkit.WebChromeClient
    public boolean onShowFileChooser(android.webkit.WebView webView, android.webkit.ValueCallback<android.net.Uri[]> valueCallback, android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {
        this.room.getGrants().choose(webView, valueCallback, fileChooserParams);
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public void onPermissionRequest(android.webkit.PermissionRequest permissionRequest) {
        this.room.runOnUiThread(new org.tessera.rules.windows.MediaQuestion(this.room.getGrants(), this.source, permissionRequest));
    }

    @Override // android.webkit.WebChromeClient
    public void onPermissionRequestCanceled(android.webkit.PermissionRequest permissionRequest) {
        this.room.getGrants().cancelMedia(permissionRequest);
    }

    @Override // android.webkit.WebChromeClient
    public void onShowCustomView(android.view.View view, android.webkit.WebChromeClient.CustomViewCallback customViewCallback) {
        this.room.showCinema(view, customViewCallback);
    }

    @Override // android.webkit.WebChromeClient
    public void onHideCustomView() {
        this.room.closeCinema();
    }
}
