package org.tessera.rules.windows;

/* compiled from: PageObservations.groovy */
/* loaded from: classes.dex */
public final class PendingDocumentNotice implements java.lang.Runnable {
    private final java.lang.String destination;
    private final android.webkit.WebView page;
    private final org.tessera.rules.EntryWindow room;

    public PendingDocumentNotice(org.tessera.rules.EntryWindow entryWindow, android.webkit.WebView webView, java.lang.String str) {
        this.room = entryWindow;
        this.page = webView;
        this.destination = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.room.principal(this.page)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getBEGIN(), this.destination));
        }
    }
}
