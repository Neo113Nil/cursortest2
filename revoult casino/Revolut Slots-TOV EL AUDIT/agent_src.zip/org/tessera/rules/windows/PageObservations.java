package org.tessera.rules.windows;

/* compiled from: PageObservations.groovy */
/* loaded from: classes.dex */
public final class PageObservations extends android.webkit.WebViewClient {
    private static /* synthetic */ long $const$0 = 4281674018L;
    private final org.tessera.rules.EntryWindow room;
    private final boolean root;

    public PageObservations(org.tessera.rules.EntryWindow entryWindow, boolean z) {
        this.room = entryWindow;
        this.root = z;
    }

    public static void wire(org.tessera.rules.EntryWindow entryWindow, android.webkit.WebView webView, boolean z) {
        android.webkit.WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setBackgroundColor((int) $const$0);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new org.tessera.rules.windows.PageObservations(entryWindow, z));
        webView.setWebChromeClient(new org.tessera.rules.windows.PageMenus(entryWindow, webView));
        webView.setDownloadListener(new org.tessera.rules.windows.DocumentDownload(entryWindow, webView, z));
    }

    private boolean current(android.webkit.WebView webView) {
        return this.root && this.room.principal(webView);
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest) {
        if (current(webView) && webResourceRequest.isForMainFrame() && webResourceRequest.isRedirect()) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getREDIRECT(), webResourceRequest.getUrl().toString(), "", true));
        }
        return this.room.getGrants().openProtocol(webView, webResourceRequest.getUrl().toString());
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, java.lang.String str) {
        return this.room.getGrants().openProtocol(webView, str);
    }

    @Override // android.webkit.WebViewClient
    public android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest) {
        if (this.root && webResourceRequest.isForMainFrame()) {
            webView.post(new org.tessera.rules.windows.PendingDocumentNotice(this.room, webView, webResourceRequest.getUrl().toString()));
        }
        return this.room.getVaultLoader().shouldInterceptRequest(webResourceRequest.getUrl());
    }

    @Override // android.webkit.WebViewClient
    public void onPageStarted(android.webkit.WebView webView, java.lang.String str, android.graphics.Bitmap bitmap) {
        if (current(webView)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getBEGIN(), str));
        }
    }

    @Override // android.webkit.WebViewClient
    public void doUpdateVisitedHistory(android.webkit.WebView webView, java.lang.String str, boolean z) {
        if (current(webView)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getHISTORY(), str, org.tessera.rules.EntryWindow.clean(webView.getUrl())));
            ready(webView, str);
        }
    }

    private void ready(android.webkit.WebView webView, java.lang.String str) {
        if (current(webView)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getREADY(), str, org.tessera.rules.EntryWindow.clean(webView.getUrl())));
        }
    }

    @Override // android.webkit.WebViewClient
    public void onPageCommitVisible(android.webkit.WebView webView, java.lang.String str) {
        ready(webView, str);
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(android.webkit.WebView webView, java.lang.String str) {
        ready(webView, str);
        if (current(webView) && org.tessera.rules.EntryWindow.getCOPY().equals(str) && str.equals(webView.getUrl())) {
            webView.evaluateJavascript("if(!window.__tesseraReturn){window.__tesseraReturn=true;addEventListener('online',()=>location.href='tessera-return:online')}", null);
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedError(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest, android.webkit.WebResourceError webResourceError) {
        if (current(webView)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getFAILED(), webResourceRequest.getUrl().toString(), "", webResourceRequest.isForMainFrame()));
        } else if (webResourceRequest.isForMainFrame()) {
            this.room.getDialogs().discard(webView);
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedSslError(android.webkit.WebView webView, android.webkit.SslErrorHandler sslErrorHandler, android.net.http.SslError sslError) {
        sslErrorHandler.cancel();
        if (current(webView)) {
            this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getFAILED(), sslError.getUrl(), "", true));
        } else {
            this.room.getDialogs().discard(webView);
        }
    }

    @Override // android.webkit.WebViewClient
    public boolean onRenderProcessGone(android.webkit.WebView webView, android.webkit.RenderProcessGoneDetail renderProcessGoneDetail) {
        this.room.rendererLost(webView);
        return true;
    }
}
