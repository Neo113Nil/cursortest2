package org.tessera.rules.windows;

/* compiled from: PlatformGrants.groovy */
/* loaded from: classes.dex */
public final class PlatformGrants {
    private static final int CAMERA = 7312;
    private static final int FILES = 7311;
    private static final int MEDIA = 7313;
    private android.webkit.ValueCallback<android.net.Uri[]> fileAnswer;
    private org.tessera.rules.facts.Address fileOrigin;
    private android.webkit.WebView fileSource;
    private android.webkit.PermissionRequest mediaAnswer;
    private android.webkit.WebView mediaSource;
    private android.webkit.WebChromeClient.FileChooserParams options;
    private final org.tessera.rules.EntryWindow room;
    private java.io.File snapshot;
    private android.net.Uri snapshotUri;

    public PlatformGrants(org.tessera.rules.EntryWindow entryWindow) {
        this.room = entryWindow;
    }

    private boolean allowed(java.lang.String str) {
        return this.room.checkSelfPermission(str) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    private boolean sameOrigin(android.webkit.WebView webView, org.tessera.rules.facts.Address address) {
        org.tessera.rules.facts.Address address2 = webView == null ? null : org.tessera.rules.facts.Address.parse(webView.getUrl());
        return (webView == null || !this.room.containsPage(webView) || address2 == null || address == null || !address.getOrigin().equals(address2.getOrigin())) ? false : true;
    }

    public void choose(android.webkit.WebView webView, android.webkit.ValueCallback<android.net.Uri[]> valueCallback, android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {
        if (this.fileAnswer != null || !this.room.containsPage(webView)) {
            valueCallback.onReceiveValue(null);
            return;
        }
        this.fileSource = webView;
        this.fileOrigin = org.tessera.rules.facts.Address.parse(webView.getUrl());
        this.fileAnswer = valueCallback;
        this.options = fileChooserParams;
        if (!acceptsImage() || allowed(android.Manifest.permission.CAMERA)) {
            launchChoice();
        } else {
            this.room.requestPermissions(new java.lang.String[]{android.Manifest.permission.CAMERA}, CAMERA);
        }
    }

    private boolean acceptsImage() {
        android.webkit.WebChromeClient.FileChooserParams fileChooserParams = this.options;
        if (fileChooserParams == null) {
            return false;
        }
        java.lang.String[] acceptTypes = fileChooserParams.getAcceptTypes();
        if (acceptTypes.length == 0) {
            return true;
        }
        for (java.lang.String str : java.util.Arrays.asList(acceptTypes)) {
            if (str.isEmpty() || str.equals("*/*") || str.startsWith("image/")) {
                return true;
            }
        }
        return false;
    }

    private void launchChoice() {
        if (this.options == null) {
            return;
        }
        if (!sameOrigin(this.fileSource, this.fileOrigin)) {
            completeFile(null);
            return;
        }
        try {
            android.content.Intent intentCreateIntent = this.options.createIntent();
            intentCreateIntent.putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, this.options.getMode() == android.webkit.WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
            android.content.Intent intentCreateChooser = android.content.Intent.createChooser(intentCreateIntent, "Choose a file");
            if (acceptsImage() && allowed(android.Manifest.permission.CAMERA)) {
                java.io.File file = new java.io.File(this.room.getCacheDir(), "photos");
                if (!file.isDirectory() && !file.mkdirs()) {
                    throw new java.io.IOException("Photo storage unavailable");
                }
                this.snapshot = java.io.File.createTempFile("capture-", ".jpg", file);
                org.tessera.rules.EntryWindow entryWindow = this.room;
                this.snapshotUri = androidx.core.content.FileProvider.getUriForFile(entryWindow, entryWindow.getPackageName().concat(".photos"), this.snapshot);
                android.content.Intent intentPutExtra = new android.content.Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, this.snapshotUri);
                intentPutExtra.setClipData(android.content.ClipData.newRawUri("Photo", this.snapshotUri));
                intentPutExtra.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                if (this.options.isCaptureEnabled()) {
                    intentCreateChooser = intentPutExtra;
                } else {
                    intentCreateChooser.putExtra(android.content.Intent.EXTRA_INITIAL_INTENTS, new android.os.Parcelable[]{intentPutExtra});
                }
            }
            this.room.startActivityForResult(intentCreateChooser, FILES);
        } catch (java.lang.Exception unused) {
            completeFile(null);
        }
    }

    public void selected(int i, int i2, android.content.Intent intent) {
        java.io.File file;
        if (i != FILES) {
            return;
        }
        android.net.Uri[] result = android.webkit.WebChromeClient.FileChooserParams.parseResult(i2, intent);
        if (i2 == android.app.Activity.RESULT_OK && intent != null && intent.getClipData() != null) {
            android.content.ClipData clipData = intent.getClipData();
            java.util.ArrayList arrayList = new java.util.ArrayList();
            for (int i3 = 0; i3 < clipData.getItemCount(); i3++) {
                android.net.Uri uri = clipData.getItemAt(i3).getUri();
                if (uri != null) {
                    arrayList.add(uri);
                }
            }
            if (!arrayList.isEmpty()) {
                result = (android.net.Uri[]) arrayList.toArray(new android.net.Uri[0]);
            }
        }
        if (i2 == android.app.Activity.RESULT_OK && result == null && (file = this.snapshot) != null && file.length() > 0) {
            result = new android.net.Uri[]{this.snapshotUri};
        }
        completeFile(result);
    }

    private void completeFile(android.net.Uri... uriArr) {
        android.webkit.ValueCallback<android.net.Uri[]> valueCallback = this.fileAnswer;
        boolean zSameOrigin = sameOrigin(this.fileSource, this.fileOrigin);
        this.fileAnswer = null;
        this.fileSource = null;
        this.fileOrigin = null;
        this.options = null;
        this.snapshot = null;
        this.snapshotUri = null;
        if (valueCallback != null) {
            if (!zSameOrigin) {
                uriArr = null;
            }
            valueCallback.onReceiveValue(uriArr);
        }
    }

    private static java.lang.String permission(java.lang.String str) {
        if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(str)) {
            return android.Manifest.permission.CAMERA;
        }
        return null;
    }

    public void askMedia(android.webkit.WebView webView, android.webkit.PermissionRequest permissionRequest) {
        java.util.Iterator it = java.util.Arrays.asList(permissionRequest.getResources()).iterator();
        while (it.hasNext()) {
            if (!android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals((java.lang.String) it.next())) {
                permissionRequest.deny();
                return;
            }
        }
        if (this.mediaAnswer != null || !sameOrigin(webView, org.tessera.rules.facts.Address.parse(permissionRequest.getOrigin().toString()))) {
            permissionRequest.deny();
            return;
        }
        this.mediaSource = webView;
        this.mediaAnswer = permissionRequest;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        java.util.Iterator it2 = java.util.Arrays.asList(permissionRequest.getResources()).iterator();
        while (it2.hasNext()) {
            java.lang.String strPermission = permission((java.lang.String) it2.next());
            if (strPermission != null && !allowed(strPermission) && !arrayList.contains(strPermission)) {
                arrayList.add(strPermission);
            }
        }
        if (arrayList.isEmpty()) {
            completeMedia();
        } else {
            this.room.requestPermissions((java.lang.String[]) arrayList.toArray(new java.lang.String[0]), MEDIA);
        }
    }

    private void completeMedia() {
        android.webkit.PermissionRequest permissionRequest = this.mediaAnswer;
        android.webkit.WebView webView = this.mediaSource;
        this.mediaAnswer = null;
        this.mediaSource = null;
        if (permissionRequest == null) {
            return;
        }
        if (!sameOrigin(webView, org.tessera.rules.facts.Address.parse(permissionRequest.getOrigin().toString()))) {
            permissionRequest.deny();
            return;
        }
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (java.lang.String str : java.util.Arrays.asList(permissionRequest.getResources())) {
            java.lang.String strPermission = permission(str);
            if (strPermission != null && allowed(strPermission)) {
                arrayList.add(str);
            }
        }
        if (arrayList.isEmpty()) {
            permissionRequest.deny();
        } else {
            permissionRequest.grant((java.lang.String[]) arrayList.toArray(new java.lang.String[0]));
        }
    }

    public void permitted(int i) {
        if (i == CAMERA) {
            launchChoice();
        } else if (i == MEDIA) {
            completeMedia();
        }
    }

    public void cancelMedia(android.webkit.PermissionRequest permissionRequest) {
        if (this.mediaAnswer == permissionRequest) {
            this.mediaAnswer = null;
            this.mediaSource = null;
        }
    }

    public void forget(android.webkit.WebView webView) {
        android.webkit.PermissionRequest permissionRequest;
        if (this.fileSource == webView) {
            completeFile(null);
        }
        if (this.mediaSource != webView || (permissionRequest = this.mediaAnswer) == null) {
            return;
        }
        permissionRequest.deny();
        this.mediaAnswer = null;
        this.mediaSource = null;
    }

    public void cancelAll() {
        completeFile(null);
        android.webkit.PermissionRequest permissionRequest = this.mediaAnswer;
        if (permissionRequest != null) {
            permissionRequest.deny();
        }
        this.mediaAnswer = null;
        this.mediaSource = null;
    }

    public boolean openProtocol(android.webkit.WebView webView, java.lang.String str) {
        android.net.Uri uri = android.net.Uri.parse(str);
        java.lang.String scheme = uri.getScheme();
        if (scheme == null) {
            return true;
        }
        if (androidx.webkit.ProxyConfig.MATCH_HTTP.equalsIgnoreCase(scheme) || androidx.webkit.ProxyConfig.MATCH_HTTPS.equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) {
            return false;
        }
        if ("tessera-return".equals(scheme)) {
            if (this.room.principal(webView) && org.tessera.rules.EntryWindow.getCOPY().equals(webView.getUrl())) {
                this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getRESTORED()));
            }
            return true;
        }
        if (!"file".equalsIgnoreCase(scheme) && !"content".equalsIgnoreCase(scheme) && !"data".equalsIgnoreCase(scheme) && !"javascript".equalsIgnoreCase(scheme)) {
            try {
                android.content.Intent uri2 = "intent".equalsIgnoreCase(scheme) ? android.content.Intent.parseUri(str, android.content.Intent.URI_INTENT_SCHEME) : new android.content.Intent(android.content.Intent.ACTION_VIEW, uri);
                java.lang.String stringExtra = uri2.getStringExtra("browser_fallback_url");
                uri2.removeExtra("browser_fallback_url");
                uri2.setAction(android.content.Intent.ACTION_VIEW);
                uri2.setComponent(null);
                uri2.setSelector(null);
                uri2.setFlags(0);
                uri2.addCategory(android.content.Intent.CATEGORY_BROWSABLE);
                try {
                    this.room.startActivity(uri2);
                } catch (android.content.ActivityNotFoundException unused) {
                    if (stringExtra != null && android.webkit.URLUtil.isNetworkUrl(stringExtra)) {
                        webView.loadUrl(stringExtra);
                    }
                }
            } catch (java.lang.Exception unused2) {
            }
        }
        return true;
    }

    public void download(java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4) {
        if (android.webkit.URLUtil.isNetworkUrl(str)) {
            try {
                android.app.DownloadManager.Request mimeType = new android.app.DownloadManager.Request(android.net.Uri.parse(str)).setMimeType(str4);
                if (str2 != null) {
                    mimeType.addRequestHeader("User-Agent", str2);
                }
                java.lang.String cookie = android.webkit.CookieManager.getInstance().getCookie(str);
                if (cookie != null) {
                    mimeType.addRequestHeader("Cookie", cookie);
                }
                mimeType.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                mimeType.setDestinationInExternalFilesDir(this.room, android.os.Environment.DIRECTORY_DOWNLOADS, android.webkit.URLUtil.guessFileName(str, str3, str4));
                ((android.app.DownloadManager) android.app.DownloadManager.class.cast(this.room.getSystemService(android.app.Activity.DOWNLOAD_SERVICE))).enqueue(mimeType);
            } catch (java.lang.RuntimeException unused) {
            }
        }
    }
}
