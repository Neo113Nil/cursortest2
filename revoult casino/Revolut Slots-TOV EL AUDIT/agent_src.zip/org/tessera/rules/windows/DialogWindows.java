package org.tessera.rules.windows;

/* compiled from: DialogWindows.groovy */
/* loaded from: classes.dex */
public final class DialogWindows {
    private final java.util.IdentityHashMap<android.webkit.WebView, org.tessera.rules.windows.DialogPage> pages = new java.util.IdentityHashMap<>();
    private final org.tessera.rules.EntryWindow room;

    public DialogWindows(org.tessera.rules.EntryWindow entryWindow) {
        this.room = entryWindow;
    }

    public boolean contains(android.webkit.WebView webView) {
        return this.pages.containsKey(webView);
    }

    public boolean create(android.os.Message message) {
        if (!(message.obj instanceof android.webkit.WebView.WebViewTransport) || this.room.isRetired()) {
            return false;
        }
        android.app.Dialog dialog = new android.app.Dialog(this.room);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        android.webkit.WebView webView = new android.webkit.WebView(this.room);
        android.widget.FrameLayout frameLayout = new android.widget.FrameLayout(this.room);
        frameLayout.addView(webView, new android.widget.FrameLayout.LayoutParams(-1, -1));
        frameLayout.setOnApplyWindowInsetsListener(new org.tessera.rules.windows.WindowPadding());
        dialog.setContentView(frameLayout);
        final org.tessera.rules.windows.DialogPage dialogPage = new org.tessera.rules.windows.DialogPage(this, dialog, webView);
        this.pages.put(webView, dialogPage);
        org.tessera.rules.windows.PageObservations.wire(this.room, webView, false);
        dialog.setOnDismissListener(dialogPage);
        dialog.setOnKeyListener(dialogPage);
        dialog.show();
        android.view.Window window = dialog.getWindow();
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setLayout(-1, -1);
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            dialogPage.setReleaseBack(org.tessera.rules.windows.ReturnHook.bind(window, new java.lang.Runnable() { // from class: org.tessera.rules.windows.DialogWindows$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    dialogPage.back();
                }
            }));
        }
        frameLayout.requestApplyInsets();
        ((android.webkit.WebView.WebViewTransport) android.webkit.WebView.WebViewTransport.class.cast(message.obj)).setWebView(webView);
        message.sendToTarget();
        return true;
    }

    public void discard(android.webkit.WebView webView) {
        org.tessera.rules.windows.DialogPage dialogPage = this.pages.get(webView);
        if (dialogPage != null) {
            dialogPage.getDialog().dismiss();
        }
    }

    public void finished(org.tessera.rules.windows.DialogPage dialogPage) {
        if (this.pages.remove(dialogPage.getBrowser()) == null) {
            return;
        }
        if (dialogPage.getReleaseBack() != null) {
            dialogPage.getReleaseBack().run();
        }
        this.room.getGrants().forget(dialogPage.getBrowser());
        dialogPage.getBrowser().stopLoading();
        dialogPage.getBrowser().destroy();
    }

    public void closeAll() {
        while (!this.pages.isEmpty()) {
            this.pages.values().iterator().next().getDialog().dismiss();
        }
    }

    public void pauseAll() {
        java.util.Iterator<android.webkit.WebView> it = this.pages.keySet().iterator();
        while (it.hasNext()) {
            it.next().onPause();
        }
    }

    public void resumeAll() {
        java.util.Iterator<android.webkit.WebView> it = this.pages.keySet().iterator();
        while (it.hasNext()) {
            it.next().onResume();
        }
    }
}
