package org.tessera.rules.windows;

/* compiled from: DialogWindows.groovy */
/* loaded from: classes.dex */
public final class DialogPage implements android.content.DialogInterface.OnDismissListener, android.content.DialogInterface.OnKeyListener {
    private final android.webkit.WebView browser;
    private final android.app.Dialog dialog;
    private final org.tessera.rules.windows.DialogWindows owner;
    private java.lang.Runnable releaseBack;

    @groovy.transform.Generated
    public android.webkit.WebView getBrowser() {
        return this.browser;
    }

    @groovy.transform.Generated
    public android.app.Dialog getDialog() {
        return this.dialog;
    }

    @groovy.transform.Generated
    public org.tessera.rules.windows.DialogWindows getOwner() {
        return this.owner;
    }

    @groovy.transform.Generated
    public java.lang.Runnable getReleaseBack() {
        return this.releaseBack;
    }

    @groovy.transform.Generated
    public void setReleaseBack(java.lang.Runnable runnable) {
        this.releaseBack = runnable;
    }

    public DialogPage(org.tessera.rules.windows.DialogWindows dialogWindows, android.app.Dialog dialog, android.webkit.WebView webView) {
        this.owner = dialogWindows;
        this.dialog = dialog;
        this.browser = webView;
    }

    public void back() {
        if (this.browser.canGoBack()) {
            this.browser.goBack();
        } else {
            this.dialog.dismiss();
        }
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(android.content.DialogInterface dialogInterface) {
        this.owner.finished(this);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(android.content.DialogInterface dialogInterface, int i, android.view.KeyEvent keyEvent) {
        if (i != android.view.KeyEvent.KEYCODE_BACK) {
            return false;
        }
        if (keyEvent.getAction() != android.view.KeyEvent.ACTION_UP) {
            return true;
        }
        back();
        return true;
    }
}
