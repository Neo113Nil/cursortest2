package org.tessera.rules.windows;

/* compiled from: PageObservations.groovy */
/* loaded from: classes.dex */
public final class DocumentDownload implements android.webkit.DownloadListener {
    private final android.webkit.WebView page;
    private final org.tessera.rules.EntryWindow room;
    private final boolean root;

    public DocumentDownload(org.tessera.rules.EntryWindow entryWindow, android.webkit.WebView webView, boolean z) {
        this.room = entryWindow;
        this.page = webView;
        this.root = z;
    }

    @Override // android.webkit.DownloadListener
    public void onDownloadStart(java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, long j) {
        try {
            this.room.getGrants().download(str, str2, str3, str4);
        } finally {
            if (this.root && this.room.principal(this.page)) {
                this.room.getPolicy().hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getATTACHMENT(), str, org.tessera.rules.EntryWindow.clean(this.page.getUrl())));
            }
        }
    }
}
