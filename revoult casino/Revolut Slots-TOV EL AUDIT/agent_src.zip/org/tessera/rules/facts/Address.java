package org.tessera.rules.facts;

/* compiled from: Address.groovy */
/* loaded from: classes.dex */
public final class Address {
    private final java.lang.String document;
    private final java.lang.String origin;
    private final java.lang.String raw;

    @groovy.transform.Generated
    public java.lang.String getDocument() {
        return this.document;
    }

    @groovy.transform.Generated
    public java.lang.String getOrigin() {
        return this.origin;
    }

    @groovy.transform.Generated
    public java.lang.String getRaw() {
        return this.raw;
    }

    private Address(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        this.raw = str;
        this.document = str2;
        this.origin = str3;
    }

    public static org.tessera.rules.facts.Address parse(java.lang.String str) {
        if (str == null) {
            return null;
        }
        try {
            java.net.URI uri = new java.net.URI(str);
            java.lang.String strConcat = "";
            java.lang.String lowerCase = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
            java.lang.String lowerCase2 = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
            if ((lowerCase.equals(androidx.webkit.ProxyConfig.MATCH_HTTPS) || lowerCase.equals(androidx.webkit.ProxyConfig.MATCH_HTTP)) && !lowerCase2.isEmpty() && uri.getRawUserInfo() == null) {
                int port = uri.getPort();
                if ((lowerCase.equals(androidx.webkit.ProxyConfig.MATCH_HTTPS) && port == 443) || (lowerCase.equals(androidx.webkit.ProxyConfig.MATCH_HTTP) && port == 80)) {
                    port = -1;
                }
                java.lang.String strConcat2 = lowerCase.concat("://").concat(lowerCase2).concat(port < 0 ? "" : ":".concat(java.lang.Integer.toString(port)));
                java.lang.String rawPath = (uri.getRawPath() == null || uri.getRawPath().isEmpty()) ? "/" : uri.getRawPath();
                if (uri.getRawQuery() != null) {
                    strConcat = "?".concat(uri.getRawQuery());
                }
                return new org.tessera.rules.facts.Address(str, strConcat2.concat(rawPath).concat(strConcat), strConcat2);
            }
            return null;
        } catch (java.net.URISyntaxException unused) {
            return null;
        }
    }

    public boolean same(org.tessera.rules.facts.Address address) {
        return address != null && this.document.equals(address.getDocument());
    }
}
