package org.tessera.rules.facts;

/* compiled from: WorkingMemory.groovy */
/* loaded from: classes.dex */
public final class WorkingMemory {
    private long attempt;
    private boolean awaitingArrival;
    private boolean closed;
    private org.tessera.rules.facts.Address document;
    private long edition;
    private final org.tessera.rules.facts.Address entrance;
    private boolean local;
    private final org.tessera.rules.facts.Address packaged;

    @groovy.transform.Generated
    public long getAttempt() {
        return this.attempt;
    }

    @groovy.transform.Generated
    public boolean getAwaitingArrival() {
        return this.awaitingArrival;
    }

    @groovy.transform.Generated
    public boolean getClosed() {
        return this.closed;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Address getDocument() {
        return this.document;
    }

    @groovy.transform.Generated
    public long getEdition() {
        return this.edition;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Address getEntrance() {
        return this.entrance;
    }

    @groovy.transform.Generated
    public boolean getLocal() {
        return this.local;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Address getPackaged() {
        return this.packaged;
    }

    @groovy.transform.Generated
    public boolean isAwaitingArrival() {
        return this.awaitingArrival;
    }

    @groovy.transform.Generated
    public boolean isClosed() {
        return this.closed;
    }

    @groovy.transform.Generated
    public boolean isLocal() {
        return this.local;
    }

    @groovy.transform.Generated
    public void setAttempt(long j) {
        this.attempt = j;
    }

    @groovy.transform.Generated
    public void setAwaitingArrival(boolean z) {
        this.awaitingArrival = z;
    }

    @groovy.transform.Generated
    public void setClosed(boolean z) {
        this.closed = z;
    }

    @groovy.transform.Generated
    public void setDocument(org.tessera.rules.facts.Address address) {
        this.document = address;
    }

    @groovy.transform.Generated
    public void setEdition(long j) {
        this.edition = j;
    }

    @groovy.transform.Generated
    public void setLocal(boolean z) {
        this.local = z;
    }

    public WorkingMemory(java.lang.String str, java.lang.String str2) {
        org.tessera.rules.facts.Address address = org.tessera.rules.facts.Address.parse(str);
        this.entrance = address;
        org.tessera.rules.facts.Address address2 = org.tessera.rules.facts.Address.parse(str2);
        this.packaged = address2;
        if (address == null || address2 == null || address.getOrigin().equals(address2.getOrigin())) {
            throw new java.lang.IllegalArgumentException("Invalid rulebook entrances");
        }
    }

    public void assign(org.tessera.rules.facts.Address address, boolean z) {
        this.document = address;
        this.local = z;
        this.edition++;
    }
}
