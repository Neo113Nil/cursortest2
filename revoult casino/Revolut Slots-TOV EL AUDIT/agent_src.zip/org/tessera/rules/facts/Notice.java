package org.tessera.rules.facts;

/* compiled from: Notice.groovy */
/* loaded from: classes.dex */
public final class Notice {
    private static final int ATTACHMENT = 10;
    private static final int BACK = 8;
    private static final int BEGIN = 2;
    private static final int DEADLINE = 11;
    private static final int DISPOSE = 9;
    private static final int FAILED = 6;
    private static final int HISTORY = 3;
    private static final int MEASURED = 5;
    private static final int OPEN = 1;
    private static final int READY = 4;
    private static final int REDIRECT = 12;
    private static final int RESTORED = 7;
    private final org.tessera.rules.facts.Address address;
    private final org.tessera.rules.facts.Address current;
    private final long edition;
    private final boolean flag;
    private final int kind;

    @groovy.transform.Generated
    public Notice(int i) {
        this(i, "", "", false, 0L);
    }

    @groovy.transform.Generated
    public Notice(int i, java.lang.String str) {
        this(i, str, "", false, 0L);
    }

    @groovy.transform.Generated
    public Notice(int i, java.lang.String str, java.lang.String str2) {
        this(i, str, str2, false, 0L);
    }

    @groovy.transform.Generated
    public Notice(int i, java.lang.String str, java.lang.String str2, boolean z) {
        this(i, str, str2, z, 0L);
    }

    @groovy.transform.Generated
    public static int getATTACHMENT() {
        return ATTACHMENT;
    }

    @groovy.transform.Generated
    public static int getBACK() {
        return BACK;
    }

    @groovy.transform.Generated
    public static int getBEGIN() {
        return BEGIN;
    }

    @groovy.transform.Generated
    public static int getDEADLINE() {
        return DEADLINE;
    }

    @groovy.transform.Generated
    public static int getDISPOSE() {
        return DISPOSE;
    }

    @groovy.transform.Generated
    public static int getFAILED() {
        return FAILED;
    }

    @groovy.transform.Generated
    public static int getHISTORY() {
        return HISTORY;
    }

    @groovy.transform.Generated
    public static int getMEASURED() {
        return MEASURED;
    }

    @groovy.transform.Generated
    public static int getOPEN() {
        return OPEN;
    }

    @groovy.transform.Generated
    public static int getREADY() {
        return READY;
    }

    @groovy.transform.Generated
    public static int getREDIRECT() {
        return REDIRECT;
    }

    @groovy.transform.Generated
    public static int getRESTORED() {
        return RESTORED;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Address getAddress() {
        return this.address;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Address getCurrent() {
        return this.current;
    }

    @groovy.transform.Generated
    public long getEdition() {
        return this.edition;
    }

    @groovy.transform.Generated
    public boolean getFlag() {
        return this.flag;
    }

    @groovy.transform.Generated
    public int getKind() {
        return this.kind;
    }

    @groovy.transform.Generated
    public boolean isFlag() {
        return this.flag;
    }

    public Notice(int i, java.lang.String str, java.lang.String str2, boolean z, long j) {
        this.kind = i;
        this.address = org.tessera.rules.facts.Address.parse(str);
        this.current = org.tessera.rules.facts.Address.parse(str2);
        this.flag = z;
        this.edition = j;
    }
}
