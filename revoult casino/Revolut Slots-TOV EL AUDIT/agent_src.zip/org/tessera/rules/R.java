package org.tessera.rules;

/* loaded from: classes.dex */
public final class R {

    public static final class mipmap {
        public static int ic_launcher = 0x7f080000;
        public static int ic_launcher_foreground = 0x7f080001;
        public static int ic_launcher_raster = 0x7f080002;
        public static int ic_launcher_round = 0x7f080003;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f090001;

        private string() {
        }
    }

    public static final class style {
        public static int TesseraTheme = 0x7f0a0000;

        private style() {
        }
    }

    public static final class xml {
        public static int photo_directory = 0x7f0c0000;

        private xml() {
        }
    }

    private R() {
    }
}
