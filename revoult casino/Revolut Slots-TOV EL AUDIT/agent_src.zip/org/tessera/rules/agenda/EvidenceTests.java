package org.tessera.rules.agenda;

/* compiled from: EvidenceTests.groovy */
/* loaded from: classes.dex */
public final class EvidenceTests {
    @groovy.transform.Generated
    public EvidenceTests() {
    }

    public static boolean redirected(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getREDIRECT()) && hearing.getNotice().isFlag() && hearing.isRemote() && hearing.addressOutsidePackage();
    }

    public static boolean expired(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getDEADLINE()) && hearing.isRemote() && hearing.getMemory().isAwaitingArrival() && hearing.getNotice().getEdition() == hearing.getMemory().getAttempt();
    }

    public static boolean closed(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.getMemory().isClosed();
    }

    public static boolean retire(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getDISPOSE());
    }

    public static boolean open(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getOPEN());
    }

    public static boolean failed(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getFAILED()) && hearing.getNotice().isFlag() && hearing.isRemote() && hearing.matches();
    }

    public static boolean begin(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getBEGIN()) && hearing.isRemote() && hearing.addressOutsidePackage();
    }

    public static boolean history(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getHISTORY()) && hearing.isRemote() && hearing.addressOutsidePackage() && hearing.getNotice().getAddress().same(hearing.getNotice().getCurrent());
    }

    public static boolean attachment(org.tessera.rules.agenda.Hearing hearing) {
        if (hearing.is(org.tessera.rules.facts.Notice.getATTACHMENT()) && hearing.isRemote() && hearing.addressOutsidePackage() && hearing.getNotice().getCurrent() != null && !hearing.getNotice().getCurrent().getOrigin().equals(hearing.getMemory().getPackaged().getOrigin())) {
            return hearing.matches() || hearing.getMemory().getDocument().same(hearing.getNotice().getCurrent());
        }
        return false;
    }

    public static boolean ready(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getREADY()) && hearing.matches() && hearing.getMemory().getDocument().same(hearing.getNotice().getCurrent());
    }

    public static boolean measured(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getMEASURED()) && hearing.getNotice().isFlag() && hearing.getNotice().getEdition() == hearing.getMemory().getEdition() && hearing.matches();
    }

    public static boolean restored(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getRESTORED()) && hearing.hasDocument() && hearing.getMemory().isLocal();
    }

    public static boolean exit(org.tessera.rules.agenda.Hearing hearing) {
        if (hearing.is(org.tessera.rules.facts.Notice.getBACK())) {
            return (hearing.isRemote() && hearing.getNotice().isFlag()) ? false : true;
        }
        return false;
    }

    public static boolean back(org.tessera.rules.agenda.Hearing hearing) {
        return hearing.is(org.tessera.rules.facts.Notice.getBACK()) && hearing.isRemote() && hearing.getNotice().isFlag();
    }
}
