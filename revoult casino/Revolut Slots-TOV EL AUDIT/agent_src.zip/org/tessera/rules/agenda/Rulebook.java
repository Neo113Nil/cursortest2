package org.tessera.rules.agenda;

/* compiled from: Rulebook.groovy */
/* loaded from: classes.dex */
public final class Rulebook {
    private final java.util.List<org.tessera.rules.agenda.Clause> clauses = new java.util.ArrayList();
    private final org.tessera.rules.facts.WorkingMemory memory;
    private final org.tessera.rules.agenda.BrowserActs screen;

    public Rulebook(java.lang.String str, java.lang.String str2, org.tessera.rules.agenda.BrowserActs browserActs) {
        this.memory = new org.tessera.rules.facts.WorkingMemory(str, str2);
        this.screen = browserActs;
        register(new org.tessera.rules.agenda.Clause("retired-no-effects", 1000, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.closed((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda2
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.ignore((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("retire", 900, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda12
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.retire((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda13
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.retire((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("open-authorized-entrance", 800, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda14
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.open((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda15
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.entrance((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("current-native-unavailable", 700, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda16
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.failed((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda17
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.packageCopy((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("initial-arrival-deadline", 650, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda18
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.expired((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda17
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.packageCopy((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("redirect-cancels-arrival-deadline", 625, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda11
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.redirected((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda19
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.redirected((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("remote-document-begins", 600, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda20
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.begin((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda21
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.nextDocument((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("history-revises-address", 500, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda22
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.history((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda23
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.amend((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("attachment-retains-document", 450, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda24
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.attachment((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda25
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.retain((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("inspect-current-document", 400, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda26
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.ready((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda1
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.examine((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("reveal-certified-document", 350, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda3
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.measured((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda4
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.reveal((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("retry-from-local-only", 300, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda5
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.restored((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda6
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.retry((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("exit-local-history", 250, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda7
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.exit((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda8
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.leave((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
        register(new org.tessera.rules.agenda.Clause("visit-previous-remote", 200, new java.util.function.Predicate() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda9
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return org.tessera.rules.agenda.EvidenceTests.back((org.tessera.rules.agenda.Hearing) obj);
            }
        }, new java.util.function.Consumer() { // from class: org.tessera.rules.agenda.Rulebook$$ExternalSyntheticLambda10
            @Override // java.util.function.Consumer
            public final void accept(java.lang.Object obj) {
                org.tessera.rules.agenda.Findings.earlier((org.tessera.rules.agenda.Hearing) obj);
            }
        }));
    }

    private void register(org.tessera.rules.agenda.Clause clause) {
        int i = 0;
        while (i < this.clauses.size() && this.clauses.get(i).getPriority() >= clause.getPriority()) {
            i++;
        }
        this.clauses.add(i, clause);
    }

    public java.lang.String hear(org.tessera.rules.facts.Notice notice) {
        org.tessera.rules.agenda.Hearing hearing = new org.tessera.rules.agenda.Hearing(notice, this.memory, this.screen, this);
        for (int i = 0; i < this.clauses.size(); i++) {
            org.tessera.rules.agenda.Clause clause = this.clauses.get(i);
            if (clause.getAccepts().test(hearing)) {
                clause.getConsequence().accept(hearing);
                return clause.getName();
            }
        }
        return "no-applicable-rule";
    }
}
