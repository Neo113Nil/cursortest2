package org.tessera.rules.agenda;

/* compiled from: Findings.groovy */
/* loaded from: classes.dex */
public final class Measurement implements java.util.function.BiConsumer<java.lang.String, java.lang.Boolean> {
    private final org.tessera.rules.agenda.Rulebook authority;
    private final long edition;

    public Measurement(org.tessera.rules.agenda.Rulebook rulebook, long j) {
        this.authority = rulebook;
        this.edition = j;
    }

    @Override // java.util.function.BiConsumer
    public void accept(java.lang.String str, java.lang.Boolean bool) {
        this.authority.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getMEASURED(), str, "", bool.booleanValue(), this.edition));
    }
}
