package org.tessera.rules.agenda;

/* compiled from: Expiration.groovy */
/* loaded from: classes.dex */
public final class Expiration implements java.lang.Runnable {
    private final long attempt;
    private final org.tessera.rules.agenda.Rulebook authority;

    public Expiration(org.tessera.rules.agenda.Rulebook rulebook, long j) {
        this.authority = rulebook;
        this.attempt = j;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.authority.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getDEADLINE(), "", "", false, this.attempt));
    }
}
