package org.tessera.rules.agenda;

/* compiled from: Hearing.groovy */
/* loaded from: classes.dex */
public final class Hearing {
    private final org.tessera.rules.agenda.Rulebook authority;
    private final org.tessera.rules.facts.WorkingMemory memory;
    private final org.tessera.rules.facts.Notice notice;
    private final org.tessera.rules.agenda.BrowserActs screen;

    @groovy.transform.Generated
    public org.tessera.rules.agenda.Rulebook getAuthority() {
        return this.authority;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.WorkingMemory getMemory() {
        return this.memory;
    }

    @groovy.transform.Generated
    public org.tessera.rules.facts.Notice getNotice() {
        return this.notice;
    }

    @groovy.transform.Generated
    public org.tessera.rules.agenda.BrowserActs getScreen() {
        return this.screen;
    }

    public Hearing(org.tessera.rules.facts.Notice notice, org.tessera.rules.facts.WorkingMemory workingMemory, org.tessera.rules.agenda.BrowserActs browserActs, org.tessera.rules.agenda.Rulebook rulebook) {
        this.notice = notice;
        this.memory = workingMemory;
        this.screen = browserActs;
        this.authority = rulebook;
    }

    public boolean is(int i) {
        return this.notice.getKind() == i;
    }

    public boolean hasDocument() {
        return this.memory.getDocument() != null;
    }

    public boolean isRemote() {
        return hasDocument() && !this.memory.isLocal();
    }

    public boolean matches() {
        return hasDocument() && this.memory.getDocument().same(this.notice.getAddress());
    }

    public boolean addressOutsidePackage() {
        return (this.notice.getAddress() == null || this.notice.getAddress().getOrigin().equals(this.memory.getPackaged().getOrigin())) ? false : true;
    }

    public void travel(org.tessera.rules.facts.Address address, boolean z, boolean z2) {
        this.memory.assign(address, z);
        this.screen.shelter();
        if (z2) {
            this.screen.interrupt();
        }
        this.screen.replace(address.getRaw());
    }
}
