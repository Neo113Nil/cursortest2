package org.tessera.rules.agenda;

/* compiled from: Clause.groovy */
/* loaded from: classes.dex */
public final class Clause {
    private final java.util.function.Predicate<org.tessera.rules.agenda.Hearing> accepts;
    private final java.util.function.Consumer<org.tessera.rules.agenda.Hearing> consequence;
    private final java.lang.String name;
    private final int priority;

    @groovy.transform.Generated
    public java.util.function.Predicate<org.tessera.rules.agenda.Hearing> getAccepts() {
        return this.accepts;
    }

    @groovy.transform.Generated
    public java.util.function.Consumer<org.tessera.rules.agenda.Hearing> getConsequence() {
        return this.consequence;
    }

    @groovy.transform.Generated
    public java.lang.String getName() {
        return this.name;
    }

    @groovy.transform.Generated
    public int getPriority() {
        return this.priority;
    }

    public Clause(java.lang.String str, int i, java.util.function.Predicate<org.tessera.rules.agenda.Hearing> predicate, java.util.function.Consumer<org.tessera.rules.agenda.Hearing> consumer) {
        this.name = str;
        this.priority = i;
        this.accepts = predicate;
        this.consequence = consumer;
    }
}
