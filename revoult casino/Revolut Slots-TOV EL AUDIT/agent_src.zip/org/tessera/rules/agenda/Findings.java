package org.tessera.rules.agenda;

/* compiled from: Findings.groovy */
/* loaded from: classes.dex */
public final class Findings {
    @groovy.transform.Generated
    public Findings() {
    }

    public static void ignore(org.tessera.rules.agenda.Hearing hearing) {
    }

    public static void retire(org.tessera.rules.agenda.Hearing hearing) {
        disarm(hearing);
        hearing.getMemory().setClosed(true);
        hearing.getMemory().setEdition(hearing.getMemory().getEdition() + 1);
    }

    public static void disarm(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getMemory().setAwaitingArrival(false);
        hearing.getScreen().cancelSchedule();
    }

    public static void arm(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getScreen().cancelSchedule();
        hearing.getMemory().setAttempt(hearing.getMemory().getAttempt() + 1);
        hearing.getMemory().setAwaitingArrival(true);
        hearing.getScreen().schedule(new org.tessera.rules.agenda.Expiration(hearing.getAuthority(), hearing.getMemory().getAttempt()), 10000);
    }

    public static void entrance(org.tessera.rules.agenda.Hearing hearing) {
        org.tessera.rules.facts.Address entrance = (hearing.getNotice().getAddress() == null || !hearing.getNotice().getAddress().getOrigin().equals(hearing.getMemory().getEntrance().getOrigin())) ? hearing.getMemory().getEntrance() : hearing.getNotice().getAddress();
        arm(hearing);
        hearing.travel(entrance, false, false);
    }

    public static void packageCopy(org.tessera.rules.agenda.Hearing hearing) {
        disarm(hearing);
        hearing.travel(hearing.getMemory().getPackaged(), true, true);
    }

    public static void nextDocument(org.tessera.rules.agenda.Hearing hearing) {
        if (!hearing.getMemory().getDocument().same(hearing.getNotice().getAddress())) {
            disarm(hearing);
        }
        hearing.getMemory().assign(hearing.getNotice().getAddress(), false);
        hearing.getScreen().shelter();
    }

    public static void redirected(org.tessera.rules.agenda.Hearing hearing) {
        disarm(hearing);
        nextDocument(hearing);
    }

    public static void amend(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getMemory().assign(hearing.getNotice().getAddress(), false);
    }

    public static void retain(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getMemory().assign(hearing.getNotice().getCurrent(), false);
        examine(hearing);
    }

    public static void examine(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getScreen().measure(hearing.getMemory().getDocument().getRaw(), new org.tessera.rules.agenda.Measurement(hearing.getAuthority(), hearing.getMemory().getEdition()));
    }

    public static void reveal(org.tessera.rules.agenda.Hearing hearing) {
        disarm(hearing);
        hearing.getScreen().display();
    }

    public static void retry(org.tessera.rules.agenda.Hearing hearing) {
        arm(hearing);
        hearing.travel(hearing.getMemory().getEntrance(), false, false);
    }

    public static void leave(org.tessera.rules.agenda.Hearing hearing) {
        disarm(hearing);
        hearing.getScreen().terminate();
    }

    public static void earlier(org.tessera.rules.agenda.Hearing hearing) {
        hearing.getMemory().setEdition(hearing.getMemory().getEdition() + 1);
        hearing.getScreen().earlier();
    }
}
