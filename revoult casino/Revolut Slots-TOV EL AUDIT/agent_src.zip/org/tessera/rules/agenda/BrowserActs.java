package org.tessera.rules.agenda;

/* compiled from: BrowserActs.groovy */
/* loaded from: classes.dex */
public interface BrowserActs {
    void cancelSchedule();

    void display();

    void earlier();

    void interrupt();

    void measure(java.lang.String str, java.util.function.BiConsumer<java.lang.String, java.lang.Boolean> biConsumer);

    void replace(java.lang.String str);

    void schedule(java.lang.Runnable runnable, int i);

    void shelter();

    void terminate();
}
