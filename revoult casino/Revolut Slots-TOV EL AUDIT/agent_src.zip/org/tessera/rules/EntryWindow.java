package org.tessera.rules;

/* compiled from: EntryWindow.groovy */
/* loaded from: classes.dex */
public final class EntryWindow extends android.app.Activity implements org.tessera.rules.agenda.BrowserActs {
    private static /* synthetic */ long $const$0 = 0;
    private static /* synthetic */ float $const$1 = 0.0f;
    private static final java.lang.String COPY = "https://vault.invalid/copy/index.html";
    private android.view.View cinema;
    private android.webkit.WebChromeClient.CustomViewCallback cinemaCallback;
    private final android.os.Handler clock = new android.os.Handler(android.os.Looper.getMainLooper());
    private org.tessera.rules.windows.DialogWindows dialogs;
    private android.widget.FrameLayout frame;
    private org.tessera.rules.windows.PlatformGrants grants;
    private org.tessera.rules.agenda.Rulebook policy;
    private boolean retired;
    private android.widget.FrameLayout shade;
    private android.webkit.WebView sheet;
    private java.lang.Runnable unbindBack;
    private androidx.webkit.WebViewAssetLoader vaultLoader;

    static {
        __$swapInit();
    }

    public static /* synthetic */ void __$swapInit() {
        $const$0 = 4281674018L;
        $const$1 = 44.0f;
    }

    @groovy.transform.Generated
    public static java.lang.String getCOPY() {
        return COPY;
    }

    @groovy.transform.Generated
    public org.tessera.rules.windows.DialogWindows getDialogs() {
        return this.dialogs;
    }

    @groovy.transform.Generated
    public org.tessera.rules.windows.PlatformGrants getGrants() {
        return this.grants;
    }

    @groovy.transform.Generated
    public org.tessera.rules.agenda.Rulebook getPolicy() {
        return this.policy;
    }

    @groovy.transform.Generated
    public boolean getRetired() {
        return this.retired;
    }

    @groovy.transform.Generated
    public android.webkit.WebView getSheet() {
        return this.sheet;
    }

    @groovy.transform.Generated
    public androidx.webkit.WebViewAssetLoader getVaultLoader() {
        return this.vaultLoader;
    }

    @groovy.transform.Generated
    public boolean isRetired() {
        return this.retired;
    }

    @groovy.transform.Generated
    public void setDialogs(org.tessera.rules.windows.DialogWindows dialogWindows) {
        this.dialogs = dialogWindows;
    }

    @groovy.transform.Generated
    public void setGrants(org.tessera.rules.windows.PlatformGrants platformGrants) {
        this.grants = platformGrants;
    }

    @groovy.transform.Generated
    public void setPolicy(org.tessera.rules.agenda.Rulebook rulebook) {
        this.policy = rulebook;
    }

    @groovy.transform.Generated
    public void setRetired(boolean z) {
        this.retired = z;
    }

    @groovy.transform.Generated
    public void setSheet(android.webkit.WebView webView) {
        this.sheet = webView;
    }

    @groovy.transform.Generated
    public void setVaultLoader(androidx.webkit.WebViewAssetLoader webViewAssetLoader) {
        this.vaultLoader = webViewAssetLoader;
    }

    @groovy.transform.Generated
    public EntryWindow() {
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void schedule(java.lang.Runnable runnable, int i) {
        this.clock.postDelayed(runnable, i);
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void cancelSchedule() {
        this.clock.removeCallbacksAndMessages(null);
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) throws java.io.IOException {
        super.onCreate(bundle);
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        android.widget.FrameLayout frameLayout = new android.widget.FrameLayout(this);
        this.frame = frameLayout;
        frameLayout.setBackgroundColor((int) $const$0);
        this.sheet = new android.webkit.WebView(this);
        android.widget.FrameLayout frameLayout2 = new android.widget.FrameLayout(this);
        this.shade = frameLayout2;
        frameLayout2.setBackgroundColor((int) $const$0);
        this.shade.setClickable(true);
        this.shade.setFocusable(true);
        this.shade.setContentDescription("Loading page");
        int iRound = java.lang.Math.round((float) ($const$1 * getResources().getDisplayMetrics().density));
        this.shade.addView(new android.widget.ProgressBar(this), new android.widget.FrameLayout.LayoutParams(iRound, iRound, android.view.Gravity.CENTER));
        this.frame.addView(this.sheet, new android.widget.FrameLayout.LayoutParams(-1, -1));
        this.frame.addView(this.shade, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(this.frame);
        this.frame.setOnApplyWindowInsetsListener(new org.tessera.rules.windows.WindowPadding());
        this.frame.requestApplyInsets();
        this.vaultLoader = new androidx.webkit.WebViewAssetLoader.Builder().setDomain("vault.invalid").addPathHandler("/", new androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this)).build();
        this.grants = new org.tessera.rules.windows.PlatformGrants(this);
        this.dialogs = new org.tessera.rules.windows.DialogWindows(this);
        java.io.InputStream inputStreamOpen = getAssets().open("entry.json");
        java.io.ByteArrayOutputStream byteArrayOutputStream = new java.io.ByteArrayOutputStream();
        byte[] bArr = new byte[4096];
        while (true) {
            try {
                int i = inputStreamOpen.read(bArr);
                if (i == -1) {
                    break;
                } else {
                    byteArrayOutputStream.write(bArr, 0, i);
                }
            } catch (java.lang.Throwable th) {
                inputStreamOpen.close();
                throw th;
            }
        }
        inputStreamOpen.close();
        this.policy = new org.tessera.rules.agenda.Rulebook(new org.json.JSONObject(byteArrayOutputStream.toString("UTF-8")).getString("remote"), COPY, this);
        org.tessera.rules.windows.PageObservations.wire(this, this.sheet, true);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            this.unbindBack = org.tessera.rules.windows.ReturnHook.bind(getWindow(), new java.lang.Runnable() { // from class: org.tessera.rules.EntryWindow$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.returnThroughRules();
                }
            });
        }
        localNotifications(getIntent(), true);
        this.policy.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getOPEN(), clean(getIntent().getDataString())));
    }

    private boolean localNotifications(android.content.Intent intent, boolean z) {
        try {
            return java.lang.Boolean.TRUE.equals(java.lang.Class.forName("org.tessera.rules.LocalPushRuntime").getMethod("onLaunch", android.app.Activity.class, android.content.Intent.class, java.lang.Boolean.TYPE).invoke(null, this, intent, java.lang.Boolean.valueOf(z)));
        } catch (java.lang.ClassNotFoundException unused) {
            return false;
        } catch (java.lang.Exception e) {
            android.util.Log.w("LocalNotifications", "Unable to start local notifications", e);
            return false;
        }
    }

    public static java.lang.String clean(java.lang.String str) {
        return str == null ? "" : str;
    }

    public boolean principal(android.webkit.WebView webView) {
        return !this.retired && webView == this.sheet;
    }

    public boolean containsPage(android.webkit.WebView webView) {
        if (this.retired) {
            return false;
        }
        return webView == this.sheet || this.dialogs.contains(webView);
    }

    public void returnThroughRules() {
        if (this.retired || closeCinema()) {
            return;
        }
        this.policy.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getBACK(), "", "", this.sheet.canGoBack()));
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void shelter() {
        this.shade.setVisibility(android.view.View.VISIBLE);
        this.shade.bringToFront();
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void display() {
        if (this.retired) {
            return;
        }
        this.shade.setVisibility(android.view.View.GONE);
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void replace(java.lang.String str) {
        if (this.retired) {
            return;
        }
        this.sheet.loadUrl(str);
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void interrupt() {
        this.dialogs.closeAll();
        closeCinema();
        this.sheet.stopLoading();
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void measure(java.lang.String str, java.util.function.BiConsumer<java.lang.String, java.lang.Boolean> biConsumer) {
        if (this.retired) {
            return;
        }
        this.sheet.evaluateJavascript("(()=>{const r=document.documentElement;return !!r&&document.readyState!=='loading'&&!r.classList.contains('neterror')&&!document.querySelector('#main-frame-error')})()", new org.tessera.rules.windows.DrawingAnswer(this, biConsumer));
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void earlier() {
        if (this.retired) {
            return;
        }
        this.sheet.goBack();
    }

    @Override // org.tessera.rules.agenda.BrowserActs
    public void terminate() {
        finish();
    }

    public void showCinema(android.view.View view, android.webkit.WebChromeClient.CustomViewCallback customViewCallback) {
        closeCinema();
        this.cinema = view;
        this.cinemaCallback = customViewCallback;
        this.frame.addView(view, new android.widget.FrameLayout.LayoutParams(-1, -1));
        view.bringToFront();
    }

    public boolean closeCinema() {
        android.view.View view = this.cinema;
        if (view == null) {
            return false;
        }
        this.frame.removeView(view);
        this.cinema = null;
        android.webkit.WebChromeClient.CustomViewCallback customViewCallback = this.cinemaCallback;
        this.cinemaCallback = null;
        customViewCallback.onCustomViewHidden();
        return true;
    }

    public void rendererLost(android.webkit.WebView webView) {
        if (!principal(webView)) {
            this.dialogs.discard(webView);
            return;
        }
        shelter();
        retire();
        recreate();
    }

    private void retire() {
        if (this.retired) {
            return;
        }
        this.retired = true;
        org.tessera.rules.agenda.Rulebook rulebook = this.policy;
        if (rulebook != null) {
            rulebook.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getDISPOSE()));
        }
        org.tessera.rules.windows.PlatformGrants platformGrants = this.grants;
        if (platformGrants != null) {
            platformGrants.cancelAll();
        }
        org.tessera.rules.windows.DialogWindows dialogWindows = this.dialogs;
        if (dialogWindows != null) {
            dialogWindows.closeAll();
        }
        closeCinema();
        android.webkit.WebView webView = this.sheet;
        if (webView != null) {
            this.frame.removeView(webView);
            this.sheet.destroy();
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        returnThroughRules();
    }

    @Override // android.app.Activity
    public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (localNotifications(intent, false)) {
            recreate();
        } else {
            if (this.retired || intent.getDataString() == null) {
                return;
            }
            this.policy.hear(new org.tessera.rules.facts.Notice(org.tessera.rules.facts.Notice.getOPEN(), intent.getDataString()));
        }
    }

    @Override // android.app.Activity
    public void onPause() {
        android.webkit.WebView webView;
        if (!this.retired && (webView = this.sheet) != null) {
            webView.onPause();
            this.dialogs.pauseAll();
        }
        super.onPause();
    }

    @Override // android.app.Activity
    public void onResume() {
        android.webkit.WebView webView;
        super.onResume();
        if (this.retired || (webView = this.sheet) == null) {
            return;
        }
        webView.onResume();
        this.dialogs.resumeAll();
    }

    @Override // android.app.Activity
    public void onDestroy() {
        java.lang.Runnable runnable = this.unbindBack;
        if (runnable != null) {
            runnable.run();
        }
        retire();
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onActivityResult(int i, int i2, android.content.Intent intent) {
        super.onActivityResult(i, i2, intent);
        this.grants.selected(i, i2, intent);
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, java.lang.String[] strArr, int... iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        this.grants.permitted(i);
    }
}
