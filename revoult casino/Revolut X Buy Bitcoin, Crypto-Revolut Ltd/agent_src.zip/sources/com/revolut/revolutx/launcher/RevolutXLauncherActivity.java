package com.revolut.revolutx.launcher;

import android.R;
import android.content.Intent;
import android.os.Bundle;
import androidx.core.splashscreen.SplashScreen;
import com.revolut.analytics.tracking.v3.AnalyticsProduct;
import com.revolut.retail.core.ui.activity.BaseDelegatesActivity;
import g89.b;
import ia.od;
import jqf.e;
import ka.g0;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;
import lli.c;
import lli.d;
import s5j.w2;
import srh.a;

/* compiled from: r8-map-id-071999a0b6822bc9972c83579ab71bc8e2fdf035ee52baca40f01bfb3fb674fb */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u00020\u00032\u00020\u0004B\u0007¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/revolut/revolutx/launcher/RevolutXLauncherActivity;", "Lsrh/a;", "Llli/c;", "Llli/d;", "Lam/m;", "<init>", "()V", "app_revolut_x_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes8.dex */
public final class RevolutXLauncherActivity extends a implements d {

    /* renamed from: t, reason: collision with root package name */
    public final w2 f88966t;
    public mli.a v;

    /* renamed from: w, reason: collision with root package name */
    public boolean f88967w;
    public final String x;

    public RevolutXLauncherActivity() {
        w2 value = w2.Auth;
        Intrinsics.checkNotNullParameter(value, "value");
        this.f88966t = value;
        this.x = "REVOLUT_X_LAUNCHER_FLOW";
    }

    @Override // hqf.b
    public final e W() {
        mli.a aVar = this.v;
        if (aVar != null) {
            return (c) aVar.p.get();
        }
        Intrinsics.p("component");
        throw null;
    }

    @Override // hqf.b
    /* renamed from: a0, reason: from getter */
    public final String getX() {
        return this.x;
    }

    @Override // hqf.b, am.m
    public final AnalyticsProduct f() {
        return new AnalyticsProduct.RevolutX(this.f88966t);
    }

    @Override // srh.a
    public final trh.a o0() {
        mli.a aVar = this.v;
        if (aVar != null) {
            return aVar;
        }
        Intrinsics.p("component");
        throw null;
    }

    @Override // srh.a, com.revolut.retail.core.ui.activity.BaseDelegatesActivity, androidx.view.ComponentActivity, android.app.Activity
    public final void onBackPressed() {
        b bVar;
        super.onBackPressed();
        Intent intent = getIntent();
        Intrinsics.checkNotNullExpressionValue(intent, "getIntent(...)");
        RevolutXLauncherContract$Config revolutXLauncherContract$Config = (RevolutXLauncherContract$Config) hqf.b.Y(intent);
        if (revolutXLauncherContract$Config == null || (bVar = revolutXLauncherContract$Config.f88968a) == null) {
            bVar = b.NONE;
        }
        switch (lli.a.f197386a[bVar.ordinal()]) {
            case 1:
            case 2:
            case 3:
                super.onBackPressed();
                return;
            case 4:
            case 5:
            case 6:
                moveTaskToBack(true);
                return;
            case 7:
            case 8:
            case 9:
            case 10:
                return;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    @Override // srh.a, com.revolut.retail.core.ui.activity.BaseDelegatesActivity, hqf.b, androidx.fragment.app.FragmentActivity, androidx.view.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) throws BaseDelegatesActivity.ActivityDelegatesInitializationException {
        SplashScreen.INSTANCE.installSplashScreen(this);
        String str = null;
        mli.b bVar = ((mli.b) g0.d(this).b(null, this.x)).C;
        unf.c cVarA = od.a(this, bundle, Integer.valueOf(R.id.content));
        Intent intent = getIntent();
        Intrinsics.checkNotNullExpressionValue(intent, "getIntent(...)");
        RevolutXLauncherContract$Config revolutXLauncherContract$Config = (RevolutXLauncherContract$Config) hqf.b.Y(intent);
        if (revolutXLauncherContract$Config == null) {
            revolutXLauncherContract$Config = new RevolutXLauncherContract$Config(b.NONE, str, 30);
        }
        this.v = new mli.a(bVar, cVarA, revolutXLauncherContract$Config);
        super.onCreate(bundle);
    }

    @Override // srh.a
    public final int q0() {
        return 0;
    }

    @Override // android.app.Activity, android.content.ContextWrapper, android.content.Context
    public final void startActivity(Intent intent, Bundle bundle) {
        super.startActivity(intent, bundle);
        if (this.f88967w) {
            overridePendingTransition(0, 0);
        }
    }

    @Override // hqf.b, li0.e
    public final boolean v() {
        return true;
    }

    @Override // srh.a, xpf.a
    public final boolean w() {
        return false;
    }
}
