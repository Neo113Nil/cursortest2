package com.revolut.revolutx;

import android.app.Application;
import android.content.Context;
import android.content.pm.Signature;
import com.google.common.base.Ascii;
import com.google.common.primitives.SignedBytes;
import com.google.common.primitives.UnsignedBytes;
import com.youTransactor.uCube.rpc.Constants;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;

/* loaded from: classes.dex */
public class ProtectedRevolutXApplication extends Application {

    /* renamed from: a, reason: collision with root package name */
    private static Object f87810a;

    public class RevolutXApplication {
        public static native String a(int i3, String str);

        public static native String a(int i3, String str, boolean z2);

        public static native String a(Throwable th2);

        public static native HttpURLConnection a(byte[] bArr, long j2);

        public static native void a(Context context);

        public static native void a(String str);

        public static native void a(String str, String str2, int i3, boolean z2, List list, int i7, String str3, int i12);

        public static native void a(String str, String str2, int i3, boolean z2, List list, List list2, int i7, String str3, int i12);

        public static native boolean a();

        public static native String b();

        public static native HttpURLConnection b(String str);

        public static native void b(Context context);

        public static native void c(String str);
    }

    public ProtectedRevolutXApplication() {
        f87810a = this;
    }

    public static native InputStream a(Object obj2, String str);

    public static byte[] a(byte[] bArr) {
        byte[] bArr2 = {38, -124, ISOFileInfo.FCP_BYTE, -63, 126, -44, 39, -45, 81, -108, -78, -126, 113, Ascii.ESC, -34, -65, -72, -106, 122, 39, -55, -14, 15, ISO7816.INS_READ_BINARY, 63, -20, 106, -109, 4, 121, -5, 117, Ascii.US, -75, 54, 108, 11, -21, -110, 70, ISOFileInfo.FCI_EXT, 120, -82, SignedBytes.MAX_POWER_OF_TWO, 0, 108, ISO7816.INS_READ_BINARY2, -10, 81, -107, -39, -52, Ascii.SYN, ISOFileInfo.A1, 61, ISOFileInfo.DATA_BYTES2, 30, -102, -39, 13, -60, 121, ISO7816.INS_PSO, ISOFileInfo.A5, ISO7816.INS_MSE, -53, 57, -92, ISO7816.INS_CREATE_FILE, -50, -8, ISO7816.INS_UPDATE_BINARY, -10, 45, -90, -126, ISOFileInfo.DATA_BYTES2, ISOFileInfo.SECURITY_ATTR_EXP, -94, ISOFileInfo.AB, 83, Constants.NFC_READER, -90, ISO7816.INS_CHANGE_CHV, -101, -23, 124, -16, 75, 109, -44, ISOFileInfo.A5, 116, -21, Ascii.US, -122, -44, -113, 3, ISO7816.INS_READ_BINARY2, -122, 13, -105, -72, 11, 29, -37, 45, ISOFileInfo.AB, 17, Ascii.DEL, -69, 4, 0, -90, ISOFileInfo.FCI_EXT, ISOFileInfo.FCP_BYTE, Ascii.DC4, 63, 56, -19, ISOFileInfo.AB, -88, 18, -13, -65, -57, -59, 75, 72, 70, 121, -12, -44, ISO7816.INS_PSO, 117, ISO7816.INS_WRITE_RECORD, ISO7816.INS_MSE, 59, -69, -57, ISO7816.INS_INCREASE, -9, 57, -128, 16, 102, -72, 14, -34, -14, 13, -67, -78, 91, 62, 55, 77, 16, -70, ISO7816.INS_UPDATE_RECORD, ISO7816.INS_READ_BINARY_STAMPED, -103, -113, 51, 65, 55, -16, ISOFileInfo.A1, 30, -55, -69, -18, Ascii.DC4, Ascii.DEL, 86, -4, -60, 96, 45, Ascii.ESC, 80, -51, 15, Ascii.SYN, 89, ISOFileInfo.LCS_BYTE, 12, 3, -33, -109, 73, Ascii.DC4, 16, 3, 39, 65, Constants.INQUIRY, ISO7816.INS_READ_BINARY_STAMPED, 1, 125, ISO7816.INS_UPDATE_RECORD, -8, 10, -39, -8, ISO7816.INS_UNBLOCK_CHV, 125, 72, -63, -58, ISO7816.INS_READ_BINARY_STAMPED, -122, -33, 123, -45, ISO7816.INS_WRITE_RECORD, 8, -51, Ascii.DEL, -23, ISOFileInfo.DATA_BYTES2, -60, 105, 53, -49, 67, -9, ISO7816.INS_PUT_DATA, -66, Ascii.NAK, Ascii.EM, 96, -21, -65, 53, ISO7816.INS_GET_DATA, 86, 16, -81, 67, ISO7816.INS_APPEND_RECORD, Constants.INQUIRY, 18, -26, 41, -59, -82, 30, -49, ISO7816.INS_PSO, -122, 43, ISO7816.INS_WRITE_RECORD, -15, -104};
        byte[] bArr3 = {73, -16, 116, -21, -84, 12, 124, 85, -104, -53, 125, -110, -45, -57, 126, 116, 56, -101, -37, -65, 82, -88, -8, 46, ISO7816.INS_CREATE_FILE, Ascii.NAK, -33, 99, -19, 125, Ascii.NAK, 103, 79, 125, 86, -35, -10, PSSSigner.TRAILER_IMPLICIT, -39, 119, ISO7816.INS_READ_BINARY, -128, -53, -50, -70, ISOFileInfo.FCI_BYTE, -47, 82, ISO7816.INS_GET_DATA, ISO7816.INS_GET_DATA, 8, -37, ISOFileInfo.SECURITY_ATTR_COMPACT, 1, Ascii.SUB, 95, 62, -56, 65, -92, ISO7816.INS_MSE, 84, 51, 47, ISO7816.INS_APPEND_RECORD, -72, -89, -67, -52, 65, -15, -21, 39, 113, -63, 102, -52, 53, ISOFileInfo.CHANNEL_SECURITY, ISO7816.INS_READ_BINARY2, 46, 118, ISO7816.INS_CREATE_FILE, 15, ISO7816.INS_READ_BINARY_STAMPED, 85, -65, -101, -20, Ascii.US, 58, 80, -81, -55, -94, Constants.NFC_READER, Ascii.ESC, ISO7816.INS_READ_BINARY_STAMPED, Ascii.EM, 104, -86, -63, ISO7816.INS_GET_DATA, -4, 46, 53, -111, 40, ISO7816.INS_CREATE_FILE, -101, -22, 86, 74, -70, -126, -103, -78, 55, -17, 78, 3, 104, ISOFileInfo.FMD_BYTE, 81, -109, -31, ISO7816.INS_READ_RECORD_STAMPED, SignedBytes.MAX_POWER_OF_TWO, Ascii.DEL, ISO7816.INS_CREATE_FILE, 32, -34, -55, -66, 53, -101, 67, ISO7816.INS_MANAGE_CHANNEL, ISO7816.INS_WRITE_RECORD, 60, 2, Ascii.SUB, 69, -53, 74, -81, 8, -43, -103, 123, 99, -16, 82, 35, -10, -55, -101, ISO7816.INS_ENVELOPE, 43, -128, ISO7816.INS_LOAD_KEY_FILE, -41, -55, -12, -124, 88, 78, -56, -27, ISO7816.INS_DELETE_FILE, ISO7816.INS_ENVELOPE, 96, -60, -43, -113, -53, 71, ISO7816.INS_WRITE_RECORD, -88, -6, 115, -113, Ascii.CAN, 125, -69, 109, -18, -51, 38, 40, Ascii.SUB, -51, 28, -122, 75, -35, -111, PSSSigner.TRAILER_IMPLICIT, ISO7816.INS_READ_RECORD_STAMPED, -111, ISO7816.INS_UNBLOCK_CHV, -13, -86, -67, 29, ISO7816.INS_ENVELOPE, -58, 1, 6, SignedBytes.MAX_POWER_OF_TWO, 61, 53, 78, Ascii.ETB, ISO7816.INS_GET_DATA, 29, 77, -71, -75, -94, ISO7816.INS_GET_RESPONSE, Constants.INQUIRY, -21, 16, -99, 101, -20, ISO7816.INS_REHABILITATE_CHV, Ascii.SYN, -10, -69, ISOFileInfo.DATA_BYTES2, -94, 78, Ascii.NAK, 74, 16, 37, 106, 12, ISO7816.INS_REHABILITATE_CHV, 126, 56, 54, 54, -66, -124, ISOFileInfo.FCI_EXT, -83, ISO7816.INS_UPDATE_BINARY, 121, ISOFileInfo.DATA_BYTES2, ISO7816.INS_ENVELOPE, 95, ISOFileInfo.FCI_EXT, 69};
        byte[] bArr4 = new byte[32];
        for (int i3 = 0; i3 < 32; i3++) {
            bArr4[i3] = bArr2[bArr3[bArr[i3] & UnsignedBytes.MAX_VALUE] & UnsignedBytes.MAX_VALUE];
        }
        return bArr4;
    }

    private void b() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        Signature[] signatureArr = getPackageManager().getPackageInfo(getPackageName(), 64).signatures;
        if (signatureArr == null || signatureArr.length == 0) {
            throw new RuntimeException("Signing certificates not found");
        }
        if (signatureArr.length != 1) {
            throw new RuntimeException("Package is signed by multiple signing certificates [" + signatureArr.length + "]");
        }
        String string = new BigInteger(1, messageDigest.digest(signatureArr[0].toByteArray())).toString(16);
        if (!"9c9be07135e972780282c2e5d27da06ecb8ee3adfc75303917ddf66d6faaefa4".equals(string)) {
            throw new RuntimeException("Certificate mismatch. Expecting sha256[9c9be07135e972780282c2e5d27da06ecb8ee3adfc75303917ddf66d6faaefa4], current sha256[" + string + "]");
        }
    }

    private static native void c();

    public static native String s(String str);

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        ProtectedRevolutXApplication$ProtectedRevolutXApplication$R$color.a(this);
        if (ProtectedRevolutXApplication$R$drawable.u()) {
            return;
        }
        try {
            b();
            System.loadLibrary("dexprotector");
        } catch (Throwable th2) {
            RevolutXApplication.a(th2);
            throw th2;
        }
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        ProtectedRevolutXApplication$ProtectedRevolutXApplication$R$color.c(this);
        if (ProtectedRevolutXApplication$R$drawable.u()) {
            return;
        }
        try {
            c();
        } catch (Throwable th2) {
            RevolutXApplication.a(th2);
            throw th2;
        }
    }
}
