package com.revolut.feature_web_view.declaration;

import android.os.Parcel;
import android.os.Parcelable;
import cy2.d;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* compiled from: r8-map-id-071999a0b6822bc9972c83579ab71bc8e2fdf035ee52baca40f01bfb3fb674fb */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/revolut/feature_web_view/declaration/WebViewInputData;", "Landroid/os/Parcelable;", "feature_web_view_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class WebViewInputData implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<WebViewInputData> CREATOR = new a();

    /* renamed from: a, reason: collision with root package name */
    public final String f81097a;

    /* renamed from: b, reason: collision with root package name */
    public final WebViewScreenTitleSource f81098b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f81099c;

    /* compiled from: r8-map-id-071999a0b6822bc9972c83579ab71bc8e2fdf035ee52baca40f01bfb3fb674fb */
    public static final class a implements Parcelable.Creator {
        @Override // android.os.Parcelable.Creator
        public final Object createFromParcel(Parcel parcel) {
            Intrinsics.checkNotNullParameter(parcel, "parcel");
            return new WebViewInputData(parcel.readString(), (WebViewScreenTitleSource) parcel.readParcelable(WebViewInputData.class.getClassLoader()), parcel.readInt() != 0);
        }

        @Override // android.os.Parcelable.Creator
        public final Object[] newArray(int i3) {
            return new WebViewInputData[i3];
        }
    }

    public WebViewInputData(String url, WebViewScreenTitleSource titleSource, boolean z2) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(titleSource, "titleSource");
        this.f81097a = url;
        this.f81098b = titleSource;
        this.f81099c = z2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj2) {
        if (this == obj2) {
            return true;
        }
        if (!(obj2 instanceof WebViewInputData)) {
            return false;
        }
        WebViewInputData webViewInputData = (WebViewInputData) obj2;
        return Intrinsics.e(this.f81097a, webViewInputData.f81097a) && Intrinsics.e(this.f81098b, webViewInputData.f81098b) && this.f81099c == webViewInputData.f81099c;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f81099c) + ((this.f81098b.hashCode() + (this.f81097a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("WebViewInputData(url=");
        sb2.append(this.f81097a);
        sb2.append(", titleSource=");
        sb2.append(this.f81098b);
        sb2.append(", isAuthorized=");
        return d.s(sb2, this.f81099c, ")");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel dest, int i3) {
        Intrinsics.checkNotNullParameter(dest, "dest");
        dest.writeString(this.f81097a);
        dest.writeParcelable(this.f81098b, i3);
        dest.writeInt(this.f81099c ? 1 : 0);
    }
}
