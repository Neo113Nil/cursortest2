package com.revolut.feature_web_view.presentation;

import al0.h0;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.appbar.AppBarLayout;
import com.revolut.core.ui_kit.R$string;
import com.revolut.core.ui_kit.models.Clause;
import com.revolut.core.ui_kit.views.FullScreenStateView;
import com.revolut.core.ui_kit.views.WebView;
import com.revolut.feature_web_view.R$id;
import com.revolut.feature_web_view.R$layout;
import com.revolut.feature_web_view.presentation.WebViewActivity;
import com.revolut.retail.core.ui.activity.BaseDelegatesActivity;
import com.revolut.uicomponent.toolbar.app_bar.CustomViewRevolutToolbar;
import com.revolut.uicomponent.toolbar.app_bar.RevolutAppBarLayout;
import com.revolut.uicomponent.toolbar.app_bar.ToolbarShadow;
import com.youTransactor.uCube.rpc.Constants;
import ia.o9;
import ia.od;
import ia.q1;
import jqf.e;
import ka.g0;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.c0;
import kotlin.jvm.internal.i0;
import kotlin.jvm.internal.j0;
import kotlin.reflect.KProperty;
import l30.g;
import la.ge;
import la.y1;
import nea.f;
import ngf.j;
import ogf.d;
import pt0.c;
import xpf.a;
import zfj.b;

/* compiled from: r8-map-id-071999a0b6822bc9972c83579ab71bc8e2fdf035ee52baca40f01bfb3fb674fb */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u00020\u00032\u00020\u00042\u00020\u0005:\u0002\b\tB\u0007¢\u0006\u0004\b\u0006\u0010\u0007¨\u0006\n"}, d2 = {"Lcom/revolut/feature_web_view/presentation/WebViewActivity;", "Lcom/revolut/retail/core/ui/activity/BaseDelegatesActivity;", "Lngf/i;", "Lngf/j;", "Lxpf/a;", "Lli0/e;", "<init>", "()V", "ngf/e", "ngf/f", "feature_web_view_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class WebViewActivity extends BaseDelegatesActivity implements j, a {
    public static final /* synthetic */ KProperty[] O;
    public WebView A;
    public WebViewContract$WebViewConfiguration D;
    public d E;
    public boolean F;
    public g G;
    public jf0.d H;
    public final Object I;
    public final Object K;
    public boolean L;
    public String M;
    public boolean N;

    /* renamed from: s, reason: collision with root package name */
    public final b50.a f81102s = o9.e(this, R$id.appbar);

    /* renamed from: t, reason: collision with root package name */
    public final b50.a f81103t = o9.e(this, R$id.toolbarShadow);
    public final b50.a v = o9.e(this, R$id.webview_container);

    /* renamed from: w, reason: collision with root package name */
    public final b50.a f81104w = o9.e(this, R$id.transparentToolbar);
    public final b50.a x = o9.e(this, R$id.toolbar);

    /* renamed from: y, reason: collision with root package name */
    public final b50.a f81105y = o9.e(this, R$id.errorView);

    /* renamed from: z, reason: collision with root package name */
    public final b50.a f81106z = o9.e(this, R$id.list_t_c_progress);
    public final zhj.d B = r1.a.z("create(...)");
    public final b C = new b();

    static {
        c0 c0Var = new c0(WebViewActivity.class, "appbar", "getAppbar()Lcom/revolut/uicomponent/toolbar/app_bar/RevolutAppBarLayout;", 0);
        j0 j0Var = i0.f185672a;
        O = new KProperty[]{j0Var.j(c0Var), k4.a.e(WebViewActivity.class, "toolbarShadow", "getToolbarShadow()Lcom/revolut/uicomponent/toolbar/app_bar/ToolbarShadow;", 0, j0Var), k4.a.e(WebViewActivity.class, "webviewContainer", "getWebviewContainer()Landroidx/coordinatorlayout/widget/CoordinatorLayout;", 0, j0Var), k4.a.e(WebViewActivity.class, "transparentToolbar", "getTransparentToolbar()Lcom/revolut/uicomponent/toolbar/app_bar/CustomViewRevolutToolbar;", 0, j0Var), k4.a.e(WebViewActivity.class, "toolbar", "getToolbar()Lcom/revolut/uicomponent/toolbar/app_bar/CustomViewRevolutToolbar;", 0, j0Var), k4.a.e(WebViewActivity.class, "errorView", "getErrorView()Lcom/revolut/core/ui_kit/views/FullScreenStateView;", 0, j0Var), k4.a.e(WebViewActivity.class, "listTCProgress", "getListTCProgress()Landroid/widget/ProgressBar;", 0, j0Var)};
    }

    public WebViewActivity() {
        final int i3 = 0;
        this.I = ge.b(new Function0(this) { // from class: ngf.b

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ WebViewActivity f216994b;

            {
                this.f216994b = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                int i7 = i3;
                WebViewActivity webViewActivity = this.f216994b;
                switch (i7) {
                    case 0:
                        KProperty[] kPropertyArr = WebViewActivity.O;
                        return Integer.valueOf(vkf.a.a(webViewActivity, 24.0f));
                    default:
                        KProperty[] kPropertyArr2 = WebViewActivity.O;
                        return new e(webViewActivity);
                }
            }
        });
        final int i7 = 1;
        this.K = ge.b(new Function0(this) { // from class: ngf.b

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ WebViewActivity f216994b;

            {
                this.f216994b = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                int i710 = i7;
                WebViewActivity webViewActivity = this.f216994b;
                switch (i710) {
                    case 0:
                        KProperty[] kPropertyArr = WebViewActivity.O;
                        return Integer.valueOf(vkf.a.a(webViewActivity, 24.0f));
                    default:
                        KProperty[] kPropertyArr2 = WebViewActivity.O;
                        return new e(webViewActivity);
                }
            }
        });
    }

    public static final void o0(WebViewActivity webViewActivity, boolean z2, boolean z3) {
        View decorView;
        b50.a aVar = webViewActivity.f81103t;
        KProperty[] kPropertyArr = O;
        if (z2 && !webViewActivity.L) {
            webViewActivity.L = true;
            ((ToolbarShadow) aVar.getValue(webViewActivity, kPropertyArr[1])).setVisibility(4);
            if (webViewActivity.p0().getVisibility() == 0) {
                if (z3) {
                    ov0.j.b(webViewActivity.p0());
                } else {
                    ov0.j.a(webViewActivity.p0());
                    webViewActivity.p0().setAlpha(0.0f);
                }
                Window window = webViewActivity.getWindow();
                Intrinsics.checkNotNullExpressionValue(window, "getWindow(...)");
                q1.a(window, h0.STATUS);
                return;
            }
            return;
        }
        if (z2 || !webViewActivity.L) {
            return;
        }
        webViewActivity.L = false;
        ((ToolbarShadow) aVar.getValue(webViewActivity, kPropertyArr[1])).setVisibility(0);
        if (z3) {
            ov0.j.f(webViewActivity.p0());
        } else {
            ov0.j.d(webViewActivity.p0());
        }
        if ((webViewActivity.getResources().getConfiguration().uiMode & 48) == 32) {
            return;
        }
        Window window2 = webViewActivity.getWindow();
        if (window2 != null) {
            window2.setStatusBarColor(0);
        }
        if (window2 == null || (decorView = window2.getDecorView()) == null) {
            return;
        }
        decorView.setSystemUiVisibility(9472);
    }

    @Override // hqf.b
    public final e W() {
        d dVar = this.E;
        if (dVar != null) {
            return dVar.b();
        }
        Intrinsics.p("activityComponent");
        throw null;
    }

    @Override // hqf.b
    public final String a0() {
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration = this.D;
        if (webViewContract$WebViewConfiguration != null) {
            return webViewContract$WebViewConfiguration.f81115j;
        }
        Intrinsics.p("config");
        throw null;
    }

    @Override // com.revolut.retail.core.ui.activity.BaseDelegatesActivity
    public final zqf.a c0() {
        d dVar = this.E;
        if (dVar != null) {
            return dVar;
        }
        Intrinsics.p("activityComponent");
        throw null;
    }

    /* JADX WARN: Type inference failed for: r1v19, types: [java.lang.Object, kotlin.Lazy] */
    @Override // com.revolut.retail.core.ui.activity.BaseDelegatesActivity, hqf.b, androidx.fragment.app.FragmentActivity, androidx.view.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) throws BaseDelegatesActivity.ActivityDelegatesInitializationException {
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration = (WebViewContract$WebViewConfiguration) getIntent().getParcelableExtra("CONFIGURATION_ARG");
        if (webViewContract$WebViewConfiguration == null) {
            throw new IllegalStateException();
        }
        this.D = webViewContract$WebViewConfiguration;
        ik3.a aVar = (ik3.a) ((ogf.e) g0.d(this).b(null, a0())).h().h(od.a(this, bundle, null));
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration2 = this.D;
        if (webViewContract$WebViewConfiguration2 == null) {
            Intrinsics.p("config");
            throw null;
        }
        switch (aVar.f155869a) {
            case 0:
                webViewContract$WebViewConfiguration2.getClass();
                aVar.f155871c = webViewContract$WebViewConfiguration2;
                break;
            case 1:
                webViewContract$WebViewConfiguration2.getClass();
                aVar.f155871c = webViewContract$WebViewConfiguration2;
                break;
            case 2:
                webViewContract$WebViewConfiguration2.getClass();
                aVar.f155871c = webViewContract$WebViewConfiguration2;
                break;
            default:
                webViewContract$WebViewConfiguration2.getClass();
                aVar.f155871c = webViewContract$WebViewConfiguration2;
                break;
        }
        d dVar = (d) aVar.mo976build();
        this.E = dVar;
        if (dVar == null) {
            Intrinsics.p("activityComponent");
            throw null;
        }
        dVar.C(this);
        super.onCreate(bundle);
        setContentView(R$layout.activity_web_view);
        this.C.a(q0().getSmallActionButton().f39205h.subscribe(new nef.e(new f(this, 10), 6)));
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration3 = this.D;
        if (webViewContract$WebViewConfiguration3 == null) {
            Intrinsics.p("config");
            throw null;
        }
        this.F = webViewContract$WebViewConfiguration3.p;
        this.A = new WebView(this, null, 6);
        CoordinatorLayout.LayoutParams layoutParams = new CoordinatorLayout.LayoutParams(-1, -1);
        ViewGroup.LayoutParams layoutParams2 = p0().getLayoutParams();
        Intrinsics.h(layoutParams2, "null cannot be cast to non-null type androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams");
        ((CoordinatorLayout.LayoutParams) layoutParams2).setBehavior(new AppBarLayout.Behavior());
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration4 = this.D;
        if (webViewContract$WebViewConfiguration4 == null) {
            Intrinsics.p("config");
            throw null;
        }
        boolean z2 = webViewContract$WebViewConfiguration4.k;
        b50.a aVar2 = this.v;
        KProperty[] kPropertyArr = O;
        if (z2) {
            WebView webView = this.A;
            if (webView == null) {
                Intrinsics.p("webView");
                throw null;
            }
            webView.setFitsSystemWindows(true);
            p0().setFitsSystemWindows(true);
            ((ToolbarShadow) this.f81103t.getValue(this, kPropertyArr[1])).setVisibility(4);
            ViewCompat.setOnApplyWindowInsetsListener((CoordinatorLayout) aVar2.getValue(this, kPropertyArr[2]), new nef.e(this, 7));
        } else {
            layoutParams.setBehavior(new AppBarLayout.ScrollingViewBehavior());
        }
        WebView webView2 = this.A;
        if (webView2 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView2.setLayoutParams(layoutParams);
        WebView webView3 = this.A;
        if (webView3 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView3.getSettings().setJavaScriptEnabled(true);
        WebView webView4 = this.A;
        if (webView4 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView4.getSettings().setDomStorageEnabled(true);
        WebView webView5 = this.A;
        if (webView5 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView5.setFocusable(true);
        WebView webView6 = this.A;
        if (webView6 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView6.setFocusableInTouchMode(true);
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) aVar2.getValue(this, kPropertyArr[2]);
        WebView webView7 = this.A;
        if (webView7 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        coordinatorLayout.addView(webView7, 0);
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration5 = this.D;
        if (webViewContract$WebViewConfiguration5 == null) {
            Intrinsics.p("config");
            throw null;
        }
        String str = webViewContract$WebViewConfiguration5.f81113h;
        v0(str, r0());
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration6 = this.D;
        if (webViewContract$WebViewConfiguration6 == null) {
            Intrinsics.p("config");
            throw null;
        }
        if (webViewContract$WebViewConfiguration6.k) {
            v0(str, s0());
        }
        WebView webView8 = this.A;
        if (webView8 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView8.setWebChromeClient(new bl3.g(this, 3));
        WebView webView9 = this.A;
        if (webView9 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView9.setDownloadListener(new bl3.e(this, 1));
        WebView webView10 = this.A;
        if (webView10 == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView10.setWebViewClient((ngf.e) this.K.getValue());
        final int i3 = 0;
        r0().setNavigationOnClickListener(new View.OnClickListener(this) { // from class: ngf.c

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ WebViewActivity f216996b;

            {
                this.f216996b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i7 = i3;
                WebViewActivity webViewActivity = this.f216996b;
                switch (i7) {
                    case 0:
                        KProperty[] kPropertyArr2 = WebViewActivity.O;
                        webViewActivity.finish();
                        break;
                    default:
                        KProperty[] kPropertyArr3 = WebViewActivity.O;
                        webViewActivity.finish();
                        break;
                }
            }
        });
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration7 = this.D;
        if (webViewContract$WebViewConfiguration7 == null) {
            Intrinsics.p("config");
            throw null;
        }
        Clause clause = webViewContract$WebViewConfiguration7.f81108b;
        r0().setTitle(clause != null ? c.a(y1.a(this).l(), clause, this, null, null, null, null, Constants.TAG_FC_SPEED_MODE) : null);
        CustomViewRevolutToolbar customViewRevolutToolbarR0 = r0();
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration8 = this.D;
        if (webViewContract$WebViewConfiguration8 == null) {
            Intrinsics.p("config");
            throw null;
        }
        customViewRevolutToolbarR0.setNavigationIcon(webViewContract$WebViewConfiguration8.f81109c);
        CustomViewRevolutToolbar customViewRevolutToolbarR02 = r0();
        g gVar = this.G;
        if (gVar == null) {
            Intrinsics.p("localization");
            throw null;
        }
        customViewRevolutToolbarR02.setNavigationContentDescription(gVar.getString(R$string.uikit_navigate_up_description));
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration9 = this.D;
        if (webViewContract$WebViewConfiguration9 == null) {
            Intrinsics.p("config");
            throw null;
        }
        if (webViewContract$WebViewConfiguration9.k) {
            WebView webView11 = this.A;
            if (webView11 == null) {
                Intrinsics.p("webView");
                throw null;
            }
            ngf.g onScrollChangedCallback = new ngf.g(this, 0);
            Intrinsics.checkNotNullParameter(onScrollChangedCallback, "onScrollChangedCallback");
            webView11.f42221b.add(onScrollChangedCallback);
            final int i7 = 1;
            s0().setNavigationOnClickListener(new View.OnClickListener(this) { // from class: ngf.c

                /* renamed from: b, reason: collision with root package name */
                public final /* synthetic */ WebViewActivity f216996b;

                {
                    this.f216996b = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i710 = i7;
                    WebViewActivity webViewActivity = this.f216996b;
                    switch (i710) {
                        case 0:
                            KProperty[] kPropertyArr2 = WebViewActivity.O;
                            webViewActivity.finish();
                            break;
                        default:
                            KProperty[] kPropertyArr3 = WebViewActivity.O;
                            webViewActivity.finish();
                            break;
                    }
                }
            });
            CustomViewRevolutToolbar customViewRevolutToolbarS0 = s0();
            WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration10 = this.D;
            if (webViewContract$WebViewConfiguration10 == null) {
                Intrinsics.p("config");
                throw null;
            }
            customViewRevolutToolbarS0.setNavigationIcon(webViewContract$WebViewConfiguration10.f81110d);
            CustomViewRevolutToolbar customViewRevolutToolbarS02 = s0();
            g gVar2 = this.G;
            if (gVar2 == null) {
                Intrinsics.p("localization");
                throw null;
            }
            customViewRevolutToolbarS02.setNavigationContentDescription(gVar2.getString(R$string.uikit_navigate_up_description));
            s0().setVisibility(0);
        }
    }

    @Override // com.revolut.retail.core.ui.activity.BaseDelegatesActivity, hqf.b, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        this.C.dispose();
        WebView webView = this.A;
        if (webView == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView.destroy();
        super.onDestroy();
    }

    @Override // com.revolut.retail.core.ui.activity.BaseDelegatesActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onPause() {
        super.onPause();
        WebView webView = this.A;
        if (webView != null) {
            webView.onPause();
        } else {
            Intrinsics.p("webView");
            throw null;
        }
    }

    @Override // com.revolut.retail.core.ui.activity.BaseDelegatesActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        WebView webView = this.A;
        if (webView == null) {
            Intrinsics.p("webView");
            throw null;
        }
        webView.onResume();
        super.onResume();
    }

    public final RevolutAppBarLayout p0() {
        return (RevolutAppBarLayout) this.f81102s.getValue(this, O[0]);
    }

    public final FullScreenStateView q0() {
        return (FullScreenStateView) this.f81105y.getValue(this, O[5]);
    }

    public final CustomViewRevolutToolbar r0() {
        return (CustomViewRevolutToolbar) this.x.getValue(this, O[4]);
    }

    public final CustomViewRevolutToolbar s0() {
        return (CustomViewRevolutToolbar) this.f81104w.getValue(this, O[3]);
    }

    public final void t0(boolean z2) {
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration = this.D;
        if (webViewContract$WebViewConfiguration == null) {
            Intrinsics.p("config");
            throw null;
        }
        if (webViewContract$WebViewConfiguration.f81112g) {
            ((ProgressBar) this.f81106z.getValue(this, O[6])).setVisibility(z2 ? 0 : 8);
        }
    }

    @Override // hqf.b, li0.e
    public final boolean v() {
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration = this.D;
        if (webViewContract$WebViewConfiguration != null) {
            return webViewContract$WebViewConfiguration.q;
        }
        Intrinsics.p("config");
        throw null;
    }

    public final void v0(String str, CustomViewRevolutToolbar customViewRevolutToolbar) {
        MenuItem menuItemFindItem = customViewRevolutToolbar.getMenu().findItem(R$id.menu_item_save);
        View actionView = menuItemFindItem.getActionView();
        View viewFindViewById = actionView != null ? actionView.findViewById(com.revolut.uicomponent.R$id.menu_button_item) : null;
        Intrinsics.h(viewFindViewById, "null cannot be cast to non-null type android.widget.TextView");
        TextView textView = (TextView) viewFindViewById;
        g gVar = this.G;
        if (gVar == null) {
            Intrinsics.p("localization");
            throw null;
        }
        textView.setText(gVar.getString(com.revolut.feature_web_view.R$string.web_view_action_save));
        if (str == null) {
            menuItemFindItem.setVisible(false);
            return;
        }
        View actionView2 = customViewRevolutToolbar.getMenu().findItem(R$id.menu_item_save).getActionView();
        if (actionView2 != null) {
            actionView2.setOnClickListener(new ko0.c(this, str, 8));
        }
        menuItemFindItem.setVisible(true);
    }

    @Override // xpf.a
    public final boolean w() {
        WebViewContract$WebViewConfiguration webViewContract$WebViewConfiguration = this.D;
        if (webViewContract$WebViewConfiguration != null) {
            return webViewContract$WebViewConfiguration.f;
        }
        Intrinsics.p("config");
        throw null;
    }
}
