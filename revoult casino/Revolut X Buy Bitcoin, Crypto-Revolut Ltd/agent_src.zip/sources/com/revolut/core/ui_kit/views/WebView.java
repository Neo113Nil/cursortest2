package com.revolut.core.ui_kit.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.WindowInsets;
import androidx.core.view.ScrollingView;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;
import es0.r0;
import es0.v1;
import is0.ld;
import java.util.Iterator;
import java.util.LinkedHashSet;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* compiled from: r8-map-id-071999a0b6822bc9972c83579ab71bc8e2fdf035ee52baca40f01bfb3fb674fb */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003:\u0001\u0004¨\u0006\u0005"}, d2 = {"Lcom/revolut/core/ui_kit/views/WebView;", "Landroid/webkit/WebView;", "Landroidx/core/view/ScrollingView;", "Les0/r0;", "is0/ld", "ui_kit_components_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes13.dex */
public final class WebView extends android.webkit.WebView implements ScrollingView, r0 {

    /* renamed from: a, reason: collision with root package name */
    public final v1 f42220a;

    /* renamed from: b, reason: collision with root package name */
    public final LinkedHashSet f42221b;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public WebView(@NotNull Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 4);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.webkit.WebView, android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.webkit.WebView, android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    @Override // android.webkit.WebView, android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.webkit.WebView, android.view.View, androidx.core.view.ScrollingView
    public final int computeVerticalScrollOffset() {
        return super.computeVerticalScrollOffset();
    }

    @Override // android.webkit.WebView, android.view.View
    public final int computeVerticalScrollRange() {
        return super.computeVerticalScrollRange();
    }

    @Override // es0.r0, es0.q0
    public /* bridge */ boolean getInsetsAdjustable() {
        return super.getInsetsAdjustable();
    }

    @Override // android.webkit.WebView, android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets insets) {
        Intrinsics.checkNotNullParameter(insets, "insets");
        return super.onApplyWindowInsets(this.f42220a.a(insets));
    }

    @Override // android.webkit.WebView, android.view.View
    public final void onScrollChanged(int i3, int i7, int i12, int i15) {
        super.onScrollChanged(i3, i7, i12, i15);
        Iterator it2 = this.f42221b.iterator();
        while (it2.hasNext()) {
            ((ld) it2.next()).a();
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public WebView(Context context, AttributeSet attributeSet, int i3) {
        attributeSet = (i3 & 2) != 0 ? null : attributeSet;
        Intrinsics.checkNotNullParameter(context, "context");
        super(context, attributeSet, 0);
        this.f42220a = new v1(this);
        if ((getResources().getConfiguration().uiMode & 48) == 32 && WebViewFeature.isFeatureSupported("FORCE_DARK_STRATEGY") && WebViewFeature.isFeatureSupported("FORCE_DARK")) {
            WebSettingsCompat.setForceDark(getSettings(), 2);
            WebSettingsCompat.setForceDarkStrategy(getSettings(), 1);
            setBackgroundColor(0);
        }
        this.f42221b = new LinkedHashSet();
    }
}
