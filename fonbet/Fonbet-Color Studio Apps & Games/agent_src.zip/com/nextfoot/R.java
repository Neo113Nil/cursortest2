package com.nextfoot;

/* loaded from: classes2.dex */
public final class R {

    public static final class color {
        public static int black = 0x7f020002;
        public static int ic_launcher_background = 0x7f020009;
        public static int purple_200 = 0x7f02000c;
        public static int purple_500 = 0x7f02000d;
        public static int purple_700 = 0x7f02000e;
        public static int teal_200 = 0x7f02000f;
        public static int teal_700 = 0x7f020010;
        public static int white = 0x7f020013;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher_background = 0x7f040008;
        public static int ic_launcher_foreground = 0x7f040009;
        public static int icon_back = 0x7f04000a;
        public static int icon_basket = 0x7f04000b;
        public static int icon_bets = 0x7f04000c;
        public static int icon_favorite = 0x7f04000d;
        public static int icon_favorite_filled = 0x7f04000e;
        public static int icon_game = 0x7f04000f;
        public static int icon_menu = 0x7f040010;
        public static int icon_profile = 0x7f040011;
        public static int icon_schedule = 0x7f040012;
        public static int icon_shield = 0x7f040013;
        public static int icon_timer = 0x7f040014;
        public static int image_avatar = 0x7f040015;
        public static int image_ball = 0x7f040016;
        public static int image_bets = 0x7f040017;
        public static int image_field = 0x7f040018;
        public static int image_golden_ball = 0x7f040019;
        public static int image_splash = 0x7f04001a;
        public static int image_text_field = 0x7f04001b;

        private drawable() {
        }
    }

    public static final class font {
        public static int alumnisans_bold = 0x7f050000;
        public static int sourcesans3_bold = 0x7f050001;
        public static int sourcesans3_extrabold = 0x7f050002;
        public static int sourcesans3_light = 0x7f050003;
        public static int sourcesans3_regular = 0x7f050004;
        public static int sourcesans3_semibold = 0x7f050005;

        private font() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f090000;
        public static int ic_launcher_foreground = 0x7f090001;
        public static int ic_launcher_round = 0x7f090002;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0a0001;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_NextFoot = 0x7f0b0009;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 0x7f0d0000;
        public static int data_extraction_rules = 0x7f0d0001;

        private xml() {
        }
    }

    private R() {
    }
}
