package com.nextfoot.model;

import com.nextfoot.database.FavoriteEntity;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: EventModel.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001Bg\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u000f\u0010\u0010J\u0006\u0010\u001e\u001a\u00020\u001fJ\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0005HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\nHÆ\u0003J\u000b\u0010&\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010'\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010(\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010)\u001a\u0004\u0018\u00010\u0005HÆ\u0003Ju\u0010*\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010+\u001a\u00020,2\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010.\u001a\u00020\u0003HÖ\u0001J\t\u0010/\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0014R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u0013\u0010\r\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0014R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0014¨\u00060"}, d2 = {"Lcom/nextfoot/model/EventModel;", "", "id", "", "homeTeamName", "", "awayTeamName", "goalsHome", "goalsAway", "timestamp", "", "referee", "country", "league", "stadium", "<init>", "(ILjava/lang/String;Ljava/lang/String;IIJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getId", "()I", "getHomeTeamName", "()Ljava/lang/String;", "getAwayTeamName", "getGoalsHome", "getGoalsAway", "getTimestamp", "()J", "getReferee", "getCountry", "getLeague", "getStadium", "createFavoriteEntity", "Lcom/nextfoot/database/FavoriteEntity;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class EventModel {
    public static final int $stable = 0;
    private final String awayTeamName;
    private final String country;
    private final int goalsAway;
    private final int goalsHome;
    private final String homeTeamName;
    private final int id;
    private final String league;
    private final String referee;
    private final String stadium;
    private final long timestamp;

    public static /* synthetic */ EventModel copy$default(EventModel eventModel, int i, String str, String str2, int i2, int i3, long j, String str3, String str4, String str5, String str6, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = eventModel.id;
        }
        if ((i4 & 2) != 0) {
            str = eventModel.homeTeamName;
        }
        if ((i4 & 4) != 0) {
            str2 = eventModel.awayTeamName;
        }
        if ((i4 & 8) != 0) {
            i2 = eventModel.goalsHome;
        }
        if ((i4 & 16) != 0) {
            i3 = eventModel.goalsAway;
        }
        if ((i4 & 32) != 0) {
            j = eventModel.timestamp;
        }
        if ((i4 & 64) != 0) {
            str3 = eventModel.referee;
        }
        if ((i4 & 128) != 0) {
            str4 = eventModel.country;
        }
        if ((i4 & 256) != 0) {
            str5 = eventModel.league;
        }
        if ((i4 & 512) != 0) {
            str6 = eventModel.stadium;
        }
        long j2 = j;
        int i5 = i2;
        int i6 = i3;
        String str7 = str2;
        return eventModel.copy(i, str, str7, i5, i6, j2, str3, str4, str5, str6);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component10, reason: from getter */
    public final String getStadium() {
        return this.stadium;
    }

    /* renamed from: component2, reason: from getter */
    public final String getHomeTeamName() {
        return this.homeTeamName;
    }

    /* renamed from: component3, reason: from getter */
    public final String getAwayTeamName() {
        return this.awayTeamName;
    }

    /* renamed from: component4, reason: from getter */
    public final int getGoalsHome() {
        return this.goalsHome;
    }

    /* renamed from: component5, reason: from getter */
    public final int getGoalsAway() {
        return this.goalsAway;
    }

    /* renamed from: component6, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    /* renamed from: component7, reason: from getter */
    public final String getReferee() {
        return this.referee;
    }

    /* renamed from: component8, reason: from getter */
    public final String getCountry() {
        return this.country;
    }

    /* renamed from: component9, reason: from getter */
    public final String getLeague() {
        return this.league;
    }

    public final EventModel copy(int id, String homeTeamName, String awayTeamName, int goalsHome, int goalsAway, long timestamp, String referee, String country, String league, String stadium) {
        Intrinsics.checkNotNullParameter(homeTeamName, "homeTeamName");
        Intrinsics.checkNotNullParameter(awayTeamName, "awayTeamName");
        return new EventModel(id, homeTeamName, awayTeamName, goalsHome, goalsAway, timestamp, referee, country, league, stadium);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof EventModel)) {
            return false;
        }
        EventModel eventModel = (EventModel) other;
        return this.id == eventModel.id && Intrinsics.areEqual(this.homeTeamName, eventModel.homeTeamName) && Intrinsics.areEqual(this.awayTeamName, eventModel.awayTeamName) && this.goalsHome == eventModel.goalsHome && this.goalsAway == eventModel.goalsAway && this.timestamp == eventModel.timestamp && Intrinsics.areEqual(this.referee, eventModel.referee) && Intrinsics.areEqual(this.country, eventModel.country) && Intrinsics.areEqual(this.league, eventModel.league) && Intrinsics.areEqual(this.stadium, eventModel.stadium);
    }

    public int hashCode() {
        int iHashCode = ((((((((((Integer.hashCode(this.id) * 31) + this.homeTeamName.hashCode()) * 31) + this.awayTeamName.hashCode()) * 31) + Integer.hashCode(this.goalsHome)) * 31) + Integer.hashCode(this.goalsAway)) * 31) + Long.hashCode(this.timestamp)) * 31;
        String str = this.referee;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.country;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.league;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.stadium;
        return iHashCode4 + (str4 != null ? str4.hashCode() : 0);
    }

    public String toString() {
        return "EventModel(id=" + this.id + ", homeTeamName=" + this.homeTeamName + ", awayTeamName=" + this.awayTeamName + ", goalsHome=" + this.goalsHome + ", goalsAway=" + this.goalsAway + ", timestamp=" + this.timestamp + ", referee=" + this.referee + ", country=" + this.country + ", league=" + this.league + ", stadium=" + this.stadium + ")";
    }

    public EventModel(int i, String homeTeamName, String awayTeamName, int i2, int i3, long j, String str, String str2, String str3, String str4) {
        Intrinsics.checkNotNullParameter(homeTeamName, "homeTeamName");
        Intrinsics.checkNotNullParameter(awayTeamName, "awayTeamName");
        this.id = i;
        this.homeTeamName = homeTeamName;
        this.awayTeamName = awayTeamName;
        this.goalsHome = i2;
        this.goalsAway = i3;
        this.timestamp = j;
        this.referee = str;
        this.country = str2;
        this.league = str3;
        this.stadium = str4;
    }

    public /* synthetic */ EventModel(int i, String str, String str2, int i2, int i3, long j, String str3, String str4, String str5, String str6, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        this(i, str, str2, i2, i3, j, (i4 & 64) != 0 ? null : str3, (i4 & 128) != 0 ? null : str4, (i4 & 256) != 0 ? null : str5, (i4 & 512) != 0 ? null : str6);
    }

    public final int getId() {
        return this.id;
    }

    public final String getHomeTeamName() {
        return this.homeTeamName;
    }

    public final String getAwayTeamName() {
        return this.awayTeamName;
    }

    public final int getGoalsHome() {
        return this.goalsHome;
    }

    public final int getGoalsAway() {
        return this.goalsAway;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final String getReferee() {
        return this.referee;
    }

    public final String getCountry() {
        return this.country;
    }

    public final String getLeague() {
        return this.league;
    }

    public final String getStadium() {
        return this.stadium;
    }

    public final FavoriteEntity createFavoriteEntity() {
        return new FavoriteEntity(this.id, this.homeTeamName, this.awayTeamName, this.goalsHome, this.goalsAway, this.timestamp);
    }
}
