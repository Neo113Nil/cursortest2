package com.nextfoot.model;

import androidx.core.app.NotificationCompat;
import com.nextfoot.database.ProfileEntity;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ProfileModel.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\u0006\u0010\u000e\u001a\u00020\u000fJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u001b"}, d2 = {"Lcom/nextfoot/model/ProfileModel;", "", "name", "", NotificationCompat.CATEGORY_EMAIL, "favoriteSport", "profilePictureUri", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getName", "()Ljava/lang/String;", "getEmail", "getFavoriteSport", "getProfilePictureUri", "createProfileEntity", "Lcom/nextfoot/database/ProfileEntity;", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class ProfileModel {
    public static final int $stable = 0;
    private final String email;
    private final String favoriteSport;
    private final String name;
    private final String profilePictureUri;

    public ProfileModel() {
        this(null, null, null, null, 15, null);
    }

    public static /* synthetic */ ProfileModel copy$default(ProfileModel profileModel, String str, String str2, String str3, String str4, int i, Object obj) {
        if ((i & 1) != 0) {
            str = profileModel.name;
        }
        if ((i & 2) != 0) {
            str2 = profileModel.email;
        }
        if ((i & 4) != 0) {
            str3 = profileModel.favoriteSport;
        }
        if ((i & 8) != 0) {
            str4 = profileModel.profilePictureUri;
        }
        return profileModel.copy(str, str2, str3, str4);
    }

    /* renamed from: component1, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* renamed from: component2, reason: from getter */
    public final String getEmail() {
        return this.email;
    }

    /* renamed from: component3, reason: from getter */
    public final String getFavoriteSport() {
        return this.favoriteSport;
    }

    /* renamed from: component4, reason: from getter */
    public final String getProfilePictureUri() {
        return this.profilePictureUri;
    }

    public final ProfileModel copy(String name, String email, String favoriteSport, String profilePictureUri) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(email, "email");
        Intrinsics.checkNotNullParameter(favoriteSport, "favoriteSport");
        Intrinsics.checkNotNullParameter(profilePictureUri, "profilePictureUri");
        return new ProfileModel(name, email, favoriteSport, profilePictureUri);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ProfileModel)) {
            return false;
        }
        ProfileModel profileModel = (ProfileModel) other;
        return Intrinsics.areEqual(this.name, profileModel.name) && Intrinsics.areEqual(this.email, profileModel.email) && Intrinsics.areEqual(this.favoriteSport, profileModel.favoriteSport) && Intrinsics.areEqual(this.profilePictureUri, profileModel.profilePictureUri);
    }

    public int hashCode() {
        return (((((this.name.hashCode() * 31) + this.email.hashCode()) * 31) + this.favoriteSport.hashCode()) * 31) + this.profilePictureUri.hashCode();
    }

    public String toString() {
        return "ProfileModel(name=" + this.name + ", email=" + this.email + ", favoriteSport=" + this.favoriteSport + ", profilePictureUri=" + this.profilePictureUri + ")";
    }

    public ProfileModel(String name, String email, String favoriteSport, String profilePictureUri) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(email, "email");
        Intrinsics.checkNotNullParameter(favoriteSport, "favoriteSport");
        Intrinsics.checkNotNullParameter(profilePictureUri, "profilePictureUri");
        this.name = name;
        this.email = email;
        this.favoriteSport = favoriteSport;
        this.profilePictureUri = profilePictureUri;
    }

    public /* synthetic */ ProfileModel(String str, String str2, String str3, String str4, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "Игрок" : str, (i & 2) != 0 ? "testmail@test.com" : str2, (i & 4) != 0 ? "футбол" : str3, (i & 8) != 0 ? "" : str4);
    }

    public final String getName() {
        return this.name;
    }

    public final String getEmail() {
        return this.email;
    }

    public final String getFavoriteSport() {
        return this.favoriteSport;
    }

    public final String getProfilePictureUri() {
        return this.profilePictureUri;
    }

    public final ProfileEntity createProfileEntity() {
        return new ProfileEntity(0, this.name, this.email, this.favoriteSport, this.profilePictureUri, 1, null);
    }
}
