package com.nextfoot.viewmodel;

import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import androidx.room.Room;
import com.nextfoot.backend.BackendManager;
import com.nextfoot.database.DatabaseBuilder;
import com.nextfoot.database.FavoriteDao;
import com.nextfoot.database.FavoriteEntity;
import com.nextfoot.database.ProfileDao;
import com.nextfoot.database.ProfileEntity;
import com.nextfoot.model.EventModel;
import com.nextfoot.model.ProfileModel;
import com.nextfoot.response.ScheduleResponse;
import com.nextfoot.ui.classes.BallState;
import io.ktor.http.ContentType;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.internal.ProgressionUtilKt;
import kotlin.io.ByteStreamsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import okhttp3.internal.ws.WebSocketProtocol;

/* compiled from: MainViewModel.kt */
@Metadata(d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\u0007\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010?\u001a\u00020FH\u0002J\b\u0010G\u001a\u00020FH\u0002J\u000e\u0010H\u001a\u00020F2\u0006\u0010I\u001a\u00020\u0011J\u0010\u0010J\u001a\u00020:2\u0006\u0010K\u001a\u00020$H\u0002J\u000e\u0010L\u001a\u00020F2\u0006\u0010I\u001a\u00020\u0011J\u0006\u0010M\u001a\u00020FJ\u0016\u0010N\u001a\u00020F2\u0006\u0010O\u001a\u00020P2\u0006\u0010Q\u001a\u00020PJ\u0018\u0010R\u001a\u00020F2\u0006\u0010S\u001a\u00020P2\u0006\u0010T\u001a\u00020PH\u0002J\b\u0010U\u001a\u00020FH\u0002J\b\u0010V\u001a\u00020FH\u0002J\b\u0010W\u001a\u00020FH\u0002J\u0006\u0010X\u001a\u00020FJ\u0016\u0010Y\u001a\u00020F2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010Z\u001a\u000203J\u001a\u0010[\u001a\u0004\u0018\u00010:2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\\\u001a\u00020]H\u0002J\u0012\u0010^\u001a\u00020F2\b\u0010_\u001a\u0004\u0018\u00010:H\u0002J\u0006\u0010`\u001a\u00020FR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u000e\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001f\u0010\u0012\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u00100\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0016\u0010\u0016\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0017\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0015R\u001a\u0010\u0019\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00110\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u001a\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00110\u00100\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0015R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001d0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0015R\u0014\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001d0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010!\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0013¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0015R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020$0\u0013¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0015R\u0014\u0010'\u001a\b\u0012\u0004\u0012\u00020$0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010(\u001a\b\u0012\u0004\u0012\u00020$0\u0013¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u0015R\u0014\u0010*\u001a\b\u0012\u0004\u0012\u00020+0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010,\u001a\b\u0012\u0004\u0012\u00020+0\u0013¢\u0006\b\n\u0000\u001a\u0004\b-\u0010\u0015R\u0010\u0010.\u001a\u0004\u0018\u00010/X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u00100\u001a\b\u0012\u0004\u0012\u00020\u001d0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00101\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0013¢\u0006\b\n\u0000\u001a\u0004\b1\u0010\u0015R\u0014\u00102\u001a\b\u0012\u0004\u0012\u0002030\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00104\u001a\b\u0012\u0004\u0012\u0002030\u0013¢\u0006\b\n\u0000\u001a\u0004\b5\u0010\u0015R\u0014\u00106\u001a\b\u0012\u0004\u0012\u00020\u001d0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00107\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0013¢\u0006\b\n\u0000\u001a\u0004\b8\u0010\u0015R\u0014\u00109\u001a\b\u0012\u0004\u0012\u00020:0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010;\u001a\b\u0012\u0004\u0012\u00020:0\u0013¢\u0006\b\n\u0000\u001a\u0004\b<\u0010\u0015R\u0016\u0010=\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010:0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010>\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010:0\u0013¢\u0006\b\n\u0000\u001a\u0004\b?\u0010\u0015R\u0014\u0010@\u001a\b\u0012\u0004\u0012\u00020:0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010A\u001a\b\u0012\u0004\u0012\u00020:0\u0013¢\u0006\b\n\u0000\u001a\u0004\bB\u0010\u0015R\u0014\u0010C\u001a\b\u0012\u0004\u0012\u00020:0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010D\u001a\b\u0012\u0004\u0012\u00020:0\u0013¢\u0006\b\n\u0000\u001a\u0004\bE\u0010\u0015¨\u0006a"}, d2 = {"Lcom/nextfoot/viewmodel/MainViewModel;", "Landroidx/lifecycle/ViewModel;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "databaseBuilder", "Lcom/nextfoot/database/DatabaseBuilder;", "favoriteDao", "Lcom/nextfoot/database/FavoriteDao;", "profileDao", "Lcom/nextfoot/database/ProfileDao;", "backendManager", "Lcom/nextfoot/backend/BackendManager;", "_eventsList", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "Lcom/nextfoot/model/EventModel;", "eventsList", "Lkotlinx/coroutines/flow/StateFlow;", "getEventsList", "()Lkotlinx/coroutines/flow/StateFlow;", "_event", NotificationCompat.CATEGORY_EVENT, "getEvent", "_favoriteList", "favoriteList", "getFavoriteList", "_gameStarted", "", "gameStarted", "getGameStarted", "_gameOver", "gameOver", "getGameOver", "_gameScore", "", "gameScore", "getGameScore", "_gameTime", "gameTime", "getGameTime", "_ballState", "Lcom/nextfoot/ui/classes/BallState;", "ballState", "getBallState", "gameTimer", "Ljava/util/Timer;", "_isGoldenBall", "isGoldenBall", "_profile", "Lcom/nextfoot/model/ProfileModel;", "profile", "getProfile", "_profileCleared", "profileCleared", "getProfileCleared", "_bets", "", "bets", "getBets", "_text", ContentType.Text.TYPE, "getText", "_privacyPolicy", "privacyPolicy", "getPrivacyPolicy", "_supportMail", "supportMail", "getSupportMail", "", "getEventsAndProfile", "onEvent", "eventModel", "getTargetDate", "hourThreshold", "onFavorite", "startGame", "throwBall", "tapX", "", "tapY", "checkScore", "endX", "endY", "generateNextBall", "startTimer", "endGame", "resetGame", "updateProfile", "profileModel", "copyUriToInternalStorage", "uri", "Landroid/net/Uri;", "deleteProfilePicture", "internalPath", "deleteProfile", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class MainViewModel extends ViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<BallState> _ballState;
    private final MutableStateFlow<String> _bets;
    private final MutableStateFlow<EventModel> _event;
    private final MutableStateFlow<List<EventModel>> _eventsList;
    private final MutableStateFlow<List<EventModel>> _favoriteList;
    private final MutableStateFlow<Boolean> _gameOver;
    private final MutableStateFlow<Integer> _gameScore;
    private final MutableStateFlow<Boolean> _gameStarted;
    private final MutableStateFlow<Integer> _gameTime;
    private final MutableStateFlow<Boolean> _isGoldenBall;
    private final MutableStateFlow<String> _privacyPolicy;
    private final MutableStateFlow<ProfileModel> _profile;
    private final MutableStateFlow<Boolean> _profileCleared;
    private final MutableStateFlow<String> _supportMail;
    private final MutableStateFlow<String> _text;
    private final BackendManager backendManager;
    private final StateFlow<BallState> ballState;
    private final StateFlow<String> bets;
    private final DatabaseBuilder databaseBuilder;
    private final StateFlow<EventModel> event;
    private final StateFlow<List<EventModel>> eventsList;
    private final FavoriteDao favoriteDao;
    private final StateFlow<List<EventModel>> favoriteList;
    private final StateFlow<Boolean> gameOver;
    private final StateFlow<Integer> gameScore;
    private final StateFlow<Boolean> gameStarted;
    private final StateFlow<Integer> gameTime;
    private Timer gameTimer;
    private final StateFlow<Boolean> isGoldenBall;
    private final StateFlow<String> privacyPolicy;
    private final StateFlow<ProfileModel> profile;
    private final StateFlow<Boolean> profileCleared;
    private final ProfileDao profileDao;
    private final StateFlow<String> supportMail;
    private final StateFlow<String> text;

    public MainViewModel(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        Context applicationContext = context.getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
        DatabaseBuilder databaseBuilder = (DatabaseBuilder) Room.databaseBuilder(applicationContext, DatabaseBuilder.class, "db2").build();
        this.databaseBuilder = databaseBuilder;
        this.favoriteDao = databaseBuilder.favoriteDao();
        this.profileDao = databaseBuilder.profileDao();
        this.backendManager = new BackendManager(context);
        MutableStateFlow<List<EventModel>> MutableStateFlow = StateFlowKt.MutableStateFlow(null);
        this._eventsList = MutableStateFlow;
        this.eventsList = FlowKt.asStateFlow(MutableStateFlow);
        MutableStateFlow<EventModel> MutableStateFlow2 = StateFlowKt.MutableStateFlow(null);
        this._event = MutableStateFlow2;
        this.event = FlowKt.asStateFlow(MutableStateFlow2);
        MutableStateFlow<List<EventModel>> MutableStateFlow3 = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
        this._favoriteList = MutableStateFlow3;
        this.favoriteList = FlowKt.asStateFlow(MutableStateFlow3);
        MutableStateFlow<Boolean> MutableStateFlow4 = StateFlowKt.MutableStateFlow(false);
        this._gameStarted = MutableStateFlow4;
        this.gameStarted = FlowKt.asStateFlow(MutableStateFlow4);
        MutableStateFlow<Boolean> MutableStateFlow5 = StateFlowKt.MutableStateFlow(false);
        this._gameOver = MutableStateFlow5;
        this.gameOver = FlowKt.asStateFlow(MutableStateFlow5);
        MutableStateFlow<Integer> MutableStateFlow6 = StateFlowKt.MutableStateFlow(0);
        this._gameScore = MutableStateFlow6;
        this.gameScore = FlowKt.asStateFlow(MutableStateFlow6);
        MutableStateFlow<Integer> MutableStateFlow7 = StateFlowKt.MutableStateFlow(45);
        this._gameTime = MutableStateFlow7;
        this.gameTime = FlowKt.asStateFlow(MutableStateFlow7);
        MutableStateFlow<BallState> MutableStateFlow8 = StateFlowKt.MutableStateFlow(BallState.Idle.INSTANCE);
        this._ballState = MutableStateFlow8;
        this.ballState = FlowKt.asStateFlow(MutableStateFlow8);
        MutableStateFlow<Boolean> MutableStateFlow9 = StateFlowKt.MutableStateFlow(false);
        this._isGoldenBall = MutableStateFlow9;
        this.isGoldenBall = FlowKt.asStateFlow(MutableStateFlow9);
        MutableStateFlow<ProfileModel> MutableStateFlow10 = StateFlowKt.MutableStateFlow(new ProfileModel(null, null, null, null, 15, null));
        this._profile = MutableStateFlow10;
        this.profile = FlowKt.asStateFlow(MutableStateFlow10);
        MutableStateFlow<Boolean> MutableStateFlow11 = StateFlowKt.MutableStateFlow(false);
        this._profileCleared = MutableStateFlow11;
        this.profileCleared = FlowKt.asStateFlow(MutableStateFlow11);
        byte[] bArrDecode = Base64.decode("aHR0cHM6Ly9zdGF2a2kuY29sb3JzdHVkaW9hcHBzLmNvbS8=", 0);
        Intrinsics.checkNotNullExpressionValue(bArrDecode, "decode(...)");
        MutableStateFlow<String> MutableStateFlow12 = StateFlowKt.MutableStateFlow(new String(bArrDecode, Charsets.UTF_8));
        this._bets = MutableStateFlow12;
        this.bets = FlowKt.asStateFlow(MutableStateFlow12);
        MutableStateFlow<String> MutableStateFlow13 = StateFlowKt.MutableStateFlow(null);
        this._text = MutableStateFlow13;
        this.text = FlowKt.asStateFlow(MutableStateFlow13);
        byte[] bArrDecode2 = Base64.decode("aHR0cHM6Ly9wcml2YWN5LmNvbG9yc3R1ZGlvYXBwcy5jb20v", 0);
        Intrinsics.checkNotNullExpressionValue(bArrDecode2, "decode(...)");
        MutableStateFlow<String> MutableStateFlow14 = StateFlowKt.MutableStateFlow(new String(bArrDecode2, Charsets.UTF_8));
        this._privacyPolicy = MutableStateFlow14;
        this.privacyPolicy = FlowKt.asStateFlow(MutableStateFlow14);
        byte[] bArrDecode3 = Base64.decode("aGF2YW5hZGV2YXBwc0BnbWFpbC5jb20=", 0);
        Intrinsics.checkNotNullExpressionValue(bArrDecode3, "decode(...)");
        MutableStateFlow<String> MutableStateFlow15 = StateFlowKt.MutableStateFlow(new String(bArrDecode3, Charsets.UTF_8));
        this._supportMail = MutableStateFlow15;
        this.supportMail = FlowKt.asStateFlow(MutableStateFlow15);
        getText();
        getEventsAndProfile();
    }

    public final StateFlow<List<EventModel>> getEventsList() {
        return this.eventsList;
    }

    public final StateFlow<EventModel> getEvent() {
        return this.event;
    }

    public final StateFlow<List<EventModel>> getFavoriteList() {
        return this.favoriteList;
    }

    public final StateFlow<Boolean> getGameStarted() {
        return this.gameStarted;
    }

    public final StateFlow<Boolean> getGameOver() {
        return this.gameOver;
    }

    public final StateFlow<Integer> getGameScore() {
        return this.gameScore;
    }

    public final StateFlow<Integer> getGameTime() {
        return this.gameTime;
    }

    public final StateFlow<BallState> getBallState() {
        return this.ballState;
    }

    public final StateFlow<Boolean> isGoldenBall() {
        return this.isGoldenBall;
    }

    public final StateFlow<ProfileModel> getProfile() {
        return this.profile;
    }

    public final StateFlow<Boolean> getProfileCleared() {
        return this.profileCleared;
    }

    public final StateFlow<String> getBets() {
        return this.bets;
    }

    /* renamed from: getText, reason: collision with other method in class */
    public final StateFlow<String> m8588getText() {
        return this.text;
    }

    public final StateFlow<String> getPrivacyPolicy() {
        return this.privacyPolicy;
    }

    public final StateFlow<String> getSupportMail() {
        return this.supportMail;
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$getText$1", f = "MainViewModel.kt", i = {}, l = {115}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$getText$1, reason: invalid class name and case insensitive filesystem */
    static final class C03881 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        C03881(Continuation<? super C03881> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03881(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03881) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            MutableStateFlow mutableStateFlow;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                MutableStateFlow mutableStateFlow2 = MainViewModel.this._text;
                this.L$0 = mutableStateFlow2;
                this.label = 1;
                Object objFetchText = MainViewModel.this.backendManager.fetchText(this);
                if (objFetchText == coroutine_suspended) {
                    return coroutine_suspended;
                }
                mutableStateFlow = mutableStateFlow2;
                obj = objFetchText;
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                mutableStateFlow = (MutableStateFlow) this.L$0;
                ResultKt.throwOnFailure(obj);
            }
            mutableStateFlow.setValue(obj);
            return Unit.INSTANCE;
        }
    }

    private final void getText() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03881(null), 3, null);
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$1", f = "MainViewModel.kt", i = {0}, l = {123}, m = "invokeSuspend", n = {"date"}, s = {"L$0"}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$1, reason: invalid class name and case insensitive filesystem */
    static final class C03861 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        Object L$1;
        int label;

        C03861(Continuation<? super C03861> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03861(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03861) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            MutableStateFlow mutableStateFlow;
            List<EventModel> listEmptyList;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                String targetDate = MainViewModel.this.getTargetDate(20);
                MutableStateFlow mutableStateFlow2 = MainViewModel.this._eventsList;
                this.L$0 = SpillingKt.nullOutSpilledVariable(targetDate);
                this.L$1 = mutableStateFlow2;
                this.label = 1;
                obj = MainViewModel.this.backendManager.fetchScheduleList(targetDate, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
                mutableStateFlow = mutableStateFlow2;
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                mutableStateFlow = (MutableStateFlow) this.L$1;
                ResultKt.throwOnFailure(obj);
            }
            ScheduleResponse scheduleResponse = (ScheduleResponse) obj;
            if (scheduleResponse == null || (listEmptyList = scheduleResponse.createEventsList()) == null) {
                listEmptyList = CollectionsKt.emptyList();
            }
            mutableStateFlow.setValue(listEmptyList);
            return Unit.INSTANCE;
        }
    }

    private final void getEventsAndProfile() {
        MainViewModel mainViewModel = this;
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(mainViewModel), null, null, new C03861(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(mainViewModel), null, null, new C03872(null), 3, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(mainViewModel), null, null, new AnonymousClass3(null), 3, null);
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$2", f = "MainViewModel.kt", i = {}, l = {WebSocketProtocol.PAYLOAD_SHORT}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$2, reason: invalid class name and case insensitive filesystem */
    static final class C03872 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C03872(Continuation<? super C03872> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03872(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03872) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Flow<List<FavoriteEntity>> flowCollectFavoriteList = MainViewModel.this.favoriteDao.collectFavoriteList();
                final MainViewModel mainViewModel = MainViewModel.this;
                this.label = 1;
                if (flowCollectFavoriteList.collect(new FlowCollector() { // from class: com.nextfoot.viewmodel.MainViewModel.getEventsAndProfile.2.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                        return emit((List<FavoriteEntity>) obj2, (Continuation<? super Unit>) continuation);
                    }

                    public final Object emit(List<FavoriteEntity> list, Continuation<? super Unit> continuation) {
                        MutableStateFlow mutableStateFlow = mainViewModel._favoriteList;
                        List<FavoriteEntity> list2 = list;
                        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
                        Iterator<T> it = list2.iterator();
                        while (it.hasNext()) {
                            arrayList.add(((FavoriteEntity) it.next()).createEventModel());
                        }
                        mutableStateFlow.setValue(arrayList);
                        return Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$3", f = "MainViewModel.kt", i = {}, l = {131}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$getEventsAndProfile$3, reason: invalid class name */
    static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new AnonymousClass3(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Flow<ProfileEntity> flowCollectProfileEntity = MainViewModel.this.profileDao.collectProfileEntity();
                final MainViewModel mainViewModel = MainViewModel.this;
                this.label = 1;
                if (flowCollectProfileEntity.collect(new FlowCollector() { // from class: com.nextfoot.viewmodel.MainViewModel.getEventsAndProfile.3.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                        return emit((ProfileEntity) obj2, (Continuation<? super Unit>) continuation);
                    }

                    public final Object emit(ProfileEntity profileEntity, Continuation<? super Unit> continuation) {
                        ProfileModel profileModel;
                        MutableStateFlow mutableStateFlow = mainViewModel._profile;
                        if (profileEntity == null || (profileModel = profileEntity.createProfileModel()) == null) {
                            profileModel = new ProfileModel(null, null, null, null, 15, null);
                        }
                        mutableStateFlow.setValue(profileModel);
                        return Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    public final void onEvent(EventModel eventModel) {
        Intrinsics.checkNotNullParameter(eventModel, "eventModel");
        this._event.setValue(eventModel);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String getTargetDate(int hourThreshold) {
        Calendar calendar = Calendar.getInstance();
        if (calendar.get(11) >= hourThreshold) {
            calendar.add(5, 1);
        }
        String str = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$onFavorite$1", f = "MainViewModel.kt", i = {}, l = {154, 156}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$onFavorite$1, reason: invalid class name and case insensitive filesystem */
    static final class C03891 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ EventModel $eventModel;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C03891(EventModel eventModel, Continuation<? super C03891> continuation) {
            super(2, continuation);
            this.$eventModel = eventModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03891(this.$eventModel, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03891) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:21:0x0069, code lost:
        
            if (r6.this$0.favoriteDao.deleteFavoriteEntity(r6.$eventModel.createFavoriteEntity(), r6) == r0) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x0081, code lost:
        
            if (r6.this$0.favoriteDao.insertFavoriteEntity(r6.$eventModel.createFavoriteEntity(), r6) == r0) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x0083, code lost:
        
            return r0;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                List<EventModel> value = MainViewModel.this.getFavoriteList().getValue();
                EventModel eventModel = this.$eventModel;
                if (!(value instanceof Collection) || !value.isEmpty()) {
                    Iterator<T> it = value.iterator();
                    while (it.hasNext()) {
                        if (((EventModel) it.next()).getId() == eventModel.getId()) {
                            this.label = 1;
                        }
                    }
                }
                this.label = 2;
            } else {
                if (i != 1 && i != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    public final void onFavorite(EventModel eventModel) {
        Intrinsics.checkNotNullParameter(eventModel, "eventModel");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03891(eventModel, null), 3, null);
    }

    public final void startGame() {
        this._gameStarted.setValue(true);
        this._gameOver.setValue(false);
        this._gameScore.setValue(0);
        this._gameTime.setValue(45);
        this._ballState.setValue(BallState.Idle.INSTANCE);
        this._isGoldenBall.setValue(false);
        startTimer();
        generateNextBall();
    }

    public final void throwBall(float tapX, float tapY) {
        if ((this._ballState.getValue() instanceof BallState.Flying) || this._gameOver.getValue().booleanValue() || !this._gameStarted.getValue().booleanValue()) {
            return;
        }
        this._ballState.setValue(new BallState.Flying(tapX, tapY, 0.0f, 4, null));
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03911(tapX, tapY, null), 3, null);
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$throwBall$1", f = "MainViewModel.kt", i = {0}, l = {186}, m = "invokeSuspend", n = {NotificationCompat.CATEGORY_PROGRESS}, s = {"I$0"}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$throwBall$1, reason: invalid class name and case insensitive filesystem */
    static final class C03911 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ float $tapX;
        final /* synthetic */ float $tapY;
        int I$0;
        int I$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C03911(float f, float f2, Continuation<? super C03911> continuation) {
            super(2, continuation);
            this.$tapX = f;
            this.$tapY = f2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03911(this.$tapX, this.$tapY, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03911) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0038  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x0062  */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0073  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:14:0x005d -> B:16:0x0060). Please report as a decompilation issue!!! */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            int i;
            int i2;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i3 = this.label;
            if (i3 == 0) {
                ResultKt.throwOnFailure(obj);
                int progressionLastElement = ProgressionUtilKt.getProgressionLastElement(0, 100, 2);
                if (progressionLastElement >= 0) {
                    i = 0;
                    i2 = progressionLastElement;
                    if (MainViewModel.this._ballState.getValue() instanceof BallState.Flying) {
                    }
                }
                if (MainViewModel.this._ballState.getValue() instanceof BallState.Flying) {
                }
                return Unit.INSTANCE;
            }
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            i2 = this.I$1;
            i = this.I$0;
            ResultKt.throwOnFailure(obj);
            if (i != i2) {
                i += 2;
                if (MainViewModel.this._ballState.getValue() instanceof BallState.Flying) {
                    MainViewModel.this._ballState.setValue(new BallState.Flying(this.$tapX, this.$tapY, i / 100.0f));
                    this.I$0 = i;
                    this.I$1 = i2;
                    this.label = 1;
                    if (DelayKt.delay(16L, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    if (i != i2) {
                    }
                }
            }
            if (MainViewModel.this._ballState.getValue() instanceof BallState.Flying) {
                MainViewModel.this.checkScore(this.$tapX, this.$tapY);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void checkScore(float endX, float endY) {
        float fAbs = Math.abs(endX - 540.0f);
        float fAbs2 = Math.abs(endY - 400.0f);
        if (fAbs <= 80.0f && fAbs2 <= 80.0f) {
            int i = this._isGoldenBall.getValue().booleanValue() ? 5 : 2;
            MutableStateFlow<Integer> mutableStateFlow = this._gameScore;
            mutableStateFlow.setValue(Integer.valueOf(mutableStateFlow.getValue().intValue() + i));
            this._ballState.setValue(BallState.Scored.INSTANCE);
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass1(null), 3, null);
            return;
        }
        this._ballState.setValue(BallState.Missed.INSTANCE);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass2(null), 3, null);
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$checkScore$1", f = "MainViewModel.kt", i = {}, l = {209}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$checkScore$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (DelayKt.delay(500L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            MainViewModel.this.generateNextBall();
            return Unit.INSTANCE;
        }
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$checkScore$2", f = "MainViewModel.kt", i = {}, l = {215}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$checkScore$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (DelayKt.delay(500L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            MainViewModel.this.generateNextBall();
            return Unit.INSTANCE;
        }
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$generateNextBall$1", f = "MainViewModel.kt", i = {}, l = {223}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$generateNextBall$1, reason: invalid class name and case insensitive filesystem */
    static final class C03851 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C03851(Continuation<? super C03851> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03851(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03851) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (DelayKt.delay(100L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            MainViewModel.this._ballState.setValue(BallState.Idle.INSTANCE);
            MainViewModel.this._isGoldenBall.setValue(Boxing.boxBoolean(RangesKt.random(new IntRange(1, 5), Random.INSTANCE) == 1));
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void generateNextBall() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03851(null), 3, null);
    }

    private final void startTimer() {
        Timer timer = this.gameTimer;
        if (timer != null) {
            timer.cancel();
        }
        Timer timer2 = new Timer();
        this.gameTimer = timer2;
        timer2.schedule(new TimerTask() { // from class: com.nextfoot.viewmodel.MainViewModel.startTimer.1
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(MainViewModel.this), null, null, new MainViewModel$startTimer$1$run$1(MainViewModel.this, null), 3, null);
            }
        }, 1000L, 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void endGame() {
        Timer timer = this.gameTimer;
        if (timer != null) {
            timer.cancel();
        }
        this._gameOver.setValue(true);
        this._gameStarted.setValue(false);
        this._ballState.setValue(BallState.Idle.INSTANCE);
    }

    public final void resetGame() {
        Timer timer = this.gameTimer;
        if (timer != null) {
            timer.cancel();
        }
        this._gameStarted.setValue(false);
        this._gameOver.setValue(false);
        this._gameScore.setValue(0);
        this._gameTime.setValue(45);
        this._ballState.setValue(BallState.Idle.INSTANCE);
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$updateProfile$1", f = "MainViewModel.kt", i = {0, 0}, l = {277}, m = "invokeSuspend", n = {"finalPictureUri", "updatedProfile"}, s = {"L$0", "L$1"}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$updateProfile$1, reason: invalid class name and case insensitive filesystem */
    static final class C03921 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Context $context;
        final /* synthetic */ ProfileModel $profileModel;
        Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ MainViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C03921(ProfileModel profileModel, MainViewModel mainViewModel, Context context, Continuation<? super C03921> continuation) {
            super(2, continuation);
            this.$profileModel = profileModel;
            this.this$0 = mainViewModel;
            this.$context = context;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C03921(this.$profileModel, this.this$0, this.$context, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03921) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            try {
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    String profilePictureUri = this.$profileModel.getProfilePictureUri();
                    if (this.$profileModel.getProfilePictureUri().length() > 0 && StringsKt.startsWith$default(this.$profileModel.getProfilePictureUri(), "content://", false, 2, (Object) null)) {
                        MainViewModel mainViewModel = this.this$0;
                        mainViewModel.deleteProfilePicture(mainViewModel.getProfile().getValue().getProfilePictureUri());
                        profilePictureUri = this.this$0.copyUriToInternalStorage(this.$context, Uri.parse(this.$profileModel.getProfilePictureUri()));
                        if (profilePictureUri == null) {
                            profilePictureUri = "";
                        }
                    }
                    String str = profilePictureUri;
                    ProfileModel profileModelCopy$default = ProfileModel.copy$default(this.$profileModel, null, null, null, str, 7, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(str);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(profileModelCopy$default);
                    this.label = 1;
                    if (this.this$0.profileDao.insertProfileEntity(profileModelCopy$default.createProfileEntity(), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return Unit.INSTANCE;
        }
    }

    public final void updateProfile(Context context, ProfileModel profileModel) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(profileModel, "profileModel");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03921(profileModel, this, context, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String copyUriToInternalStorage(Context context, Uri uri) throws FileNotFoundException {
        try {
            InputStream inputStreamOpenInputStream = context.getContentResolver().openInputStream(uri);
            File file = new File(context.getFilesDir(), "profile_" + UUID.randomUUID() + ".jpg");
            if (inputStreamOpenInputStream != null) {
                FileOutputStream fileOutputStream = inputStreamOpenInputStream;
                try {
                    InputStream inputStream = fileOutputStream;
                    fileOutputStream = new FileOutputStream(file);
                    try {
                        long jCopyTo$default = ByteStreamsKt.copyTo$default(inputStream, fileOutputStream, 0, 2, null);
                        CloseableKt.closeFinally(fileOutputStream, null);
                        Long.valueOf(jCopyTo$default);
                        CloseableKt.closeFinally(fileOutputStream, null);
                    } finally {
                    }
                } finally {
                }
            }
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void deleteProfilePicture(String internalPath) {
        String str = internalPath;
        if (str == null || str.length() == 0) {
            return;
        }
        try {
            File file = new File(internalPath);
            if (file.exists()) {
                file.delete();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* compiled from: MainViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.viewmodel.MainViewModel$deleteProfile$1", f = "MainViewModel.kt", i = {}, l = {319, 320}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.nextfoot.viewmodel.MainViewModel$deleteProfile$1, reason: invalid class name and case insensitive filesystem */
    static final class C03841 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C03841(Continuation<? super C03841> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainViewModel.this.new C03841(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03841) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:19:0x0057, code lost:
        
            if (r4.this$0.favoriteDao.clearTable(r4) == r0) goto L20;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                MainViewModel mainViewModel = MainViewModel.this;
                mainViewModel.deleteProfilePicture(mainViewModel.getProfile().getValue().getProfilePictureUri());
                this.label = 1;
                if (MainViewModel.this.profileDao.clearTable(this) == coroutine_suspended) {
                }
                return coroutine_suspended;
            }
            if (i != 1) {
                if (i != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                MainViewModel.this._profileCleared.setValue(Boxing.boxBoolean(true));
                return Unit.INSTANCE;
            }
            ResultKt.throwOnFailure(obj);
            this.label = 2;
        }
    }

    public final void deleteProfile() {
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03841(null), 3, null);
    }
}
