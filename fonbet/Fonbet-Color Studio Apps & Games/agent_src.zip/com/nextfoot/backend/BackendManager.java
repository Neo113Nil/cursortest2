package com.nextfoot.backend;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.compose.ui.text.intl.Locale;
import com.nextfoot.response.ScheduleKeyResponse;
import com.nextfoot.response.ScheduleResponse;
import com.nextfoot.response.TextResponse;
import io.github.jan.supabase.SupabaseClient;
import io.github.jan.supabase.SupabaseClientBuilder;
import io.github.jan.supabase.postgrest.Postgrest;
import io.github.jan.supabase.postgrest.PostgrestKt;
import io.github.jan.supabase.postgrest.UtilsKt;
import io.github.jan.supabase.postgrest.executor.RestRequestExecutor;
import io.github.jan.supabase.postgrest.query.Columns;
import io.github.jan.supabase.postgrest.query.PostgrestQueryBuilder;
import io.github.jan.supabase.postgrest.query.request.SelectRequestBuilder;
import io.github.jan.supabase.postgrest.request.SelectRequest;
import io.github.jan.supabase.postgrest.result.PostgrestResult;
import io.ktor.client.HttpClient;
import io.ktor.client.HttpClientConfig;
import io.ktor.client.HttpClientKt;
import io.ktor.client.call.HttpClientCall;
import io.ktor.client.engine.android.Android;
import io.ktor.client.plugins.contentnegotiation.ContentNegotiationConfig;
import io.ktor.client.plugins.contentnegotiation.ContentNegotiationKt;
import io.ktor.client.request.HttpRequestBuilder;
import io.ktor.client.request.HttpRequestKt;
import io.ktor.client.statement.HttpResponse;
import io.ktor.client.statement.HttpStatement;
import io.ktor.http.ContentType;
import io.ktor.http.HttpMethod;
import io.ktor.serialization.kotlinx.json.JsonSupportKt;
import io.ktor.util.reflect.TypeInfo;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeProjection;

/* compiled from: BackendManager.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 \u00152\u00020\u0001:\u0001\u0015B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u000f\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u0011\u001a\u00020\nH\u0086@¢\u0006\u0002\u0010\u0012J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\nH\u0086@¢\u0006\u0002\u0010\u0014R\u0016\u0010\u0006\u001a\n \b*\u0004\u0018\u00010\u00070\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/nextfoot/backend/BackendManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "backendStorage", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "scheduleKey", "", "backend", "Lio/github/jan/supabase/SupabaseClient;", "httpClient", "Lio/ktor/client/HttpClient;", "fetchScheduleList", "Lcom/nextfoot/response/ScheduleResponse;", "date", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "fetchText", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class BackendManager {
    public static final String BACKEND_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhzZnV6aWRlYXJmYXNyb2VmdW10Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk3MjQ0MDIsImV4cCI6MjA3NTMwMDQwMn0.ZWXDHwp7q7fiAHz51QhHlZ-EgjaBfCerVIQCX67Ru9k";
    public static final String BACKEND_LINK = "https://xsfuzidearfasroefumt.supabase.co";
    public static final String SCHEDULE_TABLE = "PS283";
    public static final String TEXT_TABLE = "PS283-text_feature";
    private final SupabaseClient backend;
    private final SharedPreferences backendStorage;
    private final HttpClient httpClient;
    private String scheduleKey;
    public static final int $stable = 8;

    /* compiled from: BackendManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.backend.BackendManager", f = "BackendManager.kt", i = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2}, l = {98, 123, 124}, m = "fetchScheduleList", n = {"date", "$this$iv", "$v$c$io-github-jan-supabase-postgrest-query-Columns$-columns$0$iv", "selectRequest$iv", "requestBuilder$iv", "$i$f$select-Ao2T0zE", "date", "$this$get$iv", "urlString$iv", "$this$get$iv$iv", "$this$get$iv$iv$iv", "builder$iv$iv$iv", "$this$request$iv$iv$iv$iv", "builder$iv$iv$iv$iv", "$i$f$get", "$i$f$get", "$i$f$get", "$i$f$request", "date", "$this$body$iv", "$i$f$body"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "I$0", "I$1", "I$2", "I$3", "L$0", "L$1", "I$0"}, v = 1)
    /* renamed from: com.nextfoot.backend.BackendManager$fetchScheduleList$1, reason: invalid class name */
    static final class AnonymousClass1 extends ContinuationImpl {
        int I$0;
        int I$1;
        int I$2;
        int I$3;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        Object L$7;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return BackendManager.this.fetchScheduleList(null, this);
        }
    }

    /* compiled from: BackendManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.nextfoot.backend.BackendManager", f = "BackendManager.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0}, l = {98}, m = "fetchText", n = {"language", "$this$fetchText_u24lambda_u240", "$this$iv", "$completion$iv", "$v$c$io-github-jan-supabase-postgrest-query-Columns$-columns$0$iv", "selectRequest$iv", "requestBuilder$iv", "$i$a$-run-BackendManager$fetchText$2", "$i$f$select-Ao2T0zE"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "I$0", "I$1"}, v = 1)
    /* renamed from: com.nextfoot.backend.BackendManager$fetchText$1, reason: invalid class name and case insensitive filesystem */
    static final class C03831 extends ContinuationImpl {
        int I$0;
        int I$1;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        Object L$6;
        int label;
        /* synthetic */ Object result;

        C03831(Continuation<? super C03831> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return BackendManager.this.fetchText(this);
        }
    }

    public BackendManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("backendStorage", 0);
        this.backendStorage = sharedPreferences;
        this.scheduleKey = String.valueOf(sharedPreferences.getString("scheduleKey", ""));
        SupabaseClientBuilder supabaseClientBuilder = new SupabaseClientBuilder(BACKEND_LINK, BACKEND_KEY);
        SupabaseClientBuilder.install$default(supabaseClientBuilder, Postgrest.INSTANCE, null, 2, null);
        this.backend = supabaseClientBuilder.build();
        this.httpClient = HttpClientKt.HttpClient(Android.INSTANCE, new Function1() { // from class: com.nextfoot.backend.BackendManager$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BackendManager.httpClient$lambda$0((HttpClientConfig) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit httpClient$lambda$0(HttpClientConfig HttpClient) {
        Intrinsics.checkNotNullParameter(HttpClient, "$this$HttpClient");
        HttpClient.install(ContentNegotiationKt.getContentNegotiation(), new Function1() { // from class: com.nextfoot.backend.BackendManager$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BackendManager.httpClient$lambda$0$0((ContentNegotiationConfig) obj);
            }
        });
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit httpClient$lambda$0$0(ContentNegotiationConfig install) {
        Intrinsics.checkNotNullParameter(install, "$this$install");
        JsonSupportKt.json$default(install, null, null, 3, null);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:58:0x024f, code lost:
    
        if (r1 != r3) goto L60;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:48:0x019c  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x019e A[Catch: Exception -> 0x0255, TryCatch #1 {Exception -> 0x0255, blocks: (B:14:0x003c, B:60:0x0252, B:19:0x0071, B:53:0x0215, B:57:0x0229, B:22:0x0090, B:31:0x012a, B:32:0x0156, B:34:0x015c, B:38:0x016d, B:40:0x0171, B:42:0x0177, B:44:0x018d, B:46:0x0192, B:49:0x019e, B:25:0x0099, B:27:0x00a3), top: B:66:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object fetchScheduleList(String str, Continuation<? super ScheduleResponse> continuation) {
        AnonymousClass1 anonymousClass1;
        String str2;
        BackendManager backendManager;
        String str3;
        Object next;
        String key;
        KType kTypeNullableTypeOf;
        if (continuation instanceof AnonymousClass1) {
            anonymousClass1 = (AnonymousClass1) continuation;
            if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                anonymousClass1.label -= Integer.MIN_VALUE;
            } else {
                anonymousClass1 = new AnonymousClass1(continuation);
            }
        }
        Object objExecute = anonymousClass1.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = anonymousClass1.label;
        try {
            if (i == 0) {
                ResultKt.throwOnFailure(objExecute);
                if (this.scheduleKey.length() == 0) {
                    PostgrestQueryBuilder postgrestQueryBuilderFrom = PostgrestKt.from(this.backend, SCHEDULE_TABLE);
                    String strM8670getALLU9NzzuM = Columns.INSTANCE.m8670getALLU9NzzuM();
                    SelectRequestBuilder selectRequestBuilder = new SelectRequestBuilder(((Postgrest.Config) postgrestQueryBuilderFrom.getPostgrest().getConfig()).getPropertyConversionMethod());
                    selectRequestBuilder.getParams().put("select", CollectionsKt.listOf(strM8670getALLU9NzzuM));
                    SelectRequest selectRequest = new SelectRequest(selectRequestBuilder.getHead(), selectRequestBuilder.getCount(), UtilsKt.mapToFirstValue(selectRequestBuilder.getParams()), postgrestQueryBuilderFrom.getSchema(), selectRequestBuilder.getHeaders().build());
                    str2 = str;
                    anonymousClass1.L$0 = str2;
                    anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable(postgrestQueryBuilderFrom);
                    anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(strM8670getALLU9NzzuM);
                    anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable(selectRequest);
                    anonymousClass1.L$4 = SpillingKt.nullOutSpilledVariable(selectRequestBuilder);
                    anonymousClass1.L$5 = this;
                    anonymousClass1.I$0 = 0;
                    anonymousClass1.label = 1;
                    objExecute = RestRequestExecutor.INSTANCE.execute(postgrestQueryBuilderFrom.getPostgrest(), postgrestQueryBuilderFrom.getTable(), selectRequest, anonymousClass1);
                    if (objExecute == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    backendManager = this;
                } else {
                    str2 = str;
                    if (this.scheduleKey.length() != 0) {
                        return null;
                    }
                    HttpClient httpClient = this.httpClient;
                    String str4 = "https://v3.football.api-sports.io/fixtures?date=" + str2;
                    HttpRequestBuilder httpRequestBuilder = new HttpRequestBuilder();
                    HttpRequestKt.url(httpRequestBuilder, str4);
                    io.ktor.client.request.UtilsKt.header(httpRequestBuilder, "x-rapidapi-key", this.scheduleKey);
                    httpRequestBuilder.setMethod(HttpMethod.INSTANCE.getGet());
                    HttpStatement httpStatement = new HttpStatement(httpRequestBuilder, httpClient);
                    anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(str2);
                    anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable(httpClient);
                    anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(str4);
                    anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable(httpClient);
                    anonymousClass1.L$4 = SpillingKt.nullOutSpilledVariable(httpClient);
                    anonymousClass1.L$5 = SpillingKt.nullOutSpilledVariable(httpRequestBuilder);
                    anonymousClass1.L$6 = SpillingKt.nullOutSpilledVariable(httpClient);
                    anonymousClass1.L$7 = SpillingKt.nullOutSpilledVariable(httpRequestBuilder);
                    anonymousClass1.I$0 = 0;
                    anonymousClass1.I$1 = 0;
                    anonymousClass1.I$2 = 0;
                    anonymousClass1.I$3 = 0;
                    anonymousClass1.label = 2;
                    objExecute = httpStatement.execute(anonymousClass1);
                    if (objExecute == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    str3 = str2;
                    HttpResponse httpResponse = (HttpResponse) objExecute;
                    HttpClientCall call = httpResponse.getCall();
                    KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ScheduleResponse.class);
                    kTypeNullableTypeOf = Reflection.nullableTypeOf(ScheduleResponse.class);
                    TypeInfo typeInfo = new TypeInfo(orCreateKotlinClass, kTypeNullableTypeOf);
                    anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(str3);
                    anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable(httpResponse);
                    anonymousClass1.L$2 = null;
                    anonymousClass1.L$3 = null;
                    anonymousClass1.L$4 = null;
                    anonymousClass1.L$5 = null;
                    anonymousClass1.L$6 = null;
                    anonymousClass1.L$7 = null;
                    anonymousClass1.I$0 = 0;
                    anonymousClass1.label = 3;
                    objExecute = call.bodyNullable(typeInfo, anonymousClass1);
                }
            } else if (i == 1) {
                int i2 = anonymousClass1.I$0;
                backendManager = (BackendManager) anonymousClass1.L$5;
                String str5 = (String) anonymousClass1.L$0;
                ResultKt.throwOnFailure(objExecute);
                str2 = str5;
            } else {
                if (i != 2) {
                    if (i != 3) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    int i3 = anonymousClass1.I$0;
                    ResultKt.throwOnFailure(objExecute);
                    return (ScheduleResponse) objExecute;
                }
                int i4 = anonymousClass1.I$3;
                int i5 = anonymousClass1.I$2;
                int i6 = anonymousClass1.I$1;
                int i7 = anonymousClass1.I$0;
                str3 = (String) anonymousClass1.L$0;
                ResultKt.throwOnFailure(objExecute);
                HttpResponse httpResponse2 = (HttpResponse) objExecute;
                HttpClientCall call2 = httpResponse2.getCall();
                KClass orCreateKotlinClass2 = Reflection.getOrCreateKotlinClass(ScheduleResponse.class);
                try {
                    kTypeNullableTypeOf = Reflection.nullableTypeOf(ScheduleResponse.class);
                } catch (Throwable unused) {
                    kTypeNullableTypeOf = null;
                }
                TypeInfo typeInfo2 = new TypeInfo(orCreateKotlinClass2, kTypeNullableTypeOf);
                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(str3);
                anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable(httpResponse2);
                anonymousClass1.L$2 = null;
                anonymousClass1.L$3 = null;
                anonymousClass1.L$4 = null;
                anonymousClass1.L$5 = null;
                anonymousClass1.L$6 = null;
                anonymousClass1.L$7 = null;
                anonymousClass1.I$0 = 0;
                anonymousClass1.label = 3;
                objExecute = call2.bodyNullable(typeInfo2, anonymousClass1);
            }
            PostgrestResult postgrestResult = (PostgrestResult) objExecute;
            Iterator it = ((List) postgrestResult.getPostgrest().getSerializer().decode(Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(ScheduleKeyResponse.class))), postgrestResult.getData())).iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
                if (((ScheduleKeyResponse) next).getId() == 10) {
                    break;
                }
            }
            ScheduleKeyResponse scheduleKeyResponse = (ScheduleKeyResponse) next;
            if (scheduleKeyResponse != null && (key = scheduleKeyResponse.getKey()) != null) {
                SharedPreferences backendStorage = this.backendStorage;
                Intrinsics.checkNotNullExpressionValue(backendStorage, "backendStorage");
                SharedPreferences.Editor editorEdit = backendStorage.edit();
                editorEdit.putString("scheduleKey", key);
                editorEdit.apply();
            } else {
                key = "";
            }
            backendManager.scheduleKey = key;
            if (this.scheduleKey.length() != 0) {
            }
        } catch (Exception unused2) {
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0154  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object fetchText(Continuation<? super String> continuation) {
        C03831 c03831;
        String str;
        String text;
        if (continuation instanceof C03831) {
            c03831 = (C03831) continuation;
            if ((c03831.label & Integer.MIN_VALUE) != 0) {
                c03831.label -= Integer.MIN_VALUE;
            } else {
                c03831 = new C03831(continuation);
            }
        }
        Object obj = c03831.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = c03831.label;
        try {
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                String lowerCase = Locale.INSTANCE.getCurrent().getLanguage().toLowerCase(java.util.Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String string = this.backendStorage.getString(ContentType.Text.TYPE, null);
                if (string != null) {
                    return string;
                }
                BackendManager backendManager = this;
                PostgrestQueryBuilder postgrestQueryBuilderFrom = PostgrestKt.from(this.backend, TEXT_TABLE);
                String strM8670getALLU9NzzuM = Columns.INSTANCE.m8670getALLU9NzzuM();
                SelectRequestBuilder selectRequestBuilder = new SelectRequestBuilder(((Postgrest.Config) postgrestQueryBuilderFrom.getPostgrest().getConfig()).getPropertyConversionMethod());
                selectRequestBuilder.getParams().put("select", CollectionsKt.listOf(strM8670getALLU9NzzuM));
                SelectRequest selectRequest = new SelectRequest(selectRequestBuilder.getHead(), selectRequestBuilder.getCount(), UtilsKt.mapToFirstValue(selectRequestBuilder.getParams()), postgrestQueryBuilderFrom.getSchema(), selectRequestBuilder.getHeaders().build());
                c03831.L$0 = lowerCase;
                c03831.L$1 = SpillingKt.nullOutSpilledVariable(this);
                c03831.L$2 = SpillingKt.nullOutSpilledVariable(postgrestQueryBuilderFrom);
                c03831.L$3 = SpillingKt.nullOutSpilledVariable(c03831);
                c03831.L$4 = SpillingKt.nullOutSpilledVariable(strM8670getALLU9NzzuM);
                c03831.L$5 = SpillingKt.nullOutSpilledVariable(selectRequest);
                c03831.L$6 = SpillingKt.nullOutSpilledVariable(selectRequestBuilder);
                c03831.I$0 = 0;
                c03831.I$1 = 0;
                c03831.label = 1;
                Object objExecute = RestRequestExecutor.INSTANCE.execute(postgrestQueryBuilderFrom.getPostgrest(), postgrestQueryBuilderFrom.getTable(), selectRequest, c03831);
                if (objExecute == coroutine_suspended) {
                    return coroutine_suspended;
                }
                str = lowerCase;
                obj = objExecute;
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                int i2 = c03831.I$1;
                int i3 = c03831.I$0;
                str = (String) c03831.L$0;
                ResultKt.throwOnFailure(obj);
            }
            PostgrestResult postgrestResult = (PostgrestResult) obj;
            TextResponse textResponse = (TextResponse) CollectionsKt.firstOrNull((List) postgrestResult.getPostgrest().getSerializer().decode(Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(TextResponse.class))), postgrestResult.getData()));
            if (Intrinsics.areEqual(str, "ru")) {
                text = textResponse != null ? textResponse.getTextRu() : null;
            } else if (textResponse != null) {
                text = textResponse.getText();
            }
            if (text == null) {
                return null;
            }
            SharedPreferences backendStorage = this.backendStorage;
            Intrinsics.checkNotNullExpressionValue(backendStorage, "backendStorage");
            SharedPreferences.Editor editorEdit = backendStorage.edit();
            editorEdit.putString(ContentType.Text.TYPE, text);
            editorEdit.apply();
            return text;
        } catch (Exception unused) {
            return null;
        }
    }
}
