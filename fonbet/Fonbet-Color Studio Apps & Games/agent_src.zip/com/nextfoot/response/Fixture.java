package com.nextfoot.response;

import androidx.core.app.NotificationCompat;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;
import kotlinx.serialization.internal.StringSerializer;

/* compiled from: Fixture.kt */
@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0019\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 ;2\u00020\u0001:\u0002:;BS\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f¢\u0006\u0004\b\u0010\u0010\u0011Bg\b\u0010\u0012\u0006\u0010\u0012\u001a\u00020\u0005\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u0012\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014¢\u0006\u0004\b\u0010\u0010\u0015J\u000b\u0010$\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\u000b\u0010&\u001a\u0004\u0018\u00010\u0007HÆ\u0003J\u000b\u0010'\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010(\u001a\u0004\u0018\u00010\nHÆ\u0003J\t\u0010)\u001a\u00020\fHÆ\u0003J\u000b\u0010*\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010+\u001a\u0004\u0018\u00010\u000fHÆ\u0003Je\u0010,\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2\b\b\u0002\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fHÆ\u0001J\u0013\u0010-\u001a\u00020.2\b\u0010/\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00100\u001a\u00020\u0005HÖ\u0001J\t\u00101\u001a\u00020\u0003HÖ\u0001J%\u00102\u001a\u0002032\u0006\u00104\u001a\u00020\u00002\u0006\u00105\u001a\u0002062\u0006\u00107\u001a\u000208H\u0001¢\u0006\u0002\b9R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0013\u0010\b\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0017R\u0013\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0013\u0010\r\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0017R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u000f¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#¨\u0006<"}, d2 = {"Lcom/nextfoot/response/Fixture;", "", "date", "", "id", "", "periods", "Lcom/nextfoot/response/Periods;", "referee", NotificationCompat.CATEGORY_STATUS, "Lcom/nextfoot/response/Status;", "timestamp", "", "timezone", "venue", "Lcom/nextfoot/response/Venue;", "<init>", "(Ljava/lang/String;ILcom/nextfoot/response/Periods;Ljava/lang/String;Lcom/nextfoot/response/Status;JLjava/lang/String;Lcom/nextfoot/response/Venue;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;ILcom/nextfoot/response/Periods;Ljava/lang/String;Lcom/nextfoot/response/Status;JLjava/lang/String;Lcom/nextfoot/response/Venue;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getDate", "()Ljava/lang/String;", "getId", "()I", "getPeriods", "()Lcom/nextfoot/response/Periods;", "getReferee", "getStatus", "()Lcom/nextfoot/response/Status;", "getTimestamp", "()J", "getTimezone", "getVenue", "()Lcom/nextfoot/response/Venue;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Serializable
/* loaded from: classes2.dex */
public final /* data */ class Fixture {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final String date;
    private final int id;
    private final Periods periods;
    private final String referee;
    private final Status status;
    private final long timestamp;
    private final String timezone;
    private final Venue venue;

    public static /* synthetic */ Fixture copy$default(Fixture fixture, String str, int i, Periods periods, String str2, Status status, long j, String str3, Venue venue, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = fixture.date;
        }
        if ((i2 & 2) != 0) {
            i = fixture.id;
        }
        if ((i2 & 4) != 0) {
            periods = fixture.periods;
        }
        if ((i2 & 8) != 0) {
            str2 = fixture.referee;
        }
        if ((i2 & 16) != 0) {
            status = fixture.status;
        }
        if ((i2 & 32) != 0) {
            j = fixture.timestamp;
        }
        if ((i2 & 64) != 0) {
            str3 = fixture.timezone;
        }
        if ((i2 & 128) != 0) {
            venue = fixture.venue;
        }
        long j2 = j;
        String str4 = str2;
        Status status2 = status;
        Periods periods2 = periods;
        return fixture.copy(str, i, periods2, str4, status2, j2, str3, venue);
    }

    /* renamed from: component1, reason: from getter */
    public final String getDate() {
        return this.date;
    }

    /* renamed from: component2, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component3, reason: from getter */
    public final Periods getPeriods() {
        return this.periods;
    }

    /* renamed from: component4, reason: from getter */
    public final String getReferee() {
        return this.referee;
    }

    /* renamed from: component5, reason: from getter */
    public final Status getStatus() {
        return this.status;
    }

    /* renamed from: component6, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    /* renamed from: component7, reason: from getter */
    public final String getTimezone() {
        return this.timezone;
    }

    /* renamed from: component8, reason: from getter */
    public final Venue getVenue() {
        return this.venue;
    }

    public final Fixture copy(String date, int id, Periods periods, String referee, Status status, long timestamp, String timezone, Venue venue) {
        return new Fixture(date, id, periods, referee, status, timestamp, timezone, venue);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Fixture)) {
            return false;
        }
        Fixture fixture = (Fixture) other;
        return Intrinsics.areEqual(this.date, fixture.date) && this.id == fixture.id && Intrinsics.areEqual(this.periods, fixture.periods) && Intrinsics.areEqual(this.referee, fixture.referee) && Intrinsics.areEqual(this.status, fixture.status) && this.timestamp == fixture.timestamp && Intrinsics.areEqual(this.timezone, fixture.timezone) && Intrinsics.areEqual(this.venue, fixture.venue);
    }

    public int hashCode() {
        String str = this.date;
        int iHashCode = (((str == null ? 0 : str.hashCode()) * 31) + Integer.hashCode(this.id)) * 31;
        Periods periods = this.periods;
        int iHashCode2 = (iHashCode + (periods == null ? 0 : periods.hashCode())) * 31;
        String str2 = this.referee;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Status status = this.status;
        int iHashCode4 = (((iHashCode3 + (status == null ? 0 : status.hashCode())) * 31) + Long.hashCode(this.timestamp)) * 31;
        String str3 = this.timezone;
        int iHashCode5 = (iHashCode4 + (str3 == null ? 0 : str3.hashCode())) * 31;
        Venue venue = this.venue;
        return iHashCode5 + (venue != null ? venue.hashCode() : 0);
    }

    public String toString() {
        return "Fixture(date=" + this.date + ", id=" + this.id + ", periods=" + this.periods + ", referee=" + this.referee + ", status=" + this.status + ", timestamp=" + this.timestamp + ", timezone=" + this.timezone + ", venue=" + this.venue + ")";
    }

    /* compiled from: Fixture.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/nextfoot/response/Fixture$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/nextfoot/response/Fixture;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<Fixture> serializer() {
            return Fixture$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ Fixture(int i, String str, int i2, Periods periods, String str2, Status status, long j, String str3, Venue venue, SerializationConstructorMarker serializationConstructorMarker) {
        if (255 != (i & 255)) {
            PluginExceptionsKt.throwMissingFieldException(i, 255, Fixture$$serializer.INSTANCE.getDescriptor());
        }
        this.date = str;
        this.id = i2;
        this.periods = periods;
        this.referee = str2;
        this.status = status;
        this.timestamp = j;
        this.timezone = str3;
        this.venue = venue;
    }

    public Fixture(String str, int i, Periods periods, String str2, Status status, long j, String str3, Venue venue) {
        this.date = str;
        this.id = i;
        this.periods = periods;
        this.referee = str2;
        this.status = status;
        this.timestamp = j;
        this.timezone = str3;
        this.venue = venue;
    }

    @JvmStatic
    public static final /* synthetic */ void write$Self$app_release(Fixture self, CompositeEncoder output, SerialDescriptor serialDesc) {
        output.encodeNullableSerializableElement(serialDesc, 0, StringSerializer.INSTANCE, self.date);
        output.encodeIntElement(serialDesc, 1, self.id);
        output.encodeNullableSerializableElement(serialDesc, 2, Periods$$serializer.INSTANCE, self.periods);
        output.encodeNullableSerializableElement(serialDesc, 3, StringSerializer.INSTANCE, self.referee);
        output.encodeNullableSerializableElement(serialDesc, 4, Status$$serializer.INSTANCE, self.status);
        output.encodeLongElement(serialDesc, 5, self.timestamp);
        output.encodeNullableSerializableElement(serialDesc, 6, StringSerializer.INSTANCE, self.timezone);
        output.encodeNullableSerializableElement(serialDesc, 7, Venue$$serializer.INSTANCE, self.venue);
    }

    public final String getDate() {
        return this.date;
    }

    public final int getId() {
        return this.id;
    }

    public final Periods getPeriods() {
        return this.periods;
    }

    public final String getReferee() {
        return this.referee;
    }

    public final Status getStatus() {
        return this.status;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final String getTimezone() {
        return this.timezone;
    }

    public final Venue getVenue() {
        return this.venue;
    }
}
