package com.nextfoot.response;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;

/* compiled from: Score.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 '2\u00020\u0001:\u0002&'B/\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0007\u0010\bBC\b\u0010\u0012\u0006\u0010\t\u001a\u00020\n\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\u0007\u0010\rJ\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0016\u001a\u0004\u0018\u00010\u0003HÆ\u0003J9\u0010\u0017\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\nHÖ\u0001J\t\u0010\u001c\u001a\u00020\u001dHÖ\u0001J%\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00002\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$H\u0001¢\u0006\u0002\b%R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000fR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000f¨\u0006("}, d2 = {"Lcom/nextfoot/response/Score;", "", "extratime", "Lcom/nextfoot/response/GoalsTeams;", "fulltime", "halftime", "penalty", "<init>", "(Lcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;)V", "seen0", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;Lcom/nextfoot/response/GoalsTeams;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getExtratime", "()Lcom/nextfoot/response/GoalsTeams;", "getFulltime", "getHalftime", "getPenalty", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Serializable
/* loaded from: classes2.dex */
public final /* data */ class Score {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final GoalsTeams extratime;
    private final GoalsTeams fulltime;
    private final GoalsTeams halftime;
    private final GoalsTeams penalty;

    public static /* synthetic */ Score copy$default(Score score, GoalsTeams goalsTeams, GoalsTeams goalsTeams2, GoalsTeams goalsTeams3, GoalsTeams goalsTeams4, int i, Object obj) {
        if ((i & 1) != 0) {
            goalsTeams = score.extratime;
        }
        if ((i & 2) != 0) {
            goalsTeams2 = score.fulltime;
        }
        if ((i & 4) != 0) {
            goalsTeams3 = score.halftime;
        }
        if ((i & 8) != 0) {
            goalsTeams4 = score.penalty;
        }
        return score.copy(goalsTeams, goalsTeams2, goalsTeams3, goalsTeams4);
    }

    /* renamed from: component1, reason: from getter */
    public final GoalsTeams getExtratime() {
        return this.extratime;
    }

    /* renamed from: component2, reason: from getter */
    public final GoalsTeams getFulltime() {
        return this.fulltime;
    }

    /* renamed from: component3, reason: from getter */
    public final GoalsTeams getHalftime() {
        return this.halftime;
    }

    /* renamed from: component4, reason: from getter */
    public final GoalsTeams getPenalty() {
        return this.penalty;
    }

    public final Score copy(GoalsTeams extratime, GoalsTeams fulltime, GoalsTeams halftime, GoalsTeams penalty) {
        return new Score(extratime, fulltime, halftime, penalty);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Score)) {
            return false;
        }
        Score score = (Score) other;
        return Intrinsics.areEqual(this.extratime, score.extratime) && Intrinsics.areEqual(this.fulltime, score.fulltime) && Intrinsics.areEqual(this.halftime, score.halftime) && Intrinsics.areEqual(this.penalty, score.penalty);
    }

    public int hashCode() {
        GoalsTeams goalsTeams = this.extratime;
        int iHashCode = (goalsTeams == null ? 0 : goalsTeams.hashCode()) * 31;
        GoalsTeams goalsTeams2 = this.fulltime;
        int iHashCode2 = (iHashCode + (goalsTeams2 == null ? 0 : goalsTeams2.hashCode())) * 31;
        GoalsTeams goalsTeams3 = this.halftime;
        int iHashCode3 = (iHashCode2 + (goalsTeams3 == null ? 0 : goalsTeams3.hashCode())) * 31;
        GoalsTeams goalsTeams4 = this.penalty;
        return iHashCode3 + (goalsTeams4 != null ? goalsTeams4.hashCode() : 0);
    }

    public String toString() {
        return "Score(extratime=" + this.extratime + ", fulltime=" + this.fulltime + ", halftime=" + this.halftime + ", penalty=" + this.penalty + ")";
    }

    /* compiled from: Score.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/nextfoot/response/Score$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/nextfoot/response/Score;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<Score> serializer() {
            return Score$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ Score(int i, GoalsTeams goalsTeams, GoalsTeams goalsTeams2, GoalsTeams goalsTeams3, GoalsTeams goalsTeams4, SerializationConstructorMarker serializationConstructorMarker) {
        if (15 != (i & 15)) {
            PluginExceptionsKt.throwMissingFieldException(i, 15, Score$$serializer.INSTANCE.getDescriptor());
        }
        this.extratime = goalsTeams;
        this.fulltime = goalsTeams2;
        this.halftime = goalsTeams3;
        this.penalty = goalsTeams4;
    }

    public Score(GoalsTeams goalsTeams, GoalsTeams goalsTeams2, GoalsTeams goalsTeams3, GoalsTeams goalsTeams4) {
        this.extratime = goalsTeams;
        this.fulltime = goalsTeams2;
        this.halftime = goalsTeams3;
        this.penalty = goalsTeams4;
    }

    @JvmStatic
    public static final /* synthetic */ void write$Self$app_release(Score self, CompositeEncoder output, SerialDescriptor serialDesc) {
        output.encodeNullableSerializableElement(serialDesc, 0, GoalsTeams$$serializer.INSTANCE, self.extratime);
        output.encodeNullableSerializableElement(serialDesc, 1, GoalsTeams$$serializer.INSTANCE, self.fulltime);
        output.encodeNullableSerializableElement(serialDesc, 2, GoalsTeams$$serializer.INSTANCE, self.halftime);
        output.encodeNullableSerializableElement(serialDesc, 3, GoalsTeams$$serializer.INSTANCE, self.penalty);
    }

    public final GoalsTeams getExtratime() {
        return this.extratime;
    }

    public final GoalsTeams getFulltime() {
        return this.fulltime;
    }

    public final GoalsTeams getHalftime() {
        return this.halftime;
    }

    public final GoalsTeams getPenalty() {
        return this.penalty;
    }
}
