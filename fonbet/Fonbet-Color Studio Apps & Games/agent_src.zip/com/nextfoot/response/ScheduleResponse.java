package com.nextfoot.response;

import com.nextfoot.model.EventModel;
import java.util.ArrayList;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.ArrayListSerializer;
import kotlinx.serialization.internal.IntSerializer;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;
import kotlinx.serialization.json.JsonElement;
import kotlinx.serialization.json.JsonElementSerializer;

/* compiled from: ScheduleResponse.kt */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 :2\u00020\u0001:\u00029:BE\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u000e¢\u0006\u0004\b\u000f\u0010\u0010B]\b\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u000e\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\u000e\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000b\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u000e\u0012\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013¢\u0006\u0004\b\u000f\u0010\u0014J\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020#0\u000bJ\u000b\u0010$\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\u0007HÆ\u0003J\u000b\u0010'\u001a\u0004\u0018\u00010\tHÆ\u0003J\u000f\u0010(\u001a\b\u0012\u0004\u0012\u00020\f0\u000bHÆ\u0003J\u0010\u0010)\u001a\u0004\u0018\u00010\u000eHÆ\u0003¢\u0006\u0002\u0010 JV\u0010*\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000eHÆ\u0001¢\u0006\u0002\u0010+J\u0013\u0010,\u001a\u00020-2\b\u0010.\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010/\u001a\u00020\u000eHÖ\u0001J\t\u00100\u001a\u00020\u0005HÖ\u0001J%\u00101\u001a\u0002022\u0006\u00103\u001a\u00020\u00002\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u000207H\u0001¢\u0006\u0002\b8R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0013\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0015\u0010\r\u001a\u0004\u0018\u00010\u000e¢\u0006\n\n\u0002\u0010!\u001a\u0004\b\u001f\u0010 ¨\u0006;"}, d2 = {"Lcom/nextfoot/response/ScheduleResponse;", "", "errors", "Lkotlinx/serialization/json/JsonElement;", "get", "", "paging", "Lcom/nextfoot/response/Paging;", "parameters", "Lcom/nextfoot/response/Parameters;", "response", "", "Lcom/nextfoot/response/Response;", "results", "", "<init>", "(Lkotlinx/serialization/json/JsonElement;Ljava/lang/String;Lcom/nextfoot/response/Paging;Lcom/nextfoot/response/Parameters;Ljava/util/List;Ljava/lang/Integer;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILkotlinx/serialization/json/JsonElement;Ljava/lang/String;Lcom/nextfoot/response/Paging;Lcom/nextfoot/response/Parameters;Ljava/util/List;Ljava/lang/Integer;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getErrors", "()Lkotlinx/serialization/json/JsonElement;", "getGet", "()Ljava/lang/String;", "getPaging", "()Lcom/nextfoot/response/Paging;", "getParameters", "()Lcom/nextfoot/response/Parameters;", "getResponse", "()Ljava/util/List;", "getResults", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "createEventsList", "Lcom/nextfoot/model/EventModel;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "(Lkotlinx/serialization/json/JsonElement;Ljava/lang/String;Lcom/nextfoot/response/Paging;Lcom/nextfoot/response/Parameters;Ljava/util/List;Ljava/lang/Integer;)Lcom/nextfoot/response/ScheduleResponse;", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Serializable
/* loaded from: classes2.dex */
public final /* data */ class ScheduleResponse {
    private final JsonElement errors;
    private final String get;
    private final Paging paging;
    private final Parameters parameters;
    private final List<Response> response;
    private final Integer results;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;
    private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, null, null, null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.nextfoot.response.ScheduleResponse$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            return ScheduleResponse._childSerializers$_anonymous_();
        }
    }), null};

    /* JADX INFO: Access modifiers changed from: private */
    public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
        return new ArrayListSerializer(Response$$serializer.INSTANCE);
    }

    public static /* synthetic */ ScheduleResponse copy$default(ScheduleResponse scheduleResponse, JsonElement jsonElement, String str, Paging paging, Parameters parameters, List list, Integer num, int i, Object obj) {
        if ((i & 1) != 0) {
            jsonElement = scheduleResponse.errors;
        }
        if ((i & 2) != 0) {
            str = scheduleResponse.get;
        }
        if ((i & 4) != 0) {
            paging = scheduleResponse.paging;
        }
        if ((i & 8) != 0) {
            parameters = scheduleResponse.parameters;
        }
        if ((i & 16) != 0) {
            list = scheduleResponse.response;
        }
        if ((i & 32) != 0) {
            num = scheduleResponse.results;
        }
        List list2 = list;
        Integer num2 = num;
        return scheduleResponse.copy(jsonElement, str, paging, parameters, list2, num2);
    }

    /* renamed from: component1, reason: from getter */
    public final JsonElement getErrors() {
        return this.errors;
    }

    /* renamed from: component2, reason: from getter */
    public final String getGet() {
        return this.get;
    }

    /* renamed from: component3, reason: from getter */
    public final Paging getPaging() {
        return this.paging;
    }

    /* renamed from: component4, reason: from getter */
    public final Parameters getParameters() {
        return this.parameters;
    }

    public final List<Response> component5() {
        return this.response;
    }

    /* renamed from: component6, reason: from getter */
    public final Integer getResults() {
        return this.results;
    }

    public final ScheduleResponse copy(JsonElement errors, String get, Paging paging, Parameters parameters, List<Response> response, Integer results) {
        Intrinsics.checkNotNullParameter(get, "get");
        Intrinsics.checkNotNullParameter(paging, "paging");
        Intrinsics.checkNotNullParameter(response, "response");
        return new ScheduleResponse(errors, get, paging, parameters, response, results);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ScheduleResponse)) {
            return false;
        }
        ScheduleResponse scheduleResponse = (ScheduleResponse) other;
        return Intrinsics.areEqual(this.errors, scheduleResponse.errors) && Intrinsics.areEqual(this.get, scheduleResponse.get) && Intrinsics.areEqual(this.paging, scheduleResponse.paging) && Intrinsics.areEqual(this.parameters, scheduleResponse.parameters) && Intrinsics.areEqual(this.response, scheduleResponse.response) && Intrinsics.areEqual(this.results, scheduleResponse.results);
    }

    public int hashCode() {
        JsonElement jsonElement = this.errors;
        int iHashCode = (((((jsonElement == null ? 0 : jsonElement.hashCode()) * 31) + this.get.hashCode()) * 31) + this.paging.hashCode()) * 31;
        Parameters parameters = this.parameters;
        int iHashCode2 = (((iHashCode + (parameters == null ? 0 : parameters.hashCode())) * 31) + this.response.hashCode()) * 31;
        Integer num = this.results;
        return iHashCode2 + (num != null ? num.hashCode() : 0);
    }

    public String toString() {
        return "ScheduleResponse(errors=" + this.errors + ", get=" + this.get + ", paging=" + this.paging + ", parameters=" + this.parameters + ", response=" + this.response + ", results=" + this.results + ")";
    }

    /* compiled from: ScheduleResponse.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/nextfoot/response/ScheduleResponse$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/nextfoot/response/ScheduleResponse;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<ScheduleResponse> serializer() {
            return ScheduleResponse$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ ScheduleResponse(int i, JsonElement jsonElement, String str, Paging paging, Parameters parameters, List list, Integer num, SerializationConstructorMarker serializationConstructorMarker) {
        if (62 != (i & 62)) {
            PluginExceptionsKt.throwMissingFieldException(i, 62, ScheduleResponse$$serializer.INSTANCE.getDescriptor());
        }
        if ((i & 1) == 0) {
            this.errors = null;
        } else {
            this.errors = jsonElement;
        }
        this.get = str;
        this.paging = paging;
        this.parameters = parameters;
        this.response = list;
        this.results = num;
    }

    public ScheduleResponse(JsonElement jsonElement, String get, Paging paging, Parameters parameters, List<Response> response, Integer num) {
        Intrinsics.checkNotNullParameter(get, "get");
        Intrinsics.checkNotNullParameter(paging, "paging");
        Intrinsics.checkNotNullParameter(response, "response");
        this.errors = jsonElement;
        this.get = get;
        this.paging = paging;
        this.parameters = parameters;
        this.response = response;
        this.results = num;
    }

    @JvmStatic
    public static final /* synthetic */ void write$Self$app_release(ScheduleResponse self, CompositeEncoder output, SerialDescriptor serialDesc) {
        Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
        if (output.shouldEncodeElementDefault(serialDesc, 0) || self.errors != null) {
            output.encodeNullableSerializableElement(serialDesc, 0, JsonElementSerializer.INSTANCE, self.errors);
        }
        output.encodeStringElement(serialDesc, 1, self.get);
        output.encodeSerializableElement(serialDesc, 2, Paging$$serializer.INSTANCE, self.paging);
        output.encodeNullableSerializableElement(serialDesc, 3, Parameters$$serializer.INSTANCE, self.parameters);
        output.encodeSerializableElement(serialDesc, 4, lazyArr[4].getValue(), self.response);
        output.encodeNullableSerializableElement(serialDesc, 5, IntSerializer.INSTANCE, self.results);
    }

    public /* synthetic */ ScheduleResponse(JsonElement jsonElement, String str, Paging paging, Parameters parameters, List list, Integer num, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? null : jsonElement, str, paging, parameters, list, num);
    }

    public final JsonElement getErrors() {
        return this.errors;
    }

    public final String getGet() {
        return this.get;
    }

    public final Paging getPaging() {
        return this.paging;
    }

    public final Parameters getParameters() {
        return this.parameters;
    }

    public final List<Response> getResponse() {
        return this.response;
    }

    public final Integer getResults() {
        return this.results;
    }

    public final List<EventModel> createEventsList() {
        List<Response> list = this.response;
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        for (Response response : list) {
            int id = response.getFixture().getId();
            String name = response.getTeams().getHome().getName();
            String name2 = response.getTeams().getAway().getName();
            Integer home = response.getGoals().getHome();
            int iIntValue = home != null ? home.intValue() : 0;
            Integer away = response.getGoals().getAway();
            int iIntValue2 = away != null ? away.intValue() : 0;
            long timestamp = response.getFixture().getTimestamp() * 1000;
            String referee = response.getFixture().getReferee();
            League league = response.getLeague();
            String name3 = null;
            String country = league != null ? league.getCountry() : null;
            League league2 = response.getLeague();
            String name4 = league2 != null ? league2.getName() : null;
            Venue venue = response.getFixture().getVenue();
            if (venue != null) {
                name3 = venue.getName();
            }
            arrayList.add(new EventModel(id, name, name2, iIntValue, iIntValue2, timestamp, referee, country, name4, name3));
        }
        return arrayList;
    }
}
