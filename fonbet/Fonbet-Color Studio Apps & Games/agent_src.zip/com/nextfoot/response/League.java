package com.nextfoot.response;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.BooleanSerializer;
import kotlinx.serialization.internal.IntSerializer;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;
import kotlinx.serialization.internal.StringSerializer;

/* compiled from: League.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001d\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 72\u00020\u0001:\u000267BW\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\r\u0010\u000eBk\b\u0010\u0012\u0006\u0010\u000f\u001a\u00020\u0006\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f\u0012\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011¢\u0006\u0004\b\r\u0010\u0012J\u000b\u0010 \u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010!\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010\"\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0002\u0010\u0017J\u000b\u0010#\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010&\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0002\u0010\u0017J\u0010\u0010'\u001a\u0004\u0018\u00010\fHÆ\u0003¢\u0006\u0002\u0010\u001eJn\u0010(\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\fHÆ\u0001¢\u0006\u0002\u0010)J\u0013\u0010*\u001a\u00020\f2\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0006HÖ\u0001J\t\u0010-\u001a\u00020\u0003HÖ\u0001J%\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020\u00002\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u000204H\u0001¢\u0006\u0002\b5R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0015\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\n\n\u0002\u0010\u0018\u001a\u0004\b\u0016\u0010\u0017R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0014R\u0013\u0010\b\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0014R\u0013\u0010\t\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u0015\u0010\n\u001a\u0004\u0018\u00010\u0006¢\u0006\n\n\u0002\u0010\u0018\u001a\u0004\b\u001c\u0010\u0017R\u0015\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001e¨\u00068"}, d2 = {"Lcom/nextfoot/response/League;", "", "country", "", "flag", "id", "", "logo", "name", "round", "season", "standings", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getCountry", "()Ljava/lang/String;", "getFlag", "getId", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getLogo", "getName", "getRound", "getSeason", "getStandings", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;)Lcom/nextfoot/response/League;", "equals", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Serializable
/* loaded from: classes2.dex */
public final /* data */ class League {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final String country;
    private final String flag;
    private final Integer id;
    private final String logo;
    private final String name;
    private final String round;
    private final Integer season;
    private final Boolean standings;

    public static /* synthetic */ League copy$default(League league, String str, String str2, Integer num, String str3, String str4, String str5, Integer num2, Boolean bool, int i, Object obj) {
        if ((i & 1) != 0) {
            str = league.country;
        }
        if ((i & 2) != 0) {
            str2 = league.flag;
        }
        if ((i & 4) != 0) {
            num = league.id;
        }
        if ((i & 8) != 0) {
            str3 = league.logo;
        }
        if ((i & 16) != 0) {
            str4 = league.name;
        }
        if ((i & 32) != 0) {
            str5 = league.round;
        }
        if ((i & 64) != 0) {
            num2 = league.season;
        }
        if ((i & 128) != 0) {
            bool = league.standings;
        }
        Integer num3 = num2;
        Boolean bool2 = bool;
        String str6 = str4;
        String str7 = str5;
        return league.copy(str, str2, num, str3, str6, str7, num3, bool2);
    }

    /* renamed from: component1, reason: from getter */
    public final String getCountry() {
        return this.country;
    }

    /* renamed from: component2, reason: from getter */
    public final String getFlag() {
        return this.flag;
    }

    /* renamed from: component3, reason: from getter */
    public final Integer getId() {
        return this.id;
    }

    /* renamed from: component4, reason: from getter */
    public final String getLogo() {
        return this.logo;
    }

    /* renamed from: component5, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* renamed from: component6, reason: from getter */
    public final String getRound() {
        return this.round;
    }

    /* renamed from: component7, reason: from getter */
    public final Integer getSeason() {
        return this.season;
    }

    /* renamed from: component8, reason: from getter */
    public final Boolean getStandings() {
        return this.standings;
    }

    public final League copy(String country, String flag, Integer id, String logo, String name, String round, Integer season, Boolean standings) {
        return new League(country, flag, id, logo, name, round, season, standings);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof League)) {
            return false;
        }
        League league = (League) other;
        return Intrinsics.areEqual(this.country, league.country) && Intrinsics.areEqual(this.flag, league.flag) && Intrinsics.areEqual(this.id, league.id) && Intrinsics.areEqual(this.logo, league.logo) && Intrinsics.areEqual(this.name, league.name) && Intrinsics.areEqual(this.round, league.round) && Intrinsics.areEqual(this.season, league.season) && Intrinsics.areEqual(this.standings, league.standings);
    }

    public int hashCode() {
        String str = this.country;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.flag;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        Integer num = this.id;
        int iHashCode3 = (iHashCode2 + (num == null ? 0 : num.hashCode())) * 31;
        String str3 = this.logo;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.name;
        int iHashCode5 = (iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.round;
        int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
        Integer num2 = this.season;
        int iHashCode7 = (iHashCode6 + (num2 == null ? 0 : num2.hashCode())) * 31;
        Boolean bool = this.standings;
        return iHashCode7 + (bool != null ? bool.hashCode() : 0);
    }

    public String toString() {
        return "League(country=" + this.country + ", flag=" + this.flag + ", id=" + this.id + ", logo=" + this.logo + ", name=" + this.name + ", round=" + this.round + ", season=" + this.season + ", standings=" + this.standings + ")";
    }

    /* compiled from: League.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/nextfoot/response/League$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/nextfoot/response/League;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<League> serializer() {
            return League$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ League(int i, String str, String str2, Integer num, String str3, String str4, String str5, Integer num2, Boolean bool, SerializationConstructorMarker serializationConstructorMarker) {
        if (255 != (i & 255)) {
            PluginExceptionsKt.throwMissingFieldException(i, 255, League$$serializer.INSTANCE.getDescriptor());
        }
        this.country = str;
        this.flag = str2;
        this.id = num;
        this.logo = str3;
        this.name = str4;
        this.round = str5;
        this.season = num2;
        this.standings = bool;
    }

    public League(String str, String str2, Integer num, String str3, String str4, String str5, Integer num2, Boolean bool) {
        this.country = str;
        this.flag = str2;
        this.id = num;
        this.logo = str3;
        this.name = str4;
        this.round = str5;
        this.season = num2;
        this.standings = bool;
    }

    @JvmStatic
    public static final /* synthetic */ void write$Self$app_release(League self, CompositeEncoder output, SerialDescriptor serialDesc) {
        output.encodeNullableSerializableElement(serialDesc, 0, StringSerializer.INSTANCE, self.country);
        output.encodeNullableSerializableElement(serialDesc, 1, StringSerializer.INSTANCE, self.flag);
        output.encodeNullableSerializableElement(serialDesc, 2, IntSerializer.INSTANCE, self.id);
        output.encodeNullableSerializableElement(serialDesc, 3, StringSerializer.INSTANCE, self.logo);
        output.encodeNullableSerializableElement(serialDesc, 4, StringSerializer.INSTANCE, self.name);
        output.encodeNullableSerializableElement(serialDesc, 5, StringSerializer.INSTANCE, self.round);
        output.encodeNullableSerializableElement(serialDesc, 6, IntSerializer.INSTANCE, self.season);
        output.encodeNullableSerializableElement(serialDesc, 7, BooleanSerializer.INSTANCE, self.standings);
    }

    public final String getCountry() {
        return this.country;
    }

    public final String getFlag() {
        return this.flag;
    }

    public final Integer getId() {
        return this.id;
    }

    public final String getLogo() {
        return this.logo;
    }

    public final String getName() {
        return this.name;
    }

    public final String getRound() {
        return this.round;
    }

    public final Integer getSeason() {
        return this.season;
    }

    public final Boolean getStandings() {
        return this.standings;
    }
}
