package com.nextfoot.response;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.UnknownFieldException;
import kotlinx.serialization.builtins.BuiltinSerializersKt;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeDecoder;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.encoding.Decoder;
import kotlinx.serialization.encoding.Encoder;
import kotlinx.serialization.internal.GeneratedSerializer;
import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;

/* compiled from: Score.kt */
@Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/nextfoot/response/Score.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/nextfoot/response/Score;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* loaded from: classes2.dex */
public final /* synthetic */ class Score$$serializer implements GeneratedSerializer<Score> {
    public static final int $stable;
    public static final Score$$serializer INSTANCE;
    private static final SerialDescriptor descriptor;

    @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
    public final SerialDescriptor getDescriptor() {
        return descriptor;
    }

    static {
        Score$$serializer score$$serializer = new Score$$serializer();
        INSTANCE = score$$serializer;
        $stable = 8;
        PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.nextfoot.response.Score", score$$serializer, 4);
        pluginGeneratedSerialDescriptor.addElement("extratime", false);
        pluginGeneratedSerialDescriptor.addElement("fulltime", false);
        pluginGeneratedSerialDescriptor.addElement("halftime", false);
        pluginGeneratedSerialDescriptor.addElement("penalty", false);
        descriptor = pluginGeneratedSerialDescriptor;
    }

    private Score$$serializer() {
    }

    @Override // kotlinx.serialization.internal.GeneratedSerializer
    public final KSerializer<?>[] childSerializers() {
        return new KSerializer[]{BuiltinSerializersKt.getNullable(GoalsTeams$$serializer.INSTANCE), BuiltinSerializersKt.getNullable(GoalsTeams$$serializer.INSTANCE), BuiltinSerializersKt.getNullable(GoalsTeams$$serializer.INSTANCE), BuiltinSerializersKt.getNullable(GoalsTeams$$serializer.INSTANCE)};
    }

    @Override // kotlinx.serialization.DeserializationStrategy
    public final Score deserialize(Decoder decoder) {
        int i;
        GoalsTeams goalsTeams;
        GoalsTeams goalsTeams2;
        GoalsTeams goalsTeams3;
        GoalsTeams goalsTeams4;
        Intrinsics.checkNotNullParameter(decoder, "decoder");
        SerialDescriptor serialDescriptor = descriptor;
        CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
        GoalsTeams goalsTeams5 = null;
        if (compositeDecoderBeginStructure.decodeSequentially()) {
            GoalsTeams goalsTeams6 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 0, GoalsTeams$$serializer.INSTANCE, null);
            GoalsTeams goalsTeams7 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 1, GoalsTeams$$serializer.INSTANCE, null);
            GoalsTeams goalsTeams8 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, GoalsTeams$$serializer.INSTANCE, null);
            goalsTeams = goalsTeams6;
            goalsTeams4 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, GoalsTeams$$serializer.INSTANCE, null);
            goalsTeams3 = goalsTeams8;
            goalsTeams2 = goalsTeams7;
            i = 15;
        } else {
            boolean z = true;
            int i2 = 0;
            GoalsTeams goalsTeams9 = null;
            GoalsTeams goalsTeams10 = null;
            GoalsTeams goalsTeams11 = null;
            while (z) {
                int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                if (iDecodeElementIndex == -1) {
                    z = false;
                } else if (iDecodeElementIndex == 0) {
                    goalsTeams5 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 0, GoalsTeams$$serializer.INSTANCE, goalsTeams5);
                    i2 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    goalsTeams9 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 1, GoalsTeams$$serializer.INSTANCE, goalsTeams9);
                    i2 |= 2;
                } else if (iDecodeElementIndex == 2) {
                    goalsTeams10 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, GoalsTeams$$serializer.INSTANCE, goalsTeams10);
                    i2 |= 4;
                } else {
                    if (iDecodeElementIndex != 3) {
                        throw new UnknownFieldException(iDecodeElementIndex);
                    }
                    goalsTeams11 = (GoalsTeams) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, GoalsTeams$$serializer.INSTANCE, goalsTeams11);
                    i2 |= 8;
                }
            }
            i = i2;
            goalsTeams = goalsTeams5;
            goalsTeams2 = goalsTeams9;
            goalsTeams3 = goalsTeams10;
            goalsTeams4 = goalsTeams11;
        }
        compositeDecoderBeginStructure.endStructure(serialDescriptor);
        return new Score(i, goalsTeams, goalsTeams2, goalsTeams3, goalsTeams4, null);
    }

    @Override // kotlinx.serialization.SerializationStrategy
    public final void serialize(Encoder encoder, Score value) {
        Intrinsics.checkNotNullParameter(encoder, "encoder");
        Intrinsics.checkNotNullParameter(value, "value");
        SerialDescriptor serialDescriptor = descriptor;
        CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
        Score.write$Self$app_release(value, compositeEncoderBeginStructure, serialDescriptor);
        compositeEncoderBeginStructure.endStructure(serialDescriptor);
    }

    @Override // kotlinx.serialization.internal.GeneratedSerializer
    public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
        return super.typeParametersSerializers();
    }
}
