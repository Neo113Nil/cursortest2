package com.nextfoot.response;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;

/* compiled from: Response.kt */
@Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 22\u00020\u0001:\u000212B3\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rBM\b\u0010\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011¢\u0006\u0004\b\f\u0010\u0012J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u001f\u001a\u0004\u0018\u00010\u0007HÆ\u0003J\u000b\u0010 \u001a\u0004\u0018\u00010\tHÆ\u0003J\t\u0010!\u001a\u00020\u000bHÆ\u0003J?\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t2\b\b\u0002\u0010\n\u001a\u00020\u000bHÆ\u0001J\u0013\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010&\u001a\u00020\u000fHÖ\u0001J\t\u0010'\u001a\u00020(HÖ\u0001J%\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020\u00002\u0006\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020/H\u0001¢\u0006\u0002\b0R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0013\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001c¨\u00063"}, d2 = {"Lcom/nextfoot/response/Response;", "", "fixture", "Lcom/nextfoot/response/Fixture;", "goals", "Lcom/nextfoot/response/Goals;", "league", "Lcom/nextfoot/response/League;", "score", "Lcom/nextfoot/response/Score;", "teams", "Lcom/nextfoot/response/Teams;", "<init>", "(Lcom/nextfoot/response/Fixture;Lcom/nextfoot/response/Goals;Lcom/nextfoot/response/League;Lcom/nextfoot/response/Score;Lcom/nextfoot/response/Teams;)V", "seen0", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILcom/nextfoot/response/Fixture;Lcom/nextfoot/response/Goals;Lcom/nextfoot/response/League;Lcom/nextfoot/response/Score;Lcom/nextfoot/response/Teams;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getFixture", "()Lcom/nextfoot/response/Fixture;", "getGoals", "()Lcom/nextfoot/response/Goals;", "getLeague", "()Lcom/nextfoot/response/League;", "getScore", "()Lcom/nextfoot/response/Score;", "getTeams", "()Lcom/nextfoot/response/Teams;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Serializable
/* loaded from: classes2.dex */
public final /* data */ class Response {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final Fixture fixture;
    private final Goals goals;
    private final League league;
    private final Score score;
    private final Teams teams;

    public static /* synthetic */ Response copy$default(Response response, Fixture fixture, Goals goals, League league, Score score, Teams teams, int i, Object obj) {
        if ((i & 1) != 0) {
            fixture = response.fixture;
        }
        if ((i & 2) != 0) {
            goals = response.goals;
        }
        if ((i & 4) != 0) {
            league = response.league;
        }
        if ((i & 8) != 0) {
            score = response.score;
        }
        if ((i & 16) != 0) {
            teams = response.teams;
        }
        Teams teams2 = teams;
        League league2 = league;
        return response.copy(fixture, goals, league2, score, teams2);
    }

    /* renamed from: component1, reason: from getter */
    public final Fixture getFixture() {
        return this.fixture;
    }

    /* renamed from: component2, reason: from getter */
    public final Goals getGoals() {
        return this.goals;
    }

    /* renamed from: component3, reason: from getter */
    public final League getLeague() {
        return this.league;
    }

    /* renamed from: component4, reason: from getter */
    public final Score getScore() {
        return this.score;
    }

    /* renamed from: component5, reason: from getter */
    public final Teams getTeams() {
        return this.teams;
    }

    public final Response copy(Fixture fixture, Goals goals, League league, Score score, Teams teams) {
        Intrinsics.checkNotNullParameter(fixture, "fixture");
        Intrinsics.checkNotNullParameter(goals, "goals");
        Intrinsics.checkNotNullParameter(teams, "teams");
        return new Response(fixture, goals, league, score, teams);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Response)) {
            return false;
        }
        Response response = (Response) other;
        return Intrinsics.areEqual(this.fixture, response.fixture) && Intrinsics.areEqual(this.goals, response.goals) && Intrinsics.areEqual(this.league, response.league) && Intrinsics.areEqual(this.score, response.score) && Intrinsics.areEqual(this.teams, response.teams);
    }

    public int hashCode() {
        int iHashCode = ((this.fixture.hashCode() * 31) + this.goals.hashCode()) * 31;
        League league = this.league;
        int iHashCode2 = (iHashCode + (league == null ? 0 : league.hashCode())) * 31;
        Score score = this.score;
        return ((iHashCode2 + (score != null ? score.hashCode() : 0)) * 31) + this.teams.hashCode();
    }

    public String toString() {
        return "Response(fixture=" + this.fixture + ", goals=" + this.goals + ", league=" + this.league + ", score=" + this.score + ", teams=" + this.teams + ")";
    }

    /* compiled from: Response.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/nextfoot/response/Response$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/nextfoot/response/Response;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<Response> serializer() {
            return Response$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ Response(int i, Fixture fixture, Goals goals, League league, Score score, Teams teams, SerializationConstructorMarker serializationConstructorMarker) {
        if (31 != (i & 31)) {
            PluginExceptionsKt.throwMissingFieldException(i, 31, Response$$serializer.INSTANCE.getDescriptor());
        }
        this.fixture = fixture;
        this.goals = goals;
        this.league = league;
        this.score = score;
        this.teams = teams;
    }

    public Response(Fixture fixture, Goals goals, League league, Score score, Teams teams) {
        Intrinsics.checkNotNullParameter(fixture, "fixture");
        Intrinsics.checkNotNullParameter(goals, "goals");
        Intrinsics.checkNotNullParameter(teams, "teams");
        this.fixture = fixture;
        this.goals = goals;
        this.league = league;
        this.score = score;
        this.teams = teams;
    }

    @JvmStatic
    public static final /* synthetic */ void write$Self$app_release(Response self, CompositeEncoder output, SerialDescriptor serialDesc) {
        output.encodeSerializableElement(serialDesc, 0, Fixture$$serializer.INSTANCE, self.fixture);
        output.encodeSerializableElement(serialDesc, 1, Goals$$serializer.INSTANCE, self.goals);
        output.encodeNullableSerializableElement(serialDesc, 2, League$$serializer.INSTANCE, self.league);
        output.encodeNullableSerializableElement(serialDesc, 3, Score$$serializer.INSTANCE, self.score);
        output.encodeSerializableElement(serialDesc, 4, Teams$$serializer.INSTANCE, self.teams);
    }

    public final Fixture getFixture() {
        return this.fixture;
    }

    public final Goals getGoals() {
        return this.goals;
    }

    public final League getLeague() {
        return this.league;
    }

    public final Score getScore() {
        return this.score;
    }

    public final Teams getTeams() {
        return this.teams;
    }
}
