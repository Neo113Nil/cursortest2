package com.nextfoot.response;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.UnknownFieldException;
import kotlinx.serialization.builtins.BuiltinSerializersKt;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeDecoder;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.encoding.Decoder;
import kotlinx.serialization.encoding.Encoder;
import kotlinx.serialization.internal.GeneratedSerializer;
import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;

/* compiled from: Response.kt */
@Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/nextfoot/response/Response.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/nextfoot/response/Response;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* loaded from: classes2.dex */
public final /* synthetic */ class Response$$serializer implements GeneratedSerializer<Response> {
    public static final int $stable;
    public static final Response$$serializer INSTANCE;
    private static final SerialDescriptor descriptor;

    @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
    public final SerialDescriptor getDescriptor() {
        return descriptor;
    }

    static {
        Response$$serializer response$$serializer = new Response$$serializer();
        INSTANCE = response$$serializer;
        $stable = 8;
        PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.nextfoot.response.Response", response$$serializer, 5);
        pluginGeneratedSerialDescriptor.addElement("fixture", false);
        pluginGeneratedSerialDescriptor.addElement("goals", false);
        pluginGeneratedSerialDescriptor.addElement("league", false);
        pluginGeneratedSerialDescriptor.addElement("score", false);
        pluginGeneratedSerialDescriptor.addElement("teams", false);
        descriptor = pluginGeneratedSerialDescriptor;
    }

    private Response$$serializer() {
    }

    @Override // kotlinx.serialization.internal.GeneratedSerializer
    public final KSerializer<?>[] childSerializers() {
        return new KSerializer[]{Fixture$$serializer.INSTANCE, Goals$$serializer.INSTANCE, BuiltinSerializersKt.getNullable(League$$serializer.INSTANCE), BuiltinSerializersKt.getNullable(Score$$serializer.INSTANCE), Teams$$serializer.INSTANCE};
    }

    @Override // kotlinx.serialization.DeserializationStrategy
    public final Response deserialize(Decoder decoder) {
        int i;
        Fixture fixture;
        Goals goals;
        League league;
        Score score;
        Teams teams;
        Intrinsics.checkNotNullParameter(decoder, "decoder");
        SerialDescriptor serialDescriptor = descriptor;
        CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
        Fixture fixture2 = null;
        if (compositeDecoderBeginStructure.decodeSequentially()) {
            Fixture fixture3 = (Fixture) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 0, Fixture$$serializer.INSTANCE, null);
            Goals goals2 = (Goals) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, Goals$$serializer.INSTANCE, null);
            League league2 = (League) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, League$$serializer.INSTANCE, null);
            fixture = fixture3;
            score = (Score) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, Score$$serializer.INSTANCE, null);
            teams = (Teams) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 4, Teams$$serializer.INSTANCE, null);
            league = league2;
            goals = goals2;
            i = 31;
        } else {
            boolean z = true;
            int i2 = 0;
            Goals goals3 = null;
            League league3 = null;
            Score score2 = null;
            Teams teams2 = null;
            while (z) {
                int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                if (iDecodeElementIndex == -1) {
                    z = false;
                } else if (iDecodeElementIndex == 0) {
                    fixture2 = (Fixture) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 0, Fixture$$serializer.INSTANCE, fixture2);
                    i2 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    goals3 = (Goals) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, Goals$$serializer.INSTANCE, goals3);
                    i2 |= 2;
                } else if (iDecodeElementIndex == 2) {
                    league3 = (League) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, League$$serializer.INSTANCE, league3);
                    i2 |= 4;
                } else if (iDecodeElementIndex == 3) {
                    score2 = (Score) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, Score$$serializer.INSTANCE, score2);
                    i2 |= 8;
                } else {
                    if (iDecodeElementIndex != 4) {
                        throw new UnknownFieldException(iDecodeElementIndex);
                    }
                    teams2 = (Teams) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 4, Teams$$serializer.INSTANCE, teams2);
                    i2 |= 16;
                }
            }
            i = i2;
            fixture = fixture2;
            goals = goals3;
            league = league3;
            score = score2;
            teams = teams2;
        }
        compositeDecoderBeginStructure.endStructure(serialDescriptor);
        return new Response(i, fixture, goals, league, score, teams, null);
    }

    @Override // kotlinx.serialization.SerializationStrategy
    public final void serialize(Encoder encoder, Response value) {
        Intrinsics.checkNotNullParameter(encoder, "encoder");
        Intrinsics.checkNotNullParameter(value, "value");
        SerialDescriptor serialDescriptor = descriptor;
        CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
        Response.write$Self$app_release(value, compositeEncoderBeginStructure, serialDescriptor);
        compositeEncoderBeginStructure.endStructure(serialDescriptor);
    }

    @Override // kotlinx.serialization.internal.GeneratedSerializer
    public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
        return super.typeParametersSerializers();
    }
}
