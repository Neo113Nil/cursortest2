package com.nextfoot.database;

import androidx.room.RoomDatabase;
import kotlin.Metadata;

/* compiled from: DatabaseBuilder.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0007H&¨\u0006\b"}, d2 = {"Lcom/nextfoot/database/DatabaseBuilder;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "favoriteDao", "Lcom/nextfoot/database/FavoriteDao;", "profileDao", "Lcom/nextfoot/database/ProfileDao;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class DatabaseBuilder extends RoomDatabase {
    public static final int $stable = 8;

    public abstract FavoriteDao favoriteDao();

    public abstract ProfileDao profileDao();
}
