package com.nextfoot.database;

import androidx.core.app.NotificationCompat;
import com.nextfoot.model.ProfileModel;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ProfileEntity.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B1\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0004\b\t\u0010\nJ\u0006\u0010\u0012\u001a\u00020\u0013J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J;\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001e\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000e¨\u0006\u001f"}, d2 = {"Lcom/nextfoot/database/ProfileEntity;", "", "id", "", "name", "", NotificationCompat.CATEGORY_EMAIL, "favoriteSport", "profilePictureUri", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getId", "()I", "getName", "()Ljava/lang/String;", "getEmail", "getFavoriteSport", "getProfilePictureUri", "createProfileModel", "Lcom/nextfoot/model/ProfileModel;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class ProfileEntity {
    public static final int $stable = 0;
    private final String email;
    private final String favoriteSport;
    private final int id;
    private final String name;
    private final String profilePictureUri;

    public static /* synthetic */ ProfileEntity copy$default(ProfileEntity profileEntity, int i, String str, String str2, String str3, String str4, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = profileEntity.id;
        }
        if ((i2 & 2) != 0) {
            str = profileEntity.name;
        }
        if ((i2 & 4) != 0) {
            str2 = profileEntity.email;
        }
        if ((i2 & 8) != 0) {
            str3 = profileEntity.favoriteSport;
        }
        if ((i2 & 16) != 0) {
            str4 = profileEntity.profilePictureUri;
        }
        String str5 = str4;
        String str6 = str2;
        return profileEntity.copy(i, str, str6, str3, str5);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* renamed from: component3, reason: from getter */
    public final String getEmail() {
        return this.email;
    }

    /* renamed from: component4, reason: from getter */
    public final String getFavoriteSport() {
        return this.favoriteSport;
    }

    /* renamed from: component5, reason: from getter */
    public final String getProfilePictureUri() {
        return this.profilePictureUri;
    }

    public final ProfileEntity copy(int id, String name, String email, String favoriteSport, String profilePictureUri) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(email, "email");
        Intrinsics.checkNotNullParameter(favoriteSport, "favoriteSport");
        Intrinsics.checkNotNullParameter(profilePictureUri, "profilePictureUri");
        return new ProfileEntity(id, name, email, favoriteSport, profilePictureUri);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ProfileEntity)) {
            return false;
        }
        ProfileEntity profileEntity = (ProfileEntity) other;
        return this.id == profileEntity.id && Intrinsics.areEqual(this.name, profileEntity.name) && Intrinsics.areEqual(this.email, profileEntity.email) && Intrinsics.areEqual(this.favoriteSport, profileEntity.favoriteSport) && Intrinsics.areEqual(this.profilePictureUri, profileEntity.profilePictureUri);
    }

    public int hashCode() {
        return (((((((Integer.hashCode(this.id) * 31) + this.name.hashCode()) * 31) + this.email.hashCode()) * 31) + this.favoriteSport.hashCode()) * 31) + this.profilePictureUri.hashCode();
    }

    public String toString() {
        return "ProfileEntity(id=" + this.id + ", name=" + this.name + ", email=" + this.email + ", favoriteSport=" + this.favoriteSport + ", profilePictureUri=" + this.profilePictureUri + ")";
    }

    public ProfileEntity(int i, String name, String email, String favoriteSport, String profilePictureUri) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(email, "email");
        Intrinsics.checkNotNullParameter(favoriteSport, "favoriteSport");
        Intrinsics.checkNotNullParameter(profilePictureUri, "profilePictureUri");
        this.id = i;
        this.name = name;
        this.email = email;
        this.favoriteSport = favoriteSport;
        this.profilePictureUri = profilePictureUri;
    }

    public /* synthetic */ ProfileEntity(int i, String str, String str2, String str3, String str4, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0 : i, str, str2, str3, str4);
    }

    public final int getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getEmail() {
        return this.email;
    }

    public final String getFavoriteSport() {
        return this.favoriteSport;
    }

    public final String getProfilePictureUri() {
        return this.profilePictureUri;
    }

    public final ProfileModel createProfileModel() {
        return new ProfileModel(this.name, this.email, this.favoriteSport, this.profilePictureUri);
    }
}
