package com.nextfoot.database;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* compiled from: ProfileDao.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\bg\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003H'J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0004H§@¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u0006H§@¢\u0006\u0002\u0010\n¨\u0006\u000bÀ\u0006\u0003"}, d2 = {"Lcom/nextfoot/database/ProfileDao;", "", "collectProfileEntity", "Lkotlinx/coroutines/flow/Flow;", "Lcom/nextfoot/database/ProfileEntity;", "insertProfileEntity", "", "profileEntity", "(Lcom/nextfoot/database/ProfileEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "clearTable", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public interface ProfileDao {
    Object clearTable(Continuation<? super Unit> continuation);

    Flow<ProfileEntity> collectProfileEntity();

    Object insertProfileEntity(ProfileEntity profileEntity, Continuation<? super Unit> continuation);
}
