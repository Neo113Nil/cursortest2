package com.nextfoot.database;

import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* compiled from: FavoriteDao.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0016\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\tJ\u0016\u0010\n\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\tJ\u000e\u0010\u000b\u001a\u00020\u0007H§@¢\u0006\u0002\u0010\f¨\u0006\rÀ\u0006\u0003"}, d2 = {"Lcom/nextfoot/database/FavoriteDao;", "", "collectFavoriteList", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/nextfoot/database/FavoriteEntity;", "insertFavoriteEntity", "", "favoriteEntity", "(Lcom/nextfoot/database/FavoriteEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteFavoriteEntity", "clearTable", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public interface FavoriteDao {
    Object clearTable(Continuation<? super Unit> continuation);

    Flow<List<FavoriteEntity>> collectFavoriteList();

    Object deleteFavoriteEntity(FavoriteEntity favoriteEntity, Continuation<? super Unit> continuation);

    Object insertFavoriteEntity(FavoriteEntity favoriteEntity, Continuation<? super Unit> continuation);
}
