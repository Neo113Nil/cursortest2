package com.nextfoot.database;

import com.nextfoot.model.EventModel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: FavoriteEntity.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\fJ\u0006\u0010\u0016\u001a\u00020\u0017J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\nHÆ\u0003JE\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\nHÆ\u0001J\u0013\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\"\u001a\u00020\u0003HÖ\u0001J\t\u0010#\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006$"}, d2 = {"Lcom/nextfoot/database/FavoriteEntity;", "", "id", "", "homeTeamName", "", "awayTeamName", "goalsHome", "goalsAway", "timestamp", "", "<init>", "(ILjava/lang/String;Ljava/lang/String;IIJ)V", "getId", "()I", "getHomeTeamName", "()Ljava/lang/String;", "getAwayTeamName", "getGoalsHome", "getGoalsAway", "getTimestamp", "()J", "createEventModel", "Lcom/nextfoot/model/EventModel;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class FavoriteEntity {
    public static final int $stable = 0;
    private final String awayTeamName;
    private final int goalsAway;
    private final int goalsHome;
    private final String homeTeamName;
    private final int id;
    private final long timestamp;

    public static /* synthetic */ FavoriteEntity copy$default(FavoriteEntity favoriteEntity, int i, String str, String str2, int i2, int i3, long j, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = favoriteEntity.id;
        }
        if ((i4 & 2) != 0) {
            str = favoriteEntity.homeTeamName;
        }
        if ((i4 & 4) != 0) {
            str2 = favoriteEntity.awayTeamName;
        }
        if ((i4 & 8) != 0) {
            i2 = favoriteEntity.goalsHome;
        }
        if ((i4 & 16) != 0) {
            i3 = favoriteEntity.goalsAway;
        }
        if ((i4 & 32) != 0) {
            j = favoriteEntity.timestamp;
        }
        long j2 = j;
        int i5 = i3;
        String str3 = str2;
        return favoriteEntity.copy(i, str, str3, i2, i5, j2);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final String getHomeTeamName() {
        return this.homeTeamName;
    }

    /* renamed from: component3, reason: from getter */
    public final String getAwayTeamName() {
        return this.awayTeamName;
    }

    /* renamed from: component4, reason: from getter */
    public final int getGoalsHome() {
        return this.goalsHome;
    }

    /* renamed from: component5, reason: from getter */
    public final int getGoalsAway() {
        return this.goalsAway;
    }

    /* renamed from: component6, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    public final FavoriteEntity copy(int id, String homeTeamName, String awayTeamName, int goalsHome, int goalsAway, long timestamp) {
        Intrinsics.checkNotNullParameter(homeTeamName, "homeTeamName");
        Intrinsics.checkNotNullParameter(awayTeamName, "awayTeamName");
        return new FavoriteEntity(id, homeTeamName, awayTeamName, goalsHome, goalsAway, timestamp);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FavoriteEntity)) {
            return false;
        }
        FavoriteEntity favoriteEntity = (FavoriteEntity) other;
        return this.id == favoriteEntity.id && Intrinsics.areEqual(this.homeTeamName, favoriteEntity.homeTeamName) && Intrinsics.areEqual(this.awayTeamName, favoriteEntity.awayTeamName) && this.goalsHome == favoriteEntity.goalsHome && this.goalsAway == favoriteEntity.goalsAway && this.timestamp == favoriteEntity.timestamp;
    }

    public int hashCode() {
        return (((((((((Integer.hashCode(this.id) * 31) + this.homeTeamName.hashCode()) * 31) + this.awayTeamName.hashCode()) * 31) + Integer.hashCode(this.goalsHome)) * 31) + Integer.hashCode(this.goalsAway)) * 31) + Long.hashCode(this.timestamp);
    }

    public String toString() {
        return "FavoriteEntity(id=" + this.id + ", homeTeamName=" + this.homeTeamName + ", awayTeamName=" + this.awayTeamName + ", goalsHome=" + this.goalsHome + ", goalsAway=" + this.goalsAway + ", timestamp=" + this.timestamp + ")";
    }

    public FavoriteEntity(int i, String homeTeamName, String awayTeamName, int i2, int i3, long j) {
        Intrinsics.checkNotNullParameter(homeTeamName, "homeTeamName");
        Intrinsics.checkNotNullParameter(awayTeamName, "awayTeamName");
        this.id = i;
        this.homeTeamName = homeTeamName;
        this.awayTeamName = awayTeamName;
        this.goalsHome = i2;
        this.goalsAway = i3;
        this.timestamp = j;
    }

    public final int getId() {
        return this.id;
    }

    public final String getHomeTeamName() {
        return this.homeTeamName;
    }

    public final String getAwayTeamName() {
        return this.awayTeamName;
    }

    public final int getGoalsHome() {
        return this.goalsHome;
    }

    public final int getGoalsAway() {
        return this.goalsAway;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final EventModel createEventModel() {
        return new EventModel(this.id, this.homeTeamName, this.awayTeamName, this.goalsHome, this.goalsAway, this.timestamp, null, null, null, null, 960, null);
    }
}
