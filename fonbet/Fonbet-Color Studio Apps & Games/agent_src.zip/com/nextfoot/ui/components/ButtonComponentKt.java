package com.nextfoot.ui.components;

import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.unit.Dp;
import io.ktor.http.ContentType;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.ws.WebSocketProtocol;

/* compiled from: ButtonComponent.kt */
@Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aK\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\t2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00010\fH\u0007¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"ButtonComponent", "", "modifier", "Landroidx/compose/ui/Modifier;", ContentType.Text.TYPE, "", "style", "Landroidx/compose/ui/text/TextStyle;", "containerColor", "Landroidx/compose/ui/graphics/Color;", "contentColor", "onClick", "Lkotlin/Function0;", "ButtonComponent-jB83MbM", "(Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;JJLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ButtonComponentKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ButtonComponent_jB83MbM$lambda$1(Modifier modifier, String str, TextStyle textStyle, long j, long j2, Function0 function0, int i, int i2, Composer composer, int i3) {
        m8550ButtonComponentjB83MbM(modifier, str, textStyle, j, j2, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:89:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x018c  */
    /* renamed from: ButtonComponent-jB83MbM, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void m8550ButtonComponentjB83MbM(final Modifier modifier, final String text, TextStyle textStyle, long j, long j2, final Function0<Unit> onClick, Composer composer, final int i, final int i2) {
        int i3;
        final TextStyle titleMedium;
        final long primary;
        final long onPrimary;
        Intrinsics.checkNotNullParameter(modifier, "modifier");
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        Composer composerStartRestartGroup = composer.startRestartGroup(-1604467602);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ButtonComponent)N(modifier,text,style,containerColor:c#ui.graphics.Color,contentColor:c#ui.graphics.Color,onClick)25@869L6,26@916L109,31@1061L182,23@804L439:ButtonComponent.kt#txukj4");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(modifier) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(text) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            if ((i2 & 4) == 0) {
                titleMedium = textStyle;
                int i4 = composerStartRestartGroup.changed(titleMedium) ? 256 : 128;
                i3 |= i4;
            } else {
                titleMedium = textStyle;
            }
            i3 |= i4;
        } else {
            titleMedium = textStyle;
        }
        if ((i & 3072) == 0) {
            if ((i2 & 8) == 0) {
                primary = j;
                int i5 = composerStartRestartGroup.changed(primary) ? 2048 : 1024;
                i3 |= i5;
            } else {
                primary = j;
            }
            i3 |= i5;
        } else {
            primary = j;
        }
        if ((i & 24576) == 0) {
            if ((i2 & 16) == 0) {
                onPrimary = j2;
                int i6 = composerStartRestartGroup.changed(onPrimary) ? 16384 : 8192;
                i3 |= i6;
            } else {
                onPrimary = j2;
            }
            i3 |= i6;
        } else {
            onPrimary = j2;
        }
        if ((196608 & i) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onClick) ? 131072 : 65536;
        }
        if (composerStartRestartGroup.shouldExecute((74899 & i3) != 74898, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "18@622L10,19@688L11,20@749L11");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 4) != 0) {
                    titleMedium = MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getTitleMedium();
                    i3 &= -897;
                }
                if ((i2 & 8) != 0) {
                    primary = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getPrimary();
                    i3 &= -7169;
                }
                if ((i2 & 16) != 0) {
                    onPrimary = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary();
                    i3 &= -57345;
                }
                final TextStyle textStyle2 = titleMedium;
                int i7 = i3;
                long j3 = primary;
                long j4 = onPrimary;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-1604467602, i7, -1, "com.nextfoot.ui.components.ButtonComponent (ButtonComponent.kt:22)");
                }
                ButtonKt.Button(onClick, modifier, false, MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium(), ButtonDefaults.INSTANCE.m1975buttonColorsro_MJ88(j3, j4, 0L, 0L, composerStartRestartGroup, ((i7 >> 9) & WebSocketProtocol.PAYLOAD_SHORT) | (ButtonDefaults.$stable << 12), 12), null, null, null, null, ComposableLambdaKt.rememberComposableLambda(1274337374, true, new Function3() { // from class: com.nextfoot.ui.components.ButtonComponentKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ButtonComponentKt.ButtonComponent_jB83MbM$lambda$0(text, textStyle2, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i7 >> 15) & 14) | 805306368 | ((i7 << 3) & 112), 484);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                titleMedium = textStyle2;
                primary = j3;
                onPrimary = j4;
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 4) != 0) {
                    i3 &= -897;
                }
                if ((i2 & 8) != 0) {
                    i3 &= -7169;
                }
                if ((i2 & 16) != 0) {
                    i3 &= -57345;
                }
                final TextStyle textStyle22 = titleMedium;
                int i72 = i3;
                long j32 = primary;
                long j42 = onPrimary;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                }
                ButtonKt.Button(onClick, modifier, false, MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium(), ButtonDefaults.INSTANCE.m1975buttonColorsro_MJ88(j32, j42, 0L, 0L, composerStartRestartGroup, ((i72 >> 9) & WebSocketProtocol.PAYLOAD_SHORT) | (ButtonDefaults.$stable << 12), 12), null, null, null, null, ComposableLambdaKt.rememberComposableLambda(1274337374, true, new Function3() { // from class: com.nextfoot.ui.components.ButtonComponentKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ButtonComponentKt.ButtonComponent_jB83MbM$lambda$0(text, textStyle22, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i72 >> 15) & 14) | 805306368 | ((i72 << 3) & 112), 484);
                if (ComposerKt.isTraceInProgress()) {
                }
                titleMedium = textStyle22;
                primary = j32;
                onPrimary = j42;
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.components.ButtonComponentKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ButtonComponentKt.ButtonComponent_jB83MbM$lambda$1(modifier, text, titleMedium, primary, onPrimary, onClick, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ButtonComponent_jB83MbM$lambda$0(String str, TextStyle textStyle, RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C32@1071L166:ButtonComponent.kt#txukj4");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1274337374, i, -1, "com.nextfoot.ui.components.ButtonComponent.<anonymous> (ButtonComponent.kt:32)");
            }
            TextKt.m3170TextNvy7gAk(str, PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m7962constructorimpl(0), 1, null), 0L, null, 0L, null, null, null, 0L, null, TextAlign.m7839boximpl(TextAlign.INSTANCE.m7846getCentere0LSkKk()), 0L, 0, false, 0, 0, null, textStyle, composer, 48, 0, 130044);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
