package com.nextfoot.ui.components;

import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.unit.Dp;
import io.ktor.http.ContentType;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ReverseButtonComponent.kt */
@Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a5\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\tH\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"ReverseButtonComponent", "", "modifier", "Landroidx/compose/ui/Modifier;", ContentType.Text.TYPE, "", "style", "Landroidx/compose/ui/text/TextStyle;", "onClick", "Lkotlin/Function0;", "(Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ReverseButtonComponentKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ReverseButtonComponent$lambda$1(Modifier modifier, String str, TextStyle textStyle, Function0 function0, int i, int i2, Composer composer, int i3) {
        ReverseButtonComponent(modifier, str, textStyle, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:55:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0130  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ReverseButtonComponent(final Modifier modifier, final String text, TextStyle textStyle, final Function0<Unit> onClick, Composer composer, final int i, final int i2) {
        int i3;
        TextStyle titleMedium;
        final TextStyle textStyle2;
        Intrinsics.checkNotNullParameter(modifier, "modifier");
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        Composer composerStartRestartGroup = composer.startRestartGroup(-471265664);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ReverseButtonComponent)N(modifier,text,style,onClick)21@660L6,23@764L11,24@828L11,22@707L150,27@893L140,19@595L438:ReverseButtonComponent.kt#txukj4");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(modifier) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(text) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            if ((i2 & 4) == 0) {
                titleMedium = textStyle;
                int i4 = composerStartRestartGroup.changed(titleMedium) ? 256 : 128;
                i3 |= i4;
            } else {
                titleMedium = textStyle;
            }
            i3 |= i4;
        } else {
            titleMedium = textStyle;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onClick) ? 2048 : 1024;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "16@539L10");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 4) != 0) {
                    titleMedium = MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getTitleMedium();
                    i3 &= -897;
                }
                final TextStyle textStyle3 = titleMedium;
                int i5 = i3;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-471265664, i5, -1, "com.nextfoot.ui.components.ReverseButtonComponent (ReverseButtonComponent.kt:18)");
                }
                ButtonKt.Button(onClick, modifier, false, MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium(), ButtonDefaults.INSTANCE.m1975buttonColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary(), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getPrimary(), 0L, 0L, composerStartRestartGroup, ButtonDefaults.$stable << 12, 12), null, null, null, null, ComposableLambdaKt.rememberComposableLambda(101377648, true, new Function3() { // from class: com.nextfoot.ui.components.ReverseButtonComponentKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ReverseButtonComponentKt.ReverseButtonComponent$lambda$0(text, textStyle3, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i5 >> 9) & 14) | 805306368 | ((i5 << 3) & 112), 484);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                textStyle2 = textStyle3;
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 4) != 0) {
                    i3 &= -897;
                }
                final TextStyle textStyle32 = titleMedium;
                int i52 = i3;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                }
                ButtonKt.Button(onClick, modifier, false, MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium(), ButtonDefaults.INSTANCE.m1975buttonColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary(), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getPrimary(), 0L, 0L, composerStartRestartGroup, ButtonDefaults.$stable << 12, 12), null, null, null, null, ComposableLambdaKt.rememberComposableLambda(101377648, true, new Function3() { // from class: com.nextfoot.ui.components.ReverseButtonComponentKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ReverseButtonComponentKt.ReverseButtonComponent$lambda$0(text, textStyle32, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i52 >> 9) & 14) | 805306368 | ((i52 << 3) & 112), 484);
                if (ComposerKt.isTraceInProgress()) {
                }
                textStyle2 = textStyle32;
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            textStyle2 = titleMedium;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.components.ReverseButtonComponentKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ReverseButtonComponentKt.ReverseButtonComponent$lambda$1(modifier, text, textStyle2, onClick, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ReverseButtonComponent$lambda$0(String str, TextStyle textStyle, RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C28@903L124:ReverseButtonComponent.kt#txukj4");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(101377648, i, -1, "com.nextfoot.ui.components.ReverseButtonComponent.<anonymous> (ReverseButtonComponent.kt:28)");
            }
            TextKt.m3170TextNvy7gAk(str, PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m7962constructorimpl(0), 1, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, textStyle, composer, 48, 0, 131068);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
