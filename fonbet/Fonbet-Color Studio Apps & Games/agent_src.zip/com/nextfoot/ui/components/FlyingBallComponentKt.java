package com.nextfoot.ui.components;

import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import com.nextfoot.ui.classes.BallState;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: FlyingBallComponent.kt */
@Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0004\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\b\u0010\t\u001a \u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000bH\u0002¨\u0006\u000f"}, d2 = {"FlyingBallComponent", "", "ballState", "Lcom/nextfoot/ui/classes/BallState$Flying;", "isGoldenBall", "", "boxSize", "Landroidx/compose/ui/unit/IntSize;", "FlyingBallComponent-jw68sR4", "(Lcom/nextfoot/ui/classes/BallState$Flying;ZJLandroidx/compose/runtime/Composer;I)V", "lerp", "", "start", "stop", "fraction", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class FlyingBallComponentKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit FlyingBallComponent_jw68sR4$lambda$5(BallState.Flying flying, boolean z, long j, int i, Composer composer, int i2) {
        m8552FlyingBallComponentjw68sR4(flying, z, j, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    private static final float lerp(float f, float f2, float f3) {
        return f + ((f2 - f) * f3);
    }

    /* renamed from: FlyingBallComponent-jw68sR4, reason: not valid java name */
    public static final void m8552FlyingBallComponentjw68sR4(final BallState.Flying ballState, final boolean z, final long j, Composer composer, final int i) {
        int i2;
        boolean z2;
        Intrinsics.checkNotNullParameter(ballState, "ballState");
        Composer composerStartRestartGroup = composer.startRestartGroup(-95567181);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(FlyingBallComponent)N(ballState,isGoldenBall,boxSize:c#ui.unit.IntSize)14@539L7,29@1147L380:FlyingBallComponent.kt#txukj4");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(ballState) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            z2 = z;
            i2 |= composerStartRestartGroup.changed(z2) ? 32 : 16;
        } else {
            z2 = z;
        }
        if ((i & 384) == 0) {
            i2 |= composerStartRestartGroup.changed(j) ? 256 : 128;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 147) != 146, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-95567181, i2, -1, "com.nextfoot.ui.components.FlyingBallComponent (FlyingBallComponent.kt:13)");
            }
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            Object objConsume = composerStartRestartGroup.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            Density density = (Density) objConsume;
            float progress = ballState.getProgress();
            float f = 72;
            float fMo431toPx0680j_4 = density.mo431toPx0680j_4(Dp.m7962constructorimpl(f)) / 2;
            float f2 = 1.0f - (0.3f * progress);
            BallComponentKt.BallComponent(SizeKt.m896size3ABfNKs(OffsetKt.m798offsetVpY3zN4(Modifier.INSTANCE, density.mo427toDpu2uoSUM(lerp(((int) (j >> 32)) / 2.0f, ballState.getTargetX(), progress) - fMo431toPx0680j_4), density.mo427toDpu2uoSUM((lerp((((int) (4294967295L & j)) - fMo431toPx0680j_4) - density.mo431toPx0680j_4(Dp.m7962constructorimpl(36)), ballState.getTargetY(), progress) + ((-((float) Math.sin(progress * 3.141592653589793d))) * 600.0f)) - fMo431toPx0680j_4)), Dp.m7962constructorimpl(Dp.m7962constructorimpl(f) * f2)), z2, progress * 720.0f, f2, composerStartRestartGroup, i2 & 112, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.components.FlyingBallComponentKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return FlyingBallComponentKt.FlyingBallComponent_jw68sR4$lambda$5(ballState, z, j, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }
}
