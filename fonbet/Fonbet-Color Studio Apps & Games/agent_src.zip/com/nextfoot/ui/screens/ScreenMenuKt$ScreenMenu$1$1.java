package com.nextfoot.ui.screens;

import androidx.compose.runtime.MutableState;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.NavHostController;
import com.nextfoot.ui.classes.Screen;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;

/* compiled from: ScreenMenu.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.nextfoot.ui.screens.ScreenMenuKt$ScreenMenu$1$1", f = "ScreenMenu.kt", i = {}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* loaded from: classes2.dex */
final class ScreenMenuKt$ScreenMenu$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ MutableState<Screen> $currentScreen$delegate;
    final /* synthetic */ NavHostController $menuNavController;
    final /* synthetic */ List<Screen> $screensList;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    ScreenMenuKt$ScreenMenu$1$1(NavHostController navHostController, List<? extends Screen> list, MutableState<Screen> mutableState, Continuation<? super ScreenMenuKt$ScreenMenu$1$1> continuation) {
        super(2, continuation);
        this.$menuNavController = navHostController;
        this.$screensList = list;
        this.$currentScreen$delegate = mutableState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new ScreenMenuKt$ScreenMenu$1$1(this.$menuNavController, this.$screensList, this.$currentScreen$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((ScreenMenuKt$ScreenMenu$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            Flow<NavBackStackEntry> currentBackStackEntryFlow = this.$menuNavController.getCurrentBackStackEntryFlow();
            final List<Screen> list = this.$screensList;
            final MutableState<Screen> mutableState = this.$currentScreen$delegate;
            this.label = 1;
            if (currentBackStackEntryFlow.collect(new FlowCollector() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$ScreenMenu$1$1.1
                @Override // kotlinx.coroutines.flow.FlowCollector
                public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                    return emit((NavBackStackEntry) obj2, (Continuation<? super Unit>) continuation);
                }

                public final Object emit(NavBackStackEntry navBackStackEntry, Continuation<? super Unit> continuation) {
                    T next;
                    MutableState<Screen> mutableState2 = mutableState;
                    Iterator<T> it = list.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            next = (T) null;
                            break;
                        }
                        next = it.next();
                        String lowerCase = ((Screen) next).getName().toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        if (Intrinsics.areEqual(lowerCase, navBackStackEntry.getDestination().getRoute())) {
                            break;
                        }
                    }
                    Screen screen = next;
                    if (screen == null) {
                        screen = list.get(0);
                    }
                    mutableState2.setValue(screen);
                    return Unit.INSTANCE;
                }
            }, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
        }
        return Unit.INSTANCE;
    }
}
