package com.nextfoot.ui.screens;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.shape.CornerBasedShape;
import androidx.compose.material3.CardColors;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.unit.Dp;
import androidx.core.app.NotificationCompat;
import androidx.navigation.NavController;
import androidx.navigation.NavGraph;
import androidx.navigation.NavHostController;
import androidx.navigation.NavOptions;
import androidx.navigation.NavOptionsBuilder;
import androidx.navigation.Navigator;
import androidx.navigation.PopUpToBuilder;
import com.nextfoot.model.EventModel;
import com.nextfoot.ui.classes.Screen;
import com.nextfoot.ui.components.EventComponentKt;
import com.nextfoot.viewmodel.MainViewModel;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ScreenSchedule.kt */
@Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\u001a-\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0007¢\u0006\u0002\u0010\t¨\u0006\n²\u0006\u0012\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\fX\u008a\u0084\u0002²\u0006\u0010\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u008a\u0084\u0002"}, d2 = {"ScreenSchedule", "", "paddingValues", "Landroidx/compose/foundation/layout/PaddingValues;", "viewModel", "Lcom/nextfoot/viewmodel/MainViewModel;", "navController", "Landroidx/navigation/NavHostController;", "menuNavController", "(Landroidx/compose/foundation/layout/PaddingValues;Lcom/nextfoot/viewmodel/MainViewModel;Landroidx/navigation/NavHostController;Landroidx/navigation/NavHostController;Landroidx/compose/runtime/Composer;I)V", "app_release", "scheduleList", "", "Lcom/nextfoot/model/EventModel;", "favoriteList"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ScreenScheduleKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenSchedule$lambda$3(PaddingValues paddingValues, MainViewModel mainViewModel, NavHostController navHostController, NavHostController navHostController2, int i, Composer composer, int i2) {
        ScreenSchedule(paddingValues, mainViewModel, navHostController, navHostController2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void ScreenSchedule(final PaddingValues paddingValues, final MainViewModel viewModel, final NavHostController navController, final NavHostController menuNavController, Composer composer, final int i) {
        int i2;
        String str;
        String str2;
        String str3;
        String str4;
        Unit unit;
        boolean z;
        Intrinsics.checkNotNullParameter(paddingValues, "paddingValues");
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(navController, "navController");
        Intrinsics.checkNotNullParameter(menuNavController, "menuNavController");
        Composer composerStartRestartGroup = composer.startRestartGroup(-2037678407);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ScreenSchedule)N(paddingValues,viewModel,navController,menuNavController)42@1766L16,43@1830L16,44@1851L4495:ScreenSchedule.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(paddingValues) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(viewModel) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(navController) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(menuNavController) ? 2048 : 1024;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 1171) != 1170, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2037678407, i2, -1, "com.nextfoot.ui.screens.ScreenSchedule (ScreenSchedule.kt:41)");
            }
            State stateCollectAsState = SnapshotStateKt.collectAsState(viewModel.getEventsList(), null, composerStartRestartGroup, 0, 1);
            final State stateCollectAsState2 = SnapshotStateKt.collectAsState(viewModel.getFavoriteList(), null, composerStartRestartGroup, 0, 1);
            Modifier modifierM848paddingqDBjuR0$default = PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, 0.0f, paddingValues.getBottom(), 7, null);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM848paddingqDBjuR0$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                composerM4565constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
                composerM4565constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
            }
            Updater.m4572setimpl(composerM4565constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1068166321, "C52@2156L11,48@1973L220,58@2352L11,54@2202L609:ScreenSchedule.kt#5m3rtf");
            SpacerKt.Spacer(BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), paddingValues.getTop()), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null), composerStartRestartGroup, 0);
            Modifier modifierM269backgroundbw27NRU$default = BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m7962constructorimpl(90)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null);
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, composerStartRestartGroup, 48);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM269backgroundbw27NRU$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor2);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl2 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                composerM4565constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
                composerM4565constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
            }
            Updater.m4572setimpl(composerM4565constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1424570221, "C63@2545L10,64@2610L11,61@2464L337:ScreenSchedule.kt#5m3rtf");
            TextKt.m3170TextNvy7gAk("Расписание", RowScope.weight$default(rowScopeInstance, SizeKt.fillMaxWidth$default(PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, Dp.m7962constructorimpl(40), 0.0f, 0.0f, 0.0f, 14, null), 0.0f, 1, null), 1.0f, false, 2, null), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getHeadlineMedium(), composerStartRestartGroup, 6, 0, 131064);
            composerStartRestartGroup = composerStartRestartGroup;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final List<EventModel> listScreenSchedule$lambda$0 = ScreenSchedule$lambda$0(stateCollectAsState);
            if (listScreenSchedule$lambda$0 != null) {
                composerStartRestartGroup.startReplaceGroup(1068964911);
                ComposerKt.sourceInformation(composerStartRestartGroup, "");
                if (!listScreenSchedule$lambda$0.isEmpty()) {
                    composerStartRestartGroup.startReplaceGroup(344671927);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "77@3140L1107,73@2901L1346");
                    PaddingValues paddingValuesM839PaddingValuesYgX7TsA$default = PaddingKt.m839PaddingValuesYgX7TsA$default(0.0f, Dp.m7962constructorimpl(30), 1, null);
                    Arrangement.HorizontalOrVertical horizontalOrVerticalM703spacedBy0680j_4 = Arrangement.INSTANCE.m703spacedBy0680j_4(Dp.m7962constructorimpl(20));
                    Modifier modifierM846paddingVpY3zN4$default = PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, Dp.m7962constructorimpl(12), 0.0f, 2, null);
                    Arrangement.HorizontalOrVertical horizontalOrVertical = horizontalOrVerticalM703spacedBy0680j_4;
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1950788508, "CC(remember):ScreenSchedule.kt#9igjgp");
                    boolean zChangedInstance = composerStartRestartGroup.changedInstance(listScreenSchedule$lambda$0) | composerStartRestartGroup.changed(stateCollectAsState2) | composerStartRestartGroup.changedInstance(viewModel) | composerStartRestartGroup.changedInstance(navController) | composerStartRestartGroup.changedInstance(menuNavController);
                    Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        z = true;
                        Function1 function1 = new Function1() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return ScreenScheduleKt.ScreenSchedule$lambda$2$1$0$0(listScreenSchedule$lambda$0, viewModel, navController, menuNavController, stateCollectAsState2, (LazyListScope) obj);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(function1);
                        objRememberedValue = function1;
                    } else {
                        z = true;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    str = "C72@3469L9:Box.kt#2w3rfo";
                    str2 = "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo";
                    LazyDslKt.LazyColumn(modifierM846paddingVpY3zN4$default, null, paddingValuesM839PaddingValuesYgX7TsA$default, false, horizontalOrVertical, null, null, false, null, (Function1) objRememberedValue, composerStartRestartGroup, 24966, 490);
                    composerStartRestartGroup = composerStartRestartGroup;
                    composerStartRestartGroup.endReplaceGroup();
                    str3 = "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp";
                    str4 = "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh";
                } else {
                    str = "C72@3469L9:Box.kt#2w3rfo";
                    str2 = "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo";
                    composerStartRestartGroup.startReplaceGroup(346020396);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "101@4285L1101");
                    Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Alignment center = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, str2);
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
                    int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                    CompositionLocalMap currentCompositionLocalMap3 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxSize$default);
                    Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                    str3 = "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp";
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, str3);
                    if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composerStartRestartGroup.startReusableNode();
                    if (composerStartRestartGroup.getInserting()) {
                        composerStartRestartGroup.createNode(constructor3);
                    } else {
                        composerStartRestartGroup.useNode();
                    }
                    Composer composerM4565constructorimpl3 = Updater.m4565constructorimpl(composerStartRestartGroup);
                    Updater.m4572setimpl(composerM4565constructorimpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m4572setimpl(composerM4565constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composerM4565constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                        composerM4565constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
                        composerM4565constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
                    }
                    Updater.m4572setimpl(composerM4565constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, str);
                    BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1320934075, "C106@4493L6,108@4625L11,109@4703L11,107@4554L196,105@4441L927:ScreenSchedule.kt#5m3rtf");
                    CornerBasedShape medium = MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium();
                    str4 = "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh";
                    CardColors cardColorsM1997cardColorsro_MJ88 = CardDefaults.INSTANCE.m1997cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurface(), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurface(), 0L, 0L, composerStartRestartGroup, CardDefaults.$stable << 12, 12);
                    composerStartRestartGroup = composerStartRestartGroup;
                    CardKt.Card(SizeKt.fillMaxWidth$default(PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, Dp.m7962constructorimpl(12), 0.0f, 2, null), 0.0f, 1, null), medium, cardColorsM1997cardColorsro_MJ88, null, null, ComposableSingletons$ScreenScheduleKt.INSTANCE.getLambda$328774317$app_release(), composerStartRestartGroup, 196614, 24);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    composerStartRestartGroup.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    composerStartRestartGroup.endReplaceGroup();
                }
                Unit unit2 = Unit.INSTANCE;
                composerStartRestartGroup.endReplaceGroup();
                unit = Unit.INSTANCE;
            } else {
                composerStartRestartGroup.startReplaceGroup(1068964910);
                composerStartRestartGroup.endReplaceGroup();
                unit = null;
                str = "C72@3469L9:Box.kt#2w3rfo";
                str2 = "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo";
                str3 = "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp";
                str4 = "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh";
            }
            if (unit != null) {
                composerStartRestartGroup.startReplaceGroup(34483235);
                composerStartRestartGroup.endReplaceGroup();
            } else {
                composerStartRestartGroup.startReplaceGroup(1071473121);
                ComposerKt.sourceInformation(composerStartRestartGroup, "*127@5432L898");
                Modifier modifierFillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment center2 = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, str2);
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, str4);
                int iHashCode4 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                CompositionLocalMap currentCompositionLocalMap4 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxSize$default2);
                Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, str3);
                if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor4);
                } else {
                    composerStartRestartGroup.useNode();
                }
                Composer composerM4565constructorimpl4 = Updater.m4565constructorimpl(composerStartRestartGroup);
                Updater.m4572setimpl(composerM4565constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m4572setimpl(composerM4565constructorimpl4, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM4565constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl4.rememberedValue(), Integer.valueOf(iHashCode4))) {
                    composerM4565constructorimpl4.updateRememberedValue(Integer.valueOf(iHashCode4));
                    composerM4565constructorimpl4.apply(Integer.valueOf(iHashCode4), setCompositeKeyHash4);
                }
                Updater.m4572setimpl(composerM4565constructorimpl4, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, str);
                BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1232949478, "C132@5620L6,134@5744L11,135@5818L11,133@5677L184,131@5572L744:ScreenSchedule.kt#5m3rtf");
                CornerBasedShape medium2 = MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium();
                Composer composer2 = composerStartRestartGroup;
                CardColors cardColorsM1997cardColorsro_MJ882 = CardDefaults.INSTANCE.m1997cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurface(), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurface(), 0L, 0L, composer2, CardDefaults.$stable << 12, 12);
                composerStartRestartGroup = composer2;
                CardKt.Card(SizeKt.m896size3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(56)), medium2, cardColorsM1997cardColorsro_MJ882, null, null, ComposableSingletons$ScreenScheduleKt.INSTANCE.m8565getLambda$1913335661$app_release(), composerStartRestartGroup, 196614, 24);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Unit unit3 = Unit.INSTANCE;
                composerStartRestartGroup.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ScreenScheduleKt.ScreenSchedule$lambda$3(paddingValues, viewModel, navController, menuNavController, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final List<EventModel> ScreenSchedule$lambda$0(State<? extends List<EventModel>> state) {
        return state.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final List<EventModel> ScreenSchedule$lambda$1(State<? extends List<EventModel>> state) {
        return state.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenSchedule$lambda$2$1$0$0(final List list, final MainViewModel mainViewModel, final NavHostController navHostController, final NavHostController navHostController2, final State state, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final ScreenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$1 screenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$1 = new Function1() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(EventModel eventModel) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                return invoke((EventModel) obj);
            }
        };
        LazyColumn.items(list.size(), null, new Function1<Integer, Object>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                return screenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$1.invoke(list.get(i));
            }
        }, ComposableLambdaKt.composableLambdaInstance(802480018, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$lambda$2$1$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope lazyItemScope, int i, Composer composer, int i2) {
                int i3;
                boolean z;
                ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final EventModel eventModel = (EventModel) list.get(i);
                composer.startReplaceGroup(-1929989046);
                ComposerKt.sourceInformation(composer, "CN(eventModel)*82@3410L96,86@3592L589,79@3214L993:ScreenSchedule.kt#5m3rtf");
                List listScreenSchedule$lambda$1 = ScreenScheduleKt.ScreenSchedule$lambda$1(state);
                if ((listScreenSchedule$lambda$1 instanceof Collection) && listScreenSchedule$lambda$1.isEmpty()) {
                    z = false;
                } else {
                    Iterator it = listScreenSchedule$lambda$1.iterator();
                    while (it.hasNext()) {
                        if (((EventModel) it.next()).getId() == eventModel.getId()) {
                            z = true;
                            break;
                        }
                    }
                    z = false;
                }
                ComposerKt.sourceInformationMarkerStart(composer, 214842328, "CC(remember):ScreenSchedule.kt#9igjgp");
                boolean zChangedInstance = composer.changedInstance(mainViewModel) | composer.changed(eventModel);
                Object objRememberedValue = composer.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    final MainViewModel mainViewModel2 = mainViewModel;
                    objRememberedValue = (Function0) new Function0<Unit>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$1$2$1$1$1$2$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            mainViewModel2.onFavorite(eventModel);
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                Function0 function0 = (Function0) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerStart(composer, 214848645, "CC(remember):ScreenSchedule.kt#9igjgp");
                boolean zChangedInstance2 = composer.changedInstance(mainViewModel) | composer.changed(eventModel) | composer.changedInstance(navHostController) | composer.changedInstance(navHostController2);
                Object objRememberedValue2 = composer.rememberedValue();
                if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    final MainViewModel mainViewModel3 = mainViewModel;
                    final NavHostController navHostController3 = navHostController;
                    final NavHostController navHostController4 = navHostController2;
                    objRememberedValue2 = (Function0) new Function0<Unit>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$1$2$1$1$1$3$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            mainViewModel3.onEvent(eventModel);
                            NavController.navigate$default((NavController) navHostController3, NotificationCompat.CATEGORY_EVENT, (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                            NavHostController navHostController5 = navHostController4;
                            String lowerCase = Screen.Bets.INSTANCE.getName().toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                            final NavHostController navHostController6 = navHostController4;
                            navHostController5.navigate(lowerCase, (Function1<? super NavOptionsBuilder, Unit>) new Function1<NavOptionsBuilder, Unit>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt$ScreenSchedule$1$2$1$1$1$3$1.1
                                @Override // kotlin.jvm.functions.Function1
                                public /* bridge */ /* synthetic */ Unit invoke(NavOptionsBuilder navOptionsBuilder) {
                                    invoke2(navOptionsBuilder);
                                    return Unit.INSTANCE;
                                }

                                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                                public final void invoke2(NavOptionsBuilder navigate) {
                                    Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
                                    navigate.popUpTo(NavGraph.INSTANCE.findStartDestination(navHostController6.getGraph()).getId(), new Function1<PopUpToBuilder, Unit>() { // from class: com.nextfoot.ui.screens.ScreenScheduleKt.ScreenSchedule.1.2.1.1.1.3.1.1.1
                                        @Override // kotlin.jvm.functions.Function1
                                        public /* bridge */ /* synthetic */ Unit invoke(PopUpToBuilder popUpToBuilder) {
                                            invoke2(popUpToBuilder);
                                            return Unit.INSTANCE;
                                        }

                                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                                        public final void invoke2(PopUpToBuilder popUpTo) {
                                            Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
                                            popUpTo.setSaveState(true);
                                        }
                                    });
                                    navigate.setLaunchSingleTop(true);
                                    navigate.setRestoreState(true);
                                }
                            });
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                EventComponentKt.EventComponent(eventModel, z, function0, true, (Function0) objRememberedValue2, composer, 3072, 0);
                composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }
}
