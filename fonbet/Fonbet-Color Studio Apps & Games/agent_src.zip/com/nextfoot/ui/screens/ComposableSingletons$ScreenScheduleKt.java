package com.nextfoot.ui.screens;

import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.StrokeCap;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ScreenSchedule.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ScreenScheduleKt {
    public static final ComposableSingletons$ScreenScheduleKt INSTANCE = new ComposableSingletons$ScreenScheduleKt();
    private static Function3<ColumnScope, Composer, Integer, Unit> lambda$328774317 = ComposableLambdaKt.composableLambdaInstance(328774317, false, new Function3() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenScheduleKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ScreenScheduleKt.lambda_328774317$lambda$0((ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1913335661, reason: not valid java name */
    private static Function3<ColumnScope, Composer, Integer, Unit> f52lambda$1913335661 = ComposableLambdaKt.composableLambdaInstance(-1913335661, false, new Function3() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenScheduleKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ScreenScheduleKt.lambda__1913335661$lambda$0((ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1913335661$app_release, reason: not valid java name */
    public final Function3<ColumnScope, Composer, Integer, Unit> m8565getLambda$1913335661$app_release() {
        return f52lambda$1913335661;
    }

    public final Function3<ColumnScope, Composer, Integer, Unit> getLambda$328774317$app_release() {
        return lambda$328774317;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda_328774317$lambda$0(ColumnScope Card, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation(composer, "C117@5097L10,115@4945L401:ScreenSchedule.kt#5m3rtf");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(328774317, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenScheduleKt.lambda$328774317.<anonymous> (ScreenSchedule.kt:115)");
            }
            TextKt.m3170TextNvy7gAk("Не удалось получить расписание матчей.\nПопробуйте позже.", SizeKt.fillMaxWidth$default(PaddingKt.m844padding3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(12)), 0.0f, 1, null), 0L, null, 0L, null, null, null, 0L, null, TextAlign.m7839boximpl(TextAlign.INSTANCE.m7846getCentere0LSkKk()), 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer, 54, 0, 130044);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__1913335661$lambda$0(ColumnScope Card, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation(composer, "C143@6160L11,139@5955L343:ScreenSchedule.kt#5m3rtf");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1913335661, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenScheduleKt.lambda$-1913335661.<anonymous> (ScreenSchedule.kt:139)");
            }
            ProgressIndicatorKt.m2745CircularProgressIndicator4lLiAd8(SizeKt.fillMaxSize$default(PaddingKt.m844padding3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(12)), 0.0f, 1, null), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimary(), Dp.m7962constructorimpl(4), 0L, StrokeCap.INSTANCE.m5617getRoundKaPHkGw(), 0.0f, composer, 390, 40);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
