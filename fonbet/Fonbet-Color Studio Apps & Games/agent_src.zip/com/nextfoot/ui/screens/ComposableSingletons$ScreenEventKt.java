package com.nextfoot.ui.screens;

import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.PainterResources_androidKt;
import com.nextfoot.R;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* compiled from: ScreenEvent.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ScreenEventKt {
    public static final ComposableSingletons$ScreenEventKt INSTANCE = new ComposableSingletons$ScreenEventKt();

    /* renamed from: lambda$-1841279784, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f47lambda$1841279784 = ComposableLambdaKt.composableLambdaInstance(-1841279784, false, new Function2() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenEventKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$ScreenEventKt.lambda__1841279784$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1841279784$app_release, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8557getLambda$1841279784$app_release() {
        return f47lambda$1841279784;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__1841279784$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C68@2578L37,70@2705L11,67@2552L199:ScreenEvent.kt#5m3rtf");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1841279784, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenEventKt.lambda$-1841279784.<anonymous> (ScreenEvent.kt:67)");
            }
            IconKt.m2463Iconww6aTOc(PainterResources_androidKt.painterResource(R.drawable.icon_back, composer, 0), (String) null, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), composer, 48, 4);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
