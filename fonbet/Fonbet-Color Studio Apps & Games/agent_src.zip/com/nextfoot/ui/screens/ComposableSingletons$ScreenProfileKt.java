package com.nextfoot.ui.screens;

import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* compiled from: ScreenProfile.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ScreenProfileKt {
    public static final ComposableSingletons$ScreenProfileKt INSTANCE = new ComposableSingletons$ScreenProfileKt();

    /* renamed from: lambda$-30431766, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f51lambda$30431766 = ComposableLambdaKt.composableLambdaInstance(-30431766, false, new Function2() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenProfileKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$ScreenProfileKt.lambda__30431766$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-165014455, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f50lambda$165014455 = ComposableLambdaKt.composableLambdaInstance(-165014455, false, new Function2() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenProfileKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$ScreenProfileKt.lambda__165014455$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-165014455$app_release, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8562getLambda$165014455$app_release() {
        return f50lambda$165014455;
    }

    /* renamed from: getLambda$-30431766$app_release, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8563getLambda$30431766$app_release() {
        return f51lambda$30431766;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__30431766$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C212@9462L19:ScreenProfile.kt#5m3rtf");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-30431766, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenProfileKt.lambda$-30431766.<anonymous> (ScreenProfile.kt:212)");
            }
            TextKt.m3170TextNvy7gAk("Введите имя", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer, 6, 0, 262142);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__165014455$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C249@11269L21:ScreenProfile.kt#5m3rtf");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-165014455, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenProfileKt.lambda$-165014455.<anonymous> (ScreenProfile.kt:249)");
            }
            TextKt.m3170TextNvy7gAk("Введите почту", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer, 6, 0, 262142);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }
}
