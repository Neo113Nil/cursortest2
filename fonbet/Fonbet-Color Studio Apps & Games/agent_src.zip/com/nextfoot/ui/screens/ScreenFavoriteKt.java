package com.nextfoot.ui.screens;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.unit.Dp;
import com.nextfoot.model.EventModel;
import com.nextfoot.ui.components.EventComponentKt;
import com.nextfoot.viewmodel.MainViewModel;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ScreenFavorite.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\u001a\u001d\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007²\u0006\u0010\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u008a\u0084\u0002"}, d2 = {"ScreenFavorite", "", "paddingValues", "Landroidx/compose/foundation/layout/PaddingValues;", "viewModel", "Lcom/nextfoot/viewmodel/MainViewModel;", "(Landroidx/compose/foundation/layout/PaddingValues;Lcom/nextfoot/viewmodel/MainViewModel;Landroidx/compose/runtime/Composer;I)V", "app_release", "favoriteList", "", "Lcom/nextfoot/model/EventModel;"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ScreenFavoriteKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenFavorite$lambda$2(PaddingValues paddingValues, MainViewModel mainViewModel, int i, Composer composer, int i2) {
        ScreenFavorite(paddingValues, mainViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void ScreenFavorite(final PaddingValues paddingValues, final MainViewModel viewModel, Composer composer, final int i) {
        int i2;
        final MainViewModel mainViewModel;
        Intrinsics.checkNotNullParameter(paddingValues, "paddingValues");
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Composer composerStartRestartGroup = composer.startRestartGroup(-390657245);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ScreenFavorite)N(paddingValues,viewModel)34@1384L16,35@1405L2868:ScreenFavorite.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = i | (composerStartRestartGroup.changed(paddingValues) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(viewModel) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            mainViewModel = viewModel;
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-390657245, i2, -1, "com.nextfoot.ui.screens.ScreenFavorite (ScreenFavorite.kt:33)");
            }
            final State stateCollectAsState = SnapshotStateKt.collectAsState(viewModel.getFavoriteList(), null, composerStartRestartGroup, 0, 1);
            Modifier modifierM848paddingqDBjuR0$default = PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, 0.0f, paddingValues.getBottom(), 7, null);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM848paddingqDBjuR0$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                composerM4565constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
                composerM4565constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
            }
            Updater.m4572setimpl(composerM4565constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 805457410, "C43@1710L11,39@1527L220,49@1906L11,45@1756L608:ScreenFavorite.kt#5m3rtf");
            SpacerKt.Spacer(BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), paddingValues.getTop()), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null), composerStartRestartGroup, 0);
            Modifier modifierM269backgroundbw27NRU$default = BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m7962constructorimpl(90)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null);
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, composerStartRestartGroup, 48);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM269backgroundbw27NRU$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor2);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl2 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                composerM4565constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
                composerM4565constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
            }
            Updater.m4572setimpl(composerM4565constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1924354250, "C54@2098L10,55@2163L11,52@2018L336:ScreenFavorite.kt#5m3rtf");
            TextKt.m3170TextNvy7gAk("Избранное", RowScope.weight$default(rowScopeInstance, SizeKt.fillMaxWidth$default(PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, Dp.m7962constructorimpl(40), 0.0f, 0.0f, 0.0f, 14, null), 0.0f, 1, null), 1.0f, false, 2, null), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getHeadlineMedium(), composerStartRestartGroup, 6, 0, 131064);
            composerStartRestartGroup = composerStartRestartGroup;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.startReplaceGroup(26009126);
            ComposerKt.sourceInformation(composerStartRestartGroup, "");
            final List<EventModel> listScreenFavorite$lambda$0 = ScreenFavorite$lambda$0(stateCollectAsState);
            if (!listScreenFavorite$lambda$0.isEmpty()) {
                composerStartRestartGroup.startReplaceGroup(376200551);
                ComposerKt.sourceInformation(composerStartRestartGroup, "68@2692L397,64@2453L636");
                PaddingValues paddingValuesM839PaddingValuesYgX7TsA$default = PaddingKt.m839PaddingValuesYgX7TsA$default(0.0f, Dp.m7962constructorimpl(30), 1, null);
                Arrangement.HorizontalOrVertical horizontalOrVerticalM703spacedBy0680j_4 = Arrangement.INSTANCE.m703spacedBy0680j_4(Dp.m7962constructorimpl(20));
                Modifier modifierM846paddingVpY3zN4$default = PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, Dp.m7962constructorimpl(12), 0.0f, 2, null);
                Arrangement.HorizontalOrVertical horizontalOrVertical = horizontalOrVerticalM703spacedBy0680j_4;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1536163564, "CC(remember):ScreenFavorite.kt#9igjgp");
                boolean zChangedInstance = composerStartRestartGroup.changedInstance(listScreenFavorite$lambda$0) | composerStartRestartGroup.changed(stateCollectAsState) | composerStartRestartGroup.changedInstance(viewModel);
                Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function1() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return ScreenFavoriteKt.ScreenFavorite$lambda$1$1$0$0(listScreenFavorite$lambda$0, viewModel, stateCollectAsState, (LazyListScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                mainViewModel = viewModel;
                LazyDslKt.LazyColumn(modifierM846paddingVpY3zN4$default, null, paddingValuesM839PaddingValuesYgX7TsA$default, false, horizontalOrVertical, null, null, false, null, (Function1) objRememberedValue, composerStartRestartGroup, 24966, 490);
                composerStartRestartGroup = composerStartRestartGroup;
                composerStartRestartGroup.endReplaceGroup();
            } else {
                mainViewModel = viewModel;
                composerStartRestartGroup.startReplaceGroup(376867175);
                ComposerKt.sourceInformation(composerStartRestartGroup, "79@3127L1116");
                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment center = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
                int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                CompositionLocalMap currentCompositionLocalMap3 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxSize$default);
                Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor3);
                } else {
                    composerStartRestartGroup.useNode();
                }
                Composer composerM4565constructorimpl3 = Updater.m4565constructorimpl(composerStartRestartGroup);
                Updater.m4572setimpl(composerM4565constructorimpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m4572setimpl(composerM4565constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM4565constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                    composerM4565constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
                    composerM4565constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
                }
                Updater.m4572setimpl(composerM4565constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 979777068, "C84@3335L6,86@3467L11,87@3545L11,85@3396L196,83@3283L942:ScreenFavorite.kt#5m3rtf");
                CardKt.Card(SizeKt.fillMaxWidth$default(PaddingKt.m846paddingVpY3zN4$default(Modifier.INSTANCE, Dp.m7962constructorimpl(12), 0.0f, 2, null), 0.0f, 1, null), MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium(), CardDefaults.INSTANCE.m1997cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurface(), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurface(), 0L, 0L, composerStartRestartGroup, CardDefaults.$stable << 12, 12), null, null, ComposableSingletons$ScreenFavoriteKt.INSTANCE.m8558getLambda$1682258949$app_release(), composerStartRestartGroup, 196614, 24);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endReplaceGroup();
            }
            Unit unit = Unit.INSTANCE;
            composerStartRestartGroup.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ScreenFavoriteKt.ScreenFavorite$lambda$2(paddingValues, mainViewModel, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final List<EventModel> ScreenFavorite$lambda$0(State<? extends List<EventModel>> state) {
        return state.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenFavorite$lambda$1$1$0$0(final List list, final MainViewModel mainViewModel, final State state, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final ScreenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$1 screenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$1 = new Function1() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(EventModel eventModel) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                return invoke((EventModel) obj);
            }
        };
        LazyColumn.items(list.size(), null, new Function1<Integer, Object>() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                return screenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$1.invoke(list.get(i));
            }
        }, ComposableLambdaKt.composableLambdaInstance(802480018, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$ScreenFavorite$lambda$1$1$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope lazyItemScope, int i, Composer composer, int i2) {
                int i3;
                ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final EventModel eventModel = (EventModel) list.get(i);
                composer.startReplaceGroup(1468952056);
                ComposerKt.sourceInformation(composer, "CN(eventModel)*73@2952L96,70@2766L283:ScreenFavorite.kt#5m3rtf");
                boolean zContains = ScreenFavoriteKt.ScreenFavorite$lambda$0(state).contains(eventModel);
                ComposerKt.sourceInformationMarkerStart(composer, 1017222640, "CC(remember):ScreenFavorite.kt#9igjgp");
                boolean zChangedInstance = composer.changedInstance(mainViewModel) | composer.changed(eventModel);
                Object objRememberedValue = composer.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    final MainViewModel mainViewModel2 = mainViewModel;
                    objRememberedValue = (Function0) new Function0<Unit>() { // from class: com.nextfoot.ui.screens.ScreenFavoriteKt$ScreenFavorite$1$2$1$1$1$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            mainViewModel2.onFavorite(eventModel);
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                EventComponentKt.EventComponent(eventModel, zContains, (Function0) objRememberedValue, false, null, composer, 0, 24);
                composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }
}
