package com.nextfoot.ui.screens;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.ImageKt;
import androidx.compose.foundation.gestures.TapGestureDetectorKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.CornerBasedShape;
import androidx.compose.foundation.shape.CornerSizeKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.ZIndexModifierKt;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.input.pointer.AwaitPointerEventScope;
import androidx.compose.ui.input.pointer.PointerEvent;
import androidx.compose.ui.input.pointer.PointerEventKt;
import androidx.compose.ui.input.pointer.PointerInputChange;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.input.pointer.PointerInputScope;
import androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt;
import androidx.compose.ui.layout.ContentScale;
import androidx.compose.ui.layout.LayoutCoordinates;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.layout.OnGloballyPositionedModifierKt;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.PainterResources_androidKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.IntSize;
import androidx.core.location.LocationRequestCompat;
import androidx.navigation.NavHostController;
import com.nextfoot.R;
import com.nextfoot.ui.classes.BallState;
import com.nextfoot.ui.components.BallComponentKt;
import com.nextfoot.ui.components.FlyingBallComponentKt;
import com.nextfoot.ui.components.InfoComponentKt;
import com.nextfoot.ui.components.MissComponentKt;
import com.nextfoot.ui.components.ResultComponentKt;
import com.nextfoot.ui.components.ScoredComponentKt;
import com.nextfoot.viewmodel.MainViewModel;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.RestrictedSuspendLambda;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: ScreenGame.kt */
@Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a%\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0002\u0010\b¨\u0006\t²\u0006\n\u0010\n\u001a\u00020\u000bX\u008a\u0084\u0002²\u0006\n\u0010\f\u001a\u00020\u000bX\u008a\u0084\u0002²\u0006\n\u0010\r\u001a\u00020\u000eX\u008a\u0084\u0002²\u0006\n\u0010\u000f\u001a\u00020\u000eX\u008a\u0084\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u0084\u0002²\u0006\n\u0010\u0012\u001a\u00020\u000bX\u008a\u0084\u0002"}, d2 = {"ScreenGame", "", "paddingValues", "Landroidx/compose/foundation/layout/PaddingValues;", "viewModel", "Lcom/nextfoot/viewmodel/MainViewModel;", "navController", "Landroidx/navigation/NavHostController;", "(Landroidx/compose/foundation/layout/PaddingValues;Lcom/nextfoot/viewmodel/MainViewModel;Landroidx/navigation/NavHostController;Landroidx/compose/runtime/Composer;I)V", "app_release", "gameStarted", "", "gameOver", "gameScore", "", "gameTime", "ballState", "Lcom/nextfoot/ui/classes/BallState;", "isGoldenBall"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ScreenGameKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenGame$lambda$9(PaddingValues paddingValues, MainViewModel mainViewModel, NavHostController navHostController, int i, Composer composer, int i2) {
        ScreenGame(paddingValues, mainViewModel, navHostController, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void ScreenGame(final PaddingValues paddingValues, final MainViewModel mainViewModel, final NavHostController navController, Composer composer, final int i) {
        int i2;
        final MutableState mutableState;
        final MainViewModel viewModel = mainViewModel;
        Intrinsics.checkNotNullParameter(paddingValues, "paddingValues");
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(navController, "navController");
        Composer composerStartRestartGroup = composer.startRestartGroup(1402330110);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ScreenGame)N(paddingValues,viewModel,navController)58@2464L16,59@2520L16,60@2578L16,61@2634L16,62@2692L16,63@2756L16,64@2801L53,65@2880L37,65@2859L58,68@2922L11753:ScreenGame.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(paddingValues) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(viewModel) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(navController) ? 256 : 128;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 147) != 146, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1402330110, i2, -1, "com.nextfoot.ui.screens.ScreenGame (ScreenGame.kt:57)");
            }
            State stateCollectAsState = SnapshotStateKt.collectAsState(viewModel.getGameStarted(), null, composerStartRestartGroup, 0, 1);
            final State stateCollectAsState2 = SnapshotStateKt.collectAsState(viewModel.getGameOver(), null, composerStartRestartGroup, 0, 1);
            State stateCollectAsState3 = SnapshotStateKt.collectAsState(viewModel.getGameScore(), null, composerStartRestartGroup, 0, 1);
            State stateCollectAsState4 = SnapshotStateKt.collectAsState(viewModel.getGameTime(), null, composerStartRestartGroup, 0, 1);
            final State stateCollectAsState5 = SnapshotStateKt.collectAsState(viewModel.getBallState(), null, composerStartRestartGroup, 0, 1);
            State stateCollectAsState6 = SnapshotStateKt.collectAsState(viewModel.isGoldenBall(), null, composerStartRestartGroup, 0, 1);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -980479053, "CC(remember):ScreenGame.kt#9igjgp");
            Object objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            MutableState mutableState2 = (MutableState) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            Unit unit = Unit.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -980476541, "CC(remember):ScreenGame.kt#9igjgp");
            boolean zChangedInstance = composerStartRestartGroup.changedInstance(viewModel);
            ScreenGameKt$ScreenGame$1$1 screenGameKt$ScreenGame$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (zChangedInstance || screenGameKt$ScreenGame$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                screenGameKt$ScreenGame$1$1RememberedValue = new ScreenGameKt$ScreenGame$1$1(viewModel, null);
                composerStartRestartGroup.updateRememberedValue(screenGameKt$ScreenGame$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            EffectsKt.LaunchedEffect(unit, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) screenGameKt$ScreenGame$1$1RememberedValue, composerStartRestartGroup, 6);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                composerM4565constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
                composerM4565constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
            }
            Updater.m4572setimpl(composerM4565constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 39022697, "C73@3122L11,69@2939L248,80@3346L11,76@3196L2024,129@5229L9440:ScreenGame.kt#5m3rtf");
            SpacerKt.Spacer(ZIndexModifierKt.zIndex(BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), paddingValues.getTop()), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null), 2.0f), composerStartRestartGroup, 0);
            float f = 90;
            Modifier modifierZIndex = ZIndexModifierKt.zIndex(BackgroundKt.m269backgroundbw27NRU$default(SizeKt.m882height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m7962constructorimpl(f)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getSurfaceVariant(), null, 2, null), 2.0f);
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, composerStartRestartGroup, 48);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierZIndex);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor2);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl2 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                composerM4565constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
                composerM4565constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
            }
            Updater.m4572setimpl(composerM4565constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -550294109, "C84@3486L40,85@3560L58,85@3539L312,96@3939L10,97@4004L11,94@3864L331,107@4365L6,108@4434L11,103@4208L1002:ScreenGame.kt#5m3rtf");
            float f2 = 16;
            SpacerKt.Spacer(SizeKt.m901width3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(f2)), composerStartRestartGroup, 6);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1126129378, "CC(remember):ScreenGame.kt#9igjgp");
            boolean zChangedInstance2 = composerStartRestartGroup.changedInstance(navController);
            Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
            if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new Function0() { // from class: com.nextfoot.ui.screens.ScreenGameKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ScreenGameKt.ScreenGame$lambda$8$0$0$0(navController);
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            IconButtonKt.IconButton((Function0) objRememberedValue2, null, false, null, null, null, ComposableSingletons$ScreenGameKt.INSTANCE.m8560getLambda$150686586$app_release(), composerStartRestartGroup, 1572864, 62);
            TextKt.m3170TextNvy7gAk("Игра", RowScope.weight$default(rowScopeInstance, SizeKt.fillMaxWidth$default(PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, Dp.m7962constructorimpl(f2), 0.0f, 0.0f, 0.0f, 14, null), 0.0f, 1, null), 1.0f, false, 2, null), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getHeadlineMedium(), composerStartRestartGroup, 6, 0, 131064);
            Modifier modifierM269backgroundbw27NRU$default = BackgroundKt.m269backgroundbw27NRU$default(ClipKt.clip(SizeKt.m901width3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, Dp.m7962constructorimpl(30), 0.0f, 11, null), Dp.m7962constructorimpl(f)), MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getMedium()), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getBackground(), null, 2, null);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap3 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM269backgroundbw27NRU$default);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor3);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl3 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                composerM4565constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
                composerM4565constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
            }
            Updater.m4572setimpl(composerM4565constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -349285948, "C111@4518L38,110@4491L309,120@4914L10,121@4979L11,118@4817L379:ScreenGame.kt#5m3rtf");
            ImageKt.Image(PainterResources_androidKt.painterResource(R.drawable.image_ball, composerStartRestartGroup, 0), (String) null, SizeKt.m896size3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(boxScopeInstance.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenterStart()), Dp.m7962constructorimpl(8), 0.0f, 0.0f, 0.0f, 14, null), Dp.m7962constructorimpl(12)), (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, composerStartRestartGroup, 48, 120);
            TextKt.m3170TextNvy7gAk(String.valueOf(ScreenGame$lambda$2(stateCollectAsState3)), SizeKt.fillMaxWidth$default(boxScopeInstance.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), 0.0f, 1, null), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, TextAlign.m7839boximpl(TextAlign.INSTANCE.m7846getCentere0LSkKk()), 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getTitleSmall(), composerStartRestartGroup, 0, 0, 130040);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            Modifier.Companion companion2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode4 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap4 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion2);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor4);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl4 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl4, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl4.rememberedValue(), Integer.valueOf(iHashCode4))) {
                composerM4565constructorimpl4.updateRememberedValue(Integer.valueOf(iHashCode4));
                composerM4565constructorimpl4.apply(Integer.valueOf(iHashCode4), setCompositeKeyHash4);
            }
            Updater.m4572setimpl(composerM4565constructorimpl4, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1986039363, "C131@5280L39,130@5247L251,137@5511L9148:ScreenGame.kt#5m3rtf");
            ImageKt.Image(PainterResources_androidKt.painterResource(R.drawable.image_field, composerStartRestartGroup, 0), (String) null, SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), (Alignment) null, ContentScale.INSTANCE.getCrop(), 0.0f, (ColorFilter) null, composerStartRestartGroup, 25008, LocationRequestCompat.QUALITY_LOW_POWER);
            Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(PaddingKt.m848paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, 0.0f, paddingValues.getBottom(), 7, null), 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode5 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap5 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxSize$default);
            Function0<ComposeUiNode> constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor5);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl5 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl5, measurePolicyMaybeCachedBoxMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl5, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl5.rememberedValue(), Integer.valueOf(iHashCode5))) {
                composerM4565constructorimpl5.updateRememberedValue(Integer.valueOf(iHashCode5));
                composerM4565constructorimpl5.apply(Integer.valueOf(iHashCode5), setCompositeKeyHash5);
            }
            Updater.m4572setimpl(composerM4565constructorimpl5, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance3 = BoxScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1785013997, "C147@5906L6,151@6131L11,142@5697L1632:ScreenGame.kt#5m3rtf");
            float f3 = 0;
            Modifier modifierZIndex2 = ZIndexModifierKt.zIndex(PaddingKt.m848paddingqDBjuR0$default(PaddingKt.m846paddingVpY3zN4$default(BackgroundKt.m269backgroundbw27NRU$default(ClipKt.clip(SizeKt.m901width3ABfNKs(boxScopeInstance3.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopCenter()), Dp.m7962constructorimpl(140)), CornerBasedShape.copy$default(MaterialTheme.INSTANCE.getShapes(composerStartRestartGroup, MaterialTheme.$stable).getExtraLarge(), CornerSizeKt.m1201CornerSize0680j_4(Dp.m7962constructorimpl(f3)), CornerSizeKt.m1201CornerSize0680j_4(Dp.m7962constructorimpl(f3)), null, null, 12, null)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getPrimary(), null, 2, null), Dp.m7962constructorimpl(20), 0.0f, 2, null), 0.0f, 0.0f, 0.0f, Dp.m7962constructorimpl(2), 7, null), 2.0f);
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.HorizontalOrVertical spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(spaceBetween, centerVertically2, composerStartRestartGroup, 54);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int iHashCode6 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap6 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierZIndex2);
            Function0<ComposeUiNode> constructor6 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor6);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4565constructorimpl6 = Updater.m4565constructorimpl(composerStartRestartGroup);
            Updater.m4572setimpl(composerM4565constructorimpl6, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4572setimpl(composerM4565constructorimpl6, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM4565constructorimpl6.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl6.rememberedValue(), Integer.valueOf(iHashCode6))) {
                composerM4565constructorimpl6.updateRememberedValue(Integer.valueOf(iHashCode6));
                composerM4565constructorimpl6.apply(Integer.valueOf(iHashCode6), setCompositeKeyHash6);
            }
            Updater.m4572setimpl(composerM4565constructorimpl6, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -732160353, "C159@6497L38,161@6633L11,158@6467L266,166@6858L10,167@6926L11,164@6754L270,171@7075L38,173@7211L11,170@7045L266:ScreenGame.kt#5m3rtf");
            IconKt.m2463Iconww6aTOc(PainterResources_androidKt.painterResource(R.drawable.icon_timer, composerStartRestartGroup, 0), (String) null, SizeKt.m896size3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(f2)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary(), composerStartRestartGroup, 432, 0);
            TextKt.m3170TextNvy7gAk(String.valueOf(ScreenGame$lambda$3(stateCollectAsState4)), null, MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary(), null, 0L, null, null, null, 0L, null, TextAlign.m7839boximpl(TextAlign.INSTANCE.m7846getCentere0LSkKk()), 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, MaterialTheme.$stable).getBodyLarge(), composerStartRestartGroup, 0, 0, 130042);
            IconKt.m2463Iconww6aTOc(PainterResources_androidKt.painterResource(R.drawable.icon_timer, composerStartRestartGroup, 0), (String) null, SizeKt.m896size3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(f2)), MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, MaterialTheme.$stable).getOnPrimary(), composerStartRestartGroup, 432, 0);
            composerStartRestartGroup = composerStartRestartGroup;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ScreenGame$lambda$0(stateCollectAsState)) {
                composerStartRestartGroup.startReplaceGroup(-1783422055);
                ComposerKt.sourceInformation(composerStartRestartGroup, "181@7540L3656,231@11247L116,178@7385L6949");
                Modifier modifierFillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                Boolean boolValueOf = Boolean.valueOf(ScreenGame$lambda$1(stateCollectAsState2));
                BallState ballStateScreenGame$lambda$4 = ScreenGame$lambda$4(stateCollectAsState5);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773756580, "CC(remember):ScreenGame.kt#9igjgp");
                boolean zChanged = composerStartRestartGroup.changed(stateCollectAsState2) | composerStartRestartGroup.changed(stateCollectAsState5) | composerStartRestartGroup.changedInstance(mainViewModel);
                PointerInputEventHandler pointerInputEventHandlerRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChanged || pointerInputEventHandlerRememberedValue == Composer.INSTANCE.getEmpty()) {
                    pointerInputEventHandlerRememberedValue = new PointerInputEventHandler() { // from class: com.nextfoot.ui.screens.ScreenGameKt$ScreenGame$2$2$1$2$1

                        /* compiled from: ScreenGame.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.nextfoot.ui.screens.ScreenGameKt$ScreenGame$2$2$1$2$1$1", f = "ScreenGame.kt", i = {0, 1, 1, 1, 1, 1, 1}, l = {186, 192}, m = "invokeSuspend", n = {"$this$awaitPointerEventScope", "$this$awaitPointerEventScope", "down", "startPosition", "lastPosition", "hasMoved", "minSwipeDistance"}, s = {"L$0", "L$0", "L$1", "J$0", "J$1", "I$0", "F$0"}, v = 1)
                        /* renamed from: com.nextfoot.ui.screens.ScreenGameKt$ScreenGame$2$2$1$2$1$1, reason: invalid class name */
                        static final class AnonymousClass1 extends RestrictedSuspendLambda implements Function2<AwaitPointerEventScope, Continuation<? super Unit>, Object> {
                            final /* synthetic */ MainViewModel $viewModel;
                            float F$0;
                            int I$0;
                            long J$0;
                            long J$1;
                            private /* synthetic */ Object L$0;
                            Object L$1;
                            int label;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            AnonymousClass1(MainViewModel mainViewModel, Continuation<? super AnonymousClass1> continuation) {
                                super(2, continuation);
                                this.$viewModel = mainViewModel;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.$viewModel, continuation);
                                anonymousClass1.L$0 = obj;
                                return anonymousClass1;
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(AwaitPointerEventScope awaitPointerEventScope, Continuation<? super Unit> continuation) {
                                return ((AnonymousClass1) create(awaitPointerEventScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            /* JADX WARN: Code restructure failed: missing block: B:12:0x0044, code lost:
                            
                                if (r15 != r0) goto L14;
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:16:0x006e, code lost:
                            
                                if (r15 != r0) goto L18;
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:17:0x0070, code lost:
                            
                                return r0;
                             */
                            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x006e -> B:18:0x0071). Please report as a decompilation issue!!! */
                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            /*
                                Code decompiled incorrectly, please refer to instructions dump.
                            */
                            public final Object invokeSuspend(Object obj) {
                                long position;
                                PointerInputChange pointerInputChange;
                                long position2;
                                int i;
                                float f;
                                AwaitPointerEventScope awaitPointerEventScope = (AwaitPointerEventScope) this.L$0;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                int i2 = this.label;
                                if (i2 == 0) {
                                    ResultKt.throwOnFailure(obj);
                                    this.L$0 = awaitPointerEventScope;
                                    this.L$1 = null;
                                    this.label = 1;
                                    obj = TapGestureDetectorKt.awaitFirstDown$default(awaitPointerEventScope, false, null, this, 2, null);
                                } else if (i2 == 1) {
                                    ResultKt.throwOnFailure(obj);
                                    PointerInputChange pointerInputChange2 = (PointerInputChange) obj;
                                    pointerInputChange = pointerInputChange2;
                                    position = pointerInputChange2.getPosition();
                                    i = 0;
                                    f = 30.0f;
                                    position2 = position;
                                    this.L$0 = awaitPointerEventScope;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(pointerInputChange);
                                    this.J$0 = position;
                                    this.J$1 = position2;
                                    this.I$0 = i;
                                    this.F$0 = f;
                                    this.label = 2;
                                    obj = AwaitPointerEventScope.awaitPointerEvent$default(awaitPointerEventScope, null, this, 1, null);
                                } else {
                                    if (i2 != 2) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    f = this.F$0;
                                    i = this.I$0;
                                    position2 = this.J$1;
                                    position = this.J$0;
                                    pointerInputChange = (PointerInputChange) this.L$1;
                                    ResultKt.throwOnFailure(obj);
                                    PointerInputChange pointerInputChange3 = (PointerInputChange) CollectionsKt.firstOrNull((List) ((PointerEvent) obj).getChanges());
                                    if (pointerInputChange3 != null) {
                                        if (PointerEventKt.positionChanged(pointerInputChange3)) {
                                            position2 = pointerInputChange3.getPosition();
                                            if (Offset.m5000getDistanceimpl(Offset.m5006minusMKHz9U(position2, position)) > f) {
                                                i = 1;
                                            }
                                        }
                                        if (!pointerInputChange3.getPressed()) {
                                            if (i != 0) {
                                                long jM5006minusMKHz9U = Offset.m5006minusMKHz9U(position2, position);
                                                float fMin = Math.min(Offset.m5000getDistanceimpl(jM5006minusMKHz9U) / 800.0f, 1.2f) * 1200.0f;
                                                float fMo6445getSizeYbymL2g = ((int) (awaitPointerEventScope.mo6445getSizeYbymL2g() >> 32)) / 2.0f;
                                                float fMo6445getSizeYbymL2g2 = (((int) (awaitPointerEventScope.mo6445getSizeYbymL2g() & 4294967295L)) - 72.0f) - 36.0f;
                                                float fSqrt = (float) Math.sqrt((r10 * r10) + (r11 * r11));
                                                this.$viewModel.throwBall(fMo6445getSizeYbymL2g + (((540.0f - fMo6445getSizeYbymL2g) / fSqrt) * fMin) + Float.intBitsToFloat((int) (jM5006minusMKHz9U >> 32)), fMo6445getSizeYbymL2g2 + (((400.0f - fMo6445getSizeYbymL2g2) / fSqrt) * fMin));
                                            }
                                        }
                                        this.L$0 = awaitPointerEventScope;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(pointerInputChange);
                                        this.J$0 = position;
                                        this.J$1 = position2;
                                        this.I$0 = i;
                                        this.F$0 = f;
                                        this.label = 2;
                                        obj = AwaitPointerEventScope.awaitPointerEvent$default(awaitPointerEventScope, null, this, 1, null);
                                    }
                                    this.L$0 = awaitPointerEventScope;
                                    this.L$1 = null;
                                    this.label = 1;
                                    obj = TapGestureDetectorKt.awaitFirstDown$default(awaitPointerEventScope, false, null, this, 2, null);
                                }
                            }
                        }

                        @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
                        public final Object invoke(PointerInputScope pointerInputScope, Continuation<? super Unit> continuation) {
                            if (ScreenGameKt.ScreenGame$lambda$1(stateCollectAsState2) || !(ScreenGameKt.ScreenGame$lambda$4(stateCollectAsState5) instanceof BallState.Idle)) {
                                return Unit.INSTANCE;
                            }
                            Object objAwaitPointerEventScope = pointerInputScope.awaitPointerEventScope(new AnonymousClass1(mainViewModel, null), continuation);
                            return objAwaitPointerEventScope == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objAwaitPointerEventScope : Unit.INSTANCE;
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(pointerInputEventHandlerRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Modifier modifierPointerInput = SuspendingPointerInputFilterKt.pointerInput(modifierFillMaxSize$default2, boolValueOf, ballStateScreenGame$lambda$4, (PointerInputEventHandler) pointerInputEventHandlerRememberedValue);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773871664, "CC(remember):ScreenGame.kt#9igjgp");
                Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    mutableState = mutableState2;
                    objRememberedValue3 = new Function1() { // from class: com.nextfoot.ui.screens.ScreenGameKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return ScreenGameKt.ScreenGame$lambda$8$1$0$2$0(mutableState, (LayoutCoordinates) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                } else {
                    mutableState = mutableState2;
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Modifier modifierOnGloballyPositioned = OnGloballyPositionedModifierKt.onGloballyPositioned(modifierPointerInput, (Function1) objRememberedValue3);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy4 = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
                int iHashCode7 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                CompositionLocalMap currentCompositionLocalMap7 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierOnGloballyPositioned);
                Function0<ComposeUiNode> constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor7);
                } else {
                    composerStartRestartGroup.useNode();
                }
                Composer composerM4565constructorimpl7 = Updater.m4565constructorimpl(composerStartRestartGroup);
                Updater.m4572setimpl(composerM4565constructorimpl7, measurePolicyMaybeCachedBoxMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m4572setimpl(composerM4565constructorimpl7, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM4565constructorimpl7.getInserting() || !Intrinsics.areEqual(composerM4565constructorimpl7.rememberedValue(), Integer.valueOf(iHashCode7))) {
                    composerM4565constructorimpl7.updateRememberedValue(Integer.valueOf(iHashCode7));
                    composerM4565constructorimpl7.apply(Integer.valueOf(iHashCode7), setCompositeKeyHash7);
                }
                Updater.m4572setimpl(composerM4565constructorimpl7, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance4 = BoxScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1974298924, "C236@11457L39,235@11412L423,245@11905L39,244@11860L429:ScreenGame.kt#5m3rtf");
                float f4 = 92;
                MutableState mutableState3 = mutableState;
                viewModel = mainViewModel;
                ImageKt.Image(PainterResources_androidKt.painterResource(R.drawable.icon_shield, composerStartRestartGroup, 0), (String) null, SizeKt.m882height3ABfNKs(SizeKt.m901width3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(boxScopeInstance4.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopCenter()), 0.0f, Dp.m7962constructorimpl(f4), 0.0f, 0.0f, 13, null), Dp.m7962constructorimpl(162)), Dp.m7962constructorimpl(106)), (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, composerStartRestartGroup, 48, 120);
                float f5 = 74;
                ImageKt.Image(PainterResources_androidKt.painterResource(R.drawable.icon_basket, composerStartRestartGroup, 0), (String) null, SizeKt.m882height3ABfNKs(SizeKt.m901width3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(boxScopeInstance4.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopCenter()), 0.0f, Dp.m7962constructorimpl(Dp.m7962constructorimpl(f4) + Dp.m7962constructorimpl(f5)), 0.0f, 0.0f, 13, null), Dp.m7962constructorimpl(82)), Dp.m7962constructorimpl(f5)), (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, composerStartRestartGroup, 48, 120);
                BallState ballStateScreenGame$lambda$42 = ScreenGame$lambda$4(stateCollectAsState5);
                if (ballStateScreenGame$lambda$42 instanceof BallState.Idle) {
                    composerStartRestartGroup.startReplaceGroup(-1973355998);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "255@12439L453");
                    BallComponentKt.BallComponent(SizeKt.m896size3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(boxScopeInstance4.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomCenter()), 0.0f, 0.0f, 0.0f, Dp.m7962constructorimpl(36), 7, null), Dp.m7962constructorimpl(72)), ScreenGame$lambda$5(stateCollectAsState6), 0.0f, 1.0f, composerStartRestartGroup, 3456, 0);
                    composerStartRestartGroup.endReplaceGroup();
                } else if (ballStateScreenGame$lambda$42 instanceof BallState.Flying) {
                    composerStartRestartGroup.startReplaceGroup(-1972805748);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "");
                    LayoutCoordinates layoutCoordinates = (LayoutCoordinates) mutableState3.getValue();
                    IntSize intSizeM8125boximpl = layoutCoordinates != null ? IntSize.m8125boximpl(layoutCoordinates.mo6672getSizeYbymL2g()) : null;
                    if (intSizeM8125boximpl != null) {
                        composerStartRestartGroup.startReplaceGroup(-1972698240);
                        ComposerKt.sourceInformation(composerStartRestartGroup, "269@13144L255");
                        FlyingBallComponentKt.m8552FlyingBallComponentjw68sR4((BallState.Flying) ballStateScreenGame$lambda$42, ScreenGame$lambda$5(stateCollectAsState6), intSizeM8125boximpl.m8137unboximpl(), composerStartRestartGroup, 0);
                        composerStartRestartGroup.endReplaceGroup();
                    } else {
                        composerStartRestartGroup.startReplaceGroup(-1972325310);
                        ComposerKt.sourceInformation(composerStartRestartGroup, "275@13477L485");
                        BallComponentKt.BallComponent(SizeKt.m896size3ABfNKs(PaddingKt.m848paddingqDBjuR0$default(boxScopeInstance4.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomCenter()), 0.0f, 0.0f, 0.0f, Dp.m7962constructorimpl(36), 7, null), Dp.m7962constructorimpl(72)), ScreenGame$lambda$5(stateCollectAsState6), 0.0f, 1.0f, composerStartRestartGroup, 3456, 0);
                        composerStartRestartGroup.endReplaceGroup();
                    }
                    composerStartRestartGroup.endReplaceGroup();
                } else if (Intrinsics.areEqual(ballStateScreenGame$lambda$42, BallState.Missed.INSTANCE)) {
                    composerStartRestartGroup.startReplaceGroup(-1971743688);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "288@14110L15");
                    MissComponentKt.MissComponent(composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    if (!Intrinsics.areEqual(ballStateScreenGame$lambda$42, BallState.Scored.INSTANCE)) {
                        composerStartRestartGroup.startReplaceGroup(1183266889);
                        composerStartRestartGroup.endReplaceGroup();
                        throw new NoWhenBranchMatchedException();
                    }
                    composerStartRestartGroup.startReplaceGroup(-1971615658);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "292@14239L17");
                    ScoredComponentKt.ScoredComponent(composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endReplaceGroup();
            } else {
                viewModel = mainViewModel;
                if (ScreenGame$lambda$1(stateCollectAsState2)) {
                    composerStartRestartGroup.startReplaceGroup(-1776681322);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "297@14429L69,297@14394L104");
                    int iScreenGame$lambda$2 = ScreenGame$lambda$2(stateCollectAsState3);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773973441, "CC(remember):ScreenGame.kt#9igjgp");
                    boolean zChangedInstance3 = composerStartRestartGroup.changedInstance(viewModel);
                    Object objRememberedValue4 = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance3 || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue4 = new Function0() { // from class: com.nextfoot.ui.screens.ScreenGameKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ScreenGameKt.ScreenGame$lambda$8$1$0$4$0(viewModel);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue4);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ResultComponentKt.ResultComponent(iScreenGame$lambda$2, (Function0) objRememberedValue4, composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-1776533173);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "301@14558L69,301@14544L83");
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773977569, "CC(remember):ScreenGame.kt#9igjgp");
                    boolean zChangedInstance4 = composerStartRestartGroup.changedInstance(viewModel);
                    Object objRememberedValue5 = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance4 || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue5 = new Function0() { // from class: com.nextfoot.ui.screens.ScreenGameKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ScreenGameKt.ScreenGame$lambda$8$1$0$5$0(viewModel);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue5);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    InfoComponentKt.InfoComponent((Function0) objRememberedValue5, composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                }
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.screens.ScreenGameKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ScreenGameKt.ScreenGame$lambda$9(paddingValues, viewModel, navController, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenGame$lambda$8$0$0$0(NavHostController navHostController) {
        navHostController.navigateUp();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenGame$lambda$8$1$0$2$0(MutableState mutableState, LayoutCoordinates coordinates) {
        Intrinsics.checkNotNullParameter(coordinates, "coordinates");
        mutableState.setValue(coordinates);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenGame$lambda$8$1$0$4$0(MainViewModel mainViewModel) {
        mainViewModel.resetGame();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenGame$lambda$8$1$0$5$0(MainViewModel mainViewModel) {
        mainViewModel.startGame();
        return Unit.INSTANCE;
    }

    private static final boolean ScreenGame$lambda$0(State<Boolean> state) {
        return state.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean ScreenGame$lambda$1(State<Boolean> state) {
        return state.getValue().booleanValue();
    }

    private static final int ScreenGame$lambda$2(State<Integer> state) {
        return state.getValue().intValue();
    }

    private static final int ScreenGame$lambda$3(State<Integer> state) {
        return state.getValue().intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final BallState ScreenGame$lambda$4(State<? extends BallState> state) {
        return state.getValue();
    }

    private static final boolean ScreenGame$lambda$5(State<Boolean> state) {
        return state.getValue().booleanValue();
    }
}
