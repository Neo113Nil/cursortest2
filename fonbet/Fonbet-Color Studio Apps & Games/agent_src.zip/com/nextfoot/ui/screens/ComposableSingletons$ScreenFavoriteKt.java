package com.nextfoot.ui.screens;

import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ScreenFavorite.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ScreenFavoriteKt {
    public static final ComposableSingletons$ScreenFavoriteKt INSTANCE = new ComposableSingletons$ScreenFavoriteKt();

    /* renamed from: lambda$-1682258949, reason: not valid java name */
    private static Function3<ColumnScope, Composer, Integer, Unit> f48lambda$1682258949 = ComposableLambdaKt.composableLambdaInstance(-1682258949, false, new Function3() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenFavoriteKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ScreenFavoriteKt.lambda__1682258949$lambda$0((ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1682258949$app_release, reason: not valid java name */
    public final Function3<ColumnScope, Composer, Integer, Unit> m8558getLambda$1682258949$app_release() {
        return f48lambda$1682258949;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__1682258949$lambda$0(ColumnScope Card, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation(composer, "C95@3954L10,93@3787L416:ScreenFavorite.kt#5m3rtf");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1682258949, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenFavoriteKt.lambda$-1682258949.<anonymous> (ScreenFavorite.kt:93)");
            }
            TextKt.m3170TextNvy7gAk("Ваш список избранного пуст.\nМожете добавить сюда события из расписания.", SizeKt.fillMaxWidth$default(PaddingKt.m844padding3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(12)), 0.0f, 1, null), 0L, null, 0L, null, null, null, 0L, null, TextAlign.m7839boximpl(TextAlign.INSTANCE.m7846getCentere0LSkKk()), 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer, 54, 0, 130044);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
