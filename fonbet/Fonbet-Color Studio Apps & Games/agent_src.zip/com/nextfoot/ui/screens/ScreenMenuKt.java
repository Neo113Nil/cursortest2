package com.nextfoot.ui.screens;

import androidx.compose.animation.AnimatedContentScope;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.shape.CornerBasedShape;
import androidx.compose.foundation.shape.CornerSizeKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.NavigationBarItemColors;
import androidx.compose.material3.NavigationBarItemDefaults;
import androidx.compose.material3.NavigationBarKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.res.PainterResources_androidKt;
import androidx.compose.ui.unit.Dp;
import androidx.core.view.PointerIconCompat;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.NavGraph;
import androidx.navigation.NavGraphBuilder;
import androidx.navigation.NavHostController;
import androidx.navigation.NavOptionsBuilder;
import androidx.navigation.Navigator;
import androidx.navigation.PopUpToBuilder;
import androidx.navigation.compose.NavGraphBuilderKt;
import androidx.navigation.compose.NavHostControllerKt;
import androidx.navigation.compose.NavHostKt;
import com.nextfoot.ui.classes.Screen;
import com.nextfoot.viewmodel.MainViewModel;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: ScreenMenu.kt */
@Metadata(d1 = {"\u0000\u001a\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\u001a\u001d\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007²\u0006\n\u0010\b\u001a\u00020\tX\u008a\u008e\u0002"}, d2 = {"ScreenMenu", "", "viewModel", "Lcom/nextfoot/viewmodel/MainViewModel;", "navController", "Landroidx/navigation/NavHostController;", "(Lcom/nextfoot/viewmodel/MainViewModel;Landroidx/navigation/NavHostController;Landroidx/compose/runtime/Composer;I)V", "app_release", "currentScreen", "Lcom/nextfoot/ui/classes/Screen;"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ScreenMenuKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$6(MainViewModel mainViewModel, NavHostController navHostController, int i, Composer composer, int i2) {
        ScreenMenu(mainViewModel, navHostController, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void ScreenMenu(final MainViewModel viewModel, final NavHostController navController, Composer composer, final int i) {
        int i2;
        Composer composer2;
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(navController, "navController");
        Composer composerStartRestartGroup = composer.startRestartGroup(810144279);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ScreenMenu)N(viewModel,navController)37@1491L23,45@1692L55,48@1786L256,48@1752L290,56@2077L2848,110@4927L1397,55@2047L4277:ScreenMenu.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changedInstance(viewModel) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(navController) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(810144279, i2, -1, "com.nextfoot.ui.screens.ScreenMenu (ScreenMenu.kt:36)");
            }
            final NavHostController navHostControllerRememberNavController = NavHostControllerKt.rememberNavController(new Navigator[0], composerStartRestartGroup, 0);
            final List listListOf = CollectionsKt.listOf((Object[]) new Screen[]{Screen.Schedule.INSTANCE, Screen.Favorite.INSTANCE, Screen.Bets.INSTANCE, Screen.Profile.INSTANCE, Screen.Menu.INSTANCE});
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1159581742, "CC(remember):ScreenMenu.kt#9igjgp");
            Object objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(listListOf.get(0), null, 2, null);
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            final MutableState mutableState = (MutableState) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1159584951, "CC(remember):ScreenMenu.kt#9igjgp");
            boolean zChangedInstance = composerStartRestartGroup.changedInstance(navHostControllerRememberNavController);
            ScreenMenuKt$ScreenMenu$1$1 screenMenuKt$ScreenMenu$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (zChangedInstance || screenMenuKt$ScreenMenu$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                screenMenuKt$ScreenMenu$1$1RememberedValue = new ScreenMenuKt$ScreenMenu$1$1(navHostControllerRememberNavController, listListOf, mutableState, null);
                composerStartRestartGroup.updateRememberedValue(screenMenuKt$ScreenMenu$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            EffectsKt.LaunchedEffect(navHostControllerRememberNavController, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) screenMenuKt$ScreenMenu$1$1RememberedValue, composerStartRestartGroup, 0);
            composer2 = composerStartRestartGroup;
            ScaffoldKt.m2787ScaffoldTvnljyQ(null, null, ComposableLambdaKt.rememberComposableLambda(-449760270, true, new Function2() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ScreenMenuKt.ScreenMenu$lambda$4(listListOf, navHostControllerRememberNavController, mutableState, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(-1384082328, true, new Function3() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return ScreenMenuKt.ScreenMenu$lambda$5(navHostControllerRememberNavController, viewModel, navController, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composer2, 805306752, 507);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ScreenMenuKt.ScreenMenu$lambda$6(viewModel, navController, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final Screen ScreenMenu$lambda$1(MutableState<Screen> mutableState) {
        return mutableState.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4(final List list, final NavHostController navHostController, final MutableState mutableState, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C60@2208L6,64@2427L11,64@2385L69,65@2470L2445,57@2091L2824:ScreenMenu.kt#5m3rtf");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-449760270, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous> (ScreenMenu.kt:57)");
            }
            float f = 0;
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CornerBasedShape.copy$default(MaterialTheme.INSTANCE.getShapes(composer, MaterialTheme.$stable).getLarge(), null, null, CornerSizeKt.m1201CornerSize0680j_4(Dp.m7962constructorimpl(f)), CornerSizeKt.m1201CornerSize0680j_4(Dp.m7962constructorimpl(f)), 3, null), CardDefaults.INSTANCE.m1997cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getSurfaceVariant(), 0L, 0L, 0L, composer, CardDefaults.$stable << 12, 14), null, null, ComposableLambdaKt.rememberComposableLambda(-1069629632, true, new Function3() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda14
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return ScreenMenuKt.ScreenMenu$lambda$4$0(list, navHostController, mutableState, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer, 54), composer, 196614, 24);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0(final List list, final NavHostController navHostController, final MutableState mutableState, ColumnScope Card, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation(composer, "C68@2577L2324,66@2488L2413:ScreenMenu.kt#5m3rtf");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1069629632, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous> (ScreenMenu.kt:66)");
            }
            NavigationBarKt.m2606NavigationBarHsRjFd4(null, Color.INSTANCE.m5281getTransparent0d7_KjU(), 0L, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1933654023, true, new Function3() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda15
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return ScreenMenuKt.ScreenMenu$lambda$4$0$0(list, navHostController, mutableState, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer, 54), composer, 196656, 29);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0(List list, final NavHostController navHostController, final MutableState mutableState, RowScope NavigationBar, Composer composer, int i) {
        int i2;
        long onSurfaceVariant;
        long jM5245copywmQWz5c$default;
        Composer composer2 = composer;
        Intrinsics.checkNotNullParameter(NavigationBar, "$this$NavigationBar");
        ComposerKt.sourceInformation(composer2, "C*87@3671L11,91@4022L11,85@3435L802,96@4277L583,78@3051L319,72@2774L240,70@2655L2206:ScreenMenu.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = i | (composer2.changed(NavigationBar) ? 4 : 2);
        } else {
            i2 = i;
        }
        boolean z = true;
        if (!composer2.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1933654023, i2, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:69)");
            }
            Iterator it = list.iterator();
            while (it.hasNext()) {
                final Screen screen = (Screen) it.next();
                boolean zAreEqual = Intrinsics.areEqual(ScreenMenu$lambda$1(mutableState), screen);
                int i3 = i2;
                NavigationBarItemDefaults navigationBarItemDefaults = NavigationBarItemDefaults.INSTANCE;
                if (Intrinsics.areEqual(screen, Screen.Bets.INSTANCE)) {
                    composer2.startReplaceGroup(-1506576235);
                    ComposerKt.sourceInformation(composer2, "86@3536L11");
                    onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getPrimary();
                } else {
                    composer2.startReplaceGroup(-1506574978);
                    ComposerKt.sourceInformation(composer2, "86@3575L11");
                    onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant();
                }
                composer2.endReplaceGroup();
                long onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant();
                if (Intrinsics.areEqual(screen, Screen.Bets.INSTANCE)) {
                    composer2.startReplaceGroup(-1506567915);
                    ComposerKt.sourceInformation(composer2, "88@3796L11");
                    jM5245copywmQWz5c$default = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getPrimary();
                } else {
                    composer2.startReplaceGroup(-1506566042);
                    ComposerKt.sourceInformation(composer2, "88@3835L11");
                    jM5245copywmQWz5c$default = Color.m5245copywmQWz5c$default(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null);
                }
                composer2.endReplaceGroup();
                NavigationBarItemColors navigationBarItemColorsM2601colors69fazGs = navigationBarItemDefaults.m2601colors69fazGs(onSurfaceVariant, onSurfaceVariant2, Color.INSTANCE.m5281getTransparent0d7_KjU(), jM5245copywmQWz5c$default, Color.m5245copywmQWz5c$default(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null), 0L, 0L, composer, (NavigationBarItemDefaults.$stable << 21) | 384, 96);
                ComposerKt.sourceInformationMarkerStart(composer, -1506552331, "CC(remember):ScreenMenu.kt#9igjgp");
                boolean zChanged = composer.changed(screen) | composer.changedInstance(navHostController);
                Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return ScreenMenuKt.ScreenMenu$lambda$4$0$0$0$0$0(screen, navHostController, mutableState);
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                NavigationBarKt.NavigationBarItem(NavigationBar, zAreEqual, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1431612115, true, new Function2() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ScreenMenuKt.ScreenMenu$lambda$4$0$0$0$1(screen, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer, 54), null, false, ComposableLambdaKt.rememberComposableLambda(-1057334864, true, new Function2() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ScreenMenuKt.ScreenMenu$lambda$4$0$0$0$2(screen, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer, 54), false, navigationBarItemColorsM2601colors69fazGs, null, composer, (i3 & 14) | 1575936, 344);
                composer2 = composer;
                z = true;
                i2 = i3;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0$0$2(Screen screen, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C75@2928L10,73@2808L176:ScreenMenu.kt#5m3rtf");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1057334864, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:73)");
            }
            TextKt.m3170TextNvy7gAk(screen.getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getLabelMedium(), composer, 0, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0$0$1(Screen screen, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C80@3137L36,79@3085L255:ScreenMenu.kt#5m3rtf");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1431612115, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:79)");
            }
            IconKt.m2463Iconww6aTOc(PainterResources_androidKt.painterResource(screen.getIconRes(), composer, 0), (String) null, SizeKt.m896size3ABfNKs(Modifier.INSTANCE, Dp.m7962constructorimpl(24)), 0L, composer, 432, 8);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0$0$0$0(Screen screen, final NavHostController navHostController, MutableState mutableState) {
        if (!Intrinsics.areEqual(ScreenMenu$lambda$1(mutableState), screen)) {
            String lowerCase = screen.getName().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            navHostController.navigate(lowerCase, new Function1() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return ScreenMenuKt.ScreenMenu$lambda$4$0$0$0$0$0$0(navHostController, (NavOptionsBuilder) obj);
                }
            });
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0$0$0$0$0(NavHostController navHostController, NavOptionsBuilder navigate) {
        Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo(NavGraph.INSTANCE.findStartDestination(navHostController.getGraph()).getId(), new Function1() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ScreenMenuKt.ScreenMenu$lambda$4$0$0$0$0$0$0$0((PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        navigate.setRestoreState(true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$4$0$0$0$0$0$0$0(PopUpToBuilder popUpTo) {
        Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setSaveState(true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5(final NavHostController navHostController, final MainViewModel mainViewModel, final NavHostController navHostController2, final PaddingValues innerPadding, Composer composer, int i) {
        int i2;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation(composer, "CN(innerPadding)114@5084L1234,111@4953L1365:ScreenMenu.kt#5m3rtf");
        if ((i & 6) == 0) {
            i2 = i | (composer.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if (!composer.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1384082328, i2, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous> (ScreenMenu.kt:111)");
            }
            String lowerCase = Screen.Schedule.INSTANCE.getName().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            ComposerKt.sourceInformationMarkerStart(composer, 1336750810, "CC(remember):ScreenMenu.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(mainViewModel) | ((i2 & 14) == 4) | composer.changedInstance(navHostController2) | composer.changedInstance(navHostController);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return ScreenMenuKt.ScreenMenu$lambda$5$0$0(innerPadding, mainViewModel, navHostController2, navHostController, (NavGraphBuilder) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            NavHostKt.NavHost(navHostController, lowerCase, null, null, null, null, null, null, null, null, (Function1) objRememberedValue, composer, 0, 0, PointerIconCompat.TYPE_GRAB);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0(final PaddingValues paddingValues, final MainViewModel mainViewModel, final NavHostController navHostController, final NavHostController navHostController2, NavGraphBuilder NavHost) {
        Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        String lowerCase = Screen.Schedule.INSTANCE.getName().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        NavGraphBuilderKt.composable$default(NavHost, lowerCase, (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(-1222553589, true, new Function4() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return ScreenMenuKt.ScreenMenu$lambda$5$0$0$0(paddingValues, mainViewModel, navHostController, navHostController2, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        }), 254, (Object) null);
        String lowerCase2 = Screen.Favorite.INSTANCE.getName().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
        NavGraphBuilderKt.composable$default(NavHost, lowerCase2, (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(-1301428222, true, new Function4() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return ScreenMenuKt.ScreenMenu$lambda$5$0$0$1(paddingValues, mainViewModel, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        }), 254, (Object) null);
        String lowerCase3 = Screen.Bets.INSTANCE.getName().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
        NavGraphBuilderKt.composable$default(NavHost, lowerCase3, (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(-1178524285, true, new Function4() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return ScreenMenuKt.ScreenMenu$lambda$5$0$0$2(paddingValues, mainViewModel, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        }), 254, (Object) null);
        String lowerCase4 = Screen.Profile.INSTANCE.getName().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
        NavGraphBuilderKt.composable$default(NavHost, lowerCase4, (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(-1055620348, true, new Function4() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return ScreenMenuKt.ScreenMenu$lambda$5$0$0$3(paddingValues, mainViewModel, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        }), 254, (Object) null);
        String lowerCase5 = Screen.Menu.INSTANCE.getName().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase5, "toLowerCase(...)");
        NavGraphBuilderKt.composable$default(NavHost, lowerCase5, (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(-932716411, true, new Function4() { // from class: com.nextfoot.ui.screens.ScreenMenuKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return ScreenMenuKt.ScreenMenu$lambda$5$0$0$4(paddingValues, mainViewModel, navHostController, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        }), 254, (Object) null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0$0(PaddingValues paddingValues, MainViewModel mainViewModel, NavHostController navHostController, NavHostController navHostController2, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)116@5161L236:ScreenMenu.kt#5m3rtf");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-1222553589, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:116)");
        }
        ScreenScheduleKt.ScreenSchedule(paddingValues, mainViewModel, navHostController, navHostController2, composer, 0);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0$1(PaddingValues paddingValues, MainViewModel mainViewModel, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)124@5487L125:ScreenMenu.kt#5m3rtf");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-1301428222, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:124)");
        }
        ScreenFavoriteKt.ScreenFavorite(paddingValues, mainViewModel, composer, 0);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0$2(PaddingValues paddingValues, MainViewModel mainViewModel, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)130@5698L121:ScreenMenu.kt#5m3rtf");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-1178524285, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:130)");
        }
        ScreenBetsKt.ScreenBets(paddingValues, mainViewModel, composer, 0);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0$3(PaddingValues paddingValues, MainViewModel mainViewModel, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)136@5908L124:ScreenMenu.kt#5m3rtf");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-1055620348, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:136)");
        }
        ScreenProfileKt.ScreenProfile(paddingValues, mainViewModel, composer, 0);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ScreenMenu$lambda$5$0$0$4(PaddingValues paddingValues, MainViewModel mainViewModel, NavHostController navHostController, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)142@6118L176:ScreenMenu.kt#5m3rtf");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-932716411, i, -1, "com.nextfoot.ui.screens.ScreenMenu.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ScreenMenu.kt:142)");
        }
        ScreenSubMenuKt.ScreenSubMenu(paddingValues, mainViewModel, navHostController, composer, 0);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }
}
