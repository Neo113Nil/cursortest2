package com.nextfoot.ui.screens;

import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.PainterResources_androidKt;
import com.nextfoot.R;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* compiled from: ScreenGame.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ScreenGameKt {
    public static final ComposableSingletons$ScreenGameKt INSTANCE = new ComposableSingletons$ScreenGameKt();

    /* renamed from: lambda$-150686586, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f49lambda$150686586 = ComposableLambdaKt.composableLambdaInstance(-150686586, false, new Function2() { // from class: com.nextfoot.ui.screens.ComposableSingletons$ScreenGameKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$ScreenGameKt.lambda__150686586$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-150686586$app_release, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8560getLambda$150686586$app_release() {
        return f49lambda$150686586;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit lambda__150686586$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C89@3664L37,91@3791L11,88@3638L199:ScreenGame.kt#5m3rtf");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-150686586, i, -1, "com.nextfoot.ui.screens.ComposableSingletons$ScreenGameKt.lambda$-150686586.<anonymous> (ScreenGame.kt:88)");
            }
            IconKt.m2463Iconww6aTOc(PainterResources_androidKt.painterResource(R.drawable.icon_back, composer, 0), (String) null, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), composer, 48, 4);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
