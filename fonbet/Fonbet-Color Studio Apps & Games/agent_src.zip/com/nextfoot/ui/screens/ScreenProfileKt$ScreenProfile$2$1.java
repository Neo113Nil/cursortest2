package com.nextfoot.ui.screens;

import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.State;
import androidx.compose.ui.text.TextRange;
import androidx.compose.ui.text.input.TextFieldValue;
import com.nextfoot.model.ProfileModel;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: ScreenProfile.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.nextfoot.ui.screens.ScreenProfileKt$ScreenProfile$2$1", f = "ScreenProfile.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* loaded from: classes2.dex */
final class ScreenProfileKt$ScreenProfile$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ MutableState<TextFieldValue> $emailText$delegate;
    final /* synthetic */ MutableState<TextFieldValue> $nameText$delegate;
    final /* synthetic */ State<ProfileModel> $profile$delegate;
    final /* synthetic */ MutableState<String> $selectedSport$delegate;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ScreenProfileKt$ScreenProfile$2$1(State<ProfileModel> state, MutableState<TextFieldValue> mutableState, MutableState<TextFieldValue> mutableState2, MutableState<String> mutableState3, Continuation<? super ScreenProfileKt$ScreenProfile$2$1> continuation) {
        super(2, continuation);
        this.$profile$delegate = state;
        this.$nameText$delegate = mutableState;
        this.$emailText$delegate = mutableState2;
        this.$selectedSport$delegate = mutableState3;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new ScreenProfileKt$ScreenProfile$2$1(this.$profile$delegate, this.$nameText$delegate, this.$emailText$delegate, this.$selectedSport$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((ScreenProfileKt$ScreenProfile$2$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        this.$nameText$delegate.setValue(new TextFieldValue(ScreenProfileKt.ScreenProfile$lambda$0(this.$profile$delegate).getName(), 0L, (TextRange) null, 6, (DefaultConstructorMarker) null));
        this.$emailText$delegate.setValue(new TextFieldValue(ScreenProfileKt.ScreenProfile$lambda$0(this.$profile$delegate).getEmail(), 0L, (TextRange) null, 6, (DefaultConstructorMarker) null));
        this.$selectedSport$delegate.setValue(ScreenProfileKt.ScreenProfile$lambda$0(this.$profile$delegate).getFavoriteSport());
        return Unit.INSTANCE;
    }
}
