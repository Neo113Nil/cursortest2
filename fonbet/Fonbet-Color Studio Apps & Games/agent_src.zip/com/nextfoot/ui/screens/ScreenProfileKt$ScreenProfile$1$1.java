package com.nextfoot.ui.screens;

import android.app.Activity;
import android.content.Intent;
import androidx.compose.runtime.State;
import com.nextfoot.MainActivity;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: ScreenProfile.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.nextfoot.ui.screens.ScreenProfileKt$ScreenProfile$1$1", f = "ScreenProfile.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* loaded from: classes2.dex */
final class ScreenProfileKt$ScreenProfile$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ Activity $activity;
    final /* synthetic */ State<Boolean> $profileCleared$delegate;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ScreenProfileKt$ScreenProfile$1$1(Activity activity, State<Boolean> state, Continuation<? super ScreenProfileKt$ScreenProfile$1$1> continuation) {
        super(2, continuation);
        this.$activity = activity;
        this.$profileCleared$delegate = state;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new ScreenProfileKt$ScreenProfile$1$1(this.$activity, this.$profileCleared$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((ScreenProfileKt$ScreenProfile$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            ResultKt.throwOnFailure(obj);
            if (ScreenProfileKt.ScreenProfile$lambda$1(this.$profileCleared$delegate)) {
                Activity activity = this.$activity;
                if (activity != null) {
                    activity.finish();
                }
                Activity activity2 = this.$activity;
                if (activity2 != null) {
                    activity2.startActivity(new Intent(this.$activity, (Class<?>) MainActivity.class));
                }
            }
            return Unit.INSTANCE;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
