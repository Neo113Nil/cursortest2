package com.nextfoot.ui.classes;

import androidx.core.app.NotificationCompat;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: BallState.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0004\u0004\u0005\u0006\u0007B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0004\b\t\n\u000b¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/BallState;", "", "<init>", "()V", "Idle", "Flying", "Scored", "Missed", "Lcom/nextfoot/ui/classes/BallState$Flying;", "Lcom/nextfoot/ui/classes/BallState$Idle;", "Lcom/nextfoot/ui/classes/BallState$Missed;", "Lcom/nextfoot/ui/classes/BallState$Scored;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class BallState {
    public static final int $stable = 0;

    public /* synthetic */ BallState(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    private BallState() {
    }

    /* compiled from: BallState.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/BallState$Idle;", "Lcom/nextfoot/ui/classes/BallState;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Idle extends BallState {
        public static final int $stable = 0;
        public static final Idle INSTANCE = new Idle();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Idle)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -2008808494;
        }

        public String toString() {
            return "Idle";
        }

        private Idle() {
            super(null);
        }
    }

    /* compiled from: BallState.kt */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J'\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0018"}, d2 = {"Lcom/nextfoot/ui/classes/BallState$Flying;", "Lcom/nextfoot/ui/classes/BallState;", "targetX", "", "targetY", NotificationCompat.CATEGORY_PROGRESS, "<init>", "(FFF)V", "getTargetX", "()F", "getTargetY", "getProgress", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Flying extends BallState {
        public static final int $stable = 0;
        private final float progress;
        private final float targetX;
        private final float targetY;

        public static /* synthetic */ Flying copy$default(Flying flying, float f, float f2, float f3, int i, Object obj) {
            if ((i & 1) != 0) {
                f = flying.targetX;
            }
            if ((i & 2) != 0) {
                f2 = flying.targetY;
            }
            if ((i & 4) != 0) {
                f3 = flying.progress;
            }
            return flying.copy(f, f2, f3);
        }

        /* renamed from: component1, reason: from getter */
        public final float getTargetX() {
            return this.targetX;
        }

        /* renamed from: component2, reason: from getter */
        public final float getTargetY() {
            return this.targetY;
        }

        /* renamed from: component3, reason: from getter */
        public final float getProgress() {
            return this.progress;
        }

        public final Flying copy(float targetX, float targetY, float progress) {
            return new Flying(targetX, targetY, progress);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Flying)) {
                return false;
            }
            Flying flying = (Flying) other;
            return Float.compare(this.targetX, flying.targetX) == 0 && Float.compare(this.targetY, flying.targetY) == 0 && Float.compare(this.progress, flying.progress) == 0;
        }

        public int hashCode() {
            return (((Float.hashCode(this.targetX) * 31) + Float.hashCode(this.targetY)) * 31) + Float.hashCode(this.progress);
        }

        public String toString() {
            return "Flying(targetX=" + this.targetX + ", targetY=" + this.targetY + ", progress=" + this.progress + ")";
        }

        public Flying(float f, float f2, float f3) {
            super(null);
            this.targetX = f;
            this.targetY = f2;
            this.progress = f3;
        }

        public /* synthetic */ Flying(float f, float f2, float f3, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(f, f2, (i & 4) != 0 ? 0.0f : f3);
        }

        public final float getTargetX() {
            return this.targetX;
        }

        public final float getTargetY() {
            return this.targetY;
        }

        public final float getProgress() {
            return this.progress;
        }
    }

    /* compiled from: BallState.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/BallState$Scored;", "Lcom/nextfoot/ui/classes/BallState;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Scored extends BallState {
        public static final int $stable = 0;
        public static final Scored INSTANCE = new Scored();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Scored)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -1739173744;
        }

        public String toString() {
            return "Scored";
        }

        private Scored() {
            super(null);
        }
    }

    /* compiled from: BallState.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/BallState$Missed;", "Lcom/nextfoot/ui/classes/BallState;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Missed extends BallState {
        public static final int $stable = 0;
        public static final Missed INSTANCE = new Missed();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Missed)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -1905287399;
        }

        public String toString() {
            return "Missed";
        }

        private Missed() {
            super(null);
        }
    }
}
