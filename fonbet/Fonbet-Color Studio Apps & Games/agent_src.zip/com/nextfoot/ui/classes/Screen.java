package com.nextfoot.ui.classes;

import com.nextfoot.R;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: Screen.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0005\f\r\u000e\u000f\u0010B\u0019\b\u0004\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b\u0082\u0001\u0005\u0011\u0012\u0013\u0014\u0015¨\u0006\u0016"}, d2 = {"Lcom/nextfoot/ui/classes/Screen;", "", "name", "", "iconRes", "", "<init>", "(Ljava/lang/String;I)V", "getName", "()Ljava/lang/String;", "getIconRes", "()I", "Schedule", "Favorite", "Bets", "Profile", "Menu", "Lcom/nextfoot/ui/classes/Screen$Bets;", "Lcom/nextfoot/ui/classes/Screen$Favorite;", "Lcom/nextfoot/ui/classes/Screen$Menu;", "Lcom/nextfoot/ui/classes/Screen$Profile;", "Lcom/nextfoot/ui/classes/Screen$Schedule;", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class Screen {
    public static final int $stable = 0;
    private final int iconRes;
    private final String name;

    public /* synthetic */ Screen(String str, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, i);
    }

    private Screen(String str, int i) {
        this.name = str;
        this.iconRes = i;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    public final String getName() {
        return this.name;
    }

    /* compiled from: Screen.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/Screen$Schedule;", "Lcom/nextfoot/ui/classes/Screen;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Schedule extends Screen {
        public static final int $stable = 0;
        public static final Schedule INSTANCE = new Schedule();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Schedule)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return 1747652855;
        }

        public String toString() {
            return "Schedule";
        }

        private Schedule() {
            super("Расписание", R.drawable.icon_schedule, null);
        }
    }

    /* compiled from: Screen.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/Screen$Favorite;", "Lcom/nextfoot/ui/classes/Screen;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Favorite extends Screen {
        public static final int $stable = 0;
        public static final Favorite INSTANCE = new Favorite();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Favorite)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -798603268;
        }

        public String toString() {
            return "Favorite";
        }

        private Favorite() {
            super("Избранное", R.drawable.icon_favorite, null);
        }
    }

    /* compiled from: Screen.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/Screen$Bets;", "Lcom/nextfoot/ui/classes/Screen;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Bets extends Screen {
        public static final int $stable = 0;
        public static final Bets INSTANCE = new Bets();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Bets)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -1984904094;
        }

        public String toString() {
            return "Bets";
        }

        private Bets() {
            super("Ставки", R.drawable.icon_bets, null);
        }
    }

    /* compiled from: Screen.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/Screen$Profile;", "Lcom/nextfoot/ui/classes/Screen;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Profile extends Screen {
        public static final int $stable = 0;
        public static final Profile INSTANCE = new Profile();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Profile)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return 739295049;
        }

        public String toString() {
            return "Profile";
        }

        private Profile() {
            super("Профиль", R.drawable.icon_profile, null);
        }
    }

    /* compiled from: Screen.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/nextfoot/ui/classes/Screen$Menu;", "Lcom/nextfoot/ui/classes/Screen;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final /* data */ class Menu extends Screen {
        public static final int $stable = 0;
        public static final Menu INSTANCE = new Menu();

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Menu)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return -1984576577;
        }

        public String toString() {
            return "Menu";
        }

        private Menu() {
            super("Меню", R.drawable.icon_menu, null);
        }
    }
}
