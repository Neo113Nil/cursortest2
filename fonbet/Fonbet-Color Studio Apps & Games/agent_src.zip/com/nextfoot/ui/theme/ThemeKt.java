package com.nextfoot.ui.theme;

import android.app.Activity;
import android.view.View;
import androidx.activity.compose.LocalActivityKt;
import androidx.compose.foundation.DarkThemeKt;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Theme.kt */
@Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a*\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\u0011\u0010\u0007\u001a\r\u0012\u0004\u0012\u00020\u00040\b¢\u0006\u0002\b\tH\u0007¢\u0006\u0002\u0010\n\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"DarkColorScheme", "Landroidx/compose/material3/ColorScheme;", "LightColorScheme", "NextFootTheme", "", "darkTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ThemeKt {
    private static final ColorScheme DarkColorScheme = ColorSchemeKt.m2137darkColorScheme_VG5OTI$default(ColorKt.getRed(), ColorKt.getWhite(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ColorKt.getWhite(), ColorKt.getBlack(), ColorKt.getBlue(), ColorKt.getWhite(), ColorKt.getBlack(), ColorKt.getWhite(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -516100, 65535, null);
    private static final ColorScheme LightColorScheme = ColorSchemeKt.m2143lightColorScheme_VG5OTI$default(ColorKt.getRed(), ColorKt.getWhite(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ColorKt.getWhite(), ColorKt.getBlack(), ColorKt.getBlue(), ColorKt.getWhite(), ColorKt.getBlack(), ColorKt.getWhite(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -516100, 65535, null);

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit NextFootTheme$lambda$1(boolean z, Function2 function2, int i, int i2, Composer composer, int i3) {
        NextFootTheme(z, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x007d  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0108  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void NextFootTheme(final boolean z, Function2<? super Composer, ? super Integer, Unit> content, Composer composer, final int i, final int i2) {
        int i3;
        final Function2<? super Composer, ? super Integer, Unit> function2;
        ColorScheme colorScheme;
        final Activity activity;
        Intrinsics.checkNotNullParameter(content, "content");
        Composer composerStartRestartGroup = composer.startRestartGroup(1898290243);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(NextFootTheme)N(darkTheme,content)43@1191L7,44@1232L7,53@1507L114:Theme.kt#5xaib3");
        if ((i & 6) == 0) {
            i3 = (((i2 & 1) == 0 && composerStartRestartGroup.changed(z)) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(content) ? 32 : 16;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "36@998L21");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 1) != 0) {
                    z = DarkThemeKt.isSystemInDarkTheme(composerStartRestartGroup, 0);
                    i3 &= -15;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(1898290243, i3, -1, "com.nextfoot.ui.theme.NextFootTheme (Theme.kt:38)");
                }
                if (!z) {
                    colorScheme = DarkColorScheme;
                } else {
                    colorScheme = LightColorScheme;
                }
                ColorScheme colorScheme2 = colorScheme;
                ProvidableCompositionLocal<View> localView = AndroidCompositionLocals_androidKt.getLocalView();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                Object objConsume = composerStartRestartGroup.consume(localView);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final View view = (View) objConsume;
                ProvidableCompositionLocal<Activity> localActivity = LocalActivityKt.getLocalActivity();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                Object objConsume2 = composerStartRestartGroup.consume(localActivity);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                activity = (Activity) objConsume2;
                if (activity == null) {
                    composerStartRestartGroup.startReplaceGroup(130559603);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "46@1287L209,46@1276L220");
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1104166412, "CC(remember):Theme.kt#9igjgp");
                    boolean zChangedInstance = composerStartRestartGroup.changedInstance(activity) | composerStartRestartGroup.changedInstance(view);
                    Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue = new Function0() { // from class: com.nextfoot.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ThemeKt.NextFootTheme$lambda$0$0(activity, view);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    EffectsKt.SideEffect((Function0) objRememberedValue, composerStartRestartGroup, 0);
                } else {
                    composerStartRestartGroup.startReplaceGroup(129295423);
                }
                composerStartRestartGroup.endReplaceGroup();
                function2 = content;
                MaterialThemeKt.MaterialTheme(colorScheme2, null, TypeKt.getTypography(), function2, composerStartRestartGroup, ((i3 << 6) & 7168) | 384, 2);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 1) != 0) {
                    i3 &= -15;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                }
                if (!z) {
                }
                ColorScheme colorScheme22 = colorScheme;
                ProvidableCompositionLocal<View> localView2 = AndroidCompositionLocals_androidKt.getLocalView();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                Object objConsume3 = composerStartRestartGroup.consume(localView2);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final View view2 = (View) objConsume3;
                ProvidableCompositionLocal<Activity> localActivity2 = LocalActivityKt.getLocalActivity();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                Object objConsume22 = composerStartRestartGroup.consume(localActivity2);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                activity = (Activity) objConsume22;
                if (activity == null) {
                }
                composerStartRestartGroup.endReplaceGroup();
                function2 = content;
                MaterialThemeKt.MaterialTheme(colorScheme22, null, TypeKt.getTypography(), function2, composerStartRestartGroup, ((i3 << 6) & 7168) | 384, 2);
                if (ComposerKt.isTraceInProgress()) {
                }
            }
        } else {
            function2 = content;
            composerStartRestartGroup.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.nextfoot.ui.theme.ThemeKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ThemeKt.NextFootTheme$lambda$1(z, function2, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit NextFootTheme$lambda$0$0(Activity activity, View view) {
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(activity.getWindow(), view);
        insetsController.setAppearanceLightStatusBars(false);
        insetsController.setAppearanceLightNavigationBars(false);
        return Unit.INSTANCE;
    }
}
