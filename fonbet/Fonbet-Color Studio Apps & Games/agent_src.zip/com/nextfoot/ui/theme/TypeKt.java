package com.nextfoot.ui.theme;

import androidx.compose.material3.Typography;
import androidx.compose.ui.graphics.Shadow;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.text.PlatformTextStyle;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontFamilyKt;
import androidx.compose.ui.text.font.FontKt;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontSynthesis;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.style.BaselineShift;
import androidx.compose.ui.text.style.LineHeightStyle;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.style.TextGeometricTransform;
import androidx.compose.ui.text.style.TextIndent;
import androidx.compose.ui.text.style.TextMotion;
import androidx.compose.ui.unit.TextUnitKt;
import com.nextfoot.R;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: Type.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0011\u0010\u0004\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0003\"\u0011\u0010\u0006\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0003\"\u0011\u0010\b\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0003\"\u0011\u0010\n\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0003\"\u0011\u0010\f\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0003\"\u0011\u0010\u000e\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"SourceSansExtraBold", "Landroidx/compose/ui/text/font/FontFamily;", "getSourceSansExtraBold", "()Landroidx/compose/ui/text/font/FontFamily;", "SourceSansBold", "getSourceSansBold", "SourceSansSemibold", "getSourceSansSemibold", "SourceSansRegular", "getSourceSansRegular", "SourceSansLight", "getSourceSansLight", "AlumniSansBold", "getAlumniSansBold", "Typography", "Landroidx/compose/material3/Typography;", "getTypography", "()Landroidx/compose/material3/Typography;", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class TypeKt {
    private static final FontFamily AlumniSansBold;
    private static final FontFamily SourceSansBold;
    private static final FontFamily SourceSansExtraBold;
    private static final FontFamily SourceSansLight;
    private static final FontFamily SourceSansRegular;
    private static final FontFamily SourceSansSemibold;
    private static final Typography Typography;

    static {
        FontFamily FontFamily = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.sourcesans3_extrabold, null, 0, 0, 14, null));
        SourceSansExtraBold = FontFamily;
        FontFamily FontFamily2 = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.sourcesans3_bold, null, 0, 0, 14, null));
        SourceSansBold = FontFamily2;
        FontFamily FontFamily3 = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.sourcesans3_semibold, null, 0, 0, 14, null));
        SourceSansSemibold = FontFamily3;
        FontFamily FontFamily4 = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.sourcesans3_regular, null, 0, 0, 14, null));
        SourceSansRegular = FontFamily4;
        FontFamily FontFamily5 = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.sourcesans3_light, null, 0, 0, 14, null));
        SourceSansLight = FontFamily5;
        AlumniSansBold = FontFamilyKt.FontFamily(FontKt.m7518FontYpTlLL0$default(R.font.alumnisans_bold, null, 0, 0, 14, null));
        Typography = new Typography(null, new TextStyle(0L, TextUnitKt.getSp(64), (FontWeight) null, FontStyle.m7534boximpl(FontStyle.INSTANCE.m7543getItalic_LCdwA()), (FontSynthesis) null, FontFamily2, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(64), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646101, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(64), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily3, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(64), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(24), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily2, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(24), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(36), (FontWeight) null, FontStyle.m7534boximpl(FontStyle.INSTANCE.m7543getItalic_LCdwA()), (FontSynthesis) null, FontFamily2, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(36), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646101, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(34), (FontWeight) null, FontStyle.m7534boximpl(FontStyle.INSTANCE.m7543getItalic_LCdwA()), (FontSynthesis) null, FontFamily2, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(34), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646101, (DefaultConstructorMarker) null), null, new TextStyle(0L, TextUnitKt.getSp(28), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(28), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(28), (FontWeight) null, FontStyle.m7534boximpl(FontStyle.INSTANCE.m7543getItalic_LCdwA()), (FontSynthesis) null, FontFamily2, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(28), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646101, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(24), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily4, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(24), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(20), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily4, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(20), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(16), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily4, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(16), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(12), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily4, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(12), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), new TextStyle(0L, TextUnitKt.getSp(12), (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamily5, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(12), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16646109, (DefaultConstructorMarker) null), null, 16449, null);
    }

    public static final FontFamily getSourceSansExtraBold() {
        return SourceSansExtraBold;
    }

    public static final FontFamily getSourceSansBold() {
        return SourceSansBold;
    }

    public static final FontFamily getSourceSansSemibold() {
        return SourceSansSemibold;
    }

    public static final FontFamily getSourceSansRegular() {
        return SourceSansRegular;
    }

    public static final FontFamily getSourceSansLight() {
        return SourceSansLight;
    }

    public static final FontFamily getAlumniSansBold() {
        return AlumniSansBold;
    }

    public static final Typography getTypography() {
        return Typography;
    }
}
