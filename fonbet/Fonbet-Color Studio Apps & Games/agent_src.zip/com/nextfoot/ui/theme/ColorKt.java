package com.nextfoot.ui.theme;

import kotlin.Metadata;

/* compiled from: Color.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003¨\u0006\u000b"}, d2 = {"Black", "Landroidx/compose/ui/graphics/Color;", "getBlack", "()J", "J", "White", "getWhite", "Blue", "getBlue", "Red", "getRed", "app_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ColorKt {
    private static final long Black = androidx.compose.ui.graphics.ColorKt.Color(4279374354L);
    private static final long White = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long Blue = androidx.compose.ui.graphics.ColorKt.Color(4281745496L);
    private static final long Red = androidx.compose.ui.graphics.ColorKt.Color(4292220451L);

    public static final long getBlack() {
        return Black;
    }

    public static final long getWhite() {
        return White;
    }

    public static final long getBlue() {
        return Blue;
    }

    public static final long getRed() {
        return Red;
    }
}
