package hilt_aggregated_deps;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public class _com_rewards_casino_loungerser_ui_menu_MenuViewModel_HiltModules_KeyModule {
}
