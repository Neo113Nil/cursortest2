package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/MenuItemFilter;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuItemFilter {
    public static final List XfQCOxz9Pm9BcT = CollectionsKt.jcThbbljzdkQV("Not Sweet", "Slightly Sweet", "Sweet", "Very Sweet");
    public static final List NzWQJjWwugl4VFs = CollectionsKt.jcThbbljzdkQV("Chilled", "Room Temperature", "Warm", "Hot");

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* synthetic */ class WhenMappings {
        static {
            int[] iArr = new int[SortOption.values().length];
            try {
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                SortOption sortOption = SortOption.ADpl0noRbUAhY;
                iArr[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                SortOption sortOption2 = SortOption.ADpl0noRbUAhY;
                iArr[2] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }
}
