package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.SnackbarHostState;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.favorites.FavoritesScreenKt$FavoritesScreen$1$1", f = "FavoritesScreen.kt", l = {93}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class FavoritesScreenKt$FavoritesScreen$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public int Ib3GalHLi1oFkSI;
    public final /* synthetic */ SnackbarHostState hargS3kTbQOR;
    public final /* synthetic */ FavoritesViewModel jtRrC0njHlFmpd;
    public FavoritesViewModel mhkN7GL0jG0Wg1w;
    public final /* synthetic */ String uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FavoritesScreenKt$FavoritesScreen$1$1(String str, SnackbarHostState snackbarHostState, FavoritesViewModel favoritesViewModel, Continuation continuation) {
        super(2, continuation);
        this.uVptkJu9raq3 = str;
        this.hargS3kTbQOR = snackbarHostState;
        this.jtRrC0njHlFmpd = favoritesViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        FavoritesViewModel favoritesViewModel;
        Object value;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.Ib3GalHLi1oFkSI;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            String str = this.uVptkJu9raq3;
            if (str != null) {
                FavoritesViewModel favoritesViewModel2 = this.jtRrC0njHlFmpd;
                this.mhkN7GL0jG0Wg1w = favoritesViewModel2;
                this.Ib3GalHLi1oFkSI = 1;
                if (SnackbarHostState.NzWQJjWwugl4VFs(this.hargS3kTbQOR, str, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
                favoritesViewModel = favoritesViewModel2;
            }
            return Unit.XfQCOxz9Pm9BcT;
        }
        if (i != 1) {
            defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        favoritesViewModel = this.mhkN7GL0jG0Wg1w;
        ResultKt.NzWQJjWwugl4VFs(obj);
        MutableStateFlow mutableStateFlow = favoritesViewModel.f6FsnIUuKXgtm;
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, FavoritesUiState.XfQCOxz9Pm9BcT((FavoritesUiState) value, null, null, null, null, null, null, null, 127)));
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((FavoritesScreenKt$FavoritesScreen$1$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new FavoritesScreenKt$FavoritesScreen$1$1(this.uVptkJu9raq3, this.hargS3kTbQOR, this.jtRrC0njHlFmpd, continuation);
    }
}
