package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.v6;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/MenuUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class MenuUiState {
    public final SortOption ADpl0noRbUAhY;
    public final String AY1Ge095OJR8sU;
    public final List NzWQJjWwugl4VFs;
    public final Long Q5MXmkXGmrpQ;
    public final boolean R7447vqBon0A;
    public final List XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;
    public final boolean mhkN7GL0jG0Wg1w;

    public MenuUiState(List list, List list2, String str, SortOption sortOption, String str2, boolean z, Long l, boolean z2) {
        list.getClass();
        list2.getClass();
        sortOption.getClass();
        this.XfQCOxz9Pm9BcT = list;
        this.NzWQJjWwugl4VFs = list2;
        this.f6FsnIUuKXgtm = str;
        this.ADpl0noRbUAhY = sortOption;
        this.AY1Ge095OJR8sU = str2;
        this.R7447vqBon0A = z;
        this.Q5MXmkXGmrpQ = l;
        this.mhkN7GL0jG0Wg1w = z2;
    }

    public static MenuUiState XfQCOxz9Pm9BcT(MenuUiState menuUiState, List list, List list2, String str, SortOption sortOption, String str2, Long l, int i) {
        if ((i & 1) != 0) {
            list = menuUiState.XfQCOxz9Pm9BcT;
        }
        List list3 = list;
        if ((i & 2) != 0) {
            list2 = menuUiState.NzWQJjWwugl4VFs;
        }
        List list4 = list2;
        if ((i & 4) != 0) {
            str = menuUiState.f6FsnIUuKXgtm;
        }
        String str3 = str;
        if ((i & 8) != 0) {
            sortOption = menuUiState.ADpl0noRbUAhY;
        }
        SortOption sortOption2 = sortOption;
        String str4 = (i & 16) != 0 ? menuUiState.AY1Ge095OJR8sU : str2;
        boolean z = (i & 32) != 0 ? menuUiState.R7447vqBon0A : false;
        menuUiState.getClass();
        Long l2 = (i & 128) != 0 ? menuUiState.Q5MXmkXGmrpQ : l;
        boolean z2 = (i & 256) != 0 ? menuUiState.mhkN7GL0jG0Wg1w : false;
        menuUiState.getClass();
        list3.getClass();
        list4.getClass();
        str3.getClass();
        sortOption2.getClass();
        str4.getClass();
        return new MenuUiState(list3, list4, str3, sortOption2, str4, z, l2, z2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MenuUiState)) {
            return false;
        }
        MenuUiState menuUiState = (MenuUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, menuUiState.XfQCOxz9Pm9BcT) && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, menuUiState.NzWQJjWwugl4VFs) && this.f6FsnIUuKXgtm.equals(menuUiState.f6FsnIUuKXgtm) && this.ADpl0noRbUAhY == menuUiState.ADpl0noRbUAhY && this.AY1Ge095OJR8sU.equals(menuUiState.AY1Ge095OJR8sU) && this.R7447vqBon0A == menuUiState.R7447vqBon0A && Intrinsics.XfQCOxz9Pm9BcT(this.Q5MXmkXGmrpQ, menuUiState.Q5MXmkXGmrpQ) && this.mhkN7GL0jG0Wg1w == menuUiState.mhkN7GL0jG0Wg1w;
    }

    public final int hashCode() {
        int iXfQCOxz9Pm9BcT = v6.XfQCOxz9Pm9BcT(v6.NzWQJjWwugl4VFs(this.AY1Ge095OJR8sU, (this.ADpl0noRbUAhY.hashCode() + v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, (this.NzWQJjWwugl4VFs.hashCode() + (this.XfQCOxz9Pm9BcT.hashCode() * 31)) * 31, 31)) * 31, 31), 961, this.R7447vqBon0A);
        Long l = this.Q5MXmkXGmrpQ;
        return Boolean.hashCode(this.mhkN7GL0jG0Wg1w) + ((iXfQCOxz9Pm9BcT + (l == null ? 0 : l.hashCode())) * 31);
    }

    public final String toString() {
        return "MenuUiState(allItems=" + this.XfQCOxz9Pm9BcT + ", filteredItems=" + this.NzWQJjWwugl4VFs + ", selectedCategory=" + this.f6FsnIUuKXgtm + ", selectedSort=" + this.ADpl0noRbUAhY + ", searchQuery=" + this.AY1Ge095OJR8sU + ", isLoading=" + this.R7447vqBon0A + ", error=null, selectedItemId=" + this.Q5MXmkXGmrpQ + ", showSortSheet=" + this.mhkN7GL0jG0Wg1w + ")";
    }
}
