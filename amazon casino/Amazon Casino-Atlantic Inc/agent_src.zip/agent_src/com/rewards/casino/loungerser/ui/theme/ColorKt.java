package com.rewards.casino.loungerser.ui.theme;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ColorKt {
    public static final long XfQCOxz9Pm9BcT = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4287548320L);
    public static final long NzWQJjWwugl4VFs = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4289776056L);
    public static final long f6FsnIUuKXgtm = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4289250720L);
    public static final long ADpl0noRbUAhY = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4283202140L);
    public static final long AY1Ge095OJR8sU = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4283591514L);
    public static final long R7447vqBon0A = androidx.compose.ui.graphics.ColorKt.ADpl0noRbUAhY(4284381797L);
}
