package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import java.util.Comparator;
import kotlin.Metadata;
import kotlin.comparisons.ComparisonsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class NotesViewModel$applySorting$$inlined$sortedBy$2<T> implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        String str = ((NoteWithItemName) obj).NzWQJjWwugl4VFs;
        if (str == null) {
            str = "";
        }
        String str2 = ((NoteWithItemName) obj2).NzWQJjWwugl4VFs;
        return ComparisonsKt.XfQCOxz9Pm9BcT(str, str2 != null ? str2 : "");
    }
}
