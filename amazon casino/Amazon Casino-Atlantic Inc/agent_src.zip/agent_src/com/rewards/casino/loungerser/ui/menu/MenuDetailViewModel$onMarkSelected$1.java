package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.TasteMarkEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel$onMarkSelected$1", f = "MenuDetailViewModel.kt", l = {114}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MenuDetailViewModel$onMarkSelected$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ MenuDetailViewModel Ib3GalHLi1oFkSI;
    public final /* synthetic */ String hargS3kTbQOR;
    public final /* synthetic */ String jtRrC0njHlFmpd;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ long uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MenuDetailViewModel$onMarkSelected$1(MenuDetailViewModel menuDetailViewModel, long j, String str, String str2, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = menuDetailViewModel;
        this.uVptkJu9raq3 = j;
        this.hargS3kTbQOR = str;
        this.jtRrC0njHlFmpd = str2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        if (i != 0) {
            if (i == 1) {
                ResultKt.NzWQJjWwugl4VFs(obj);
                return unit;
            }
            defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        ResultKt.NzWQJjWwugl4VFs(obj);
        AppRepository appRepository = this.Ib3GalHLi1oFkSI.NzWQJjWwugl4VFs;
        this.mhkN7GL0jG0Wg1w = 1;
        Object objNzWQJjWwugl4VFs = appRepository.ADpl0noRbUAhY.NzWQJjWwugl4VFs(new TasteMarkEntity(0L, this.uVptkJu9raq3, this.hargS3kTbQOR, this.jtRrC0njHlFmpd, System.currentTimeMillis()), this);
        if (objNzWQJjWwugl4VFs != coroutineSingletons) {
            objNzWQJjWwugl4VFs = unit;
        }
        return objNzWQJjWwugl4VFs == coroutineSingletons ? coroutineSingletons : unit;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((MenuDetailViewModel$onMarkSelected$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MenuDetailViewModel$onMarkSelected$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this.hargS3kTbQOR, this.jtRrC0njHlFmpd, continuation);
    }
}
