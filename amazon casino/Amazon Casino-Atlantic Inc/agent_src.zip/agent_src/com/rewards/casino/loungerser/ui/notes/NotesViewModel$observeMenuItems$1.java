package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeMenuItems$1", f = "NotesViewModel.kt", l = {63}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NotesViewModel$observeMenuItems$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ NotesViewModel Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesViewModel$observeMenuItems$1(NotesViewModel notesViewModel, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = notesViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            final NotesViewModel notesViewModel = this.Ib3GalHLi1oFkSI;
            FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1XfQCOxz9Pm9BcT = notesViewModel.NzWQJjWwugl4VFs.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT();
            FlowCollector flowCollector = new FlowCollector() { // from class: com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeMenuItems$1.1
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object f6FsnIUuKXgtm(Object obj2, Continuation continuation) {
                    Object value;
                    List list = (List) obj2;
                    MutableStateFlow mutableStateFlow = notesViewModel.f6FsnIUuKXgtm;
                    do {
                        value = mutableStateFlow.getValue();
                    } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, CollectionsKt.eqwJwm8oIiKHLs(list, new NotesViewModel$observeMenuItems$1$1$emit$lambda$0$$inlined$sortedBy$1()), null, null, null, false, false, null, null, null, false, null, 16381)));
                    return Unit.XfQCOxz9Pm9BcT;
                }
            };
            this.mhkN7GL0jG0Wg1w = 1;
            if (flowUtil$createFlow$$inlined$map$1XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(flowCollector, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NotesViewModel$observeMenuItems$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NotesViewModel$observeMenuItems$1(this.Ib3GalHLi1oFkSI, continuation);
    }
}
