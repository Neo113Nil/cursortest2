package com.rewards.casino.loungerser.data.repository;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.dao.FavoriteDao;
import com.rewards.casino.loungerser.data.dao.MenuItemDao;
import com.rewards.casino.loungerser.data.dao.NoteDao;
import com.rewards.casino.loungerser.data.dao.TasteMarkDao;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import defpackage.XfQCOxz9Pm9BcT;
import defpackage.j2;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.random.AbstractPlatformRandom;
import kotlin.random.Random;
import kotlin.ranges.IntRange;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Singleton
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/repository/AppRepository;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class AppRepository {
    public final TasteMarkDao ADpl0noRbUAhY;
    public final FavoriteDao NzWQJjWwugl4VFs;
    public final MenuItemDao XfQCOxz9Pm9BcT;
    public final NoteDao f6FsnIUuKXgtm;

    public AppRepository(MenuItemDao menuItemDao, FavoriteDao favoriteDao, NoteDao noteDao, TasteMarkDao tasteMarkDao) {
        this.XfQCOxz9Pm9BcT = menuItemDao;
        this.NzWQJjWwugl4VFs = favoriteDao;
        this.f6FsnIUuKXgtm = noteDao;
        this.ADpl0noRbUAhY = tasteMarkDao;
    }

    public static final String XfQCOxz9Pm9BcT(List list) {
        int iNzWQJjWwugl4VFs;
        IntRange intRange = new IntRange(3, 5, 1);
        AbstractPlatformRandom abstractPlatformRandom = Random.ADpl0noRbUAhY;
        try {
            AbstractPlatformRandom abstractPlatformRandom2 = Random.ADpl0noRbUAhY;
            if (intRange.isEmpty()) {
                XfQCOxz9Pm9BcT.mhkN7GL0jG0Wg1w(intRange, "Cannot get random in empty range: ");
                iNzWQJjWwugl4VFs = 0;
            } else {
                int i = intRange.AY1Ge095OJR8sU;
                int i2 = intRange.ADpl0noRbUAhY;
                if (i < Integer.MAX_VALUE) {
                    iNzWQJjWwugl4VFs = Random.ADpl0noRbUAhY.f6FsnIUuKXgtm(i2, i + 1);
                } else if (i2 > Integer.MIN_VALUE) {
                    iNzWQJjWwugl4VFs = Random.ADpl0noRbUAhY.f6FsnIUuKXgtm(i2 - 1, i) + 1;
                } else {
                    iNzWQJjWwugl4VFs = Random.ADpl0noRbUAhY.NzWQJjWwugl4VFs();
                }
            }
            return CollectionsKt.Mdvwk4KCHtoBY(CollectionsKt.M7DF7HY0IK3zByX(iNzWQJjWwugl4VFs, CollectionsKt.WOuUYCT1RQRv0EU(list)), ", ", null, null, null, 62);
        } catch (IllegalArgumentException e) {
            j2.mhkN7GL0jG0Wg1w(e.getMessage());
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object NzWQJjWwugl4VFs(ContinuationImpl continuationImpl) {
        AppRepository$seedDatabase$1 appRepository$seedDatabase$1;
        if (continuationImpl instanceof AppRepository$seedDatabase$1) {
            appRepository$seedDatabase$1 = (AppRepository$seedDatabase$1) continuationImpl;
            int i = appRepository$seedDatabase$1.Ib3GalHLi1oFkSI;
            if ((i & Integer.MIN_VALUE) != 0) {
                appRepository$seedDatabase$1.Ib3GalHLi1oFkSI = i - Integer.MIN_VALUE;
            } else {
                appRepository$seedDatabase$1 = new AppRepository$seedDatabase$1(this, continuationImpl);
            }
        }
        Object objADpl0noRbUAhY = appRepository$seedDatabase$1.Q5MXmkXGmrpQ;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i2 = appRepository$seedDatabase$1.Ib3GalHLi1oFkSI;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        MenuItemDao menuItemDao = this.XfQCOxz9Pm9BcT;
        if (i2 == 0) {
            ResultKt.NzWQJjWwugl4VFs(objADpl0noRbUAhY);
            appRepository$seedDatabase$1.Ib3GalHLi1oFkSI = 1;
            objADpl0noRbUAhY = menuItemDao.ADpl0noRbUAhY(appRepository$seedDatabase$1);
            if (objADpl0noRbUAhY != coroutineSingletons) {
            }
        }
        if (i2 != 1) {
            if (i2 == 2) {
                ResultKt.NzWQJjWwugl4VFs(objADpl0noRbUAhY);
                return unit;
            }
            XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        ResultKt.NzWQJjWwugl4VFs(objADpl0noRbUAhY);
        if (((Number) objADpl0noRbUAhY).intValue() > 0) {
            return unit;
        }
        List listJcThbbljzdkQV = CollectionsKt.jcThbbljzdkQV("Open Sandwiches", "Warm Plates", "Pastries", "Hot Drinks", "Cold Drinks");
        List listJcThbbljzdkQV2 = CollectionsKt.jcThbbljzdkQV("Not Sweet", "Slightly Sweet", "Sweet", "Very Sweet");
        List listJcThbbljzdkQV3 = CollectionsKt.jcThbbljzdkQV("Chilled", "Room Temperature", "Warm", "Hot");
        List listJcThbbljzdkQV4 = CollectionsKt.jcThbbljzdkQV("Norwegian", "Swedish", "Danish", "Finnish");
        List listJcThbbljzdkQV5 = CollectionsKt.jcThbbljzdkQV("Cozy", "Toasted", "Creamy", "Smoky", "Fresh", "Buttery", "Herbal", "Nutty", "Signature", "Seasonal");
        ArrayList arrayList = new ArrayList();
        List<Triple> listJcThbbljzdkQV6 = CollectionsKt.jcThbbljzdkQV(new Triple("Gravlax on Rye", "Cured salmon with dill mustard and pickled onions", "Rye bread, Gravlax, Dill, Mustard, Red onion"), new Triple("Smoked Mackerel Spread", "Creamy smoked mackerel with horseradish on toast", "Mackerel, Horseradish, Cream cheese, Toast"), new Triple("Cucumber & Shrimp", "Fresh shrimp with cucumber and dill mayo", "Shrimp, Cucumber, Dill, Mayonnaise"), new Triple("Roast Beef & Pickles", "Tender roast beef with pickled beets", "Roast beef, Pickled beets, Greens"), new Triple("Egg & Anchovy", "Hard-boiled egg with anchovy paste", "Egg, Anchovy, Chives"), new Triple("Liver Pâté", "Rich liver pâté with bacon and lingonberry", "Pork liver, Bacon, Lingonberry jam"), new Triple("Herring & Onion", "Pickled herring with red onion rings", "Herring, Red onion, Capers"), new Triple("Cheese & Radish", "Aged cheese with crisp radish slices", "Cheese, Radish, Butter"));
        List<Triple> listJcThbbljzdkQV7 = CollectionsKt.jcThbbljzdkQV(new Triple("Swedish Meatballs", "Classic meatballs in creamy gravy", "Beef, Pork, Cream, Lingonberry"), new Triple("Reindeer Stew", "Slow-cooked reindeer with root vegetables", "Reindeer, Carrot, Potato, Juniper"), new Triple("Pan-Fried Pike", "Pike fillet with browned butter", "Pike, Butter, Dill"), new Triple("Cabbage Rolls", "Stuffed cabbage with minced meat", "Cabbage, Beef, Rice"), new Triple("Salmon Soup", "Creamy salmon and potato soup", "Salmon, Potato, Cream, Dill"), new Triple("Pork Roast", "Slow-roasted pork with prunes", "Pork, Prunes, Thyme"), new Triple("Potato Pancakes", "Crispy potato pancakes with sour cream", "Potato, Flour, Sour cream"), new Triple("Root Vegetable Gratin", "Baked roots with cream and cheese", "Carrot, Parsnip, Cream, Cheese"));
        List<Triple> listJcThbbljzdkQV8 = CollectionsKt.jcThbbljzdkQV(new Triple("Cinnamon Bun", "Classic kanelbulle with pearl sugar", "Flour, Butter, Cinnamon, Cardamom"), new Triple("Cardamom Roll", "Twisted roll with cardamom butter", "Flour, Butter, Cardamom, Sugar"), new Triple("Almond Tart", "Swedish almond pastry", "Almond paste, Butter, Flour"), new Triple("Rye Cookie", "Crisp rye biscuit with caraway", "Rye flour, Butter, Caraway"), new Triple("Cloudberry Pastry", "Puff pastry with cloudberry jam", "Puff pastry, Cloudberry"), new Triple("Saffron Bun", "Lussekatt with saffron and raisins", "Flour, Saffron, Butter, Raisins"), new Triple("Butter Cookie", "Shortbread with almond slivers", "Flour, Butter, Almond"), new Triple("Rhubarb Slice", "Layered cake with rhubarb cream", "Rhubarb, Cream, Flour"));
        List<Triple> listJcThbbljzdkQV9 = CollectionsKt.jcThbbljzdkQV(new Triple("Glögg", "Mulled wine with spices and almonds", "Red wine, Cinnamon, Cloves, Raisins"), new Triple("Lingonberry Tea", "Herbal tea with lingonberry", "Lingonberry, Black tea"), new Triple("Nordic Coffee", "Strong filtered coffee", "Arabica beans"), new Triple("Hot Chocolate", "Rich chocolate with whipped cream", "Chocolate, Milk, Cream"), new Triple("Elderflower Tea", "Floral herbal infusion", "Elderflower, Apple"), new Triple("Birch Sap Latte", "Steamed birch sap with espresso", "Birch sap, Espresso"));
        List<Triple> listJcThbbljzdkQV10 = CollectionsKt.jcThbbljzdkQV(new Triple("Lingonberry Spritz", "Sparkling lingonberry drink", "Lingonberry, Soda water"), new Triple("Sea Buckthorn Juice", "Tart sea buckthorn nectar", "Sea buckthorn, Apple juice"), new Triple("Cloudberry Smoothie", "Smooth cloudberry blend", "Cloudberry, Yogurt"), new Triple("Elderflower Cordial", "Sweet elderflower syrup with water", "Elderflower, Sugar, Lemon"), new Triple("Pine Needle Tonic", "Refreshing pine tonic", "Pine needle extract, Tonic water"), new Triple("Rhubarb Lemonade", "Tangy rhubarb drink", "Rhubarb, Lemon, Sugar"));
        for (Triple triple : listJcThbbljzdkQV6) {
            String str = (String) triple.ADpl0noRbUAhY;
            String str2 = (String) triple.AY1Ge095OJR8sU;
            String str3 = (String) triple.R7447vqBon0A;
            String str4 = (String) listJcThbbljzdkQV.get(0);
            String str5 = (String) listJcThbbljzdkQV2.get(0);
            String str6 = (String) listJcThbbljzdkQV3.get(1);
            AbstractPlatformRandom abstractPlatformRandom = Random.ADpl0noRbUAhY;
            arrayList.add(new MenuItemEntity(str, str4, str2, str3, str5, str6, (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV4), XfQCOxz9Pm9BcT(listJcThbbljzdkQV5)));
        }
        for (Triple triple2 : listJcThbbljzdkQV7) {
            String str7 = (String) triple2.ADpl0noRbUAhY;
            String str8 = (String) triple2.AY1Ge095OJR8sU;
            String str9 = (String) triple2.R7447vqBon0A;
            String str10 = (String) listJcThbbljzdkQV.get(1);
            String str11 = (String) listJcThbbljzdkQV2.get(0);
            String str12 = (String) listJcThbbljzdkQV3.get(3);
            AbstractPlatformRandom abstractPlatformRandom2 = Random.ADpl0noRbUAhY;
            arrayList.add(new MenuItemEntity(str7, str10, str8, str9, str11, str12, (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV4), XfQCOxz9Pm9BcT(listJcThbbljzdkQV5)));
        }
        for (Triple triple3 : listJcThbbljzdkQV8) {
            String str13 = (String) triple3.ADpl0noRbUAhY;
            String str14 = (String) triple3.AY1Ge095OJR8sU;
            String str15 = (String) triple3.R7447vqBon0A;
            String str16 = (String) listJcThbbljzdkQV.get(2);
            List listJcThbbljzdkQV11 = CollectionsKt.jcThbbljzdkQV(listJcThbbljzdkQV2.get(2), listJcThbbljzdkQV2.get(3));
            AbstractPlatformRandom abstractPlatformRandom3 = Random.ADpl0noRbUAhY;
            arrayList.add(new MenuItemEntity(str13, str16, str14, str15, (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV11), (String) listJcThbbljzdkQV3.get(1), (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV4), XfQCOxz9Pm9BcT(listJcThbbljzdkQV5)));
        }
        for (Triple triple4 : listJcThbbljzdkQV9) {
            String str17 = (String) triple4.ADpl0noRbUAhY;
            String str18 = (String) triple4.AY1Ge095OJR8sU;
            String str19 = (String) triple4.R7447vqBon0A;
            String str20 = (String) listJcThbbljzdkQV.get(3);
            List listJcThbbljzdkQV12 = CollectionsKt.jcThbbljzdkQV(listJcThbbljzdkQV2.get(0), listJcThbbljzdkQV2.get(1));
            AbstractPlatformRandom abstractPlatformRandom4 = Random.ADpl0noRbUAhY;
            arrayList.add(new MenuItemEntity(str17, str20, str18, str19, (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV12), (String) listJcThbbljzdkQV3.get(3), (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV4), XfQCOxz9Pm9BcT(listJcThbbljzdkQV5)));
        }
        for (Triple triple5 : listJcThbbljzdkQV10) {
            String str21 = (String) triple5.ADpl0noRbUAhY;
            String str22 = (String) triple5.AY1Ge095OJR8sU;
            String str23 = (String) triple5.R7447vqBon0A;
            String str24 = (String) listJcThbbljzdkQV.get(4);
            List listJcThbbljzdkQV13 = CollectionsKt.jcThbbljzdkQV(listJcThbbljzdkQV2.get(1), listJcThbbljzdkQV2.get(2));
            AbstractPlatformRandom abstractPlatformRandom5 = Random.ADpl0noRbUAhY;
            arrayList.add(new MenuItemEntity(str21, str24, str22, str23, (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV13), (String) listJcThbbljzdkQV3.get(0), (String) CollectionsKt.PfW12hv02h7HZc(listJcThbbljzdkQV4), XfQCOxz9Pm9BcT(listJcThbbljzdkQV5)));
        }
        appRepository$seedDatabase$1.Ib3GalHLi1oFkSI = 2;
        return menuItemDao.f6FsnIUuKXgtm(arrayList, appRepository$seedDatabase$1) == coroutineSingletons ? coroutineSingletons : unit;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object f6FsnIUuKXgtm(long j, String str, ContinuationImpl continuationImpl) {
        AppRepository$updateNote$1 appRepository$updateNote$1;
        String str2;
        long j2 = j;
        if (continuationImpl instanceof AppRepository$updateNote$1) {
            appRepository$updateNote$1 = (AppRepository$updateNote$1) continuationImpl;
            int i = appRepository$updateNote$1.hargS3kTbQOR;
            if ((i & Integer.MIN_VALUE) != 0) {
                appRepository$updateNote$1.hargS3kTbQOR = i - Integer.MIN_VALUE;
            } else {
                appRepository$updateNote$1 = new AppRepository$updateNote$1(this, continuationImpl);
            }
        }
        Object obj = appRepository$updateNote$1.Ib3GalHLi1oFkSI;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i2 = appRepository$updateNote$1.hargS3kTbQOR;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        NoteDao noteDao = this.f6FsnIUuKXgtm;
        if (i2 == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            appRepository$updateNote$1.mhkN7GL0jG0Wg1w = str;
            appRepository$updateNote$1.Q5MXmkXGmrpQ = j2;
            appRepository$updateNote$1.hargS3kTbQOR = 1;
            Object objNzWQJjWwugl4VFs = noteDao.NzWQJjWwugl4VFs(j2, appRepository$updateNote$1);
            if (objNzWQJjWwugl4VFs != coroutineSingletons) {
                str2 = str;
                obj = objNzWQJjWwugl4VFs;
            }
            return coroutineSingletons;
        }
        if (i2 != 1) {
            if (i2 == 2) {
                ResultKt.NzWQJjWwugl4VFs(obj);
                return unit;
            }
            XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        j2 = appRepository$updateNote$1.Q5MXmkXGmrpQ;
        String str3 = appRepository$updateNote$1.mhkN7GL0jG0Wg1w;
        ResultKt.NzWQJjWwugl4VFs(obj);
        str2 = str3;
        NoteEntity noteEntity = (NoteEntity) obj;
        if (noteEntity != null) {
            long jCurrentTimeMillis = System.currentTimeMillis();
            long j3 = noteEntity.XfQCOxz9Pm9BcT;
            Long l = noteEntity.NzWQJjWwugl4VFs;
            str2.getClass();
            NoteEntity noteEntity2 = new NoteEntity(j3, l, str2, jCurrentTimeMillis);
            appRepository$updateNote$1.mhkN7GL0jG0Wg1w = null;
            appRepository$updateNote$1.Q5MXmkXGmrpQ = j2;
            appRepository$updateNote$1.hargS3kTbQOR = 2;
            if (noteDao.ADpl0noRbUAhY(noteEntity2, appRepository$updateNote$1) == coroutineSingletons) {
                return coroutineSingletons;
            }
        }
        return unit;
    }
}
