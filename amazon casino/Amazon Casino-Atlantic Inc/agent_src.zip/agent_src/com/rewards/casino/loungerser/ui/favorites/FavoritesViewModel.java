package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoritesViewModel;", "Landroidx/lifecycle/ViewModel;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoritesViewModel extends ViewModel {
    public final StateFlow ADpl0noRbUAhY;
    public final AppRepository NzWQJjWwugl4VFs;
    public final MutableStateFlow f6FsnIUuKXgtm;

    public FavoritesViewModel(AppRepository appRepository) {
        appRepository.getClass();
        this.NzWQJjWwugl4VFs = appRepository;
        EmptyList emptyList = EmptyList.ADpl0noRbUAhY;
        MutableStateFlow mutableStateFlowXfQCOxz9Pm9BcT = StateFlowKt.XfQCOxz9Pm9BcT(new FavoritesUiState(emptyList, emptyList, "", "All", false, null, null, null));
        this.f6FsnIUuKXgtm = mutableStateFlowXfQCOxz9Pm9BcT;
        this.ADpl0noRbUAhY = FlowKt.f6FsnIUuKXgtm(mutableStateFlowXfQCOxz9Pm9BcT);
        BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(this), null, null, new FavoritesViewModel$observeFavorites$1(this, null), 3);
    }

    public final void R7447vqBon0A(Function1 function1) {
        MutableStateFlow mutableStateFlow;
        Object value;
        FavoritesUiState favoritesUiState;
        List list;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
            favoritesUiState = (FavoritesUiState) function1.KT0nNGpxhUtad((FavoritesUiState) value);
            List list2 = FavoriteItemFilter.XfQCOxz9Pm9BcT;
            list = favoritesUiState.XfQCOxz9Pm9BcT;
            String str = favoritesUiState.f6FsnIUuKXgtm;
            String str2 = favoritesUiState.ADpl0noRbUAhY;
            list.getClass();
            if (!str2.equals("All")) {
                ArrayList arrayList = new ArrayList();
                for (Object obj : list) {
                    if (Intrinsics.XfQCOxz9Pm9BcT(((MenuItemEntity) obj).mhkN7GL0jG0Wg1w, str2)) {
                        arrayList.add(obj);
                    }
                }
                list = arrayList;
            }
            if (!StringsKt.plDIFW7uQvLLZ1(str)) {
                Locale locale = Locale.ENGLISH;
                locale.getClass();
                String lowerCase = str.toLowerCase(locale);
                lowerCase.getClass();
                ArrayList arrayList2 = new ArrayList();
                for (Object obj2 : list) {
                    MenuItemEntity menuItemEntity = (MenuItemEntity) obj2;
                    String str3 = menuItemEntity.NzWQJjWwugl4VFs;
                    Locale locale2 = Locale.ENGLISH;
                    locale2.getClass();
                    String lowerCase2 = str3.toLowerCase(locale2);
                    lowerCase2.getClass();
                    if (!StringsKt.AY1Ge095OJR8sU(lowerCase2, lowerCase, false)) {
                        String lowerCase3 = menuItemEntity.f6FsnIUuKXgtm.toLowerCase(locale2);
                        lowerCase3.getClass();
                        if (StringsKt.AY1Ge095OJR8sU(lowerCase3, lowerCase, false)) {
                        }
                    }
                    arrayList2.add(obj2);
                }
                list = arrayList2;
            }
        } while (!mutableStateFlow.R7447vqBon0A(value, FavoritesUiState.XfQCOxz9Pm9BcT(favoritesUiState, null, CollectionsKt.eqwJwm8oIiKHLs(list, new FavoriteItemFilter$apply$$inlined$sortedBy$1()), null, null, null, null, null, 509)));
    }
}
