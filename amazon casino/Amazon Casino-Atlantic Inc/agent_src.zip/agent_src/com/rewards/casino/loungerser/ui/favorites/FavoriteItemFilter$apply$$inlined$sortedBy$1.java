package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import java.util.Comparator;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.comparisons.ComparisonsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoriteItemFilter$apply$$inlined$sortedBy$1<T> implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        String str = ((MenuItemEntity) obj).NzWQJjWwugl4VFs;
        Locale locale = Locale.ENGLISH;
        locale.getClass();
        String lowerCase = str.toLowerCase(locale);
        lowerCase.getClass();
        String str2 = ((MenuItemEntity) obj2).NzWQJjWwugl4VFs;
        locale.getClass();
        String lowerCase2 = str2.toLowerCase(locale);
        lowerCase2.getClass();
        return ComparisonsKt.XfQCOxz9Pm9BcT(lowerCase, lowerCase2);
    }
}
