package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.BTSST24gkDbxl1;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$FavoritesScreenKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(-377911625, new BTSST24gkDbxl1(9), false);
    public static final ComposableLambdaImpl NzWQJjWwugl4VFs = new ComposableLambdaImpl(-261947079, new BTSST24gkDbxl1(10), false);
    public static final ComposableLambdaImpl f6FsnIUuKXgtm = new ComposableLambdaImpl(799750387, new BTSST24gkDbxl1(11), false);
    public static final ComposableLambdaImpl ADpl0noRbUAhY = new ComposableLambdaImpl(-702754207, new BTSST24gkDbxl1(12), false);
    public static final ComposableLambdaImpl AY1Ge095OJR8sU = new ComposableLambdaImpl(-1731926045, new BTSST24gkDbxl1(13), false);
    public static final ComposableLambdaImpl R7447vqBon0A = new ComposableLambdaImpl(1833011266, new BTSST24gkDbxl1(14), false);
}
