package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.FavoriteEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel$toggleFavorite$1", f = "MenuDetailViewModel.kt", l = {66, 68}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MenuDetailViewModel$toggleFavorite$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ MenuDetailViewModel Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ long uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MenuDetailViewModel$toggleFavorite$1(MenuDetailViewModel menuDetailViewModel, long j, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = menuDetailViewModel;
        this.uVptkJu9raq3 = j;
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x003d, code lost:
    
        if (r0 == r3) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0055, code lost:
    
        if (r0 == r3) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0057, code lost:
    
        return r3;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        MenuDetailViewModel menuDetailViewModel = this.Ib3GalHLi1oFkSI;
        MutableStateFlow mutableStateFlow = menuDetailViewModel.f6FsnIUuKXgtm;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            boolean z = ((MenuDetailUiState) mutableStateFlow.getValue()).NzWQJjWwugl4VFs;
            AppRepository appRepository = menuDetailViewModel.NzWQJjWwugl4VFs;
            long j = this.uVptkJu9raq3;
            if (z) {
                this.mhkN7GL0jG0Wg1w = 1;
                Object objADpl0noRbUAhY = appRepository.NzWQJjWwugl4VFs.ADpl0noRbUAhY(j, this);
                if (objADpl0noRbUAhY != coroutineSingletons) {
                    objADpl0noRbUAhY = unit;
                }
            } else {
                this.mhkN7GL0jG0Wg1w = 2;
                Object objF6FsnIUuKXgtm = appRepository.NzWQJjWwugl4VFs.f6FsnIUuKXgtm(new FavoriteEntity(j, System.currentTimeMillis()), this);
                if (objF6FsnIUuKXgtm != coroutineSingletons) {
                    objF6FsnIUuKXgtm = unit;
                }
            }
        } else {
            if (i != 1 && i != 2) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value, null, !r8.NzWQJjWwugl4VFs, null, false, false, null, null, null, 509)));
        return unit;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((MenuDetailViewModel$toggleFavorite$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MenuDetailViewModel$toggleFavorite$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, continuation);
    }
}
