package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuScreenKt$MenuScreen$lambda$6$0$4$0$$inlined$items$default$2 implements Function1<Integer, Object> {
    @Override // kotlin.jvm.functions.Function1
    public final Object KT0nNGpxhUtad(Object obj) {
        ((Number) obj).intValue();
        throw null;
    }
}
