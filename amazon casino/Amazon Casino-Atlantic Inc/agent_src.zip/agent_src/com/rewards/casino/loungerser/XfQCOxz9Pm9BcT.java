package com.rewards.casino.loungerser;

import androidx.compose.material3.DrawerState;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final /* synthetic */ class XfQCOxz9Pm9BcT implements Function0 {
    public final /* synthetic */ int ADpl0noRbUAhY;
    public final /* synthetic */ CoroutineScope AY1Ge095OJR8sU;
    public final /* synthetic */ DrawerState R7447vqBon0A;

    public /* synthetic */ XfQCOxz9Pm9BcT(CoroutineScope coroutineScope, DrawerState drawerState, int i) {
        this.ADpl0noRbUAhY = i;
        this.AY1Ge095OJR8sU = coroutineScope;
        this.R7447vqBon0A = drawerState;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object NzWQJjWwugl4VFs() {
        int i = this.ADpl0noRbUAhY;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        DrawerState drawerState = this.R7447vqBon0A;
        CoroutineScope coroutineScope = this.AY1Ge095OJR8sU;
        switch (i) {
            case 0:
                BuildersKt.NzWQJjWwugl4VFs(coroutineScope, null, null, new MainActivityKt$MainScreen$2$1$2$1$1$1(drawerState, null), 3);
                break;
            default:
                BuildersKt.NzWQJjWwugl4VFs(coroutineScope, null, null, new MainActivityKt$MainScreen$2$2$1$1$1$1(drawerState, null), 3);
                break;
        }
        return unit;
    }
}
