package com.rewards.casino.loungerser.ui.theme;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.Typography;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class TypeKt {
    public static final Typography XfQCOxz9Pm9BcT;

    static {
        FontWeight fontWeight = FontWeight.mhkN7GL0jG0Wg1w;
        XfQCOxz9Pm9BcT = new Typography(new TextStyle(0L, TextUnitKt.f6FsnIUuKXgtm(16), fontWeight, TextUnitKt.NzWQJjWwugl4VFs(0.5d), 0L, 0, 0, TextUnitKt.f6FsnIUuKXgtm(24), 16645977), 32255);
    }
}
