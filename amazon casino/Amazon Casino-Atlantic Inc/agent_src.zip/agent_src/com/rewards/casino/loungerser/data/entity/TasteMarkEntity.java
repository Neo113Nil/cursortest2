package com.rewards.casino.loungerser.data.entity;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.Sq4Z9oOaVh4F;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/entity/TasteMarkEntity;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class TasteMarkEntity {
    public final String ADpl0noRbUAhY;
    public final long AY1Ge095OJR8sU;
    public final long NzWQJjWwugl4VFs;
    public final long XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;

    public TasteMarkEntity(long j, long j2, String str, String str2, long j3) {
        str.getClass();
        str2.getClass();
        this.XfQCOxz9Pm9BcT = j;
        this.NzWQJjWwugl4VFs = j2;
        this.f6FsnIUuKXgtm = str;
        this.ADpl0noRbUAhY = str2;
        this.AY1Ge095OJR8sU = j3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TasteMarkEntity)) {
            return false;
        }
        TasteMarkEntity tasteMarkEntity = (TasteMarkEntity) obj;
        return this.XfQCOxz9Pm9BcT == tasteMarkEntity.XfQCOxz9Pm9BcT && this.NzWQJjWwugl4VFs == tasteMarkEntity.NzWQJjWwugl4VFs && Intrinsics.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, tasteMarkEntity.f6FsnIUuKXgtm) && Intrinsics.XfQCOxz9Pm9BcT(this.ADpl0noRbUAhY, tasteMarkEntity.ADpl0noRbUAhY) && this.AY1Ge095OJR8sU == tasteMarkEntity.AY1Ge095OJR8sU;
    }

    public final int hashCode() {
        return Long.hashCode(this.AY1Ge095OJR8sU) + v6.NzWQJjWwugl4VFs(this.ADpl0noRbUAhY, v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, Sq4Z9oOaVh4F.f6FsnIUuKXgtm(Long.hashCode(this.XfQCOxz9Pm9BcT) * 31, 31, this.NzWQJjWwugl4VFs), 31), 31);
    }

    public final String toString() {
        return "TasteMarkEntity(id=" + this.XfQCOxz9Pm9BcT + ", menuItemId=" + this.NzWQJjWwugl4VFs + ", value=" + this.f6FsnIUuKXgtm + ", label=" + this.ADpl0noRbUAhY + ", timestamp=" + this.AY1Ge095OJR8sU + ")";
    }
}
