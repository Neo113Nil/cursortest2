package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/notes/NoteDetailUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class NoteDetailUiState {
    public final boolean ADpl0noRbUAhY;
    public final String AY1Ge095OJR8sU;
    public final String NzWQJjWwugl4VFs;
    public final boolean Q5MXmkXGmrpQ;
    public final String R7447vqBon0A;
    public final NoteEntity XfQCOxz9Pm9BcT;
    public final boolean f6FsnIUuKXgtm;

    public NoteDetailUiState(NoteEntity noteEntity, String str, boolean z, boolean z2, String str2, String str3, boolean z3) {
        this.XfQCOxz9Pm9BcT = noteEntity;
        this.NzWQJjWwugl4VFs = str;
        this.f6FsnIUuKXgtm = z;
        this.ADpl0noRbUAhY = z2;
        this.AY1Ge095OJR8sU = str2;
        this.R7447vqBon0A = str3;
        this.Q5MXmkXGmrpQ = z3;
    }

    public static NoteDetailUiState XfQCOxz9Pm9BcT(NoteDetailUiState noteDetailUiState, NoteEntity noteEntity, String str, boolean z, String str2, String str3, boolean z2, int i) {
        if ((i & 1) != 0) {
            noteEntity = noteDetailUiState.XfQCOxz9Pm9BcT;
        }
        NoteEntity noteEntity2 = noteEntity;
        if ((i & 2) != 0) {
            str = noteDetailUiState.NzWQJjWwugl4VFs;
        }
        String str4 = str;
        boolean z3 = (i & 4) != 0 ? noteDetailUiState.f6FsnIUuKXgtm : false;
        noteDetailUiState.getClass();
        if ((i & 16) != 0) {
            z = noteDetailUiState.ADpl0noRbUAhY;
        }
        boolean z4 = z;
        if ((i & 32) != 0) {
            str2 = noteDetailUiState.AY1Ge095OJR8sU;
        }
        String str5 = str2;
        if ((i & 64) != 0) {
            str3 = noteDetailUiState.R7447vqBon0A;
        }
        String str6 = str3;
        if ((i & 128) != 0) {
            z2 = noteDetailUiState.Q5MXmkXGmrpQ;
        }
        noteDetailUiState.getClass();
        str4.getClass();
        str5.getClass();
        return new NoteDetailUiState(noteEntity2, str4, z3, z4, str5, str6, z2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NoteDetailUiState)) {
            return false;
        }
        NoteDetailUiState noteDetailUiState = (NoteDetailUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, noteDetailUiState.XfQCOxz9Pm9BcT) && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, noteDetailUiState.NzWQJjWwugl4VFs) && this.f6FsnIUuKXgtm == noteDetailUiState.f6FsnIUuKXgtm && this.ADpl0noRbUAhY == noteDetailUiState.ADpl0noRbUAhY && Intrinsics.XfQCOxz9Pm9BcT(this.AY1Ge095OJR8sU, noteDetailUiState.AY1Ge095OJR8sU) && Intrinsics.XfQCOxz9Pm9BcT(this.R7447vqBon0A, noteDetailUiState.R7447vqBon0A) && this.Q5MXmkXGmrpQ == noteDetailUiState.Q5MXmkXGmrpQ;
    }

    public final int hashCode() {
        NoteEntity noteEntity = this.XfQCOxz9Pm9BcT;
        int iNzWQJjWwugl4VFs = v6.NzWQJjWwugl4VFs(this.AY1Ge095OJR8sU, v6.XfQCOxz9Pm9BcT(v6.XfQCOxz9Pm9BcT(v6.NzWQJjWwugl4VFs(this.NzWQJjWwugl4VFs, (noteEntity == null ? 0 : noteEntity.hashCode()) * 31, 31), 961, this.f6FsnIUuKXgtm), 31, this.ADpl0noRbUAhY), 31);
        String str = this.R7447vqBon0A;
        return Boolean.hashCode(this.Q5MXmkXGmrpQ) + ((iNzWQJjWwugl4VFs + (str != null ? str.hashCode() : 0)) * 31);
    }

    public final String toString() {
        return "NoteDetailUiState(note=" + this.XfQCOxz9Pm9BcT + ", itemName=" + this.NzWQJjWwugl4VFs + ", isLoading=" + this.f6FsnIUuKXgtm + ", error=null, showEditDialog=" + this.ADpl0noRbUAhY + ", editText=" + this.AY1Ge095OJR8sU + ", editTextError=" + this.R7447vqBon0A + ", showDeleteConfirmation=" + this.Q5MXmkXGmrpQ + ")";
    }

    public /* synthetic */ NoteDetailUiState(int i) {
        this(null, "", true, false, "", null, false);
    }
}
