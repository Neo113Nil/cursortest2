package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.BTSST24gkDbxl1;
import defpackage.jpgeID8zMPb9;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$MenuScreenKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(-304351244, new BTSST24gkDbxl1(18), false);
    public static final ComposableLambdaImpl NzWQJjWwugl4VFs = new ComposableLambdaImpl(-321638794, new BTSST24gkDbxl1(19), false);
    public static final ComposableLambdaImpl f6FsnIUuKXgtm = new ComposableLambdaImpl(-1237732816, new BTSST24gkDbxl1(20), false);
    public static final ComposableLambdaImpl ADpl0noRbUAhY = new ComposableLambdaImpl(-538803286, new BTSST24gkDbxl1(21), false);
    public static final ComposableLambdaImpl AY1Ge095OJR8sU = new ComposableLambdaImpl(-1749172242, new BTSST24gkDbxl1(22), false);
    public static final ComposableLambdaImpl R7447vqBon0A = new ComposableLambdaImpl(1848025010, new jpgeID8zMPb9(9), false);
    public static final ComposableLambdaImpl Q5MXmkXGmrpQ = new ComposableLambdaImpl(1652836328, new jpgeID8zMPb9(10), false);
    public static final ComposableLambdaImpl mhkN7GL0jG0Wg1w = new ComposableLambdaImpl(-1993538198, new jpgeID8zMPb9(11), false);
    public static final ComposableLambdaImpl Ib3GalHLi1oFkSI = new ComposableLambdaImpl(1284680623, new BTSST24gkDbxl1(23), false);
    public static final ComposableLambdaImpl uVptkJu9raq3 = new ComposableLambdaImpl(1743926666, new BTSST24gkDbxl1(24), false);
}
