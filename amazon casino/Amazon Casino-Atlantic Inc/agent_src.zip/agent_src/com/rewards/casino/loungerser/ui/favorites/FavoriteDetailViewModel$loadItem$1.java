package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.datastore.preferences.protobuf.DescriptorProtos;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.favorites.FavoriteDetailViewModel$loadItem$1", f = "FavoriteDetailViewModel.kt", l = {DescriptorProtos.FileOptions.SWIFT_PREFIX_FIELD_NUMBER}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class FavoriteDetailViewModel$loadItem$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ FavoriteDetailViewModel Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ long uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FavoriteDetailViewModel$loadItem$1(FavoriteDetailViewModel favoriteDetailViewModel, long j, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = favoriteDetailViewModel;
        this.uVptkJu9raq3 = j;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        Object value2;
        FavoriteDetailViewModel favoriteDetailViewModel = this.Ib3GalHLi1oFkSI;
        MutableStateFlow mutableStateFlow = favoriteDetailViewModel.f6FsnIUuKXgtm;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, FavoriteDetailUiState.XfQCOxz9Pm9BcT((FavoriteDetailUiState) value, null, true, false, 13)));
            AppRepository appRepository = favoriteDetailViewModel.NzWQJjWwugl4VFs;
            this.mhkN7GL0jG0Wg1w = 1;
            obj = appRepository.XfQCOxz9Pm9BcT.NzWQJjWwugl4VFs(this.uVptkJu9raq3, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        MenuItemEntity menuItemEntity = (MenuItemEntity) obj;
        do {
            value2 = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value2, FavoriteDetailUiState.XfQCOxz9Pm9BcT((FavoriteDetailUiState) value2, menuItemEntity, false, false, 12)));
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((FavoriteDetailViewModel$loadItem$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new FavoriteDetailViewModel$loadItem$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, continuation);
    }
}
