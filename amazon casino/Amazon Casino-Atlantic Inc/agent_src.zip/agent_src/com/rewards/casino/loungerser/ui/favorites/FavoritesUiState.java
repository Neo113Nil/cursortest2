package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.v6;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoritesUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class FavoritesUiState {
    public final String ADpl0noRbUAhY;
    public final boolean AY1Ge095OJR8sU;
    public final List NzWQJjWwugl4VFs;
    public final FavoriteSnackbarMessage Q5MXmkXGmrpQ;
    public final Long R7447vqBon0A;
    public final List XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;
    public final String mhkN7GL0jG0Wg1w;

    public FavoritesUiState(List list, List list2, String str, String str2, boolean z, Long l, FavoriteSnackbarMessage favoriteSnackbarMessage, String str3) {
        list.getClass();
        list2.getClass();
        this.XfQCOxz9Pm9BcT = list;
        this.NzWQJjWwugl4VFs = list2;
        this.f6FsnIUuKXgtm = str;
        this.ADpl0noRbUAhY = str2;
        this.AY1Ge095OJR8sU = z;
        this.R7447vqBon0A = l;
        this.Q5MXmkXGmrpQ = favoriteSnackbarMessage;
        this.mhkN7GL0jG0Wg1w = str3;
    }

    public static FavoritesUiState XfQCOxz9Pm9BcT(FavoritesUiState favoritesUiState, List list, List list2, String str, String str2, Long l, FavoriteSnackbarMessage favoriteSnackbarMessage, String str3, int i) {
        if ((i & 1) != 0) {
            list = favoritesUiState.XfQCOxz9Pm9BcT;
        }
        List list3 = list;
        if ((i & 2) != 0) {
            list2 = favoritesUiState.NzWQJjWwugl4VFs;
        }
        List list4 = list2;
        if ((i & 4) != 0) {
            str = favoritesUiState.f6FsnIUuKXgtm;
        }
        String str4 = str;
        if ((i & 8) != 0) {
            str2 = favoritesUiState.ADpl0noRbUAhY;
        }
        String str5 = str2;
        boolean z = (i & 16) != 0 ? favoritesUiState.AY1Ge095OJR8sU : false;
        favoritesUiState.getClass();
        if ((i & 64) != 0) {
            l = favoritesUiState.R7447vqBon0A;
        }
        Long l2 = l;
        if ((i & 128) != 0) {
            favoriteSnackbarMessage = favoritesUiState.Q5MXmkXGmrpQ;
        }
        FavoriteSnackbarMessage favoriteSnackbarMessage2 = favoriteSnackbarMessage;
        String str6 = (i & 256) != 0 ? favoritesUiState.mhkN7GL0jG0Wg1w : str3;
        favoritesUiState.getClass();
        list3.getClass();
        list4.getClass();
        str4.getClass();
        str5.getClass();
        return new FavoritesUiState(list3, list4, str4, str5, z, l2, favoriteSnackbarMessage2, str6);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FavoritesUiState)) {
            return false;
        }
        FavoritesUiState favoritesUiState = (FavoritesUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, favoritesUiState.XfQCOxz9Pm9BcT) && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, favoritesUiState.NzWQJjWwugl4VFs) && this.f6FsnIUuKXgtm.equals(favoritesUiState.f6FsnIUuKXgtm) && this.ADpl0noRbUAhY.equals(favoritesUiState.ADpl0noRbUAhY) && this.AY1Ge095OJR8sU == favoritesUiState.AY1Ge095OJR8sU && Intrinsics.XfQCOxz9Pm9BcT(this.R7447vqBon0A, favoritesUiState.R7447vqBon0A) && this.Q5MXmkXGmrpQ == favoritesUiState.Q5MXmkXGmrpQ && Intrinsics.XfQCOxz9Pm9BcT(this.mhkN7GL0jG0Wg1w, favoritesUiState.mhkN7GL0jG0Wg1w);
    }

    public final int hashCode() {
        int iXfQCOxz9Pm9BcT = v6.XfQCOxz9Pm9BcT(v6.NzWQJjWwugl4VFs(this.ADpl0noRbUAhY, v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, (this.NzWQJjWwugl4VFs.hashCode() + (this.XfQCOxz9Pm9BcT.hashCode() * 31)) * 31, 31), 31), 961, this.AY1Ge095OJR8sU);
        Long l = this.R7447vqBon0A;
        int iHashCode = (iXfQCOxz9Pm9BcT + (l == null ? 0 : l.hashCode())) * 31;
        FavoriteSnackbarMessage favoriteSnackbarMessage = this.Q5MXmkXGmrpQ;
        int iHashCode2 = (iHashCode + (favoriteSnackbarMessage == null ? 0 : favoriteSnackbarMessage.hashCode())) * 31;
        String str = this.mhkN7GL0jG0Wg1w;
        return iHashCode2 + (str != null ? str.hashCode() : 0);
    }

    public final String toString() {
        return "FavoritesUiState(allFavorites=" + this.XfQCOxz9Pm9BcT + ", filteredFavorites=" + this.NzWQJjWwugl4VFs + ", searchQuery=" + this.f6FsnIUuKXgtm + ", selectedRegion=" + this.ADpl0noRbUAhY + ", isLoading=" + this.AY1Ge095OJR8sU + ", error=null, selectedItemId=" + this.R7447vqBon0A + ", snackbarMessage=" + this.Q5MXmkXGmrpQ + ", snackbarArgument=" + this.mhkN7GL0jG0Wg1w + ")";
    }
}
