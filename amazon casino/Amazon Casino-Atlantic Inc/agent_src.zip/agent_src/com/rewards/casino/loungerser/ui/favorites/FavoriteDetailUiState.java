package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoriteDetailUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class FavoriteDetailUiState {
    public final boolean NzWQJjWwugl4VFs;
    public final MenuItemEntity XfQCOxz9Pm9BcT;
    public final boolean f6FsnIUuKXgtm;

    public FavoriteDetailUiState(MenuItemEntity menuItemEntity, boolean z, boolean z2) {
        this.XfQCOxz9Pm9BcT = menuItemEntity;
        this.NzWQJjWwugl4VFs = z;
        this.f6FsnIUuKXgtm = z2;
    }

    public static FavoriteDetailUiState XfQCOxz9Pm9BcT(FavoriteDetailUiState favoriteDetailUiState, MenuItemEntity menuItemEntity, boolean z, boolean z2, int i) {
        if ((i & 1) != 0) {
            menuItemEntity = favoriteDetailUiState.XfQCOxz9Pm9BcT;
        }
        if ((i & 2) != 0) {
            z = favoriteDetailUiState.NzWQJjWwugl4VFs;
        }
        favoriteDetailUiState.getClass();
        if ((i & 8) != 0) {
            z2 = favoriteDetailUiState.f6FsnIUuKXgtm;
        }
        favoriteDetailUiState.getClass();
        return new FavoriteDetailUiState(menuItemEntity, z, z2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FavoriteDetailUiState)) {
            return false;
        }
        FavoriteDetailUiState favoriteDetailUiState = (FavoriteDetailUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, favoriteDetailUiState.XfQCOxz9Pm9BcT) && this.NzWQJjWwugl4VFs == favoriteDetailUiState.NzWQJjWwugl4VFs && this.f6FsnIUuKXgtm == favoriteDetailUiState.f6FsnIUuKXgtm;
    }

    public final int hashCode() {
        MenuItemEntity menuItemEntity = this.XfQCOxz9Pm9BcT;
        return Boolean.hashCode(this.f6FsnIUuKXgtm) + v6.XfQCOxz9Pm9BcT((menuItemEntity == null ? 0 : menuItemEntity.hashCode()) * 31, 961, this.NzWQJjWwugl4VFs);
    }

    public final String toString() {
        return "FavoriteDetailUiState(item=" + this.XfQCOxz9Pm9BcT + ", isLoading=" + this.NzWQJjWwugl4VFs + ", error=null, showRemoveConfirmation=" + this.f6FsnIUuKXgtm + ")";
    }
}
