package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.foundation.layout.WindowInsetsKt;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.AndroidAlertDialog_androidKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.Composer$Companion$Empty$1;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import defpackage.BP5ZuwkznkVwnNY;
import defpackage.FLMntEtk8XkIet1;
import defpackage.jIAALsBkQIUpNq8;
import defpackage.l0;
import defpackage.m0;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Reflection;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0002¨\u0006\u0002²\u0006\f\u0010\u0001\u001a\u00020\u00008\nX\u008a\u0084\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoriteDetailUiState;", "state", "app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoriteDetailScreenKt {
    public static final void XfQCOxz9Pm9BcT(long j, Function0 function0, FavoriteDetailViewModel favoriteDetailViewModel, Composer composer, int i) {
        Composer composer2;
        FavoriteDetailViewModel favoriteDetailViewModel2;
        int i2;
        FavoriteDetailViewModel favoriteDetailViewModel3;
        function0.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(1587644484);
        int i3 = i | (composerPIQ5UlgpXmpV.KT0nNGpxhUtad(j) ? 4 : 2) | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function0) ? 32 : 16) | 128;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i3 & 1, (i3 & 147) != 146)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                } else {
                    FavoriteDetailViewModel favoriteDetailViewModel4 = (FavoriteDetailViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(FavoriteDetailViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
                    i2 = i3 & (-897);
                    favoriteDetailViewModel3 = favoriteDetailViewModel4;
                }
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                i2 = i3 & (-897);
                favoriteDetailViewModel3 = favoriteDetailViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(favoriteDetailViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            Long lValueOf = Long.valueOf(j);
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(favoriteDetailViewModel3) | ((i2 & 14) == 4);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Composer$Companion$Empty$1 composer$Companion$Empty$1 = Composer.Companion.XfQCOxz9Pm9BcT;
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq3 == composer$Companion$Empty$1) {
                objUVptkJu9raq3 = new FavoriteDetailScreenKt$FavoriteDetailScreen$1$1(favoriteDetailViewModel3, j, null);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, lValueOf, (Function2) objUVptkJu9raq3);
            WindowInsets windowInsetsXfQCOxz9Pm9BcT = WindowInsetsKt.XfQCOxz9Pm9BcT();
            ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs = ComposableLambdaKt.NzWQJjWwugl4VFs(1991414528, new jIAALsBkQIUpNq8(7, mutableStateXfQCOxz9Pm9BcT, function0), composerPIQ5UlgpXmpV);
            ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs2 = ComposableLambdaKt.NzWQJjWwugl4VFs(-369433387, new BP5ZuwkznkVwnNY(2, mutableStateXfQCOxz9Pm9BcT, favoriteDetailViewModel3), composerPIQ5UlgpXmpV);
            favoriteDetailViewModel2 = favoriteDetailViewModel3;
            ScaffoldKt.XfQCOxz9Pm9BcT(null, composableLambdaImplNzWQJjWwugl4VFs, null, null, null, 0, 0L, 0L, windowInsetsXfQCOxz9Pm9BcT, composableLambdaImplNzWQJjWwugl4VFs2, composerPIQ5UlgpXmpV, 805306416, 253);
            composer2 = composerPIQ5UlgpXmpV;
            if (((FavoriteDetailUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).f6FsnIUuKXgtm) {
                composer2.Y9lRRazOjmFYx(1348742363);
                boolean zOqhsKX67fcZ7qq2 = composer2.oqhsKX67fcZ7qq(favoriteDetailViewModel2);
                Object objUVptkJu9raq32 = composer2.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq32 == composer$Companion$Empty$1) {
                    objUVptkJu9raq32 = new m0(favoriteDetailViewModel2, 2);
                    composer2.jcThbbljzdkQV(objUVptkJu9raq32);
                }
                AndroidAlertDialog_androidKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq32, ComposableLambdaKt.NzWQJjWwugl4VFs(223930705, new jIAALsBkQIUpNq8(6, favoriteDetailViewModel2, function0), composer2), null, ComposableLambdaKt.NzWQJjWwugl4VFs(751324755, new FLMntEtk8XkIet1(7, favoriteDetailViewModel2), composer2), ComposableSingletons$FavoriteDetailScreenKt.AY1Ge095OJR8sU, ComposableSingletons$FavoriteDetailScreenKt.R7447vqBon0A, null, 0L, 0L, 0L, 0L, null, composer2, 1772592);
                composer2 = composer2;
                composer2.V02FBF0Ulcpcy();
            } else {
                composer2.Y9lRRazOjmFYx(1349544798);
                composer2.V02FBF0Ulcpcy();
            }
        } else {
            composer2 = composerPIQ5UlgpXmpV;
            composer2.R7447vqBon0A();
            favoriteDetailViewModel2 = favoriteDetailViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composer2.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new l0(j, function0, favoriteDetailViewModel2, i, 0));
        }
    }
}
