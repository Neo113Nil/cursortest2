package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel$loadNote$1", f = "NoteDetailViewModel.kt", l = {WindowInsetsSides.R7447vqBon0A, 50}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NoteDetailViewModel$loadNote$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public int Ib3GalHLi1oFkSI;
    public final /* synthetic */ long hargS3kTbQOR;
    public NoteEntity mhkN7GL0jG0Wg1w;
    public final /* synthetic */ NoteDetailViewModel uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NoteDetailViewModel$loadNote$1(NoteDetailViewModel noteDetailViewModel, long j, Continuation continuation) {
        super(2, continuation);
        this.uVptkJu9raq3 = noteDetailViewModel;
        this.hargS3kTbQOR = j;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x006f  */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object HDXQYm0hWNKDrl(Object obj) {
        NoteEntity noteEntity;
        Long l;
        NoteEntity noteEntity2;
        Object value;
        NoteDetailViewModel noteDetailViewModel = this.uVptkJu9raq3;
        AppRepository appRepository = noteDetailViewModel.NzWQJjWwugl4VFs;
        MutableStateFlow mutableStateFlow = noteDetailViewModel.f6FsnIUuKXgtm;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.Ib3GalHLi1oFkSI;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            mutableStateFlow.setValue(new NoteDetailUiState(251));
            this.Ib3GalHLi1oFkSI = 1;
            obj = appRepository.f6FsnIUuKXgtm.NzWQJjWwugl4VFs(this.hargS3kTbQOR, this);
            if (obj != coroutineSingletons) {
            }
            return coroutineSingletons;
        }
        if (i != 1) {
            if (i != 2) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            noteEntity2 = this.mhkN7GL0jG0Wg1w;
            ResultKt.NzWQJjWwugl4VFs(obj);
            MenuItemEntity menuItemEntity = (MenuItemEntity) obj;
            str = menuItemEntity != null ? menuItemEntity.NzWQJjWwugl4VFs : null;
            noteEntity = noteEntity2;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value, noteEntity, str == null ? "" : str, false, null, null, false, 248)));
            return Unit.XfQCOxz9Pm9BcT;
        }
        ResultKt.NzWQJjWwugl4VFs(obj);
        NoteEntity noteEntity3 = (NoteEntity) obj;
        if (noteEntity3 == null || (l = noteEntity3.NzWQJjWwugl4VFs) == null) {
            noteEntity = noteEntity3;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value, noteEntity, str == null ? "" : str, false, null, null, false, 248)));
            return Unit.XfQCOxz9Pm9BcT;
        }
        long jLongValue = l.longValue();
        this.mhkN7GL0jG0Wg1w = noteEntity3;
        this.Ib3GalHLi1oFkSI = 2;
        Object objNzWQJjWwugl4VFs = appRepository.XfQCOxz9Pm9BcT.NzWQJjWwugl4VFs(jLongValue, this);
        if (objNzWQJjWwugl4VFs != coroutineSingletons) {
            obj = objNzWQJjWwugl4VFs;
            noteEntity2 = noteEntity3;
            MenuItemEntity menuItemEntity2 = (MenuItemEntity) obj;
            if (menuItemEntity2 != null) {
            }
            noteEntity = noteEntity2;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value, noteEntity, str == null ? "" : str, false, null, null, false, 248)));
            return Unit.XfQCOxz9Pm9BcT;
        }
        return coroutineSingletons;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NoteDetailViewModel$loadNote$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NoteDetailViewModel$loadNote$1(this.uVptkJu9raq3, this.hargS3kTbQOR, continuation);
    }
}
