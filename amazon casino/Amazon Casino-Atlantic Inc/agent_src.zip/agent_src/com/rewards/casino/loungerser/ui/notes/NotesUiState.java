package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.v6;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/notes/NotesUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class NotesUiState {
    public final boolean ADpl0noRbUAhY;
    public final Long AY1Ge095OJR8sU;
    public final String Ib3GalHLi1oFkSI;
    public final NoteSnackbarMessage KT0nNGpxhUtad;
    public final List NzWQJjWwugl4VFs;
    public final boolean Q5MXmkXGmrpQ;
    public final Set R7447vqBon0A;
    public final List XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;
    public final NoteTextError hargS3kTbQOR;
    public final boolean jtRrC0njHlFmpd;
    public final boolean mhkN7GL0jG0Wg1w;
    public final Long uVptkJu9raq3;

    public NotesUiState(List list, List list2, String str, boolean z, Long l, Set set, boolean z2, boolean z3, String str2, Long l2, NoteTextError noteTextError, boolean z4, NoteSnackbarMessage noteSnackbarMessage) {
        list.getClass();
        list2.getClass();
        set.getClass();
        this.XfQCOxz9Pm9BcT = list;
        this.NzWQJjWwugl4VFs = list2;
        this.f6FsnIUuKXgtm = str;
        this.ADpl0noRbUAhY = z;
        this.AY1Ge095OJR8sU = l;
        this.R7447vqBon0A = set;
        this.Q5MXmkXGmrpQ = z2;
        this.mhkN7GL0jG0Wg1w = z3;
        this.Ib3GalHLi1oFkSI = str2;
        this.uVptkJu9raq3 = l2;
        this.hargS3kTbQOR = noteTextError;
        this.jtRrC0njHlFmpd = z4;
        this.KT0nNGpxhUtad = noteSnackbarMessage;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r15v23, types: [java.util.Set] */
    public static NotesUiState XfQCOxz9Pm9BcT(NotesUiState notesUiState, List list, List list2, String str, Long l, LinkedHashSet linkedHashSet, boolean z, boolean z2, String str2, Long l2, NoteTextError noteTextError, boolean z3, NoteSnackbarMessage noteSnackbarMessage, int i) {
        if ((i & 1) != 0) {
            list = notesUiState.XfQCOxz9Pm9BcT;
        }
        List list3 = list;
        List list4 = (i & 2) != 0 ? notesUiState.NzWQJjWwugl4VFs : list2;
        String str3 = (i & 4) != 0 ? notesUiState.f6FsnIUuKXgtm : str;
        boolean z4 = (i & 8) != 0 ? notesUiState.ADpl0noRbUAhY : false;
        notesUiState.getClass();
        Long l3 = (i & 32) != 0 ? notesUiState.AY1Ge095OJR8sU : l;
        LinkedHashSet linkedHashSet2 = (i & 64) != 0 ? notesUiState.R7447vqBon0A : linkedHashSet;
        boolean z5 = (i & 128) != 0 ? notesUiState.Q5MXmkXGmrpQ : z;
        boolean z6 = (i & 256) != 0 ? notesUiState.mhkN7GL0jG0Wg1w : z2;
        String str4 = (i & 512) != 0 ? notesUiState.Ib3GalHLi1oFkSI : str2;
        Long l4 = (i & 1024) != 0 ? notesUiState.uVptkJu9raq3 : l2;
        NoteTextError noteTextError2 = (i & 2048) != 0 ? notesUiState.hargS3kTbQOR : noteTextError;
        boolean z7 = (i & 4096) != 0 ? notesUiState.jtRrC0njHlFmpd : z3;
        NoteSnackbarMessage noteSnackbarMessage2 = (i & 8192) != 0 ? notesUiState.KT0nNGpxhUtad : noteSnackbarMessage;
        notesUiState.getClass();
        list3.getClass();
        list4.getClass();
        str3.getClass();
        linkedHashSet2.getClass();
        str4.getClass();
        return new NotesUiState(list3, list4, str3, z4, l3, linkedHashSet2, z5, z6, str4, l4, noteTextError2, z7, noteSnackbarMessage2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NotesUiState)) {
            return false;
        }
        NotesUiState notesUiState = (NotesUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, notesUiState.XfQCOxz9Pm9BcT) && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, notesUiState.NzWQJjWwugl4VFs) && this.f6FsnIUuKXgtm.equals(notesUiState.f6FsnIUuKXgtm) && this.ADpl0noRbUAhY == notesUiState.ADpl0noRbUAhY && Intrinsics.XfQCOxz9Pm9BcT(this.AY1Ge095OJR8sU, notesUiState.AY1Ge095OJR8sU) && Intrinsics.XfQCOxz9Pm9BcT(this.R7447vqBon0A, notesUiState.R7447vqBon0A) && this.Q5MXmkXGmrpQ == notesUiState.Q5MXmkXGmrpQ && this.mhkN7GL0jG0Wg1w == notesUiState.mhkN7GL0jG0Wg1w && this.Ib3GalHLi1oFkSI.equals(notesUiState.Ib3GalHLi1oFkSI) && Intrinsics.XfQCOxz9Pm9BcT(this.uVptkJu9raq3, notesUiState.uVptkJu9raq3) && this.hargS3kTbQOR == notesUiState.hargS3kTbQOR && this.jtRrC0njHlFmpd == notesUiState.jtRrC0njHlFmpd && this.KT0nNGpxhUtad == notesUiState.KT0nNGpxhUtad;
    }

    public final int hashCode() {
        int iXfQCOxz9Pm9BcT = v6.XfQCOxz9Pm9BcT(v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, (this.NzWQJjWwugl4VFs.hashCode() + (this.XfQCOxz9Pm9BcT.hashCode() * 31)) * 31, 31), 961, this.ADpl0noRbUAhY);
        Long l = this.AY1Ge095OJR8sU;
        int iNzWQJjWwugl4VFs = v6.NzWQJjWwugl4VFs(this.Ib3GalHLi1oFkSI, v6.XfQCOxz9Pm9BcT(v6.XfQCOxz9Pm9BcT((this.R7447vqBon0A.hashCode() + ((iXfQCOxz9Pm9BcT + (l == null ? 0 : l.hashCode())) * 31)) * 31, 31, this.Q5MXmkXGmrpQ), 31, this.mhkN7GL0jG0Wg1w), 31);
        Long l2 = this.uVptkJu9raq3;
        int iHashCode = (iNzWQJjWwugl4VFs + (l2 == null ? 0 : l2.hashCode())) * 31;
        NoteTextError noteTextError = this.hargS3kTbQOR;
        int iXfQCOxz9Pm9BcT2 = v6.XfQCOxz9Pm9BcT((iHashCode + (noteTextError == null ? 0 : noteTextError.hashCode())) * 31, 31, this.jtRrC0njHlFmpd);
        NoteSnackbarMessage noteSnackbarMessage = this.KT0nNGpxhUtad;
        return iXfQCOxz9Pm9BcT2 + (noteSnackbarMessage != null ? noteSnackbarMessage.hashCode() : 0);
    }

    public final String toString() {
        return "NotesUiState(notes=" + this.XfQCOxz9Pm9BcT + ", menuItems=" + this.NzWQJjWwugl4VFs + ", selectedSort=" + this.f6FsnIUuKXgtm + ", isLoading=" + this.ADpl0noRbUAhY + ", error=null, selectedNoteId=" + this.AY1Ge095OJR8sU + ", expandedNoteIds=" + this.R7447vqBon0A + ", showSortSheet=" + this.Q5MXmkXGmrpQ + ", showCreateDialog=" + this.mhkN7GL0jG0Wg1w + ", createNoteText=" + this.Ib3GalHLi1oFkSI + ", createSelectedMenuItemId=" + this.uVptkJu9raq3 + ", createNoteTextError=" + this.hargS3kTbQOR + ", isCreatingNote=" + this.jtRrC0njHlFmpd + ", snackbarMessage=" + this.KT0nNGpxhUtad + ")";
    }
}
