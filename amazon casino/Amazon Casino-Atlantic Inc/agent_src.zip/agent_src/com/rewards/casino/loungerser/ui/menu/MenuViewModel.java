package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/MenuViewModel;", "Landroidx/lifecycle/ViewModel;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuViewModel extends ViewModel {
    public final StateFlow ADpl0noRbUAhY;
    public final AppRepository NzWQJjWwugl4VFs;
    public final MutableStateFlow f6FsnIUuKXgtm;

    public MenuViewModel(AppRepository appRepository) {
        appRepository.getClass();
        this.NzWQJjWwugl4VFs = appRepository;
        SortOption sortOption = SortOption.ADpl0noRbUAhY;
        EmptyList emptyList = EmptyList.ADpl0noRbUAhY;
        MutableStateFlow mutableStateFlowXfQCOxz9Pm9BcT = StateFlowKt.XfQCOxz9Pm9BcT(new MenuUiState(emptyList, emptyList, "All", sortOption, "", false, null, false));
        this.f6FsnIUuKXgtm = mutableStateFlowXfQCOxz9Pm9BcT;
        this.ADpl0noRbUAhY = FlowKt.f6FsnIUuKXgtm(mutableStateFlowXfQCOxz9Pm9BcT);
        BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(this), null, null, new MenuViewModel$observeMenuItems$1(this, null), 3);
    }

    public final void R7447vqBon0A(Function1 function1) {
        MutableStateFlow mutableStateFlow;
        Object value;
        MenuUiState menuUiState;
        List listEqwJwm8oIiKHLs;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
            menuUiState = (MenuUiState) function1.KT0nNGpxhUtad((MenuUiState) value);
            List list = MenuItemFilter.XfQCOxz9Pm9BcT;
            List list2 = menuUiState.XfQCOxz9Pm9BcT;
            String str = menuUiState.f6FsnIUuKXgtm;
            String str2 = menuUiState.AY1Ge095OJR8sU;
            SortOption sortOption = menuUiState.ADpl0noRbUAhY;
            list2.getClass();
            sortOption.getClass();
            if (!str.equals("All")) {
                ArrayList arrayList = new ArrayList();
                for (Object obj : list2) {
                    if (Intrinsics.XfQCOxz9Pm9BcT(((MenuItemEntity) obj).f6FsnIUuKXgtm, str)) {
                        arrayList.add(obj);
                    }
                }
                list2 = arrayList;
            }
            if (!StringsKt.plDIFW7uQvLLZ1(str2)) {
                Locale locale = Locale.ENGLISH;
                locale.getClass();
                String lowerCase = str2.toLowerCase(locale);
                lowerCase.getClass();
                ArrayList arrayList2 = new ArrayList();
                for (Object obj2 : list2) {
                    MenuItemEntity menuItemEntity = (MenuItemEntity) obj2;
                    String str3 = menuItemEntity.NzWQJjWwugl4VFs;
                    Locale locale2 = Locale.ENGLISH;
                    locale2.getClass();
                    String lowerCase2 = str3.toLowerCase(locale2);
                    lowerCase2.getClass();
                    if (!StringsKt.AY1Ge095OJR8sU(lowerCase2, lowerCase, false)) {
                        String lowerCase3 = menuItemEntity.ADpl0noRbUAhY.toLowerCase(locale2);
                        lowerCase3.getClass();
                        if (!StringsKt.AY1Ge095OJR8sU(lowerCase3, lowerCase, false)) {
                            String str4 = menuItemEntity.AY1Ge095OJR8sU;
                            if (str4 != null) {
                                String lowerCase4 = str4.toLowerCase(locale2);
                                lowerCase4.getClass();
                                if (StringsKt.AY1Ge095OJR8sU(lowerCase4, lowerCase, false)) {
                                }
                            }
                        }
                    }
                    arrayList2.add(obj2);
                }
                list2 = arrayList2;
            }
            int iOrdinal = sortOption.ordinal();
            if (iOrdinal == 0) {
                listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(list2, new MenuItemFilter$apply$$inlined$sortedBy$1());
            } else if (iOrdinal == 1) {
                listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(list2, new MenuItemFilter$apply$$inlined$sortedBy$2());
            } else {
                if (iOrdinal != 2) {
                    defpackage.XfQCOxz9Pm9BcT.jpgeID8zMPb9();
                    return;
                }
                listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(list2, new MenuItemFilter$apply$$inlined$sortedBy$3());
            }
        } while (!mutableStateFlow.R7447vqBon0A(value, MenuUiState.XfQCOxz9Pm9BcT(menuUiState, null, listEqwJwm8oIiKHLs, null, null, null, null, 509)));
    }
}
