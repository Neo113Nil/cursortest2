package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import androidx.room.util.DBUtil;
import androidx.sqlite.SQLiteStatement;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import defpackage.f6FsnIUuKXgtm;
import defpackage.jvr2ydndnJ9FEHk;
import defpackage.y;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.ContinuationImpl;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/MenuItemDao_Impl;", "Lcom/rewards/casino/loungerser/data/dao/MenuItemDao;", "Companion", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuItemDao_Impl implements MenuItemDao {
    public final AnonymousClass1 NzWQJjWwugl4VFs = new AnonymousClass1();
    public final RoomDatabase XfQCOxz9Pm9BcT;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"com/rewards/casino/loungerser/data/dao/MenuItemDao_Impl$1", "Landroidx/room/EntityInsertAdapter;", "Lcom/rewards/casino/loungerser/data/entity/MenuItemEntity;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.data.dao.MenuItemDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends EntityInsertAdapter<MenuItemEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final String NzWQJjWwugl4VFs() {
            return "INSERT OR ABORT INTO `menu_items` (`id`,`name`,`category`,`description`,`ingredients`,`sweetness`,`warmth`,`region`,`tags`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?)";
        }

        @Override // androidx.room.EntityInsertAdapter
        public final void XfQCOxz9Pm9BcT(SQLiteStatement sQLiteStatement, Object obj) {
            MenuItemEntity menuItemEntity = (MenuItemEntity) obj;
            sQLiteStatement.getClass();
            sQLiteStatement.ADpl0noRbUAhY(1, menuItemEntity.XfQCOxz9Pm9BcT);
            sQLiteStatement.M7DF7HY0IK3zByX(2, menuItemEntity.NzWQJjWwugl4VFs);
            sQLiteStatement.M7DF7HY0IK3zByX(3, menuItemEntity.f6FsnIUuKXgtm);
            sQLiteStatement.M7DF7HY0IK3zByX(4, menuItemEntity.ADpl0noRbUAhY);
            String str = menuItemEntity.AY1Ge095OJR8sU;
            if (str == null) {
                sQLiteStatement.XfQCOxz9Pm9BcT(5);
            } else {
                sQLiteStatement.M7DF7HY0IK3zByX(5, str);
            }
            sQLiteStatement.M7DF7HY0IK3zByX(6, menuItemEntity.R7447vqBon0A);
            sQLiteStatement.M7DF7HY0IK3zByX(7, menuItemEntity.Q5MXmkXGmrpQ);
            sQLiteStatement.M7DF7HY0IK3zByX(8, menuItemEntity.mhkN7GL0jG0Wg1w);
            sQLiteStatement.M7DF7HY0IK3zByX(9, menuItemEntity.Ib3GalHLi1oFkSI);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/MenuItemDao_Impl$Companion;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final class Companion {
    }

    public MenuItemDao_Impl(RoomDatabase roomDatabase) {
        this.XfQCOxz9Pm9BcT = roomDatabase;
    }

    @Override // com.rewards.casino.loungerser.data.dao.MenuItemDao
    public final Object ADpl0noRbUAhY(Continuation continuation) {
        return DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new y(25), true, false);
    }

    @Override // com.rewards.casino.loungerser.data.dao.MenuItemDao
    public final Object NzWQJjWwugl4VFs(long j, ContinuationImpl continuationImpl) {
        return DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuationImpl, new jvr2ydndnJ9FEHk(4, j), true, false);
    }

    @Override // com.rewards.casino.loungerser.data.dao.MenuItemDao
    public final FlowUtil$createFlow$$inlined$map$1 XfQCOxz9Pm9BcT() {
        y yVar = new y(24);
        return FlowUtil.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, new String[]{"menu_items"}, yVar);
    }

    @Override // com.rewards.casino.loungerser.data.dao.MenuItemDao
    public final Object f6FsnIUuKXgtm(ArrayList arrayList, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new f6FsnIUuKXgtm(25, this, arrayList), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }
}
