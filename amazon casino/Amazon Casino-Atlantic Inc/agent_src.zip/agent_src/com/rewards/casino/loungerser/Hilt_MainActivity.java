package com.rewards.casino.loungerser;

import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.activity.contextaware.ContextAwareHelper;
import androidx.activity.contextaware.OnContextAvailableListener;
import androidx.lifecycle.ViewModelProvider;
import dagger.hilt.EntryPoints;
import dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories;
import dagger.hilt.android.internal.lifecycle.HiltViewModelFactory;
import dagger.hilt.android.internal.managers.ActivityComponentManager;
import dagger.hilt.android.internal.managers.SavedStateHandleHolder;
import dagger.hilt.internal.GeneratedComponentManagerHolder;
import dagger.internal.LazyClassKeyMap;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public abstract class Hilt_MainActivity extends ComponentActivity implements GeneratedComponentManagerHolder {
    public volatile ActivityComponentManager Sq4Z9oOaVh4F;
    public final Object Mdvwk4KCHtoBY = new Object();
    public boolean pIQ5UlgpXmpV = false;

    public Hilt_MainActivity() {
        final MainActivity mainActivity = (MainActivity) this;
        OnContextAvailableListener onContextAvailableListener = new OnContextAvailableListener() { // from class: com.rewards.casino.loungerser.Hilt_MainActivity.1
            @Override // androidx.activity.contextaware.OnContextAvailableListener
            public final void XfQCOxz9Pm9BcT(ComponentActivity componentActivity) {
                MainActivity mainActivity2 = mainActivity;
                if (mainActivity2.pIQ5UlgpXmpV) {
                    return;
                }
                mainActivity2.pIQ5UlgpXmpV = true;
                ((MainActivity_GeneratedInjector) mainActivity2.AY1Ge095OJR8sU()).getClass();
            }
        };
        ContextAwareHelper contextAwareHelper = this.AY1Ge095OJR8sU;
        contextAwareHelper.getClass();
        ComponentActivity componentActivity = contextAwareHelper.NzWQJjWwugl4VFs;
        if (componentActivity != null) {
            onContextAvailableListener.XfQCOxz9Pm9BcT(componentActivity);
        }
        contextAwareHelper.XfQCOxz9Pm9BcT.add(onContextAvailableListener);
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public final Object AY1Ge095OJR8sU() {
        return KT0nNGpxhUtad().AY1Ge095OJR8sU();
    }

    public final ActivityComponentManager KT0nNGpxhUtad() {
        if (this.Sq4Z9oOaVh4F == null) {
            synchronized (this.Mdvwk4KCHtoBY) {
                try {
                    if (this.Sq4Z9oOaVh4F == null) {
                        this.Sq4Z9oOaVh4F = new ActivityComponentManager(this);
                    }
                } finally {
                }
            }
        }
        return this.Sq4Z9oOaVh4F;
    }

    @Override // androidx.activity.ComponentActivity, androidx.lifecycle.HasDefaultViewModelProviderFactory
    public final ViewModelProvider.Factory Q5MXmkXGmrpQ() {
        ViewModelProvider.Factory factoryQ5MXmkXGmrpQ = super.Q5MXmkXGmrpQ();
        DefaultViewModelFactories.InternalFactoryFactory internalFactoryFactoryXfQCOxz9Pm9BcT = ((DefaultViewModelFactories.ActivityEntryPoint) EntryPoints.XfQCOxz9Pm9BcT(this, DefaultViewModelFactories.ActivityEntryPoint.class)).XfQCOxz9Pm9BcT();
        LazyClassKeyMap lazyClassKeyMap = internalFactoryFactoryXfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT;
        factoryQ5MXmkXGmrpQ.getClass();
        return new HiltViewModelFactory(lazyClassKeyMap, factoryQ5MXmkXGmrpQ, internalFactoryFactoryXfQCOxz9Pm9BcT.NzWQJjWwugl4VFs);
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        KT0nNGpxhUtad().NzWQJjWwugl4VFs();
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        SavedStateHandleHolder savedStateHandleHolder = KT0nNGpxhUtad().mhkN7GL0jG0Wg1w;
        if (savedStateHandleHolder != null) {
            savedStateHandleHolder.XfQCOxz9Pm9BcT = null;
        }
    }
}
