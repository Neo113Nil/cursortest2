package com.rewards.casino.loungerser.data.database;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.RoomDatabase;
import com.rewards.casino.loungerser.data.dao.FavoriteDao;
import com.rewards.casino.loungerser.data.dao.MenuItemDao;
import com.rewards.casino.loungerser.data.dao.NoteDao;
import com.rewards.casino.loungerser.data.dao.TasteMarkDao;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b'\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Lcom/rewards/casino/loungerser/data/database/AppDatabase;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "Companion", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public abstract class AppDatabase extends RoomDatabase {
    public static final Companion hargS3kTbQOR = new Companion();
    public static volatile AppDatabase jtRrC0njHlFmpd;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001R\u0018\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"Lcom/rewards/casino/loungerser/data/database/AppDatabase$Companion;", "", "Lcom/rewards/casino/loungerser/data/database/AppDatabase;", "INSTANCE", "Lcom/rewards/casino/loungerser/data/database/AppDatabase;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final class Companion {
    }

    public abstract NoteDao KT0nNGpxhUtad();

    public abstract FavoriteDao hargS3kTbQOR();

    public abstract MenuItemDao jtRrC0njHlFmpd();

    public abstract TasteMarkDao plDIFW7uQvLLZ1();
}
