package com.rewards.casino.loungerser.navigation;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0004\u0002\u0003\u0004\u0005\u0082\u0001\u0004\u0006\u0007\b\t¨\u0006\n"}, d2 = {"Lcom/rewards/casino/loungerser/navigation/Screen;", "", "Menu", "Notes", "Favorites", "FavoriteDetail", "Lcom/rewards/casino/loungerser/navigation/Screen$FavoriteDetail;", "Lcom/rewards/casino/loungerser/navigation/Screen$Favorites;", "Lcom/rewards/casino/loungerser/navigation/Screen$Menu;", "Lcom/rewards/casino/loungerser/navigation/Screen$Notes;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public abstract class Screen {

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\n\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/navigation/Screen$FavoriteDetail;", "Lcom/rewards/casino/loungerser/navigation/Screen;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* data */ class FavoriteDetail extends Screen {
        public final boolean equals(Object obj) {
            return this == obj || (obj instanceof FavoriteDetail);
        }

        public final int hashCode() {
            return 713692121;
        }

        public final String toString() {
            return "FavoriteDetail";
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\n\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/navigation/Screen$Favorites;", "Lcom/rewards/casino/loungerser/navigation/Screen;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* data */ class Favorites extends Screen {
        public final boolean equals(Object obj) {
            return this == obj || (obj instanceof Favorites);
        }

        public final int hashCode() {
            return -1373442037;
        }

        public final String toString() {
            return "Favorites";
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\n\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/navigation/Screen$Menu;", "Lcom/rewards/casino/loungerser/navigation/Screen;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* data */ class Menu extends Screen {
        public final boolean equals(Object obj) {
            return this == obj || (obj instanceof Menu);
        }

        public final int hashCode() {
            return 365940523;
        }

        public final String toString() {
            return "Menu";
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\n\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/navigation/Screen$Notes;", "Lcom/rewards/casino/loungerser/navigation/Screen;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* data */ class Notes extends Screen {
        public final boolean equals(Object obj) {
            return this == obj || (obj instanceof Notes);
        }

        public final int hashCode() {
            return -1539518859;
        }

        public final String toString() {
            return "Notes";
        }
    }
}
