package com.rewards.casino.loungerser.data.database;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.InvalidationTracker;
import androidx.room.ObservedTableStates;
import androidx.room.RoomOpenDelegate;
import androidx.room.RoomOpenDelegateMarker;
import androidx.room.TriggerBasedInvalidationTracker;
import androidx.room.util.TableInfo;
import androidx.sqlite.SQLite;
import androidx.sqlite.SQLiteConnection;
import androidx.sqlite.SQLiteStatement;
import com.rewards.casino.loungerser.data.dao.FavoriteDao;
import com.rewards.casino.loungerser.data.dao.FavoriteDao_Impl;
import com.rewards.casino.loungerser.data.dao.MenuItemDao;
import com.rewards.casino.loungerser.data.dao.MenuItemDao_Impl;
import com.rewards.casino.loungerser.data.dao.NoteDao;
import com.rewards.casino.loungerser.data.dao.NoteDao_Impl;
import com.rewards.casino.loungerser.data.dao.TasteMarkDao;
import com.rewards.casino.loungerser.data.dao.TasteMarkDao_Impl;
import com.rewards.casino.loungerser.data.database.AppDatabase_Impl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.builders.ListBuilder;
import kotlin.jdk7.AutoCloseableKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.ClassReference;
import kotlin.jvm.internal.Reflection;
import kotlin.text.StringsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/rewards/casino/loungerser/data/database/AppDatabase_Impl;", "Lcom/rewards/casino/loungerser/data/database/AppDatabase;", "<init>", "()V", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final Lazy KT0nNGpxhUtad;
    public final Lazy TXtQqiMBq0ieO9;
    public final Lazy oqhsKX67fcZ7qq;
    public final Lazy plDIFW7uQvLLZ1;

    public AppDatabase_Impl() {
        final int i = 0;
        this.KT0nNGpxhUtad = LazyKt.NzWQJjWwugl4VFs(new Function0(this) { // from class: Qw1KafZjnrAzgKz
            public final /* synthetic */ AppDatabase_Impl AY1Ge095OJR8sU;

            {
                this.AY1Ge095OJR8sU = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object NzWQJjWwugl4VFs() {
                int i2 = i;
                AppDatabase_Impl appDatabase_Impl = this.AY1Ge095OJR8sU;
                switch (i2) {
                    case 0:
                        return new MenuItemDao_Impl(appDatabase_Impl);
                    case 1:
                        return new FavoriteDao_Impl(appDatabase_Impl);
                    case 2:
                        return new NoteDao_Impl(appDatabase_Impl);
                    default:
                        return new TasteMarkDao_Impl(appDatabase_Impl);
                }
            }
        });
        final int i2 = 1;
        this.plDIFW7uQvLLZ1 = LazyKt.NzWQJjWwugl4VFs(new Function0(this) { // from class: Qw1KafZjnrAzgKz
            public final /* synthetic */ AppDatabase_Impl AY1Ge095OJR8sU;

            {
                this.AY1Ge095OJR8sU = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object NzWQJjWwugl4VFs() {
                int i22 = i2;
                AppDatabase_Impl appDatabase_Impl = this.AY1Ge095OJR8sU;
                switch (i22) {
                    case 0:
                        return new MenuItemDao_Impl(appDatabase_Impl);
                    case 1:
                        return new FavoriteDao_Impl(appDatabase_Impl);
                    case 2:
                        return new NoteDao_Impl(appDatabase_Impl);
                    default:
                        return new TasteMarkDao_Impl(appDatabase_Impl);
                }
            }
        });
        final int i3 = 2;
        this.oqhsKX67fcZ7qq = LazyKt.NzWQJjWwugl4VFs(new Function0(this) { // from class: Qw1KafZjnrAzgKz
            public final /* synthetic */ AppDatabase_Impl AY1Ge095OJR8sU;

            {
                this.AY1Ge095OJR8sU = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object NzWQJjWwugl4VFs() {
                int i22 = i3;
                AppDatabase_Impl appDatabase_Impl = this.AY1Ge095OJR8sU;
                switch (i22) {
                    case 0:
                        return new MenuItemDao_Impl(appDatabase_Impl);
                    case 1:
                        return new FavoriteDao_Impl(appDatabase_Impl);
                    case 2:
                        return new NoteDao_Impl(appDatabase_Impl);
                    default:
                        return new TasteMarkDao_Impl(appDatabase_Impl);
                }
            }
        });
        final int i4 = 3;
        this.TXtQqiMBq0ieO9 = LazyKt.NzWQJjWwugl4VFs(new Function0(this) { // from class: Qw1KafZjnrAzgKz
            public final /* synthetic */ AppDatabase_Impl AY1Ge095OJR8sU;

            {
                this.AY1Ge095OJR8sU = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final Object NzWQJjWwugl4VFs() {
                int i22 = i4;
                AppDatabase_Impl appDatabase_Impl = this.AY1Ge095OJR8sU;
                switch (i22) {
                    case 0:
                        return new MenuItemDao_Impl(appDatabase_Impl);
                    case 1:
                        return new FavoriteDao_Impl(appDatabase_Impl);
                    case 2:
                        return new NoteDao_Impl(appDatabase_Impl);
                    default:
                        return new TasteMarkDao_Impl(appDatabase_Impl);
                }
            }
        });
    }

    @Override // androidx.room.RoomDatabase
    public final Set AY1Ge095OJR8sU() {
        return new LinkedHashSet();
    }

    @Override // com.rewards.casino.loungerser.data.database.AppDatabase
    public final NoteDao KT0nNGpxhUtad() {
        return (NoteDao) this.oqhsKX67fcZ7qq.getValue();
    }

    @Override // androidx.room.RoomDatabase
    public final InvalidationTracker NzWQJjWwugl4VFs() {
        return new InvalidationTracker(this, new LinkedHashMap(), new LinkedHashMap(), "menu_items", "favorites", "notes", "taste_marks");
    }

    @Override // androidx.room.RoomDatabase
    public final LinkedHashMap R7447vqBon0A() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        ClassReference classReferenceXfQCOxz9Pm9BcT = Reflection.XfQCOxz9Pm9BcT(MenuItemDao.class);
        EmptyList emptyList = EmptyList.ADpl0noRbUAhY;
        linkedHashMap.put(classReferenceXfQCOxz9Pm9BcT, emptyList);
        linkedHashMap.put(Reflection.XfQCOxz9Pm9BcT(FavoriteDao.class), emptyList);
        linkedHashMap.put(Reflection.XfQCOxz9Pm9BcT(NoteDao.class), emptyList);
        linkedHashMap.put(Reflection.XfQCOxz9Pm9BcT(TasteMarkDao.class), emptyList);
        return linkedHashMap;
    }

    @Override // androidx.room.RoomDatabase
    public final List XfQCOxz9Pm9BcT(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // androidx.room.RoomDatabase
    public final RoomOpenDelegateMarker f6FsnIUuKXgtm() {
        return new RoomOpenDelegate() { // from class: com.rewards.casino.loungerser.data.database.AppDatabase_Impl$createOpenDelegate$_openDelegate$1
            {
                super(1, "92249df896c32930e5c1efaeb46bb20a", "775eae1e89b10e6cade1d4e4428612c2");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void ADpl0noRbUAhY(SQLiteConnection sQLiteConnection) throws Exception {
                sQLiteConnection.getClass();
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "PRAGMA foreign_keys = ON");
                InvalidationTracker invalidationTrackerADpl0noRbUAhY = this.ADpl0noRbUAhY.ADpl0noRbUAhY();
                TriggerBasedInvalidationTracker triggerBasedInvalidationTracker = invalidationTrackerADpl0noRbUAhY.NzWQJjWwugl4VFs;
                triggerBasedInvalidationTracker.getClass();
                SQLiteStatement sQLiteStatementEhGqOszSxmfoL = sQLiteConnection.ehGqOszSxmfoL("PRAGMA query_only");
                try {
                    sQLiteStatementEhGqOszSxmfoL.C3CbJlOuT34G();
                    boolean zOtDkAb0taFfpD3X = sQLiteStatementEhGqOszSxmfoL.OtDkAb0taFfpD3X();
                    AutoCloseableKt.XfQCOxz9Pm9BcT(sQLiteStatementEhGqOszSxmfoL, null);
                    if (!zOtDkAb0taFfpD3X) {
                        SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "PRAGMA temp_store = MEMORY");
                        SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "PRAGMA recursive_triggers = 1");
                        SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TABLE IF EXISTS room_table_modification_log");
                        if (triggerBasedInvalidationTracker.ADpl0noRbUAhY) {
                            SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
                        } else {
                            SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, StringsKt.Ujria6HCrnzq("CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)", "TEMP", ""));
                        }
                        ObservedTableStates observedTableStates = triggerBasedInvalidationTracker.mhkN7GL0jG0Wg1w;
                        ReentrantLock reentrantLock = observedTableStates.XfQCOxz9Pm9BcT;
                        reentrantLock.lock();
                        try {
                            observedTableStates.ADpl0noRbUAhY = true;
                        } finally {
                            reentrantLock.unlock();
                        }
                    }
                    synchronized (invalidationTrackerADpl0noRbUAhY.Q5MXmkXGmrpQ) {
                    }
                } finally {
                }
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void AY1Ge095OJR8sU(SQLiteConnection sQLiteConnection) {
                sQLiteConnection.getClass();
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void NzWQJjWwugl4VFs(SQLiteConnection sQLiteConnection) throws Exception {
                sQLiteConnection.getClass();
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TABLE IF EXISTS `menu_items`");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TABLE IF EXISTS `favorites`");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TABLE IF EXISTS `notes`");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TABLE IF EXISTS `taste_marks`");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final RoomOpenDelegate.ValidationResult Q5MXmkXGmrpQ(SQLiteConnection sQLiteConnection) {
                sQLiteConnection.getClass();
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                linkedHashMap.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap.put("name", new TableInfo.Column("name", "TEXT", true, 0, null, 1));
                linkedHashMap.put("category", new TableInfo.Column("category", "TEXT", true, 0, null, 1));
                linkedHashMap.put("description", new TableInfo.Column("description", "TEXT", true, 0, null, 1));
                linkedHashMap.put("ingredients", new TableInfo.Column("ingredients", "TEXT", false, 0, null, 1));
                linkedHashMap.put("sweetness", new TableInfo.Column("sweetness", "TEXT", true, 0, null, 1));
                linkedHashMap.put("warmth", new TableInfo.Column("warmth", "TEXT", true, 0, null, 1));
                linkedHashMap.put("region", new TableInfo.Column("region", "TEXT", true, 0, null, 1));
                linkedHashMap.put("tags", new TableInfo.Column("tags", "TEXT", true, 0, null, 1));
                TableInfo tableInfo = new TableInfo("menu_items", linkedHashMap, new LinkedHashSet(), new LinkedHashSet());
                TableInfo tableInfoXfQCOxz9Pm9BcT = TableInfo.Companion.XfQCOxz9Pm9BcT(sQLiteConnection, "menu_items");
                if (!tableInfo.equals(tableInfoXfQCOxz9Pm9BcT)) {
                    return new RoomOpenDelegate.ValidationResult("menu_items(com.rewards.casino.loungerser.data.entity.MenuItemEntity).\n Expected:\n" + tableInfo + "\n Found:\n" + tableInfoXfQCOxz9Pm9BcT, false);
                }
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                linkedHashMap2.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap2.put("menuItemId", new TableInfo.Column("menuItemId", "INTEGER", true, 0, null, 1));
                linkedHashMap2.put("timestamp", new TableInfo.Column("timestamp", "INTEGER", true, 0, null, 1));
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                linkedHashSet.add(new TableInfo.ForeignKey("menu_items", "CASCADE", "NO ACTION", CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("id")));
                LinkedHashSet linkedHashSet2 = new LinkedHashSet();
                linkedHashSet2.add(new TableInfo.Index("index_favorites_menuItemId", true, CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("ASC")));
                TableInfo tableInfo2 = new TableInfo("favorites", linkedHashMap2, linkedHashSet, linkedHashSet2);
                TableInfo tableInfoXfQCOxz9Pm9BcT2 = TableInfo.Companion.XfQCOxz9Pm9BcT(sQLiteConnection, "favorites");
                if (!tableInfo2.equals(tableInfoXfQCOxz9Pm9BcT2)) {
                    return new RoomOpenDelegate.ValidationResult("favorites(com.rewards.casino.loungerser.data.entity.FavoriteEntity).\n Expected:\n" + tableInfo2 + "\n Found:\n" + tableInfoXfQCOxz9Pm9BcT2, false);
                }
                LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                linkedHashMap3.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap3.put("menuItemId", new TableInfo.Column("menuItemId", "INTEGER", false, 0, null, 1));
                linkedHashMap3.put("text", new TableInfo.Column("text", "TEXT", true, 0, null, 1));
                linkedHashMap3.put("timestamp", new TableInfo.Column("timestamp", "INTEGER", true, 0, null, 1));
                LinkedHashSet linkedHashSet3 = new LinkedHashSet();
                linkedHashSet3.add(new TableInfo.ForeignKey("menu_items", "SET NULL", "NO ACTION", CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("id")));
                LinkedHashSet linkedHashSet4 = new LinkedHashSet();
                linkedHashSet4.add(new TableInfo.Index("index_notes_menuItemId", false, CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("ASC")));
                TableInfo tableInfo3 = new TableInfo("notes", linkedHashMap3, linkedHashSet3, linkedHashSet4);
                TableInfo tableInfoXfQCOxz9Pm9BcT3 = TableInfo.Companion.XfQCOxz9Pm9BcT(sQLiteConnection, "notes");
                if (!tableInfo3.equals(tableInfoXfQCOxz9Pm9BcT3)) {
                    return new RoomOpenDelegate.ValidationResult("notes(com.rewards.casino.loungerser.data.entity.NoteEntity).\n Expected:\n" + tableInfo3 + "\n Found:\n" + tableInfoXfQCOxz9Pm9BcT3, false);
                }
                LinkedHashMap linkedHashMap4 = new LinkedHashMap();
                linkedHashMap4.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap4.put("menuItemId", new TableInfo.Column("menuItemId", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("value", new TableInfo.Column("value", "TEXT", true, 0, null, 1));
                linkedHashMap4.put("label", new TableInfo.Column("label", "TEXT", true, 0, null, 1));
                linkedHashMap4.put("timestamp", new TableInfo.Column("timestamp", "INTEGER", true, 0, null, 1));
                LinkedHashSet linkedHashSet5 = new LinkedHashSet();
                linkedHashSet5.add(new TableInfo.ForeignKey("menu_items", "CASCADE", "NO ACTION", CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("id")));
                LinkedHashSet linkedHashSet6 = new LinkedHashSet();
                linkedHashSet6.add(new TableInfo.Index("index_taste_marks_menuItemId", false, CollectionsKt.V02FBF0Ulcpcy("menuItemId"), CollectionsKt.V02FBF0Ulcpcy("ASC")));
                TableInfo tableInfo4 = new TableInfo("taste_marks", linkedHashMap4, linkedHashSet5, linkedHashSet6);
                TableInfo tableInfoXfQCOxz9Pm9BcT4 = TableInfo.Companion.XfQCOxz9Pm9BcT(sQLiteConnection, "taste_marks");
                if (tableInfo4.equals(tableInfoXfQCOxz9Pm9BcT4)) {
                    return new RoomOpenDelegate.ValidationResult(null, true);
                }
                return new RoomOpenDelegate.ValidationResult("taste_marks(com.rewards.casino.loungerser.data.entity.TasteMarkEntity).\n Expected:\n" + tableInfo4 + "\n Found:\n" + tableInfoXfQCOxz9Pm9BcT4, false);
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void R7447vqBon0A(SQLiteConnection sQLiteConnection) throws Exception {
                sQLiteConnection.getClass();
                ListBuilder listBuilderJpgeID8zMPb9 = CollectionsKt.jpgeID8zMPb9();
                SQLiteStatement sQLiteStatementEhGqOszSxmfoL = sQLiteConnection.ehGqOszSxmfoL("SELECT name FROM sqlite_master WHERE type = 'trigger'");
                while (sQLiteStatementEhGqOszSxmfoL.C3CbJlOuT34G()) {
                    try {
                        listBuilderJpgeID8zMPb9.add(sQLiteStatementEhGqOszSxmfoL.plDIFW7uQvLLZ1(0));
                    } finally {
                    }
                }
                AutoCloseableKt.XfQCOxz9Pm9BcT(sQLiteStatementEhGqOszSxmfoL, null);
                ListIterator listIterator = CollectionsKt.plDIFW7uQvLLZ1(listBuilderJpgeID8zMPb9).listIterator(0);
                while (listIterator.hasNext()) {
                    String str = (String) listIterator.next();
                    if (StringsKt.ewPYrn4vZ38dEmT(str, "room_fts_content_sync_")) {
                        SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "DROP TRIGGER IF EXISTS ".concat(str));
                    }
                }
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void XfQCOxz9Pm9BcT(SQLiteConnection sQLiteConnection) throws Exception {
                sQLiteConnection.getClass();
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TABLE IF NOT EXISTS `menu_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `category` TEXT NOT NULL, `description` TEXT NOT NULL, `ingredients` TEXT, `sweetness` TEXT NOT NULL, `warmth` TEXT NOT NULL, `region` TEXT NOT NULL, `tags` TEXT NOT NULL)");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TABLE IF NOT EXISTS `favorites` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `menuItemId` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, FOREIGN KEY(`menuItemId`) REFERENCES `menu_items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE UNIQUE INDEX IF NOT EXISTS `index_favorites_menuItemId` ON `favorites` (`menuItemId`)");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TABLE IF NOT EXISTS `notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `menuItemId` INTEGER, `text` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, FOREIGN KEY(`menuItemId`) REFERENCES `menu_items`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE INDEX IF NOT EXISTS `index_notes_menuItemId` ON `notes` (`menuItemId`)");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TABLE IF NOT EXISTS `taste_marks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `menuItemId` INTEGER NOT NULL, `value` TEXT NOT NULL, `label` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, FOREIGN KEY(`menuItemId`) REFERENCES `menu_items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE INDEX IF NOT EXISTS `index_taste_marks_menuItemId` ON `taste_marks` (`menuItemId`)");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
                SQLite.XfQCOxz9Pm9BcT(sQLiteConnection, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '92249df896c32930e5c1efaeb46bb20a')");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void f6FsnIUuKXgtm(SQLiteConnection sQLiteConnection) {
                sQLiteConnection.getClass();
            }
        };
    }

    @Override // com.rewards.casino.loungerser.data.database.AppDatabase
    public final FavoriteDao hargS3kTbQOR() {
        return (FavoriteDao) this.plDIFW7uQvLLZ1.getValue();
    }

    @Override // com.rewards.casino.loungerser.data.database.AppDatabase
    public final MenuItemDao jtRrC0njHlFmpd() {
        return (MenuItemDao) this.KT0nNGpxhUtad.getValue();
    }

    @Override // com.rewards.casino.loungerser.data.database.AppDatabase
    public final TasteMarkDao plDIFW7uQvLLZ1() {
        return (TasteMarkDao) this.TXtQqiMBq0ieO9.getValue();
    }
}
