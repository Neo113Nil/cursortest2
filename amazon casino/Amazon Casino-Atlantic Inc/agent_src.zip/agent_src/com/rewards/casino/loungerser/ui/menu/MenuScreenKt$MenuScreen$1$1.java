package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.MutableState;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.menu.MenuScreenKt$MenuScreen$1$1", f = "MenuScreen.kt", l = {}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MenuScreenKt$MenuScreen$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ MutableState mhkN7GL0jG0Wg1w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MenuScreenKt$MenuScreen$1$1(MutableState mutableState, Continuation continuation) {
        super(2, continuation);
        this.mhkN7GL0jG0Wg1w = mutableState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        ResultKt.NzWQJjWwugl4VFs(obj);
        this.mhkN7GL0jG0Wg1w.setValue(Boolean.FALSE);
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        MenuScreenKt$MenuScreen$1$1 menuScreenKt$MenuScreen$1$1 = (MenuScreenKt$MenuScreen$1$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2);
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        menuScreenKt$MenuScreen$1$1.HDXQYm0hWNKDrl(unit);
        return unit;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MenuScreenKt$MenuScreen$1$1(this.mhkN7GL0jG0Wg1w, continuation);
    }
}
