package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.entity.TasteMarkEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel$loadItem$1", f = "MenuDetailViewModel.kt", l = {49, 50, 56}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MenuDetailViewModel$loadItem$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public int Ib3GalHLi1oFkSI;
    public final /* synthetic */ long hargS3kTbQOR;
    public MenuItemEntity mhkN7GL0jG0Wg1w;
    public final /* synthetic */ MenuDetailViewModel uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MenuDetailViewModel$loadItem$1(MenuDetailViewModel menuDetailViewModel, long j, Continuation continuation) {
        super(2, continuation);
        this.uVptkJu9raq3 = menuDetailViewModel;
        this.hargS3kTbQOR = j;
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x00a8, code lost:
    
        if (r2.XfQCOxz9Pm9BcT(r3, r22) != r4) goto L28;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        Object objNzWQJjWwugl4VFs;
        MenuItemEntity menuItemEntity;
        Object objXfQCOxz9Pm9BcT;
        MenuItemEntity menuItemEntity2;
        boolean zBooleanValue;
        Object value2;
        final MenuDetailViewModel menuDetailViewModel = this.uVptkJu9raq3;
        MutableStateFlow mutableStateFlow = menuDetailViewModel.f6FsnIUuKXgtm;
        AppRepository appRepository = menuDetailViewModel.NzWQJjWwugl4VFs;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.Ib3GalHLi1oFkSI;
        long j = this.hargS3kTbQOR;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value, null, false, null, true, false, null, null, null, 503)));
            this.Ib3GalHLi1oFkSI = 1;
            objNzWQJjWwugl4VFs = appRepository.XfQCOxz9Pm9BcT.NzWQJjWwugl4VFs(j, this);
            if (objNzWQJjWwugl4VFs != coroutineSingletons) {
            }
            return coroutineSingletons;
        }
        if (i == 1) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            objNzWQJjWwugl4VFs = obj;
        } else {
            if (i != 2) {
                if (i == 3) {
                    ResultKt.NzWQJjWwugl4VFs(obj);
                    return Unit.XfQCOxz9Pm9BcT;
                }
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            menuItemEntity = this.mhkN7GL0jG0Wg1w;
            ResultKt.NzWQJjWwugl4VFs(obj);
            objXfQCOxz9Pm9BcT = obj;
            menuItemEntity2 = menuItemEntity;
            zBooleanValue = ((Boolean) objXfQCOxz9Pm9BcT).booleanValue();
            do {
                value2 = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value2, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value2, menuItemEntity2, zBooleanValue, null, false, false, null, null, null, 500)));
            FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1F6FsnIUuKXgtm = appRepository.ADpl0noRbUAhY.f6FsnIUuKXgtm(j);
            FlowCollector flowCollector = new FlowCollector() { // from class: com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel$loadItem$1.3
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object f6FsnIUuKXgtm(Object obj2, Continuation continuation) {
                    Object value3;
                    TasteMarkEntity tasteMarkEntity = (TasteMarkEntity) obj2;
                    MutableStateFlow mutableStateFlow2 = menuDetailViewModel.f6FsnIUuKXgtm;
                    do {
                        value3 = mutableStateFlow2.getValue();
                    } while (!mutableStateFlow2.R7447vqBon0A(value3, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value3, null, false, tasteMarkEntity, false, false, null, null, null, 507)));
                    return Unit.XfQCOxz9Pm9BcT;
                }
            };
            this.mhkN7GL0jG0Wg1w = null;
            this.Ib3GalHLi1oFkSI = 3;
        }
        menuItemEntity = (MenuItemEntity) objNzWQJjWwugl4VFs;
        this.mhkN7GL0jG0Wg1w = menuItemEntity;
        this.Ib3GalHLi1oFkSI = 2;
        objXfQCOxz9Pm9BcT = appRepository.NzWQJjWwugl4VFs.XfQCOxz9Pm9BcT(j, this);
        if (objXfQCOxz9Pm9BcT != coroutineSingletons) {
            menuItemEntity2 = menuItemEntity;
            zBooleanValue = ((Boolean) objXfQCOxz9Pm9BcT).booleanValue();
            do {
                value2 = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value2, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value2, menuItemEntity2, zBooleanValue, null, false, false, null, null, null, 500)));
            FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1F6FsnIUuKXgtm2 = appRepository.ADpl0noRbUAhY.f6FsnIUuKXgtm(j);
            FlowCollector flowCollector2 = new FlowCollector() { // from class: com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel$loadItem$1.3
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final Object f6FsnIUuKXgtm(Object obj2, Continuation continuation) {
                    Object value3;
                    TasteMarkEntity tasteMarkEntity = (TasteMarkEntity) obj2;
                    MutableStateFlow mutableStateFlow2 = menuDetailViewModel.f6FsnIUuKXgtm;
                    do {
                        value3 = mutableStateFlow2.getValue();
                    } while (!mutableStateFlow2.R7447vqBon0A(value3, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value3, null, false, tasteMarkEntity, false, false, null, null, null, 507)));
                    return Unit.XfQCOxz9Pm9BcT;
                }
            };
            this.mhkN7GL0jG0Wg1w = null;
            this.Ib3GalHLi1oFkSI = 3;
        }
        return coroutineSingletons;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((MenuDetailViewModel$loadItem$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MenuDetailViewModel$loadItem$1(this.uVptkJu9raq3, this.hargS3kTbQOR, continuation);
    }
}
