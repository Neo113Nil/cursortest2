package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import defpackage.o0;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel$deleteNote$1", f = "NoteDetailViewModel.kt", l = {109}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NoteDetailViewModel$deleteNote$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ NoteDetailViewModel Ib3GalHLi1oFkSI;
    public final /* synthetic */ o0 hargS3kTbQOR;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ long uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NoteDetailViewModel$deleteNote$1(NoteDetailViewModel noteDetailViewModel, long j, o0 o0Var, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = noteDetailViewModel;
        this.uVptkJu9raq3 = j;
        this.hargS3kTbQOR = o0Var;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        NoteDetailViewModel noteDetailViewModel = this.Ib3GalHLi1oFkSI;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            AppRepository appRepository = noteDetailViewModel.NzWQJjWwugl4VFs;
            this.mhkN7GL0jG0Wg1w = 1;
            Object objF6FsnIUuKXgtm = appRepository.f6FsnIUuKXgtm.f6FsnIUuKXgtm(this.uVptkJu9raq3, this);
            if (objF6FsnIUuKXgtm != coroutineSingletons) {
                objF6FsnIUuKXgtm = unit;
            }
            if (objF6FsnIUuKXgtm == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        noteDetailViewModel.R7447vqBon0A();
        noteDetailViewModel.AY1Ge095OJR8sU = null;
        noteDetailViewModel.f6FsnIUuKXgtm.setValue(new NoteDetailUiState(255));
        this.hargS3kTbQOR.NzWQJjWwugl4VFs();
        return unit;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NoteDetailViewModel$deleteNote$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NoteDetailViewModel$deleteNote$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this.hargS3kTbQOR, continuation);
    }
}
