package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.lifecycle.ViewModelKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesScreenKt$NoteDetailBottomSheet$1$1", f = "NotesScreen.kt", l = {}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NotesScreenKt$NoteDetailBottomSheet$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ long Ib3GalHLi1oFkSI;
    public final /* synthetic */ NoteDetailViewModel mhkN7GL0jG0Wg1w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesScreenKt$NoteDetailBottomSheet$1$1(NoteDetailViewModel noteDetailViewModel, long j, Continuation continuation) {
        super(2, continuation);
        this.mhkN7GL0jG0Wg1w = noteDetailViewModel;
        this.Ib3GalHLi1oFkSI = j;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        ResultKt.NzWQJjWwugl4VFs(obj);
        NoteDetailViewModel noteDetailViewModel = this.mhkN7GL0jG0Wg1w;
        Long l = noteDetailViewModel.AY1Ge095OJR8sU;
        long j = this.Ib3GalHLi1oFkSI;
        if (l == null || l.longValue() != j) {
            noteDetailViewModel.AY1Ge095OJR8sU = Long.valueOf(j);
            BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(noteDetailViewModel), null, null, new NoteDetailViewModel$loadNote$1(noteDetailViewModel, j, null), 3);
        }
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        NotesScreenKt$NoteDetailBottomSheet$1$1 notesScreenKt$NoteDetailBottomSheet$1$1 = (NotesScreenKt$NoteDetailBottomSheet$1$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2);
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        notesScreenKt$NoteDetailBottomSheet$1$1.HDXQYm0hWNKDrl(unit);
        return unit;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NotesScreenKt$NoteDetailBottomSheet$1$1(this.mhkN7GL0jG0Wg1w, this.Ib3GalHLi1oFkSI, continuation);
    }
}
