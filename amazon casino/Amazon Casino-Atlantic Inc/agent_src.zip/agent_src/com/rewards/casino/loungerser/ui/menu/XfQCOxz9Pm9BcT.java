package com.rewards.casino.loungerser.ui.menu;

import androidx.lifecycle.ViewModelKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final /* synthetic */ class XfQCOxz9Pm9BcT implements Function0 {
    public final /* synthetic */ int ADpl0noRbUAhY;
    public final /* synthetic */ MenuDetailViewModel AY1Ge095OJR8sU;

    public /* synthetic */ XfQCOxz9Pm9BcT(MenuDetailViewModel menuDetailViewModel, int i) {
        this.ADpl0noRbUAhY = i;
        this.AY1Ge095OJR8sU = menuDetailViewModel;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object NzWQJjWwugl4VFs() {
        Object value;
        Object value2;
        int i = this.ADpl0noRbUAhY;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        switch (i) {
            case 0:
                MenuDetailViewModel menuDetailViewModel = this.AY1Ge095OJR8sU;
                Long l = menuDetailViewModel.AY1Ge095OJR8sU;
                if (l != null) {
                    BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(menuDetailViewModel), null, null, new MenuDetailViewModel$toggleFavorite$1(menuDetailViewModel, l.longValue(), null), 3);
                    break;
                }
                break;
            default:
                MenuDetailViewModel menuDetailViewModel2 = this.AY1Ge095OJR8sU;
                MutableStateFlow mutableStateFlow = menuDetailViewModel2.f6FsnIUuKXgtm;
                Long l2 = menuDetailViewModel2.AY1Ge095OJR8sU;
                if (l2 != null) {
                    long jLongValue = l2.longValue();
                    String string = StringsKt.raz1graTVlUtt(((MenuDetailUiState) mutableStateFlow.getValue()).R7447vqBon0A).toString();
                    if (!StringsKt.plDIFW7uQvLLZ1(string)) {
                        if (string.length() <= 500) {
                            BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(menuDetailViewModel2), null, null, new MenuDetailViewModel$saveNote$3(menuDetailViewModel2, jLongValue, string, null), 3);
                            break;
                        } else {
                            do {
                                value = mutableStateFlow.getValue();
                            } while (!mutableStateFlow.R7447vqBon0A(value, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value, null, false, null, false, false, null, "Note too long (max 500 characters)", null, 383)));
                        }
                    } else {
                        do {
                            value2 = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.R7447vqBon0A(value2, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value2, null, false, null, false, false, null, "Note cannot be empty", null, 383)));
                    }
                }
                break;
        }
        return unit;
    }
}
