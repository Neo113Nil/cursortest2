package com.rewards.casino.loungerser.data.entity;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/entity/MenuItemEntity;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class MenuItemEntity {
    public final String ADpl0noRbUAhY;
    public final String AY1Ge095OJR8sU;
    public final String Ib3GalHLi1oFkSI;
    public final String NzWQJjWwugl4VFs;
    public final String Q5MXmkXGmrpQ;
    public final String R7447vqBon0A;
    public final long XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;
    public final String mhkN7GL0jG0Wg1w;

    public MenuItemEntity(long j, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
        str.getClass();
        str2.getClass();
        str3.getClass();
        str5.getClass();
        str6.getClass();
        str7.getClass();
        str8.getClass();
        this.XfQCOxz9Pm9BcT = j;
        this.NzWQJjWwugl4VFs = str;
        this.f6FsnIUuKXgtm = str2;
        this.ADpl0noRbUAhY = str3;
        this.AY1Ge095OJR8sU = str4;
        this.R7447vqBon0A = str5;
        this.Q5MXmkXGmrpQ = str6;
        this.mhkN7GL0jG0Wg1w = str7;
        this.Ib3GalHLi1oFkSI = str8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MenuItemEntity)) {
            return false;
        }
        MenuItemEntity menuItemEntity = (MenuItemEntity) obj;
        return this.XfQCOxz9Pm9BcT == menuItemEntity.XfQCOxz9Pm9BcT && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, menuItemEntity.NzWQJjWwugl4VFs) && Intrinsics.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, menuItemEntity.f6FsnIUuKXgtm) && Intrinsics.XfQCOxz9Pm9BcT(this.ADpl0noRbUAhY, menuItemEntity.ADpl0noRbUAhY) && Intrinsics.XfQCOxz9Pm9BcT(this.AY1Ge095OJR8sU, menuItemEntity.AY1Ge095OJR8sU) && Intrinsics.XfQCOxz9Pm9BcT(this.R7447vqBon0A, menuItemEntity.R7447vqBon0A) && Intrinsics.XfQCOxz9Pm9BcT(this.Q5MXmkXGmrpQ, menuItemEntity.Q5MXmkXGmrpQ) && Intrinsics.XfQCOxz9Pm9BcT(this.mhkN7GL0jG0Wg1w, menuItemEntity.mhkN7GL0jG0Wg1w) && Intrinsics.XfQCOxz9Pm9BcT(this.Ib3GalHLi1oFkSI, menuItemEntity.Ib3GalHLi1oFkSI);
    }

    public final int hashCode() {
        int iNzWQJjWwugl4VFs = v6.NzWQJjWwugl4VFs(this.ADpl0noRbUAhY, v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, v6.NzWQJjWwugl4VFs(this.NzWQJjWwugl4VFs, Long.hashCode(this.XfQCOxz9Pm9BcT) * 31, 31), 31), 31);
        String str = this.AY1Ge095OJR8sU;
        return this.Ib3GalHLi1oFkSI.hashCode() + v6.NzWQJjWwugl4VFs(this.mhkN7GL0jG0Wg1w, v6.NzWQJjWwugl4VFs(this.Q5MXmkXGmrpQ, v6.NzWQJjWwugl4VFs(this.R7447vqBon0A, (iNzWQJjWwugl4VFs + (str == null ? 0 : str.hashCode())) * 31, 31), 31), 31);
    }

    public final String toString() {
        return "MenuItemEntity(id=" + this.XfQCOxz9Pm9BcT + ", name=" + this.NzWQJjWwugl4VFs + ", category=" + this.f6FsnIUuKXgtm + ", description=" + this.ADpl0noRbUAhY + ", ingredients=" + this.AY1Ge095OJR8sU + ", sweetness=" + this.R7447vqBon0A + ", warmth=" + this.Q5MXmkXGmrpQ + ", region=" + this.mhkN7GL0jG0Wg1w + ", tags=" + this.Ib3GalHLi1oFkSI + ")";
    }

    public /* synthetic */ MenuItemEntity(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
        this(0L, str, str2, str3, str4, str5, str6, str7, str8);
    }
}
