package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/notes/NoteWithItemName;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class NoteWithItemName {
    public final String NzWQJjWwugl4VFs;
    public final NoteEntity XfQCOxz9Pm9BcT;

    public NoteWithItemName(NoteEntity noteEntity, String str) {
        noteEntity.getClass();
        this.XfQCOxz9Pm9BcT = noteEntity;
        this.NzWQJjWwugl4VFs = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NoteWithItemName)) {
            return false;
        }
        NoteWithItemName noteWithItemName = (NoteWithItemName) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, noteWithItemName.XfQCOxz9Pm9BcT) && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, noteWithItemName.NzWQJjWwugl4VFs);
    }

    public final int hashCode() {
        int iHashCode = this.XfQCOxz9Pm9BcT.hashCode() * 31;
        String str = this.NzWQJjWwugl4VFs;
        return iHashCode + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        return "NoteWithItemName(note=" + this.XfQCOxz9Pm9BcT + ", itemName=" + this.NzWQJjWwugl4VFs + ")";
    }
}
