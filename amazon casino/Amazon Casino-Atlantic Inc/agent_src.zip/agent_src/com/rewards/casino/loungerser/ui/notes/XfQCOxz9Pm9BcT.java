package com.rewards.casino.loungerser.ui.notes;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final /* synthetic */ class XfQCOxz9Pm9BcT implements Function0 {
    public final /* synthetic */ int ADpl0noRbUAhY;
    public final /* synthetic */ ViewModel AY1Ge095OJR8sU;

    public /* synthetic */ XfQCOxz9Pm9BcT(ViewModel viewModel, int i) {
        this.ADpl0noRbUAhY = i;
        this.AY1Ge095OJR8sU = viewModel;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object NzWQJjWwugl4VFs() {
        Object value;
        Object value2;
        Object value3;
        Object value4;
        int i = this.ADpl0noRbUAhY;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        ViewModel viewModel = this.AY1Ge095OJR8sU;
        switch (i) {
            case 0:
                NotesViewModel notesViewModel = (NotesViewModel) viewModel;
                MutableStateFlow mutableStateFlow = notesViewModel.f6FsnIUuKXgtm;
                String string = StringsKt.raz1graTVlUtt(((NotesUiState) mutableStateFlow.getValue()).Ib3GalHLi1oFkSI).toString();
                if (!StringsKt.plDIFW7uQvLLZ1(string)) {
                    if (string.length() <= 500) {
                        BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(notesViewModel), null, null, new NotesViewModel$saveCreateNote$3(notesViewModel, string, null), 3);
                        break;
                    } else {
                        do {
                            value = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, false, false, null, null, NoteTextError.AY1Ge095OJR8sU, false, null, 14335)));
                    }
                } else {
                    do {
                        value2 = mutableStateFlow.getValue();
                    } while (!mutableStateFlow.R7447vqBon0A(value2, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value2, null, null, null, null, null, false, false, null, null, NoteTextError.ADpl0noRbUAhY, false, null, 14335)));
                }
            default:
                NoteDetailViewModel noteDetailViewModel = (NoteDetailViewModel) viewModel;
                MutableStateFlow mutableStateFlow2 = noteDetailViewModel.f6FsnIUuKXgtm;
                Long l = noteDetailViewModel.AY1Ge095OJR8sU;
                if (l != null) {
                    long jLongValue = l.longValue();
                    String string2 = StringsKt.raz1graTVlUtt(((NoteDetailUiState) mutableStateFlow2.getValue()).AY1Ge095OJR8sU).toString();
                    if (!StringsKt.plDIFW7uQvLLZ1(string2)) {
                        if (string2.length() <= 500) {
                            BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(noteDetailViewModel), null, null, new NoteDetailViewModel$saveEdit$3(noteDetailViewModel, jLongValue, string2, null), 3);
                            break;
                        } else {
                            do {
                                value3 = mutableStateFlow2.getValue();
                            } while (!mutableStateFlow2.R7447vqBon0A(value3, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value3, null, null, false, null, "Note too long (max 500 characters)", false, 191)));
                        }
                    } else {
                        do {
                            value4 = mutableStateFlow2.getValue();
                        } while (!mutableStateFlow2.R7447vqBon0A(value4, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value4, null, null, false, null, "Note cannot be empty", false, 191)));
                    }
                }
                break;
        }
        return unit;
    }
}
