package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.entity.TasteMarkEntity;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/MenuDetailUiState;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class MenuDetailUiState {
    public final boolean ADpl0noRbUAhY;
    public final boolean AY1Ge095OJR8sU;
    public final boolean NzWQJjWwugl4VFs;
    public final String Q5MXmkXGmrpQ;
    public final String R7447vqBon0A;
    public final MenuItemEntity XfQCOxz9Pm9BcT;
    public final TasteMarkEntity f6FsnIUuKXgtm;
    public final NoteSnackbarMessage mhkN7GL0jG0Wg1w;

    public MenuDetailUiState(MenuItemEntity menuItemEntity, boolean z, TasteMarkEntity tasteMarkEntity, boolean z2, boolean z3, String str, String str2, NoteSnackbarMessage noteSnackbarMessage) {
        this.XfQCOxz9Pm9BcT = menuItemEntity;
        this.NzWQJjWwugl4VFs = z;
        this.f6FsnIUuKXgtm = tasteMarkEntity;
        this.ADpl0noRbUAhY = z2;
        this.AY1Ge095OJR8sU = z3;
        this.R7447vqBon0A = str;
        this.Q5MXmkXGmrpQ = str2;
        this.mhkN7GL0jG0Wg1w = noteSnackbarMessage;
    }

    public static MenuDetailUiState XfQCOxz9Pm9BcT(MenuDetailUiState menuDetailUiState, MenuItemEntity menuItemEntity, boolean z, TasteMarkEntity tasteMarkEntity, boolean z2, boolean z3, String str, String str2, NoteSnackbarMessage noteSnackbarMessage, int i) {
        if ((i & 1) != 0) {
            menuItemEntity = menuDetailUiState.XfQCOxz9Pm9BcT;
        }
        MenuItemEntity menuItemEntity2 = menuItemEntity;
        if ((i & 2) != 0) {
            z = menuDetailUiState.NzWQJjWwugl4VFs;
        }
        boolean z4 = z;
        if ((i & 4) != 0) {
            tasteMarkEntity = menuDetailUiState.f6FsnIUuKXgtm;
        }
        TasteMarkEntity tasteMarkEntity2 = tasteMarkEntity;
        if ((i & 8) != 0) {
            z2 = menuDetailUiState.ADpl0noRbUAhY;
        }
        boolean z5 = z2;
        menuDetailUiState.getClass();
        if ((i & 32) != 0) {
            z3 = menuDetailUiState.AY1Ge095OJR8sU;
        }
        boolean z6 = z3;
        if ((i & 64) != 0) {
            str = menuDetailUiState.R7447vqBon0A;
        }
        String str3 = str;
        String str4 = (i & 128) != 0 ? menuDetailUiState.Q5MXmkXGmrpQ : str2;
        NoteSnackbarMessage noteSnackbarMessage2 = (i & 256) != 0 ? menuDetailUiState.mhkN7GL0jG0Wg1w : noteSnackbarMessage;
        menuDetailUiState.getClass();
        str3.getClass();
        return new MenuDetailUiState(menuItemEntity2, z4, tasteMarkEntity2, z5, z6, str3, str4, noteSnackbarMessage2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MenuDetailUiState)) {
            return false;
        }
        MenuDetailUiState menuDetailUiState = (MenuDetailUiState) obj;
        return Intrinsics.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, menuDetailUiState.XfQCOxz9Pm9BcT) && this.NzWQJjWwugl4VFs == menuDetailUiState.NzWQJjWwugl4VFs && Intrinsics.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, menuDetailUiState.f6FsnIUuKXgtm) && this.ADpl0noRbUAhY == menuDetailUiState.ADpl0noRbUAhY && this.AY1Ge095OJR8sU == menuDetailUiState.AY1Ge095OJR8sU && this.R7447vqBon0A.equals(menuDetailUiState.R7447vqBon0A) && Intrinsics.XfQCOxz9Pm9BcT(this.Q5MXmkXGmrpQ, menuDetailUiState.Q5MXmkXGmrpQ) && this.mhkN7GL0jG0Wg1w == menuDetailUiState.mhkN7GL0jG0Wg1w;
    }

    public final int hashCode() {
        MenuItemEntity menuItemEntity = this.XfQCOxz9Pm9BcT;
        int iXfQCOxz9Pm9BcT = v6.XfQCOxz9Pm9BcT((menuItemEntity == null ? 0 : menuItemEntity.hashCode()) * 31, 31, this.NzWQJjWwugl4VFs);
        TasteMarkEntity tasteMarkEntity = this.f6FsnIUuKXgtm;
        int iNzWQJjWwugl4VFs = v6.NzWQJjWwugl4VFs(this.R7447vqBon0A, v6.XfQCOxz9Pm9BcT(v6.XfQCOxz9Pm9BcT((iXfQCOxz9Pm9BcT + (tasteMarkEntity == null ? 0 : tasteMarkEntity.hashCode())) * 31, 961, this.ADpl0noRbUAhY), 31, this.AY1Ge095OJR8sU), 31);
        String str = this.Q5MXmkXGmrpQ;
        int iHashCode = (iNzWQJjWwugl4VFs + (str == null ? 0 : str.hashCode())) * 31;
        NoteSnackbarMessage noteSnackbarMessage = this.mhkN7GL0jG0Wg1w;
        return iHashCode + (noteSnackbarMessage != null ? noteSnackbarMessage.hashCode() : 0);
    }

    public final String toString() {
        return "MenuDetailUiState(item=" + this.XfQCOxz9Pm9BcT + ", isFavorite=" + this.NzWQJjWwugl4VFs + ", tasteMark=" + this.f6FsnIUuKXgtm + ", isLoading=" + this.ADpl0noRbUAhY + ", error=null, showAddNoteDialog=" + this.AY1Ge095OJR8sU + ", noteText=" + this.R7447vqBon0A + ", noteTextError=" + this.Q5MXmkXGmrpQ + ", snackbarMessage=" + this.mhkN7GL0jG0Wg1w + ")";
    }
}
