package com.rewards.casino.loungerser.data.repository;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.data.repository.AppRepository", f = "AppRepository.kt", l = {53, 55}, m = "updateNote", v = 2)
/* loaded from: classes.dex */
final class AppRepository$updateNote$1 extends ContinuationImpl {
    public /* synthetic */ Object Ib3GalHLi1oFkSI;
    public long Q5MXmkXGmrpQ;
    public int hargS3kTbQOR;
    public String mhkN7GL0jG0Wg1w;
    public final /* synthetic */ AppRepository uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppRepository$updateNote$1(AppRepository appRepository, ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.uVptkJu9raq3 = appRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        this.Ib3GalHLi1oFkSI = obj;
        this.hargS3kTbQOR |= Integer.MIN_VALUE;
        return this.uVptkJu9raq3.f6FsnIUuKXgtm(0L, null, this);
    }
}
