package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import androidx.room.util.DBUtil;
import androidx.sqlite.SQLiteStatement;
import com.rewards.casino.loungerser.data.entity.TasteMarkEntity;
import defpackage.jvr2ydndnJ9FEHk;
import defpackage.m3;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/TasteMarkDao_Impl;", "Lcom/rewards/casino/loungerser/data/dao/TasteMarkDao;", "Companion", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class TasteMarkDao_Impl implements TasteMarkDao {
    public final AnonymousClass1 NzWQJjWwugl4VFs = new AnonymousClass1();
    public final RoomDatabase XfQCOxz9Pm9BcT;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"com/rewards/casino/loungerser/data/dao/TasteMarkDao_Impl$1", "Landroidx/room/EntityInsertAdapter;", "Lcom/rewards/casino/loungerser/data/entity/TasteMarkEntity;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.data.dao.TasteMarkDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends EntityInsertAdapter<TasteMarkEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final String NzWQJjWwugl4VFs() {
            return "INSERT OR REPLACE INTO `taste_marks` (`id`,`menuItemId`,`value`,`label`,`timestamp`) VALUES (nullif(?, 0),?,?,?,?)";
        }

        @Override // androidx.room.EntityInsertAdapter
        public final void XfQCOxz9Pm9BcT(SQLiteStatement sQLiteStatement, Object obj) {
            TasteMarkEntity tasteMarkEntity = (TasteMarkEntity) obj;
            sQLiteStatement.getClass();
            sQLiteStatement.ADpl0noRbUAhY(1, tasteMarkEntity.XfQCOxz9Pm9BcT);
            sQLiteStatement.ADpl0noRbUAhY(2, tasteMarkEntity.NzWQJjWwugl4VFs);
            sQLiteStatement.M7DF7HY0IK3zByX(3, tasteMarkEntity.f6FsnIUuKXgtm);
            sQLiteStatement.M7DF7HY0IK3zByX(4, tasteMarkEntity.ADpl0noRbUAhY);
            sQLiteStatement.ADpl0noRbUAhY(5, tasteMarkEntity.AY1Ge095OJR8sU);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/TasteMarkDao_Impl$Companion;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final class Companion {
    }

    public TasteMarkDao_Impl(RoomDatabase roomDatabase) {
        this.XfQCOxz9Pm9BcT = roomDatabase;
    }

    @Override // com.rewards.casino.loungerser.data.dao.TasteMarkDao
    public final Object NzWQJjWwugl4VFs(TasteMarkEntity tasteMarkEntity, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new m3(9, this, tasteMarkEntity), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }

    @Override // com.rewards.casino.loungerser.data.dao.TasteMarkDao
    public final Object XfQCOxz9Pm9BcT(long j, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new jvr2ydndnJ9FEHk(7, j), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }

    @Override // com.rewards.casino.loungerser.data.dao.TasteMarkDao
    public final FlowUtil$createFlow$$inlined$map$1 f6FsnIUuKXgtm(long j) {
        jvr2ydndnJ9FEHk jvr2ydndnj9fehk = new jvr2ydndnJ9FEHk(8, j);
        return FlowUtil.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, new String[]{"taste_marks"}, jvr2ydndnj9fehk);
    }
}
