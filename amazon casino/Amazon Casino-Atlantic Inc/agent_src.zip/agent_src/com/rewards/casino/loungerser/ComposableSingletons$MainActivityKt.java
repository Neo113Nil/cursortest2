package com.rewards.casino.loungerser;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.BTSST24gkDbxl1;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$MainActivityKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(-882659479, new BTSST24gkDbxl1(15), false);
    public static final ComposableLambdaImpl NzWQJjWwugl4VFs = new ComposableLambdaImpl(-1220408242, new BTSST24gkDbxl1(16), false);
    public static final ComposableLambdaImpl f6FsnIUuKXgtm = new ComposableLambdaImpl(-163253763, new BTSST24gkDbxl1(17), false);
}
