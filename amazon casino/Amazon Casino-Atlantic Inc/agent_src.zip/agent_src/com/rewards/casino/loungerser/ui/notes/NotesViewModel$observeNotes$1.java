package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeNotes$1", f = "NotesViewModel.kt", l = {71}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NotesViewModel$observeNotes$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ NotesViewModel Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeNotes$1$1, reason: invalid class name */
    final class AnonymousClass1<T> implements FlowCollector {
        public final /* synthetic */ NotesViewModel ADpl0noRbUAhY;

        public AnonymousClass1(NotesViewModel notesViewModel) {
            this.ADpl0noRbUAhY = notesViewModel;
        }

        /* JADX WARN: Removed duplicated region for block: B:17:0x0065  */
        /* JADX WARN: Removed duplicated region for block: B:25:0x0097  */
        /* JADX WARN: Removed duplicated region for block: B:26:0x009a  */
        /* JADX WARN: Removed duplicated region for block: B:29:0x00a8  */
        /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0092 -> B:23:0x0093). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:27:0x009c -> B:28:0x009e). Please report as a decompilation issue!!! */
        @Override // kotlinx.coroutines.flow.FlowCollector
        /* renamed from: XfQCOxz9Pm9BcT, reason: merged with bridge method [inline-methods] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object f6FsnIUuKXgtm(List list, Continuation continuation) {
            NotesViewModel$observeNotes$1$1$emit$1 notesViewModel$observeNotes$1$1$emit$1;
            int i;
            NotesViewModel notesViewModel;
            Collection arrayList;
            Iterator<T> it;
            int i2;
            Object value;
            if (continuation instanceof NotesViewModel$observeNotes$1$1$emit$1) {
                notesViewModel$observeNotes$1$1$emit$1 = (NotesViewModel$observeNotes$1$1$emit$1) continuation;
                int i3 = notesViewModel$observeNotes$1$1$emit$1.TXtQqiMBq0ieO9;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    notesViewModel$observeNotes$1$1$emit$1.TXtQqiMBq0ieO9 = i3 - Integer.MIN_VALUE;
                } else {
                    notesViewModel$observeNotes$1$1$emit$1 = new NotesViewModel$observeNotes$1$1$emit$1(this, continuation);
                }
            }
            Object objNzWQJjWwugl4VFs = notesViewModel$observeNotes$1$1$emit$1.plDIFW7uQvLLZ1;
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
            int i4 = notesViewModel$observeNotes$1$1$emit$1.TXtQqiMBq0ieO9;
            NotesViewModel notesViewModel2 = this.ADpl0noRbUAhY;
            if (i4 == 0) {
                ResultKt.NzWQJjWwugl4VFs(objNzWQJjWwugl4VFs);
                i = 0;
                notesViewModel = notesViewModel2;
                arrayList = new ArrayList(CollectionsKt.oqhsKX67fcZ7qq(list, 10));
                it = list.iterator();
                i2 = 0;
                if (!it.hasNext()) {
                }
            } else {
                if (i4 != 1) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                i2 = notesViewModel$observeNotes$1$1$emit$1.KT0nNGpxhUtad;
                i = notesViewModel$observeNotes$1$1$emit$1.jtRrC0njHlFmpd;
                arrayList = notesViewModel$observeNotes$1$1$emit$1.hargS3kTbQOR;
                NoteEntity noteEntity = notesViewModel$observeNotes$1$1$emit$1.uVptkJu9raq3;
                it = notesViewModel$observeNotes$1$1$emit$1.Ib3GalHLi1oFkSI;
                Collection collection = notesViewModel$observeNotes$1$1$emit$1.mhkN7GL0jG0Wg1w;
                notesViewModel = notesViewModel$observeNotes$1$1$emit$1.Q5MXmkXGmrpQ;
                ResultKt.NzWQJjWwugl4VFs(objNzWQJjWwugl4VFs);
                MenuItemEntity menuItemEntity = (MenuItemEntity) objNzWQJjWwugl4VFs;
                String str = menuItemEntity == null ? menuItemEntity.NzWQJjWwugl4VFs : null;
                arrayList.add(new NoteWithItemName(noteEntity, str));
                arrayList = collection;
                if (!it.hasNext()) {
                    List list2 = (List) arrayList;
                    MutableStateFlow mutableStateFlow = notesViewModel2.f6FsnIUuKXgtm;
                    do {
                        value = mutableStateFlow.getValue();
                    } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, list2, null, null, null, null, false, false, null, null, null, false, null, 16374)));
                    notesViewModel2.R7447vqBon0A();
                    return Unit.XfQCOxz9Pm9BcT;
                }
                noteEntity = (NoteEntity) it.next();
                Long l = noteEntity.NzWQJjWwugl4VFs;
                if (l != null) {
                    long jLongValue = l.longValue();
                    AppRepository appRepository = notesViewModel.NzWQJjWwugl4VFs;
                    notesViewModel$observeNotes$1$1$emit$1.Q5MXmkXGmrpQ = notesViewModel;
                    Collection collection2 = arrayList;
                    notesViewModel$observeNotes$1$1$emit$1.mhkN7GL0jG0Wg1w = collection2;
                    notesViewModel$observeNotes$1$1$emit$1.Ib3GalHLi1oFkSI = it;
                    notesViewModel$observeNotes$1$1$emit$1.uVptkJu9raq3 = noteEntity;
                    notesViewModel$observeNotes$1$1$emit$1.hargS3kTbQOR = collection2;
                    notesViewModel$observeNotes$1$1$emit$1.jtRrC0njHlFmpd = i;
                    notesViewModel$observeNotes$1$1$emit$1.KT0nNGpxhUtad = i2;
                    notesViewModel$observeNotes$1$1$emit$1.TXtQqiMBq0ieO9 = 1;
                    objNzWQJjWwugl4VFs = appRepository.XfQCOxz9Pm9BcT.NzWQJjWwugl4VFs(jLongValue, notesViewModel$observeNotes$1$1$emit$1);
                    if (objNzWQJjWwugl4VFs == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                    collection = arrayList;
                    MenuItemEntity menuItemEntity2 = (MenuItemEntity) objNzWQJjWwugl4VFs;
                    if (menuItemEntity2 == null) {
                    }
                    arrayList.add(new NoteWithItemName(noteEntity, str));
                    arrayList = collection;
                    if (!it.hasNext()) {
                    }
                } else {
                    str = null;
                    collection = arrayList;
                    arrayList.add(new NoteWithItemName(noteEntity, str));
                    arrayList = collection;
                    if (!it.hasNext()) {
                    }
                }
            }
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesViewModel$observeNotes$1(NotesViewModel notesViewModel, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = notesViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            NotesViewModel notesViewModel = this.Ib3GalHLi1oFkSI;
            FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1XfQCOxz9Pm9BcT = notesViewModel.NzWQJjWwugl4VFs.f6FsnIUuKXgtm.XfQCOxz9Pm9BcT();
            AnonymousClass1 anonymousClass1 = new AnonymousClass1(notesViewModel);
            this.mhkN7GL0jG0Wg1w = 1;
            if (flowUtil$createFlow$$inlined$map$1XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NotesViewModel$observeNotes$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NotesViewModel$observeNotes$1(this.Ib3GalHLi1oFkSI, continuation);
    }
}
