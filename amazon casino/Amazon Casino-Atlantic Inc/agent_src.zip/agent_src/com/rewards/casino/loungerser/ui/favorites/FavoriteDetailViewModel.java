package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.lifecycle.ViewModel;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoriteDetailViewModel;", "Landroidx/lifecycle/ViewModel;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoriteDetailViewModel extends ViewModel {
    public final StateFlow ADpl0noRbUAhY;
    public Long AY1Ge095OJR8sU;
    public final AppRepository NzWQJjWwugl4VFs;
    public final MutableStateFlow f6FsnIUuKXgtm;

    public FavoriteDetailViewModel(AppRepository appRepository) {
        appRepository.getClass();
        this.NzWQJjWwugl4VFs = appRepository;
        MutableStateFlow mutableStateFlowXfQCOxz9Pm9BcT = StateFlowKt.XfQCOxz9Pm9BcT(new FavoriteDetailUiState(null, true, false));
        this.f6FsnIUuKXgtm = mutableStateFlowXfQCOxz9Pm9BcT;
        this.ADpl0noRbUAhY = FlowKt.f6FsnIUuKXgtm(mutableStateFlowXfQCOxz9Pm9BcT);
    }
}
