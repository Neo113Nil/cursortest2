package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptySet;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/notes/NotesViewModel;", "Landroidx/lifecycle/ViewModel;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class NotesViewModel extends ViewModel {
    public final StateFlow ADpl0noRbUAhY;
    public final AppRepository NzWQJjWwugl4VFs;
    public final MutableStateFlow f6FsnIUuKXgtm;

    public NotesViewModel(AppRepository appRepository) {
        appRepository.getClass();
        this.NzWQJjWwugl4VFs = appRepository;
        EmptyList emptyList = EmptyList.ADpl0noRbUAhY;
        MutableStateFlow mutableStateFlowXfQCOxz9Pm9BcT = StateFlowKt.XfQCOxz9Pm9BcT(new NotesUiState(emptyList, emptyList, "Newest First", false, null, EmptySet.ADpl0noRbUAhY, false, false, "", null, null, false, null));
        this.f6FsnIUuKXgtm = mutableStateFlowXfQCOxz9Pm9BcT;
        this.ADpl0noRbUAhY = FlowKt.f6FsnIUuKXgtm(mutableStateFlowXfQCOxz9Pm9BcT);
        BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(this), null, null, new NotesViewModel$observeNotes$1(this, null), 3);
        BuildersKt.NzWQJjWwugl4VFs(ViewModelKt.XfQCOxz9Pm9BcT(this), null, null, new NotesViewModel$observeMenuItems$1(this, null), 3);
    }

    public final void Ib3GalHLi1oFkSI(Long l) {
        MutableStateFlow mutableStateFlow;
        Object value;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, false, false, null, l, null, false, null, 15359)));
    }

    public final void Q5MXmkXGmrpQ() {
        MutableStateFlow mutableStateFlow;
        Object value;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, false, false, null, null, null, false, null, 8191)));
    }

    public final void R7447vqBon0A() {
        Object value;
        MutableStateFlow mutableStateFlow = this.f6FsnIUuKXgtm;
        NotesUiState notesUiState = (NotesUiState) mutableStateFlow.getValue();
        String str = notesUiState.f6FsnIUuKXgtm;
        List listEqwJwm8oIiKHLs = notesUiState.XfQCOxz9Pm9BcT;
        int iHashCode = str.hashCode();
        if (iHashCode != -648234225) {
            if (iHashCode != -115448497) {
                if (iHashCode == 10437110 && str.equals("Newest First")) {
                    listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(listEqwJwm8oIiKHLs, new NotesViewModel$applySorting$$inlined$sortedByDescending$1());
                }
            } else if (str.equals("Oldest First")) {
                listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(listEqwJwm8oIiKHLs, new NotesViewModel$applySorting$$inlined$sortedBy$1());
            }
        } else if (str.equals("By Item Name")) {
            listEqwJwm8oIiKHLs = CollectionsKt.eqwJwm8oIiKHLs(listEqwJwm8oIiKHLs, new NotesViewModel$applySorting$$inlined$sortedBy$2());
        }
        List list = listEqwJwm8oIiKHLs;
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, list, null, null, null, null, false, false, null, null, null, false, null, 16382)));
    }

    public final void mhkN7GL0jG0Wg1w() {
        MutableStateFlow mutableStateFlow;
        Object value;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, false, false, "", null, null, false, null, 8447)));
    }

    public final void uVptkJu9raq3() {
        MutableStateFlow mutableStateFlow;
        Object value;
        do {
            mutableStateFlow = this.f6FsnIUuKXgtm;
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, !r3.Q5MXmkXGmrpQ, false, null, null, null, false, null, 16255)));
    }
}
