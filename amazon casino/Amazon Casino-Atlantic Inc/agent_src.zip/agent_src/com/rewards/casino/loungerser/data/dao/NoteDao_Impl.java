package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.EntityDeleteOrUpdateAdapter;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import androidx.room.util.DBUtil;
import androidx.sqlite.SQLiteStatement;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import defpackage.ADpl0noRbUAhY;
import defpackage.e3;
import defpackage.jvr2ydndnJ9FEHk;
import defpackage.m3;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.SuspendLambda;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/NoteDao_Impl;", "Lcom/rewards/casino/loungerser/data/dao/NoteDao;", "Companion", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class NoteDao_Impl implements NoteDao {
    public final AnonymousClass1 NzWQJjWwugl4VFs = new AnonymousClass1();
    public final RoomDatabase XfQCOxz9Pm9BcT;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"com/rewards/casino/loungerser/data/dao/NoteDao_Impl$1", "Landroidx/room/EntityInsertAdapter;", "Lcom/rewards/casino/loungerser/data/entity/NoteEntity;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.data.dao.NoteDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends EntityInsertAdapter<NoteEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final String NzWQJjWwugl4VFs() {
            return "INSERT OR ABORT INTO `notes` (`id`,`menuItemId`,`text`,`timestamp`) VALUES (nullif(?, 0),?,?,?)";
        }

        @Override // androidx.room.EntityInsertAdapter
        public final void XfQCOxz9Pm9BcT(SQLiteStatement sQLiteStatement, Object obj) {
            NoteEntity noteEntity = (NoteEntity) obj;
            sQLiteStatement.getClass();
            sQLiteStatement.ADpl0noRbUAhY(1, noteEntity.XfQCOxz9Pm9BcT);
            Long l = noteEntity.NzWQJjWwugl4VFs;
            if (l == null) {
                sQLiteStatement.XfQCOxz9Pm9BcT(2);
            } else {
                sQLiteStatement.ADpl0noRbUAhY(2, l.longValue());
            }
            sQLiteStatement.M7DF7HY0IK3zByX(3, noteEntity.f6FsnIUuKXgtm);
            sQLiteStatement.ADpl0noRbUAhY(4, noteEntity.ADpl0noRbUAhY);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"com/rewards/casino/loungerser/data/dao/NoteDao_Impl$2", "Landroidx/room/EntityDeleteOrUpdateAdapter;", "Lcom/rewards/casino/loungerser/data/entity/NoteEntity;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.data.dao.NoteDao_Impl$2, reason: invalid class name */
    public final class AnonymousClass2 extends EntityDeleteOrUpdateAdapter<NoteEntity> {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/NoteDao_Impl$Companion;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final class Companion {
    }

    public NoteDao_Impl(RoomDatabase roomDatabase) {
        this.XfQCOxz9Pm9BcT = roomDatabase;
    }

    @Override // com.rewards.casino.loungerser.data.dao.NoteDao
    public final Object ADpl0noRbUAhY(NoteEntity noteEntity, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new ADpl0noRbUAhY(this, noteEntity), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }

    @Override // com.rewards.casino.loungerser.data.dao.NoteDao
    public final Object AY1Ge095OJR8sU(NoteEntity noteEntity, SuspendLambda suspendLambda) {
        return DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, suspendLambda, new m3(3, this, noteEntity), false, true);
    }

    @Override // com.rewards.casino.loungerser.data.dao.NoteDao
    public final Object NzWQJjWwugl4VFs(long j, ContinuationImpl continuationImpl) {
        return DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuationImpl, new jvr2ydndnJ9FEHk(6, j), true, false);
    }

    @Override // com.rewards.casino.loungerser.data.dao.NoteDao
    public final FlowUtil$createFlow$$inlined$map$1 XfQCOxz9Pm9BcT() {
        e3 e3Var = new e3(19);
        return FlowUtil.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, new String[]{"notes"}, e3Var);
    }

    @Override // com.rewards.casino.loungerser.data.dao.NoteDao
    public final Object f6FsnIUuKXgtm(long j, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new jvr2ydndnJ9FEHk(5, j), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }
}
