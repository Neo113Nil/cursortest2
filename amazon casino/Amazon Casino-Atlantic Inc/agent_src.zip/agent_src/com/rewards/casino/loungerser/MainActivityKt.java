package com.rewards.casino.loungerser;

import android.content.Context;
import android.os.Bundle;
import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material.icons.automirrored.filled.NoteKt;
import androidx.compose.material.icons.filled.FavoriteKt;
import androidx.compose.material.icons.outlined.MenuKt;
import androidx.compose.material3.DrawerState;
import androidx.compose.material3.DrawerValue;
import androidx.compose.material3.NavigationDrawerKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.RememberedCoroutineScope;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.saveable.RememberSaveableKt;
import androidx.compose.runtime.saveable.SaverKt$Saver$1;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.SolidColor;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.graphics.vector.PathBuilder;
import androidx.compose.ui.graphics.vector.VectorKt;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.core.os.BundleCompat;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.NavBackStackEntryState;
import androidx.navigation.NavDestination;
import androidx.navigation.NavHostController;
import androidx.navigation.Navigator;
import androidx.navigation.internal.NavControllerImpl;
import androidx.os.SavedStateReader;
import androidx.os.SavedStateReaderKt;
import defpackage.XzGSkR7TbcB0;
import defpackage.YtVqGpkhpxZ5;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArrayDeque;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0002¨\u0006\u0002²\u0006\u000e\u0010\u0001\u001a\u0004\u0018\u00010\u00008\nX\u008a\u0084\u0002"}, d2 = {"Landroidx/navigation/NavBackStackEntry;", "navBackStackEntry", "app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MainActivityKt {
    public static final void XfQCOxz9Pm9BcT(int i, Composer composer) {
        NavDestination navDestination;
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(1641461915);
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i & 1, i != 0)) {
            final Context context = (Context) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(AndroidCompositionLocals_androidKt.NzWQJjWwugl4VFs);
            Object[] objArrCopyOf = Arrays.copyOf(new Navigator[0], 0);
            SaverKt$Saver$1 saverKt$Saver$1 = new SaverKt$Saver$1(new YtVqGpkhpxZ5(21), new Function1() { // from class: androidx.navigation.compose.NzWQJjWwugl4VFs
                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlin.jvm.functions.Function1
                public final Object KT0nNGpxhUtad(Object obj) throws Throwable {
                    Bundle[] bundleArr;
                    Throwable th;
                    Bundle bundle = (Bundle) obj;
                    NavHostController navHostControllerXfQCOxz9Pm9BcT = NavHostControllerKt__NavHostController_androidKt.XfQCOxz9Pm9BcT(context);
                    if (bundle != null) {
                        bundle.setClassLoader(navHostControllerXfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT.getClassLoader());
                    }
                    NavControllerImpl navControllerImpl = navHostControllerXfQCOxz9Pm9BcT.NzWQJjWwugl4VFs;
                    LinkedHashMap linkedHashMap = navControllerImpl.plDIFW7uQvLLZ1;
                    Throwable th2 = null;
                    if (bundle == null) {
                        th = null;
                    } else {
                        navControllerImpl.ADpl0noRbUAhY = bundle.containsKey("android-support-nav:controller:navigatorState") ? SavedStateReader.Q5MXmkXGmrpQ("android-support-nav:controller:navigatorState", bundle) : null;
                        if (bundle.containsKey("android-support-nav:controller:backStack")) {
                            ArrayList arrayListXfQCOxz9Pm9BcT = BundleCompat.XfQCOxz9Pm9BcT(bundle, "android-support-nav:controller:backStack", JvmClassMappingKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(Bundle.class)));
                            if (arrayListXfQCOxz9Pm9BcT == null) {
                                SavedStateReaderKt.XfQCOxz9Pm9BcT("android-support-nav:controller:backStack");
                                throw null;
                            }
                            bundleArr = (Bundle[]) arrayListXfQCOxz9Pm9BcT.toArray(new Bundle[0]);
                        } else {
                            bundleArr = null;
                        }
                        navControllerImpl.AY1Ge095OJR8sU = bundleArr;
                        linkedHashMap.clear();
                        if (bundle.containsKey("android-support-nav:controller:backStackDestIds") && bundle.containsKey("android-support-nav:controller:backStackIds")) {
                            int[] iArrAY1Ge095OJR8sU = SavedStateReader.AY1Ge095OJR8sU("android-support-nav:controller:backStackDestIds", bundle);
                            ArrayList arrayListUVptkJu9raq3 = SavedStateReader.uVptkJu9raq3("android-support-nav:controller:backStackIds", bundle);
                            int length = iArrAY1Ge095OJR8sU.length;
                            int i2 = 0;
                            int i3 = 0;
                            while (i2 < length) {
                                int i4 = i3 + 1;
                                Throwable th3 = th2;
                                navControllerImpl.KT0nNGpxhUtad.put(Integer.valueOf(iArrAY1Ge095OJR8sU[i2]), !Intrinsics.XfQCOxz9Pm9BcT(arrayListUVptkJu9raq3.get(i3), "") ? (String) arrayListUVptkJu9raq3.get(i3) : th3);
                                i2++;
                                th2 = th3;
                                i3 = i4;
                            }
                        }
                        th = th2;
                        if (bundle.containsKey("android-support-nav:controller:backStackStates")) {
                            ArrayList arrayListUVptkJu9raq32 = SavedStateReader.uVptkJu9raq3("android-support-nav:controller:backStackStates", bundle);
                            int size = arrayListUVptkJu9raq32.size();
                            int i5 = 0;
                            while (i5 < size) {
                                Object obj2 = arrayListUVptkJu9raq32.get(i5);
                                i5++;
                                String str = (String) obj2;
                                if (bundle.containsKey("android-support-nav:controller:backStackStates:" + str)) {
                                    String str2 = "android-support-nav:controller:backStackStates:" + str;
                                    ArrayList arrayListXfQCOxz9Pm9BcT2 = BundleCompat.XfQCOxz9Pm9BcT(bundle, str2, JvmClassMappingKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(Bundle.class)));
                                    if (arrayListXfQCOxz9Pm9BcT2 == null) {
                                        SavedStateReaderKt.XfQCOxz9Pm9BcT(str2);
                                        throw th;
                                    }
                                    ArrayDeque arrayDeque = new ArrayDeque(arrayListXfQCOxz9Pm9BcT2.size());
                                    int size2 = arrayListXfQCOxz9Pm9BcT2.size();
                                    int i6 = 0;
                                    while (i6 < size2) {
                                        Object obj3 = arrayListXfQCOxz9Pm9BcT2.get(i6);
                                        i6++;
                                        arrayDeque.addLast(new NavBackStackEntryState((Bundle) obj3));
                                    }
                                    linkedHashMap.put(str, arrayDeque);
                                }
                            }
                        }
                    }
                    if (bundle != null) {
                        boolean z = bundle.getBoolean("android-support-nav:controller:deepLinkHandled", false);
                        Boolean boolValueOf = (z || !bundle.getBoolean("android-support-nav:controller:deepLinkHandled", true)) ? Boolean.valueOf(z) : th;
                        navHostControllerXfQCOxz9Pm9BcT.AY1Ge095OJR8sU = boolValueOf != 0 ? boolValueOf.booleanValue() : false;
                    }
                    return navHostControllerXfQCOxz9Pm9BcT;
                }
            });
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(context);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Object obj = Composer.Companion.XfQCOxz9Pm9BcT;
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq3 == obj) {
                objUVptkJu9raq3 = new Function0() { // from class: androidx.navigation.compose.XfQCOxz9Pm9BcT
                    @Override // kotlin.jvm.functions.Function0
                    public final Object NzWQJjWwugl4VFs() {
                        return NavHostControllerKt__NavHostController_androidKt.XfQCOxz9Pm9BcT(context);
                    }
                };
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            final NavHostController navHostController = (NavHostController) RememberSaveableKt.f6FsnIUuKXgtm(objArrCopyOf, saverKt$Saver$1, (Function0) objUVptkJu9raq3, composerPIQ5UlgpXmpV, 0, 4);
            DrawerValue drawerValue = DrawerValue.ADpl0noRbUAhY;
            final DrawerState drawerStateMhkN7GL0jG0Wg1w = NavigationDrawerKt.mhkN7GL0jG0Wg1w(composerPIQ5UlgpXmpV);
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq32 == obj) {
                RememberedCoroutineScope rememberedCoroutineScope = new RememberedCoroutineScope(composerPIQ5UlgpXmpV.getJvr2ydndnJ9FEHk());
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(rememberedCoroutineScope);
                objUVptkJu9raq32 = rememberedCoroutineScope;
            }
            final CoroutineScope coroutineScope = (CoroutineScope) objUVptkJu9raq32;
            NavBackStackEntry navBackStackEntry = (NavBackStackEntry) SnapshotStateKt.XfQCOxz9Pm9BcT(FlowKt.NzWQJjWwugl4VFs(navHostController.NzWQJjWwugl4VFs.pIQ5UlgpXmpV), null, null, composerPIQ5UlgpXmpV, 48, 2).getADpl0noRbUAhY();
            final String str = (navBackStackEntry == null || (navDestination = navBackStackEntry.AY1Ge095OJR8sU) == null) ? null : navDestination.AY1Ge095OJR8sU.AY1Ge095OJR8sU;
            String strXfQCOxz9Pm9BcT = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.screen_menu, composerPIQ5UlgpXmpV);
            ImageVector imageVectorADpl0noRbUAhY = MenuKt.XfQCOxz9Pm9BcT;
            if (imageVectorADpl0noRbUAhY == null) {
                ImageVector.Builder builder = new ImageVector.Builder("Outlined.Menu", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
                int i2 = VectorKt.XfQCOxz9Pm9BcT;
                SolidColor solidColor = new SolidColor(Color.NzWQJjWwugl4VFs);
                PathBuilder pathBuilder = new PathBuilder();
                pathBuilder.Q5MXmkXGmrpQ(3.0f, 18.0f);
                pathBuilder.ADpl0noRbUAhY(18.0f);
                pathBuilder.Ib3GalHLi1oFkSI(-2.0f);
                pathBuilder.AY1Ge095OJR8sU(3.0f, 16.0f);
                pathBuilder.Ib3GalHLi1oFkSI(2.0f);
                pathBuilder.XfQCOxz9Pm9BcT();
                pathBuilder.Q5MXmkXGmrpQ(3.0f, 13.0f);
                pathBuilder.ADpl0noRbUAhY(18.0f);
                pathBuilder.Ib3GalHLi1oFkSI(-2.0f);
                pathBuilder.AY1Ge095OJR8sU(3.0f, 11.0f);
                pathBuilder.Ib3GalHLi1oFkSI(2.0f);
                pathBuilder.XfQCOxz9Pm9BcT();
                pathBuilder.Q5MXmkXGmrpQ(3.0f, 6.0f);
                pathBuilder.Ib3GalHLi1oFkSI(2.0f);
                pathBuilder.ADpl0noRbUAhY(18.0f);
                pathBuilder.AY1Ge095OJR8sU(21.0f, 6.0f);
                pathBuilder.AY1Ge095OJR8sU(3.0f, 6.0f);
                pathBuilder.XfQCOxz9Pm9BcT();
                builder.NzWQJjWwugl4VFs(1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0, 0, 2, solidColor, null, "", pathBuilder.XfQCOxz9Pm9BcT);
                imageVectorADpl0noRbUAhY = builder.ADpl0noRbUAhY();
                MenuKt.XfQCOxz9Pm9BcT = imageVectorADpl0noRbUAhY;
            }
            Triple triple = new Triple("menu", strXfQCOxz9Pm9BcT, imageVectorADpl0noRbUAhY);
            String strXfQCOxz9Pm9BcT2 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.screen_notes, composerPIQ5UlgpXmpV);
            ImageVector imageVectorADpl0noRbUAhY2 = NoteKt.XfQCOxz9Pm9BcT;
            if (imageVectorADpl0noRbUAhY2 == null) {
                ImageVector.Builder builder2 = new ImageVector.Builder("AutoMirrored.Filled.Note", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, true, 96);
                int i3 = VectorKt.XfQCOxz9Pm9BcT;
                SolidColor solidColor2 = new SolidColor(Color.NzWQJjWwugl4VFs);
                PathBuilder pathBuilder2 = new PathBuilder();
                pathBuilder2.Q5MXmkXGmrpQ(22.0f, 10.0f);
                pathBuilder2.R7447vqBon0A(-6.0f, -6.0f);
                pathBuilder2.AY1Ge095OJR8sU(4.0f, 4.0f);
                pathBuilder2.f6FsnIUuKXgtm(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f);
                pathBuilder2.Ib3GalHLi1oFkSI(12.01f);
                pathBuilder2.f6FsnIUuKXgtm(0.0f, 1.1f, 0.9f, 1.99f, 2.0f, 1.99f);
                pathBuilder2.R7447vqBon0A(16.0f, -0.01f);
                pathBuilder2.f6FsnIUuKXgtm(1.1f, 0.0f, 2.0f, -0.89f, 2.0f, -1.99f);
                pathBuilder2.Ib3GalHLi1oFkSI(-8.0f);
                pathBuilder2.XfQCOxz9Pm9BcT();
                pathBuilder2.Q5MXmkXGmrpQ(15.0f, 5.5f);
                pathBuilder2.R7447vqBon0A(5.5f, 5.5f);
                pathBuilder2.AY1Ge095OJR8sU(15.0f, 11.0f);
                pathBuilder2.AY1Ge095OJR8sU(15.0f, 5.5f);
                pathBuilder2.XfQCOxz9Pm9BcT();
                builder2.NzWQJjWwugl4VFs(1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0, 0, 2, solidColor2, null, "", pathBuilder2.XfQCOxz9Pm9BcT);
                imageVectorADpl0noRbUAhY2 = builder2.ADpl0noRbUAhY();
                NoteKt.XfQCOxz9Pm9BcT = imageVectorADpl0noRbUAhY2;
            }
            Triple triple2 = new Triple("notes", strXfQCOxz9Pm9BcT2, imageVectorADpl0noRbUAhY2);
            String strXfQCOxz9Pm9BcT3 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.screen_favorites, composerPIQ5UlgpXmpV);
            ImageVector imageVectorADpl0noRbUAhY3 = FavoriteKt.XfQCOxz9Pm9BcT;
            if (imageVectorADpl0noRbUAhY3 == null) {
                ImageVector.Builder builder3 = new ImageVector.Builder("Filled.Favorite", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
                int i4 = VectorKt.XfQCOxz9Pm9BcT;
                SolidColor solidColor3 = new SolidColor(Color.NzWQJjWwugl4VFs);
                PathBuilder pathBuilder3 = new PathBuilder();
                pathBuilder3.Q5MXmkXGmrpQ(12.0f, 21.35f);
                pathBuilder3.R7447vqBon0A(-1.45f, -1.32f);
                pathBuilder3.NzWQJjWwugl4VFs(5.4f, 15.36f, 2.0f, 12.28f, 2.0f, 8.5f);
                pathBuilder3.NzWQJjWwugl4VFs(2.0f, 5.42f, 4.42f, 3.0f, 7.5f, 3.0f);
                pathBuilder3.f6FsnIUuKXgtm(1.74f, 0.0f, 3.41f, 0.81f, 4.5f, 2.09f);
                pathBuilder3.NzWQJjWwugl4VFs(13.09f, 3.81f, 14.76f, 3.0f, 16.5f, 3.0f);
                pathBuilder3.NzWQJjWwugl4VFs(19.58f, 3.0f, 22.0f, 5.42f, 22.0f, 8.5f);
                pathBuilder3.f6FsnIUuKXgtm(0.0f, 3.78f, -3.4f, 6.86f, -8.55f, 11.54f);
                pathBuilder3.AY1Ge095OJR8sU(12.0f, 21.35f);
                pathBuilder3.XfQCOxz9Pm9BcT();
                builder3.NzWQJjWwugl4VFs(1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0, 0, 2, solidColor3, null, "", pathBuilder3.XfQCOxz9Pm9BcT);
                imageVectorADpl0noRbUAhY3 = builder3.ADpl0noRbUAhY();
                FavoriteKt.XfQCOxz9Pm9BcT = imageVectorADpl0noRbUAhY3;
            }
            List listJcThbbljzdkQV = CollectionsKt.jcThbbljzdkQV(triple, triple2, new Triple("favorites", strXfQCOxz9Pm9BcT3, imageVectorADpl0noRbUAhY3));
            boolean z = Intrinsics.XfQCOxz9Pm9BcT(str, "menu") || Intrinsics.XfQCOxz9Pm9BcT(str, "favorites");
            ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs = ComposableLambdaKt.NzWQJjWwugl4VFs(211804386, new XzGSkR7TbcB0(listJcThbbljzdkQV, str, navHostController, coroutineScope, drawerStateMhkN7GL0jG0Wg1w), composerPIQ5UlgpXmpV);
            final boolean z2 = z;
            NavigationDrawerKt.f6FsnIUuKXgtm(composableLambdaImplNzWQJjWwugl4VFs, null, drawerStateMhkN7GL0jG0Wg1w, false, 0L, ComposableLambdaKt.NzWQJjWwugl4VFs(-609927875, new Function2() { // from class: o2
                @Override // kotlin.jvm.functions.Function2
                public final Object jtRrC0njHlFmpd(Object obj2, Object obj3) {
                    Composer composer2 = (Composer) obj2;
                    int iIntValue = ((Integer) obj3).intValue();
                    int i5 = 1;
                    if (composer2.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                        FillElement fillElement = SizeKt.f6FsnIUuKXgtm;
                        boolean z3 = z2;
                        String str2 = str;
                        CoroutineScope coroutineScope2 = coroutineScope;
                        DrawerState drawerState = drawerStateMhkN7GL0jG0Wg1w;
                        ScaffoldKt.XfQCOxz9Pm9BcT(fillElement, ComposableLambdaKt.NzWQJjWwugl4VFs(-1044020999, new n1(z3, str2, coroutineScope2, drawerState), composer2), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.NzWQJjWwugl4VFs(1318484878, new q0(navHostController, coroutineScope2, drawerState, i5), composer2), composer2, 805306422, 508);
                    } else {
                        composer2.R7447vqBon0A();
                    }
                    return Unit.XfQCOxz9Pm9BcT;
                }
            }, composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, 196614);
            composerPIQ5UlgpXmpV = composerPIQ5UlgpXmpV;
        } else {
            composerPIQ5UlgpXmpV.R7447vqBon0A();
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new YtVqGpkhpxZ5(i, 20));
        }
    }
}
