package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import androidx.room.util.DBUtil;
import androidx.sqlite.SQLiteStatement;
import com.rewards.casino.loungerser.data.entity.FavoriteEntity;
import defpackage.f6FsnIUuKXgtm;
import defpackage.jvr2ydndnJ9FEHk;
import defpackage.y;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/FavoriteDao_Impl;", "Lcom/rewards/casino/loungerser/data/dao/FavoriteDao;", "Companion", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoriteDao_Impl implements FavoriteDao {
    public final AnonymousClass1 NzWQJjWwugl4VFs = new AnonymousClass1();
    public final RoomDatabase XfQCOxz9Pm9BcT;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"com/rewards/casino/loungerser/data/dao/FavoriteDao_Impl$1", "Landroidx/room/EntityInsertAdapter;", "Lcom/rewards/casino/loungerser/data/entity/FavoriteEntity;", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    /* renamed from: com.rewards.casino.loungerser.data.dao.FavoriteDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends EntityInsertAdapter<FavoriteEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final String NzWQJjWwugl4VFs() {
            return "INSERT OR ABORT INTO `favorites` (`id`,`menuItemId`,`timestamp`) VALUES (nullif(?, 0),?,?)";
        }

        @Override // androidx.room.EntityInsertAdapter
        public final void XfQCOxz9Pm9BcT(SQLiteStatement sQLiteStatement, Object obj) {
            FavoriteEntity favoriteEntity = (FavoriteEntity) obj;
            sQLiteStatement.getClass();
            sQLiteStatement.ADpl0noRbUAhY(1, 0L);
            sQLiteStatement.ADpl0noRbUAhY(2, favoriteEntity.XfQCOxz9Pm9BcT);
            sQLiteStatement.ADpl0noRbUAhY(3, favoriteEntity.NzWQJjWwugl4VFs);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/FavoriteDao_Impl$Companion;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final class Companion {
    }

    public FavoriteDao_Impl(RoomDatabase roomDatabase) {
        this.XfQCOxz9Pm9BcT = roomDatabase;
    }

    @Override // com.rewards.casino.loungerser.data.dao.FavoriteDao
    public final Object ADpl0noRbUAhY(long j, SuspendLambda suspendLambda) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, suspendLambda, new jvr2ydndnJ9FEHk(3, j), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }

    @Override // com.rewards.casino.loungerser.data.dao.FavoriteDao
    public final FlowUtil$createFlow$$inlined$map$1 NzWQJjWwugl4VFs() {
        y yVar = new y(2);
        return FlowUtil.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, new String[]{"menu_items", "favorites"}, yVar);
    }

    @Override // com.rewards.casino.loungerser.data.dao.FavoriteDao
    public final Object XfQCOxz9Pm9BcT(long j, Continuation continuation) {
        return DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new jvr2ydndnJ9FEHk(2, j), true, false);
    }

    @Override // com.rewards.casino.loungerser.data.dao.FavoriteDao
    public final Object f6FsnIUuKXgtm(FavoriteEntity favoriteEntity, Continuation continuation) {
        Object objNzWQJjWwugl4VFs = DBUtil.NzWQJjWwugl4VFs(this.XfQCOxz9Pm9BcT, continuation, new f6FsnIUuKXgtm(14, this, favoriteEntity), false, true);
        return objNzWQJjWwugl4VFs == CoroutineSingletons.ADpl0noRbUAhY ? objNzWQJjWwugl4VFs : Unit.XfQCOxz9Pm9BcT;
    }
}
