package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnMeasurePolicy;
import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.WindowInsetsKt;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.AndroidAlertDialog_androidKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.ExposedDropdownMenuKt;
import androidx.compose.material3.FloatingActionButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ModalBottomSheetKt;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.SheetState;
import androidx.compose.material3.SnackbarHostState;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.Composer$Companion$Empty$1;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.PersistentCompositionLocalMap;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.ClipboardManager;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.rewards.casino.loungerser.R;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import com.rewards.casino.loungerser.ui.notes.ComposableSingletons$NotesScreenKt;
import com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel;
import com.rewards.casino.loungerser.ui.notes.NotesUiState;
import com.rewards.casino.loungerser.ui.notes.NotesViewModel;
import com.rewards.casino.loungerser.ui.notes.XfQCOxz9Pm9BcT;
import defpackage.FLMntEtk8XkIet1;
import defpackage.c4;
import defpackage.d;
import defpackage.eXZoBnCfBCqjp;
import defpackage.jIAALsBkQIUpNq8;
import defpackage.l0;
import defpackage.q0;
import defpackage.x3;
import defpackage.z3;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Reflection;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000¨\u0006\u0005²\u0006\f\u0010\u0001\u001a\u00020\u00008\nX\u008a\u0084\u0002²\u0006\u000e\u0010\u0003\u001a\u00020\u00028\n@\nX\u008a\u008e\u0002²\u0006\f\u0010\u0001\u001a\u00020\u00048\nX\u008a\u0084\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/notes/NotesUiState;", "state", "", "itemMenuExpanded", "Lcom/rewards/casino/loungerser/ui/notes/NoteDetailUiState;", "app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class NotesScreenKt {

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] XfQCOxz9Pm9BcT;

        static {
            int[] iArr = new int[NoteTextError.values().length];
            try {
                NoteTextError noteTextError = NoteTextError.ADpl0noRbUAhY;
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                NoteTextError noteTextError2 = NoteTextError.ADpl0noRbUAhY;
                iArr[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            XfQCOxz9Pm9BcT = iArr;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:71:0x0277  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void NzWQJjWwugl4VFs(Function0 function0, NotesViewModel notesViewModel, Composer composer, int i) {
        final NotesViewModel notesViewModel2;
        final NotesViewModel notesViewModel3;
        NoteSnackbarMessage noteSnackbarMessage;
        MutableState mutableState;
        int i2;
        Object next;
        boolean z;
        function0.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-144514150);
        int i3 = 2;
        int i4 = i | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function0) ? 4 : 2) | 16;
        final int i5 = 1;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i4 & 1, (i4 & 19) != 18)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                }
                notesViewModel3 = (NotesViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(NotesViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                notesViewModel3 = notesViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(notesViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            List listJcThbbljzdkQV = CollectionsKt.jcThbbljzdkQV(StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_newest_first, composerPIQ5UlgpXmpV), StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_oldest_first, composerPIQ5UlgpXmpV), StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_by_item_name, composerPIQ5UlgpXmpV));
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Object obj = Composer.Companion.XfQCOxz9Pm9BcT;
            if (objUVptkJu9raq3 == obj) {
                objUVptkJu9raq3 = new SnackbarHostState();
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            SnackbarHostState snackbarHostState = (SnackbarHostState) objUVptkJu9raq3;
            String strXfQCOxz9Pm9BcT = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.note_added, composerPIQ5UlgpXmpV);
            String strXfQCOxz9Pm9BcT2 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.note_copied, composerPIQ5UlgpXmpV);
            final String strXfQCOxz9Pm9BcT3 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.without_dish, composerPIQ5UlgpXmpV);
            String strXfQCOxz9Pm9BcT4 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.no_item_linked, composerPIQ5UlgpXmpV);
            ClipboardManager clipboardManager = (ClipboardManager) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(CompositionLocalsKt.AY1Ge095OJR8sU);
            NoteSnackbarMessage noteSnackbarMessage2 = ((NotesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).KT0nNGpxhUtad;
            boolean zWOuUYCT1RQRv0EU = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(mutableStateXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(strXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(notesViewModel3) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(strXfQCOxz9Pm9BcT2);
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zWOuUYCT1RQRv0EU || objUVptkJu9raq32 == obj) {
                NotesViewModel notesViewModel4 = notesViewModel3;
                noteSnackbarMessage = noteSnackbarMessage2;
                NotesScreenKt$NotesScreen$1$1 notesScreenKt$NotesScreen$1$1 = new NotesScreenKt$NotesScreen$1$1(snackbarHostState, strXfQCOxz9Pm9BcT, notesViewModel4, strXfQCOxz9Pm9BcT2, mutableStateXfQCOxz9Pm9BcT, null);
                notesViewModel3 = notesViewModel4;
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(notesScreenKt$NotesScreen$1$1);
                objUVptkJu9raq32 = notesScreenKt$NotesScreen$1$1;
            } else {
                noteSnackbarMessage = noteSnackbarMessage2;
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, noteSnackbarMessage, (Function2) objUVptkJu9raq32);
            notesViewModel2 = notesViewModel3;
            ScaffoldKt.XfQCOxz9Pm9BcT(null, ComposableLambdaKt.NzWQJjWwugl4VFs(-491742122, new c4(function0, notesViewModel3), composerPIQ5UlgpXmpV), null, ComposableLambdaKt.NzWQJjWwugl4VFs(455295764, new FLMntEtk8XkIet1(17, snackbarHostState), composerPIQ5UlgpXmpV), ComposableLambdaKt.NzWQJjWwugl4VFs(928814707, new Function2() { // from class: y3
                @Override // kotlin.jvm.functions.Function2
                public final Object jtRrC0njHlFmpd(Object obj2, Object obj3) {
                    int i6 = i5;
                    Unit unit = Unit.XfQCOxz9Pm9BcT;
                    Composer$Companion$Empty$1 composer$Companion$Empty$1 = Composer.Companion.XfQCOxz9Pm9BcT;
                    NotesViewModel notesViewModel5 = notesViewModel3;
                    switch (i6) {
                        case 0:
                            Composer composer2 = (Composer) obj2;
                            int iIntValue = ((Integer) obj3).intValue();
                            if (!composer2.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                composer2.R7447vqBon0A();
                                break;
                            } else {
                                boolean zOqhsKX67fcZ7qq = composer2.oqhsKX67fcZ7qq(notesViewModel5);
                                Object objUVptkJu9raq33 = composer2.uVptkJu9raq3();
                                if (zOqhsKX67fcZ7qq || objUVptkJu9raq33 == composer$Companion$Empty$1) {
                                    objUVptkJu9raq33 = new x3(notesViewModel5, 4);
                                    composer2.jcThbbljzdkQV(objUVptkJu9raq33);
                                }
                                ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq33, null, false, null, null, null, ComposableSingletons$NotesScreenKt.Q5MXmkXGmrpQ, composer2, 805306368, 510);
                                break;
                            }
                        default:
                            Composer composer3 = (Composer) obj2;
                            int iIntValue2 = ((Integer) obj3).intValue();
                            if (!composer3.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                composer3.R7447vqBon0A();
                                break;
                            } else {
                                boolean zOqhsKX67fcZ7qq2 = composer3.oqhsKX67fcZ7qq(notesViewModel5);
                                Object objUVptkJu9raq34 = composer3.uVptkJu9raq3();
                                if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq34 == composer$Companion$Empty$1) {
                                    objUVptkJu9raq34 = new x3(notesViewModel5, 3);
                                    composer3.jcThbbljzdkQV(objUVptkJu9raq34);
                                }
                                FloatingActionButtonKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq34, null, null, MaterialTheme.XfQCOxz9Pm9BcT(composer3).XfQCOxz9Pm9BcT, MaterialTheme.XfQCOxz9Pm9BcT(composer3).NzWQJjWwugl4VFs, null, composer3, 12582912);
                                break;
                            }
                    }
                    return unit;
                }
            }, composerPIQ5UlgpXmpV), 0, 0L, 0L, WindowInsetsKt.XfQCOxz9Pm9BcT(), ComposableLambdaKt.NzWQJjWwugl4VFs(1424733355, new d(mutableStateXfQCOxz9Pm9BcT, notesViewModel3, strXfQCOxz9Pm9BcT4, clipboardManager, 3), composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, 805334064, 229);
            if (((NotesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1654323359);
                SheetState sheetStateR7447vqBon0A = ModalBottomSheetKt.R7447vqBon0A(6, 2, composerPIQ5UlgpXmpV);
                boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(notesViewModel2);
                Object objUVptkJu9raq33 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq || objUVptkJu9raq33 == obj) {
                    z = false;
                    objUVptkJu9raq33 = new x3(notesViewModel2, 0);
                    composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq33);
                } else {
                    z = false;
                }
                mutableState = mutableStateXfQCOxz9Pm9BcT;
                ModalBottomSheetKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq33, null, sheetStateR7447vqBon0A, 0.0f, false, null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).TXtQqiMBq0ieO9, 0L, 0L, null, null, null, ComposableLambdaKt.NzWQJjWwugl4VFs(1361873729, new q0(listJcThbbljzdkQV, notesViewModel2, mutableStateXfQCOxz9Pm9BcT, i3), composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, 0);
                composerPIQ5UlgpXmpV = composerPIQ5UlgpXmpV;
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            } else {
                mutableState = mutableStateXfQCOxz9Pm9BcT;
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1652656024);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            }
            Long l = ((NotesUiState) mutableState.getADpl0noRbUAhY()).AY1Ge095OJR8sU;
            if (l == null) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1652623723);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                i2 = 1;
            } else {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1652623722);
                long jLongValue = l.longValue();
                boolean zOqhsKX67fcZ7qq2 = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(notesViewModel2);
                Object objUVptkJu9raq34 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq34 == obj) {
                    i2 = 1;
                    objUVptkJu9raq34 = new x3(notesViewModel2, 1);
                    composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq34);
                } else {
                    i2 = 1;
                }
                XfQCOxz9Pm9BcT(jLongValue, (Function0) objUVptkJu9raq34, null, composerPIQ5UlgpXmpV, 0);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            }
            if (((NotesUiState) mutableState.getADpl0noRbUAhY()).mhkN7GL0jG0Wg1w) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1652326959);
                Object objUVptkJu9raq35 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                if (objUVptkJu9raq35 == obj) {
                    objUVptkJu9raq35 = SnapshotStateKt.Q5MXmkXGmrpQ(Boolean.FALSE);
                    composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq35);
                }
                final MutableState mutableState2 = (MutableState) objUVptkJu9raq35;
                Long l2 = ((NotesUiState) mutableState.getADpl0noRbUAhY()).uVptkJu9raq3;
                String strXfQCOxz9Pm9BcT5 = null;
                if (l2 != null) {
                    long jLongValue2 = l2.longValue();
                    Iterator it = ((NotesUiState) mutableState.getADpl0noRbUAhY()).NzWQJjWwugl4VFs.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            next = null;
                            break;
                        } else {
                            next = it.next();
                            if (((MenuItemEntity) next).XfQCOxz9Pm9BcT == jLongValue2) {
                                break;
                            }
                        }
                    }
                    MenuItemEntity menuItemEntity = (MenuItemEntity) next;
                    String str = menuItemEntity != null ? menuItemEntity.NzWQJjWwugl4VFs : null;
                    final String str2 = str == null ? strXfQCOxz9Pm9BcT3 : str;
                    NoteTextError noteTextError = ((NotesUiState) mutableState.getADpl0noRbUAhY()).hargS3kTbQOR;
                    int i6 = noteTextError == null ? -1 : WhenMappings.XfQCOxz9Pm9BcT[noteTextError.ordinal()];
                    if (i6 == -1) {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1651961501);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    } else if (i6 == i2) {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1438767035);
                        strXfQCOxz9Pm9BcT5 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.note_text_required, composerPIQ5UlgpXmpV);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    } else if (i6 != 2) {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1438769088);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                        defpackage.XfQCOxz9Pm9BcT.jpgeID8zMPb9();
                        return;
                    } else {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1438764411);
                        strXfQCOxz9Pm9BcT5 = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.note_text_too_long, composerPIQ5UlgpXmpV);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    }
                    final String str3 = strXfQCOxz9Pm9BcT5;
                    boolean zOqhsKX67fcZ7qq3 = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(notesViewModel2);
                    Object objUVptkJu9raq36 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                    if (zOqhsKX67fcZ7qq3 || objUVptkJu9raq36 == obj) {
                        objUVptkJu9raq36 = new x3(notesViewModel2, 2);
                        composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq36);
                    }
                    final MutableState mutableState3 = mutableState;
                    final int i7 = 0;
                    Composer composer2 = composerPIQ5UlgpXmpV;
                    AndroidAlertDialog_androidKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq36, ComposableLambdaKt.NzWQJjWwugl4VFs(-1453898288, new jIAALsBkQIUpNq8(14, notesViewModel2, mutableState3), composerPIQ5UlgpXmpV), null, ComposableLambdaKt.NzWQJjWwugl4VFs(1053199186, new Function2() { // from class: y3
                        @Override // kotlin.jvm.functions.Function2
                        public final Object jtRrC0njHlFmpd(Object obj2, Object obj3) {
                            int i62 = i7;
                            Unit unit = Unit.XfQCOxz9Pm9BcT;
                            Composer$Companion$Empty$1 composer$Companion$Empty$1 = Composer.Companion.XfQCOxz9Pm9BcT;
                            NotesViewModel notesViewModel5 = notesViewModel2;
                            switch (i62) {
                                case 0:
                                    Composer composer22 = (Composer) obj2;
                                    int iIntValue = ((Integer) obj3).intValue();
                                    if (!composer22.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                        composer22.R7447vqBon0A();
                                        break;
                                    } else {
                                        boolean zOqhsKX67fcZ7qq4 = composer22.oqhsKX67fcZ7qq(notesViewModel5);
                                        Object objUVptkJu9raq332 = composer22.uVptkJu9raq3();
                                        if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq332 == composer$Companion$Empty$1) {
                                            objUVptkJu9raq332 = new x3(notesViewModel5, 4);
                                            composer22.jcThbbljzdkQV(objUVptkJu9raq332);
                                        }
                                        ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq332, null, false, null, null, null, ComposableSingletons$NotesScreenKt.Q5MXmkXGmrpQ, composer22, 805306368, 510);
                                        break;
                                    }
                                default:
                                    Composer composer3 = (Composer) obj2;
                                    int iIntValue2 = ((Integer) obj3).intValue();
                                    if (!composer3.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                        composer3.R7447vqBon0A();
                                        break;
                                    } else {
                                        boolean zOqhsKX67fcZ7qq22 = composer3.oqhsKX67fcZ7qq(notesViewModel5);
                                        Object objUVptkJu9raq342 = composer3.uVptkJu9raq3();
                                        if (zOqhsKX67fcZ7qq22 || objUVptkJu9raq342 == composer$Companion$Empty$1) {
                                            objUVptkJu9raq342 = new x3(notesViewModel5, 3);
                                            composer3.jcThbbljzdkQV(objUVptkJu9raq342);
                                        }
                                        FloatingActionButtonKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq342, null, null, MaterialTheme.XfQCOxz9Pm9BcT(composer3).XfQCOxz9Pm9BcT, MaterialTheme.XfQCOxz9Pm9BcT(composer3).NzWQJjWwugl4VFs, null, composer3, 12582912);
                                        break;
                                    }
                            }
                            return unit;
                        }
                    }, composerPIQ5UlgpXmpV), ComposableSingletons$NotesScreenKt.mhkN7GL0jG0Wg1w, ComposableLambdaKt.NzWQJjWwugl4VFs(-1628605547, new Function2() { // from class: d4
                        @Override // kotlin.jvm.functions.Function2
                        public final Object jtRrC0njHlFmpd(Object obj2, Object obj3) {
                            Composer composer3 = (Composer) obj2;
                            int iIntValue = ((Integer) obj3).intValue();
                            if (composer3.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                ColumnMeasurePolicy columnMeasurePolicyXfQCOxz9Pm9BcT = ColumnKt.XfQCOxz9Pm9BcT(Arrangement.Q5MXmkXGmrpQ(12.0f), Alignment.Companion.KT0nNGpxhUtad, composer3, 6);
                                int iHashCode = Long.hashCode(composer3.getADpl0noRbUAhY());
                                PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd = composer3.nSB32oL0LrDTKFd();
                                Modifier modifierADpl0noRbUAhY = ComposedModifierKt.ADpl0noRbUAhY(composer3, Modifier.Companion.ADpl0noRbUAhY);
                                ComposeUiNode.NzWQJjWwugl4VFs.getClass();
                                Function0 function02 = ComposeUiNode.Companion.NzWQJjWwugl4VFs;
                                ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs = null;
                                if (composer3.J1WzLTBdSsmQzK() == null) {
                                    ComposablesKt.XfQCOxz9Pm9BcT();
                                    throw null;
                                }
                                composer3.XodfXzJCenbBF();
                                if (composer3.getEqwJwm8oIiKHLs()) {
                                    composer3.eqwJwm8oIiKHLs(function02);
                                } else {
                                    composer3.HDXQYm0hWNKDrl();
                                }
                                Updater.NzWQJjWwugl4VFs(composer3, columnMeasurePolicyXfQCOxz9Pm9BcT, ComposeUiNode.Companion.R7447vqBon0A);
                                Updater.NzWQJjWwugl4VFs(composer3, persistentCompositionLocalMapNSB32oL0LrDTKFd, ComposeUiNode.Companion.AY1Ge095OJR8sU);
                                Updater.NzWQJjWwugl4VFs(composer3, Integer.valueOf(iHashCode), ComposeUiNode.Companion.Q5MXmkXGmrpQ);
                                Updater.XfQCOxz9Pm9BcT(composer3, ComposeUiNode.Companion.mhkN7GL0jG0Wg1w);
                                Updater.NzWQJjWwugl4VFs(composer3, modifierADpl0noRbUAhY, ComposeUiNode.Companion.ADpl0noRbUAhY);
                                MutableState mutableState4 = mutableState2;
                                boolean zBooleanValue = ((Boolean) mutableState4.getADpl0noRbUAhY()).booleanValue();
                                Object objUVptkJu9raq37 = composer3.uVptkJu9raq3();
                                Composer$Companion$Empty$1 composer$Companion$Empty$1 = Composer.Companion.XfQCOxz9Pm9BcT;
                                if (objUVptkJu9raq37 == composer$Companion$Empty$1) {
                                    objUVptkJu9raq37 = new PshsHemYN6Jxj3l(mutableState4, 3);
                                    composer3.jcThbbljzdkQV(objUVptkJu9raq37);
                                }
                                String str4 = str2;
                                NotesViewModel notesViewModel5 = notesViewModel2;
                                String str5 = strXfQCOxz9Pm9BcT3;
                                MutableState mutableState5 = mutableState3;
                                ExposedDropdownMenuKt.XfQCOxz9Pm9BcT(zBooleanValue, (Function1) objUVptkJu9raq37, null, ComposableLambdaKt.NzWQJjWwugl4VFs(520896289, new p2(str4, mutableState4, notesViewModel5, str5, mutableState5), composer3), composer3, 3120, 4);
                                String str6 = ((NotesUiState) mutableState5.getADpl0noRbUAhY()).Ib3GalHLi1oFkSI;
                                FillElement fillElement = SizeKt.XfQCOxz9Pm9BcT;
                                boolean z2 = ((NotesUiState) mutableState5.getADpl0noRbUAhY()).hargS3kTbQOR != null;
                                String str7 = str3;
                                if (str7 == null) {
                                    composer3.Y9lRRazOjmFYx(1808536994);
                                } else {
                                    composer3.Y9lRRazOjmFYx(1808536995);
                                    composableLambdaImplNzWQJjWwugl4VFs = ComposableLambdaKt.NzWQJjWwugl4VFs(-1481022326, new p0(9, str7), composer3);
                                }
                                composer3.V02FBF0Ulcpcy();
                                RoundedCornerShape roundedCornerShapeXfQCOxz9Pm9BcT = RoundedCornerShapeKt.XfQCOxz9Pm9BcT(12.0f);
                                boolean zOqhsKX67fcZ7qq4 = composer3.oqhsKX67fcZ7qq(notesViewModel5);
                                Object objUVptkJu9raq38 = composer3.uVptkJu9raq3();
                                if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq38 == composer$Companion$Empty$1) {
                                    objUVptkJu9raq38 = new b4(0, notesViewModel5);
                                    composer3.jcThbbljzdkQV(objUVptkJu9raq38);
                                }
                                OutlinedTextFieldKt.XfQCOxz9Pm9BcT(str6, (Function1) objUVptkJu9raq38, fillElement, false, false, null, ComposableSingletons$NotesScreenKt.uVptkJu9raq3, null, null, composableLambdaImplNzWQJjWwugl4VFs, z2, null, null, null, true, 0, 0, roundedCornerShapeXfQCOxz9Pm9BcT, null, composer3, 1573248, 6148024);
                                composer3.Mr6Qni2bHsJ0X();
                            } else {
                                composer3.R7447vqBon0A();
                            }
                            return Unit.XfQCOxz9Pm9BcT;
                        }
                    }, composerPIQ5UlgpXmpV), null, 0L, 0L, 0L, 0L, null, composer2, 1772592);
                    composerPIQ5UlgpXmpV = composer2;
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                }
            } else {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1648522360);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            }
        } else {
            composerPIQ5UlgpXmpV.R7447vqBon0A();
            notesViewModel2 = notesViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new c4(function0, notesViewModel2, i));
        }
    }

    public static final void XfQCOxz9Pm9BcT(long j, Function0 function0, NoteDetailViewModel noteDetailViewModel, Composer composer, int i) {
        Composer composer2;
        final NoteDetailViewModel noteDetailViewModel2;
        int i2;
        NoteDetailViewModel noteDetailViewModel3;
        int i3;
        function0.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-2031421380);
        int i4 = i | (composerPIQ5UlgpXmpV.KT0nNGpxhUtad(j) ? 4 : 2) | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function0) ? 32 : 16) | 128;
        final int i5 = 0;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i4 & 1, (i4 & 147) != 146)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                } else {
                    NoteDetailViewModel noteDetailViewModel4 = (NoteDetailViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(NoteDetailViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
                    i2 = i4 & (-897);
                    noteDetailViewModel3 = noteDetailViewModel4;
                }
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                i2 = i4 & (-897);
                noteDetailViewModel3 = noteDetailViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(noteDetailViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            SheetState sheetStateR7447vqBon0A = ModalBottomSheetKt.R7447vqBon0A(6, 2, composerPIQ5UlgpXmpV);
            String strXfQCOxz9Pm9BcT = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.no_item_linked, composerPIQ5UlgpXmpV);
            Long lValueOf = Long.valueOf(j);
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(noteDetailViewModel3) | ((i2 & 14) == 4);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Composer$Companion$Empty$1 composer$Companion$Empty$1 = Composer.Companion.XfQCOxz9Pm9BcT;
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq3 == composer$Companion$Empty$1) {
                objUVptkJu9raq3 = new NotesScreenKt$NoteDetailBottomSheet$1$1(noteDetailViewModel3, j, null);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, lValueOf, (Function2) objUVptkJu9raq3);
            boolean zOqhsKX67fcZ7qq2 = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(noteDetailViewModel3) | ((i2 & 112) == 32);
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            int i6 = 15;
            if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq32 == composer$Companion$Empty$1) {
                objUVptkJu9raq32 = new eXZoBnCfBCqjp(i6, noteDetailViewModel3, function0);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq32);
            }
            long j2 = MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).TXtQqiMBq0ieO9;
            ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs = ComposableLambdaKt.NzWQJjWwugl4VFs(-2035740642, new q0(mutableStateXfQCOxz9Pm9BcT, strXfQCOxz9Pm9BcT, noteDetailViewModel3, 3), composerPIQ5UlgpXmpV);
            noteDetailViewModel2 = noteDetailViewModel3;
            ModalBottomSheetKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq32, null, sheetStateR7447vqBon0A, 0.0f, false, null, j2, 0L, 0L, null, null, null, composableLambdaImplNzWQJjWwugl4VFs, composerPIQ5UlgpXmpV, 0);
            composer2 = composerPIQ5UlgpXmpV;
            if (((NoteDetailUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).ADpl0noRbUAhY) {
                composer2.Y9lRRazOjmFYx(-1980938312);
                boolean zOqhsKX67fcZ7qq3 = composer2.oqhsKX67fcZ7qq(noteDetailViewModel2);
                Object objUVptkJu9raq33 = composer2.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq3 || objUVptkJu9raq33 == composer$Companion$Empty$1) {
                    objUVptkJu9raq33 = new z3(noteDetailViewModel2, 0);
                    composer2.jcThbbljzdkQV(objUVptkJu9raq33);
                }
                final int i7 = 1;
                i3 = 1;
                AndroidAlertDialog_androidKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq33, ComposableLambdaKt.NzWQJjWwugl4VFs(748163913, new Function2() { // from class: a4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                        int i8 = i5;
                        Unit unit = Unit.XfQCOxz9Pm9BcT;
                        Composer$Companion$Empty$1 composer$Companion$Empty$12 = Composer.Companion.XfQCOxz9Pm9BcT;
                        NoteDetailViewModel noteDetailViewModel5 = noteDetailViewModel2;
                        switch (i8) {
                            case 0:
                                Composer composer3 = (Composer) obj;
                                int iIntValue = ((Integer) obj2).intValue();
                                if (!composer3.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                    composer3.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq4 = composer3.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq34 = composer3.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq34 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq34 = new XfQCOxz9Pm9BcT(noteDetailViewModel5, 1);
                                        composer3.jcThbbljzdkQV(objUVptkJu9raq34);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq34, null, false, null, null, null, ComposableSingletons$NotesScreenKt.KT0nNGpxhUtad, composer3, 805306368, 510);
                                    break;
                                }
                            case 1:
                                Composer composer4 = (Composer) obj;
                                int iIntValue2 = ((Integer) obj2).intValue();
                                if (!composer4.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                    composer4.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq5 = composer4.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq35 = composer4.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq5 || objUVptkJu9raq35 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq35 = new z3(noteDetailViewModel5, 5);
                                        composer4.jcThbbljzdkQV(objUVptkJu9raq35);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq35, null, false, null, null, null, ComposableSingletons$NotesScreenKt.plDIFW7uQvLLZ1, composer4, 805306368, 510);
                                    break;
                                }
                            default:
                                Composer composer5 = (Composer) obj;
                                int iIntValue3 = ((Integer) obj2).intValue();
                                if (!composer5.Sq4Z9oOaVh4F(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                                    composer5.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq6 = composer5.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq36 = composer5.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq6 || objUVptkJu9raq36 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq36 = new z3(noteDetailViewModel5, 4);
                                        composer5.jcThbbljzdkQV(objUVptkJu9raq36);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq36, null, false, null, null, null, ComposableSingletons$NotesScreenKt.iyZDfhenXfXSTA, composer5, 805306368, 510);
                                    break;
                                }
                        }
                        return unit;
                    }
                }, composer2), null, ComposableLambdaKt.NzWQJjWwugl4VFs(1092992075, new Function2() { // from class: a4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                        int i8 = i7;
                        Unit unit = Unit.XfQCOxz9Pm9BcT;
                        Composer$Companion$Empty$1 composer$Companion$Empty$12 = Composer.Companion.XfQCOxz9Pm9BcT;
                        NoteDetailViewModel noteDetailViewModel5 = noteDetailViewModel2;
                        switch (i8) {
                            case 0:
                                Composer composer3 = (Composer) obj;
                                int iIntValue = ((Integer) obj2).intValue();
                                if (!composer3.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                    composer3.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq4 = composer3.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq34 = composer3.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq34 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq34 = new XfQCOxz9Pm9BcT(noteDetailViewModel5, 1);
                                        composer3.jcThbbljzdkQV(objUVptkJu9raq34);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq34, null, false, null, null, null, ComposableSingletons$NotesScreenKt.KT0nNGpxhUtad, composer3, 805306368, 510);
                                    break;
                                }
                            case 1:
                                Composer composer4 = (Composer) obj;
                                int iIntValue2 = ((Integer) obj2).intValue();
                                if (!composer4.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                    composer4.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq5 = composer4.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq35 = composer4.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq5 || objUVptkJu9raq35 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq35 = new z3(noteDetailViewModel5, 5);
                                        composer4.jcThbbljzdkQV(objUVptkJu9raq35);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq35, null, false, null, null, null, ComposableSingletons$NotesScreenKt.plDIFW7uQvLLZ1, composer4, 805306368, 510);
                                    break;
                                }
                            default:
                                Composer composer5 = (Composer) obj;
                                int iIntValue3 = ((Integer) obj2).intValue();
                                if (!composer5.Sq4Z9oOaVh4F(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                                    composer5.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq6 = composer5.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq36 = composer5.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq6 || objUVptkJu9raq36 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq36 = new z3(noteDetailViewModel5, 4);
                                        composer5.jcThbbljzdkQV(objUVptkJu9raq36);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq36, null, false, null, null, null, ComposableSingletons$NotesScreenKt.iyZDfhenXfXSTA, composer5, 805306368, 510);
                                    break;
                                }
                        }
                        return unit;
                    }
                }, composer2), ComposableSingletons$NotesScreenKt.oqhsKX67fcZ7qq, ComposableLambdaKt.NzWQJjWwugl4VFs(1610234318, new jIAALsBkQIUpNq8(15, noteDetailViewModel2, mutableStateXfQCOxz9Pm9BcT), composer2), null, 0L, 0L, 0L, 0L, null, composer2, 1772592);
                composer2 = composer2;
                composer2.V02FBF0Ulcpcy();
            } else {
                i3 = 1;
                composer2.Y9lRRazOjmFYx(-1979848538);
                composer2.V02FBF0Ulcpcy();
            }
            if (((NoteDetailUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ) {
                composer2.Y9lRRazOjmFYx(-1979783841);
                boolean zOqhsKX67fcZ7qq4 = composer2.oqhsKX67fcZ7qq(noteDetailViewModel2);
                Object objUVptkJu9raq34 = composer2.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq34 == composer$Companion$Empty$1) {
                    objUVptkJu9raq34 = new z3(noteDetailViewModel2, i3);
                    composer2.jcThbbljzdkQV(objUVptkJu9raq34);
                }
                final int i8 = 2;
                Composer composer3 = composer2;
                AndroidAlertDialog_androidKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq34, ComposableLambdaKt.NzWQJjWwugl4VFs(-316791950, new jIAALsBkQIUpNq8(16, noteDetailViewModel2, function0), composer2), null, ComposableLambdaKt.NzWQJjWwugl4VFs(350589940, new Function2() { // from class: a4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                        int i82 = i8;
                        Unit unit = Unit.XfQCOxz9Pm9BcT;
                        Composer$Companion$Empty$1 composer$Companion$Empty$12 = Composer.Companion.XfQCOxz9Pm9BcT;
                        NoteDetailViewModel noteDetailViewModel5 = noteDetailViewModel2;
                        switch (i82) {
                            case 0:
                                Composer composer32 = (Composer) obj;
                                int iIntValue = ((Integer) obj2).intValue();
                                if (!composer32.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                    composer32.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq42 = composer32.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq342 = composer32.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq42 || objUVptkJu9raq342 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq342 = new XfQCOxz9Pm9BcT(noteDetailViewModel5, 1);
                                        composer32.jcThbbljzdkQV(objUVptkJu9raq342);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq342, null, false, null, null, null, ComposableSingletons$NotesScreenKt.KT0nNGpxhUtad, composer32, 805306368, 510);
                                    break;
                                }
                            case 1:
                                Composer composer4 = (Composer) obj;
                                int iIntValue2 = ((Integer) obj2).intValue();
                                if (!composer4.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                    composer4.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq5 = composer4.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq35 = composer4.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq5 || objUVptkJu9raq35 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq35 = new z3(noteDetailViewModel5, 5);
                                        composer4.jcThbbljzdkQV(objUVptkJu9raq35);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq35, null, false, null, null, null, ComposableSingletons$NotesScreenKt.plDIFW7uQvLLZ1, composer4, 805306368, 510);
                                    break;
                                }
                            default:
                                Composer composer5 = (Composer) obj;
                                int iIntValue3 = ((Integer) obj2).intValue();
                                if (!composer5.Sq4Z9oOaVh4F(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                                    composer5.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq6 = composer5.oqhsKX67fcZ7qq(noteDetailViewModel5);
                                    Object objUVptkJu9raq36 = composer5.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq6 || objUVptkJu9raq36 == composer$Companion$Empty$12) {
                                        objUVptkJu9raq36 = new z3(noteDetailViewModel5, 4);
                                        composer5.jcThbbljzdkQV(objUVptkJu9raq36);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq36, null, false, null, null, null, ComposableSingletons$NotesScreenKt.iyZDfhenXfXSTA, composer5, 805306368, 510);
                                    break;
                                }
                        }
                        return unit;
                    }
                }, composer2), ComposableSingletons$NotesScreenKt.nSB32oL0LrDTKFd, ComposableSingletons$NotesScreenKt.jScSmm0NvYn0J, null, 0L, 0L, 0L, 0L, null, composer3, 1772592);
                composer2 = composer3;
                composer2.V02FBF0Ulcpcy();
            } else {
                composer2.Y9lRRazOjmFYx(-1979008314);
                composer2.V02FBF0Ulcpcy();
            }
        } else {
            composer2 = composerPIQ5UlgpXmpV;
            composer2.R7447vqBon0A();
            noteDetailViewModel2 = noteDetailViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composer2.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new l0(j, function0, noteDetailViewModel2, i, 1));
        }
    }
}
