package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
final class MenuScreenKt$MenuScreen$2$1$5$1$1$2$1$2$3$1$1 implements Function0<Unit> {
    public static final MenuScreenKt$MenuScreen$2$1$5$1$1$2$1$2$3$1$1 ADpl0noRbUAhY = new MenuScreenKt$MenuScreen$2$1$5$1$1$2$1$2$3$1$1();

    @Override // kotlin.jvm.functions.Function0
    public final /* bridge */ /* synthetic */ Object NzWQJjWwugl4VFs() {
        return Unit.XfQCOxz9Pm9BcT;
    }
}
