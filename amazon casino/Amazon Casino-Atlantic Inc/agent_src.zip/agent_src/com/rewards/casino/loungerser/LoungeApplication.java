package com.rewards.casino.loungerser;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.datastore.preferences.protobuf.DescriptorProtos;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import dagger.hilt.android.HiltAndroidApp;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobSupport;
import kotlinx.coroutines.SupervisorKt;
import kotlinx.coroutines.internal.ContextScope;
import kotlinx.coroutines.scheduling.DefaultIoScheduler;
import kotlinx.coroutines.scheduling.DefaultScheduler;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/rewards/casino/loungerser/LoungeApplication;", "Landroid/app/Application;", "<init>", "()V", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@HiltAndroidApp
/* loaded from: classes.dex */
public class LoungeApplication extends Hilt_LoungeApplication {
    public final ContextScope Q5MXmkXGmrpQ;
    public AppRepository R7447vqBon0A;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    @DebugMetadata(c = "com.rewards.casino.loungerser.LoungeApplication$onCreate$1", f = "LoungeApplication.kt", l = {DescriptorProtos.FileOptions.DEPRECATED_FIELD_NUMBER}, m = "invokeSuspend", v = 2)
    /* renamed from: com.rewards.casino.loungerser.LoungeApplication$onCreate$1, reason: invalid class name */
    final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        public int mhkN7GL0jG0Wg1w;

        public AnonymousClass1(Continuation continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object HDXQYm0hWNKDrl(Object obj) {
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
            int i = this.mhkN7GL0jG0Wg1w;
            if (i == 0) {
                ResultKt.NzWQJjWwugl4VFs(obj);
                AppRepository appRepository = LoungeApplication.this.R7447vqBon0A;
                if (appRepository == null) {
                    Intrinsics.R7447vqBon0A("repository");
                    throw null;
                }
                this.mhkN7GL0jG0Wg1w = 1;
                if (appRepository.NzWQJjWwugl4VFs(this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ResultKt.NzWQJjWwugl4VFs(obj);
            }
            return Unit.XfQCOxz9Pm9BcT;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
            return ((AnonymousClass1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
            return LoungeApplication.this.new AnonymousClass1(continuation);
        }
    }

    public LoungeApplication() {
        Job jobNzWQJjWwugl4VFs = SupervisorKt.NzWQJjWwugl4VFs();
        DefaultScheduler defaultScheduler = Dispatchers.XfQCOxz9Pm9BcT;
        this.Q5MXmkXGmrpQ = CoroutineScopeKt.XfQCOxz9Pm9BcT(CoroutineContext.Element.DefaultImpls.f6FsnIUuKXgtm((JobSupport) jobNzWQJjWwugl4VFs, DefaultIoScheduler.R7447vqBon0A));
    }

    @Override // com.rewards.casino.loungerser.Hilt_LoungeApplication, android.app.Application
    public final void onCreate() {
        super.onCreate();
        BuildersKt.NzWQJjWwugl4VFs(this.Q5MXmkXGmrpQ, null, null, new AnonymousClass1(null), 3);
    }
}
