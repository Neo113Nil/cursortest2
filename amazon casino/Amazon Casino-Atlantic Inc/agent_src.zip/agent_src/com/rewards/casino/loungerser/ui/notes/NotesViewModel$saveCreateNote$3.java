package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesViewModel$saveCreateNote$3", f = "NotesViewModel.kt", l = {165}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NotesViewModel$saveCreateNote$3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ NotesViewModel Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ String uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesViewModel$saveCreateNote$3(NotesViewModel notesViewModel, String str, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = notesViewModel;
        this.uVptkJu9raq3 = str;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        Object value2;
        NotesViewModel notesViewModel = this.Ib3GalHLi1oFkSI;
        MutableStateFlow mutableStateFlow = notesViewModel.f6FsnIUuKXgtm;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value, null, null, null, null, null, false, false, null, null, null, true, null, 12287)));
            AppRepository appRepository = notesViewModel.NzWQJjWwugl4VFs;
            Long l = ((NotesUiState) mutableStateFlow.getValue()).uVptkJu9raq3;
            this.mhkN7GL0jG0Wg1w = 1;
            if (appRepository.f6FsnIUuKXgtm.AY1Ge095OJR8sU(new NoteEntity(0L, l, this.uVptkJu9raq3, System.currentTimeMillis()), this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        notesViewModel.mhkN7GL0jG0Wg1w();
        do {
            value2 = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value2, NotesUiState.XfQCOxz9Pm9BcT((NotesUiState) value2, null, null, null, null, null, false, false, null, null, null, false, NoteSnackbarMessage.ADpl0noRbUAhY, 8191)));
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NotesViewModel$saveCreateNote$3) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NotesViewModel$saveCreateNote$3(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, continuation);
    }
}
