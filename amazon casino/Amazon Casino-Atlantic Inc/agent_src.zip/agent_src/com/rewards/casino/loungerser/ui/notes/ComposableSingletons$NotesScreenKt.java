package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.BTSST24gkDbxl1;
import defpackage.YtVqGpkhpxZ5;
import defpackage.jpgeID8zMPb9;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$NotesScreenKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(626938138, new BTSST24gkDbxl1(25), false);
    public static final ComposableLambdaImpl NzWQJjWwugl4VFs = new ComposableLambdaImpl(-1079252550, new BTSST24gkDbxl1(27), false);
    public static final ComposableLambdaImpl f6FsnIUuKXgtm = new ComposableLambdaImpl(587627559, new BTSST24gkDbxl1(28), false);
    public static final ComposableLambdaImpl ADpl0noRbUAhY = new ComposableLambdaImpl(1148942641, new BTSST24gkDbxl1(29), false);
    public static final ComposableLambdaImpl AY1Ge095OJR8sU = new ComposableLambdaImpl(-159074146, new YtVqGpkhpxZ5(0), false);
    public static final ComposableLambdaImpl R7447vqBon0A = new ComposableLambdaImpl(-1205956339, new jpgeID8zMPb9(12), false);
    public static final ComposableLambdaImpl Q5MXmkXGmrpQ = new ComposableLambdaImpl(1301141135, new jpgeID8zMPb9(13), false);
    public static final ComposableLambdaImpl mhkN7GL0jG0Wg1w = new ComposableLambdaImpl(-734670636, new YtVqGpkhpxZ5(1), false);
    public static final ComposableLambdaImpl Ib3GalHLi1oFkSI = new ComposableLambdaImpl(-868288453, new YtVqGpkhpxZ5(2), false);
    public static final ComposableLambdaImpl uVptkJu9raq3 = new ComposableLambdaImpl(-259234267, new YtVqGpkhpxZ5(3), false);
    public static final ComposableLambdaImpl hargS3kTbQOR = new ComposableLambdaImpl(-1531420130, new jpgeID8zMPb9(14), false);
    public static final ComposableLambdaImpl jtRrC0njHlFmpd = new ComposableLambdaImpl(-2137175225, new jpgeID8zMPb9(15), false);
    public static final ComposableLambdaImpl KT0nNGpxhUtad = new ComposableLambdaImpl(-1545868986, new jpgeID8zMPb9(16), false);
    public static final ComposableLambdaImpl plDIFW7uQvLLZ1 = new ComposableLambdaImpl(-1201040824, new jpgeID8zMPb9(17), false);
    public static final ComposableLambdaImpl oqhsKX67fcZ7qq = new ComposableLambdaImpl(1437820237, new YtVqGpkhpxZ5(4), false);
    public static final ComposableLambdaImpl TXtQqiMBq0ieO9 = new ComposableLambdaImpl(775387752, new YtVqGpkhpxZ5(5), false);
    public static final ComposableLambdaImpl jpgeID8zMPb9 = new ComposableLambdaImpl(-1564185041, new jpgeID8zMPb9(18), false);
    public static final ComposableLambdaImpl iyZDfhenXfXSTA = new ComposableLambdaImpl(-896803151, new jpgeID8zMPb9(19), false);
    public static final ComposableLambdaImpl nSB32oL0LrDTKFd = new ComposableLambdaImpl(1017971830, new YtVqGpkhpxZ5(6), false);
    public static final ComposableLambdaImpl jScSmm0NvYn0J = new ComposableLambdaImpl(-795820873, new BTSST24gkDbxl1(26), false);
}
