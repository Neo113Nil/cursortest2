package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.SnackbarHostState;
import androidx.compose.runtime.MutableState;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.menu.MenuScreenKt$MenuDetailSideSheet$2$1", f = "MenuScreen.kt", l = {299}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MenuScreenKt$MenuDetailSideSheet$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ SnackbarHostState Ib3GalHLi1oFkSI;
    public final /* synthetic */ MenuDetailViewModel hargS3kTbQOR;
    public final /* synthetic */ MutableState jtRrC0njHlFmpd;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ String uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MenuScreenKt$MenuDetailSideSheet$2$1(SnackbarHostState snackbarHostState, String str, MenuDetailViewModel menuDetailViewModel, MutableState mutableState, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = snackbarHostState;
        this.uVptkJu9raq3 = str;
        this.hargS3kTbQOR = menuDetailViewModel;
        this.jtRrC0njHlFmpd = mutableState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            if (((MenuDetailUiState) this.jtRrC0njHlFmpd.getADpl0noRbUAhY()).mhkN7GL0jG0Wg1w == NoteSnackbarMessage.ADpl0noRbUAhY) {
                this.mhkN7GL0jG0Wg1w = 1;
                if (SnackbarHostState.NzWQJjWwugl4VFs(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            }
            return Unit.XfQCOxz9Pm9BcT;
        }
        if (i != 1) {
            defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        ResultKt.NzWQJjWwugl4VFs(obj);
        MutableStateFlow mutableStateFlow = this.hargS3kTbQOR.f6FsnIUuKXgtm;
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.R7447vqBon0A(value, MenuDetailUiState.XfQCOxz9Pm9BcT((MenuDetailUiState) value, null, false, null, false, false, null, null, null, 255)));
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((MenuScreenKt$MenuDetailSideSheet$2$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MenuScreenKt$MenuDetailSideSheet$2$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this.hargS3kTbQOR, this.jtRrC0njHlFmpd, continuation);
    }
}
