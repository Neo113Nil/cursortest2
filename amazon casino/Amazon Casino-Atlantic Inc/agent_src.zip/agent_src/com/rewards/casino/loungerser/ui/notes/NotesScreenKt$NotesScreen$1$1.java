package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.SnackbarHostState;
import androidx.compose.runtime.MutableState;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesScreenKt$NotesScreen$1$1", f = "NotesScreen.kt", l = {99, 103}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NotesScreenKt$NotesScreen$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ SnackbarHostState Ib3GalHLi1oFkSI;
    public final /* synthetic */ MutableState KT0nNGpxhUtad;
    public final /* synthetic */ NotesViewModel hargS3kTbQOR;
    public final /* synthetic */ String jtRrC0njHlFmpd;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ String uVptkJu9raq3;

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] XfQCOxz9Pm9BcT;

        static {
            int[] iArr = new int[NoteSnackbarMessage.values().length];
            try {
                NoteSnackbarMessage noteSnackbarMessage = NoteSnackbarMessage.ADpl0noRbUAhY;
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                NoteSnackbarMessage noteSnackbarMessage2 = NoteSnackbarMessage.ADpl0noRbUAhY;
                iArr[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            XfQCOxz9Pm9BcT = iArr;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesScreenKt$NotesScreen$1$1(SnackbarHostState snackbarHostState, String str, NotesViewModel notesViewModel, String str2, MutableState mutableState, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = snackbarHostState;
        this.uVptkJu9raq3 = str;
        this.hargS3kTbQOR = notesViewModel;
        this.jtRrC0njHlFmpd = str2;
        this.KT0nNGpxhUtad = mutableState;
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0047, code lost:
    
        if (androidx.compose.material3.SnackbarHostState.NzWQJjWwugl4VFs(r1, r7.jtRrC0njHlFmpd, r7) == r0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x005a, code lost:
    
        if (androidx.compose.material3.SnackbarHostState.NzWQJjWwugl4VFs(r1, r7.uVptkJu9raq3, r7) == r0) goto L26;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        NotesViewModel notesViewModel = this.hargS3kTbQOR;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            NoteSnackbarMessage noteSnackbarMessage = ((NotesUiState) this.KT0nNGpxhUtad.getADpl0noRbUAhY()).KT0nNGpxhUtad;
            int i2 = noteSnackbarMessage == null ? -1 : WhenMappings.XfQCOxz9Pm9BcT[noteSnackbarMessage.ordinal()];
            if (i2 != -1) {
                SnackbarHostState snackbarHostState = this.Ib3GalHLi1oFkSI;
                if (i2 == 1) {
                    this.mhkN7GL0jG0Wg1w = 1;
                } else {
                    if (i2 != 2) {
                        defpackage.XfQCOxz9Pm9BcT.jpgeID8zMPb9();
                        return null;
                    }
                    this.mhkN7GL0jG0Wg1w = 2;
                }
                return coroutineSingletons;
            }
        } else if (i == 1) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            notesViewModel.Q5MXmkXGmrpQ();
        } else {
            if (i != 2) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
            notesViewModel.Q5MXmkXGmrpQ();
        }
        return Unit.XfQCOxz9Pm9BcT;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NotesScreenKt$NotesScreen$1$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NotesScreenKt$NotesScreen$1$1(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this.hargS3kTbQOR, this.jtRrC0njHlFmpd, this.KT0nNGpxhUtad, continuation);
    }
}
