package com.rewards.casino.loungerser.ui.menu;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final class MenuViewModel_HiltModules_KeyModule_Provide_LazyMapKey {
    public static final /* synthetic */ int XfQCOxz9Pm9BcT = 0;
}
