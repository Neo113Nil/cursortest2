package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import com.rewards.casino.loungerser.data.entity.TasteMarkEntity;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002À\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/TasteMarkDao;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public interface TasteMarkDao {
    Object NzWQJjWwugl4VFs(TasteMarkEntity tasteMarkEntity, Continuation continuation);

    Object XfQCOxz9Pm9BcT(long j, Continuation continuation);

    FlowUtil$createFlow$$inlined$map$1 f6FsnIUuKXgtm(long j);
}
