package com.rewards.casino.loungerser;

import android.app.Application;
import com.rewards.casino.loungerser.DaggerLoungeApplication_HiltComponents_SingletonC;
import dagger.hilt.android.internal.managers.ApplicationComponentManager;
import dagger.hilt.android.internal.managers.ComponentSupplier;
import dagger.hilt.android.internal.modules.ApplicationContextModule;
import dagger.hilt.internal.GeneratedComponentManagerHolder;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public abstract class Hilt_LoungeApplication extends Application implements GeneratedComponentManagerHolder {
    public boolean ADpl0noRbUAhY = false;
    public final ApplicationComponentManager AY1Ge095OJR8sU = new ApplicationComponentManager(new ComponentSupplier() { // from class: com.rewards.casino.loungerser.Hilt_LoungeApplication.1
        @Override // dagger.hilt.android.internal.managers.ComponentSupplier
        public final Object get() {
            return new DaggerLoungeApplication_HiltComponents_SingletonC.SingletonCImpl(new ApplicationContextModule(Hilt_LoungeApplication.this));
        }
    });

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public final Object AY1Ge095OJR8sU() {
        return this.AY1Ge095OJR8sU.AY1Ge095OJR8sU();
    }

    @Override // android.app.Application
    public void onCreate() {
        if (!this.ADpl0noRbUAhY) {
            this.ADpl0noRbUAhY = true;
            ((LoungeApplication_GeneratedInjector) this.AY1Ge095OJR8sU.AY1Ge095OJR8sU()).XfQCOxz9Pm9BcT((LoungeApplication) this);
        }
        super.onCreate();
    }
}
