package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnMeasurePolicy;
import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValuesImpl;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowMeasurePolicy;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.AndroidAlertDialog_androidKt;
import androidx.compose.material3.AndroidMenu_androidKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ModalBottomSheetKt;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SheetState;
import androidx.compose.material3.SnackbarHostKt;
import androidx.compose.material3.SnackbarHostState;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.Composer$Companion$Empty$1;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.LaunchedEffectImpl;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.PersistentCompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.BiasAlignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.focus.FocusManager;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.rewards.casino.loungerser.R;
import com.rewards.casino.loungerser.ui.menu.ComposableSingletons$MenuScreenKt;
import com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel;
import com.rewards.casino.loungerser.ui.menu.MenuScreenKt;
import com.rewards.casino.loungerser.ui.menu.XfQCOxz9Pm9BcT;
import defpackage.ADpl0noRbUAhY;
import defpackage.FLMntEtk8XkIet1;
import defpackage.Sq4Z9oOaVh4F;
import defpackage.V02FBF0Ulcpcy;
import defpackage.d;
import defpackage.ehGqOszSxmfoL;
import defpackage.f6FsnIUuKXgtm;
import defpackage.jIAALsBkQIUpNq8;
import defpackage.oqhsKX67fcZ7qq;
import defpackage.plDIFW7uQvLLZ1;
import defpackage.s2;
import defpackage.t2;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Reflection;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000¨\u0006\u0005²\u0006\f\u0010\u0001\u001a\u00020\u00008\nX\u008a\u0084\u0002²\u0006\u000e\u0010\u0003\u001a\u00020\u00028\n@\nX\u008a\u008e\u0002²\u0006\f\u0010\u0001\u001a\u00020\u00048\nX\u008a\u0084\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/MenuUiState;", "state", "", "sortMenuExpanded", "Lcom/rewards/casino/loungerser/ui/menu/MenuDetailUiState;", "app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuScreenKt {
    /* JADX WARN: Removed duplicated region for block: B:105:0x0692  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x069c  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x04fa  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x0570  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void NzWQJjWwugl4VFs(MenuViewModel menuViewModel, Composer composer, int i) {
        MenuViewModel menuViewModel2;
        MenuViewModel menuViewModel3;
        Function0 function0;
        MutableState mutableState;
        Object obj;
        boolean z;
        float f;
        Modifier.Companion companion;
        Object obj2;
        Long l;
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-1527809746);
        int i2 = i | 2;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i2 & 1, (i2 & 3) != 2)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                }
                menuViewModel3 = (MenuViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(MenuViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                menuViewModel3 = menuViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(menuViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            FocusManager focusManager = (FocusManager) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(CompositionLocalsKt.Ib3GalHLi1oFkSI);
            List listJcThbbljzdkQV = CollectionsKt.jcThbbljzdkQV(new Pair("All", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_all, composerPIQ5UlgpXmpV)), new Pair("Open Sandwiches", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_open_sandwiches, composerPIQ5UlgpXmpV)), new Pair("Warm Plates", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_warm_plates, composerPIQ5UlgpXmpV)), new Pair("Pastries", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_pastries, composerPIQ5UlgpXmpV)), new Pair("Hot Drinks", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_hot_drinks, composerPIQ5UlgpXmpV)), new Pair("Cold Drinks", StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.category_cold_drinks, composerPIQ5UlgpXmpV)));
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Object obj3 = Composer.Companion.XfQCOxz9Pm9BcT;
            if (objUVptkJu9raq3 == obj3) {
                objUVptkJu9raq3 = SnapshotStateKt.Q5MXmkXGmrpQ(Boolean.FALSE);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            MutableState mutableState2 = (MutableState) objUVptkJu9raq3;
            List listJcThbbljzdkQV2 = CollectionsKt.jcThbbljzdkQV(new Pair(SortOption.ADpl0noRbUAhY, StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_alphabetical, composerPIQ5UlgpXmpV)), new Pair(SortOption.AY1Ge095OJR8sU, StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_by_sweetness, composerPIQ5UlgpXmpV)), new Pair(SortOption.R7447vqBon0A, StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.sort_by_warmth, composerPIQ5UlgpXmpV)));
            String str = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).AY1Ge095OJR8sU;
            String str2 = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).f6FsnIUuKXgtm;
            SortOption sortOption = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).ADpl0noRbUAhY;
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq32 == obj3) {
                objUVptkJu9raq32 = new MenuScreenKt$MenuScreen$1$1(mutableState2, null);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq32);
            }
            Function2 function2 = (Function2) objUVptkJu9raq32;
            CoroutineContext jvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.getJvr2ydndnJ9FEHk();
            boolean zWOuUYCT1RQRv0EU = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(str) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(str2) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(sortOption);
            Object objUVptkJu9raq33 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zWOuUYCT1RQRv0EU || objUVptkJu9raq33 == obj3) {
                objUVptkJu9raq33 = new LaunchedEffectImpl(jvr2ydndnJ9FEHk, function2);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq33);
            }
            Object objUVptkJu9raq34 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq34 == obj3) {
                objUVptkJu9raq34 = new SnackbarHostState();
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq34);
            }
            SnackbarHostState snackbarHostState = (SnackbarHostState) objUVptkJu9raq34;
            FillElement fillElement = SizeKt.f6FsnIUuKXgtm;
            BiasAlignment biasAlignment = Alignment.Companion.XfQCOxz9Pm9BcT;
            MeasurePolicy measurePolicyADpl0noRbUAhY = BoxKt.ADpl0noRbUAhY(biasAlignment, false);
            int iHashCode = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            Modifier modifierADpl0noRbUAhY = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
            ComposeUiNode.NzWQJjWwugl4VFs.getClass();
            Function0 function02 = ComposeUiNode.Companion.NzWQJjWwugl4VFs;
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function02);
            } else {
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Function2 function22 = ComposeUiNode.Companion.R7447vqBon0A;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY, function22);
            Function2 function23 = ComposeUiNode.Companion.AY1Ge095OJR8sU;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd, function23);
            Integer numValueOf = Integer.valueOf(iHashCode);
            Function2 function24 = ComposeUiNode.Companion.Q5MXmkXGmrpQ;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, numValueOf, function24);
            Function1 function1 = ComposeUiNode.Companion.mhkN7GL0jG0Wg1w;
            Updater.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV, function1);
            Function2 function25 = ComposeUiNode.Companion.ADpl0noRbUAhY;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY, function25);
            ColumnMeasurePolicy columnMeasurePolicyXfQCOxz9Pm9BcT = ColumnKt.XfQCOxz9Pm9BcT(Arrangement.f6FsnIUuKXgtm, Alignment.Companion.KT0nNGpxhUtad, composerPIQ5UlgpXmpV, 0);
            int iHashCode2 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd2 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            Modifier modifierADpl0noRbUAhY2 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function02);
            } else {
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, columnMeasurePolicyXfQCOxz9Pm9BcT, function22);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd2, function23);
            Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode2, composerPIQ5UlgpXmpV, function24, composerPIQ5UlgpXmpV, function1);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY2, function25);
            Modifier modifierQ5MXmkXGmrpQ = PaddingKt.Q5MXmkXGmrpQ(SizeKt.XfQCOxz9Pm9BcT, 16.0f, 8.0f);
            RowMeasurePolicy rowMeasurePolicyXfQCOxz9Pm9BcT = RowKt.XfQCOxz9Pm9BcT(Arrangement.XfQCOxz9Pm9BcT, Alignment.Companion.hargS3kTbQOR, composerPIQ5UlgpXmpV, 48);
            int iHashCode3 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd3 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            Modifier modifierADpl0noRbUAhY3 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, modifierQ5MXmkXGmrpQ);
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function02);
            } else {
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, rowMeasurePolicyXfQCOxz9Pm9BcT, function22);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd3, function23);
            Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode3, composerPIQ5UlgpXmpV, function24, composerPIQ5UlgpXmpV, function1);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY3, function25);
            String str3 = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).AY1Ge095OJR8sU;
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuViewModel3);
            Object objUVptkJu9raq35 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq35 == obj3) {
                objUVptkJu9raq35 = new ADpl0noRbUAhY(21, menuViewModel3);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq35);
            }
            MenuViewModel menuViewModel4 = menuViewModel3;
            OutlinedTextFieldKt.XfQCOxz9Pm9BcT(str3, (Function1) objUVptkJu9raq35, RowScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(1.0f), false, false, null, ComposableSingletons$MenuScreenKt.XfQCOxz9Pm9BcT, ComposableSingletons$MenuScreenKt.NzWQJjWwugl4VFs, ComposableLambdaKt.NzWQJjWwugl4VFs(1817201079, new oqhsKX67fcZ7qq(menuViewModel3, focusManager, mutableStateXfQCOxz9Pm9BcT, 4), composerPIQ5UlgpXmpV), null, false, null, null, null, true, 0, 0, RoundedCornerShapeKt.XfQCOxz9Pm9BcT(12.0f), OutlinedTextFieldDefaults.f6FsnIUuKXgtm(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).XfQCOxz9Pm9BcT, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).pIQ5UlgpXmpV, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composerPIQ5UlgpXmpV, 3072, 2147477503, 4095), composerPIQ5UlgpXmpV, 907542528, 1965240);
            Modifier.Companion companion2 = Modifier.Companion.ADpl0noRbUAhY;
            SpacerKt.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV, SizeKt.TXtQqiMBq0ieO9(companion2, 8.0f));
            MeasurePolicy measurePolicyADpl0noRbUAhY2 = BoxKt.ADpl0noRbUAhY(biasAlignment, false);
            int iHashCode4 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd4 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            Modifier modifierADpl0noRbUAhY4 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, companion2);
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                function0 = function02;
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
            } else {
                function0 = function02;
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY2, function22);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd4, function23);
            Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode4, composerPIQ5UlgpXmpV, function24, composerPIQ5UlgpXmpV, function1);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY4, function25);
            Object objUVptkJu9raq36 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq36 == obj3) {
                mutableState = mutableState2;
                objUVptkJu9raq36 = new ehGqOszSxmfoL(mutableState, 8);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq36);
            } else {
                mutableState = mutableState2;
            }
            MutableState mutableState3 = mutableState;
            IconButtonKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq36, null, false, null, null, ComposableSingletons$MenuScreenKt.ADpl0noRbUAhY, composerPIQ5UlgpXmpV, 1572870, 62);
            boolean zBooleanValue = ((Boolean) mutableState3.getADpl0noRbUAhY()).booleanValue();
            Object objUVptkJu9raq37 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq37 == obj3) {
                objUVptkJu9raq37 = new ehGqOszSxmfoL(mutableState3, 9);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq37);
            }
            Function0 function03 = function0;
            AndroidMenu_androidKt.XfQCOxz9Pm9BcT(zBooleanValue, (Function0) objUVptkJu9raq37, null, 0L, null, null, null, 0L, 0.0f, ComposableLambdaKt.NzWQJjWwugl4VFs(-495035581, new d(listJcThbbljzdkQV2, menuViewModel4, mutableState3, mutableStateXfQCOxz9Pm9BcT, 2), composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, 48);
            composerPIQ5UlgpXmpV = composerPIQ5UlgpXmpV;
            composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
            composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
            PaddingValuesImpl paddingValuesImplXfQCOxz9Pm9BcT = PaddingKt.XfQCOxz9Pm9BcT(16.0f, 2);
            Arrangement.SpacedAligned spacedAlignedQ5MXmkXGmrpQ = Arrangement.Q5MXmkXGmrpQ(8.0f);
            Modifier modifierIb3GalHLi1oFkSI = PaddingKt.Ib3GalHLi1oFkSI(companion2, 0.0f, 0.0f, 0.0f, 8.0f, 7);
            boolean zWOuUYCT1RQRv0EU2 = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(listJcThbbljzdkQV) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(mutableStateXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuViewModel4);
            Object objUVptkJu9raq38 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zWOuUYCT1RQRv0EU2) {
                obj = obj3;
            } else {
                obj = obj3;
                if (objUVptkJu9raq38 == obj) {
                }
                Object obj4 = obj;
                LazyDslKt.NzWQJjWwugl4VFs(modifierIb3GalHLi1oFkSI, null, paddingValuesImplXfQCOxz9Pm9BcT, spacedAlignedQ5MXmkXGmrpQ, null, null, false, null, (Function1) objUVptkJu9raq38, composerPIQ5UlgpXmpV, 24966, 490);
                z = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).R7447vqBon0A;
                BiasAlignment biasAlignment2 = Alignment.Companion.AY1Ge095OJR8sU;
                if (!z) {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(298974184);
                    MeasurePolicy measurePolicyADpl0noRbUAhY3 = BoxKt.ADpl0noRbUAhY(biasAlignment2, false);
                    int iHashCode5 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
                    PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd5 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
                    Modifier modifierADpl0noRbUAhY5 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
                    if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                        ComposablesKt.XfQCOxz9Pm9BcT();
                        throw null;
                    }
                    composerPIQ5UlgpXmpV.XodfXzJCenbBF();
                    if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                        composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function03);
                    } else {
                        composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
                    }
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY3, function22);
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd5, function23);
                    Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode5, composerPIQ5UlgpXmpV, function24, composerPIQ5UlgpXmpV, function1);
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY5, function25);
                    ProgressIndicatorKt.XfQCOxz9Pm9BcT(null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).XfQCOxz9Pm9BcT, 0.0f, 0L, 0, 0.0f, composerPIQ5UlgpXmpV, 0, 61);
                    composerPIQ5UlgpXmpV = composerPIQ5UlgpXmpV;
                    composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    menuViewModel2 = menuViewModel4;
                    f = 16.0f;
                    companion = companion2;
                } else if (((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).NzWQJjWwugl4VFs.isEmpty()) {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(299217968);
                    MeasurePolicy measurePolicyADpl0noRbUAhY4 = BoxKt.ADpl0noRbUAhY(biasAlignment2, false);
                    int iHashCode6 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
                    PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd6 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
                    Modifier modifierADpl0noRbUAhY6 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
                    if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                        ComposablesKt.XfQCOxz9Pm9BcT();
                        throw null;
                    }
                    composerPIQ5UlgpXmpV.XodfXzJCenbBF();
                    if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                        composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function03);
                    } else {
                        composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
                    }
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY4, function22);
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd6, function23);
                    Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode6, composerPIQ5UlgpXmpV, function24, composerPIQ5UlgpXmpV, function1);
                    Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY6, function25);
                    companion = companion2;
                    f = 16.0f;
                    TextKt.NzWQJjWwugl4VFs(StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.no_items, composerPIQ5UlgpXmpV), null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).nSB32oL0LrDTKFd, 0L, null, 0L, null, 0L, 0, false, 0, 0, MaterialTheme.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV).uVptkJu9raq3, composerPIQ5UlgpXmpV, 0, 0, 131066);
                    composerPIQ5UlgpXmpV = composerPIQ5UlgpXmpV;
                    composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    menuViewModel2 = menuViewModel4;
                } else {
                    f = 16.0f;
                    companion = companion2;
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(299687246);
                    PaddingValuesImpl paddingValuesImpl = new PaddingValuesImpl(16.0f, 8.0f, 16.0f, 16.0f);
                    Arrangement.SpacedAligned spacedAlignedQ5MXmkXGmrpQ2 = Arrangement.Q5MXmkXGmrpQ(10.0f);
                    menuViewModel2 = menuViewModel4;
                    boolean zWOuUYCT1RQRv0EU3 = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(mutableStateXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuViewModel2);
                    Object objUVptkJu9raq39 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                    obj2 = obj4;
                    if (zWOuUYCT1RQRv0EU3 || objUVptkJu9raq39 == obj2) {
                        objUVptkJu9raq39 = new f6FsnIUuKXgtm(26, mutableStateXfQCOxz9Pm9BcT, menuViewModel2);
                        composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq39);
                    }
                    LazyDslKt.XfQCOxz9Pm9BcT(fillElement, null, paddingValuesImpl, spacedAlignedQ5MXmkXGmrpQ2, null, null, false, null, (Function1) objUVptkJu9raq39, composerPIQ5UlgpXmpV, 24582, 490);
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                    SnackbarHostKt.NzWQJjWwugl4VFs(snackbarHostState, PaddingKt.Ib3GalHLi1oFkSI(BoxScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(companion, Alignment.Companion.mhkN7GL0jG0Wg1w), 0.0f, 0.0f, 0.0f, f, 7), null, composerPIQ5UlgpXmpV, 6, 4);
                    composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                    l = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ;
                    if (l == null) {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1202290193);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    } else {
                        composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1202290192);
                        long jLongValue = l.longValue();
                        boolean zOqhsKX67fcZ7qq2 = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuViewModel2);
                        Object objUVptkJu9raq310 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                        if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq310 == obj2) {
                            objUVptkJu9raq310 = new V02FBF0Ulcpcy(17, menuViewModel2);
                            composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq310);
                        }
                        XfQCOxz9Pm9BcT(jLongValue, (Function0) objUVptkJu9raq310, snackbarHostState, null, composerPIQ5UlgpXmpV, 384);
                        composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    }
                }
                obj2 = obj4;
                composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                SnackbarHostKt.NzWQJjWwugl4VFs(snackbarHostState, PaddingKt.Ib3GalHLi1oFkSI(BoxScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(companion, Alignment.Companion.mhkN7GL0jG0Wg1w), 0.0f, 0.0f, 0.0f, f, 7), null, composerPIQ5UlgpXmpV, 6, 4);
                composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
                l = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ;
                if (l == null) {
                }
            }
            objUVptkJu9raq38 = new plDIFW7uQvLLZ1(listJcThbbljzdkQV, menuViewModel4, mutableStateXfQCOxz9Pm9BcT, 12);
            composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq38);
            Object obj42 = obj;
            LazyDslKt.NzWQJjWwugl4VFs(modifierIb3GalHLi1oFkSI, null, paddingValuesImplXfQCOxz9Pm9BcT, spacedAlignedQ5MXmkXGmrpQ, null, null, false, null, (Function1) objUVptkJu9raq38, composerPIQ5UlgpXmpV, 24966, 490);
            z = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).R7447vqBon0A;
            BiasAlignment biasAlignment22 = Alignment.Companion.AY1Ge095OJR8sU;
            if (!z) {
            }
            obj2 = obj42;
            composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
            SnackbarHostKt.NzWQJjWwugl4VFs(snackbarHostState, PaddingKt.Ib3GalHLi1oFkSI(BoxScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(companion, Alignment.Companion.mhkN7GL0jG0Wg1w), 0.0f, 0.0f, 0.0f, f, 7), null, composerPIQ5UlgpXmpV, 6, 4);
            composerPIQ5UlgpXmpV.Mr6Qni2bHsJ0X();
            l = ((MenuUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ;
            if (l == null) {
            }
        } else {
            composerPIQ5UlgpXmpV.R7447vqBon0A();
            menuViewModel2 = menuViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new FLMntEtk8XkIet1(i, 14, menuViewModel2));
        }
    }

    public static final void XfQCOxz9Pm9BcT(final long j, final Function0 function0, final SnackbarHostState snackbarHostState, MenuDetailViewModel menuDetailViewModel, Composer composer, final int i) {
        Composer composer2;
        final MenuDetailViewModel menuDetailViewModel2;
        int i2;
        MenuDetailViewModel menuDetailViewModel3;
        Composer$Companion$Empty$1 composer$Companion$Empty$1;
        Object menuScreenKt$MenuDetailSideSheet$2$1;
        MenuDetailViewModel menuDetailViewModel4;
        MutableState mutableState;
        function0.getClass();
        snackbarHostState.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-1745162146);
        int i3 = i | (composerPIQ5UlgpXmpV.KT0nNGpxhUtad(j) ? 4 : 2) | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function0) ? 32 : 16) | 1024;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i3 & 1, (i3 & 1171) != 1170)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                } else {
                    i2 = i3 & (-7169);
                    menuDetailViewModel3 = (MenuDetailViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(MenuDetailViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
                }
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                i2 = i3 & (-7169);
                menuDetailViewModel3 = menuDetailViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(menuDetailViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            SheetState sheetStateR7447vqBon0A = ModalBottomSheetKt.R7447vqBon0A(6, 2, composerPIQ5UlgpXmpV);
            String strXfQCOxz9Pm9BcT = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.note_added, composerPIQ5UlgpXmpV);
            Long lValueOf = Long.valueOf(j);
            boolean zOqhsKX67fcZ7qq = ((i2 & 14) == 4) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuDetailViewModel3);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Composer$Companion$Empty$1 composer$Companion$Empty$12 = Composer.Companion.XfQCOxz9Pm9BcT;
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq3 == composer$Companion$Empty$12) {
                objUVptkJu9raq3 = new MenuScreenKt$MenuDetailSideSheet$1$1(menuDetailViewModel3, j, null);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, lValueOf, (Function2) objUVptkJu9raq3);
            NoteSnackbarMessage noteSnackbarMessage = ((MenuDetailUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).mhkN7GL0jG0Wg1w;
            boolean zWOuUYCT1RQRv0EU = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(mutableStateXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(strXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(menuDetailViewModel3);
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zWOuUYCT1RQRv0EU || objUVptkJu9raq32 == composer$Companion$Empty$12) {
                composer$Companion$Empty$1 = composer$Companion$Empty$12;
                menuScreenKt$MenuDetailSideSheet$2$1 = new MenuScreenKt$MenuDetailSideSheet$2$1(snackbarHostState, strXfQCOxz9Pm9BcT, menuDetailViewModel3, mutableStateXfQCOxz9Pm9BcT, null);
                menuDetailViewModel4 = menuDetailViewModel3;
                mutableState = mutableStateXfQCOxz9Pm9BcT;
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(menuScreenKt$MenuDetailSideSheet$2$1);
            } else {
                composer$Companion$Empty$1 = composer$Companion$Empty$12;
                mutableState = mutableStateXfQCOxz9Pm9BcT;
                menuScreenKt$MenuDetailSideSheet$2$1 = objUVptkJu9raq32;
                menuDetailViewModel4 = menuDetailViewModel3;
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, noteSnackbarMessage, (Function2) menuScreenKt$MenuDetailSideSheet$2$1);
            int i4 = (i2 >> 3) & 14;
            Composer$Companion$Empty$1 composer$Companion$Empty$13 = composer$Companion$Empty$1;
            final MenuDetailViewModel menuDetailViewModel5 = menuDetailViewModel4;
            MutableState mutableState2 = mutableState;
            final int i5 = 0;
            ModalBottomSheetKt.XfQCOxz9Pm9BcT(function0, null, sheetStateR7447vqBon0A, 0.0f, false, null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).TXtQqiMBq0ieO9, 0L, 0L, null, null, null, ComposableLambdaKt.NzWQJjWwugl4VFs(1031312576, new s2(mutableState, CollectionsKt.jcThbbljzdkQV(new Pair("buttery", "Buttery"), new Pair("smoky", "Smoky"), new Pair("fresh", "Fresh"), new Pair("nutty", "Nutty"), new Pair("creamy", "Creamy")), menuDetailViewModel4), composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, i4);
            composer2 = composerPIQ5UlgpXmpV;
            if (((MenuDetailUiState) mutableState2.getADpl0noRbUAhY()).AY1Ge095OJR8sU) {
                composer2.Y9lRRazOjmFYx(464214367);
                boolean zOqhsKX67fcZ7qq2 = composer2.oqhsKX67fcZ7qq(menuDetailViewModel5);
                Object objUVptkJu9raq33 = composer2.uVptkJu9raq3();
                if (zOqhsKX67fcZ7qq2 || objUVptkJu9raq33 == composer$Companion$Empty$13) {
                    objUVptkJu9raq33 = new t2(menuDetailViewModel5, i5);
                    composer2.jcThbbljzdkQV(objUVptkJu9raq33);
                }
                ComposableLambdaImpl composableLambdaImplNzWQJjWwugl4VFs = ComposableLambdaKt.NzWQJjWwugl4VFs(-12504917, new Function2() { // from class: u2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                        int i6 = i5;
                        Unit unit = Unit.XfQCOxz9Pm9BcT;
                        Composer$Companion$Empty$1 composer$Companion$Empty$14 = Composer.Companion.XfQCOxz9Pm9BcT;
                        MenuDetailViewModel menuDetailViewModel6 = menuDetailViewModel5;
                        switch (i6) {
                            case 0:
                                Composer composer3 = (Composer) obj;
                                int iIntValue = ((Integer) obj2).intValue();
                                if (!composer3.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                    composer3.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq3 = composer3.oqhsKX67fcZ7qq(menuDetailViewModel6);
                                    Object objUVptkJu9raq34 = composer3.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq3 || objUVptkJu9raq34 == composer$Companion$Empty$14) {
                                        objUVptkJu9raq34 = new XfQCOxz9Pm9BcT(menuDetailViewModel6, 1);
                                        composer3.jcThbbljzdkQV(objUVptkJu9raq34);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq34, null, false, null, null, null, ComposableSingletons$MenuScreenKt.Q5MXmkXGmrpQ, composer3, 805306368, 510);
                                    break;
                                }
                            default:
                                Composer composer4 = (Composer) obj;
                                int iIntValue2 = ((Integer) obj2).intValue();
                                if (!composer4.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                    composer4.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq4 = composer4.oqhsKX67fcZ7qq(menuDetailViewModel6);
                                    Object objUVptkJu9raq35 = composer4.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq35 == composer$Companion$Empty$14) {
                                        objUVptkJu9raq35 = new t2(menuDetailViewModel6, 2);
                                        composer4.jcThbbljzdkQV(objUVptkJu9raq35);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq35, null, false, null, null, null, ComposableSingletons$MenuScreenKt.mhkN7GL0jG0Wg1w, composer4, 805306368, 510);
                                    break;
                                }
                        }
                        return unit;
                    }
                }, composer2);
                final int i6 = 1;
                AndroidAlertDialog_androidKt.XfQCOxz9Pm9BcT((Function0) objUVptkJu9raq33, composableLambdaImplNzWQJjWwugl4VFs, null, ComposableLambdaKt.NzWQJjWwugl4VFs(636087853, new Function2() { // from class: u2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                        int i62 = i6;
                        Unit unit = Unit.XfQCOxz9Pm9BcT;
                        Composer$Companion$Empty$1 composer$Companion$Empty$14 = Composer.Companion.XfQCOxz9Pm9BcT;
                        MenuDetailViewModel menuDetailViewModel6 = menuDetailViewModel5;
                        switch (i62) {
                            case 0:
                                Composer composer3 = (Composer) obj;
                                int iIntValue = ((Integer) obj2).intValue();
                                if (!composer3.Sq4Z9oOaVh4F(iIntValue & 1, (iIntValue & 3) != 2)) {
                                    composer3.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq3 = composer3.oqhsKX67fcZ7qq(menuDetailViewModel6);
                                    Object objUVptkJu9raq34 = composer3.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq3 || objUVptkJu9raq34 == composer$Companion$Empty$14) {
                                        objUVptkJu9raq34 = new XfQCOxz9Pm9BcT(menuDetailViewModel6, 1);
                                        composer3.jcThbbljzdkQV(objUVptkJu9raq34);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq34, null, false, null, null, null, ComposableSingletons$MenuScreenKt.Q5MXmkXGmrpQ, composer3, 805306368, 510);
                                    break;
                                }
                            default:
                                Composer composer4 = (Composer) obj;
                                int iIntValue2 = ((Integer) obj2).intValue();
                                if (!composer4.Sq4Z9oOaVh4F(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                                    composer4.R7447vqBon0A();
                                    break;
                                } else {
                                    boolean zOqhsKX67fcZ7qq4 = composer4.oqhsKX67fcZ7qq(menuDetailViewModel6);
                                    Object objUVptkJu9raq35 = composer4.uVptkJu9raq3();
                                    if (zOqhsKX67fcZ7qq4 || objUVptkJu9raq35 == composer$Companion$Empty$14) {
                                        objUVptkJu9raq35 = new t2(menuDetailViewModel6, 2);
                                        composer4.jcThbbljzdkQV(objUVptkJu9raq35);
                                    }
                                    ButtonKt.NzWQJjWwugl4VFs((Function0) objUVptkJu9raq35, null, false, null, null, null, ComposableSingletons$MenuScreenKt.mhkN7GL0jG0Wg1w, composer4, 805306368, 510);
                                    break;
                                }
                        }
                        return unit;
                    }
                }, composer2), ComposableSingletons$MenuScreenKt.Ib3GalHLi1oFkSI, ComposableLambdaKt.NzWQJjWwugl4VFs(-538506640, new jIAALsBkQIUpNq8(12, menuDetailViewModel5, mutableState2), composer2), null, 0L, 0L, 0L, 0L, null, composer2, 1772592);
                composer2 = composer2;
                composer2.V02FBF0Ulcpcy();
            } else {
                composer2.Y9lRRazOjmFYx(465541508);
                composer2.V02FBF0Ulcpcy();
            }
            menuDetailViewModel2 = menuDetailViewModel5;
        } else {
            composer2 = composerPIQ5UlgpXmpV;
            composer2.R7447vqBon0A();
            menuDetailViewModel2 = menuDetailViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composer2.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new Function2(j, function0, snackbarHostState, menuDetailViewModel2, i) { // from class: v2
                public final /* synthetic */ long ADpl0noRbUAhY;
                public final /* synthetic */ Function0 AY1Ge095OJR8sU;
                public final /* synthetic */ MenuDetailViewModel Q5MXmkXGmrpQ;
                public final /* synthetic */ SnackbarHostState R7447vqBon0A;

                @Override // kotlin.jvm.functions.Function2
                public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int iXfQCOxz9Pm9BcT = RecomposeScopeImplKt.XfQCOxz9Pm9BcT(385);
                    MenuScreenKt.XfQCOxz9Pm9BcT(this.ADpl0noRbUAhY, this.AY1Ge095OJR8sU, this.R7447vqBon0A, this.Q5MXmkXGmrpQ, (Composer) obj, iXfQCOxz9Pm9BcT);
                    return Unit.XfQCOxz9Pm9BcT;
                }
            });
        }
    }
}
