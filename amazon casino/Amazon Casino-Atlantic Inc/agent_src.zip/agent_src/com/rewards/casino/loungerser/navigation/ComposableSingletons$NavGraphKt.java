package com.rewards.casino.loungerser.navigation;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.WW0p8MosooWXzC5;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$NavGraphKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(-1896727725, new WW0p8MosooWXzC5(0), false);
}
