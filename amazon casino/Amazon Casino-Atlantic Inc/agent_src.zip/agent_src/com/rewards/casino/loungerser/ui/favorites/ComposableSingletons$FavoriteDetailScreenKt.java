package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import defpackage.BTSST24gkDbxl1;
import defpackage.jpgeID8zMPb9;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ComposableSingletons$FavoriteDetailScreenKt {
    public static final ComposableLambdaImpl XfQCOxz9Pm9BcT = new ComposableLambdaImpl(-631636380, new BTSST24gkDbxl1(6), false);
    public static final ComposableLambdaImpl NzWQJjWwugl4VFs = new ComposableLambdaImpl(-2069656317, new jpgeID8zMPb9(6), false);
    public static final ComposableLambdaImpl f6FsnIUuKXgtm = new ComposableLambdaImpl(-1405934258, new jpgeID8zMPb9(7), false);
    public static final ComposableLambdaImpl ADpl0noRbUAhY = new ComposableLambdaImpl(-878540208, new jpgeID8zMPb9(8), false);
    public static final ComposableLambdaImpl AY1Ge095OJR8sU = new ComposableLambdaImpl(1278718805, new BTSST24gkDbxl1(7), false);
    public static final ComposableLambdaImpl R7447vqBon0A = new ComposableLambdaImpl(1542415830, new BTSST24gkDbxl1(8), false);
}
