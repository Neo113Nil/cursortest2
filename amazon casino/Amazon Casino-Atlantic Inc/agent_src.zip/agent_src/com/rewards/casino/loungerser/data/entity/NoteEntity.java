package com.rewards.casino.loungerser.data.entity;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.v6;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/entity/NoteEntity;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class NoteEntity {
    public final long ADpl0noRbUAhY;
    public final Long NzWQJjWwugl4VFs;
    public final long XfQCOxz9Pm9BcT;
    public final String f6FsnIUuKXgtm;

    public NoteEntity(long j, Long l, String str, long j2) {
        str.getClass();
        this.XfQCOxz9Pm9BcT = j;
        this.NzWQJjWwugl4VFs = l;
        this.f6FsnIUuKXgtm = str;
        this.ADpl0noRbUAhY = j2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NoteEntity)) {
            return false;
        }
        NoteEntity noteEntity = (NoteEntity) obj;
        return this.XfQCOxz9Pm9BcT == noteEntity.XfQCOxz9Pm9BcT && Intrinsics.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, noteEntity.NzWQJjWwugl4VFs) && Intrinsics.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, noteEntity.f6FsnIUuKXgtm) && this.ADpl0noRbUAhY == noteEntity.ADpl0noRbUAhY;
    }

    public final int hashCode() {
        int iHashCode = Long.hashCode(this.XfQCOxz9Pm9BcT) * 31;
        Long l = this.NzWQJjWwugl4VFs;
        return Long.hashCode(this.ADpl0noRbUAhY) + v6.NzWQJjWwugl4VFs(this.f6FsnIUuKXgtm, (iHashCode + (l == null ? 0 : l.hashCode())) * 31, 31);
    }

    public final String toString() {
        return "NoteEntity(id=" + this.XfQCOxz9Pm9BcT + ", menuItemId=" + this.NzWQJjWwugl4VFs + ", text=" + this.f6FsnIUuKXgtm + ", timestamp=" + this.ADpl0noRbUAhY + ")";
    }
}
