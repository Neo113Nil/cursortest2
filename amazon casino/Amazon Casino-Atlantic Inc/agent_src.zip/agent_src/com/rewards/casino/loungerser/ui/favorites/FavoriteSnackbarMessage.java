package com.rewards.casino.loungerser.ui.favorites;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoriteSnackbarMessage;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoriteSnackbarMessage {
    public static final FavoriteSnackbarMessage ADpl0noRbUAhY;
    public static final FavoriteSnackbarMessage AY1Ge095OJR8sU;
    public static final /* synthetic */ EnumEntries Q5MXmkXGmrpQ;
    public static final /* synthetic */ FavoriteSnackbarMessage[] R7447vqBon0A;

    static {
        FavoriteSnackbarMessage favoriteSnackbarMessage = new FavoriteSnackbarMessage("REGION_FILTERED", 0);
        ADpl0noRbUAhY = favoriteSnackbarMessage;
        FavoriteSnackbarMessage favoriteSnackbarMessage2 = new FavoriteSnackbarMessage("CATEGORY_FILTERED", 1);
        AY1Ge095OJR8sU = favoriteSnackbarMessage2;
        FavoriteSnackbarMessage[] favoriteSnackbarMessageArr = {favoriteSnackbarMessage, favoriteSnackbarMessage2};
        R7447vqBon0A = favoriteSnackbarMessageArr;
        Q5MXmkXGmrpQ = EnumEntriesKt.XfQCOxz9Pm9BcT(favoriteSnackbarMessageArr);
    }

    public static FavoriteSnackbarMessage valueOf(String str) {
        return (FavoriteSnackbarMessage) Enum.valueOf(FavoriteSnackbarMessage.class, str);
    }

    public static FavoriteSnackbarMessage[] values() {
        return (FavoriteSnackbarMessage[]) R7447vqBon0A.clone();
    }
}
