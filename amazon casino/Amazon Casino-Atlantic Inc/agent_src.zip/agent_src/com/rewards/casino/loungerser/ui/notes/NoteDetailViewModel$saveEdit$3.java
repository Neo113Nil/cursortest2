package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableStateFlow;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel$saveEdit$3", f = "NoteDetailViewModel.kt", l = {91, 93}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class NoteDetailViewModel$saveEdit$3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ NoteDetailViewModel Ib3GalHLi1oFkSI;
    public final /* synthetic */ String hargS3kTbQOR;
    public int mhkN7GL0jG0Wg1w;
    public final /* synthetic */ long uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NoteDetailViewModel$saveEdit$3(NoteDetailViewModel noteDetailViewModel, long j, String str, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = noteDetailViewModel;
        this.uVptkJu9raq3 = j;
        this.hargS3kTbQOR = str;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x003a, code lost:
    
        if (r10 == r2) goto L15;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object HDXQYm0hWNKDrl(Object obj) {
        Object value;
        NoteDetailViewModel noteDetailViewModel = this.Ib3GalHLi1oFkSI;
        AppRepository appRepository = noteDetailViewModel.NzWQJjWwugl4VFs;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        long j = this.uVptkJu9raq3;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            this.mhkN7GL0jG0Wg1w = 1;
            if (appRepository.f6FsnIUuKXgtm(j, this.hargS3kTbQOR, this) != coroutineSingletons) {
            }
            return coroutineSingletons;
        }
        if (i != 1) {
            if (i != 2) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
            NoteEntity noteEntity = (NoteEntity) obj;
            MutableStateFlow mutableStateFlow = noteDetailViewModel.f6FsnIUuKXgtm;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.R7447vqBon0A(value, NoteDetailUiState.XfQCOxz9Pm9BcT((NoteDetailUiState) value, noteEntity, null, false, null, null, false, 254)));
            return Unit.XfQCOxz9Pm9BcT;
        }
        ResultKt.NzWQJjWwugl4VFs(obj);
        noteDetailViewModel.Q5MXmkXGmrpQ();
        this.mhkN7GL0jG0Wg1w = 2;
        obj = appRepository.f6FsnIUuKXgtm.NzWQJjWwugl4VFs(j, this);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((NoteDetailViewModel$saveEdit$3) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new NoteDetailViewModel$saveEdit$3(this.Ib3GalHLi1oFkSI, this.uVptkJu9raq3, this.hargS3kTbQOR, continuation);
    }
}
