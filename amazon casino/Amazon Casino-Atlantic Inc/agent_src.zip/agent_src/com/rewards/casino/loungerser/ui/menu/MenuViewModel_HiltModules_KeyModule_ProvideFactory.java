package com.rewards.casino.loungerser.ui.menu;

import dagger.internal.Factory;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final class MenuViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class InstanceHolder {
    }

    @Override // javax.inject.Provider
    public final /* bridge */ /* synthetic */ Object get() {
        return Boolean.TRUE;
    }
}
