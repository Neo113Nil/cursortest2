package com.rewards.casino.loungerser.ui.notes;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.NoteEntity;
import com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeNotes$1;
import java.util.Collection;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.ui.notes.NotesViewModel$observeNotes$1$1", f = "NotesViewModel.kt", l = {74}, m = "emit", v = 2)
/* loaded from: classes.dex */
final class NotesViewModel$observeNotes$1$1$emit$1 extends ContinuationImpl {
    public Iterator Ib3GalHLi1oFkSI;
    public int KT0nNGpxhUtad;
    public NotesViewModel Q5MXmkXGmrpQ;
    public int TXtQqiMBq0ieO9;
    public Collection hargS3kTbQOR;
    public int jtRrC0njHlFmpd;
    public Collection mhkN7GL0jG0Wg1w;
    public final /* synthetic */ NotesViewModel$observeNotes$1.AnonymousClass1 oqhsKX67fcZ7qq;
    public /* synthetic */ Object plDIFW7uQvLLZ1;
    public NoteEntity uVptkJu9raq3;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotesViewModel$observeNotes$1$1$emit$1(NotesViewModel$observeNotes$1.AnonymousClass1 anonymousClass1, Continuation continuation) {
        super(continuation);
        this.oqhsKX67fcZ7qq = anonymousClass1;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        this.plDIFW7uQvLLZ1 = obj;
        this.TXtQqiMBq0ieO9 |= Integer.MIN_VALUE;
        return this.oqhsKX67fcZ7qq.f6FsnIUuKXgtm(null, this);
    }
}
