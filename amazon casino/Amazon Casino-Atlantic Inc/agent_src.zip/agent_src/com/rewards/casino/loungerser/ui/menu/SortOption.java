package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/menu/SortOption;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class SortOption {
    public static final SortOption ADpl0noRbUAhY;
    public static final SortOption AY1Ge095OJR8sU;
    public static final /* synthetic */ SortOption[] Q5MXmkXGmrpQ;
    public static final SortOption R7447vqBon0A;
    public static final /* synthetic */ EnumEntries mhkN7GL0jG0Wg1w;

    static {
        SortOption sortOption = new SortOption("ALPHABETICAL", 0);
        ADpl0noRbUAhY = sortOption;
        SortOption sortOption2 = new SortOption("BY_SWEETNESS", 1);
        AY1Ge095OJR8sU = sortOption2;
        SortOption sortOption3 = new SortOption("BY_WARMTH", 2);
        R7447vqBon0A = sortOption3;
        SortOption[] sortOptionArr = {sortOption, sortOption2, sortOption3};
        Q5MXmkXGmrpQ = sortOptionArr;
        mhkN7GL0jG0Wg1w = EnumEntriesKt.XfQCOxz9Pm9BcT(sortOptionArr);
    }

    public static SortOption valueOf(String str) {
        return (SortOption) Enum.valueOf(SortOption.class, str);
    }

    public static SortOption[] values() {
        return (SortOption[]) Q5MXmkXGmrpQ.clone();
    }
}
