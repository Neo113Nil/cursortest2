package com.rewards.casino.loungerser.data.entity;

import androidx.compose.foundation.layout.WindowInsetsSides;
import defpackage.Sq4Z9oOaVh4F;
import kotlin.Metadata;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/data/entity/FavoriteEntity;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final /* data */ class FavoriteEntity {
    public final long NzWQJjWwugl4VFs;
    public final long XfQCOxz9Pm9BcT;

    public FavoriteEntity(long j, long j2) {
        this.XfQCOxz9Pm9BcT = j;
        this.NzWQJjWwugl4VFs = j2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FavoriteEntity)) {
            return false;
        }
        FavoriteEntity favoriteEntity = (FavoriteEntity) obj;
        return this.XfQCOxz9Pm9BcT == favoriteEntity.XfQCOxz9Pm9BcT && this.NzWQJjWwugl4VFs == favoriteEntity.NzWQJjWwugl4VFs;
    }

    public final int hashCode() {
        return Long.hashCode(this.NzWQJjWwugl4VFs) + Sq4Z9oOaVh4F.f6FsnIUuKXgtm(Long.hashCode(0L) * 31, 31, this.XfQCOxz9Pm9BcT);
    }

    public final String toString() {
        return "FavoriteEntity(id=0, menuItemId=" + this.XfQCOxz9Pm9BcT + ", timestamp=" + this.NzWQJjWwugl4VFs + ")";
    }
}
