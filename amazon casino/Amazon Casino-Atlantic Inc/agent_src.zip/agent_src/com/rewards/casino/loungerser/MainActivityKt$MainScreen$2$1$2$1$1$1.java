package com.rewards.casino.loungerser;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.DrawerState;
import androidx.compose.material3.DrawerValue;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
@DebugMetadata(c = "com.rewards.casino.loungerser.MainActivityKt$MainScreen$2$1$2$1$1$1", f = "MainActivity.kt", l = {133}, m = "invokeSuspend", v = 2)
/* loaded from: classes.dex */
final class MainActivityKt$MainScreen$2$1$2$1$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    public final /* synthetic */ DrawerState Ib3GalHLi1oFkSI;
    public int mhkN7GL0jG0Wg1w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivityKt$MainScreen$2$1$2$1$1$1(DrawerState drawerState, Continuation continuation) {
        super(2, continuation);
        this.Ib3GalHLi1oFkSI = drawerState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object HDXQYm0hWNKDrl(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.ADpl0noRbUAhY;
        int i = this.mhkN7GL0jG0Wg1w;
        Unit unit = Unit.XfQCOxz9Pm9BcT;
        if (i == 0) {
            ResultKt.NzWQJjWwugl4VFs(obj);
            this.mhkN7GL0jG0Wg1w = 1;
            DrawerState drawerState = this.Ib3GalHLi1oFkSI;
            drawerState.getClass();
            Object objXfQCOxz9Pm9BcT = DrawerState.XfQCOxz9Pm9BcT(drawerState, DrawerValue.AY1Ge095OJR8sU, drawerState.AY1Ge095OJR8sU, this);
            if (objXfQCOxz9Pm9BcT != coroutineSingletons) {
                objXfQCOxz9Pm9BcT = unit;
            }
            if (objXfQCOxz9Pm9BcT == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.NzWQJjWwugl4VFs(obj);
        }
        return unit;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
        return ((MainActivityKt$MainScreen$2$1$2$1$1$1) nSB32oL0LrDTKFd((CoroutineScope) obj, (Continuation) obj2)).HDXQYm0hWNKDrl(Unit.XfQCOxz9Pm9BcT);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation nSB32oL0LrDTKFd(Object obj, Continuation continuation) {
        return new MainActivityKt$MainScreen$2$1$2$1$1$1(this.Ib3GalHLi1oFkSI, continuation);
    }
}
