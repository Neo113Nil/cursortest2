package com.rewards.casino.loungerser.navigation;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.navigation.NavHostController;
import androidx.navigation.compose.NavHostKt;
import defpackage.f6FsnIUuKXgtm;
import defpackage.oqhsKX67fcZ7qq;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class NavGraphKt {
    public static final void XfQCOxz9Pm9BcT(NavHostController navHostController, Function0 function0, String str, Composer composer, int i) {
        int i2;
        navHostController.getClass();
        function0.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-1584512618);
        int i3 = (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(navHostController) ? 4 : 2) | i | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function0) ? 32 : 16) | 128;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i3 & 1, (i3 & 147) != 146)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                i2 = i3 & (-897);
                str = "menu";
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                i2 = i3 & (-897);
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(navHostController) | ((i2 & 112) == 32);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq3 == Composer.Companion.XfQCOxz9Pm9BcT) {
                objUVptkJu9raq3 = new f6FsnIUuKXgtm(29, function0, navHostController);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            NavHostKt.NzWQJjWwugl4VFs(navHostController, str, null, null, null, null, null, null, (Function1) objUVptkJu9raq3, composerPIQ5UlgpXmpV, i2 & 14);
        } else {
            composerPIQ5UlgpXmpV.R7447vqBon0A();
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new oqhsKX67fcZ7qq(navHostController, function0, str, i));
        }
    }
}
