package com.rewards.casino.loungerser.ui.theme;

import android.content.res.Configuration;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.rewards.casino.loungerser.ui.theme.ThemeKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class ThemeKt {
    public static final ColorScheme XfQCOxz9Pm9BcT = ColorSchemeKt.f6FsnIUuKXgtm(ColorKt.XfQCOxz9Pm9BcT, 0, 0, 0, 0, ColorKt.NzWQJjWwugl4VFs, 0, 0, 0, ColorKt.f6FsnIUuKXgtm, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -546, 65535);
    public static final ColorScheme NzWQJjWwugl4VFs = ColorSchemeKt.R7447vqBon0A(ColorKt.ADpl0noRbUAhY, 0, 0, 0, 0, ColorKt.AY1Ge095OJR8sU, 0, 0, 0, ColorKt.R7447vqBon0A, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -546, 65535);

    public static final void XfQCOxz9Pm9BcT(final boolean z, Composer composer, final int i) {
        ColorScheme colorScheme;
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(96739333);
        int i2 = i | 50;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i2 & 1, (i2 & 147) != 146)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                z = (((Configuration) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(AndroidCompositionLocals_androidKt.XfQCOxz9Pm9BcT)).uiMode & 48) == 32;
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            if (z) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1522767756);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                colorScheme = XfQCOxz9Pm9BcT;
            } else {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1522766731);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                colorScheme = NzWQJjWwugl4VFs;
            }
            MaterialThemeKt.NzWQJjWwugl4VFs(colorScheme, null, TypeKt.XfQCOxz9Pm9BcT, composerPIQ5UlgpXmpV, 3456);
        } else {
            composerPIQ5UlgpXmpV.R7447vqBon0A();
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composerPIQ5UlgpXmpV.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new Function2(i, z) { // from class: q7
                public final /* synthetic */ boolean ADpl0noRbUAhY;

                {
                    this.ADpl0noRbUAhY = z;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object jtRrC0njHlFmpd(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int iXfQCOxz9Pm9BcT = RecomposeScopeImplKt.XfQCOxz9Pm9BcT(385);
                    ThemeKt.XfQCOxz9Pm9BcT(this.ADpl0noRbUAhY, (Composer) obj, iXfQCOxz9Pm9BcT);
                    return Unit.XfQCOxz9Pm9BcT;
                }
            });
        }
    }
}
