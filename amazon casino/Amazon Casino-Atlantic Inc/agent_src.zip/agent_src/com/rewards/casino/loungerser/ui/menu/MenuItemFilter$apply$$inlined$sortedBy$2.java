package com.rewards.casino.loungerser.ui.menu;

import androidx.compose.foundation.layout.WindowInsetsSides;
import com.rewards.casino.loungerser.data.entity.MenuItemEntity;
import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.comparisons.ComparisonsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class MenuItemFilter$apply$$inlined$sortedBy$2<T> implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        List list = MenuItemFilter.XfQCOxz9Pm9BcT;
        return ComparisonsKt.XfQCOxz9Pm9BcT(Integer.valueOf(list.indexOf(((MenuItemEntity) obj).R7447vqBon0A)), Integer.valueOf(list.indexOf(((MenuItemEntity) obj2).R7447vqBon0A)));
    }
}
