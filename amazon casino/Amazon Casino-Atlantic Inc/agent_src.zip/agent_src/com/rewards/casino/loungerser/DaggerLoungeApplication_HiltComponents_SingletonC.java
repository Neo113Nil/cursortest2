package com.rewards.casino.loungerser;

import android.app.Activity;
import android.content.Context;
import androidx.lifecycle.SavedStateHandle;
import androidx.room.RoomDatabase;
import com.rewards.casino.loungerser.LoungeApplication_HiltComponents;
import com.rewards.casino.loungerser.data.dao.FavoriteDao;
import com.rewards.casino.loungerser.data.dao.MenuItemDao;
import com.rewards.casino.loungerser.data.dao.NoteDao;
import com.rewards.casino.loungerser.data.dao.TasteMarkDao;
import com.rewards.casino.loungerser.data.database.AppDatabase;
import com.rewards.casino.loungerser.data.repository.AppRepository;
import com.rewards.casino.loungerser.ui.favorites.FavoriteDetailViewModel;
import com.rewards.casino.loungerser.ui.favorites.FavoritesViewModel;
import com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel;
import com.rewards.casino.loungerser.ui.menu.MenuViewModel;
import com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel;
import com.rewards.casino.loungerser.ui.notes.NotesViewModel;
import dagger.hilt.android.ActivityRetainedLifecycle;
import dagger.hilt.android.ViewModelLifecycle;
import dagger.hilt.android.components.ActivityComponent;
import dagger.hilt.android.components.ActivityRetainedComponent;
import dagger.hilt.android.components.ViewModelComponent;
import dagger.hilt.android.internal.builders.ActivityComponentBuilder;
import dagger.hilt.android.internal.builders.ActivityRetainedComponentBuilder;
import dagger.hilt.android.internal.builders.ViewModelComponentBuilder;
import dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories;
import dagger.hilt.android.internal.lifecycle.RetainedLifecycleImpl;
import dagger.hilt.android.internal.managers.SavedStateHandleHolder;
import dagger.hilt.android.internal.modules.ApplicationContextModule;
import dagger.internal.DoubleCheck;
import dagger.internal.LazyClassKeyMap;
import dagger.internal.MapBuilder;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.text.StringsKt;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
/* loaded from: classes.dex */
public final class DaggerLoungeApplication_HiltComponents_SingletonC {

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ActivityCBuilder implements LoungeApplication_HiltComponents.ActivityC.Builder {
        public final ActivityRetainedCImpl NzWQJjWwugl4VFs;
        public final SingletonCImpl XfQCOxz9Pm9BcT;
        public Hilt_MainActivity f6FsnIUuKXgtm;

        public ActivityCBuilder(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl) {
            this.XfQCOxz9Pm9BcT = singletonCImpl;
            this.NzWQJjWwugl4VFs = activityRetainedCImpl;
        }

        @Override // dagger.hilt.android.internal.builders.ActivityComponentBuilder
        public final ActivityComponentBuilder XfQCOxz9Pm9BcT(Hilt_MainActivity hilt_MainActivity) {
            this.f6FsnIUuKXgtm = hilt_MainActivity;
            return this;
        }

        @Override // dagger.hilt.android.internal.builders.ActivityComponentBuilder
        public final ActivityComponent build() {
            Preconditions.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, Activity.class);
            return new ActivityCImpl(this.XfQCOxz9Pm9BcT, this.NzWQJjWwugl4VFs);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ActivityCImpl extends LoungeApplication_HiltComponents.ActivityC {
        public final ActivityRetainedCImpl NzWQJjWwugl4VFs;
        public final SingletonCImpl XfQCOxz9Pm9BcT;

        public ActivityCImpl(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl) {
            this.XfQCOxz9Pm9BcT = singletonCImpl;
            this.NzWQJjWwugl4VFs = activityRetainedCImpl;
        }

        @Override // dagger.hilt.android.internal.lifecycle.HiltViewModelFactory.ActivityCreatorEntryPoint
        public final LazyClassKeyMap NzWQJjWwugl4VFs() {
            MapBuilder mapBuilder = new MapBuilder();
            Boolean bool = Boolean.TRUE;
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.favorites.FavoriteDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.favorites.FavoritesViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.menu.MenuViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(bool, "com.rewards.casino.loungerser.ui.notes.NotesViewModel");
            LinkedHashMap linkedHashMap = mapBuilder.XfQCOxz9Pm9BcT;
            return new LazyClassKeyMap(linkedHashMap.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(linkedHashMap));
        }

        @Override // dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories.ActivityEntryPoint
        public final DefaultViewModelFactories.InternalFactoryFactory XfQCOxz9Pm9BcT() {
            return new DefaultViewModelFactories.InternalFactoryFactory(NzWQJjWwugl4VFs(), new ViewModelCBuilder(this.XfQCOxz9Pm9BcT, this.NzWQJjWwugl4VFs));
        }

        @Override // dagger.hilt.android.internal.lifecycle.HiltViewModelFactory.ActivityCreatorEntryPoint
        public final ViewModelComponentBuilder f6FsnIUuKXgtm() {
            return new ViewModelCBuilder(this.XfQCOxz9Pm9BcT, this.NzWQJjWwugl4VFs);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ActivityRetainedCBuilder implements LoungeApplication_HiltComponents.ActivityRetainedC.Builder {
        public SavedStateHandleHolder NzWQJjWwugl4VFs;
        public final SingletonCImpl XfQCOxz9Pm9BcT;

        public ActivityRetainedCBuilder(SingletonCImpl singletonCImpl) {
            this.XfQCOxz9Pm9BcT = singletonCImpl;
        }

        @Override // dagger.hilt.android.internal.builders.ActivityRetainedComponentBuilder
        public final ActivityRetainedComponentBuilder XfQCOxz9Pm9BcT(SavedStateHandleHolder savedStateHandleHolder) {
            this.NzWQJjWwugl4VFs = savedStateHandleHolder;
            return this;
        }

        @Override // dagger.hilt.android.internal.builders.ActivityRetainedComponentBuilder
        public final ActivityRetainedComponent build() {
            Preconditions.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, SavedStateHandleHolder.class);
            return new ActivityRetainedCImpl(this.XfQCOxz9Pm9BcT);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ActivityRetainedCImpl extends LoungeApplication_HiltComponents.ActivityRetainedC {
        public final SingletonCImpl XfQCOxz9Pm9BcT;
        public final ActivityRetainedCImpl NzWQJjWwugl4VFs = this;
        public final Provider f6FsnIUuKXgtm = new DoubleCheck(new SwitchingProvider());

        /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
        public static final class SwitchingProvider<T> implements Provider<T> {
            @Override // javax.inject.Provider
            public final Object get() {
                return new RetainedLifecycleImpl();
            }
        }

        public ActivityRetainedCImpl(SingletonCImpl singletonCImpl) {
            this.XfQCOxz9Pm9BcT = singletonCImpl;
        }

        @Override // dagger.hilt.android.internal.managers.ActivityRetainedComponentManager.ActivityRetainedLifecycleEntryPoint
        public final ActivityRetainedLifecycle NzWQJjWwugl4VFs() {
            return (ActivityRetainedLifecycle) this.f6FsnIUuKXgtm.get();
        }

        @Override // dagger.hilt.android.internal.managers.ActivityComponentManager.ActivityComponentBuilderEntryPoint
        public final ActivityComponentBuilder XfQCOxz9Pm9BcT() {
            return new ActivityCBuilder(this.XfQCOxz9Pm9BcT, this.NzWQJjWwugl4VFs);
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class Builder {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class FragmentCBuilder implements LoungeApplication_HiltComponents.FragmentC.Builder {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class FragmentCImpl extends LoungeApplication_HiltComponents.FragmentC {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ServiceCBuilder implements LoungeApplication_HiltComponents.ServiceC.Builder {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ServiceCImpl extends LoungeApplication_HiltComponents.ServiceC {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class SingletonCImpl extends LoungeApplication_HiltComponents.SingletonC {
        public final ApplicationContextModule XfQCOxz9Pm9BcT;
        public final SingletonCImpl NzWQJjWwugl4VFs = this;
        public final Provider f6FsnIUuKXgtm = new DoubleCheck(new SwitchingProvider(this, 1));
        public final Provider ADpl0noRbUAhY = new DoubleCheck(new SwitchingProvider(this, 0));

        /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
        public static final class SwitchingProvider<T> implements Provider<T> {
            public final int NzWQJjWwugl4VFs;
            public final SingletonCImpl XfQCOxz9Pm9BcT;

            public SwitchingProvider(SingletonCImpl singletonCImpl, int i) {
                this.XfQCOxz9Pm9BcT = singletonCImpl;
                this.NzWQJjWwugl4VFs = i;
            }

            @Override // javax.inject.Provider
            public final Object get() {
                AppDatabase appDatabase;
                int i = this.NzWQJjWwugl4VFs;
                if (i == 0) {
                    AppDatabase appDatabase2 = (AppDatabase) this.XfQCOxz9Pm9BcT.f6FsnIUuKXgtm.get();
                    appDatabase2.getClass();
                    MenuItemDao menuItemDaoJtRrC0njHlFmpd = appDatabase2.jtRrC0njHlFmpd();
                    Preconditions.NzWQJjWwugl4VFs(menuItemDaoJtRrC0njHlFmpd);
                    AppDatabase appDatabase3 = (AppDatabase) this.XfQCOxz9Pm9BcT.f6FsnIUuKXgtm.get();
                    appDatabase3.getClass();
                    FavoriteDao favoriteDaoHargS3kTbQOR = appDatabase3.hargS3kTbQOR();
                    Preconditions.NzWQJjWwugl4VFs(favoriteDaoHargS3kTbQOR);
                    AppDatabase appDatabase4 = (AppDatabase) this.XfQCOxz9Pm9BcT.f6FsnIUuKXgtm.get();
                    appDatabase4.getClass();
                    NoteDao noteDaoKT0nNGpxhUtad = appDatabase4.KT0nNGpxhUtad();
                    Preconditions.NzWQJjWwugl4VFs(noteDaoKT0nNGpxhUtad);
                    AppDatabase appDatabase5 = (AppDatabase) this.XfQCOxz9Pm9BcT.f6FsnIUuKXgtm.get();
                    appDatabase5.getClass();
                    TasteMarkDao tasteMarkDaoPlDIFW7uQvLLZ1 = appDatabase5.plDIFW7uQvLLZ1();
                    Preconditions.NzWQJjWwugl4VFs(tasteMarkDaoPlDIFW7uQvLLZ1);
                    return new AppRepository(menuItemDaoJtRrC0njHlFmpd, favoriteDaoHargS3kTbQOR, noteDaoKT0nNGpxhUtad, tasteMarkDaoPlDIFW7uQvLLZ1);
                }
                if (i != 1) {
                    throw new AssertionError(i);
                }
                Context context = this.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT;
                AppDatabase.Companion companion = AppDatabase.hargS3kTbQOR;
                AppDatabase appDatabase6 = AppDatabase.jtRrC0njHlFmpd;
                if (appDatabase6 != null) {
                    return appDatabase6;
                }
                synchronized (companion) {
                    try {
                        appDatabase = AppDatabase.jtRrC0njHlFmpd;
                        if (appDatabase == null) {
                            Context applicationContext = context.getApplicationContext();
                            applicationContext.getClass();
                            if (StringsKt.plDIFW7uQvLLZ1("ivory_pine_lounge_db")) {
                                throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
                            }
                            RoomDatabase roomDatabaseXfQCOxz9Pm9BcT = new RoomDatabase.Builder(applicationContext).XfQCOxz9Pm9BcT();
                            AppDatabase.jtRrC0njHlFmpd = (AppDatabase) roomDatabaseXfQCOxz9Pm9BcT;
                            appDatabase = (AppDatabase) roomDatabaseXfQCOxz9Pm9BcT;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                return appDatabase;
            }
        }

        public SingletonCImpl(ApplicationContextModule applicationContextModule) {
            this.XfQCOxz9Pm9BcT = applicationContextModule;
        }

        @Override // dagger.hilt.android.internal.managers.ActivityRetainedComponentManager.ActivityRetainedComponentBuilderEntryPoint
        public final ActivityRetainedComponentBuilder NzWQJjWwugl4VFs() {
            return new ActivityRetainedCBuilder(this.NzWQJjWwugl4VFs);
        }

        @Override // com.rewards.casino.loungerser.LoungeApplication_GeneratedInjector
        public final void XfQCOxz9Pm9BcT(LoungeApplication loungeApplication) {
            loungeApplication.R7447vqBon0A = (AppRepository) this.ADpl0noRbUAhY.get();
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewCBuilder implements LoungeApplication_HiltComponents.ViewC.Builder {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewCImpl extends LoungeApplication_HiltComponents.ViewC {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewModelCBuilder implements LoungeApplication_HiltComponents.ViewModelC.Builder {
        public SavedStateHandle NzWQJjWwugl4VFs;
        public final SingletonCImpl XfQCOxz9Pm9BcT;
        public RetainedLifecycleImpl f6FsnIUuKXgtm;

        public ViewModelCBuilder(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl) {
            this.XfQCOxz9Pm9BcT = singletonCImpl;
        }

        @Override // dagger.hilt.android.internal.builders.ViewModelComponentBuilder
        public final ViewModelComponentBuilder NzWQJjWwugl4VFs(RetainedLifecycleImpl retainedLifecycleImpl) {
            this.f6FsnIUuKXgtm = retainedLifecycleImpl;
            return this;
        }

        @Override // dagger.hilt.android.internal.builders.ViewModelComponentBuilder
        public final ViewModelComponentBuilder XfQCOxz9Pm9BcT(SavedStateHandle savedStateHandle) {
            this.NzWQJjWwugl4VFs = savedStateHandle;
            return this;
        }

        @Override // dagger.hilt.android.internal.builders.ViewModelComponentBuilder
        public final ViewModelComponent build() {
            Preconditions.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, SavedStateHandle.class);
            Preconditions.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, ViewModelLifecycle.class);
            ViewModelCImpl viewModelCImpl = new ViewModelCImpl();
            SingletonCImpl singletonCImpl = this.XfQCOxz9Pm9BcT;
            viewModelCImpl.XfQCOxz9Pm9BcT = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 0);
            viewModelCImpl.NzWQJjWwugl4VFs = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 1);
            viewModelCImpl.f6FsnIUuKXgtm = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 2);
            viewModelCImpl.ADpl0noRbUAhY = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 3);
            viewModelCImpl.AY1Ge095OJR8sU = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 4);
            viewModelCImpl.R7447vqBon0A = new ViewModelCImpl.SwitchingProvider(singletonCImpl, 5);
            return viewModelCImpl;
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewModelCImpl extends LoungeApplication_HiltComponents.ViewModelC {
        public Provider ADpl0noRbUAhY;
        public Provider AY1Ge095OJR8sU;
        public Provider NzWQJjWwugl4VFs;
        public Provider R7447vqBon0A;
        public Provider XfQCOxz9Pm9BcT;
        public Provider f6FsnIUuKXgtm;

        /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
        public static final class SwitchingProvider<T> implements Provider<T> {
            public final int NzWQJjWwugl4VFs;
            public final SingletonCImpl XfQCOxz9Pm9BcT;

            public SwitchingProvider(SingletonCImpl singletonCImpl, int i) {
                this.XfQCOxz9Pm9BcT = singletonCImpl;
                this.NzWQJjWwugl4VFs = i;
            }

            @Override // javax.inject.Provider
            public final Object get() {
                SingletonCImpl singletonCImpl = this.XfQCOxz9Pm9BcT;
                int i = this.NzWQJjWwugl4VFs;
                if (i == 0) {
                    return new FavoriteDetailViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                if (i == 1) {
                    return new FavoritesViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                if (i == 2) {
                    return new MenuDetailViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                if (i == 3) {
                    return new MenuViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                if (i == 4) {
                    return new NoteDetailViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                if (i == 5) {
                    return new NotesViewModel((AppRepository) singletonCImpl.ADpl0noRbUAhY.get());
                }
                throw new AssertionError(i);
            }
        }

        @Override // dagger.hilt.android.internal.lifecycle.HiltViewModelFactory.ViewModelFactoriesEntryPoint
        public final LazyClassKeyMap NzWQJjWwugl4VFs() {
            MapBuilder mapBuilder = new MapBuilder();
            mapBuilder.XfQCOxz9Pm9BcT(this.XfQCOxz9Pm9BcT, "com.rewards.casino.loungerser.ui.favorites.FavoriteDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(this.NzWQJjWwugl4VFs, "com.rewards.casino.loungerser.ui.favorites.FavoritesViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(this.f6FsnIUuKXgtm, "com.rewards.casino.loungerser.ui.menu.MenuDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(this.ADpl0noRbUAhY, "com.rewards.casino.loungerser.ui.menu.MenuViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(this.AY1Ge095OJR8sU, "com.rewards.casino.loungerser.ui.notes.NoteDetailViewModel");
            mapBuilder.XfQCOxz9Pm9BcT(this.R7447vqBon0A, "com.rewards.casino.loungerser.ui.notes.NotesViewModel");
            LinkedHashMap linkedHashMap = mapBuilder.XfQCOxz9Pm9BcT;
            return new LazyClassKeyMap(linkedHashMap.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(linkedHashMap));
        }

        @Override // dagger.hilt.android.internal.lifecycle.HiltViewModelFactory.ViewModelFactoriesEntryPoint
        public final void XfQCOxz9Pm9BcT() {
            Map map = Collections.EMPTY_MAP;
        }
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewWithFragmentCBuilder implements LoungeApplication_HiltComponents.ViewWithFragmentC.Builder {
    }

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    public static final class ViewWithFragmentCImpl extends LoungeApplication_HiltComponents.ViewWithFragmentC {
    }
}
