package com.rewards.casino.loungerser.data.dao;

import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1;
import com.rewards.casino.loungerser.data.entity.FavoriteEntity;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.SuspendLambda;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002À\u0006\u0003"}, d2 = {"Lcom/rewards/casino/loungerser/data/dao/FavoriteDao;", "", "app"}, k = 1, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public interface FavoriteDao {
    Object ADpl0noRbUAhY(long j, SuspendLambda suspendLambda);

    FlowUtil$createFlow$$inlined$map$1 NzWQJjWwugl4VFs();

    Object XfQCOxz9Pm9BcT(long j, Continuation continuation);

    Object f6FsnIUuKXgtm(FavoriteEntity favoriteEntity, Continuation continuation);
}
