package com.rewards.casino.loungerser.ui.favorites;

import android.content.res.Resources;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.Arrangement$Top$1;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnMeasurePolicy;
import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValuesImpl;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.layout.WindowInsetsSides;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.icons.outlined.FavoriteKt;
import androidx.compose.material3.ExposedDropdownMenuKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SnackbarHostKt;
import androidx.compose.material3.SnackbarHostState;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.PersistentCompositionLocalMap;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.BiasAlignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.focus.FocusManager;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.rewards.casino.loungerser.R;
import defpackage.ADpl0noRbUAhY;
import defpackage.OiJigLtJwiAnv;
import defpackage.PshsHemYN6Jxj3l;
import defpackage.Sq4Z9oOaVh4F;
import defpackage.d;
import defpackage.jIAALsBkQIUpNq8;
import defpackage.oqhsKX67fcZ7qq;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;

/* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003¨\u0006\u0005²\u0006\f\u0010\u0001\u001a\u00020\u00008\nX\u008a\u0084\u0002²\u0006\u000e\u0010\u0003\u001a\u00020\u00028\n@\nX\u008a\u008e\u0002²\u0006\u000e\u0010\u0004\u001a\u00020\u00028\n@\nX\u008a\u008e\u0002"}, d2 = {"Lcom/rewards/casino/loungerser/ui/favorites/FavoritesUiState;", "state", "", "regionMenuExpanded", "isNavigating", "app"}, k = 2, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
/* loaded from: classes.dex */
public final class FavoritesScreenKt {

    /* compiled from: r8-map-id-66da59d1ff9f1036be956a6b5588aa0d2ac17bfe68aec5bcc56c56c70d69b4a2 */
    @Metadata(k = 3, mv = {2, 3, 0}, xi = WindowInsetsSides.R7447vqBon0A)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] XfQCOxz9Pm9BcT;

        static {
            int[] iArr = new int[FavoriteSnackbarMessage.values().length];
            try {
                FavoriteSnackbarMessage favoriteSnackbarMessage = FavoriteSnackbarMessage.ADpl0noRbUAhY;
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                FavoriteSnackbarMessage favoriteSnackbarMessage2 = FavoriteSnackbarMessage.ADpl0noRbUAhY;
                iArr[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            XfQCOxz9Pm9BcT = iArr;
        }
    }

    public static final void XfQCOxz9Pm9BcT(Function1 function1, FavoritesViewModel favoritesViewModel, Composer composer, int i) {
        Composer composer2;
        FavoritesViewModel favoritesViewModel2;
        FavoritesViewModel favoritesViewModel3;
        int i2;
        Object obj;
        String str;
        String string;
        int i3;
        Modifier.Companion companion;
        Modifier.Companion companion2;
        Composer composer3;
        Function1 function12 = function1;
        function12.getClass();
        Composer composerPIQ5UlgpXmpV = composer.pIQ5UlgpXmpV(-990664179);
        int i4 = i | (composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(function12) ? 4 : 2) | 16;
        if (composerPIQ5UlgpXmpV.Sq4Z9oOaVh4F(i4 & 1, (i4 & 19) != 18)) {
            composerPIQ5UlgpXmpV.Mdvwk4KCHtoBY();
            if ((i & 1) == 0 || composerPIQ5UlgpXmpV.jScSmm0NvYn0J()) {
                ViewModelStoreOwner viewModelStoreOwnerXfQCOxz9Pm9BcT = LocalViewModelStoreOwner.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV);
                if (viewModelStoreOwnerXfQCOxz9Pm9BcT == null) {
                    defpackage.XfQCOxz9Pm9BcT.nSB32oL0LrDTKFd("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return;
                } else {
                    favoritesViewModel3 = (FavoritesViewModel) ViewModelKt.XfQCOxz9Pm9BcT(Reflection.XfQCOxz9Pm9BcT(FavoritesViewModel.class), viewModelStoreOwnerXfQCOxz9Pm9BcT, HiltViewModelKt.XfQCOxz9Pm9BcT(ViewModelStoreOwnerDefaults.NzWQJjWwugl4VFs(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV), ViewModelStoreOwnerDefaults.XfQCOxz9Pm9BcT(viewModelStoreOwnerXfQCOxz9Pm9BcT), composerPIQ5UlgpXmpV);
                    i2 = i4 & (-113);
                }
            } else {
                composerPIQ5UlgpXmpV.R7447vqBon0A();
                i2 = i4 & (-113);
                favoritesViewModel3 = favoritesViewModel;
            }
            composerPIQ5UlgpXmpV.QoeSuTkaarqEJ();
            MutableState mutableStateXfQCOxz9Pm9BcT = FlowExtKt.XfQCOxz9Pm9BcT(favoritesViewModel3.ADpl0noRbUAhY, composerPIQ5UlgpXmpV);
            FocusManager focusManager = (FocusManager) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(CompositionLocalsKt.Ib3GalHLi1oFkSI);
            Object objUVptkJu9raq3 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            Object obj2 = Composer.Companion.XfQCOxz9Pm9BcT;
            if (objUVptkJu9raq3 == obj2) {
                objUVptkJu9raq3 = SnapshotStateKt.Q5MXmkXGmrpQ(Boolean.FALSE);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq3);
            }
            MutableState mutableState = (MutableState) objUVptkJu9raq3;
            String strXfQCOxz9Pm9BcT = StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.all_regions, composerPIQ5UlgpXmpV);
            List listV02FBF0Ulcpcy = CollectionsKt.V02FBF0Ulcpcy(new Pair("All", strXfQCOxz9Pm9BcT));
            List<String> list = FavoriteItemFilter.XfQCOxz9Pm9BcT;
            ArrayList arrayList = new ArrayList(CollectionsKt.oqhsKX67fcZ7qq(list, 10));
            for (String str2 : list) {
                arrayList.add(new Pair(str2, str2));
            }
            ArrayList arrayListDlgq9j9fo3KNf7 = CollectionsKt.Dlgq9j9fo3KNf7(listV02FBF0Ulcpcy, arrayList);
            int size = arrayListDlgq9j9fo3KNf7.size();
            int i5 = 0;
            while (true) {
                if (i5 >= size) {
                    obj = null;
                    break;
                }
                obj = arrayListDlgq9j9fo3KNf7.get(i5);
                i5++;
                if (Intrinsics.XfQCOxz9Pm9BcT(((Pair) obj).ADpl0noRbUAhY, ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).ADpl0noRbUAhY)) {
                    break;
                }
            }
            Pair pair = (Pair) obj;
            if (pair == null || (str = (String) pair.AY1Ge095OJR8sU) == null) {
                str = strXfQCOxz9Pm9BcT;
            }
            Object objUVptkJu9raq32 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq32 == obj2) {
                objUVptkJu9raq32 = new SnackbarHostState();
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq32);
            }
            SnackbarHostState snackbarHostState = (SnackbarHostState) objUVptkJu9raq32;
            Object objUVptkJu9raq33 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq33 == obj2) {
                objUVptkJu9raq33 = SnapshotStateKt.Q5MXmkXGmrpQ(Boolean.FALSE);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq33);
            }
            MutableState mutableState2 = (MutableState) objUVptkJu9raq33;
            FavoriteSnackbarMessage favoriteSnackbarMessage = ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).Q5MXmkXGmrpQ;
            int i6 = favoriteSnackbarMessage == null ? -1 : WhenMappings.XfQCOxz9Pm9BcT[favoriteSnackbarMessage.ordinal()];
            if (i6 == -1) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139878160);
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                string = null;
            } else if (i6 == 1) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139634811);
                String str3 = ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).mhkN7GL0jG0Wg1w;
                if (str3 == null) {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139634810);
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    string = null;
                } else {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139634811);
                    string = ((Resources) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(AndroidCompositionLocals_androidKt.f6FsnIUuKXgtm)).getString(R.string.filter_applied_region, Arrays.copyOf(new Object[]{str3}, 1));
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                }
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            } else {
                if (i6 != 2) {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(1454490278);
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    defpackage.XfQCOxz9Pm9BcT.jpgeID8zMPb9();
                    return;
                }
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139793593);
                String str4 = ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).mhkN7GL0jG0Wg1w;
                if (str4 == null) {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139793592);
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                    string = null;
                } else {
                    composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(2139793593);
                    string = ((Resources) composerPIQ5UlgpXmpV.mhkN7GL0jG0Wg1w(AndroidCompositionLocals_androidKt.f6FsnIUuKXgtm)).getString(R.string.filter_applied_category, Arrays.copyOf(new Object[]{str4}, 1));
                    composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
                }
                composerPIQ5UlgpXmpV.V02FBF0Ulcpcy();
            }
            boolean zWOuUYCT1RQRv0EU = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(string) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(favoritesViewModel3);
            Object objUVptkJu9raq34 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zWOuUYCT1RQRv0EU || objUVptkJu9raq34 == obj2) {
                objUVptkJu9raq34 = new FavoritesScreenKt$FavoritesScreen$1$1(string, snackbarHostState, favoritesViewModel3, null);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq34);
            }
            EffectsKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, string, (Function2) objUVptkJu9raq34);
            FillElement fillElement = SizeKt.f6FsnIUuKXgtm;
            MeasurePolicy measurePolicyADpl0noRbUAhY = BoxKt.ADpl0noRbUAhY(Alignment.Companion.XfQCOxz9Pm9BcT, false);
            int iHashCode = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            int i7 = i2;
            Modifier modifierADpl0noRbUAhY = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
            ComposeUiNode.NzWQJjWwugl4VFs.getClass();
            Function0 function0 = ComposeUiNode.Companion.NzWQJjWwugl4VFs;
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
            } else {
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Function2 function2 = ComposeUiNode.Companion.R7447vqBon0A;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY, function2);
            Function2 function22 = ComposeUiNode.Companion.AY1Ge095OJR8sU;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd, function22);
            Integer numValueOf = Integer.valueOf(iHashCode);
            Function2 function23 = ComposeUiNode.Companion.Q5MXmkXGmrpQ;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, numValueOf, function23);
            Function1 function13 = ComposeUiNode.Companion.mhkN7GL0jG0Wg1w;
            Updater.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV, function13);
            Function2 function24 = ComposeUiNode.Companion.ADpl0noRbUAhY;
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY, function24);
            BiasAlignment.Horizontal horizontal = Alignment.Companion.KT0nNGpxhUtad;
            String str5 = str;
            Arrangement$Top$1 arrangement$Top$1 = Arrangement.f6FsnIUuKXgtm;
            ColumnMeasurePolicy columnMeasurePolicyXfQCOxz9Pm9BcT = ColumnKt.XfQCOxz9Pm9BcT(arrangement$Top$1, horizontal, composerPIQ5UlgpXmpV, 0);
            int iHashCode2 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
            PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd2 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
            Modifier modifierADpl0noRbUAhY2 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
            if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                ComposablesKt.XfQCOxz9Pm9BcT();
                throw null;
            }
            composerPIQ5UlgpXmpV.XodfXzJCenbBF();
            if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
            } else {
                composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
            }
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, columnMeasurePolicyXfQCOxz9Pm9BcT, function2);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd2, function22);
            Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode2, composerPIQ5UlgpXmpV, function23, composerPIQ5UlgpXmpV, function13);
            Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY2, function24);
            String str6 = ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).f6FsnIUuKXgtm;
            boolean zOqhsKX67fcZ7qq = composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(favoritesViewModel3);
            Object objUVptkJu9raq35 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (zOqhsKX67fcZ7qq || objUVptkJu9raq35 == obj2) {
                objUVptkJu9raq35 = new ADpl0noRbUAhY(11, favoritesViewModel3);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq35);
            }
            FillElement fillElement2 = SizeKt.XfQCOxz9Pm9BcT;
            FavoritesViewModel favoritesViewModel4 = favoritesViewModel3;
            OutlinedTextFieldKt.XfQCOxz9Pm9BcT(str6, (Function1) objUVptkJu9raq35, PaddingKt.Q5MXmkXGmrpQ(fillElement2, 16.0f, 8.0f), false, false, null, ComposableSingletons$FavoritesScreenKt.XfQCOxz9Pm9BcT, ComposableSingletons$FavoritesScreenKt.NzWQJjWwugl4VFs, ComposableLambdaKt.NzWQJjWwugl4VFs(-203964806, new oqhsKX67fcZ7qq(favoritesViewModel3, focusManager, mutableStateXfQCOxz9Pm9BcT, 3), composerPIQ5UlgpXmpV), null, false, null, null, null, true, 0, 0, RoundedCornerShapeKt.XfQCOxz9Pm9BcT(12.0f), OutlinedTextFieldDefaults.f6FsnIUuKXgtm(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).XfQCOxz9Pm9BcT, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).pIQ5UlgpXmpV, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composerPIQ5UlgpXmpV, 3072, 2147477503, 4095), composerPIQ5UlgpXmpV, 907542912, 1965240);
            boolean zBooleanValue = ((Boolean) mutableState.getADpl0noRbUAhY()).booleanValue();
            Object objUVptkJu9raq36 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
            if (objUVptkJu9raq36 == obj2) {
                i3 = 2;
                objUVptkJu9raq36 = new PshsHemYN6Jxj3l(mutableState, 2);
                composerPIQ5UlgpXmpV.jcThbbljzdkQV(objUVptkJu9raq36);
            } else {
                i3 = 2;
            }
            Modifier modifierIb3GalHLi1oFkSI = PaddingKt.Ib3GalHLi1oFkSI(PaddingKt.mhkN7GL0jG0Wg1w(fillElement2, 16.0f, 0.0f, i3), 0.0f, 0.0f, 0.0f, 8.0f, 7);
            favoritesViewModel2 = favoritesViewModel4;
            ExposedDropdownMenuKt.XfQCOxz9Pm9BcT(zBooleanValue, (Function1) objUVptkJu9raq36, modifierIb3GalHLi1oFkSI, ComposableLambdaKt.NzWQJjWwugl4VFs(925231931, new d(str5, mutableState, arrayListDlgq9j9fo3KNf7, favoritesViewModel4, 1), composerPIQ5UlgpXmpV), composerPIQ5UlgpXmpV, 3504, 0);
            boolean z = ((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).AY1Ge095OJR8sU;
            BiasAlignment biasAlignment = Alignment.Companion.AY1Ge095OJR8sU;
            Modifier.Companion companion3 = Modifier.Companion.ADpl0noRbUAhY;
            if (z) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1102044151);
                MeasurePolicy measurePolicyADpl0noRbUAhY2 = BoxKt.ADpl0noRbUAhY(biasAlignment, false);
                int iHashCode3 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
                PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd3 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
                Modifier modifierADpl0noRbUAhY3 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
                if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                    ComposablesKt.XfQCOxz9Pm9BcT();
                    throw null;
                }
                composerPIQ5UlgpXmpV.XodfXzJCenbBF();
                if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                    composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
                } else {
                    composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
                }
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY2, function2);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd3, function22);
                Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode3, composerPIQ5UlgpXmpV, function23, composerPIQ5UlgpXmpV, function13);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY3, function24);
                companion2 = companion3;
                ProgressIndicatorKt.XfQCOxz9Pm9BcT(null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).XfQCOxz9Pm9BcT, 0.0f, 0L, 0, 0.0f, composerPIQ5UlgpXmpV, 0, 61);
                composer3 = composerPIQ5UlgpXmpV;
                composer3.Mr6Qni2bHsJ0X();
                composer3.V02FBF0Ulcpcy();
            } else if (((FavoritesUiState) mutableStateXfQCOxz9Pm9BcT.getADpl0noRbUAhY()).NzWQJjWwugl4VFs.isEmpty()) {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1101780651);
                MeasurePolicy measurePolicyADpl0noRbUAhY3 = BoxKt.ADpl0noRbUAhY(biasAlignment, false);
                int iHashCode4 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
                PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd4 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
                Modifier modifierADpl0noRbUAhY4 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, fillElement);
                if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                    ComposablesKt.XfQCOxz9Pm9BcT();
                    throw null;
                }
                composerPIQ5UlgpXmpV.XodfXzJCenbBF();
                if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                    composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
                } else {
                    composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
                }
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, measurePolicyADpl0noRbUAhY3, function2);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd4, function22);
                Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode4, composerPIQ5UlgpXmpV, function23, composerPIQ5UlgpXmpV, function13);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY4, function24);
                ColumnMeasurePolicy columnMeasurePolicyXfQCOxz9Pm9BcT2 = ColumnKt.XfQCOxz9Pm9BcT(arrangement$Top$1, Alignment.Companion.plDIFW7uQvLLZ1, composerPIQ5UlgpXmpV, 48);
                int iHashCode5 = Long.hashCode(composerPIQ5UlgpXmpV.getADpl0noRbUAhY());
                PersistentCompositionLocalMap persistentCompositionLocalMapNSB32oL0LrDTKFd5 = composerPIQ5UlgpXmpV.nSB32oL0LrDTKFd();
                Modifier modifierADpl0noRbUAhY5 = ComposedModifierKt.ADpl0noRbUAhY(composerPIQ5UlgpXmpV, companion3);
                if (composerPIQ5UlgpXmpV.J1WzLTBdSsmQzK() == null) {
                    ComposablesKt.XfQCOxz9Pm9BcT();
                    throw null;
                }
                composerPIQ5UlgpXmpV.XodfXzJCenbBF();
                if (composerPIQ5UlgpXmpV.getEqwJwm8oIiKHLs()) {
                    composerPIQ5UlgpXmpV.eqwJwm8oIiKHLs(function0);
                } else {
                    composerPIQ5UlgpXmpV.HDXQYm0hWNKDrl();
                }
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, columnMeasurePolicyXfQCOxz9Pm9BcT2, function2);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, persistentCompositionLocalMapNSB32oL0LrDTKFd5, function22);
                Sq4Z9oOaVh4F.jScSmm0NvYn0J(iHashCode5, composerPIQ5UlgpXmpV, function23, composerPIQ5UlgpXmpV, function13);
                Updater.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV, modifierADpl0noRbUAhY5, function24);
                IconKt.NzWQJjWwugl4VFs(FavoriteKt.XfQCOxz9Pm9BcT(), null, SizeKt.TXtQqiMBq0ieO9(SizeKt.f6FsnIUuKXgtm(companion3, 48.0f), 48.0f), Color.NzWQJjWwugl4VFs(0.4f, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).nSB32oL0LrDTKFd), composerPIQ5UlgpXmpV, 432, 0);
                SpacerKt.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV, SizeKt.f6FsnIUuKXgtm(companion3, 12.0f));
                companion2 = companion3;
                TextKt.NzWQJjWwugl4VFs(StringResources_androidKt.XfQCOxz9Pm9BcT(R.string.no_favorites, composerPIQ5UlgpXmpV), null, MaterialTheme.XfQCOxz9Pm9BcT(composerPIQ5UlgpXmpV).nSB32oL0LrDTKFd, 0L, null, 0L, null, 0L, 0, false, 0, 0, MaterialTheme.NzWQJjWwugl4VFs(composerPIQ5UlgpXmpV).uVptkJu9raq3, composerPIQ5UlgpXmpV, 0, 0, 131066);
                composer3 = composerPIQ5UlgpXmpV;
                composer3.Mr6Qni2bHsJ0X();
                composer3.Mr6Qni2bHsJ0X();
                composer3.V02FBF0Ulcpcy();
            } else {
                composerPIQ5UlgpXmpV.Y9lRRazOjmFYx(-1100802415);
                PaddingValuesImpl paddingValuesImpl = new PaddingValuesImpl(16.0f, 8.0f, 16.0f, 8.0f);
                Arrangement.SpacedAligned spacedAlignedQ5MXmkXGmrpQ = Arrangement.Q5MXmkXGmrpQ(10.0f);
                boolean zWOuUYCT1RQRv0EU2 = composerPIQ5UlgpXmpV.WOuUYCT1RQRv0EU(mutableStateXfQCOxz9Pm9BcT) | composerPIQ5UlgpXmpV.oqhsKX67fcZ7qq(favoritesViewModel2) | ((i7 & 14) == 4);
                Object objUVptkJu9raq37 = composerPIQ5UlgpXmpV.uVptkJu9raq3();
                if (zWOuUYCT1RQRv0EU2 || objUVptkJu9raq37 == obj2) {
                    companion = companion3;
                    function12 = function1;
                    Object oiJigLtJwiAnv = new OiJigLtJwiAnv(mutableStateXfQCOxz9Pm9BcT, favoritesViewModel2, function12, mutableState2, 2);
                    composerPIQ5UlgpXmpV.jcThbbljzdkQV(oiJigLtJwiAnv);
                    objUVptkJu9raq37 = oiJigLtJwiAnv;
                } else {
                    function12 = function1;
                    companion = companion3;
                }
                composer2 = composerPIQ5UlgpXmpV;
                companion2 = companion;
                LazyDslKt.XfQCOxz9Pm9BcT(fillElement, null, paddingValuesImpl, spacedAlignedQ5MXmkXGmrpQ, null, null, false, null, (Function1) objUVptkJu9raq37, composer2, 24966, 490);
                composer2.V02FBF0Ulcpcy();
                composer2.Mr6Qni2bHsJ0X();
                SnackbarHostKt.NzWQJjWwugl4VFs(snackbarHostState, PaddingKt.Ib3GalHLi1oFkSI(BoxScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(companion2, Alignment.Companion.mhkN7GL0jG0Wg1w), 0.0f, 0.0f, 0.0f, 16.0f, 7), null, composer2, 6, 4);
                composer2.Mr6Qni2bHsJ0X();
            }
            function12 = function1;
            composer2 = composer3;
            composer2.Mr6Qni2bHsJ0X();
            SnackbarHostKt.NzWQJjWwugl4VFs(snackbarHostState, PaddingKt.Ib3GalHLi1oFkSI(BoxScopeInstance.XfQCOxz9Pm9BcT.XfQCOxz9Pm9BcT(companion2, Alignment.Companion.mhkN7GL0jG0Wg1w), 0.0f, 0.0f, 0.0f, 16.0f, 7), null, composer2, 6, 4);
            composer2.Mr6Qni2bHsJ0X();
        } else {
            composer2 = composerPIQ5UlgpXmpV;
            composer2.R7447vqBon0A();
            favoritesViewModel2 = favoritesViewModel;
        }
        ScopeUpdateScope scopeUpdateScopeJvr2ydndnJ9FEHk = composer2.jvr2ydndnJ9FEHk();
        if (scopeUpdateScopeJvr2ydndnJ9FEHk != null) {
            scopeUpdateScopeJvr2ydndnJ9FEHk.XfQCOxz9Pm9BcT(new jIAALsBkQIUpNq8(function12, favoritesViewModel2, i));
        }
    }
}
