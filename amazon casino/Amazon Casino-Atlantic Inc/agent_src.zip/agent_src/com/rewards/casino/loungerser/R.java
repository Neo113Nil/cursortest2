package com.rewards.casino.loungerser;

/* loaded from: classes.dex */
public final class R {

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f030015;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f030016;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f030017;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f030018;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f030019;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f03001a;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f03001b;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f03001c;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f03001d;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f03001e;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f03001f;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f030020;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f030023;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f030044;
    }

    public static final class color {
    }

    public static final class drawable {

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_background = 0x7f060007;
    }

    /* JADX INFO: Added by JADX */
    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int adjacent = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int alwaysAllow = 0x7f070028;

        /* JADX INFO: Added by JADX */
        public static final int alwaysDisallow = 0x7f070029;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_compose_view_context = 0x7f07002a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_composition_context = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int androidx_window_activity_scope = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f07002d;

        /* JADX INFO: Added by JADX */
        public static final int auto_clear_focus_behavior_tag = 0x7f07002e;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f07002f;

        /* JADX INFO: Added by JADX */
        public static final int bottomToTop = 0x7f070030;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int compose_prefetch_scheduler = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int compose_view_saveable_id_tag = 0x7f070033;

        /* JADX INFO: Added by JADX */
        public static final int consume_window_insets_tag = 0x7f070034;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f070035;

        /* JADX INFO: Added by JADX */
        public static final int draggable = 0x7f070036;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f070037;

        /* JADX INFO: Added by JADX */
        public static final int fixed = 0x7f070038;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f070039;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view = 0x7f07003b;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view_holder = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int hide_graphics_layer_in_inspector_tag = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int hide_in_inspector_tag = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f070040;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f070042;

        /* JADX INFO: Added by JADX */
        public static final int inspection_slot_table_set = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f070044;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int jumpCut = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int locale = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int ltr = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int nav_controller_view_tag = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f07004d;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f07004e;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f07004f;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f070050;

        /* JADX INFO: Added by JADX */
        public static final int parent_matrix = 0x7f070051;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f070052;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f070053;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f070054;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f070055;

        /* JADX INFO: Added by JADX */
        public static final int rtl = 0x7f070056;

        /* JADX INFO: Added by JADX */
        public static final int save_non_transition_alpha = 0x7f070057;

        /* JADX INFO: Added by JADX */
        public static final int save_overlay_view = 0x7f070058;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 0x7f070059;

        /* JADX INFO: Added by JADX */
        public static final int systemDefault = 0x7f07005a;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f07005b;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f07005d;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f07005e;

        /* JADX INFO: Added by JADX */
        public static final int tag_compat_insets_dispatch = 0x7f07005f;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f070060;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f070061;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f070062;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f070063;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int tag_system_bar_state_monitor = 0x7f070065;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f070067;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f07006a;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f07006c;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int topToBottom = 0x7f07006e;

        /* JADX INFO: Added by JADX */
        public static final int transition_clip = 0x7f07006f;

        /* JADX INFO: Added by JADX */
        public static final int transition_current_scene = 0x7f070070;

        /* JADX INFO: Added by JADX */
        public static final int transition_image_transform = 0x7f070071;

        /* JADX INFO: Added by JADX */
        public static final int transition_layout_save = 0x7f070072;

        /* JADX INFO: Added by JADX */
        public static final int transition_pause_alpha = 0x7f070073;

        /* JADX INFO: Added by JADX */
        public static final int transition_position = 0x7f070074;

        /* JADX INFO: Added by JADX */
        public static final int transition_scene_layoutid_cache = 0x7f070075;

        /* JADX INFO: Added by JADX */
        public static final int transition_transform = 0x7f070076;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_disjoint_parent = 0x7f070077;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f070078;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_navigation_event_dispatcher_owner = 0x7f070079;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f07007a;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f07007b;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f07007c;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 0x7f07007d;

        /* JADX INFO: Added by JADX */
        public static final int wrapped_composition_tag = 0x7f07007e;
    }

    /* JADX INFO: Added by JADX */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int m3c_window_layout_in_display_cutout_mode = 0x7f080000;
    }

    public static final class mipmap {

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher = 0x7f0a0000;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_foreground = 0x7f0a0001;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_round = 0x7f0a0002;
    }

    public static final class string {

        /* JADX INFO: Added by JADX */
        public static final int add_note = 0x7f0b0000;

        /* JADX INFO: Added by JADX */
        public static final int add_to_favorites = 0x7f0b0001;

        /* JADX INFO: Added by JADX */
        public static final int all_regions = 0x7f0b0003;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_foundation_autofill = 0x7f0b0004;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_autofill = 0x7f0b0005;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f0b0006;

        /* JADX INFO: Added by JADX */
        public static final int app_name = 0x7f0b0007;

        /* JADX INFO: Added by JADX */
        public static final int back = 0x7f0b0008;

        /* JADX INFO: Added by JADX */
        public static final int cancel = 0x7f0b0010;

        /* JADX INFO: Added by JADX */
        public static final int category_all = 0x7f0b0012;

        /* JADX INFO: Added by JADX */
        public static final int category_cold_drinks = 0x7f0b0013;

        /* JADX INFO: Added by JADX */
        public static final int category_hot_drinks = 0x7f0b0014;

        /* JADX INFO: Added by JADX */
        public static final int category_open_sandwiches = 0x7f0b0015;

        /* JADX INFO: Added by JADX */
        public static final int category_pastries = 0x7f0b0016;

        /* JADX INFO: Added by JADX */
        public static final int category_warm_plates = 0x7f0b0017;

        /* JADX INFO: Added by JADX */
        public static final int clear_search = 0x7f0b0019;

        /* JADX INFO: Added by JADX */
        public static final int close_drawer = 0x7f0b001a;

        /* JADX INFO: Added by JADX */
        public static final int close_sheet = 0x7f0b001b;

        /* JADX INFO: Added by JADX */
        public static final int collapse_note = 0x7f0b001c;

        /* JADX INFO: Added by JADX */
        public static final int confirm_delete_note = 0x7f0b001d;

        /* JADX INFO: Added by JADX */
        public static final int confirm_remove_favorite = 0x7f0b001e;

        /* JADX INFO: Added by JADX */
        public static final int copy_note = 0x7f0b001f;

        /* JADX INFO: Added by JADX */
        public static final int create_note = 0x7f0b0020;

        /* JADX INFO: Added by JADX */
        public static final int default_error_message = 0x7f0b0021;

        /* JADX INFO: Added by JADX */
        public static final int default_popup_window_title = 0x7f0b0022;

        /* JADX INFO: Added by JADX */
        public static final int delete = 0x7f0b0023;

        /* JADX INFO: Added by JADX */
        public static final int delete_note = 0x7f0b0024;

        /* JADX INFO: Added by JADX */
        public static final int description = 0x7f0b0025;

        /* JADX INFO: Added by JADX */
        public static final int edit_note = 0x7f0b0027;

        /* JADX INFO: Added by JADX */
        public static final int expand_note = 0x7f0b0028;

        /* JADX INFO: Added by JADX */
        public static final int filter_applied_category = 0x7f0b0029;

        /* JADX INFO: Added by JADX */
        public static final int filter_applied_region = 0x7f0b002a;

        /* JADX INFO: Added by JADX */
        public static final int filter_by_region = 0x7f0b002b;

        /* JADX INFO: Added by JADX */
        public static final int in_progress = 0x7f0b002d;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f0b002e;

        /* JADX INFO: Added by JADX */
        public static final int ingredients = 0x7f0b002f;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_collapse_description = 0x7f0b0031;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_dismiss_description = 0x7f0b0032;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_drag_handle_description = 0x7f0b0033;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_expand_description = 0x7f0b0034;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_pane_title = 0x7f0b0035;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_day_selection = 0x7f0b0045;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_next_month = 0x7f0b0047;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_previous_month = 0x7f0b0048;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_year_selection = 0x7f0b0049;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_year_picker_pane_title = 0x7f0b004c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dialog = 0x7f0b0055;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_collapsed = 0x7f0b0056;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_expanded = 0x7f0b0057;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_toggle = 0x7f0b0058;

        /* JADX INFO: Added by JADX */
        public static final int m3c_snackbar_dismiss = 0x7f0b005c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_snackbar_pane_title = 0x7f0b005d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_am = 0x7f0b0060;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_pm = 0x7f0b006c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_toggle_touch = 0x7f0b006e;

        /* JADX INFO: Added by JADX */
        public static final int navigation_menu = 0x7f0b0073;

        /* JADX INFO: Added by JADX */
        public static final int no_favorites = 0x7f0b0074;

        /* JADX INFO: Added by JADX */
        public static final int no_item_linked = 0x7f0b0075;

        /* JADX INFO: Added by JADX */
        public static final int no_items = 0x7f0b0076;

        /* JADX INFO: Added by JADX */
        public static final int no_notes = 0x7f0b0077;

        /* JADX INFO: Added by JADX */
        public static final int not_selected = 0x7f0b0078;

        /* JADX INFO: Added by JADX */
        public static final int note_added = 0x7f0b0079;

        /* JADX INFO: Added by JADX */
        public static final int note_copied = 0x7f0b007a;

        /* JADX INFO: Added by JADX */
        public static final int note_text_hint = 0x7f0b007b;

        /* JADX INFO: Added by JADX */
        public static final int note_text_required = 0x7f0b007c;

        /* JADX INFO: Added by JADX */
        public static final int note_text_too_long = 0x7f0b007d;

        /* JADX INFO: Added by JADX */
        public static final int open_drawer = 0x7f0b007e;

        /* JADX INFO: Added by JADX */
        public static final int region = 0x7f0b0081;

        /* JADX INFO: Added by JADX */
        public static final int remove = 0x7f0b0082;

        /* JADX INFO: Added by JADX */
        public static final int remove_from_favorites = 0x7f0b0083;

        /* JADX INFO: Added by JADX */
        public static final int save = 0x7f0b0084;

        /* JADX INFO: Added by JADX */
        public static final int screen_favorites = 0x7f0b0085;

        /* JADX INFO: Added by JADX */
        public static final int screen_menu = 0x7f0b0086;

        /* JADX INFO: Added by JADX */
        public static final int screen_notes = 0x7f0b0087;

        /* JADX INFO: Added by JADX */
        public static final int search = 0x7f0b0088;

        /* JADX INFO: Added by JADX */
        public static final int select_item = 0x7f0b0089;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f0b008a;

        /* JADX INFO: Added by JADX */
        public static final int sort = 0x7f0b008c;

        /* JADX INFO: Added by JADX */
        public static final int sort_alphabetical = 0x7f0b008d;

        /* JADX INFO: Added by JADX */
        public static final int sort_by_item_name = 0x7f0b008e;

        /* JADX INFO: Added by JADX */
        public static final int sort_by_sweetness = 0x7f0b008f;

        /* JADX INFO: Added by JADX */
        public static final int sort_by_warmth = 0x7f0b0090;

        /* JADX INFO: Added by JADX */
        public static final int sort_newest_first = 0x7f0b0091;

        /* JADX INFO: Added by JADX */
        public static final int sort_oldest_first = 0x7f0b0092;

        /* JADX INFO: Added by JADX */
        public static final int state_empty = 0x7f0b0093;

        /* JADX INFO: Added by JADX */
        public static final int state_off = 0x7f0b0094;

        /* JADX INFO: Added by JADX */
        public static final int state_on = 0x7f0b0095;

        /* JADX INFO: Added by JADX */
        public static final int sweetness = 0x7f0b0097;

        /* JADX INFO: Added by JADX */
        public static final int switch_role = 0x7f0b0098;

        /* JADX INFO: Added by JADX */
        public static final int tab = 0x7f0b0099;

        /* JADX INFO: Added by JADX */
        public static final int tags = 0x7f0b009a;

        /* JADX INFO: Added by JADX */
        public static final int taste_mark = 0x7f0b009b;

        /* JADX INFO: Added by JADX */
        public static final int template_percent = 0x7f0b009c;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_description = 0x7f0b009d;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_label = 0x7f0b009e;

        /* JADX INFO: Added by JADX */
        public static final int warmth = 0x7f0b009f;

        /* JADX INFO: Added by JADX */
        public static final int without_dish = 0x7f0b00a0;
    }

    public static final class style {

        /* JADX INFO: Added by JADX */
        public static final int DialogWindowTheme = 0x7f0c0000;

        /* JADX INFO: Added by JADX */
        public static final int EdgeToEdgeFloatingDialogTheme = 0x7f0c0001;

        /* JADX INFO: Added by JADX */
        public static final int EdgeToEdgeFloatingDialogWindowTheme = 0x7f0c0002;

        /* JADX INFO: Added by JADX */
        public static final int FloatingDialogWindowTheme = 0x7f0c0003;

        /* JADX INFO: Added by JADX */
        public static final int Theme_IvoryPineLounge = 0x7f0c0009;
    }

    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f0d0000;
    }
}
