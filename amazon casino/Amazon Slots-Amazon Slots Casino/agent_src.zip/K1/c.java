package K1;

/* loaded from: classes.dex */
public final class c extends d {

    /* renamed from: a, reason: collision with root package name */
    public static final c f1575a = new c();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof c);
    }

    public final int hashCode() {
        return 1989405592;
    }

    public final String toString() {
        return "Riverbed";
    }
}
