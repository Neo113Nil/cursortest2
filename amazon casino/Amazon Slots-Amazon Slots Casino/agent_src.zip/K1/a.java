package K1;

import m2.h;

/* loaded from: classes.dex */
public final class a extends d {

    /* renamed from: a, reason: collision with root package name */
    public final String f1573a;

    public a(String str) {
        this.f1573a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof a) && h.a(this.f1573a, ((a) obj).f1573a);
    }

    public final int hashCode() {
        return this.f1573a.hashCode();
    }

    public final String toString() {
        return "Canopy(path=" + this.f1573a + ")";
    }
}
