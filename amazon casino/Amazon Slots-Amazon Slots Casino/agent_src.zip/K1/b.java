package K1;

/* loaded from: classes.dex */
public final class b extends d {

    /* renamed from: a, reason: collision with root package name */
    public static final b f1574a = new b();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof b);
    }

    public final int hashCode() {
        return -1800945910;
    }

    public final String toString() {
        return "OpenMist";
    }
}
