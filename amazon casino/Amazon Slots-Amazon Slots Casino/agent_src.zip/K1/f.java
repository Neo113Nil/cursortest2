package K1;

/* loaded from: classes.dex */
public final class f extends g {

    /* renamed from: a, reason: collision with root package name */
    public static final f f1577a = new f();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof f);
    }

    public final int hashCode() {
        return -1348913047;
    }

    public final String toString() {
        return "Riverbed";
    }
}
