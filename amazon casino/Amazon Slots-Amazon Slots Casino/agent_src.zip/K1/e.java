package K1;

import m2.h;

/* loaded from: classes.dex */
public final class e extends g {

    /* renamed from: a, reason: collision with root package name */
    public final String f1576a;

    public e(String str) {
        h.e(str, "path");
        this.f1576a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof e) && h.a(this.f1576a, ((e) obj).f1576a);
    }

    public final int hashCode() {
        return this.f1576a.hashCode();
    }

    public final String toString() {
        return "Canopy(path=" + this.f1576a + ")";
    }
}
