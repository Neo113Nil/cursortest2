package F1;

import N.F;
import Y1.n;
import c2.InterfaceC0178d;
import e2.i;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class b extends i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ e f726h;
    public final /* synthetic */ String i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(e eVar, String str, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.f726h = eVar;
        this.i = str;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        b bVar = (b) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj);
        n nVar = n.f3007a;
        bVar.k(nVar);
        return nVar;
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new b(this.f726h, this.i, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) {
        F.p0(obj);
        this.f726h.f729a.edit().putString(X1.b.k(), X1.b.b()).putString(X1.b.e(), this.i).commit();
        return n.f3007a;
    }
}
