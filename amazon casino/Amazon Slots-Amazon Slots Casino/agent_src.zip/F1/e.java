package F1;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final SharedPreferences f729a;

    public e(Context context) {
        this.f729a = context.getApplicationContext().getSharedPreferences(X1.b.a(), 0);
    }
}
