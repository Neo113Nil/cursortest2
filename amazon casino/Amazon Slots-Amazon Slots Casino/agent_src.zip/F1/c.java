package F1;

import N.F;
import Y1.l;
import Y1.n;
import Z1.k;
import android.content.SharedPreferences;
import c2.InterfaceC0178d;
import e2.i;
import java.util.ArrayList;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class c extends i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ e f727h;
    public final /* synthetic */ String i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(e eVar, String str, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.f727h = eVar;
        this.i = str;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        c cVar = (c) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj);
        n nVar = n.f3007a;
        cVar.k(nVar);
        return nVar;
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new c(this.f727h, this.i, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) {
        F.p0(obj);
        SharedPreferences.Editor editorEdit = this.f727h.f729a.edit();
        l lVar = X1.b.f2933a;
        int[] iArr = {44, 54};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        editorEdit.putString(k.E0(arrayList, "", null, null, null, 62), this.i).commit();
        return n.f3007a;
    }
}
