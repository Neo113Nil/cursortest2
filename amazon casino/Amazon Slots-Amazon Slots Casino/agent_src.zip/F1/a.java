package F1;

import N.F;
import Y1.n;
import android.content.SharedPreferences;
import c2.InterfaceC0178d;
import e2.i;
import m2.h;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class a extends i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ e f725h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(e eVar, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.f725h = eVar;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        return ((a) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj)).k(n.f3007a);
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new a(this.f725h, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) {
        F.p0(obj);
        e eVar = this.f725h;
        String strK = X1.b.k();
        SharedPreferences sharedPreferences = eVar.f729a;
        String string = sharedPreferences.getString(strK, null);
        boolean zA = h.a(string, X1.b.b());
        K1.b bVar = K1.b.f1574a;
        if (!zA) {
            return h.a(string, X1.b.g()) ? K1.c.f1575a : bVar;
        }
        String string2 = sharedPreferences.getString(X1.b.e(), null);
        if (string2 == null) {
            string2 = "";
        }
        return u2.d.c0(string2) ? bVar : new K1.a(string2);
    }
}
