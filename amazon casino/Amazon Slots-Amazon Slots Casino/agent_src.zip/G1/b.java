package G1;

import K1.e;
import K1.f;
import K1.g;
import N.D;
import Y1.l;
import Z1.k;
import android.content.Context;
import com.amazonia.reels.MainActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import l1.i;
import m2.h;
import org.json.JSONArray;
import org.json.JSONObject;
import u2.d;

/* loaded from: classes.dex */
public final class b implements i {

    /* renamed from: a, reason: collision with root package name */
    public final Context f792a;

    public b(MainActivity mainActivity) {
        this.f792a = mainActivity.getApplicationContext();
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0151 A[Catch: all -> 0x015b, TRY_ENTER, TRY_LEAVE, TryCatch #1 {all -> 0x015b, blocks: (B:12:0x00cf, B:17:0x00dd, B:22:0x0112, B:24:0x012a, B:28:0x013d, B:33:0x0151, B:25:0x0130, B:27:0x0138, B:44:0x0168, B:43:0x0165, B:40:0x0160, B:18:0x00f4, B:20:0x0101, B:21:0x0109, B:38:0x015e), top: B:50:0x00cf, inners: #0, #2, #3 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final g b(b bVar) throws IOException {
        String strD;
        Object jSONArray;
        String str = (String) X1.b.f2933a.getValue();
        URLConnection uRLConnectionOpenConnection = new URL(str).openConnection();
        h.c(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
        httpURLConnection.setRequestMethod("GET");
        int[] iArr = {27, 57, 57, 63, 42, 46};
        ArrayList arrayList = new ArrayList(6);
        for (int i = 0; i < 6; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        String strE0 = k.E0(arrayList, "", null, null, null, 62);
        l lVar = X1.b.f2933a;
        int[] iArr2 = {59, 42, 42, 54, 51, 57, 59, 46, 51, 53, 52, 117, 48, 41, 53, 52};
        ArrayList arrayList2 = new ArrayList(16);
        for (int i3 = 0; i3 < 16; i3++) {
            arrayList2.add(Character.valueOf((char) (iArr2[i3] ^ 90)));
        }
        httpURLConnection.setRequestProperty(strE0, k.E0(arrayList2, "", null, null, null, 62));
        httpURLConnection.setRequestProperty(X1.b.i(), X1.b.j());
        int[] iArr3 = {15, 41, 63, 40, 119, 27, 61, 63, 52, 46};
        ArrayList arrayList3 = new ArrayList(10);
        for (int i4 = 0; i4 < 10; i4++) {
            arrayList3.add(Character.valueOf((char) (iArr3[i4] ^ 90)));
        }
        String strE02 = k.E0(arrayList3, "", null, null, null, 62);
        Context context = bVar.f792a;
        h.d(context, "appContext");
        httpURLConnection.setRequestProperty(strE02, D.z(context));
        String strL = X1.b.l();
        String packageName = context.getPackageName();
        h.d(packageName, "getPackageName(...)");
        httpURLConnection.setRequestProperty(strL, packageName);
        httpURLConnection.setConnectTimeout(8000);
        httpURLConnection.setReadTimeout(8000);
        httpURLConnection.setInstanceFollowRedirects(true);
        try {
            int responseCode = httpURLConnection.getResponseCode();
            g eVar = f.f1577a;
            if (200 <= responseCode && responseCode < 300) {
                InputStream inputStream = httpURLConnection.getInputStream();
                h.d(inputStream, "getInputStream(...)");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, u2.a.f6231a), 8192);
                try {
                    StringWriter stringWriter = new StringWriter();
                    char[] cArr = new char[8192];
                    for (int i5 = bufferedReader.read(cArr); i5 >= 0; i5 = bufferedReader.read(cArr)) {
                        stringWriter.write(cArr, 0, i5);
                    }
                    String string = stringWriter.toString();
                    h.d(string, "toString(...)");
                    bufferedReader.close();
                    String string2 = d.j0(string).toString();
                    h.e(string2, "<this>");
                    if (string2.startsWith("{")) {
                        jSONArray = new JSONObject(string2);
                    } else if (string2.startsWith("[")) {
                        jSONArray = new JSONArray(string2);
                    } else {
                        strD = null;
                        if (strD != null) {
                            eVar = new e(c(str, strD));
                        }
                    }
                    strD = d(jSONArray, (String) X1.b.f2934b.getValue());
                    if (strD != null) {
                    }
                } finally {
                }
            }
            return eVar;
        } finally {
            httpURLConnection.disconnect();
        }
    }

    public static String c(String str, String str2) {
        CharSequence charSequenceSubSequence;
        char[] cArr = {'/'};
        h.e(str, "<this>");
        int length = str.length() - 1;
        if (length >= 0) {
            while (true) {
                int i = length - 1;
                char cCharAt = str.charAt(length);
                int i3 = 0;
                while (true) {
                    if (i3 >= 1) {
                        i3 = -1;
                        break;
                    }
                    if (cCharAt == cArr[i3]) {
                        break;
                    }
                    i3++;
                }
                if (i3 < 0) {
                    charSequenceSubSequence = str.subSequence(0, length + 1);
                    break;
                }
                if (i < 0) {
                    break;
                }
                length = i;
            }
            charSequenceSubSequence = "";
        } else {
            charSequenceSubSequence = "";
        }
        String string = charSequenceSubSequence.toString();
        if (str2.startsWith(X1.b.d()) || str2.startsWith(X1.b.c())) {
            return str2;
        }
        if (str2.startsWith("/")) {
            return string + str2;
        }
        return string + "/" + str2;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0034 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static String d(Object obj, String str) {
        String strD;
        String string;
        if (obj instanceof JSONObject) {
            JSONObject jSONObject = (JSONObject) obj;
            if (jSONObject.has(str)) {
                Object objOpt = jSONObject.opt(str);
                if (objOpt instanceof String) {
                    string = d.j0((String) objOpt).toString();
                    if (string.length() == 0 || string.equalsIgnoreCase("null")) {
                    }
                    if (string == null) {
                    }
                } else {
                    string = null;
                    if (string == null) {
                        return string;
                    }
                    String strD2 = d(objOpt, str);
                    if (strD2 != null) {
                        return strD2;
                    }
                }
            }
            Iterator<String> itKeys = jSONObject.keys();
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                if (!h.a(next, str) && (strD = d(jSONObject.opt(next), str)) != null) {
                    return strD;
                }
            }
        } else if (obj instanceof JSONArray) {
            JSONArray jSONArray = (JSONArray) obj;
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                String strD3 = d(jSONArray.opt(i), str);
                if (strD3 != null) {
                    return strD3;
                }
            }
        }
        return null;
    }

    @Override // l1.i
    public void a(final e0.b bVar) {
        final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new l1.a("EmojiCompatInitializer"));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new Runnable() { // from class: l1.l
            @Override // java.lang.Runnable
            public final void run() {
                G1.b bVar2 = this.f4864d;
                e0.b bVar3 = bVar;
                ThreadPoolExecutor threadPoolExecutor2 = threadPoolExecutor;
                bVar2.getClass();
                try {
                    q qVarR = e0.e.r(bVar2.f792a);
                    if (qVarR == null) {
                        throw new RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    p pVar = (p) qVarR.f4878a;
                    synchronized (pVar.f4872d) {
                        pVar.f4874f = threadPoolExecutor2;
                    }
                    qVarR.f4878a.a(new m(bVar3, threadPoolExecutor2));
                } catch (Throwable th) {
                    bVar3.B(th);
                    threadPoolExecutor2.shutdown();
                }
            }
        });
    }

    public b(Context context) {
        this.f792a = context.getApplicationContext();
    }
}
