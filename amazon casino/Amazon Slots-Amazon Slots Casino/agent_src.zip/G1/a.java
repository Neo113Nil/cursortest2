package G1;

import K1.f;
import N.F;
import Y1.j;
import Y1.n;
import c2.InterfaceC0178d;
import e2.i;
import l2.e;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class a extends i implements e {

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f791h;
    public final /* synthetic */ b i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(b bVar, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.i = bVar;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        return ((a) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj)).k(n.f3007a);
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        a aVar = new a(this.i, interfaceC0178d);
        aVar.f791h = obj;
        return aVar;
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) {
        Object objO;
        F.p0(obj);
        try {
            objO = b.b(this.i);
        } catch (Throwable th) {
            objO = F.O(th);
        }
        return j.a(objO) == null ? objO : f.f1577a;
    }
}
