package X1;

import J1.r;
import N.D;
import Y1.l;
import Z1.k;
import java.util.ArrayList;
import java.util.Locale;
import m2.h;
import u2.d;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public static final l f2933a = D.X(new r(2));

    /* renamed from: b, reason: collision with root package name */
    public static final l f2934b = D.X(new r(3));

    public static String a() {
        int[] iArr = {61, 40, 53, 44, 63, 5, 57, 59, 57, 50, 63};
        ArrayList arrayList = new ArrayList(11);
        for (int i = 0; i < 11; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String b() {
        int[] iArr = {41, 104};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String c() {
        int[] iArr = {50, 46, 46, 42, 96, 117, 117};
        ArrayList arrayList = new ArrayList(7);
        for (int i = 0; i < 7; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String d() {
        int[] iArr = {50, 46, 46, 42, 41, 96, 117, 117};
        ArrayList arrayList = new ArrayList(8);
        for (int i = 0; i < 8; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String e() {
        int[] iArr = {44, 42};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String f() {
        int[] iArr = {42, 34};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String g() {
        int[] iArr = {41, 107};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String h() {
        int[] iArr = {41, 59, 42};
        ArrayList arrayList = new ArrayList(3);
        for (int i = 0; i < 3; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String i() {
        int[] iArr = {27, 57, 57, 63, 42, 46, 119, 22, 59, 52, 61, 47, 59, 61, 63};
        ArrayList arrayList = new ArrayList(15);
        for (int i = 0; i < 15; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String j() {
        Locale locale = Locale.getDefault();
        String languageTag = locale.toLanguageTag();
        String language = locale.getLanguage();
        h.b(language);
        if (d.c0(language)) {
            return d.c0(languageTag) ? "en" : languageTag;
        }
        if (languageTag == null ? false : languageTag.equalsIgnoreCase(language)) {
            h.b(languageTag);
            return languageTag;
        }
        return languageTag + "," + language + ";q=0.9";
    }

    public static String k() {
        int[] iArr = {44, 46};
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }

    public static String l() {
        int[] iArr = {2, 119, 8, 63, 43, 47, 63, 41, 46, 63, 62, 119, 13, 51, 46, 50};
        ArrayList arrayList = new ArrayList(16);
        for (int i = 0; i < 16; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        return k.E0(arrayList, "", null, null, null, 62);
    }
}
