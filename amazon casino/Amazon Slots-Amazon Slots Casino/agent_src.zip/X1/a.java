package X1;

import Y1.l;
import Z1.k;
import android.util.Base64;
import java.nio.charset.Charset;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import m2.h;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final String f2932a;

    static {
        int[] iArr = {27, 31, 9, 117, 25, 24, 25, 117, 10, 17, 25, 9, 111, 10, 59, 62, 62, 51, 52, 61};
        ArrayList arrayList = new ArrayList(20);
        for (int i = 0; i < 20; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        f2932a = k.E0(arrayList, "", null, null, null, 62);
    }

    public static String a(String str) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        l lVar = b.f2933a;
        int[] iArr = {17, 109, 52, 11, 104, 44, 22, 42, 99, 41, 13, 55, 110, 34, 14, 57};
        ArrayList arrayList = new ArrayList(16);
        for (int i = 0; i < 16; i++) {
            arrayList.add(Character.valueOf((char) (iArr[i] ^ 90)));
        }
        byte[] bytes = k.E0(arrayList, "", null, null, null, 62).getBytes(u2.a.f6231a);
        h.d(bytes, "getBytes(...)");
        SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");
        l lVar2 = b.f2933a;
        int[] iArr2 = {56, 8, 98, 50, 3, 107, 57, 30, 108, 47, 16, 59, 105, 63, 0, 43};
        ArrayList arrayList2 = new ArrayList(16);
        for (int i3 = 0; i3 < 16; i3++) {
            arrayList2.add(Character.valueOf((char) (iArr2[i3] ^ 90)));
        }
        String strE0 = k.E0(arrayList2, "", null, null, null, 62);
        Charset charset = u2.a.f6231a;
        byte[] bytes2 = strE0.getBytes(charset);
        h.d(bytes2, "getBytes(...)");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bytes2);
        Cipher cipher = Cipher.getInstance(f2932a);
        cipher.init(2, secretKeySpec, ivParameterSpec);
        byte[] bArrDoFinal = cipher.doFinal(Base64.decode(str, 0));
        h.d(bArrDoFinal, "doFinal(...)");
        return new String(bArrDoFinal, charset);
    }
}
