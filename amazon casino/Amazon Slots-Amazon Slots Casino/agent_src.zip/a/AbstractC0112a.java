package a;

import A2.AbstractC0000a;
import C0.l;
import D0.g;
import D0.i;
import D0.q;
import D0.t;
import F0.C;
import G0.A;
import G0.y;
import J.AbstractC0042p;
import J.B0;
import M.C0058d;
import M.C0074l;
import M.C0082p;
import M.C0088s0;
import M.InterfaceC0079n0;
import M.R0;
import N.D;
import N.F;
import O.d;
import Q0.j;
import X1.b;
import Y.m;
import Y1.n;
import a.AbstractC0112a;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Build;
import android.text.Layout;
import androidx.compose.foundation.layout.FillElement;
import androidx.compose.foundation.layout.c;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.amazonia.reels.canopy.CanopyActivity;
import e0.f;
import f0.AbstractC0260p;
import f0.C0241P;
import f0.C0265u;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import l0.C0414e;
import l0.C0415f;
import l0.C0419j;
import l0.G;
import l0.k;
import l0.p;
import l0.x;
import l2.InterfaceC0420a;
import l2.e;
import m2.h;
import v0.C0674i;
import v0.E;
import v0.P;
import v2.AbstractC0689a;
import w.AbstractC0726M;
import w.AbstractC0747i;
import w.AbstractC0752n;
import w.C0727N;
import w.InterfaceC0728O;
import x0.C0797i;
import x0.C0798j;
import x0.C0803o;
import x0.InterfaceC0799k;
import x0.a0;
import y0.K;
import z1.AbstractC0944f;
import z1.C0943e;

/* renamed from: a.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0112a {

    /* renamed from: a, reason: collision with root package name */
    public static C0415f f3047a;

    /* renamed from: b, reason: collision with root package name */
    public static C0415f f3048b;

    /* renamed from: c, reason: collision with root package name */
    public static C0415f f3049c;

    /* renamed from: d, reason: collision with root package name */
    public static C0415f f3050d;

    /* renamed from: e, reason: collision with root package name */
    public static C0415f f3051e;

    /* renamed from: f, reason: collision with root package name */
    public static C0415f f3052f;

    /* renamed from: g, reason: collision with root package name */
    public static C0415f f3053g;

    /* renamed from: h, reason: collision with root package name */
    public static C0415f f3054h;
    public static C0415f i;

    /* renamed from: j, reason: collision with root package name */
    public static C0415f f3055j;

    public static Intent A(Context context, String str) {
        h.e(context, "context");
        h.e(str, "path");
        Intent intent = new Intent(context, (Class<?>) CanopyActivity.class);
        intent.putExtra(b.f(), str);
        intent.addFlags(268468224);
        return intent;
    }

    public static void B(e eVar, AbstractC0689a abstractC0689a, AbstractC0689a abstractC0689a2) {
        try {
            AbstractC0000a.h(D.U(D.L(abstractC0689a, abstractC0689a2, eVar)), n.f3007a, null);
        } catch (Throwable th) {
            abstractC0689a2.s(F.O(th));
            throw th;
        }
    }

    /* JADX WARN: Type inference failed for: r3v5, types: [l2.a, m2.i] */
    public static final void C(D0.n nVar, int i3, l lVar) {
        D0.n nVar2;
        d dVar = new d(new D0.n[16]);
        List listG = nVar.g(false, false, false);
        while (true) {
            dVar.d(dVar.f2321f, listG);
            while (dVar.l()) {
                nVar2 = (D0.n) dVar.n(dVar.f2321f - 1);
                if (K.u(nVar2)) {
                    t tVar = q.i;
                    i iVar = nVar2.f346d;
                    LinkedHashMap linkedHashMap = iVar.f335d;
                    if (linkedHashMap.containsKey(tVar)) {
                        continue;
                    } else {
                        a0 a0VarC = nVar2.c();
                        if (a0VarC == null) {
                            e0.b.R("Expected semantics node to have a coordinator.");
                            throw null;
                        }
                        f fVarE = P.e(a0VarC);
                        int iRound = Math.round(fVarE.f3772a);
                        int iRound2 = Math.round(fVarE.f3773b);
                        int iRound3 = Math.round(fVarE.f3774c);
                        int iRound4 = Math.round(fVarE.f3775d);
                        Q0.h hVar = new Q0.h(iRound, iRound2, iRound3, iRound4);
                        if (iRound < iRound3 && iRound2 < iRound4) {
                            Object obj = iVar.f335d.get(D0.h.f314e);
                            if (obj == null) {
                                obj = null;
                            }
                            e eVar = (e) obj;
                            Object obj2 = linkedHashMap.get(q.f382p);
                            g gVar = (g) (obj2 != null ? obj2 : null);
                            if (eVar == null || gVar == null || ((Number) gVar.f308b.a()).floatValue() <= 0.0f) {
                                break;
                            }
                            int i4 = i3 + 1;
                            lVar.g(new C0.n(nVar2, i4, hVar, a0VarC));
                            C(nVar2, i4, lVar);
                        }
                    }
                }
            }
            return;
            listG = nVar2.g(false, false, false);
        }
    }

    public static final void a(String str, float f3, Y.l lVar, C0082p c0082p, int i3, int i4) {
        int i5;
        h.e(str, "asset");
        c0082p.S(-2146619185);
        if ((i3 & 6) == 0) {
            i5 = (c0082p.f(str) ? 4 : 2) | i3;
        } else {
            i5 = i3;
        }
        if ((i3 & 48) == 0) {
            i5 |= c0082p.c(f3) ? 32 : 16;
        }
        int i6 = i4 & 4;
        if (i6 != 0) {
            i5 |= 384;
        } else if ((i3 & 384) == 0) {
            i5 |= c0082p.f(lVar) ? 256 : 128;
        }
        if ((i5 & 147) == 146 && c0082p.x()) {
            c0082p.L();
        } else {
            Y.i iVar = Y.i.f2958a;
            if (i6 != 0) {
                lVar = iVar;
            }
            Y.l lVarD = c.d(lVar, f3);
            C.d dVar = C.e.f138a;
            Y.l lVarJ = e0.b.j(D.E(lVarD, dVar), (float) 2.5d, D1.d.f412b, dVar);
            E e3 = AbstractC0752n.e(Y.a.f2935d, false);
            int i7 = c0082p.f2053P;
            InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
            Y.l lVarD2 = m.d(c0082p, lVarJ);
            InterfaceC0799k.f6960b.getClass();
            C0803o c0803o = C0798j.f6955b;
            c0082p.U();
            if (c0082p.f2052O) {
                c0082p.l(c0803o);
            } else {
                c0082p.d0();
            }
            C0058d.P(c0082p, e3, C0798j.f6958e);
            C0058d.P(c0082p, interfaceC0079n0M, C0798j.f6957d);
            C0797i c0797i = C0798j.f6959f;
            if (c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i7))) {
                B.a.k(i7, c0082p, i7, c0797i);
            }
            C0058d.P(c0082p, lVarD2, C0798j.f6956c);
            o2.a.b(str, c.d(iVar, f3), C0674i.f6307a, c0082p, (i5 & 14) | 384, 0);
            c0082p.p(true);
        }
        Y.l lVar2 = lVar;
        C0088s0 c0088s0R = c0082p.r();
        if (c0088s0R != null) {
            c0088s0R.f2094d = new C1.c(str, f3, lVar2, i3, i4, 0);
        }
    }

    public static final void b(C0415f c0415f, Y.l lVar, InterfaceC0420a interfaceC0420a, C0082p c0082p, int i3) {
        int i4;
        Y.l lVar2;
        h.e(interfaceC0420a, "action");
        c0082p.S(-1358715298);
        if ((i3 & 6) == 0) {
            i4 = (c0082p.f(c0415f) ? 4 : 2) | i3;
        } else {
            i4 = i3;
        }
        int i5 = i4 | 48;
        if ((i3 & 384) == 0) {
            i5 |= c0082p.h(interfaceC0420a) ? 256 : 128;
        }
        int i6 = i5;
        if ((i6 & 147) == 146 && c0082p.x()) {
            c0082p.L();
            lVar2 = lVar;
        } else {
            Y.i iVar = Y.i.f2958a;
            Y.l lVarD = c.d(iVar, 44);
            C.d dVar = C.e.f138a;
            Y.l lVarX = o2.a.x(e0.b.j(androidx.compose.foundation.a.a(D.E(lVarD, dVar), D1.d.f414d, 0.0f, 6), 2, D1.d.f412b, dVar), false, 0.9f, interfaceC0420a, c0082p, ((i6 << 15) & 29360128) | 196608, 47);
            E e3 = AbstractC0752n.e(Y.a.f2939h, false);
            int i7 = c0082p.f2053P;
            InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
            Y.l lVarD2 = m.d(c0082p, lVarX);
            InterfaceC0799k.f6960b.getClass();
            C0803o c0803o = C0798j.f6955b;
            c0082p.U();
            if (c0082p.f2052O) {
                c0082p.l(c0803o);
            } else {
                c0082p.d0();
            }
            C0058d.P(c0082p, e3, C0798j.f6958e);
            C0058d.P(c0082p, interfaceC0079n0M, C0798j.f6957d);
            C0797i c0797i = C0798j.f6959f;
            if (c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i7))) {
                B.a.k(i7, c0082p, i7, c0797i);
            }
            C0058d.P(c0082p, lVarD2, C0798j.f6956c);
            AbstractC0042p.a(c0415f, null, c.d(iVar, 20), D1.e.f422g, c0082p, (i6 & 14) | 3504);
            c0082p.p(true);
            lVar2 = iVar;
        }
        C0088s0 c0088s0R = c0082p.r();
        if (c0088s0R != null) {
            c0088s0R.f2094d = new C1.g(c0415f, lVar2, interfaceC0420a, i3, 1);
        }
    }

    public static final void c(int i3, int i4, C0082p c0082p, Y.l lVar) {
        int i5;
        Y.l lVar2;
        c0082p.S(-292813345);
        if ((i4 & 6) == 0) {
            i5 = (c0082p.d(i3) ? 4 : 2) | i4;
        } else {
            i5 = i4;
        }
        if (((i5 | 48) & 19) == 18 && c0082p.x()) {
            c0082p.L();
            lVar2 = lVar;
        } else {
            Y.i iVar = Y.i.f2958a;
            C.d dVar = C.e.f138a;
            Y.l lVarF = androidx.compose.foundation.layout.a.f(e0.b.j(androidx.compose.foundation.a.a(D.E(iVar, dVar), D1.d.f411a, 0.0f, 6), 2, D1.d.f412b, dVar), 14, 8);
            C0727N c0727nA = AbstractC0726M.a(AbstractC0747i.f6534a, Y.a.f2944n, c0082p, 48);
            int i6 = c0082p.f2053P;
            InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
            Y.l lVarD = m.d(c0082p, lVarF);
            InterfaceC0799k.f6960b.getClass();
            C0803o c0803o = C0798j.f6955b;
            c0082p.U();
            if (c0082p.f2052O) {
                c0082p.l(c0803o);
            } else {
                c0082p.d0();
            }
            C0058d.P(c0082p, c0727nA, C0798j.f6958e);
            C0058d.P(c0082p, interfaceC0079n0M, C0798j.f6957d);
            C0797i c0797i = C0798j.f6959f;
            if (c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i6))) {
                B.a.k(i6, c0082p, i6, c0797i);
            }
            C0058d.P(c0082p, lVarD, C0798j.f6956c);
            d("icon_coin", null, 24, null, c0082p, 390, 10);
            AbstractC0752n.a(c.f(7), c0082p, 6);
            B0.b(w(i3), null, D1.e.f425k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 1, 0, null, x(17), c0082p, 384, 3072, 57338);
            c0082p.p(true);
            lVar2 = iVar;
        }
        C0088s0 c0088s0R = c0082p.r();
        if (c0088s0R != null) {
            c0088s0R.f2094d = new C1.d(i3, lVar2, i4);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0089  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x010b  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0110  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0121  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x013b  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0162  */
    /* JADX WARN: Removed duplicated region for block: B:61:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void d(String str, C0415f c0415f, float f3, Y.l lVar, C0082p c0082p, int i3, int i4) {
        int i5;
        Y.l lVar2;
        C0415f c0415f2;
        C0415f c0415fB;
        int i6;
        C0415f c0415f3;
        Y.l lVar3;
        int i7;
        C0415f c0415f4;
        Y.l lVar4;
        C0088s0 c0088s0R;
        h.e(str, "name");
        c0082p.S(698534858);
        if ((i3 & 6) == 0) {
            i5 = (c0082p.f(str) ? 4 : 2) | i3;
        } else {
            i5 = i3;
        }
        if ((i3 & 48) == 0) {
            i5 |= 16;
        }
        if ((i3 & 384) == 0) {
            i5 |= c0082p.c(f3) ? 256 : 128;
        }
        int i8 = i4 & 8;
        if (i8 == 0) {
            if ((i3 & 3072) == 0) {
                lVar2 = lVar;
                i5 |= c0082p.f(lVar2) ? 2048 : 1024;
            }
            if ((i5 & 1171) == 1170 || !c0082p.x()) {
                c0082p.N();
                if ((i3 & 1) != 0 || c0082p.w()) {
                    c0415f2 = o2.a.f5097e;
                    if (c0415f2 == null) {
                        c0415fB = c0415f2;
                    } else {
                        C0414e c0414e = new C0414e("Filled.Circle", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
                        int i9 = G.f4692a;
                        C0241P c0241p = new C0241P(C0265u.f3887b);
                        ArrayList arrayList = new ArrayList(32);
                        arrayList.add(new l0.n(12.0f, 2.0f));
                        arrayList.add(new k(6.47f, 2.0f, 2.0f, 6.47f, 2.0f, 12.0f));
                        arrayList.add(new x(4.47f, 10.0f, 10.0f, 10.0f));
                        arrayList.add(new x(10.0f, -4.47f, 10.0f, -10.0f));
                        arrayList.add(new p(17.53f, 2.0f, 12.0f, 2.0f));
                        arrayList.add(C0419j.f4793c);
                        C0414e.a(c0414e, arrayList, c0241p);
                        c0415fB = c0414e.b();
                        o2.a.f5097e = c0415fB;
                    }
                    i6 = i5 & (-113);
                    if (i8 == 0) {
                        c0415f3 = c0415fB;
                        lVar3 = Y.i.f2958a;
                        c0082p.q();
                        i7 = i6 & 14;
                        if (y(str, c0082p, i7 | 48) == 0) {
                            c0082p.Q(-201128986);
                            o2.a.b(str, c.d(lVar3, f3), C0674i.f6308b, c0082p, i7 | 384, 0);
                            c0082p.p(false);
                        } else {
                            c0082p.Q(-201017262);
                            AbstractC0042p.a(c0415f3, str, c.d(lVar3, f3), D1.e.f422g, c0082p, 3072 | ((i6 << 3) & 112));
                            c0082p.p(false);
                        }
                        c0415f4 = c0415f3;
                        lVar4 = lVar3;
                    } else {
                        c0415f3 = c0415fB;
                    }
                } else {
                    c0082p.L();
                    i6 = i5 & (-113);
                    c0415f3 = c0415f;
                }
                lVar3 = lVar2;
                c0082p.q();
                i7 = i6 & 14;
                if (y(str, c0082p, i7 | 48) == 0) {
                }
                c0415f4 = c0415f3;
                lVar4 = lVar3;
            } else {
                c0082p.L();
                c0415f4 = c0415f;
                lVar4 = lVar2;
            }
            c0088s0R = c0082p.r();
            if (c0088s0R == null) {
                c0088s0R.f2094d = new C1.b(str, c0415f4, f3, lVar4, i3, i4);
                return;
            }
            return;
        }
        i5 |= 3072;
        lVar2 = lVar;
        if ((i5 & 1171) == 1170) {
            c0082p.N();
            if ((i3 & 1) != 0) {
                c0415f2 = o2.a.f5097e;
                if (c0415f2 == null) {
                }
                i6 = i5 & (-113);
                if (i8 == 0) {
                }
            }
        }
        c0088s0R = c0082p.r();
        if (c0088s0R == null) {
        }
    }

    public static final void e(String str, float f3, Y.l lVar, C0082p c0082p, int i3, int i4) {
        int i5;
        String str2;
        float f4;
        Y.l lVar2;
        c0082p.S(661431465);
        int i6 = i4 & 1;
        if (i6 != 0) {
            i5 = i3 | 6;
        } else if ((i3 & 6) == 0) {
            i5 = (c0082p.f(str) ? 4 : 2) | i3;
        } else {
            i5 = i3;
        }
        int i7 = i4 & 2;
        if (i7 != 0) {
            i5 |= 48;
        } else if ((i3 & 48) == 0) {
            i5 |= c0082p.c(f3) ? 32 : 16;
        }
        int i8 = i5 | 384;
        if ((i8 & 147) == 146 && c0082p.x()) {
            c0082p.L();
            str2 = str;
            f4 = f3;
            lVar2 = lVar;
        } else {
            if (i6 != 0) {
                str = "bg_jungle";
            }
            if (i7 != 0) {
                f3 = 0.0f;
            }
            Y.i iVar = Y.i.f2958a;
            FillElement fillElement = c.f3301c;
            Y.l lVarA = androidx.compose.foundation.a.a(fillElement, D1.d.f411a, 0.0f, 6);
            E e3 = AbstractC0752n.e(Y.a.f2935d, false);
            int i9 = c0082p.f2053P;
            InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
            Y.l lVarD = m.d(c0082p, lVarA);
            InterfaceC0799k.f6960b.getClass();
            C0803o c0803o = C0798j.f6955b;
            c0082p.U();
            if (c0082p.f2052O) {
                c0082p.l(c0803o);
            } else {
                c0082p.d0();
            }
            C0058d.P(c0082p, e3, C0798j.f6958e);
            C0058d.P(c0082p, interfaceC0079n0M, C0798j.f6957d);
            C0797i c0797i = C0798j.f6959f;
            if (c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i9))) {
                B.a.k(i9, c0082p, i9, c0797i);
            }
            C0058d.P(c0082p, lVarD, C0798j.f6956c);
            c0082p.Q(1636439620);
            int i10 = i8 & 14;
            if (y(str, c0082p, i10 | 48) != 0) {
                o2.a.b(str, fillElement, C0674i.f6307a, c0082p, i10 | 432, 0);
            }
            c0082p.p(false);
            c0082p.Q(1636446680);
            if (f3 > 0.0f) {
                AbstractC0752n.a(androidx.compose.foundation.a.b(fillElement, C0265u.b(f3, C0265u.f3887b), AbstractC0260p.f3880a), c0082p, 0);
            }
            c0082p.p(false);
            c0082p.p(true);
            str2 = str;
            f4 = f3;
            lVar2 = iVar;
        }
        C0088s0 c0088s0R = c0082p.r();
        if (c0088s0R != null) {
            c0088s0R.f2094d = new C1.c(str2, f4, lVar2, i3, i4, 1);
        }
    }

    public static final I2.c f(E2.a aVar) {
        h.e(aVar, "elementSerializer");
        return new I2.c(aVar);
    }

    public static final void g(final double d3, final Y.l lVar, C0082p c0082p, final int i3) {
        int i4;
        int i5;
        c0082p.S(-1290046091);
        if ((i3 & 6) == 0) {
            Object objZ = c0082p.z();
            if ((objZ instanceof Double) && d3 == ((Number) objZ).doubleValue()) {
                i5 = 2;
            } else {
                c0082p.b0(Double.valueOf(d3));
                i5 = 4;
            }
            i4 = i5 | i3;
        } else {
            i4 = i3;
        }
        if ((i3 & 48) == 0) {
            i4 |= c0082p.f(lVar) ? 32 : 16;
        }
        if ((i4 & 19) == 18 && c0082p.x()) {
            c0082p.L();
        } else {
            C.d dVar = C.e.f138a;
            Y.l lVarI = e0.b.i(androidx.compose.foundation.a.b(D.E(lVar, dVar), C0265u.b(0.85f, D1.e.f416a), AbstractC0260p.f3880a), 1, C0265u.b(0.7f, D1.e.f423h), dVar);
            E e3 = AbstractC0752n.e(Y.a.f2935d, false);
            int i6 = c0082p.f2053P;
            InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
            Y.l lVarD = m.d(c0082p, lVarI);
            InterfaceC0799k.f6960b.getClass();
            C0803o c0803o = C0798j.f6955b;
            c0082p.U();
            if (c0082p.f2052O) {
                c0082p.l(c0803o);
            } else {
                c0082p.d0();
            }
            C0058d.P(c0082p, e3, C0798j.f6958e);
            C0058d.P(c0082p, interfaceC0079n0M, C0798j.f6957d);
            C0797i c0797i = C0798j.f6959f;
            if (c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i6))) {
                B.a.k(i6, c0082p, i6, c0797i);
            }
            C0058d.P(c0082p, lVarD, C0798j.f6956c);
            AbstractC0752n.a(androidx.compose.foundation.a.a(D.E(c.a(c.f3300b, (float) e0.e.l(d3, 0.0d, 1.0d)), dVar), D1.d.f412b, 0.0f, 6), c0082p, 0);
            c0082p.p(true);
        }
        C0088s0 c0088s0R = c0082p.r();
        if (c0088s0R != null) {
            c0088s0R.f2094d = new e() { // from class: C1.e
                @Override // l2.e
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int iS = C0058d.S(i3 | 1);
                    AbstractC0112a.g(d3, lVar, (C0082p) obj, iS);
                    return Y1.n.f3007a;
                }
            };
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:102:0x027a  */
    /* JADX WARN: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x008e  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0123  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x013e  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x014e  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0180  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x020a  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x020e  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x022b  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0242  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0260  */
    /* JADX WARN: Type inference failed for: r3v12 */
    /* JADX WARN: Type inference failed for: r3v13, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r3v15 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void h(String str, String str2, Y.l lVar, boolean z3, InterfaceC0420a interfaceC0420a, C0082p c0082p, int i3, int i4) {
        int i5;
        boolean z4;
        int i6;
        InterfaceC0420a interfaceC0420a2;
        int i7;
        boolean z5;
        int i8;
        C0797i c0797i;
        int i9;
        int i10;
        Y.d dVar;
        C0797i c0797i2;
        C0797i c0797i3;
        C0803o c0803o;
        C0797i c0797i4;
        androidx.compose.foundation.layout.b bVar;
        C0797i c0797i5;
        ?? r3;
        int i11;
        Y.i iVar;
        InterfaceC0420a interfaceC0420a3;
        C0082p c0082p2;
        int i12;
        InterfaceC0420a interfaceC0420a4;
        InterfaceC0420a interfaceC0420a5;
        C0088s0 c0088s0R;
        c0082p.S(-1964428658);
        if ((i3 & 6) == 0) {
            i5 = (c0082p.f(str) ? 4 : 2) | i3;
        } else {
            i5 = i3;
        }
        if ((i3 & 48) == 0) {
            i5 |= c0082p.f(str2) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i5 |= c0082p.f(lVar) ? 256 : 128;
        }
        int i13 = i4 & 8;
        if (i13 != 0) {
            i5 |= 3072;
        } else {
            if ((i3 & 3072) == 0) {
                z4 = z3;
                i5 |= c0082p.g(z4) ? 2048 : 1024;
            }
            i6 = i4 & 16;
            if (i6 != 0) {
                if ((i3 & 24576) == 0) {
                    interfaceC0420a2 = interfaceC0420a;
                    i5 |= c0082p.h(interfaceC0420a2) ? 16384 : 8192;
                }
                i7 = i5;
                if ((i7 & 9363) == 9362 && c0082p.x()) {
                    c0082p.L();
                    z5 = z4;
                    interfaceC0420a5 = interfaceC0420a2;
                } else {
                    z5 = i13 == 0 ? false : z4;
                    InterfaceC0420a interfaceC0420a6 = i6 == 0 ? null : interfaceC0420a2;
                    C0943e c0943e = (C0943e) c0082p.k(AbstractC0944f.f7823a);
                    Y.l lVarB = c.b(c.a(lVar, 1.0f), 56);
                    Y.d dVar2 = Y.a.f2935d;
                    E e3 = AbstractC0752n.e(dVar2, false);
                    i8 = c0082p.f2053P;
                    InterfaceC0079n0 interfaceC0079n0M = c0082p.m();
                    Y.l lVarD = m.d(c0082p, lVarB);
                    InterfaceC0799k.f6960b.getClass();
                    C0803o c0803o2 = C0798j.f6955b;
                    c0082p.U();
                    if (c0082p.f2052O) {
                        c0082p.d0();
                    } else {
                        c0082p.l(c0803o2);
                    }
                    C0797i c0797i6 = C0798j.f6958e;
                    C0058d.P(c0082p, e3, c0797i6);
                    C0797i c0797i7 = C0798j.f6957d;
                    C0058d.P(c0082p, interfaceC0079n0M, c0797i7);
                    c0797i = C0798j.f6959f;
                    if (!c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i8))) {
                        B.a.k(i8, c0082p, i8, c0797i);
                    }
                    C0797i c0797i8 = C0798j.f6956c;
                    C0058d.P(c0082p, lVarD, c0797i8);
                    androidx.compose.foundation.layout.b bVar2 = androidx.compose.foundation.layout.b.f3298a;
                    Y.i iVar2 = Y.i.f2958a;
                    Y.d dVar3 = Y.a.f2939h;
                    Y.l lVarA = bVar2.a(iVar2, dVar3);
                    E e4 = AbstractC0752n.e(dVar2, false);
                    i9 = c0082p.f2053P;
                    InterfaceC0079n0 interfaceC0079n0M2 = c0082p.m();
                    Y.l lVarD2 = m.d(c0082p, lVarA);
                    c0082p.U();
                    if (c0082p.f2052O) {
                        c0082p.d0();
                    } else {
                        c0082p.l(c0803o2);
                    }
                    C0058d.P(c0082p, e4, c0797i6);
                    C0058d.P(c0082p, interfaceC0079n0M2, c0797i7);
                    if (!c0082p.f2052O || !h.a(c0082p.G(), Integer.valueOf(i9))) {
                        B.a.k(i9, c0082p, i9, c0797i);
                    }
                    C0058d.P(c0082p, lVarD2, c0797i8);
                    i10 = (i7 & 14) | 48;
                    if (y(str, c0082p, i10) == 0) {
                        c0082p.Q(-31287256);
                        dVar = dVar3;
                        c0797i2 = c0797i7;
                        c0797i3 = c0797i;
                        c0803o = c0803o2;
                        o2.a.b(str, c.b(iVar2, 46), null, c0082p, i10, 4);
                        c0082p.p(false);
                        r3 = 0;
                        iVar = iVar2;
                        c0797i4 = c0797i6;
                        c0082p2 = c0082p;
                        bVar = bVar2;
                        interfaceC0420a3 = interfaceC0420a6;
                        c0797i5 = c0797i8;
                        i11 = i7;
                    } else {
                        dVar = dVar3;
                        c0797i2 = c0797i7;
                        c0797i3 = c0797i;
                        c0803o = c0803o2;
                        c0082p.Q(-31185824);
                        c0797i4 = c0797i6;
                        bVar = bVar2;
                        c0797i5 = c0797i8;
                        r3 = 0;
                        i11 = i7;
                        iVar = iVar2;
                        C0082p c0082p3 = c0082p;
                        interfaceC0420a3 = interfaceC0420a6;
                        B0.b(str2, null, D1.e.f422g, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, m(28), c0082p, ((i7 >> 3) & 14) | 384, 0, 65530);
                        c0082p3.p(false);
                        c0082p2 = c0082p3;
                    }
                    c0082p2.p(true);
                    Y.l lVarA2 = bVar.a(c.a(iVar, 1.0f), dVar);
                    C0727N c0727nA = AbstractC0726M.a(AbstractC0747i.f6534a, Y.a.f2943m, c0082p2, r3);
                    i12 = c0082p2.f2053P;
                    InterfaceC0079n0 interfaceC0079n0M3 = c0082p.m();
                    Y.l lVarD3 = m.d(c0082p2, lVarA2);
                    c0082p.U();
                    if (c0082p2.f2052O) {
                        c0082p.d0();
                    } else {
                        c0082p2.l(c0803o);
                    }
                    C0058d.P(c0082p2, c0727nA, c0797i4);
                    C0058d.P(c0082p2, interfaceC0079n0M3, c0797i2);
                    if (!c0082p2.f2052O || !h.a(c0082p.G(), Integer.valueOf(i12))) {
                        B.a.k(i12, c0082p2, i12, c0797i3);
                    }
                    C0058d.P(c0082p2, lVarD3, c0797i5);
                    c0082p2.Q(414642107);
                    interfaceC0420a4 = interfaceC0420a3;
                    if (interfaceC0420a4 != null) {
                        b(o2.a.t(), null, interfaceC0420a4, c0082p2, (i11 >> 6) & 896);
                    }
                    c0082p2.p(r3);
                    AbstractC0752n.a(InterfaceC0728O.a(), c0082p2, r3);
                    c0082p2.Q(414647791);
                    if (z5) {
                        c(c0943e.a().f1447a, r3, c0082p2, null);
                    }
                    c0082p2.p(r3);
                    c0082p2.p(true);
                    c0082p2.p(true);
                    interfaceC0420a5 = interfaceC0420a4;
                }
                c0088s0R = c0082p.r();
                if (c0088s0R != null) {
                    c0088s0R.f2094d = new C1.n(str, str2, lVar, z5, interfaceC0420a5, i3, i4);
                    return;
                }
                return;
            }
            i5 |= 24576;
            interfaceC0420a2 = interfaceC0420a;
            i7 = i5;
            if ((i7 & 9363) == 9362) {
                if (i13 == 0) {
                }
                if (i6 == 0) {
                }
                C0943e c0943e2 = (C0943e) c0082p.k(AbstractC0944f.f7823a);
                Y.l lVarB2 = c.b(c.a(lVar, 1.0f), 56);
                Y.d dVar22 = Y.a.f2935d;
                E e32 = AbstractC0752n.e(dVar22, false);
                i8 = c0082p.f2053P;
                InterfaceC0079n0 interfaceC0079n0M4 = c0082p.m();
                Y.l lVarD4 = m.d(c0082p, lVarB2);
                InterfaceC0799k.f6960b.getClass();
                C0803o c0803o22 = C0798j.f6955b;
                c0082p.U();
                if (c0082p.f2052O) {
                }
                C0797i c0797i62 = C0798j.f6958e;
                C0058d.P(c0082p, e32, c0797i62);
                C0797i c0797i72 = C0798j.f6957d;
                C0058d.P(c0082p, interfaceC0079n0M4, c0797i72);
                c0797i = C0798j.f6959f;
                if (!c0082p.f2052O) {
                    B.a.k(i8, c0082p, i8, c0797i);
                    C0797i c0797i82 = C0798j.f6956c;
                    C0058d.P(c0082p, lVarD4, c0797i82);
                    androidx.compose.foundation.layout.b bVar22 = androidx.compose.foundation.layout.b.f3298a;
                    Y.i iVar22 = Y.i.f2958a;
                    Y.d dVar32 = Y.a.f2939h;
                    Y.l lVarA3 = bVar22.a(iVar22, dVar32);
                    E e42 = AbstractC0752n.e(dVar22, false);
                    i9 = c0082p.f2053P;
                    InterfaceC0079n0 interfaceC0079n0M22 = c0082p.m();
                    Y.l lVarD22 = m.d(c0082p, lVarA3);
                    c0082p.U();
                    if (c0082p.f2052O) {
                    }
                    C0058d.P(c0082p, e42, c0797i62);
                    C0058d.P(c0082p, interfaceC0079n0M22, c0797i72);
                    if (!c0082p.f2052O) {
                        B.a.k(i9, c0082p, i9, c0797i);
                        C0058d.P(c0082p, lVarD22, c0797i82);
                        i10 = (i7 & 14) | 48;
                        if (y(str, c0082p, i10) == 0) {
                        }
                        c0082p2.p(true);
                        Y.l lVarA22 = bVar.a(c.a(iVar, 1.0f), dVar);
                        C0727N c0727nA2 = AbstractC0726M.a(AbstractC0747i.f6534a, Y.a.f2943m, c0082p2, r3);
                        i12 = c0082p2.f2053P;
                        InterfaceC0079n0 interfaceC0079n0M32 = c0082p.m();
                        Y.l lVarD32 = m.d(c0082p2, lVarA22);
                        c0082p.U();
                        if (c0082p2.f2052O) {
                        }
                        C0058d.P(c0082p2, c0727nA2, c0797i4);
                        C0058d.P(c0082p2, interfaceC0079n0M32, c0797i2);
                        if (!c0082p2.f2052O) {
                            B.a.k(i12, c0082p2, i12, c0797i3);
                            C0058d.P(c0082p2, lVarD32, c0797i5);
                            c0082p2.Q(414642107);
                            interfaceC0420a4 = interfaceC0420a3;
                            if (interfaceC0420a4 != null) {
                            }
                            c0082p2.p(r3);
                            AbstractC0752n.a(InterfaceC0728O.a(), c0082p2, r3);
                            c0082p2.Q(414647791);
                            if (z5) {
                            }
                            c0082p2.p(r3);
                            c0082p2.p(true);
                            c0082p2.p(true);
                            interfaceC0420a5 = interfaceC0420a4;
                        }
                    }
                }
            }
            c0088s0R = c0082p.r();
            if (c0088s0R != null) {
            }
        }
        z4 = z3;
        i6 = i4 & 16;
        if (i6 != 0) {
        }
        interfaceC0420a2 = interfaceC0420a;
        i7 = i5;
        if ((i7 & 9363) == 9362) {
        }
        c0088s0R = c0082p.r();
        if (c0088s0R != null) {
        }
    }

    public static final long i(int i3, int i4) {
        if (i3 < 0) {
            throw new IllegalArgumentException(("start cannot be negative. [start: " + i3 + ", end: " + i4 + ']').toString());
        }
        if (i4 >= 0) {
            long j2 = (i4 & 4294967295L) | (i3 << 32);
            int i5 = C.f563c;
            return j2;
        }
        throw new IllegalArgumentException(("end cannot be negative. [start: " + i3 + ", end: " + i4 + ']').toString());
    }

    public static final F0.D j(int i3) {
        return new F0.D(D.R(i3), J0.k.f1375h, J0.q.f1380b, 16777177);
    }

    public static final int k(float f3) {
        return Math.round((float) Math.ceil(f3));
    }

    public static final J0.e l(Context context) {
        A.b bVar = new A.b(2);
        context.getApplicationContext();
        return new J0.e(bVar, new J0.a(Build.VERSION.SDK_INT >= 31 ? J0.l.f1377a.a(context) : 0));
    }

    public static final F0.D m(int i3) {
        return new F0.D(D.R(i3), J0.k.i, J0.q.f1380b, 16777177);
    }

    public static final boolean n(int i3, int i4) {
        return i3 == i4;
    }

    public static final boolean o(int i3, int i4) {
        return i3 == i4;
    }

    public static final int p(int i3, List list) {
        int size = list.size() - 1;
        int i4 = 0;
        while (i4 <= size) {
            int i5 = (i4 + size) >>> 1;
            F0.m mVar = (F0.m) list.get(i5);
            char c3 = mVar.f613b > i3 ? (char) 1 : mVar.f614c <= i3 ? (char) 65535 : (char) 0;
            if (c3 < 0) {
                i4 = i5 + 1;
            } else {
                if (c3 <= 0) {
                    return i5;
                }
                size = i5 - 1;
            }
        }
        return -(i4 + 1);
    }

    public static final int q(int i3, List list) {
        int size = list.size() - 1;
        int i4 = 0;
        while (i4 <= size) {
            int i5 = (i4 + size) >>> 1;
            F0.m mVar = (F0.m) list.get(i5);
            char c3 = mVar.f615d > i3 ? (char) 1 : mVar.f616e <= i3 ? (char) 65535 : (char) 0;
            if (c3 < 0) {
                i4 = i5 + 1;
            } else {
                if (c3 <= 0) {
                    return i5;
                }
                size = i5 - 1;
            }
        }
        return -(i4 + 1);
    }

    public static E.b r(E.b bVar, j jVar, F0.D d3, Q0.b bVar2, J0.d dVar) {
        if (bVar != null && jVar == bVar.f454a && h.a(d3, bVar.f455b) && bVar2.a() == bVar.f456c.f2486d && dVar == bVar.f457d) {
            return bVar;
        }
        E.b bVar3 = E.b.f453h;
        if (bVar3 != null && jVar == bVar3.f454a && h.a(d3, bVar3.f455b) && bVar2.a() == bVar3.f456c.f2486d && dVar == bVar3.f457d) {
            return bVar3;
        }
        E.b bVar4 = new E.b(jVar, o2.a.y(d3, jVar), new Q0.c(bVar2.a(), bVar2.t()), dVar);
        E.b.f453h = bVar4;
        return bVar4;
    }

    public static final float s(Layout layout, int i3, Paint paint) {
        float fAbs;
        float width;
        float lineLeft = layout.getLineLeft(i3);
        y yVar = A.f730a;
        if (layout.getEllipsisCount(i3) <= 0 || layout.getParagraphDirection(i3) != 1 || lineLeft >= 0.0f) {
            return 0.0f;
        }
        float fMeasureText = paint.measureText("…") + (layout.getPrimaryHorizontal(layout.getEllipsisStart(i3) + layout.getLineStart(i3)) - lineLeft);
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i3);
        if ((paragraphAlignment == null ? -1 : H0.d.f829a[paragraphAlignment.ordinal()]) == 1) {
            fAbs = Math.abs(lineLeft);
            width = (layout.getWidth() - fMeasureText) / 2.0f;
        } else {
            fAbs = Math.abs(lineLeft);
            width = layout.getWidth() - fMeasureText;
        }
        return width + fAbs;
    }

    public static final float t(Layout layout, int i3, Paint paint) {
        float width;
        float width2;
        y yVar = A.f730a;
        if (layout.getEllipsisCount(i3) <= 0) {
            return 0.0f;
        }
        if (layout.getParagraphDirection(i3) != -1 || layout.getWidth() >= layout.getLineRight(i3)) {
            return 0.0f;
        }
        float fMeasureText = paint.measureText("…") + (layout.getLineRight(i3) - layout.getPrimaryHorizontal(layout.getEllipsisStart(i3) + layout.getLineStart(i3)));
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i3);
        if ((paragraphAlignment != null ? H0.d.f829a[paragraphAlignment.ordinal()] : -1) == 1) {
            width = layout.getWidth() - layout.getLineRight(i3);
            width2 = (layout.getWidth() - fMeasureText) / 2.0f;
        } else {
            width = layout.getWidth() - layout.getLineRight(i3);
            width2 = layout.getWidth() - fMeasureText;
        }
        return width - width2;
    }

    public static final C0415f u() {
        C0415f c0415f = f3052f;
        if (c0415f != null) {
            return c0415f;
        }
        C0414e c0414e = new C0414e("Filled.Lock", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i3 = G.f4692a;
        C0241P c0241p = new C0241P(C0265u.f3887b);
        R0 r02 = new R0(1);
        r02.g(18.0f, 8.0f);
        r02.d(-1.0f);
        r02.e(17.0f, 6.0f);
        r02.c(0.0f, -2.76f, -2.24f, -5.0f, -5.0f, -5.0f);
        r02.h(7.0f, 3.24f, 7.0f, 6.0f);
        r02.k(2.0f);
        r02.e(6.0f, 8.0f);
        r02.c(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f);
        r02.k(10.0f);
        r02.c(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f);
        r02.d(12.0f);
        r02.c(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f);
        r02.e(20.0f, 10.0f);
        r02.c(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f);
        r02.a();
        r02.g(12.0f, 17.0f);
        r02.c(-1.1f, 0.0f, -2.0f, -0.9f, -2.0f, -2.0f);
        r02.i(0.9f, -2.0f, 2.0f, -2.0f);
        r02.i(2.0f, 0.9f, 2.0f, 2.0f);
        r02.i(-0.9f, 2.0f, -2.0f, 2.0f);
        r02.a();
        r02.g(15.1f, 8.0f);
        r02.e(8.9f, 8.0f);
        r02.e(8.9f, 6.0f);
        r02.c(0.0f, -1.71f, 1.39f, -3.1f, 3.1f, -3.1f);
        r02.c(1.71f, 0.0f, 3.1f, 1.39f, 3.1f, 3.1f);
        r02.k(2.0f);
        r02.a();
        C0414e.a(c0414e, r02.f1959d, c0241p);
        C0415f c0415fB = c0414e.b();
        f3052f = c0415fB;
        return c0415fB;
    }

    public static final Object v(i iVar, t tVar) {
        Object obj = iVar.f335d.get(tVar);
        if (obj == null) {
            return null;
        }
        return obj;
    }

    public static final String w(int i3) {
        return String.format("%,d", Arrays.copyOf(new Object[]{Integer.valueOf(i3)}, 1));
    }

    public static final F0.D x(int i3) {
        return new F0.D(D.R(i3), J0.k.f1375h, J0.q.f1380b, 16777177);
    }

    public static int y(String str, C0082p c0082p, int i3) {
        h.e(str, "name");
        c0082p.Q(-1522741242);
        Context context = (Context) c0082p.k(AndroidCompositionLocals_androidKt.f3402b);
        c0082p.Q(-116300382);
        boolean z3 = (((i3 & 14) ^ 6) > 4 && c0082p.f(str)) || (i3 & 6) == 4;
        Object objG = c0082p.G();
        if (z3 || objG == C0074l.f2018a) {
            objG = Integer.valueOf(context.getResources().getIdentifier(str, "drawable", context.getPackageName()));
            c0082p.a0(objG);
        }
        int iIntValue = ((Number) objG).intValue();
        c0082p.p(false);
        c0082p.p(false);
        return iIntValue;
    }

    public static final F0.D z(int i3) {
        return new F0.D(D.R(i3), J0.k.f1374g, J0.q.f1380b, 16777177);
    }
}
