package W1;

import M.C0058d;
import M.C0082p;
import N.F;
import Y1.n;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements l2.e {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2856d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f2857e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ float f2858f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ float f2859g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ float f2860h;
    public final /* synthetic */ float i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f2861j;

    public /* synthetic */ e(float f3, float f4, float f5, float f6, float f7, int i, int i3) {
        this.f2856d = i3;
        this.f2857e = f3;
        this.f2858f = f4;
        this.f2859g = f5;
        this.f2860h = f6;
        this.i = f7;
        this.f2861j = i;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        switch (this.f2856d) {
            case 0:
                ((Integer) obj2).intValue();
                F.t(this.f2857e, this.f2858f, this.f2859g, this.f2860h, this.i, (C0082p) obj, C0058d.S(this.f2861j | 1));
                break;
            default:
                ((Integer) obj2).intValue();
                F.k(this.f2857e, this.f2858f, this.f2859g, this.f2860h, this.i, (C0082p) obj, C0058d.S(this.f2861j | 1));
                break;
        }
        return n.f3007a;
    }
}
