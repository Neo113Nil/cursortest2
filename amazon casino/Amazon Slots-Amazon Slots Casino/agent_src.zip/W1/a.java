package W1;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final float f2844a;

    /* renamed from: b, reason: collision with root package name */
    public final float f2845b;

    /* renamed from: c, reason: collision with root package name */
    public final float f2846c;

    /* renamed from: d, reason: collision with root package name */
    public final float f2847d;

    /* renamed from: e, reason: collision with root package name */
    public final float f2848e;

    public a(float f3, float f4, float f5, float f6, float f7) {
        this.f2844a = f3;
        this.f2845b = f4;
        this.f2846c = f5;
        this.f2847d = f6;
        this.f2848e = f7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return Float.compare(this.f2844a, aVar.f2844a) == 0 && Float.compare(this.f2845b, aVar.f2845b) == 0 && Float.compare(this.f2846c, aVar.f2846c) == 0 && Float.compare(this.f2847d, aVar.f2847d) == 0 && Float.compare(this.f2848e, aVar.f2848e) == 0;
    }

    public final int hashCode() {
        return Float.hashCode(this.f2848e) + B.a.a(this.f2847d, B.a.a(this.f2846c, B.a.a(this.f2845b, Float.hashCode(this.f2844a) * 31, 31), 31), 31);
    }

    public final String toString() {
        return "Floater(x=" + this.f2844a + ", y=" + this.f2845b + ", size=" + this.f2846c + ", spin=" + this.f2847d + ", phase=" + this.f2848e + ")";
    }
}
