package W1;

import M.C0063f0;
import M.InterfaceC0057c0;
import N.F;
import Y1.n;
import c2.InterfaceC0178d;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class i extends e2.i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0057c0 f2874h;
    public final /* synthetic */ C0063f0 i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(InterfaceC0057c0 interfaceC0057c0, C0063f0 c0063f0, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.f2874h = interfaceC0057c0;
        this.i = c0063f0;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        i iVar = (i) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj);
        n nVar = n.f3007a;
        iVar.k(nVar);
        return nVar;
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new i(this.f2874h, this.i, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) {
        F.p0(obj);
        this.f2874h.setValue(Boolean.TRUE);
        this.i.h(1.0f);
        return n.f3007a;
    }
}
