package W1;

import N.F;
import Y1.n;
import c2.InterfaceC0178d;
import d2.EnumC0208a;
import v2.AbstractC0712y;
import v2.G;
import v2.InterfaceC0710w;
import z1.C0945g;

/* loaded from: classes.dex */
public final class j extends e2.i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public int f2875h;
    public final /* synthetic */ C0945g i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(C0945g c0945g, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.i = c0945g;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        return ((j) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj)).k(n.f3007a);
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new j(this.i, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) throws Throwable {
        EnumC0208a enumC0208a = EnumC0208a.f3731d;
        int i = this.f2875h;
        if (i == 0) {
            F.p0(obj);
            G1.b bVar = this.i.f7826c;
            this.f2875h = 1;
            obj = AbstractC0712y.w(G.f6351b, new G1.a(bVar, null), this);
            if (obj == enumC0208a) {
                return enumC0208a;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            F.p0(obj);
        }
        return obj;
    }
}
