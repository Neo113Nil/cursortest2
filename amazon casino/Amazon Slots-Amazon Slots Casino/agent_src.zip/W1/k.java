package W1;

import A2.B;
import M.InterfaceC0057c0;
import N.F;
import Y1.n;
import Z1.m;
import a.AbstractC0112a;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.telephony.TelephonyManager;
import c2.C0184j;
import c2.InterfaceC0178d;
import com.amazonia.reels.canopy.CanopyActivity;
import d2.EnumC0208a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import v2.AbstractC0689a;
import v2.AbstractC0712y;
import v2.C;
import v2.EnumC0711x;
import v2.G;
import v2.InterfaceC0710w;
import z1.C0945g;

/* loaded from: classes.dex */
public final class k extends e2.i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public int f2876h;
    public /* synthetic */ Object i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Context f2877j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ T1.e f2878k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ C0945g f2879l;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0057c0 f2880m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(Context context, T1.e eVar, C0945g c0945g, InterfaceC0057c0 interfaceC0057c0, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.f2877j = context;
        this.f2878k = eVar;
        this.f2879l = c0945g;
        this.f2880m = interfaceC0057c0;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        return ((k) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj)).k(n.f3007a);
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        k kVar = new k(this.f2877j, this.f2878k, this.f2879l, this.f2880m, interfaceC0178d);
        kVar.i = obj;
        return kVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0274 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:116:0x027b  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x02a8  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x01a7  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x01b3  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x01b6  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x01cc  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x020d  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x021b  */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v62, types: [v2.B] */
    /* JADX WARN: Type inference failed for: r0v83 */
    @Override // e2.AbstractC0221a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object k(Object obj) throws Throwable {
        InterfaceC0710w interfaceC0710w;
        String str;
        Object objO;
        boolean zBooleanValue;
        ArrayList arrayList;
        boolean z3;
        boolean z4;
        Object objW;
        Network activeNetwork;
        NetworkCapabilities networkCapabilities;
        K1.d dVar;
        ?? r02;
        Object objX;
        K1.g gVar;
        EnumC0208a enumC0208a = EnumC0208a.f3731d;
        int i = this.f2876h;
        n nVar = n.f3007a;
        T1.e eVar = this.f2878k;
        Context context = this.f2877j;
        C0945g c0945g = this.f2879l;
        switch (i) {
            case 0:
                F.p0(obj);
                interfaceC0710w = (InterfaceC0710w) this.i;
                Boolean bool = Boolean.FALSE;
                InterfaceC0057c0 interfaceC0057c0 = this.f2880m;
                interfaceC0057c0.setValue(bool);
                m2.h.e(context, "context");
                String lowerCase = Z1.k.E0(Z1.l.u0(Build.FINGERPRINT, Build.MODEL, Build.MANUFACTURER, Build.BRAND, Build.DEVICE, Build.PRODUCT, Build.HARDWARE, Build.BOARD, Build.HOST), " ", null, null, null, 62).toLowerCase(Locale.ROOT);
                m2.h.d(lowerCase, "toLowerCase(...)");
                List listU0 = Z1.l.u0("sdk_gphone", "google_sdk", "emulator", "android sdk", "genymotion", "goldfish", "ranchu", "vbox86", "nox", "bluestacks", "ttvm");
                if (listU0.isEmpty()) {
                    str = Build.FINGERPRINT;
                    m2.h.d(str, "FINGERPRINT");
                    if (!str.startsWith("generic") || u2.d.X(str, "/generic", false)) {
                        z4 = true;
                        if (!z4) {
                            this.f2876h = 1;
                            if (AbstractC0712y.d(1900L, this) == enumC0208a) {
                                return enumC0208a;
                            }
                            B1.b.f124h = true;
                            B1.b.e();
                            eVar.f2644a.setValue(Boolean.FALSE);
                            return nVar;
                        }
                        ConnectivityManager connectivityManager = (ConnectivityManager) c0945g.f7824a.f1265e;
                        if (!((connectivityManager == null || (activeNetwork = connectivityManager.getActiveNetwork()) == null || (networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)) == null) ? false : networkCapabilities.hasCapability(12))) {
                            interfaceC0057c0.setValue(Boolean.TRUE);
                            return nVar;
                        }
                        F1.e eVar2 = c0945g.f7825b;
                        this.i = interfaceC0710w;
                        this.f2876h = 2;
                        objW = AbstractC0712y.w(G.f6351b, new F1.a(eVar2, null), this);
                        if (objW == enumC0208a) {
                            return enumC0208a;
                        }
                        dVar = (K1.d) objW;
                        if (!(dVar instanceof K1.a)) {
                            int i3 = CanopyActivity.f3673F;
                            context.startActivity(AbstractC0112a.A(context, ((K1.a) dVar).f1573a));
                            return nVar;
                        }
                        if (m2.h.a(dVar, K1.c.f1575a)) {
                            this.i = null;
                            this.f2876h = 3;
                            if (AbstractC0712y.d(1900L, this) == enumC0208a) {
                                return enumC0208a;
                            }
                            B1.b.f124h = true;
                            B1.b.e();
                            eVar.f2644a.setValue(Boolean.FALSE);
                            return nVar;
                        }
                        if (!m2.h.a(dVar, K1.b.f1574a)) {
                            throw new B();
                        }
                        j jVar = new j(c0945g, null);
                        C0184j c0184j = C0184j.f3669d;
                        EnumC0711x enumC0711x = EnumC0711x.f6428d;
                        AbstractC0689a c3 = new C(AbstractC0712y.p(interfaceC0710w, c0184j), true);
                        c3.j0(enumC0711x, c3, jVar);
                        this.i = c3;
                        this.f2876h = 4;
                        if (AbstractC0712y.d(1900L, this) == enumC0208a) {
                            return enumC0208a;
                        }
                        r02 = c3;
                        this.i = null;
                        this.f2876h = 5;
                        objX = r02.x(this);
                        if (objX == enumC0208a) {
                            return enumC0208a;
                        }
                        gVar = (K1.g) objX;
                        if (gVar instanceof K1.e) {
                            F1.e eVar3 = c0945g.f7825b;
                            String str2 = ((K1.e) gVar).f1576a;
                            this.i = gVar;
                            this.f2876h = 6;
                            Object objW2 = AbstractC0712y.w(G.f6351b, new F1.b(eVar3, str2, null), this);
                            if (objW2 != enumC0208a) {
                                objW2 = nVar;
                            }
                            if (objW2 == enumC0208a) {
                                return enumC0208a;
                            }
                            int i4 = CanopyActivity.f3673F;
                            context.startActivity(AbstractC0112a.A(context, ((K1.e) gVar).f1576a));
                        } else {
                            if (!m2.h.a(gVar, K1.f.f1577a)) {
                                throw new B();
                            }
                            F1.e eVar4 = c0945g.f7825b;
                            this.f2876h = 7;
                            Object objW3 = AbstractC0712y.w(G.f6351b, new F1.d(eVar4, null), this);
                            if (objW3 != enumC0208a) {
                                objW3 = nVar;
                            }
                            if (objW3 == enumC0208a) {
                                return enumC0208a;
                            }
                            B1.b.f124h = true;
                            B1.b.e();
                            eVar.f2644a.setValue(Boolean.FALSE);
                        }
                    } else {
                        String str3 = Build.HARDWARE;
                        m2.h.d(str3, "HARDWARE");
                        if (!u2.d.X(str3, "goldfish", true) && !u2.d.X(str3, "ranchu", true)) {
                            String str4 = Build.PRODUCT;
                            m2.h.d(str4, "PRODUCT");
                            if (u2.d.X(str4, "sdk", true)) {
                                String str5 = Build.MANUFACTURER;
                                m2.h.d(str5, "MANUFACTURER");
                                if (!u2.d.X(str5, "Google", true)) {
                                    TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(TelephonyManager.class);
                                    if (telephonyManager != null && context.getPackageManager().hasSystemFeature("android.hardware.telephony")) {
                                        try {
                                            int phoneCount = telephonyManager.getPhoneCount();
                                            if (phoneCount < 1) {
                                                phoneCount = 1;
                                            }
                                            r2.d dVarO = e0.e.O(0, phoneCount);
                                            arrayList = new ArrayList(m.x0(dVarO, 10));
                                            Iterator it = dVarO.iterator();
                                            while (((r2.c) it).f5623f) {
                                                arrayList.add(Integer.valueOf(telephonyManager.getSimState(((r2.c) it).a())));
                                            }
                                        } catch (Throwable th) {
                                            objO = F.O(th);
                                        }
                                        if (arrayList.isEmpty()) {
                                            z3 = true;
                                            objO = Boolean.valueOf(z3);
                                            Object obj2 = Boolean.TRUE;
                                            if (objO instanceof Y1.i) {
                                                objO = obj2;
                                            }
                                            zBooleanValue = ((Boolean) objO).booleanValue();
                                        } else {
                                            Iterator it2 = arrayList.iterator();
                                            while (it2.hasNext()) {
                                                if (((Number) it2.next()).intValue() == 5) {
                                                    z3 = false;
                                                    objO = Boolean.valueOf(z3);
                                                    Object obj22 = Boolean.TRUE;
                                                    if (objO instanceof Y1.i) {
                                                    }
                                                    zBooleanValue = ((Boolean) objO).booleanValue();
                                                }
                                            }
                                            z3 = true;
                                            objO = Boolean.valueOf(z3);
                                            Object obj222 = Boolean.TRUE;
                                            if (objO instanceof Y1.i) {
                                            }
                                            zBooleanValue = ((Boolean) objO).booleanValue();
                                        }
                                    } else {
                                        zBooleanValue = true;
                                    }
                                    if (!zBooleanValue) {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Iterator it3 = listU0.iterator();
                    while (it3.hasNext()) {
                        if (u2.d.X(lowerCase, (String) it3.next(), false)) {
                            z4 = true;
                            if (!z4) {
                            }
                        }
                    }
                    str = Build.FINGERPRINT;
                    m2.h.d(str, "FINGERPRINT");
                    if (str.startsWith("generic")) {
                        z4 = true;
                        if (!z4) {
                        }
                    }
                }
                return nVar;
            case 1:
                F.p0(obj);
                B1.b.f124h = true;
                B1.b.e();
                eVar.f2644a.setValue(Boolean.FALSE);
                return nVar;
            case 2:
                InterfaceC0710w interfaceC0710w2 = (InterfaceC0710w) this.i;
                F.p0(obj);
                interfaceC0710w = interfaceC0710w2;
                objW = obj;
                dVar = (K1.d) objW;
                if (!(dVar instanceof K1.a)) {
                }
                break;
            case 3:
                F.p0(obj);
                B1.b.f124h = true;
                B1.b.e();
                eVar.f2644a.setValue(Boolean.FALSE);
                return nVar;
            case 4:
                v2.B b3 = (v2.B) this.i;
                F.p0(obj);
                r02 = b3;
                this.i = null;
                this.f2876h = 5;
                objX = r02.x(this);
                if (objX == enumC0208a) {
                }
                gVar = (K1.g) objX;
                if (gVar instanceof K1.e) {
                }
                break;
            case 5:
                F.p0(obj);
                objX = obj;
                gVar = (K1.g) objX;
                if (gVar instanceof K1.e) {
                }
                break;
            case 6:
                gVar = (K1.g) this.i;
                F.p0(obj);
                int i42 = CanopyActivity.f3673F;
                context.startActivity(AbstractC0112a.A(context, ((K1.e) gVar).f1576a));
                return nVar;
            case 7:
                F.p0(obj);
                B1.b.f124h = true;
                B1.b.e();
                eVar.f2644a.setValue(Boolean.FALSE);
                return nVar;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
