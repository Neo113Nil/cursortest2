package W1;

import M.C0082p;
import N.F;
import Y1.n;
import r.C0509F;
import v0.U;
import w.C0756r;

/* loaded from: classes.dex */
public final class l implements l2.f {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0509F f2881d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0509F f2882e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0509F f2883f;

    public l(C0509F c0509f, C0509F c0509f2, C0509F c0509f3) {
        this.f2881d = c0509f;
        this.f2882e = c0509f2;
        this.f2883f = c0509f3;
    }

    @Override // l2.f
    public final Object e(Object obj, Object obj2, Object obj3) {
        C0756r c0756r = (C0756r) obj;
        C0082p c0082p = (C0082p) obj2;
        int iIntValue = ((Number) obj3).intValue();
        m2.h.e(c0756r, "$this$BoxWithConstraints");
        if ((iIntValue & 6) == 0) {
            iIntValue |= c0082p.f(c0756r) ? 4 : 2;
        }
        if ((iIntValue & 19) == 18 && c0082p.x()) {
            c0082p.L();
        } else {
            long j2 = c0756r.f6563b;
            boolean zD = Q0.a.d(j2);
            U u3 = c0756r.f6562a;
            F.t(zD ? u3.j0(Q0.a.h(j2)) : Float.POSITIVE_INFINITY, Q0.a.c(j2) ? u3.j0(Q0.a.g(j2)) : Float.POSITIVE_INFINITY, ((Number) this.f2881d.f5299f.getValue()).floatValue(), ((Number) this.f2882e.f5299f.getValue()).floatValue(), ((Number) this.f2883f.f5299f.getValue()).floatValue(), c0082p, 0);
        }
        return n.f3007a;
    }
}
