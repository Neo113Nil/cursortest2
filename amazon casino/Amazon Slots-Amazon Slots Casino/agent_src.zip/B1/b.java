package B1;

import J1.f;
import Z1.t;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import com.amazonia.reels.R;
import m2.h;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public static Context f117a;

    /* renamed from: b, reason: collision with root package name */
    public static MediaPlayer f118b;

    /* renamed from: c, reason: collision with root package name */
    public static SoundPool f119c;

    /* renamed from: d, reason: collision with root package name */
    public static Object f120d = t.f3029d;

    /* renamed from: e, reason: collision with root package name */
    public static boolean f121e = true;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f122f = true;

    /* renamed from: g, reason: collision with root package name */
    public static boolean f123g;

    /* renamed from: h, reason: collision with root package name */
    public static boolean f124h;

    public static void a(f fVar) throws IllegalStateException {
        h.e(fVar, "settings");
        f121e = fVar.f1397a;
        f123g = fVar.f1399c;
        boolean z3 = fVar.f1398b;
        f122f = z3;
        if (z3) {
            e();
            return;
        }
        MediaPlayer mediaPlayer = f118b;
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    public static void b(long j2) {
        Vibrator vibratorF;
        if (f123g && (vibratorF = f()) != null) {
            vibratorF.vibrate(VibrationEffect.createOneShot(j2, -1));
        }
    }

    public static void c() {
        Vibrator vibratorF;
        if (f123g && (vibratorF = f()) != null) {
            vibratorF.vibrate(VibrationEffect.createWaveform(new long[]{0, 40, 60, 40}, -1));
        }
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, java.util.Map] */
    public static void d(c cVar) {
        Integer num;
        if (f121e && (num = (Integer) f120d.get(cVar)) != null) {
            int iIntValue = num.intValue();
            SoundPool soundPool = f119c;
            if (soundPool != null) {
                soundPool.play(iIntValue, 0.9f, 0.9f, 1, 0, 1.0f);
            }
        }
    }

    public static void e() throws IllegalStateException {
        Context context;
        if (f122f && f124h && (context = f117a) != null) {
            if (f118b == null) {
                MediaPlayer mediaPlayerCreate = MediaPlayer.create(context, R.raw.music);
                if (mediaPlayerCreate != null) {
                    mediaPlayerCreate.setLooping(true);
                    mediaPlayerCreate.setVolume(0.45f, 0.45f);
                } else {
                    mediaPlayerCreate = null;
                }
                f118b = mediaPlayerCreate;
            }
            MediaPlayer mediaPlayer = f118b;
            if (mediaPlayer != null) {
                MediaPlayer mediaPlayer2 = mediaPlayer.isPlaying() ? null : mediaPlayer;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.start();
                }
            }
        }
    }

    public static Vibrator f() {
        Context context = f117a;
        if (context == null) {
            return null;
        }
        if (Build.VERSION.SDK_INT < 31) {
            Object systemService = context.getSystemService("vibrator");
            if (systemService instanceof Vibrator) {
                return (Vibrator) systemService;
            }
            return null;
        }
        Object systemService2 = context.getSystemService("vibrator_manager");
        VibratorManager vibratorManagerD = a.w(systemService2) ? a.d(systemService2) : null;
        if (vibratorManagerD != null) {
            return vibratorManagerD.getDefaultVibrator();
        }
        return null;
    }
}
