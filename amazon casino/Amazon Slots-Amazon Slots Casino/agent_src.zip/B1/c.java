package B1;

import com.amazonia.reels.R;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class c {

    /* renamed from: e, reason: collision with root package name */
    public static final c f125e;

    /* renamed from: f, reason: collision with root package name */
    public static final c f126f;

    /* renamed from: g, reason: collision with root package name */
    public static final c f127g;

    /* renamed from: h, reason: collision with root package name */
    public static final c f128h;
    public static final c i;

    /* renamed from: j, reason: collision with root package name */
    public static final /* synthetic */ c[] f129j;

    /* renamed from: k, reason: collision with root package name */
    public static final /* synthetic */ f2.a f130k;

    /* renamed from: d, reason: collision with root package name */
    public final int f131d;

    static {
        c cVar = new c(0, R.raw.sfx_tap, "TAP");
        f125e = cVar;
        c cVar2 = new c(1, R.raw.sfx_spin, "SPIN");
        f126f = cVar2;
        c cVar3 = new c(2, R.raw.sfx_win, "WIN");
        f127g = cVar3;
        c cVar4 = new c(3, R.raw.sfx_bigwin, "BIG_WIN");
        f128h = cVar4;
        c cVar5 = new c(4, R.raw.sfx_coin, "COIN");
        i = cVar5;
        c[] cVarArr = {cVar, cVar2, cVar3, cVar4, cVar5};
        f129j = cVarArr;
        f130k = new f2.a(cVarArr);
    }

    public c(int i3, int i4, String str) {
        this.f131d = i4;
    }

    public static c valueOf(String str) {
        return (c) Enum.valueOf(c.class, str);
    }

    public static c[] values() {
        return (c[]) f129j.clone();
    }
}
