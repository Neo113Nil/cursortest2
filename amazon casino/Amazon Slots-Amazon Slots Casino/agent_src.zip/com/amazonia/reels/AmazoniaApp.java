package com.amazonia.reels;

import android.app.Application;
import android.webkit.CookieManager;
import o2.a;

/* loaded from: classes.dex */
public class AmazoniaApp extends Application {
    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        CookieManager.getInstance().setAcceptCookie(true);
        a.z(this);
    }
}
