package com.amazonia.reels;

import E1.a;
import H1.b;
import J.C0038l;
import J1.c;
import J1.q;
import J1.x;
import T1.e;
import Z1.w;
import a.AbstractC0112a;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.G;
import androidx.lifecycle.N;
import androidx.lifecycle.O;
import b.m;
import c.AbstractC0152c;
import java.util.Iterator;
import java.util.LinkedHashMap;
import t2.h;
import y0.C0861a0;
import y1.C0913c;
import z1.C0943e;
import z1.C0945g;

/* loaded from: classes.dex */
public final class MainActivity extends m {

    /* renamed from: w, reason: collision with root package name */
    public b f3672w;

    @Override // b.m, android.app.Activity
    public final void onCreate(Bundle bundle) throws IllegalStateException {
        super.onCreate(bundle);
        b bVar = new b();
        a aVar = new a(this);
        a aVar2 = new a(aVar);
        H1.a aVar3 = new H1.a(aVar);
        H1.a aVar4 = new H1.a(aVar);
        b bVar2 = new b();
        bVar2.f853a = aVar;
        bVar2.f854b = AbstractC0112a.f(q.Companion.serializer());
        bVar2.f855c = AbstractC0112a.f(c.Companion.serializer());
        A.b bVar3 = new A.b(1);
        C0038l c0038l = new C0038l(5, aVar2);
        bVar.f853a = new C0943e(c0038l, new a(aVar4, c0038l, bVar3), new a(bVar2, 6, c0038l), bVar3, bVar3, aVar3, new C0038l(4, new x(I1.a.f968a)));
        bVar.f854b = new e();
        bVar.f855c = new C0945g(new C0038l(this), new F1.e(this), new G1.b(this));
        if (B1.b.f117a == null) {
            B1.b.f117a = getApplicationContext();
            SoundPool soundPoolBuild = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).build();
            B1.b.f119c = soundPoolBuild;
            f2.a aVar5 = B1.c.f130k;
            int iJ0 = w.j0(Z1.m.x0(aVar5, 10));
            if (iJ0 < 16) {
                iJ0 = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(iJ0);
            Iterator it = aVar5.iterator();
            while (it.hasNext()) {
                Object next = it.next();
                linkedHashMap.put(next, Integer.valueOf(soundPoolBuild.load(B1.b.f117a, ((B1.c) next).f131d, 1)));
            }
            B1.b.f120d = linkedHashMap;
        }
        B1.b.a(((C0943e) bVar.f853a).b());
        this.f3672w = bVar;
        U.b bVar4 = new U.b(2092747470, new C0913c(this, 2), true);
        ViewGroup.LayoutParams layoutParams = AbstractC0152c.f3611a;
        View childAt = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        C0861a0 c0861a0 = childAt instanceof C0861a0 ? (C0861a0) childAt : null;
        if (c0861a0 != null) {
            c0861a0.setParentCompositionContext(null);
            c0861a0.setContent(bVar4);
            return;
        }
        C0861a0 c0861a02 = new C0861a0(this);
        c0861a02.setParentCompositionContext(null);
        c0861a02.setContent(bVar4);
        View decorView = getWindow().getDecorView();
        if (G.b(decorView) == null) {
            decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (((N) h.Q(h.S(h.R(decorView, O.f3475h), O.i))) == null) {
            decorView.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (e0.b.o(decorView) == null) {
            decorView.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(c0861a02, AbstractC0152c.f3611a);
    }

    @Override // android.app.Activity
    public final void onPause() throws IllegalStateException {
        super.onPause();
        Context context = B1.b.f117a;
        MediaPlayer mediaPlayer = B1.b.f118b;
        if (mediaPlayer != null) {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer = null;
            }
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() throws IllegalStateException {
        super.onResume();
        B1.b.e();
    }
}
