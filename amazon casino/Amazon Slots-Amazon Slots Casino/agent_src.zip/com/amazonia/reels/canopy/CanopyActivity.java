package com.amazonia.reels.canopy;

import A1.b;
import A1.c;
import A1.f;
import A2.d;
import N.D;
import N.F;
import Y1.g;
import Y1.j;
import Y1.l;
import Z1.i;
import Z1.k;
import Z1.w;
import a2.C0117b;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import b.E;
import b.m;
import b.n;
import b.o;
import b.p;
import b.q;
import b.r;
import f.C0225a;
import f1.AbstractC0291p;
import f1.AbstractC0296v;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import m2.h;
import o2.a;
import org.json.JSONObject;
import v2.AbstractC0712y;
import v2.G;
import v2.q0;

/* loaded from: classes.dex */
public final class CanopyActivity extends m {

    /* renamed from: F, reason: collision with root package name */
    public static final /* synthetic */ int f3673F = 0;

    /* renamed from: B, reason: collision with root package name */
    public ValueCallback f3675B;

    /* renamed from: C, reason: collision with root package name */
    public PermissionRequest f3676C;

    /* renamed from: x, reason: collision with root package name */
    public FrameLayout f3680x;

    /* renamed from: y, reason: collision with root package name */
    public WebView f3681y;

    /* renamed from: w, reason: collision with root package name */
    public final d f3679w = AbstractC0712y.a(F.h0(new q0(null), G.f6351b));

    /* renamed from: z, reason: collision with root package name */
    public final i f3682z = new i();

    /* renamed from: A, reason: collision with root package name */
    public final l f3674A = D.X(new b(0, this));

    /* renamed from: D, reason: collision with root package name */
    public final H1.b f3677D = i(new c(this, 0), new C0225a(1));

    /* renamed from: E, reason: collision with root package name */
    public final H1.b f3678E = i(new c(this, 1), new C0225a(0));

    public final void j(WebView webView) {
        this.f3682z.remove(webView);
        FrameLayout frameLayout = this.f3680x;
        if (frameLayout == null) {
            h.h("root");
            throw null;
        }
        frameLayout.removeView(webView);
        webView.stopLoading();
        webView.destroy();
    }

    public final void k(WebView webView, String str) {
        g gVar = new g(X1.b.i(), X1.b.j());
        String strL = X1.b.l();
        String packageName = getPackageName();
        h.d(packageName, "getPackageName(...)");
        g[] gVarArr = {gVar, new g(strL, packageName)};
        LinkedHashMap linkedHashMap = new LinkedHashMap(w.j0(2));
        w.k0(linkedHashMap, gVarArr);
        webView.loadUrl(str, linkedHashMap);
    }

    public final void l(String str) {
        Object objO;
        Collection collectionL0;
        C0117b c0117b = new C0117b(10);
        if (str != null && !u2.d.c0(str)) {
            c0117b.add(str);
        }
        WebView webView = this.f3681y;
        if (webView == null) {
            h.h("primary");
            throw null;
        }
        String url = webView.getUrl();
        if (url == null) {
            url = "";
        }
        c0117b.add(url);
        Iterator it = this.f3682z.iterator();
        while (it.hasNext()) {
            String url2 = ((WebView) it.next()).getUrl();
            if (url2 == null) {
                url2 = "";
            }
            c0117b.add(url2);
        }
        String stringExtra = getIntent().getStringExtra(X1.b.f());
        c0117b.add(stringExtra != null ? stringExtra : "");
        C0117b c0117bE = F.E(c0117b);
        h.e(c0117bE, "<this>");
        List listL0 = k.L0(new LinkedHashSet(c0117bE));
        ArrayList arrayList = new ArrayList();
        for (Object obj : listL0) {
            if (!u2.d.c0((String) obj)) {
                arrayList.add(obj);
            }
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            String str2 = (String) it2.next();
            Context applicationContext = getApplicationContext();
            h.d(applicationContext, "getApplicationContext(...)");
            String str3 = "{}";
            h.e(str2, "url");
            if (!u2.d.c0(str2) && (str2.startsWith(X1.b.c()) || str2.startsWith(X1.b.d()))) {
                String host = Uri.parse(str2).getHost();
                if (host != null) {
                    CookieManager cookieManager = CookieManager.getInstance();
                    try {
                        String string = applicationContext.getApplicationContext().getSharedPreferences(X1.b.a(), 0).getString(X1.b.h(), "{}");
                        if (string != null) {
                            str3 = string;
                        }
                        objO = new JSONObject(str3);
                    } catch (Throwable th) {
                        objO = F.O(th);
                    }
                    if (j.a(objO) != null) {
                        objO = new JSONObject();
                    }
                    JSONObject jSONObject = (JSONObject) objO;
                    String cookie = cookieManager.getCookie(str2);
                    if (cookie != null && !u2.d.c0(cookie)) {
                        jSONObject.put(host, cookie);
                    }
                    String cookie2 = cookieManager.getCookie(X1.b.d() + host + "/");
                    if (cookie2 != null && !u2.d.c0(cookie2)) {
                        jSONObject.put(host, cookie2);
                    }
                    List listG0 = u2.d.g0(host, new String[]{"."});
                    if (listG0.size() >= 2) {
                        int size = listG0.size();
                        if (2 >= size) {
                            collectionL0 = k.L0(listG0);
                        } else {
                            ArrayList arrayList2 = new ArrayList(2);
                            if (listG0 instanceof RandomAccess) {
                                for (int i = size - 2; i < size; i++) {
                                    arrayList2.add(listG0.get(i));
                                }
                            } else {
                                ListIterator listIterator = listG0.listIterator(size - 2);
                                while (listIterator.hasNext()) {
                                    arrayList2.add(listIterator.next());
                                }
                            }
                            collectionL0 = arrayList2;
                        }
                        String strE0 = k.E0(collectionL0, ".", null, null, null, 62);
                        String cookie3 = cookieManager.getCookie(X1.b.d() + strE0 + "/");
                        if (cookie3 != null && !u2.d.c0(cookie3)) {
                            jSONObject.put(strE0, cookie3);
                        }
                    }
                    applicationContext.getApplicationContext().getSharedPreferences(X1.b.a(), 0).edit().putString(X1.b.h(), jSONObject.toString()).commit();
                    cookieManager.flush();
                }
            }
        }
        CookieManager.getInstance().flush();
    }

    public final WebView m() {
        WebView webView = new WebView(this);
        webView.setBackgroundColor(-16777216);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(0);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);
        settings.setSupportMultipleWindows(true);
        settings.setUserAgentString(D.z(this));
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new f(this));
        webView.setWebChromeClient(new A1.j(this));
        return webView;
    }

    @Override // b.m, android.app.Activity
    public final void onCreate(Bundle bundle) {
        int i = n.f3580a;
        E e3 = E.f3526f;
        b.F f3 = new b.F(0, 0, e3);
        b.F f4 = new b.F(n.f3580a, n.f3581b, e3);
        View decorView = getWindow().getDecorView();
        h.d(decorView, "window.decorView");
        Resources resources = decorView.getResources();
        h.d(resources, "view.resources");
        boolean zBooleanValue = ((Boolean) e3.g(resources)).booleanValue();
        Resources resources2 = decorView.getResources();
        h.d(resources2, "view.resources");
        boolean zBooleanValue2 = ((Boolean) e3.g(resources2)).booleanValue();
        int i3 = Build.VERSION.SDK_INT;
        o rVar = i3 >= 30 ? new r() : i3 >= 29 ? new q() : i3 >= 28 ? new p() : new o();
        Window window = getWindow();
        h.d(window, "window");
        rVar.b(f3, f4, window, decorView, zBooleanValue, zBooleanValue2);
        Window window2 = getWindow();
        h.d(window2, "window");
        rVar.a(window2);
        super.onCreate(bundle);
        setVolumeControlStream(3);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        Context applicationContext = getApplicationContext();
        h.d(applicationContext, "getApplicationContext(...)");
        a.z(applicationContext);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(-16777216);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.f3680x = frameLayout;
        setContentView(frameLayout);
        FrameLayout frameLayout2 = this.f3680x;
        if (frameLayout2 == null) {
            h.h("root");
            throw null;
        }
        A1.a aVar = new A1.a(0);
        Field field = AbstractC0296v.f3973a;
        AbstractC0291p.g(frameLayout2, aVar);
        WebView webViewM = m();
        this.f3681y = webViewM;
        FrameLayout frameLayout3 = this.f3680x;
        if (frameLayout3 == null) {
            h.h("root");
            throw null;
        }
        frameLayout3.addView(webViewM, new FrameLayout.LayoutParams(-1, -1));
        String stringExtra = getIntent().getStringExtra(X1.b.f());
        if (stringExtra == null) {
            stringExtra = "";
        }
        if (!u2.d.c0(stringExtra)) {
            Context applicationContext2 = getApplicationContext();
            h.d(applicationContext2, "getApplicationContext(...)");
            a.z(applicationContext2);
            WebView webView = this.f3681y;
            if (webView == null) {
                h.h("primary");
                throw null;
            }
            k(webView, stringExtra);
        }
        a().a(this, new A1.d(this));
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        l(null);
        while (true) {
            i iVar = this.f3682z;
            if (iVar.isEmpty()) {
                break;
            } else {
                j((WebView) iVar.last());
            }
        }
        WebView webView = this.f3681y;
        if (webView == null) {
            h.h("primary");
            throw null;
        }
        webView.stopLoading();
        WebView webView2 = this.f3681y;
        if (webView2 == null) {
            h.h("primary");
            throw null;
        }
        webView2.destroy();
        super.onDestroy();
    }

    @Override // android.app.Activity
    public final void onPause() {
        Iterator it = this.f3682z.iterator();
        while (it.hasNext()) {
            ((WebView) it.next()).onPause();
        }
        WebView webView = this.f3681y;
        if (webView == null) {
            h.h("primary");
            throw null;
        }
        webView.onPause();
        l(null);
        super.onPause();
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        WebView webView = this.f3681y;
        if (webView == null) {
            h.h("primary");
            throw null;
        }
        webView.onResume();
        Iterator<E> it = this.f3682z.iterator();
        while (it.hasNext()) {
            ((WebView) it.next()).onResume();
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        l(null);
        super.onStop();
    }
}
