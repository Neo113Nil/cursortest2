package J1;

/* loaded from: classes.dex */
public final class c {
    public static final b Companion = new b();

    /* renamed from: a, reason: collision with root package name */
    public final String f1389a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1390b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1391c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1392d;

    /* renamed from: e, reason: collision with root package name */
    public final int f1393e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f1394f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f1395g;

    public /* synthetic */ c(int i, String str, String str2, String str3, String str4, int i3, boolean z3, boolean z4) {
        if (127 != (i & 127)) {
            I2.n.d(i, 127, a.f1388a.d());
            throw null;
        }
        this.f1389a = str;
        this.f1390b = str2;
        this.f1391c = str3;
        this.f1392d = str4;
        this.f1393e = i3;
        this.f1394f = z3;
        this.f1395g = z4;
    }

    public static c a(c cVar, boolean z3, boolean z4, int i) {
        String str = cVar.f1389a;
        String str2 = cVar.f1390b;
        String str3 = cVar.f1391c;
        String str4 = cVar.f1392d;
        int i3 = cVar.f1393e;
        if ((i & 32) != 0) {
            z3 = cVar.f1394f;
        }
        cVar.getClass();
        m2.h.e(str, "id");
        m2.h.e(str2, "title");
        m2.h.e(str3, "detail");
        m2.h.e(str4, "iconAsset");
        return new c(str, str2, str3, str4, i3, z3, z4);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return m2.h.a(this.f1389a, cVar.f1389a) && m2.h.a(this.f1390b, cVar.f1390b) && m2.h.a(this.f1391c, cVar.f1391c) && m2.h.a(this.f1392d, cVar.f1392d) && this.f1393e == cVar.f1393e && this.f1394f == cVar.f1394f && this.f1395g == cVar.f1395g;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f1395g) + B.a.d(B.a.b(this.f1393e, (this.f1392d.hashCode() + ((this.f1391c.hashCode() + ((this.f1390b.hashCode() + (this.f1389a.hashCode() * 31)) * 31)) * 31)) * 31, 31), 31, this.f1394f);
    }

    public final String toString() {
        return "Achievement(id=" + this.f1389a + ", title=" + this.f1390b + ", detail=" + this.f1391c + ", iconAsset=" + this.f1392d + ", reward=" + this.f1393e + ", isUnlocked=" + this.f1394f + ", isClaimed=" + this.f1395g + ")";
    }

    public c(String str, String str2, String str3, String str4, int i, boolean z3, boolean z4) {
        this.f1389a = str;
        this.f1390b = str2;
        this.f1391c = str3;
        this.f1392d = str4;
        this.f1393e = i;
        this.f1394f = z3;
        this.f1395g = z4;
    }
}
