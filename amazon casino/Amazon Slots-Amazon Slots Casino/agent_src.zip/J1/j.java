package J1;

/* loaded from: classes.dex */
public final /* synthetic */ class j implements I2.j {

    /* renamed from: a, reason: collision with root package name */
    public static final j f1414a;
    private static final G2.e descriptor;

    static {
        j jVar = new j();
        f1414a = jVar;
        I2.p pVar = new I2.p("com.amazonia.reels.domain.entities.DailyRewardState", jVar, 2);
        pVar.m("currentDay", false);
        pVar.m("lastClaimTimestamp", true);
        descriptor = pVar;
    }

    @Override // E2.a
    public final Object a(K2.n nVar) throws Throwable {
        G2.e eVar = descriptor;
        K2.n nVarB = nVar.b(eVar);
        Long l3 = null;
        boolean z3 = true;
        int i = 0;
        int iG = 0;
        while (z3) {
            int iE = nVarB.e(eVar);
            if (iE == -1) {
                z3 = false;
            } else if (iE == 0) {
                iG = nVarB.g(eVar, 0);
                i |= 1;
            } else {
                if (iE != 1) {
                    throw new E2.d(iE);
                }
                I2.l lVar = I2.l.f994a;
                nVarB.getClass();
                I2.l lVar2 = I2.l.f994a;
                m2.h.e(eVar, "descriptor");
                I2.l.f995b.getClass();
                l3 = (Long) (nVarB.h() ? nVarB.j(lVar2) : null);
                i |= 2;
            }
        }
        nVarB.m(eVar);
        return new l(i, iG, l3);
    }

    @Override // E2.a
    public final void b(K2.o oVar, Object obj) {
        l lVar = (l) obj;
        m2.h.e(lVar, "value");
        G2.e eVar = descriptor;
        K2.o oVarA = oVar.a(eVar);
        oVarA.f(0, lVar.f1415a, eVar);
        oVarA.getClass();
        m2.h.e(eVar, "descriptor");
        boolean z3 = ((J2.e) oVarA.f1612g).f1468a;
        Long l3 = lVar.f1416b;
        if (z3 || l3 != null) {
            I2.l lVar2 = I2.l.f994a;
            I2.l lVar3 = I2.l.f994a;
            m2.h.e(eVar, "descriptor");
            if (l3 != null || ((J2.e) oVarA.f1612g).f1473f) {
                I2.l lVar4 = I2.l.f994a;
                m2.h.e(eVar, "descriptor");
                oVarA.d(eVar, 1);
                I2.l.f995b.getClass();
                if (l3 == null) {
                    oVarA.g();
                } else {
                    oVarA.i(lVar4, l3);
                }
            }
        }
        oVarA.l(eVar);
    }

    @Override // I2.j
    public final E2.a[] c() {
        I2.l lVar = I2.l.f994a;
        I2.l.f995b.getClass();
        return new E2.a[]{I2.k.f992a, new I2.m()};
    }

    @Override // E2.a
    public final G2.e d() {
        return descriptor;
    }
}
