package J1;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements I2.j {

    /* renamed from: a, reason: collision with root package name */
    public static final a f1388a;
    private static final G2.e descriptor;

    static {
        a aVar = new a();
        f1388a = aVar;
        I2.p pVar = new I2.p("com.amazonia.reels.domain.entities.Achievement", aVar, 7);
        pVar.m("id", false);
        pVar.m("title", false);
        pVar.m("detail", false);
        pVar.m("iconAsset", false);
        pVar.m("reward", false);
        pVar.m("isUnlocked", false);
        pVar.m("isClaimed", false);
        descriptor = pVar;
    }

    @Override // E2.a
    public final Object a(K2.n nVar) throws Throwable {
        G2.e eVar = descriptor;
        K2.n nVarB = nVar.b(eVar);
        int i = 0;
        int iG = 0;
        boolean zD = false;
        boolean zD2 = false;
        String strL = null;
        String strL2 = null;
        String strL3 = null;
        String strL4 = null;
        boolean z3 = true;
        while (z3) {
            int iE = nVarB.e(eVar);
            switch (iE) {
                case -1:
                    z3 = false;
                    break;
                case 0:
                    strL = nVarB.l(eVar, 0);
                    i |= 1;
                    break;
                case 1:
                    strL2 = nVarB.l(eVar, 1);
                    i |= 2;
                    break;
                case 2:
                    strL3 = nVarB.l(eVar, 2);
                    i |= 4;
                    break;
                case 3:
                    strL4 = nVarB.l(eVar, 3);
                    i |= 8;
                    break;
                case 4:
                    iG = nVarB.g(eVar, 4);
                    i |= 16;
                    break;
                case 5:
                    zD = nVarB.d(eVar, 5);
                    i |= 32;
                    break;
                case 6:
                    zD2 = nVarB.d(eVar, 6);
                    i |= 64;
                    break;
                default:
                    throw new E2.d(iE);
            }
        }
        nVarB.m(eVar);
        return new c(i, strL, strL2, strL3, strL4, iG, zD, zD2);
    }

    @Override // E2.a
    public final void b(K2.o oVar, Object obj) {
        c cVar = (c) obj;
        m2.h.e(cVar, "value");
        G2.e eVar = descriptor;
        K2.o oVarA = oVar.a(eVar);
        oVarA.k(eVar, 0, cVar.f1389a);
        oVarA.k(eVar, 1, cVar.f1390b);
        oVarA.k(eVar, 2, cVar.f1391c);
        oVarA.k(eVar, 3, cVar.f1392d);
        oVarA.f(4, cVar.f1393e, eVar);
        oVarA.c(eVar, 5, cVar.f1394f);
        oVarA.c(eVar, 6, cVar.f1395g);
        oVarA.l(eVar);
    }

    @Override // I2.j
    public final E2.a[] c() {
        I2.s sVar = I2.s.f1016a;
        I2.d dVar = I2.d.f979a;
        return new E2.a[]{sVar, sVar, sVar, sVar, I2.k.f992a, dVar, dVar};
    }

    @Override // E2.a
    public final G2.e d() {
        return descriptor;
    }
}
