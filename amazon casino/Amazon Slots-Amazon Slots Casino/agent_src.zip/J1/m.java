package J1;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class m {

    /* renamed from: a, reason: collision with root package name */
    public final String f1417a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1418b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1419c;

    /* renamed from: d, reason: collision with root package name */
    public final double f1420d;

    /* renamed from: e, reason: collision with root package name */
    public final String f1421e;

    /* renamed from: f, reason: collision with root package name */
    public final List f1422f;

    /* renamed from: g, reason: collision with root package name */
    public final int f1423g;

    /* renamed from: h, reason: collision with root package name */
    public final String f1424h;
    public final String i;

    /* renamed from: j, reason: collision with root package name */
    public final ArrayList f1425j;

    public m(String str, String str2, int i, double d3, String str3, List list, int i3, String str4, String str5, ArrayList arrayList) {
        n nVar = n.f1426e;
        this.f1417a = str;
        this.f1418b = str2;
        this.f1419c = i;
        this.f1420d = d3;
        this.f1421e = str3;
        this.f1422f = list;
        this.f1423g = i3;
        this.f1424h = str4;
        this.i = str5;
        this.f1425j = arrayList;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        if (!this.f1417a.equals(mVar.f1417a) || !this.f1418b.equals(mVar.f1418b)) {
            return false;
        }
        n nVar = n.f1426e;
        return this.f1419c == mVar.f1419c && Double.compare(this.f1420d, mVar.f1420d) == 0 && this.f1421e.equals(mVar.f1421e) && this.f1422f.equals(mVar.f1422f) && this.f1423g == mVar.f1423g && this.f1424h.equals(mVar.f1424h) && this.i.equals(mVar.i) && this.f1425j.equals(mVar.f1425j);
    }

    public final int hashCode() {
        return this.f1425j.hashCode() + ((this.i.hashCode() + ((((this.f1424h.hashCode() + B.a.b(this.f1423g, (this.f1422f.hashCode() + ((this.f1421e.hashCode() + ((Double.hashCode(this.f1420d) + B.a.b(this.f1419c, (n.f1426e.hashCode() + ((this.f1418b.hashCode() + (this.f1417a.hashCode() * 31)) * 31)) * 31, 31)) * 31)) * 31)) * 31, 31)) * 31) - 1251520225) * 31)) * 31);
    }

    public final String toString() {
        return "Game(id=" + this.f1417a + ", title=" + this.f1418b + ", category=" + n.f1426e + ", entryCost=" + this.f1419c + ", rating=" + this.f1420d + ", summary=" + this.f1421e + ", rules=" + this.f1422f + ", requiredLevel=" + this.f1423g + ", thumbnailAsset=" + this.f1424h + ", backgroundAsset=bg_reels, titleBannerAsset=" + this.i + ", symbolAssets=" + this.f1425j + ")";
    }
}
