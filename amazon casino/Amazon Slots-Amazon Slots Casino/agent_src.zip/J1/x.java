package J1;

import java.util.List;

/* loaded from: classes.dex */
public final class x {

    /* renamed from: a, reason: collision with root package name */
    public final List f1453a;

    public x(List list) {
        m2.h.e(list, "symbols");
        this.f1453a = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof x)) {
            return false;
        }
        x xVar = (x) obj;
        xVar.getClass();
        return m2.h.a(this.f1453a, xVar.f1453a);
    }

    public final int hashCode() {
        return this.f1453a.hashCode() + B.a.b(3, Integer.hashCode(5) * 31, 31);
    }

    public final String toString() {
        return "ReelConfiguration(columns=5, rows=3, symbols=" + this.f1453a + ")";
    }
}
