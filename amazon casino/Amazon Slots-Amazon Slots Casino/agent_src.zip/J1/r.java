package J1;

import l2.InterfaceC0420a;

/* loaded from: classes.dex */
public final /* synthetic */ class r implements InterfaceC0420a {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1439d;

    public /* synthetic */ r(int i) {
        this.f1439d = i;
    }

    @Override // l2.InterfaceC0420a
    public final Object a() {
        switch (this.f1439d) {
            case 0:
                t[] tVarArrValues = t.values();
                m2.h.e(tVarArrValues, "values");
                return new I2.i(tVarArrValues);
            case 1:
                B1.b.b(12L);
                return Y1.n.f3007a;
            case 2:
                return X1.a.a("Cl3NKjzHKhUB22LVfOxYrshzqvV2ySaEQyRtoiZitq0=");
            case 3:
                return X1.a.a("nHWCaeHnj4isqyAr2TV+LA==");
            case 4:
                throw new IllegalStateException("AppRouter is not provided");
            case 5:
                throw new IllegalStateException("VineSession is not provided");
            default:
                throw new IllegalStateException("GameStore is not provided");
        }
    }
}
