package J1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class n {

    /* renamed from: e, reason: collision with root package name */
    public static final n f1426e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ n[] f1427f;

    /* renamed from: g, reason: collision with root package name */
    public static final /* synthetic */ f2.a f1428g;

    /* renamed from: d, reason: collision with root package name */
    public final String f1429d;

    static {
        n nVar = new n("SLOTS", 0, "Slots");
        f1426e = nVar;
        n[] nVarArr = {nVar, new n("TABLE", 1, "Table"), new n("BONUS", 2, "Bonus")};
        f1427f = nVarArr;
        f1428g = new f2.a(nVarArr);
    }

    public n(String str, int i, String str2) {
        this.f1429d = str2;
    }

    public static n valueOf(String str) {
        return (n) Enum.valueOf(n.class, str);
    }

    public static n[] values() {
        return (n[]) f1427f.clone();
    }
}
