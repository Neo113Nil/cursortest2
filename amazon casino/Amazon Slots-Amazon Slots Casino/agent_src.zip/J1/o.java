package J1;

/* loaded from: classes.dex */
public final /* synthetic */ class o implements I2.j {

    /* renamed from: a, reason: collision with root package name */
    public static final o f1430a;
    private static final G2.e descriptor;

    static {
        o oVar = new o();
        f1430a = oVar;
        I2.p pVar = new I2.p("com.amazonia.reels.domain.entities.Mission", oVar, 7);
        pVar.m("id", false);
        pVar.m("title", false);
        pVar.m("iconAsset", false);
        pVar.m("goal", false);
        pVar.m("reward", false);
        pVar.m("progress", false);
        pVar.m("status", false);
        descriptor = pVar;
    }

    @Override // E2.a
    public final Object a(K2.n nVar) throws Throwable {
        G2.e eVar = descriptor;
        K2.n nVarB = nVar.b(eVar);
        E2.a[] aVarArr = q.f1431h;
        int i = 0;
        int iG = 0;
        int iG2 = 0;
        int iG3 = 0;
        String strL = null;
        String strL2 = null;
        String strL3 = null;
        t tVar = null;
        boolean z3 = true;
        while (z3) {
            int iE = nVarB.e(eVar);
            switch (iE) {
                case -1:
                    z3 = false;
                    break;
                case 0:
                    strL = nVarB.l(eVar, 0);
                    i |= 1;
                    break;
                case 1:
                    strL2 = nVarB.l(eVar, 1);
                    i |= 2;
                    break;
                case 2:
                    strL3 = nVarB.l(eVar, 2);
                    i |= 4;
                    break;
                case 3:
                    iG = nVarB.g(eVar, 3);
                    i |= 8;
                    break;
                case 4:
                    iG2 = nVarB.g(eVar, 4);
                    i |= 16;
                    break;
                case 5:
                    iG3 = nVarB.g(eVar, 5);
                    i |= 32;
                    break;
                case 6:
                    tVar = (t) nVarB.i(eVar, 6, aVarArr[6], tVar);
                    i |= 64;
                    break;
                default:
                    throw new E2.d(iE);
            }
        }
        nVarB.m(eVar);
        return new q(i, strL, strL2, strL3, iG, iG2, iG3, tVar);
    }

    @Override // E2.a
    public final void b(K2.o oVar, Object obj) {
        q qVar = (q) obj;
        m2.h.e(qVar, "value");
        G2.e eVar = descriptor;
        K2.o oVarA = oVar.a(eVar);
        oVarA.k(eVar, 0, qVar.f1432a);
        oVarA.k(eVar, 1, qVar.f1433b);
        oVarA.k(eVar, 2, qVar.f1434c);
        oVarA.f(3, qVar.f1435d, eVar);
        oVarA.f(4, qVar.f1436e, eVar);
        oVarA.f(5, qVar.f1437f, eVar);
        oVarA.h(eVar, 6, q.f1431h[6], qVar.f1438g);
        oVarA.l(eVar);
    }

    @Override // I2.j
    public final E2.a[] c() {
        E2.a aVar = q.f1431h[6];
        I2.s sVar = I2.s.f1016a;
        I2.k kVar = I2.k.f992a;
        return new E2.a[]{sVar, sVar, sVar, kVar, kVar, kVar, aVar};
    }

    @Override // E2.a
    public final G2.e d() {
        return descriptor;
    }
}
