package J1;

import java.util.LinkedHashSet;
import java.util.Set;

/* loaded from: classes.dex */
public final class w {
    public static final v Companion = new v();

    /* renamed from: g, reason: collision with root package name */
    public static final E2.a[] f1446g;

    /* renamed from: a, reason: collision with root package name */
    public final int f1447a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1448b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1449c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1450d;

    /* renamed from: e, reason: collision with root package name */
    public final String f1451e;

    /* renamed from: f, reason: collision with root package name */
    public final Set f1452f;

    static {
        I2.s sVar = I2.s.f1016a;
        f1446g = new E2.a[]{null, null, null, null, null, new I2.c()};
    }

    public /* synthetic */ w(int i, int i3, int i4, int i5, String str, String str2, Set set) {
        if (63 != (i & 63)) {
            I2.n.d(i, 63, u.f1445a.d());
            throw null;
        }
        this.f1447a = i3;
        this.f1448b = i4;
        this.f1449c = i5;
        this.f1450d = str;
        this.f1451e = str2;
        this.f1452f = set;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v2, types: [java.util.Set] */
    public static w a(w wVar, int i, int i3, int i4, String str, String str2, LinkedHashSet linkedHashSet, int i5) {
        if ((i5 & 1) != 0) {
            i = wVar.f1447a;
        }
        int i6 = i;
        if ((i5 & 2) != 0) {
            i3 = wVar.f1448b;
        }
        int i7 = i3;
        if ((i5 & 4) != 0) {
            i4 = wVar.f1449c;
        }
        int i8 = i4;
        if ((i5 & 8) != 0) {
            str = wVar.f1450d;
        }
        String str3 = str;
        if ((i5 & 16) != 0) {
            str2 = wVar.f1451e;
        }
        String str4 = str2;
        LinkedHashSet linkedHashSet2 = linkedHashSet;
        if ((i5 & 32) != 0) {
            linkedHashSet2 = wVar.f1452f;
        }
        LinkedHashSet linkedHashSet3 = linkedHashSet2;
        wVar.getClass();
        m2.h.e(str3, "equippedAvatarId");
        m2.h.e(str4, "equippedCardBackId");
        m2.h.e(linkedHashSet3, "unlockedItemIds");
        return new w(i6, i7, i8, str3, str4, linkedHashSet3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof w)) {
            return false;
        }
        w wVar = (w) obj;
        return this.f1447a == wVar.f1447a && this.f1448b == wVar.f1448b && this.f1449c == wVar.f1449c && m2.h.a(this.f1450d, wVar.f1450d) && m2.h.a(this.f1451e, wVar.f1451e) && m2.h.a(this.f1452f, wVar.f1452f);
    }

    public final int hashCode() {
        return this.f1452f.hashCode() + ((this.f1451e.hashCode() + ((this.f1450d.hashCode() + B.a.b(this.f1449c, B.a.b(this.f1448b, Integer.hashCode(this.f1447a) * 31, 31), 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Player(coins=" + this.f1447a + ", level=" + this.f1448b + ", experience=" + this.f1449c + ", equippedAvatarId=" + this.f1450d + ", equippedCardBackId=" + this.f1451e + ", unlockedItemIds=" + this.f1452f + ")";
    }

    public w(int i, int i3, int i4, String str, String str2, Set set) {
        this.f1447a = i;
        this.f1448b = i3;
        this.f1449c = i4;
        this.f1450d = str;
        this.f1451e = str2;
        this.f1452f = set;
    }
}
