package J1;

/* loaded from: classes.dex */
public final class s {
    /* JADX WARN: Type inference failed for: r0v0, types: [Y1.d, java.lang.Object] */
    public final E2.a serializer() {
        return (E2.a) t.f1440d.getValue();
    }
}
