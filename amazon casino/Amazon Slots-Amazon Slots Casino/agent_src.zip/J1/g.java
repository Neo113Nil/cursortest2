package J1;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final String f1401a;

    /* renamed from: b, reason: collision with root package name */
    public final h f1402b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1403c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1404d;

    /* renamed from: e, reason: collision with root package name */
    public final String f1405e;

    /* renamed from: f, reason: collision with root package name */
    public final int f1406f;

    public g(String str, h hVar, String str2, String str3, String str4, int i) {
        this.f1401a = str;
        this.f1402b = hVar;
        this.f1403c = str2;
        this.f1404d = str3;
        this.f1405e = str4;
        this.f1406f = i;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return this.f1401a.equals(gVar.f1401a) && this.f1402b == gVar.f1402b && this.f1403c.equals(gVar.f1403c) && this.f1404d.equals(gVar.f1404d) && this.f1405e.equals(gVar.f1405e) && this.f1406f == gVar.f1406f;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f1406f) + ((this.f1405e.hashCode() + ((this.f1404d.hashCode() + ((this.f1403c.hashCode() + ((this.f1402b.hashCode() + (this.f1401a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "CollectionItem(id=" + this.f1401a + ", kind=" + this.f1402b + ", name=" + this.f1403c + ", asset=" + this.f1404d + ", unlockDescription=" + this.f1405e + ", requiredLevel=" + this.f1406f + ")";
    }
}
