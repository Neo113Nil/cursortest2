package J1;

/* loaded from: classes.dex */
public final class e {
    public final E2.a serializer() {
        return d.f1396a;
    }
}
