package J1;

/* loaded from: classes.dex */
public final class k {
    public final E2.a serializer() {
        return j.f1414a;
    }
}
