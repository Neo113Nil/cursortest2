package J1;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public final int f1410a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1411b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1412c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1413d;

    public i(int i, int i3, String str, boolean z3) {
        this.f1410a = i;
        this.f1411b = i3;
        this.f1412c = str;
        this.f1413d = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return this.f1410a == iVar.f1410a && this.f1411b == iVar.f1411b && this.f1412c.equals(iVar.f1412c) && this.f1413d == iVar.f1413d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f1413d) + ((this.f1412c.hashCode() + B.a.b(this.f1411b, Integer.hashCode(this.f1410a) * 31, 31)) * 31);
    }

    public final String toString() {
        return "DailyRewardDay(id=" + this.f1410a + ", coins=" + this.f1411b + ", label=" + this.f1412c + ", isGrandPrize=" + this.f1413d + ")";
    }
}
