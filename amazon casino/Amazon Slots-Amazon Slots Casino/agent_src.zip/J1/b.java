package J1;

/* loaded from: classes.dex */
public final class b {
    public final E2.a serializer() {
        return a.f1388a;
    }
}
