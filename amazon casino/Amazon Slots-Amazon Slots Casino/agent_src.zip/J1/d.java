package J1;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements I2.j {

    /* renamed from: a, reason: collision with root package name */
    public static final d f1396a;
    private static final G2.e descriptor;

    static {
        d dVar = new d();
        f1396a = dVar;
        I2.p pVar = new I2.p("com.amazonia.reels.domain.entities.AppSettings", dVar, 4);
        pVar.m("soundEnabled", false);
        pVar.m("musicEnabled", false);
        pVar.m("vibrationEnabled", false);
        pVar.m("sessionRemindersEnabled", false);
        descriptor = pVar;
    }

    @Override // E2.a
    public final Object a(K2.n nVar) throws Throwable {
        G2.e eVar = descriptor;
        K2.n nVarB = nVar.b(eVar);
        boolean z3 = true;
        int i = 0;
        boolean zD = false;
        boolean zD2 = false;
        boolean zD3 = false;
        boolean zD4 = false;
        while (z3) {
            int iE = nVarB.e(eVar);
            if (iE == -1) {
                z3 = false;
            } else if (iE == 0) {
                zD = nVarB.d(eVar, 0);
                i |= 1;
            } else if (iE == 1) {
                zD2 = nVarB.d(eVar, 1);
                i |= 2;
            } else if (iE == 2) {
                zD3 = nVarB.d(eVar, 2);
                i |= 4;
            } else {
                if (iE != 3) {
                    throw new E2.d(iE);
                }
                zD4 = nVarB.d(eVar, 3);
                i |= 8;
            }
        }
        nVarB.m(eVar);
        return new f(i, zD, zD2, zD3, zD4);
    }

    @Override // E2.a
    public final void b(K2.o oVar, Object obj) {
        f fVar = (f) obj;
        m2.h.e(fVar, "value");
        G2.e eVar = descriptor;
        K2.o oVarA = oVar.a(eVar);
        oVarA.c(eVar, 0, fVar.f1397a);
        oVarA.c(eVar, 1, fVar.f1398b);
        oVarA.c(eVar, 2, fVar.f1399c);
        oVarA.c(eVar, 3, fVar.f1400d);
        oVarA.l(eVar);
    }

    @Override // I2.j
    public final E2.a[] c() {
        I2.d dVar = I2.d.f979a;
        return new E2.a[]{dVar, dVar, dVar, dVar};
    }

    @Override // E2.a
    public final G2.e d() {
        return descriptor;
    }
}
