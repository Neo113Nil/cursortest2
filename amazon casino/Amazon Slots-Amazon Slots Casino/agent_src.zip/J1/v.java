package J1;

/* loaded from: classes.dex */
public final class v {
    public final E2.a serializer() {
        return u.f1445a;
    }
}
