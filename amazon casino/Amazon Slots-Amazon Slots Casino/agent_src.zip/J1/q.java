package J1;

/* loaded from: classes.dex */
public final class q {
    public static final p Companion = new p();

    /* renamed from: h, reason: collision with root package name */
    public static final E2.a[] f1431h = {null, null, null, null, null, null, t.Companion.serializer()};

    /* renamed from: a, reason: collision with root package name */
    public final String f1432a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1433b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1434c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1435d;

    /* renamed from: e, reason: collision with root package name */
    public final int f1436e;

    /* renamed from: f, reason: collision with root package name */
    public final int f1437f;

    /* renamed from: g, reason: collision with root package name */
    public final t f1438g;

    public /* synthetic */ q(int i, String str, String str2, String str3, int i3, int i4, int i5, t tVar) {
        if (127 != (i & 127)) {
            I2.n.d(i, 127, o.f1430a.d());
            throw null;
        }
        this.f1432a = str;
        this.f1433b = str2;
        this.f1434c = str3;
        this.f1435d = i3;
        this.f1436e = i4;
        this.f1437f = i5;
        this.f1438g = tVar;
    }

    public static q a(q qVar, int i, t tVar, int i3) {
        String str = qVar.f1432a;
        String str2 = qVar.f1433b;
        String str3 = qVar.f1434c;
        int i4 = qVar.f1435d;
        int i5 = qVar.f1436e;
        if ((i3 & 32) != 0) {
            i = qVar.f1437f;
        }
        qVar.getClass();
        m2.h.e(str, "id");
        m2.h.e(str2, "title");
        m2.h.e(str3, "iconAsset");
        m2.h.e(tVar, "status");
        return new q(str, str2, str3, i4, i5, i, tVar);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return m2.h.a(this.f1432a, qVar.f1432a) && m2.h.a(this.f1433b, qVar.f1433b) && m2.h.a(this.f1434c, qVar.f1434c) && this.f1435d == qVar.f1435d && this.f1436e == qVar.f1436e && this.f1437f == qVar.f1437f && this.f1438g == qVar.f1438g;
    }

    public final int hashCode() {
        return this.f1438g.hashCode() + B.a.b(this.f1437f, B.a.b(this.f1436e, B.a.b(this.f1435d, (this.f1434c.hashCode() + ((this.f1433b.hashCode() + (this.f1432a.hashCode() * 31)) * 31)) * 31, 31), 31), 31);
    }

    public final String toString() {
        return "Mission(id=" + this.f1432a + ", title=" + this.f1433b + ", iconAsset=" + this.f1434c + ", goal=" + this.f1435d + ", reward=" + this.f1436e + ", progress=" + this.f1437f + ", status=" + this.f1438g + ")";
    }

    public q(String str, String str2, String str3, int i, int i3, int i4, t tVar) {
        this.f1432a = str;
        this.f1433b = str2;
        this.f1434c = str3;
        this.f1435d = i;
        this.f1436e = i3;
        this.f1437f = i4;
        this.f1438g = tVar;
    }
}
