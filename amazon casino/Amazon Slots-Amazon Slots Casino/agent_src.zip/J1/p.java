package J1;

/* loaded from: classes.dex */
public final class p {
    public final E2.a serializer() {
        return o.f1430a;
    }
}
