package J1;

/* loaded from: classes.dex */
public final class f {
    public static final e Companion = new e();

    /* renamed from: a, reason: collision with root package name */
    public final boolean f1397a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f1398b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1399c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1400d;

    public /* synthetic */ f(int i, boolean z3, boolean z4, boolean z5, boolean z6) {
        if (15 != (i & 15)) {
            I2.n.d(i, 15, d.f1396a.d());
            throw null;
        }
        this.f1397a = z3;
        this.f1398b = z4;
        this.f1399c = z5;
        this.f1400d = z6;
    }

    public static f a(f fVar, boolean z3, boolean z4, boolean z5, boolean z6, int i) {
        if ((i & 1) != 0) {
            z3 = fVar.f1397a;
        }
        if ((i & 2) != 0) {
            z4 = fVar.f1398b;
        }
        if ((i & 4) != 0) {
            z5 = fVar.f1399c;
        }
        if ((i & 8) != 0) {
            z6 = fVar.f1400d;
        }
        fVar.getClass();
        return new f(z3, z4, z5, z6);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return this.f1397a == fVar.f1397a && this.f1398b == fVar.f1398b && this.f1399c == fVar.f1399c && this.f1400d == fVar.f1400d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f1400d) + B.a.d(B.a.d(Boolean.hashCode(this.f1397a) * 31, 31, this.f1398b), 31, this.f1399c);
    }

    public final String toString() {
        return "AppSettings(soundEnabled=" + this.f1397a + ", musicEnabled=" + this.f1398b + ", vibrationEnabled=" + this.f1399c + ", sessionRemindersEnabled=" + this.f1400d + ")";
    }

    public f(boolean z3, boolean z4, boolean z5, boolean z6) {
        this.f1397a = z3;
        this.f1398b = z4;
        this.f1399c = z5;
        this.f1400d = z6;
    }
}
