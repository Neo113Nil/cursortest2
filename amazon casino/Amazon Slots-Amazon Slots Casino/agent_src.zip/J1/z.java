package J1;

import java.util.ArrayList;
import java.util.LinkedHashSet;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f1458a;

    /* renamed from: b, reason: collision with root package name */
    public final LinkedHashSet f1459b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1460c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1461d;

    public z(ArrayList arrayList, LinkedHashSet linkedHashSet, int i, boolean z3) {
        this.f1458a = arrayList;
        this.f1459b = linkedHashSet;
        this.f1460c = i;
        this.f1461d = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof z)) {
            return false;
        }
        z zVar = (z) obj;
        return this.f1458a.equals(zVar.f1458a) && this.f1459b.equals(zVar.f1459b) && this.f1460c == zVar.f1460c && this.f1461d == zVar.f1461d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f1461d) + B.a.b(this.f1460c, (this.f1459b.hashCode() + (this.f1458a.hashCode() * 31)) * 31, 31);
    }

    public final String toString() {
        return "SpinOutcome(grid=" + this.f1458a + ", winningRows=" + this.f1459b + ", coinsWon=" + this.f1460c + ", triggeredFreeSpins=" + this.f1461d + ")";
    }
}
