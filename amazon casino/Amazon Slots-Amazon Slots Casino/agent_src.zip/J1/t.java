package J1;

import N.D;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class t {
    public static final s Companion;

    /* renamed from: d, reason: collision with root package name */
    public static final Object f1440d;

    /* renamed from: e, reason: collision with root package name */
    public static final t f1441e;

    /* renamed from: f, reason: collision with root package name */
    public static final t f1442f;

    /* renamed from: g, reason: collision with root package name */
    public static final t f1443g;

    /* renamed from: h, reason: collision with root package name */
    public static final /* synthetic */ t[] f1444h;

    static {
        t tVar = new t("IN_PROGRESS", 0);
        f1441e = tVar;
        t tVar2 = new t("CLAIMABLE", 1);
        f1442f = tVar2;
        t tVar3 = new t("CLAIMED", 2);
        f1443g = tVar3;
        f1444h = new t[]{tVar, tVar2, tVar3};
        Companion = new s();
        f1440d = D.W(Y1.e.f2994d, new r(0));
    }

    public static t valueOf(String str) {
        return (t) Enum.valueOf(t.class, str);
    }

    public static t[] values() {
        return (t[]) f1444h.clone();
    }
}
