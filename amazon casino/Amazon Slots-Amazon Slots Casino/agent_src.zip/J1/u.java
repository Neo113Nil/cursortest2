package J1;

import java.util.Set;

/* loaded from: classes.dex */
public final /* synthetic */ class u implements I2.j {

    /* renamed from: a, reason: collision with root package name */
    public static final u f1445a;
    private static final G2.e descriptor;

    static {
        u uVar = new u();
        f1445a = uVar;
        I2.p pVar = new I2.p("com.amazonia.reels.domain.entities.Player", uVar, 6);
        pVar.m("coins", false);
        pVar.m("level", false);
        pVar.m("experience", false);
        pVar.m("equippedAvatarId", false);
        pVar.m("equippedCardBackId", false);
        pVar.m("unlockedItemIds", false);
        descriptor = pVar;
    }

    @Override // E2.a
    public final Object a(K2.n nVar) throws Throwable {
        G2.e eVar = descriptor;
        K2.n nVarB = nVar.b(eVar);
        E2.a[] aVarArr = w.f1446g;
        int i = 0;
        int iG = 0;
        int iG2 = 0;
        int iG3 = 0;
        String strL = null;
        String strL2 = null;
        Set set = null;
        boolean z3 = true;
        while (z3) {
            int iE = nVarB.e(eVar);
            switch (iE) {
                case -1:
                    z3 = false;
                    break;
                case 0:
                    iG = nVarB.g(eVar, 0);
                    i |= 1;
                    break;
                case 1:
                    iG2 = nVarB.g(eVar, 1);
                    i |= 2;
                    break;
                case 2:
                    iG3 = nVarB.g(eVar, 2);
                    i |= 4;
                    break;
                case 3:
                    strL = nVarB.l(eVar, 3);
                    i |= 8;
                    break;
                case 4:
                    strL2 = nVarB.l(eVar, 4);
                    i |= 16;
                    break;
                case 5:
                    set = (Set) nVarB.i(eVar, 5, aVarArr[5], set);
                    i |= 32;
                    break;
                default:
                    throw new E2.d(iE);
            }
        }
        nVarB.m(eVar);
        return new w(i, iG, iG2, iG3, strL, strL2, set);
    }

    @Override // E2.a
    public final void b(K2.o oVar, Object obj) {
        w wVar = (w) obj;
        m2.h.e(wVar, "value");
        G2.e eVar = descriptor;
        K2.o oVarA = oVar.a(eVar);
        oVarA.f(0, wVar.f1447a, eVar);
        oVarA.f(1, wVar.f1448b, eVar);
        oVarA.f(2, wVar.f1449c, eVar);
        oVarA.k(eVar, 3, wVar.f1450d);
        oVarA.k(eVar, 4, wVar.f1451e);
        oVarA.h(eVar, 5, w.f1446g[5], wVar.f1452f);
        oVarA.l(eVar);
    }

    @Override // I2.j
    public final E2.a[] c() {
        E2.a aVar = w.f1446g[5];
        I2.k kVar = I2.k.f992a;
        I2.s sVar = I2.s.f1016a;
        return new E2.a[]{kVar, kVar, kVar, sVar, sVar, aVar};
    }

    @Override // E2.a
    public final G2.e d() {
        return descriptor;
    }
}
