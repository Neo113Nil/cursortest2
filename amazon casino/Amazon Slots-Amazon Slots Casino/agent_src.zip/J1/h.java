package J1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: d, reason: collision with root package name */
    public static final h f1407d;

    /* renamed from: e, reason: collision with root package name */
    public static final h f1408e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ h[] f1409f;

    static {
        h hVar = new h("AVATAR", 0);
        f1407d = hVar;
        h hVar2 = new h("CARD_BACK", 1);
        f1408e = hVar2;
        f1409f = new h[]{hVar, hVar2};
    }

    public static h valueOf(String str) {
        return (h) Enum.valueOf(h.class, str);
    }

    public static h[] values() {
        return (h[]) f1409f.clone();
    }
}
