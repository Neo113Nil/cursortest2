package J1;

/* loaded from: classes.dex */
public final class l {
    public static final k Companion = new k();

    /* renamed from: a, reason: collision with root package name */
    public final int f1415a;

    /* renamed from: b, reason: collision with root package name */
    public final Long f1416b;

    public /* synthetic */ l(int i, int i3, Long l3) {
        if (1 != (i & 1)) {
            I2.n.d(i, 1, j.f1414a.d());
            throw null;
        }
        this.f1415a = i3;
        if ((i & 2) == 0) {
            this.f1416b = null;
        } else {
            this.f1416b = l3;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return this.f1415a == lVar.f1415a && m2.h.a(this.f1416b, lVar.f1416b);
    }

    public final int hashCode() {
        int iHashCode = Integer.hashCode(this.f1415a) * 31;
        Long l3 = this.f1416b;
        return iHashCode + (l3 == null ? 0 : l3.hashCode());
    }

    public final String toString() {
        return "DailyRewardState(currentDay=" + this.f1415a + ", lastClaimTimestamp=" + this.f1416b + ")";
    }

    public l(int i, Long l3) {
        this.f1415a = i;
        this.f1416b = l3;
    }
}
