package J1;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public final String f1454a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1455b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1456c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1457d;

    public y(String str, String str2, int i, boolean z3) {
        this.f1454a = str;
        this.f1455b = str2;
        this.f1456c = i;
        this.f1457d = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        return this.f1454a.equals(yVar.f1454a) && this.f1455b.equals(yVar.f1455b) && this.f1456c == yVar.f1456c && this.f1457d == yVar.f1457d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f1457d) + B.a.b(this.f1456c, (this.f1455b.hashCode() + (this.f1454a.hashCode() * 31)) * 31, 31);
    }

    public final String toString() {
        return "SlotSymbol(id=" + this.f1454a + ", asset=" + this.f1455b + ", payoutMultiplier=" + this.f1456c + ", isScatter=" + this.f1457d + ")";
    }
}
