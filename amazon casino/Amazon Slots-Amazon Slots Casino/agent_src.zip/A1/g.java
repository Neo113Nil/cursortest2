package A1;

import android.content.DialogInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;

/* loaded from: classes.dex */
public final /* synthetic */ class g implements DialogInterface.OnClickListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f38a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ JsResult f39b;

    public /* synthetic */ g(JsResult jsResult, int i) {
        this.f38a = i;
        this.f39b = jsResult;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.f38a) {
            case 0:
                JsResult jsResult = this.f39b;
                if (jsResult != null) {
                    jsResult.confirm();
                    break;
                }
                break;
            case 1:
                JsResult jsResult2 = this.f39b;
                if (jsResult2 != null) {
                    jsResult2.confirm();
                    break;
                }
                break;
            case 2:
                JsResult jsResult3 = this.f39b;
                if (jsResult3 != null) {
                    jsResult3.cancel();
                    break;
                }
                break;
            default:
                JsPromptResult jsPromptResult = (JsPromptResult) this.f39b;
                if (jsPromptResult != null) {
                    jsPromptResult.cancel();
                    break;
                }
                break;
        }
    }
}
