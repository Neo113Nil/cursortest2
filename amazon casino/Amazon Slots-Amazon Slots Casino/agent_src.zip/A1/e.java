package A1;

import N.F;
import Y1.n;
import c2.InterfaceC0178d;
import com.amazonia.reels.canopy.CanopyActivity;
import d2.EnumC0208a;
import v2.AbstractC0712y;
import v2.G;
import v2.InterfaceC0710w;

/* loaded from: classes.dex */
public final class e extends e2.i implements l2.e {

    /* renamed from: h, reason: collision with root package name */
    public int f35h;
    public final /* synthetic */ CanopyActivity i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ String f36j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(CanopyActivity canopyActivity, String str, InterfaceC0178d interfaceC0178d) {
        super(2, interfaceC0178d);
        this.i = canopyActivity;
        this.f36j = str;
    }

    @Override // l2.e
    public final Object f(Object obj, Object obj2) {
        return ((e) h((InterfaceC0178d) obj2, (InterfaceC0710w) obj)).k(n.f3007a);
    }

    @Override // e2.AbstractC0221a
    public final InterfaceC0178d h(InterfaceC0178d interfaceC0178d, Object obj) {
        return new e(this.i, this.f36j, interfaceC0178d);
    }

    @Override // e2.AbstractC0221a
    public final Object k(Object obj) throws Throwable {
        EnumC0208a enumC0208a = EnumC0208a.f3731d;
        int i = this.f35h;
        n nVar = n.f3007a;
        if (i == 0) {
            F.p0(obj);
            F1.e eVar = (F1.e) this.i.f3674A.getValue();
            this.f35h = 1;
            eVar.getClass();
            Object objW = AbstractC0712y.w(G.f6351b, new F1.c(eVar, this.f36j, null), this);
            if (objW != enumC0208a) {
                objW = nVar;
            }
            if (objW == enumC0208a) {
                return enumC0208a;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            F.p0(obj);
        }
        return nVar;
    }
}
