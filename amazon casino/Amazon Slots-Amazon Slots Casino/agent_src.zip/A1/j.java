package A1;

import N.D;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Message;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.FrameLayout;
import com.amazonia.reels.canopy.CanopyActivity;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class j extends WebChromeClient {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ CanopyActivity f44a;

    public j(CanopyActivity canopyActivity) {
        this.f44a = canopyActivity;
    }

    @Override // android.webkit.WebChromeClient
    public final void onCloseWindow(WebView webView) {
        if (webView != null) {
            CanopyActivity canopyActivity = this.f44a;
            if (canopyActivity.f3682z.contains(webView)) {
                canopyActivity.j(webView);
            }
        }
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onCreateWindow(WebView webView, boolean z3, boolean z4, Message message) {
        int i = CanopyActivity.f3673F;
        CanopyActivity canopyActivity = this.f44a;
        WebView webViewM = canopyActivity.m();
        canopyActivity.f3682z.addLast(webViewM);
        FrameLayout frameLayout = canopyActivity.f3680x;
        if (frameLayout == null) {
            m2.h.h("root");
            throw null;
        }
        frameLayout.addView(webViewM, new FrameLayout.LayoutParams(-1, -1));
        Object obj = message != null ? message.obj : null;
        WebView.WebViewTransport webViewTransport = obj instanceof WebView.WebViewTransport ? (WebView.WebViewTransport) obj : null;
        if (webViewTransport == null) {
            return false;
        }
        webViewTransport.setWebView(webViewM);
        message.sendToTarget();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public final void onGeolocationPermissionsShowPrompt(String str, GeolocationPermissions.Callback callback) {
        if (callback != null) {
            callback.invoke(str, true, false);
        }
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
        new AlertDialog.Builder(this.f44a).setTitle("Оповещение").setMessage(str2).setPositiveButton("ОК", new g(jsResult, 0)).setOnCancelListener(new h(jsResult, 0)).show();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsConfirm(WebView webView, String str, String str2, JsResult jsResult) {
        new AlertDialog.Builder(this.f44a).setTitle("Подтверждение").setMessage(str2).setPositiveButton("ОК", new g(jsResult, 1)).setNegativeButton("Отмена", new g(jsResult, 2)).setOnCancelListener(new h(jsResult, 1)).show();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsPrompt(WebView webView, String str, String str2, String str3, final JsPromptResult jsPromptResult) {
        CanopyActivity canopyActivity = this.f44a;
        final EditText editText = new EditText(canopyActivity);
        if (str3 == null) {
            str3 = "";
        }
        editText.setText(str3);
        new AlertDialog.Builder(canopyActivity).setTitle("Ввод данных").setMessage(str2).setView(editText).setPositiveButton("ОК", new DialogInterface.OnClickListener() { // from class: A1.i
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                JsPromptResult jsPromptResult2 = jsPromptResult;
                if (jsPromptResult2 != null) {
                    jsPromptResult2.confirm(editText.getText().toString());
                }
            }
        }).setNegativeButton("Отмена", new g(jsPromptResult, 3)).setOnCancelListener(new h(jsPromptResult, 2)).show();
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v3, types: [java.lang.Cloneable, java.lang.Object[]] */
    @Override // android.webkit.WebChromeClient
    public final void onPermissionRequest(PermissionRequest permissionRequest) throws Exception {
        if (permissionRequest == null) {
            return;
        }
        CanopyActivity canopyActivity = this.f44a;
        canopyActivity.f3676C = permissionRequest;
        ArrayList arrayList = new ArrayList();
        String[] resources = permissionRequest.getResources();
        m2.h.d(resources, "getResources(...)");
        if (Z1.j.r0(resources, "android.webkit.resource.VIDEO_CAPTURE") >= 0) {
            arrayList.add("android.permission.CAMERA");
        }
        String[] resources2 = permissionRequest.getResources();
        m2.h.d(resources2, "getResources(...)");
        if (Z1.j.r0(resources2, "android.webkit.resource.AUDIO_CAPTURE") >= 0) {
            arrayList.add("android.permission.RECORD_AUDIO");
        }
        if (arrayList.isEmpty()) {
            permissionRequest.deny();
            canopyActivity.f3676C = null;
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Object next = it.next();
            if (D.D(canopyActivity, (String) next) != 0) {
                arrayList2.add(next);
            }
        }
        if (arrayList2.isEmpty()) {
            permissionRequest.grant(permissionRequest.getResources());
            canopyActivity.f3676C = null;
        } else {
            canopyActivity.f3678E.t(arrayList2.toArray(new String[0]));
        }
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onShowFileChooser(WebView webView, ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        Intent intent;
        CanopyActivity canopyActivity = this.f44a;
        ValueCallback valueCallback2 = canopyActivity.f3675B;
        if (valueCallback2 != null) {
            valueCallback2.onReceiveValue(null);
        }
        canopyActivity.f3675B = valueCallback;
        if (fileChooserParams == null || (intent = fileChooserParams.createIntent()) == null) {
            intent = new Intent("android.intent.action.GET_CONTENT");
            intent.addCategory("android.intent.category.OPENABLE");
            intent.setType("*/*");
        }
        try {
            canopyActivity.f3677D.t(intent);
            return true;
        } catch (Exception unused) {
            canopyActivity.f3675B = null;
            return false;
        }
    }
}
