package A1;

import W.p;
import Z1.m;
import android.net.Uri;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import com.amazonia.reels.canopy.CanopyActivity;
import e.C0214b;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final /* synthetic */ class c {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f31a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f32b;

    public /* synthetic */ c(CanopyActivity canopyActivity, int i) {
        this.f31a = i;
        this.f32b = canopyActivity;
    }

    public void a() {
        m2.i iVar = (m2.i) this.f32b;
        synchronized (p.f2800b) {
            try {
                List list = (List) p.f2805g;
                m2.h.e(list, "<this>");
                ArrayList arrayList = new ArrayList(m.x0(list, 10));
                boolean z3 = false;
                for (Object obj : list) {
                    boolean z4 = true;
                    if (!z3 && m2.h.a(obj, iVar)) {
                        z3 = true;
                        z4 = false;
                    }
                    if (z4) {
                        arrayList.add(obj);
                    }
                }
                p.f2805g = arrayList;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void b(Object obj) {
        Object obj2 = this.f32b;
        switch (this.f31a) {
            case 0:
                C0214b c0214b = (C0214b) obj;
                int i = CanopyActivity.f3673F;
                m2.h.e(c0214b, "result");
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(c0214b.f3741d, c0214b.f3742e);
                CanopyActivity canopyActivity = (CanopyActivity) obj2;
                ValueCallback valueCallback = canopyActivity.f3675B;
                if (valueCallback != null) {
                    valueCallback.onReceiveValue(result);
                }
                canopyActivity.f3675B = null;
                break;
            default:
                Map map = (Map) obj;
                int i3 = CanopyActivity.f3673F;
                m2.h.e(map, "grants");
                CanopyActivity canopyActivity2 = (CanopyActivity) obj2;
                PermissionRequest permissionRequest = canopyActivity2.f3676C;
                if (permissionRequest != null) {
                    canopyActivity2.f3676C = null;
                    ArrayList arrayList = new ArrayList();
                    String[] resources = permissionRequest.getResources();
                    m2.h.d(resources, "getResources(...)");
                    for (String str : resources) {
                        if (m2.h.a(str, "android.webkit.resource.VIDEO_CAPTURE") ? m2.h.a(map.get("android.permission.CAMERA"), Boolean.TRUE) : m2.h.a(str, "android.webkit.resource.AUDIO_CAPTURE") ? m2.h.a(map.get("android.permission.RECORD_AUDIO"), Boolean.TRUE) : false) {
                            arrayList.add(str);
                        }
                    }
                    if (arrayList.isEmpty()) {
                        permissionRequest.deny();
                        break;
                    } else {
                        permissionRequest.grant((String[]) arrayList.toArray(new String[0]));
                        break;
                    }
                }
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ c(l2.e eVar) {
        this.f31a = 2;
        this.f32b = (m2.i) eVar;
    }
}
