package A1;

import J.E;
import android.webkit.WebView;
import b.t;
import com.amazonia.reels.canopy.CanopyActivity;

/* loaded from: classes.dex */
public final class d extends t {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f33d = 0;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f34e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(CanopyActivity canopyActivity) {
        super(true);
        this.f34e = canopyActivity;
    }

    @Override // b.t
    public final void a() {
        switch (this.f33d) {
            case 0:
                CanopyActivity canopyActivity = (CanopyActivity) this.f34e;
                if (!canopyActivity.f3682z.isEmpty()) {
                    canopyActivity.j((WebView) canopyActivity.f3682z.last());
                    return;
                }
                WebView webView = canopyActivity.f3681y;
                if (webView == null) {
                    m2.h.h("primary");
                    throw null;
                }
                if (webView.canGoBack()) {
                    WebView webView2 = canopyActivity.f3681y;
                    if (webView2 != null) {
                        webView2.goBack();
                        return;
                    } else {
                        m2.h.h("primary");
                        throw null;
                    }
                }
                return;
            default:
                ((E) this.f34e).g(this);
                return;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(boolean z3, E e3) {
        super(z3);
        this.f34e = e3;
    }
}
