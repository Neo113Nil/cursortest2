package A1;

import M.C0065g0;
import Y1.n;
import android.content.Context;
import com.amazonia.reels.canopy.CanopyActivity;
import l2.InterfaceC0420a;
import z1.C0943e;

/* loaded from: classes.dex */
public final /* synthetic */ class b implements InterfaceC0420a {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f29d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f30e;

    public /* synthetic */ b(int i, Object obj) {
        this.f29d = i;
        this.f30e = obj;
    }

    @Override // l2.InterfaceC0420a
    public final Object a() {
        n nVar = n.f3007a;
        Object obj = this.f30e;
        switch (this.f29d) {
            case 0:
                int i = CanopyActivity.f3673F;
                Context applicationContext = ((CanopyActivity) obj).getApplicationContext();
                m2.h.d(applicationContext, "getApplicationContext(...)");
                break;
            case 1:
                G2.g gVar = (G2.g) obj;
                break;
            case 2:
                I2.i iVar = (I2.i) obj;
                iVar.getClass();
                Enum[] enumArr = iVar.f990a;
                I2.h hVar = new I2.h(enumArr.length);
                for (Enum r02 : enumArr) {
                    hVar.m(r02.name(), false);
                }
                break;
            case 3:
                break;
            case 4:
                C0943e c0943e = (C0943e) obj;
                c0943e.e(c0943e.f7815a.l(1000));
                Context context = B1.b.f117a;
                B1.b.d(B1.c.i);
                break;
            default:
                C0065g0 c0065g0 = (C0065g0) obj;
                c0065g0.h(c0065g0.g() + 1);
                break;
        }
        return nVar;
    }
}
