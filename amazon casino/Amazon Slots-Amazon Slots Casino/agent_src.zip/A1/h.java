package A1;

import android.content.DialogInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;

/* loaded from: classes.dex */
public final /* synthetic */ class h implements DialogInterface.OnCancelListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f40a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ JsResult f41b;

    public /* synthetic */ h(JsResult jsResult, int i) {
        this.f40a = i;
        this.f41b = jsResult;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        switch (this.f40a) {
            case 0:
                JsResult jsResult = this.f41b;
                if (jsResult != null) {
                    jsResult.cancel();
                    break;
                }
                break;
            case 1:
                JsResult jsResult2 = this.f41b;
                if (jsResult2 != null) {
                    jsResult2.cancel();
                    break;
                }
                break;
            default:
                JsPromptResult jsPromptResult = (JsPromptResult) this.f41b;
                if (jsPromptResult != null) {
                    jsPromptResult.cancel();
                    break;
                }
                break;
        }
    }
}
