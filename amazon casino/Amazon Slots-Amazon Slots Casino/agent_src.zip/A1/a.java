package A1;

import android.view.View;
import com.amazonia.reels.canopy.CanopyActivity;
import f1.InterfaceC0283h;
import f1.S;
import g0.InterfaceC0306i;
import r.InterfaceC0543y;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements InterfaceC0283h, InterfaceC0543y, InterfaceC0306i {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f28d;

    public /* synthetic */ a(int i) {
        this.f28d = i;
    }

    @Override // r.InterfaceC0543y
    public float a(float f3) {
        switch (this.f28d) {
            case 1:
                return 1.0f - (((float) Math.exp((-6.0f) * f3)) * ((float) Math.cos(f3 * 10.0f)));
            default:
                return f3;
        }
    }

    @Override // f1.InterfaceC0283h
    public S b(View view, S s3) {
        int i = CanopyActivity.f3673F;
        m2.h.e(view, "view");
        Y0.c cVarF = s3.f3937a.f(135);
        m2.h.d(cVarF, "getInsets(...)");
        view.setPadding(cVarF.f2974a, cVarF.f2975b, cVarF.f2976c, cVarF.f2977d);
        return S.f3936b;
    }

    @Override // g0.InterfaceC0306i
    public double c(double d3) {
        double d4;
        switch (this.f28d) {
            case 4:
                double dPow = d3 < 0.0d ? -d3 : d3;
                if (dPow >= 0.0031308049535603718d) {
                    dPow = Math.pow(dPow, 0.4166666666666667d) - 0.05213270142180095d;
                    d4 = 0.9478672985781991d;
                } else {
                    d4 = 0.07739938080495357d;
                }
                return Math.copySign(dPow / d4, d3);
            case 5:
                double d5 = d3 < 0.0d ? -d3 : d3;
                return Math.copySign(d5 >= 0.04045d ? Math.pow((0.9478672985781991d * d5) + 0.05213270142180095d, 2.4d) : d5 * 0.07739938080495357d, d3);
            default:
                return d3;
        }
    }
}
