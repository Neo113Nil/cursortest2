package A1;

import N.F;
import Y1.l;
import Z1.k;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.amazonia.reels.canopy.CanopyActivity;
import java.net.URISyntaxException;
import java.util.ArrayList;
import v2.AbstractC0712y;

/* loaded from: classes.dex */
public final class f extends WebViewClient {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ CanopyActivity f37a;

    public f(CanopyActivity canopyActivity) {
        this.f37a = canopyActivity;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, String str) {
        int i = CanopyActivity.f3673F;
        this.f37a.l(str);
    }

    @Override // android.webkit.WebViewClient
    public final void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        if (str == null) {
            str = "";
        }
        if (str.startsWith(X1.b.c()) || str.startsWith(X1.b.d())) {
            CanopyActivity canopyActivity = this.f37a;
            AbstractC0712y.o(canopyActivity.f3679w, null, null, new e(canopyActivity, str, null), 3);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00b9  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00d5 A[LOOP:1: B:52:0x00d3->B:53:0x00d5, LOOP_END] */
    @Override // android.webkit.WebViewClient
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        Uri url;
        Object objO;
        String str;
        Object objO2;
        String str2;
        if (webResourceRequest == null || (url = webResourceRequest.getUrl()) == null) {
            return false;
        }
        String string = url.toString();
        m2.h.d(string, "toString(...)");
        int i = CanopyActivity.f3673F;
        CanopyActivity canopyActivity = this.f37a;
        canopyActivity.getClass();
        if (!string.startsWith(X1.b.c()) && !string.startsWith(X1.b.d())) {
            try {
                try {
                    canopyActivity.startActivity(string.startsWith("intent://") ? Intent.parseUri(string, 1) : new Intent("android.intent.action.VIEW", Uri.parse(string)));
                    return true;
                } catch (Throwable th) {
                    objO = F.O(th);
                    if (objO instanceof Y1.i) {
                        objO = null;
                    }
                    str = (String) objO;
                    if (str == null && !u2.d.c0(str)) {
                        WebView webView2 = canopyActivity.f3681y;
                        if (webView2 != null) {
                            canopyActivity.k(webView2, str);
                            return true;
                        }
                        m2.h.h("primary");
                        throw null;
                    }
                    try {
                        objO2 = Intent.parseUri(string, 1).getPackage();
                    } catch (Throwable th2) {
                        objO2 = F.O(th2);
                    }
                    str2 = (String) (objO2 instanceof Y1.i ? null : objO2);
                    if (str2 != null && !u2.d.c0(str2)) {
                        l lVar = X1.b.f2933a;
                        int[] iArr = {55, 59, 40, 49, 63, 46, 96, 117, 117, 62, 63, 46, 59, 51, 54, 41, 101, 51, 62, 103};
                        ArrayList arrayList = new ArrayList(20);
                        for (int i3 = 0; i3 < 20; i3++) {
                            arrayList.add(Character.valueOf((char) (iArr[i3] ^ 90)));
                        }
                        canopyActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(k.E0(arrayList, "", null, null, null, 62).concat(str2))));
                        return true;
                    }
                    return false;
                }
            } catch (ActivityNotFoundException unused) {
                Intent uri = Intent.parseUri(string, 1);
                l lVar2 = X1.b.f2933a;
                int[] iArr2 = {56, 40, 53, 45, 41, 63, 40, 5, 60, 59, 54, 54, 56, 59, 57, 49, 5, 47, 40, 54};
                ArrayList arrayList2 = new ArrayList(20);
                for (int i4 = 0; i4 < 20; i4++) {
                    arrayList2.add(Character.valueOf((char) (iArr2[i4] ^ 90)));
                }
                objO = uri.getStringExtra(k.E0(arrayList2, "", null, null, null, 62));
                if (objO instanceof Y1.i) {
                }
                str = (String) objO;
                if (str == null) {
                }
                objO2 = Intent.parseUri(string, 1).getPackage();
                str2 = (String) (objO2 instanceof Y1.i ? null : objO2);
                if (str2 != null) {
                    l lVar3 = X1.b.f2933a;
                    int[] iArr3 = {55, 59, 40, 49, 63, 46, 96, 117, 117, 62, 63, 46, 59, 51, 54, 41, 101, 51, 62, 103};
                    ArrayList arrayList3 = new ArrayList(20);
                    while (i3 < 20) {
                    }
                    canopyActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(k.E0(arrayList3, "", null, null, null, 62).concat(str2))));
                    return true;
                }
                return false;
            } catch (URISyntaxException unused2) {
            }
        }
        return false;
    }
}
