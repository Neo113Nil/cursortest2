package e;

import android.os.LocaleList;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public abstract class b {
    public static String a() {
        LocaleList adjustedDefault = LocaleList.getAdjustedDefault();
        if (adjustedDefault.size() > 0) {
            return adjustedDefault.get(0).toLanguageTag();
        }
        return null;
    }
}
