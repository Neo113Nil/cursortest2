package e;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: c, reason: collision with root package name */
    public ActivityOptions f95c;

    /* renamed from: a, reason: collision with root package name */
    public final Intent f93a = new Intent("android.intent.action.VIEW");

    /* renamed from: b, reason: collision with root package name */
    public final c0.b f94b = new c0.b(2);

    /* renamed from: d, reason: collision with root package name */
    public final boolean f96d = true;

    public final c0.a a() {
        Intent intent = this.f93a;
        if (!intent.hasExtra("android.support.customtabs.extra.SESSION")) {
            Bundle bundle = new Bundle();
            bundle.putBinder("android.support.customtabs.extra.SESSION", null);
            intent.putExtras(bundle);
        }
        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.f96d);
        this.f94b.getClass();
        intent.putExtras(new Bundle());
        intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 0);
        String strA = b.a();
        if (!TextUtils.isEmpty(strA)) {
            Bundle bundleExtra = intent.hasExtra("com.android.browser.headers") ? intent.getBundleExtra("com.android.browser.headers") : new Bundle();
            if (!bundleExtra.containsKey("Accept-Language")) {
                bundleExtra.putString("Accept-Language", strA);
                intent.putExtra("com.android.browser.headers", bundleExtra);
            }
        }
        if (Build.VERSION.SDK_INT >= 34) {
            if (this.f95c == null) {
                this.f95c = a.a();
            }
            c.a(this.f95c, false);
        }
        ActivityOptions activityOptions = this.f95c;
        return new c0.a(1, intent, activityOptions != null ? activityOptions.toBundle() : null);
    }
}
