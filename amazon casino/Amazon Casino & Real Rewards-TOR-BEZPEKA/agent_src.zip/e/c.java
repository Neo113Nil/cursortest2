package e;

import android.app.ActivityOptions;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public abstract class c {
    public static void a(ActivityOptions activityOptions, boolean z2) {
        activityOptions.setShareIdentityEnabled(z2);
    }
}
