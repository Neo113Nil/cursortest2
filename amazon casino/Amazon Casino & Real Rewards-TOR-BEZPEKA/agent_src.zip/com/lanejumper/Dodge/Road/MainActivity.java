package com.lanejumper.Dodge.Road;

import f0.f;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public final class MainActivity extends f {

    /* renamed from: g, reason: collision with root package name */
    public static final /* synthetic */ int f85g = 0;

    /* renamed from: f, reason: collision with root package name */
    public final String f86f = "lane_chassis_stream";
}
