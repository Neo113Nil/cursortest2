package d0;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.lanejumper.Dodge.Road.MainActivity;
import e.d;
import f0.c0;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import o0.k;
import org.json.JSONException;
import org.json.JSONObject;
import p0.c;
import p0.j;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public final /* synthetic */ class b implements j, c {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f91b;

    public /* synthetic */ b(Object obj) {
        this.f91b = obj;
    }

    @Override // p0.j
    public void l(c0.a aVar, k kVar) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        MainActivity mainActivity = (MainActivity) this.f91b;
        int i2 = MainActivity.f85g;
        aVar.getClass();
        if (!((String) aVar.f76c).equals("unfurlMistLane")) {
            kVar.b();
            return;
        }
        mainActivity.getClass();
        try {
            int[] iArr = a.f88a;
            byte[] bArr = new byte[16];
            for (int i3 = 0; i3 < 16; i3++) {
                bArr[i3] = (byte) (iArr[i3] ^ 115);
            }
            int[] iArr2 = a.f89b;
            byte[] bArr2 = new byte[16];
            for (int i4 = 0; i4 < 16; i4++) {
                bArr2[i4] = (byte) (iArr2[i4] ^ 115);
            }
            int[] iArr3 = a.f90c;
            byte[] bArr3 = new byte[32];
            for (int i5 = 0; i5 < 32; i5++) {
                bArr3[i5] = (byte) (iArr3[i5] ^ 115);
            }
            SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr2);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(2, secretKeySpec, ivParameterSpec);
            byte[] bArrDoFinal = cipher.doFinal(bArr3);
            bArrDoFinal.getClass();
            String str = new String(bArrDoFinal, l1.a.f689a);
            c0.a aVarA = new d().a();
            Uri uri = Uri.parse(str);
            Intent intent = (Intent) aVarA.f76c;
            intent.setData(uri);
            mainActivity.startActivity(intent, (Bundle) aVarA.f77d);
        } catch (Exception unused) {
        }
        kVar.d(null);
    }

    @Override // p0.c
    public void p(Object obj) throws JSONException {
        b bVar = (b) this.f91b;
        boolean z2 = false;
        if (obj != null) {
            try {
                z2 = ((JSONObject) obj).getBoolean("handled");
            } catch (JSONException e2) {
                Log.e("KeyEventChannel", "Unable to unpack JSON message: " + e2);
            }
        }
        ((c0) bVar.f91b).a(z2);
    }
}
