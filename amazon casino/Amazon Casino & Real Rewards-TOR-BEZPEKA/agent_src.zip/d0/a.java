package d0;

/* compiled from: r8-map-id-86de9347d150e76d106abe7953094f01341165a1df16a579b83bd893f92fc0e3 */
/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f88a = {43, 80, 59, 242, 128, 190, 49, 148, 161, 31, 45, 41, 204, 94, 133, 77};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f89b = {120, 160, 130, 129, 10, 197, 124, 85, 196, 182, 116, 119, 149, 243, 197, 251};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f90c = {19, 204, 5, 238, 194, 112, 207, 196, 136, 44, 149, 129, 210, 235, 64, 9, 86, 92, 137, 117, 155, 53, 156, 56, 97, 30, 145, 202, 120, 26, 242, 135};
}
