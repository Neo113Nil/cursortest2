package y0;

import E0.i;
import h.Y;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import m0.AbstractC0230j;

/* loaded from: classes.dex */
public abstract class a implements w0.c, d, Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final w0.c f3055e;

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public a(w0.c cVar) {
        this.f3055e = cVar;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public d c() {
        w0.c cVar = this.f3055e;
        if (cVar instanceof d) {
            return (d) cVar;
        }
        return null;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // w0.c
    public final void g(Object obj) {
        w0.c cVar = this;
        while (true) {
            a aVar = (a) cVar;
            w0.c cVar2 = aVar.f3055e;
            i.b(cVar2);
            try {
                obj = aVar.n(obj);
                if (obj == x0.a.f3053e) {
                    return;
                }
            } catch (Throwable th) {
                obj = AbstractC0230j.f(th);
            }
            aVar.o();
            if (!(cVar2 instanceof a)) {
                cVar2.g(obj);
                return;
            }
            cVar = cVar2;
        }
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public w0.c k(Object obj, w0.c cVar) {
        throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public StackTraceElement l() throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        int iIntValue;
        String strC;
        Method method;
        Object objInvoke;
        Method method2;
        Object objInvoke2;
        e eVar = (e) getClass().getAnnotation(e.class);
        String str = null;
        if (eVar == null || eVar.v() < 1) {
            return null;
        }
        try {
            Field declaredField = getClass().getDeclaredField("label");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(this);
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            iIntValue = (num != null ? num.intValue() : 0) - 1;
        } catch (Exception unused) {
            iIntValue = -1;
        }
        int i2 = iIntValue >= 0 ? eVar.l()[iIntValue] : -1;
        Y y2 = f.f3060b;
        Y y3 = f.f3059a;
        if (y2 == null) {
            try {
                Y y4 = new Y(Class.class.getDeclaredMethod("getModule", null), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", null), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", null));
                f.f3060b = y4;
                y2 = y4;
            } catch (Exception unused2) {
                f.f3060b = y3;
                y2 = y3;
            }
        }
        if (y2 != y3 && (method = y2.f2115a) != null && (objInvoke = method.invoke(getClass(), null)) != null && (method2 = y2.f2116b) != null && (objInvoke2 = method2.invoke(objInvoke, null)) != null) {
            Method method3 = y2.f2117c;
            Object objInvoke3 = method3 != null ? method3.invoke(objInvoke2, null) : null;
            if (objInvoke3 instanceof String) {
                str = (String) objInvoke3;
            }
        }
        if (str == null) {
            strC = eVar.c();
        } else {
            strC = str + '/' + eVar.c();
        }
        return new StackTraceElement(strC, eVar.m(), eVar.f(), i2);
    }

    public abstract Object n(Object obj);

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public String toString() throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        StringBuilder sb = new StringBuilder("Continuation at ");
        Object objL = l();
        if (objL == null) {
            objL = getClass().getName();
        }
        sb.append(objL);
        return sb.toString();
    }

    public void o() {
    }
}
