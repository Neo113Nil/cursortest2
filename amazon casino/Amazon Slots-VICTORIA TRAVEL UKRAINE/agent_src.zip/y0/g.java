package y0;

import E0.i;
import E0.q;

/* loaded from: classes.dex */
public abstract class g extends c implements E0.f {

    /* renamed from: h, reason: collision with root package name */
    public final int f3061h;

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public g(int i2, w0.c cVar) {
        super(cVar);
        this.f3061h = i2;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // E0.f
    public final int a() {
        return this.f3061h;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // y0.a
    public final String toString() {
        if (this.f3055e != null) {
            return super.toString();
        }
        q.f301a.getClass();
        String string = getClass().getGenericInterfaces()[0].toString();
        if (string.startsWith("kotlin.jvm.functions.")) {
            string = string.substring(21);
        }
        i.d(string, "renderLambdaToString(...)");
        return string;
    }
}
