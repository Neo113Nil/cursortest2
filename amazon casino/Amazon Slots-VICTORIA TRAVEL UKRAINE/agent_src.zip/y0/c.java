package y0;

import E0.i;
import J0.C0031g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import w0.h;

/* loaded from: classes.dex */
public abstract class c extends a {

    /* renamed from: f, reason: collision with root package name */
    public final h f3057f;

    /* renamed from: g, reason: collision with root package name */
    public transient w0.c f3058g;

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public c(w0.c cVar, h hVar) {
        super(cVar);
        this.f3057f = hVar;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // w0.c
    public h e() {
        h hVar = this.f3057f;
        i.b(hVar);
        return hVar;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // y0.a
    public void o() {
        w0.c cVar = this.f3058g;
        if (cVar != null && cVar != this) {
            w0.f fVarH = e().h(w0.d.f3039e);
            i.b(fVarH);
            O0.f fVar = (O0.f) cVar;
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = O0.f.f839l;
            while (atomicReferenceFieldUpdater.get(fVar) == O0.a.f829c) {
            }
            Object obj = atomicReferenceFieldUpdater.get(fVar);
            C0031g c0031g = obj instanceof C0031g ? (C0031g) obj : null;
            if (c0031g != null) {
                c0031g.q();
            }
        }
        this.f3058g = b.f3056e;
    }

    public c(w0.c cVar) {
        this(cVar, cVar != null ? cVar.e() : null);
    }
}
