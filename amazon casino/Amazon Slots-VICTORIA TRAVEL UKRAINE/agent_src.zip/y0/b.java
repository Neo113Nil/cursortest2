package y0;

import w0.h;

/* loaded from: classes.dex */
public final class b implements w0.c {

    /* renamed from: e, reason: collision with root package name */
    public static final b f3056e = new b();

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // w0.c
    public final h e() {
        throw new IllegalStateException("This continuation is already complete");
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // w0.c
    public final void g(Object obj) {
        throw new IllegalStateException("This continuation is already complete");
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    public final String toString() {
        return "This continuation is already complete";
    }
}
