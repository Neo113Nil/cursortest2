package y0;

import h.Y;

/* loaded from: classes.dex */
public abstract class f {

    /* renamed from: a, reason: collision with root package name */
    public static final Y f3059a = new Y(null, null, null);

    /* renamed from: b, reason: collision with root package name */
    public static Y f3060b;
}
