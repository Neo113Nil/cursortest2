package com.tube.flicker.gas;

import c0.AbstractActivityC0103f;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0103f {
}
