package g0;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public int f2020a;

    /* renamed from: b, reason: collision with root package name */
    public int f2021b;

    /* renamed from: c, reason: collision with root package name */
    public int f2022c;

    /* renamed from: d, reason: collision with root package name */
    public String f2023d;

    /* renamed from: e, reason: collision with root package name */
    public int f2024e;

    /* renamed from: f, reason: collision with root package name */
    public int f2025f;

    /* renamed from: g, reason: collision with root package name */
    public int f2026g;
}
