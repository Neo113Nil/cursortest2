package g0;

import A.j;
import a.AbstractC0068a;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import d0.C0123k;
import java.nio.ByteBuffer;

/* renamed from: g0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0151b extends j {

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ int f2018g;

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0151b(C0123k c0123k, int i2) {
        super(19, c0123k);
        this.f2018g = i2;
    }

    /* JADX DEBUG: Don't trust debug lines info. Lines numbers was adjusted: min line is 1 */
    @Override // A.j
    public final Bitmap y(ByteBuffer byteBuffer, d dVar) {
        switch (this.f2018g) {
            case 0:
                Bitmap bitmapY = super.y(byteBuffer, dVar);
                if (bitmapY != null) {
                    return bitmapY;
                }
                int iRemaining = byteBuffer.remaining();
                byte[] bArr = new byte[iRemaining];
                byteBuffer.get(bArr);
                byteBuffer.rewind();
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, iRemaining, options);
                if (dVar.f2022c == 0) {
                    return AbstractC0068a.c(bitmapDecodeByteArray, dVar.f2024e);
                }
                Matrix matrix = new Matrix();
                matrix.postRotate(dVar.f2022c);
                Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmapDecodeByteArray, 0, 0, bitmapDecodeByteArray.getWidth(), bitmapDecodeByteArray.getHeight(), matrix, true);
                bitmapDecodeByteArray.recycle();
                return AbstractC0068a.c(bitmapCreateBitmap, dVar.f2024e);
            default:
                return AbstractC0068a.c(super.y(byteBuffer, dVar), dVar.f2024e);
        }
    }
}
