package io.flutter.plugins;

import android.util.Log;
import d0.C0115c;
import r0.C0252d;
import s0.J;

/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(C0115c c0115c) {
        try {
            c0115c.f1763d.a(new C0252d());
        } catch (Exception e2) {
            Log.e(TAG, "Error registering plugin path_provider_android, io.flutter.plugins.pathprovider.PathProviderPlugin", e2);
        }
        try {
            c0115c.f1763d.a(new J());
        } catch (Exception e3) {
            Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e3);
        }
    }
}
