package c0;

import L.C0051b;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.util.Log;
import android.view.View;
import android.window.OnBackInvokedCallback;
import d0.C0115c;
import d0.C0117e;
import e0.C0127a;
import h0.C0189e;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import l0.C0203a;
import l0.C0204b;
import l0.C0205c;

/* renamed from: c0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0103f extends Activity implements InterfaceC0106i, androidx.lifecycle.i {

    /* renamed from: i, reason: collision with root package name */
    public static final int f1666i = View.generateViewId();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1667e = false;

    /* renamed from: f, reason: collision with root package name */
    public C0107j f1668f;

    /* renamed from: g, reason: collision with root package name */
    public final androidx.lifecycle.j f1669g;

    /* renamed from: h, reason: collision with root package name */
    public final OnBackInvokedCallback f1670h;

    public AbstractActivityC0103f() {
        int i2 = Build.VERSION.SDK_INT;
        this.f1670h = i2 < 33 ? null : i2 >= 34 ? new C0102e(this) : new OnBackInvokedCallback() { // from class: c0.d
            public final void onBackInvoked() {
                this.f1664a.onBackPressed();
            }
        };
        this.f1669g = new androidx.lifecycle.j(this);
    }

    @Override // androidx.lifecycle.i
    public final androidx.lifecycle.j a() {
        return this.f1669g;
    }

    public final String b() {
        String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int c() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final String d() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final String e() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle bundleG = g();
            String string = bundleG != null ? bundleG.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final String f() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle bundleG = g();
            if (bundleG != null) {
                return bundleG.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final Bundle g() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void h(boolean z2) {
        if (z2 && !this.f1667e) {
            if (Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f1670h);
                this.f1667e = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1667e || Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1670h);
        this.f1667e = false;
    }

    public final boolean i() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (d() != null || this.f1668f.f1681g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean j() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : d() == null;
    }

    public final boolean k(String str) {
        C0107j c0107j = this.f1668f;
        if (c0107j == null) {
            Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0107j.f1684j) {
            return true;
        }
        Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        if (k("onActivityResult")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Objects.toString(intent);
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                c0117e.f1794f.d(i2, i3, intent);
                Trace.endSection();
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (k("onBackPressed")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                c0115c.f1768i.f2655a.B("popRoute", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:188:0x0442  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x04e9  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x04f4  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x054a A[LOOP:0: B:202:0x0544->B:204:0x054a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0560  */
    /* JADX WARN: Removed duplicated region for block: B:215:0x057a  */
    /* JADX WARN: Removed duplicated region for block: B:249:0x062b  */
    /* JADX WARN: Type inference failed for: r10v1, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onCreate(android.os.Bundle r17) throws java.lang.IllegalAccessException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        /*
            Method dump skipped, instructions count: 1602
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c0.AbstractActivityC0103f.onCreate(android.os.Bundle):void");
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (k("onDestroy")) {
            this.f1668f.e();
            this.f1668f.f();
        }
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1670h);
            this.f1667e = false;
        }
        C0107j c0107j = this.f1668f;
        if (c0107j != null) {
            c0107j.f1675a = null;
            c0107j.f1676b = null;
            c0107j.f1677c = null;
            c0107j.f1678d = null;
            c0107j.f1679e = null;
            this.f1668f = null;
        }
        this.f1669g.a(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (k("onNewIntent")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0117e c0117e = c0115c.f1763d;
            if (c0117e.f()) {
                t0.a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    Iterator it = ((HashSet) c0117e.f1794f.f1786d).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            String strD = c0107j.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            C0203a c0203a = c0107j.f1676b.f1768i;
            c0203a.getClass();
            HashMap map = new HashMap();
            map.put("location", strD);
            c0203a.f2655a.B("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (k("onPause")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(3, c0205c.f2659c);
            }
        }
        this.f1669g.a(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (k("onPostResume")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0107j.f1678d;
            if (eVar != null) {
                eVar.b();
            }
            Iterator it = c0107j.f1676b.f1777s.f2445m.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (k("onRequestPermissionsResult")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1676b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Arrays.toString(strArr);
            Arrays.toString(iArr);
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                Iterator it = ((HashSet) c0117e.f1794f.f1784b).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1669g.a(androidx.lifecycle.d.ON_RESUME);
        if (k("onResume")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1676b.f1761b.d();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(2, c0205c.f2659c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (k("onSaveInstanceState")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1675a.j()) {
                bundle.putByteArray("framework", c0107j.f1676b.f1770k.f2699b);
            }
            c0107j.f1675a.getClass();
            Bundle bundle2 = new Bundle();
            C0117e c0117e = c0107j.f1676b.f1763d;
            if (c0117e.f()) {
                t0.a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    Iterator it = ((HashSet) c0117e.f1794f.f1788f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0107j.f1675a.d() == null || c0107j.f1675a.i()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0107j.f1675a.f1667e);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        Bundle bundleG;
        super.onStart();
        this.f1669g.a(androidx.lifecycle.d.ON_START);
        if (k("onStart")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            if (c0107j.f1675a.d() == null && !c0107j.f1676b.f1762c.f1818j) {
                String strF = c0107j.f1675a.f();
                if (strF == null) {
                    AbstractActivityC0103f abstractActivityC0103f = c0107j.f1675a;
                    abstractActivityC0103f.getClass();
                    strF = c0107j.d(abstractActivityC0103f.getIntent());
                    if (strF == null) {
                        strF = "/";
                    }
                }
                AbstractActivityC0103f abstractActivityC0103f2 = c0107j.f1675a;
                abstractActivityC0103f2.getClass();
                try {
                    bundleG = abstractActivityC0103f2.g();
                } catch (PackageManager.NameNotFoundException unused) {
                }
                String string = bundleG != null ? bundleG.getString("io.flutter.EntrypointUri") : null;
                c0107j.f1675a.e();
                c0107j.f1676b.f1768i.f2655a.B("setInitialRoute", strF, null);
                String strB = c0107j.f1675a.b();
                if (strB == null || strB.isEmpty()) {
                    strB = ((C0189e) C0051b.A().f584g).f2305d.f2294b;
                }
                c0107j.f1676b.f1762c.a(string == null ? new C0127a(strB, c0107j.f1675a.e()) : new C0127a(strB, string, c0107j.f1675a.e()), (List) c0107j.f1675a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            Integer num = c0107j.f1685k;
            if (num != null) {
                c0107j.f1677c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (k("onStop")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                c0205c.a(5, c0205c.f2659c);
            }
            c0107j.f1685k = Integer.valueOf(c0107j.f1677c.getVisibility());
            c0107j.f1677c.setVisibility(8);
            C0115c c0115c2 = c0107j.f1676b;
            if (c0115c2 != null) {
                c0115c2.f1761b.b(40);
            }
        }
        this.f1669g.a(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (k("onTrimMemory")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                if (c0107j.f1683i && i2 >= 10) {
                    FlutterJNI flutterJNI = c0115c.f1762c.f1813e;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    C0204b c0204b = c0107j.f1676b.f1776q;
                    c0204b.getClass();
                    HashMap map = new HashMap(1);
                    map.put("type", "memoryPressure");
                    c0204b.f2656a.i(map, null);
                }
                c0107j.f1676b.f1761b.b(i2);
                io.flutter.plugin.platform.k kVar = c0107j.f1676b.f1777s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                Iterator it = kVar.f2445m.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (k("onUserLeaveHint")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0117e c0117e = c0115c.f1763d;
            if (!c0117e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            t0.a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                Iterator it = ((HashSet) c0117e.f1794f.f1787e).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (k("onWindowFocusChanged")) {
            C0107j c0107j = this.f1668f;
            c0107j.c();
            c0107j.f1675a.getClass();
            C0115c c0115c = c0107j.f1676b;
            if (c0115c != null) {
                C0205c c0205c = c0115c.f1766g;
                if (z2) {
                    c0205c.a(c0205c.f2657a, true);
                } else {
                    c0205c.a(c0205c.f2657a, false);
                }
            }
        }
    }
}
