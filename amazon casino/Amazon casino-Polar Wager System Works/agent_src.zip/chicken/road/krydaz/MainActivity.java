package com.chicken.road.krydaz;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.bi1;
import defpackage.bk0;
import defpackage.cc1;
import defpackage.e70;
import defpackage.fi;
import defpackage.k40;
import defpackage.la;
import defpackage.mu;
import defpackage.nu;
import defpackage.ou;
import defpackage.pj;
import defpackage.pu;
import defpackage.qr0;
import defpackage.qu;
import defpackage.ru;
import defpackage.su;
import defpackage.tu;
import defpackage.uu;
import defpackage.yh;
import defpackage.zh;

/* compiled from: r8-map-id-b5d2657f5b0f3e540a3a9843e3f2eeec28d8e847fe8d4f8230331ac70eeacdc4 */
/* loaded from: classes.dex */
public final class MainActivity extends yh {
    @Override // defpackage.yh, defpackage.xh, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bi1 bi1Var = new bi1(0, 0, new cc1(4));
        bi1 bi1Var2 = new bi1(nu.IW7RaZ97Y7To, nu.xOaSj6v4Rdxc, new cc1(4));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        uu tuVar = nu.cxMx144E6FML;
        if (tuVar == null) {
            int i = Build.VERSION.SDK_INT;
            tuVar = i >= 35 ? new tu() : i >= 30 ? new su() : i >= 29 ? new ru() : i >= 28 ? new qu() : i >= 26 ? new pu() : new ou();
            nu.cxMx144E6FML = tuVar;
        }
        uu uuVar = tuVar;
        la laVar = new la(uuVar, bi1Var, bi1Var2, this, decorView, 1);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                mu muVar = new mu(laVar, viewGroup.getContext());
                muVar.setTag(uuVar);
                muVar.setVisibility(8);
                muVar.setWillNotDraw(true);
                viewGroup.addView(muVar);
                break;
            }
            int i3 = i2 + 1;
            View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof uu) {
                break;
            } else {
                i2 = i3;
            }
        }
        laVar.run();
        Window window = getWindow();
        window.getClass();
        uuVar.IW7RaZ97Y7To(window);
        fi fiVar = qr0.Au7MwaVnghPm;
        ViewGroup.LayoutParams layoutParams = zh.IW7RaZ97Y7To;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        pj pjVar = childAt2 instanceof pj ? (pj) childAt2 : null;
        if (pjVar != null) {
            pjVar.setParentCompositionContext(null);
            pjVar.setContent(fiVar);
            return;
        }
        pj pjVar2 = new pj(this);
        pjVar2.setParentCompositionContext(null);
        pjVar2.setContent(fiVar);
        View decorView2 = getWindow().getDecorView();
        if (e70.DrPBaYEkKpzD(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (bk0.VtfmQhiGDumc(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (k40.xdXPfVwSiPTy(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(pjVar2, zh.IW7RaZ97Y7To);
    }
}
