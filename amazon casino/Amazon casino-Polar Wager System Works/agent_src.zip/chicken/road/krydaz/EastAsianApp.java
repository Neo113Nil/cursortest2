package com.chicken.road.krydaz;

import android.app.Application;
import defpackage.Aup7NPoXv3uF;
import defpackage.cc0;
import defpackage.hp;
import defpackage.nIVxjeSkdpvE;

/* compiled from: r8-map-id-b5d2657f5b0f3e540a3a9843e3f2eeec28d8e847fe8d4f8230331ac70eeacdc4 */
/* loaded from: classes.dex */
public class EastAsianApp extends Application {
    public static final /* synthetic */ int EXOtxUGA1xTC = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        Aup7NPoXv3uF aup7NPoXv3uF = new Aup7NPoXv3uF(9, this);
        synchronized (nIVxjeSkdpvE.a8A89tOw0OY4) {
            cc0 cc0Var = new cc0();
            if (nIVxjeSkdpvE.cYqgOELghtLl != null) {
                throw new hp("A Koin Application has already been started");
            }
            nIVxjeSkdpvE.cYqgOELghtLl = cc0Var.IW7RaZ97Y7To;
            aup7NPoXv3uF.eCZbD8y1mBaQ(cc0Var);
            cc0Var.IW7RaZ97Y7To.Au7MwaVnghPm();
        }
    }
}
