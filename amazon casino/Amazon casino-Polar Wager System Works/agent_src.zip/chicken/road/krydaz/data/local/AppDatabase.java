package com.chicken.road.krydaz.data.local;

import defpackage.g61;
import defpackage.o81;
import defpackage.za0;

/* compiled from: r8-map-id-b5d2657f5b0f3e540a3a9843e3f2eeec28d8e847fe8d4f8230331ac70eeacdc4 */
/* loaded from: classes.dex */
public abstract class AppDatabase extends g61 {
    public static volatile AppDatabase Aup7NPoXv3uF;
    public static final o81 d0GDpJJtcWIg = new o81(16);

    public abstract za0 d0GDpJJtcWIg();
}
