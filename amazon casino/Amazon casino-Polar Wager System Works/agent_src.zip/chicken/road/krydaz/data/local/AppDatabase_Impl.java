package com.chicken.road.krydaz.data.local;

import defpackage.ai1;
import defpackage.av;
import defpackage.e4;
import defpackage.t7;
import defpackage.tv;
import defpackage.ua0;
import defpackage.x31;
import defpackage.za0;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-b5d2657f5b0f3e540a3a9843e3f2eeec28d8e847fe8d4f8230331ac70eeacdc4 */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final ai1 xdXPfVwSiPTy = new ai1(new e4(3, this));

    @Override // defpackage.g61
    public final LinkedHashMap Au7MwaVnghPm() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(x31.IW7RaZ97Y7To(za0.class), tv.EXOtxUGA1xTC);
        return linkedHashMap;
    }

    @Override // defpackage.g61
    public final Set EXOtxUGA1xTC() {
        return new LinkedHashSet();
    }

    @Override // defpackage.g61
    public final List IW7RaZ97Y7To(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // defpackage.g61
    public final av cxMx144E6FML() {
        return new t7(this);
    }

    @Override // com.chicken.road.krydaz.data.local.AppDatabase
    public final za0 d0GDpJJtcWIg() {
        return (za0) this.xdXPfVwSiPTy.getValue();
    }

    @Override // defpackage.g61
    public final ua0 xOaSj6v4Rdxc() {
        return new ua0(this, new LinkedHashMap(), new LinkedHashMap(), "items");
    }
}
