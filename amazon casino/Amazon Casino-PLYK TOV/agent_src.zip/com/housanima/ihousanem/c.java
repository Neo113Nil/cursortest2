package com.housanima.ihousanem;

import android.animation.ValueAnimator;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import f2.l;
import j1.q;
import j1.r;
import j1.s;
import p0.s1;
import p0.z;
import r2.y;

/* loaded from: classes.dex */
public final /* synthetic */ class c implements z, l, s, y {

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f1599f;

    public /* synthetic */ c(int i4) {
        this.f1599f = i4;
    }

    @Override // f2.l
    public void a(ValueAnimator valueAnimator, View view) {
        switch (this.f1599f) {
            case 1:
                view.setTranslationX(((Float) valueAnimator.getAnimatedValue()).floatValue());
                break;
            case 2:
                view.setTranslationY(((Float) valueAnimator.getAnimatedValue()).floatValue());
                break;
            case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                Float f4 = (Float) valueAnimator.getAnimatedValue();
                view.setScaleX(f4.floatValue());
                view.setScaleY(f4.floatValue());
                break;
            default:
                view.setAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
                break;
        }
    }

    @Override // j1.s
    public void b(r rVar, q qVar) {
        switch (this.f1599f) {
            case 5:
                rVar.f(qVar);
                break;
            case 6:
                rVar.b(qVar);
                break;
            case 7:
                rVar.a(qVar);
                break;
            case 8:
                rVar.c();
                break;
            default:
                rVar.d();
                break;
        }
    }

    @Override // p0.z
    public s1 onApplyWindowInsets(View view, s1 s1Var) {
        return MainActivity.onCreate$lambda$0(view, s1Var);
    }
}
