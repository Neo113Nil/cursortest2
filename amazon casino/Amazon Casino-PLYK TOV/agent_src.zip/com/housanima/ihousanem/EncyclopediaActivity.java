package com.housanima.ihousanem;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.datepicker.q;
import g3.j;
import java.util.List;
import w2.n;

/* loaded from: classes.dex */
public final class EncyclopediaActivity extends f.f {
    private final List<EncyclopediaEntry> entries = n.b(new EncyclopediaEntry("🌱", "Seed Germination", "The process by which a plant grows from a seed. Seeds need water, oxygen, and proper temperature to germinate successfully."), new EncyclopediaEntry("🌿", "Photosynthesis", "The process plants use to convert light energy into chemical energy. Chlorophyll in leaves absorbs sunlight to produce glucose and oxygen."), new EncyclopediaEntry("💧", "Watering Tips", "Water plants early morning or evening. Check soil moisture before watering. Overwatering can be as harmful as underwatering."), new EncyclopediaEntry("🌸", "Pollination", "Transfer of pollen from male to female parts of flowers. Bees, butterflies, birds, and wind help in pollination."), new EncyclopediaEntry("🍂", "Composting", "Decomposition of organic matter into nutrient-rich soil amendment. Use kitchen scraps, leaves, and grass clippings."), new EncyclopediaEntry("🌞", "Sunlight Requirements", "Full sun: 6+ hours. Partial sun: 3-6 hours. Shade: less than 3 hours. Match plants to light conditions."), new EncyclopediaEntry("🪴", "Container Gardening", "Growing plants in pots. Ensure drainage holes, use quality potting mix, and fertilize regularly as nutrients wash away."), new EncyclopediaEntry("🐛", "Pest Management", "Use companion planting, encourage beneficial insects, handpick pests, or use organic pesticides when necessary."), new EncyclopediaEntry("✂️", "Pruning", "Cutting plants to improve shape, health, and yield. Remove dead/diseased parts, thin crowded areas, and shape growth."), new EncyclopediaEntry("🌾", "Crop Rotation", "Growing different crops in sequence in the same area. Prevents soil depletion and reduces pest/disease problems."), new EncyclopediaEntry("🌡️", "Hardiness Zones", "Geographic areas defined by average minimum winter temperature. Choose plants suited to your zone for best results."), new EncyclopediaEntry("🥕", "Root Vegetables", "Vegetables that grow underground: carrots, beets, radishes. Need loose, deep soil free of rocks for proper development."));

    public final class EncyclopediaAdapter extends RecyclerView.Adapter<ViewHolder> {
        private final List<EncyclopediaEntry> entries;
        final /* synthetic */ EncyclopediaActivity this$0;

        public final class ViewHolder extends RecyclerView.ViewHolder {
            final /* synthetic */ EncyclopediaAdapter this$0;
            private final TextView tvDescription;
            private final TextView tvTitle;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public ViewHolder(EncyclopediaAdapter encyclopediaAdapter, View view) {
                super(view);
                j.e(view, "view");
                this.this$0 = encyclopediaAdapter;
                View viewFindViewById = view.findViewById(R.id.tvEntryTitle);
                j.d(viewFindViewById, "findViewById(...)");
                this.tvTitle = (TextView) viewFindViewById;
                View viewFindViewById2 = view.findViewById(R.id.tvEntryDescription);
                j.d(viewFindViewById2, "findViewById(...)");
                this.tvDescription = (TextView) viewFindViewById2;
            }

            public final TextView getTvDescription() {
                return this.tvDescription;
            }

            public final TextView getTvTitle() {
                return this.tvTitle;
            }
        }

        public EncyclopediaAdapter(EncyclopediaActivity encyclopediaActivity, List<EncyclopediaEntry> list) {
            j.e(list, "entries");
            this.this$0 = encyclopediaActivity;
            this.entries = list;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.entries.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(ViewHolder viewHolder, int i4) {
            j.e(viewHolder, "holder");
            EncyclopediaEntry encyclopediaEntry = this.entries.get(i4);
            viewHolder.getTvTitle().setText(encyclopediaEntry.getEmoji() + " " + encyclopediaEntry.getTitle());
            viewHolder.getTvDescription().setText(encyclopediaEntry.getDescription());
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i4) {
            j.e(viewGroup, "parent");
            View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_encyclopedia, viewGroup, false);
            j.b(viewInflate);
            return new ViewHolder(this, viewInflate);
        }
    }

    public static final class EncyclopediaEntry {
        private final String description;
        private final String emoji;
        private final String title;

        public EncyclopediaEntry(String str, String str2, String str3) {
            j.e(str, "emoji");
            j.e(str2, "title");
            j.e(str3, "description");
            this.emoji = str;
            this.title = str2;
            this.description = str3;
        }

        public static /* synthetic */ EncyclopediaEntry copy$default(EncyclopediaEntry encyclopediaEntry, String str, String str2, String str3, int i4, Object obj) {
            if ((i4 & 1) != 0) {
                str = encyclopediaEntry.emoji;
            }
            if ((i4 & 2) != 0) {
                str2 = encyclopediaEntry.title;
            }
            if ((i4 & 4) != 0) {
                str3 = encyclopediaEntry.description;
            }
            return encyclopediaEntry.copy(str, str2, str3);
        }

        public final String component1() {
            return this.emoji;
        }

        public final String component2() {
            return this.title;
        }

        public final String component3() {
            return this.description;
        }

        public final EncyclopediaEntry copy(String str, String str2, String str3) {
            j.e(str, "emoji");
            j.e(str2, "title");
            j.e(str3, "description");
            return new EncyclopediaEntry(str, str2, str3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof EncyclopediaEntry)) {
                return false;
            }
            EncyclopediaEntry encyclopediaEntry = (EncyclopediaEntry) obj;
            return j.a(this.emoji, encyclopediaEntry.emoji) && j.a(this.title, encyclopediaEntry.title) && j.a(this.description, encyclopediaEntry.description);
        }

        public final String getDescription() {
            return this.description;
        }

        public final String getEmoji() {
            return this.emoji;
        }

        public final String getTitle() {
            return this.title;
        }

        public int hashCode() {
            return this.description.hashCode() + ((this.title.hashCode() + (this.emoji.hashCode() * 31)) * 31);
        }

        public String toString() {
            return "EncyclopediaEntry(emoji=" + this.emoji + ", title=" + this.title + ", description=" + this.description + ")";
        }
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_encyclopedia);
        View viewFindViewById = findViewById(R.id.recyclerViewEncyclopedia);
        j.d(viewFindViewById, "findViewById(...)");
        RecyclerView recyclerView = (RecyclerView) viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.btnBack);
        j.d(viewFindViewById2, "findViewById(...)");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new EncyclopediaAdapter(this, this.entries));
        ((Button) viewFindViewById2).setOnClickListener(new q(1, this));
    }
}
