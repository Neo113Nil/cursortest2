package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import g3.j;

/* loaded from: classes.dex */
public final class HomeHubActivity extends f.f {
    private StorageManager storageManager;
    private TextView tvPoints;

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(HomeHubActivity homeHubActivity, View view) {
        homeHubActivity.startActivity(new Intent(homeHubActivity, (Class<?>) ReactionCheckActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1(HomeHubActivity homeHubActivity, View view) {
        homeHubActivity.startActivity(new Intent(homeHubActivity, (Class<?>) StatsMenuActivity.class));
    }

    private final void updatePointsDisplay() {
        TextView textView = this.tvPoints;
        if (textView == null) {
            j.g("tvPoints");
            throw null;
        }
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        textView.setText("🌟 Points: " + storageManager.getTotalPoints());
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home_hub);
        this.storageManager = new StorageManager(this);
        this.tvPoints = (TextView) findViewById(R.id.tvPoints);
        View viewFindViewById = findViewById(R.id.btnPlayGames);
        j.d(viewFindViewById, "findViewById(...)");
        View viewFindViewById2 = findViewById(R.id.btnQuizStats);
        j.d(viewFindViewById2, "findViewById(...)");
        updatePointsDisplay();
        final int i4 = 0;
        ((Button) viewFindViewById).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.b
            public final /* synthetic */ HomeHubActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i4) {
                    case 0:
                        HomeHubActivity.onCreate$lambda$0(this.g, view);
                        break;
                    default:
                        HomeHubActivity.onCreate$lambda$1(this.g, view);
                        break;
                }
            }
        });
        final int i5 = 1;
        ((Button) viewFindViewById2).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.b
            public final /* synthetic */ HomeHubActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i5) {
                    case 0:
                        HomeHubActivity.onCreate$lambda$0(this.g, view);
                        break;
                    default:
                        HomeHubActivity.onCreate$lambda$1(this.g, view);
                        break;
                }
            }
        });
    }

    @Override // androidx.fragment.app.z, android.app.Activity
    public void onResume() {
        super.onResume();
        updatePointsDisplay();
    }
}
