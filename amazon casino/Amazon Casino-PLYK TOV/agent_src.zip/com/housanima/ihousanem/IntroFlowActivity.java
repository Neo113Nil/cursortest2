package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.datepicker.q;
import g3.j;
import java.util.List;
import w2.n;

/* loaded from: classes.dex */
public final class IntroFlowActivity extends f.f {
    private Button btnNext;
    private final List<OnboardingItem> onboardingItems = n.b(new OnboardingItem("🌱", "Welcome to Hous Anima", "Discover the wonderful world of gardening and grow your knowledge!"), new OnboardingItem("🎮", "Play & Learn", "Test your reaction, play gardening games, and earn points to unlock items!"), new OnboardingItem("📚", "Expand Your Knowledge", "Take quizzes, read encyclopedia, and become a gardening expert!"));
    private StorageManager storageManager;
    private ViewPager2 viewPager;

    public final class OnboardingAdapter extends RecyclerView.Adapter<ViewHolder> {
        private final List<OnboardingItem> items;
        final /* synthetic */ IntroFlowActivity this$0;

        public final class ViewHolder extends RecyclerView.ViewHolder {
            private final TextView description;
            private final TextView emoji;
            final /* synthetic */ OnboardingAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public ViewHolder(OnboardingAdapter onboardingAdapter, View view) {
                super(view);
                j.e(view, "view");
                this.this$0 = onboardingAdapter;
                View viewFindViewById = view.findViewById(R.id.tvEmoji);
                j.d(viewFindViewById, "findViewById(...)");
                this.emoji = (TextView) viewFindViewById;
                View viewFindViewById2 = view.findViewById(R.id.tvTitle);
                j.d(viewFindViewById2, "findViewById(...)");
                this.title = (TextView) viewFindViewById2;
                View viewFindViewById3 = view.findViewById(R.id.tvDescription);
                j.d(viewFindViewById3, "findViewById(...)");
                this.description = (TextView) viewFindViewById3;
            }

            public final TextView getDescription() {
                return this.description;
            }

            public final TextView getEmoji() {
                return this.emoji;
            }

            public final TextView getTitle() {
                return this.title;
            }
        }

        public OnboardingAdapter(IntroFlowActivity introFlowActivity, List<OnboardingItem> list) {
            j.e(list, "items");
            this.this$0 = introFlowActivity;
            this.items = list;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.items.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(ViewHolder viewHolder, int i4) {
            j.e(viewHolder, "holder");
            OnboardingItem onboardingItem = this.items.get(i4);
            viewHolder.getEmoji().setText(onboardingItem.getEmoji());
            viewHolder.getTitle().setText(onboardingItem.getTitle());
            viewHolder.getDescription().setText(onboardingItem.getDescription());
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i4) {
            j.e(viewGroup, "parent");
            View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_onboarding, viewGroup, false);
            j.b(viewInflate);
            return new ViewHolder(this, viewInflate);
        }
    }

    public static final class OnboardingItem {
        private final String description;
        private final String emoji;
        private final String title;

        public OnboardingItem(String str, String str2, String str3) {
            j.e(str, "emoji");
            j.e(str2, "title");
            j.e(str3, "description");
            this.emoji = str;
            this.title = str2;
            this.description = str3;
        }

        public static /* synthetic */ OnboardingItem copy$default(OnboardingItem onboardingItem, String str, String str2, String str3, int i4, Object obj) {
            if ((i4 & 1) != 0) {
                str = onboardingItem.emoji;
            }
            if ((i4 & 2) != 0) {
                str2 = onboardingItem.title;
            }
            if ((i4 & 4) != 0) {
                str3 = onboardingItem.description;
            }
            return onboardingItem.copy(str, str2, str3);
        }

        public final String component1() {
            return this.emoji;
        }

        public final String component2() {
            return this.title;
        }

        public final String component3() {
            return this.description;
        }

        public final OnboardingItem copy(String str, String str2, String str3) {
            j.e(str, "emoji");
            j.e(str2, "title");
            j.e(str3, "description");
            return new OnboardingItem(str, str2, str3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof OnboardingItem)) {
                return false;
            }
            OnboardingItem onboardingItem = (OnboardingItem) obj;
            return j.a(this.emoji, onboardingItem.emoji) && j.a(this.title, onboardingItem.title) && j.a(this.description, onboardingItem.description);
        }

        public final String getDescription() {
            return this.description;
        }

        public final String getEmoji() {
            return this.emoji;
        }

        public final String getTitle() {
            return this.title;
        }

        public int hashCode() {
            return this.description.hashCode() + ((this.title.hashCode() + (this.emoji.hashCode() * 31)) * 31);
        }

        public String toString() {
            return "OnboardingItem(emoji=" + this.emoji + ", title=" + this.title + ", description=" + this.description + ")";
        }
    }

    private final void navigateToHome() {
        startActivity(new Intent(this, (Class<?>) HomeHubActivity.class));
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(IntroFlowActivity introFlowActivity, View view) {
        ViewPager2 viewPager2 = introFlowActivity.viewPager;
        if (viewPager2 == null) {
            j.g("viewPager");
            throw null;
        }
        if (viewPager2.getCurrentItem() != introFlowActivity.onboardingItems.size() - 1) {
            ViewPager2 viewPager22 = introFlowActivity.viewPager;
            if (viewPager22 != null) {
                viewPager22.setCurrentItem(viewPager22.getCurrentItem() + 1);
                return;
            } else {
                j.g("viewPager");
                throw null;
            }
        }
        StorageManager storageManager = introFlowActivity.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager.setHasCompletedOnboarding(true);
        introFlowActivity.navigateToHome();
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_intro_flow);
        StorageManager storageManager = new StorageManager(this);
        this.storageManager = storageManager;
        if (storageManager.getHasCompletedOnboarding()) {
            navigateToHome();
            return;
        }
        this.viewPager = (ViewPager2) findViewById(R.id.viewPagerOnboarding);
        this.btnNext = (Button) findViewById(R.id.btnNext);
        ViewPager2 viewPager2 = this.viewPager;
        if (viewPager2 == null) {
            j.g("viewPager");
            throw null;
        }
        viewPager2.setAdapter(new OnboardingAdapter(this, this.onboardingItems));
        ViewPager2 viewPager22 = this.viewPager;
        if (viewPager22 == null) {
            j.g("viewPager");
            throw null;
        }
        viewPager22.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() { // from class: com.housanima.ihousanem.IntroFlowActivity.onCreate.1
            @Override // androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
            public void onPageSelected(int i4) {
                Button button = IntroFlowActivity.this.btnNext;
                if (button != null) {
                    button.setText(i4 == IntroFlowActivity.this.onboardingItems.size() + (-1) ? "Get Started" : "Next");
                } else {
                    j.g("btnNext");
                    throw null;
                }
            }
        });
        Button button = this.btnNext;
        if (button != null) {
            button.setOnClickListener(new q(2, this));
        } else {
            j.g("btnNext");
            throw null;
        }
    }
}
