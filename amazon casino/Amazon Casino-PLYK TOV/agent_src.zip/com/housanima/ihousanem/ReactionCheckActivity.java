package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.n;
import g3.j;

/* loaded from: classes.dex */
public final class ReactionCheckActivity extends f.f {
    private Button btnNextGame;
    private Button btnTap;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isWaiting;
    private long startTime;
    private StorageManager storageManager;
    private TextView tvInstructions;
    private TextView tvResult;

    private final int calculatePoints(long j4) {
        if (j4 < 200) {
            return 100;
        }
        if (j4 < 300) {
            return 75;
        }
        if (j4 < 400) {
            return 50;
        }
        return j4 < 500 ? 30 : 10;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1(ReactionCheckActivity reactionCheckActivity, View view) {
        if (reactionCheckActivity.isWaiting) {
            TextView textView = reactionCheckActivity.tvInstructions;
            if (textView == null) {
                j.g("tvInstructions");
                throw null;
            }
            textView.setText("⚠️ Too early! Wait for green!");
            reactionCheckActivity.resetGame();
            return;
        }
        Button button = reactionCheckActivity.btnTap;
        if (button == null) {
            j.g("btnTap");
            throw null;
        }
        if (!j.a(button.getText(), "TAP NOW! 🎯")) {
            reactionCheckActivity.startReactionTest();
            return;
        }
        long jCurrentTimeMillis = System.currentTimeMillis() - reactionCheckActivity.startTime;
        int iCalculatePoints = reactionCheckActivity.calculatePoints(jCurrentTimeMillis);
        StorageManager storageManager = reactionCheckActivity.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager.addPoints(iCalculatePoints);
        StorageManager storageManager2 = reactionCheckActivity.storageManager;
        if (storageManager2 == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager2.updateReactionTime(jCurrentTimeMillis);
        TextView textView2 = reactionCheckActivity.tvResult;
        if (textView2 == null) {
            j.g("tvResult");
            throw null;
        }
        textView2.setText("⚡ " + jCurrentTimeMillis + "ms\n🌟 +" + iCalculatePoints + " points!");
        TextView textView3 = reactionCheckActivity.tvResult;
        if (textView3 == null) {
            j.g("tvResult");
            throw null;
        }
        textView3.setVisibility(0);
        Button button2 = reactionCheckActivity.btnNextGame;
        if (button2 == null) {
            j.g("btnNextGame");
            throw null;
        }
        button2.setVisibility(0);
        Button button3 = reactionCheckActivity.btnTap;
        if (button3 == null) {
            j.g("btnTap");
            throw null;
        }
        button3.setVisibility(8);
        TextView textView4 = reactionCheckActivity.tvInstructions;
        if (textView4 != null) {
            textView4.setText("Great job!");
        } else {
            j.g("tvInstructions");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2(ReactionCheckActivity reactionCheckActivity, View view) {
        reactionCheckActivity.startActivity(new Intent(reactionCheckActivity, (Class<?>) GardenPlayActivity.class));
        reactionCheckActivity.finish();
    }

    private final void resetGame() {
        this.handler.removeCallbacksAndMessages(null);
        this.isWaiting = false;
        Button button = this.btnTap;
        if (button == null) {
            j.g("btnTap");
            throw null;
        }
        button.setEnabled(true);
        Button button2 = this.btnTap;
        if (button2 == null) {
            j.g("btnTap");
            throw null;
        }
        button2.setText("Start Test");
        TextView textView = this.tvInstructions;
        if (textView != null) {
            textView.setText("Tap to start the reaction test");
        } else {
            j.g("tvInstructions");
            throw null;
        }
    }

    private final void startReactionTest() {
        this.isWaiting = true;
        Button button = this.btnTap;
        if (button == null) {
            j.g("btnTap");
            throw null;
        }
        button.setEnabled(false);
        Button button2 = this.btnTap;
        if (button2 == null) {
            j.g("btnTap");
            throw null;
        }
        button2.setText("Wait...");
        TextView textView = this.tvInstructions;
        if (textView == null) {
            j.g("tvInstructions");
            throw null;
        }
        textView.setText("⏳ Wait for it...");
        i3.d.f2217f.getClass();
        this.handler.postDelayed(new n(4, this), i3.d.g.e());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startReactionTest$lambda$3(ReactionCheckActivity reactionCheckActivity) {
        reactionCheckActivity.isWaiting = false;
        Button button = reactionCheckActivity.btnTap;
        if (button == null) {
            j.g("btnTap");
            throw null;
        }
        button.setEnabled(true);
        Button button2 = reactionCheckActivity.btnTap;
        if (button2 == null) {
            j.g("btnTap");
            throw null;
        }
        button2.setText("TAP NOW! 🎯");
        TextView textView = reactionCheckActivity.tvInstructions;
        if (textView == null) {
            j.g("tvInstructions");
            throw null;
        }
        textView.setText("🎯 TAP NOW!");
        reactionCheckActivity.startTime = System.currentTimeMillis();
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_reaction_check);
        this.storageManager = new StorageManager(this);
        this.tvInstructions = (TextView) findViewById(R.id.tvInstructions);
        this.btnTap = (Button) findViewById(R.id.btnTap);
        this.tvResult = (TextView) findViewById(R.id.tvResult);
        this.btnNextGame = (Button) findViewById(R.id.btnNextGame);
        View viewFindViewById = findViewById(R.id.btnBack);
        j.d(viewFindViewById, "findViewById(...)");
        final int i4 = 0;
        ((Button) viewFindViewById).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.g
            public final /* synthetic */ ReactionCheckActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i4) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        ReactionCheckActivity.onCreate$lambda$1(this.g, view);
                        break;
                    default:
                        ReactionCheckActivity.onCreate$lambda$2(this.g, view);
                        break;
                }
            }
        });
        Button button = this.btnTap;
        if (button == null) {
            j.g("btnTap");
            throw null;
        }
        final int i5 = 1;
        button.setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.g
            public final /* synthetic */ ReactionCheckActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i5) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        ReactionCheckActivity.onCreate$lambda$1(this.g, view);
                        break;
                    default:
                        ReactionCheckActivity.onCreate$lambda$2(this.g, view);
                        break;
                }
            }
        });
        Button button2 = this.btnNextGame;
        if (button2 == null) {
            j.g("btnNextGame");
            throw null;
        }
        final int i6 = 2;
        button2.setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.g
            public final /* synthetic */ ReactionCheckActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i6) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        ReactionCheckActivity.onCreate$lambda$1(this.g, view);
                        break;
                    default:
                        ReactionCheckActivity.onCreate$lambda$2(this.g, view);
                        break;
                }
            }
        });
    }

    @Override // f.f, androidx.fragment.app.z, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.handler.removeCallbacksAndMessages(null);
    }
}
