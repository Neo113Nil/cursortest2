package com.housanima.ihousanem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import g3.j;
import java.util.List;
import w2.n;

/* loaded from: classes.dex */
public final class QuizGameActivity extends f.f {
    private Button btnSubmit;
    private int currentQuestionIndex;
    private List<QuizQuestion> questions;
    private int quizLevel = 1;
    private RadioGroup radioGroup;
    private RadioButton rbOption1;
    private RadioButton rbOption2;
    private RadioButton rbOption3;
    private RadioButton rbOption4;
    private int score;
    private StorageManager storageManager;
    private TextView tvQuestion;
    private TextView tvQuestionNumber;
    private TextView tvResult;

    public static final class QuizQuestion {
        private final int correctAnswer;
        private final List<String> options;
        private final String question;

        public QuizQuestion(String str, List<String> list, int i4) {
            j.e(str, "question");
            j.e(list, "options");
            this.question = str;
            this.options = list;
            this.correctAnswer = i4;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ QuizQuestion copy$default(QuizQuestion quizQuestion, String str, List list, int i4, int i5, Object obj) {
            if ((i5 & 1) != 0) {
                str = quizQuestion.question;
            }
            if ((i5 & 2) != 0) {
                list = quizQuestion.options;
            }
            if ((i5 & 4) != 0) {
                i4 = quizQuestion.correctAnswer;
            }
            return quizQuestion.copy(str, list, i4);
        }

        public final String component1() {
            return this.question;
        }

        public final List<String> component2() {
            return this.options;
        }

        public final int component3() {
            return this.correctAnswer;
        }

        public final QuizQuestion copy(String str, List<String> list, int i4) {
            j.e(str, "question");
            j.e(list, "options");
            return new QuizQuestion(str, list, i4);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof QuizQuestion)) {
                return false;
            }
            QuizQuestion quizQuestion = (QuizQuestion) obj;
            return j.a(this.question, quizQuestion.question) && j.a(this.options, quizQuestion.options) && this.correctAnswer == quizQuestion.correctAnswer;
        }

        public final int getCorrectAnswer() {
            return this.correctAnswer;
        }

        public final List<String> getOptions() {
            return this.options;
        }

        public final String getQuestion() {
            return this.question;
        }

        public int hashCode() {
            return Integer.hashCode(this.correctAnswer) + ((this.options.hashCode() + (this.question.hashCode() * 31)) * 31);
        }

        public String toString() {
            return "QuizQuestion(question=" + this.question + ", options=" + this.options + ", correctAnswer=" + this.correctAnswer + ")";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void checkAnswer() {
        RadioGroup radioGroup = this.radioGroup;
        if (radioGroup == null) {
            j.g("radioGroup");
            throw null;
        }
        int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
        int i4 = -1;
        if (checkedRadioButtonId == -1) {
            return;
        }
        if (checkedRadioButtonId == R.id.rbOption1) {
            i4 = 0;
        } else if (checkedRadioButtonId == R.id.rbOption2) {
            i4 = 1;
        } else if (checkedRadioButtonId == R.id.rbOption3) {
            i4 = 2;
        } else if (checkedRadioButtonId == R.id.rbOption4) {
            i4 = 3;
        }
        List<QuizQuestion> list = this.questions;
        if (list == null) {
            j.g("questions");
            throw null;
        }
        QuizQuestion quizQuestion = list.get(this.currentQuestionIndex);
        if (i4 == quizQuestion.getCorrectAnswer()) {
            this.score++;
            TextView textView = this.tvResult;
            if (textView == null) {
                j.g("tvResult");
                throw null;
            }
            textView.setText("✅ Correct!");
            TextView textView2 = this.tvResult;
            if (textView2 == null) {
                j.g("tvResult");
                throw null;
            }
            textView2.setTextColor(getColor(android.R.color.holo_green_dark));
        } else {
            TextView textView3 = this.tvResult;
            if (textView3 == null) {
                j.g("tvResult");
                throw null;
            }
            textView3.setText("❌ Wrong! Correct answer: " + ((Object) quizQuestion.getOptions().get(quizQuestion.getCorrectAnswer())));
            TextView textView4 = this.tvResult;
            if (textView4 == null) {
                j.g("tvResult");
                throw null;
            }
            textView4.setTextColor(getColor(android.R.color.holo_red_dark));
        }
        TextView textView5 = this.tvResult;
        if (textView5 == null) {
            j.g("tvResult");
            throw null;
        }
        textView5.setVisibility(0);
        int i5 = this.currentQuestionIndex + 1;
        this.currentQuestionIndex = i5;
        Button button = this.btnSubmit;
        if (button == null) {
            j.g("btnSubmit");
            throw null;
        }
        List<QuizQuestion> list2 = this.questions;
        if (list2 == null) {
            j.g("questions");
            throw null;
        }
        button.setText(i5 < list2.size() ? "Next Question" : "See Results");
        Button button2 = this.btnSubmit;
        if (button2 != null) {
            button2.setOnClickListener(new e(this, 4));
        } else {
            j.g("btnSubmit");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void checkAnswer$lambda$3(QuizGameActivity quizGameActivity, View view) {
        quizGameActivity.displayQuestion();
        Button button = quizGameActivity.btnSubmit;
        if (button != null) {
            button.setOnClickListener(new e(quizGameActivity, 3));
        } else {
            j.g("btnSubmit");
            throw null;
        }
    }

    private final void displayQuestion() {
        int i4 = this.currentQuestionIndex;
        List<QuizQuestion> list = this.questions;
        if (list == null) {
            j.g("questions");
            throw null;
        }
        if (i4 >= list.size()) {
            showFinalScore();
            return;
        }
        List<QuizQuestion> list2 = this.questions;
        if (list2 == null) {
            j.g("questions");
            throw null;
        }
        QuizQuestion quizQuestion = list2.get(this.currentQuestionIndex);
        TextView textView = this.tvQuestionNumber;
        if (textView == null) {
            j.g("tvQuestionNumber");
            throw null;
        }
        textView.setText("Question " + (this.currentQuestionIndex + 1) + "/10");
        TextView textView2 = this.tvQuestion;
        if (textView2 == null) {
            j.g("tvQuestion");
            throw null;
        }
        textView2.setText(quizQuestion.getQuestion());
        RadioButton radioButton = this.rbOption1;
        if (radioButton == null) {
            j.g("rbOption1");
            throw null;
        }
        radioButton.setText(quizQuestion.getOptions().get(0));
        RadioButton radioButton2 = this.rbOption2;
        if (radioButton2 == null) {
            j.g("rbOption2");
            throw null;
        }
        radioButton2.setText(quizQuestion.getOptions().get(1));
        RadioButton radioButton3 = this.rbOption3;
        if (radioButton3 == null) {
            j.g("rbOption3");
            throw null;
        }
        radioButton3.setText(quizQuestion.getOptions().get(2));
        RadioButton radioButton4 = this.rbOption4;
        if (radioButton4 == null) {
            j.g("rbOption4");
            throw null;
        }
        radioButton4.setText(quizQuestion.getOptions().get(3));
        RadioGroup radioGroup = this.radioGroup;
        if (radioGroup == null) {
            j.g("radioGroup");
            throw null;
        }
        radioGroup.clearCheck();
        TextView textView3 = this.tvResult;
        if (textView3 == null) {
            j.g("tvResult");
            throw null;
        }
        textView3.setVisibility(8);
        Button button = this.btnSubmit;
        if (button != null) {
            button.setText("Submit Answer");
        } else {
            j.g("btnSubmit");
            throw null;
        }
    }

    private final List<QuizQuestion> getLevel1Questions() {
        return n.b(new QuizQuestion("What do plants need to grow?", n.b("Water, sunlight, soil", "Only water", "Only sunlight", "Only air"), 0), new QuizQuestion("Which part of the plant absorbs water?", n.b("Leaves", "Roots", "Stem", "Flowers"), 1), new QuizQuestion("What process do plants use to make food?", n.b("Respiration", "Photosynthesis", "Digestion", "Fermentation"), 1), new QuizQuestion("What gives plants their green color?", n.b("Nitrogen", "Chlorophyll", "Water", "Oxygen"), 1), new QuizQuestion("Which season is best for planting tomatoes?", n.b("Winter", "Fall", "Spring", "All seasons"), 2), new QuizQuestion("How often should most plants be watered?", n.b("Once a month", "Every day", "When soil is dry", "Never"), 2), new QuizQuestion("What do flowers attract to help pollination?", n.b("Wind", "Rain", "Bees and butterflies", "Soil"), 2), new QuizQuestion("Which vegetable grows underground?", n.b("Tomato", "Cucumber", "Carrot", "Pumpkin"), 2), new QuizQuestion("What is compost used for?", n.b("Decoration", "Fertilizing soil", "Painting", "Building"), 1), new QuizQuestion("When should you harvest vegetables?", n.b("When they're ripe", "Immediately after planting", "Never", "Only in winter"), 0));
    }

    private final List<QuizQuestion> getLevel2Questions() {
        return n.b(new QuizQuestion("What is the ideal pH level for most garden soil?", n.b("3-4", "6-7", "9-10", "12-13"), 1), new QuizQuestion("Which nutrient is essential for root development?", n.b("Nitrogen", "Phosphorus", "Potassium", "Carbon"), 1), new QuizQuestion("What is crop rotation?", n.b("Spinning plants", "Growing different crops in sequence", "Rotating the garden", "None"), 1), new QuizQuestion("Which pest is common in vegetable gardens?", n.b("Dolphins", "Aphids", "Eagles", "Whales"), 1), new QuizQuestion("What does mulching help with?", n.b("Nothing", "Retaining moisture", "Making noise", "Decoration only"), 1), new QuizQuestion("When is the best time to prune most plants?", n.b("Summer", "Late winter/early spring", "During flowering", "Never"), 1), new QuizQuestion("What is companion planting?", n.b("Planting alone", "Planting compatible plants together", "Planting randomly", "Not planting"), 1), new QuizQuestion("How deep should most seeds be planted?", n.b("1 foot", "2-3 times seed size", "Surface only", "Very deep"), 1), new QuizQuestion("What causes blossom end rot in tomatoes?", n.b("Too much sun", "Calcium deficiency", "Too much water", "Wind"), 1), new QuizQuestion("Which month is ideal to start seedlings indoors?", n.b("December", "Late winter/early spring", "Mid-summer", "November"), 1));
    }

    private final List<QuizQuestion> getLevel3Questions() {
        return n.b(new QuizQuestion("What is hydroponics?", n.b("Growing in water", "Growing in air", "Growing in rocks", "Growing in sand"), 0), new QuizQuestion("What is the term for growing plants without soil?", n.b("Aeroponics", "Geoponics", "Soilponics", "Sandponics"), 0), new QuizQuestion("What is grafting in horticulture?", n.b("Joining two plants", "Cutting plants", "Watering plants", "Removing leaves"), 0), new QuizQuestion("Which hormone promotes fruit ripening?", n.b("Ethylene", "Gibberellin", "Auxin", "Cytokinin"), 0), new QuizQuestion("What is vermiculture?", n.b("Growing worms for compost", "Growing vegetables", "Growing flowers", "Growing trees"), 0), new QuizQuestion("What does NPK stand for in fertilizers?", n.b("Nitrogen, Phosphorus, Potassium", "Natural Plant Killer", "New Plant Kit", "None"), 0), new QuizQuestion("What is a perennial plant?", n.b("Lives more than 2 years", "Lives 1 year", "Lives 1 month", "Dies immediately"), 0), new QuizQuestion("What is the hardiness zone system?", n.b("Climate classification", "Soil type", "Water quality", "Light levels"), 0), new QuizQuestion("What is bolting in plants?", n.b("Premature flowering/seed production", "Fast growth", "Wilting", "Root rot"), 0), new QuizQuestion("What is the purpose of cold stratification?", n.b("Break seed dormancy", "Kill plants", "Freeze soil", "Stop growth"), 0));
    }

    private final void loadQuestions() {
        int i4 = this.quizLevel;
        this.questions = i4 != 1 ? i4 != 2 ? i4 != 3 ? getLevel1Questions() : getLevel3Questions() : getLevel2Questions() : getLevel1Questions();
    }

    private final void showFinalScore() {
        int i4 = this.score * 20;
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager.addPoints(i4);
        int i5 = this.quizLevel;
        if (i5 == 1) {
            StorageManager storageManager2 = this.storageManager;
            if (storageManager2 == null) {
                j.g("storageManager");
                throw null;
            }
            storageManager2.setQuizLevel1Score(Math.max(this.score, storageManager2.getQuizLevel1Score()));
        } else if (i5 == 2) {
            StorageManager storageManager3 = this.storageManager;
            if (storageManager3 == null) {
                j.g("storageManager");
                throw null;
            }
            storageManager3.setQuizLevel2Score(Math.max(this.score, storageManager3.getQuizLevel2Score()));
        } else if (i5 == 3) {
            StorageManager storageManager4 = this.storageManager;
            if (storageManager4 == null) {
                j.g("storageManager");
                throw null;
            }
            storageManager4.setQuizLevel3Score(Math.max(this.score, storageManager4.getQuizLevel3Score()));
        }
        TextView textView = this.tvQuestionNumber;
        if (textView == null) {
            j.g("tvQuestionNumber");
            throw null;
        }
        textView.setText("Quiz Complete! 🎉");
        TextView textView2 = this.tvQuestion;
        if (textView2 == null) {
            j.g("tvQuestion");
            throw null;
        }
        textView2.setText("You scored " + this.score + "/10\nEarned " + i4 + " points!");
        RadioGroup radioGroup = this.radioGroup;
        if (radioGroup == null) {
            j.g("radioGroup");
            throw null;
        }
        radioGroup.setVisibility(8);
        Button button = this.btnSubmit;
        if (button == null) {
            j.g("btnSubmit");
            throw null;
        }
        button.setText("Back to Menu");
        Button button2 = this.btnSubmit;
        if (button2 != null) {
            button2.setOnClickListener(new e(this, 2));
        } else {
            j.g("btnSubmit");
            throw null;
        }
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_quiz_game);
        this.storageManager = new StorageManager(this);
        this.quizLevel = getIntent().getIntExtra("QUIZ_LEVEL", 1);
        this.tvQuestion = (TextView) findViewById(R.id.tvQuestion);
        this.tvQuestionNumber = (TextView) findViewById(R.id.tvQuestionNumber);
        this.radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        this.rbOption1 = (RadioButton) findViewById(R.id.rbOption1);
        this.rbOption2 = (RadioButton) findViewById(R.id.rbOption2);
        this.rbOption3 = (RadioButton) findViewById(R.id.rbOption3);
        this.rbOption4 = (RadioButton) findViewById(R.id.rbOption4);
        this.btnSubmit = (Button) findViewById(R.id.btnSubmit);
        this.tvResult = (TextView) findViewById(R.id.tvResult);
        View viewFindViewById = findViewById(R.id.btnBack);
        j.d(viewFindViewById, "findViewById(...)");
        ((Button) viewFindViewById).setOnClickListener(new e(this, 0));
        loadQuestions();
        displayQuestion();
        Button button = this.btnSubmit;
        if (button != null) {
            button.setOnClickListener(new e(this, 1));
        } else {
            j.g("btnSubmit");
            throw null;
        }
    }
}
