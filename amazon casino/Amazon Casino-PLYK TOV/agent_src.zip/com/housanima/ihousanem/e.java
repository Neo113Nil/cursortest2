package com.housanima.ihousanem;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements View.OnClickListener {

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f1601f;
    public final /* synthetic */ QuizGameActivity g;

    public /* synthetic */ e(QuizGameActivity quizGameActivity, int i4) {
        this.f1601f = i4;
        this.g = quizGameActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f1601f) {
            case 0:
                this.g.finish();
                break;
            case 1:
                this.g.checkAnswer();
                break;
            case 2:
                this.g.finish();
                break;
            case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                this.g.checkAnswer();
                break;
            default:
                QuizGameActivity.checkAnswer$lambda$3(this.g, view);
                break;
        }
    }
}
