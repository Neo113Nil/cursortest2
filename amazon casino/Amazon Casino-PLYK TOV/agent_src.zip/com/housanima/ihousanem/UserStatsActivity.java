package com.housanima.ihousanem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.android.material.datepicker.q;
import g3.j;

/* loaded from: classes.dex */
public final class UserStatsActivity extends f.f {
    private StorageManager storageManager;

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        setContentView(R.layout.activity_user_stats);
        this.storageManager = new StorageManager(this);
        View viewFindViewById = findViewById(R.id.tvTotalPoints);
        j.d(viewFindViewById, "findViewById(...)");
        TextView textView = (TextView) viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.tvGamesPlayed);
        j.d(viewFindViewById2, "findViewById(...)");
        TextView textView2 = (TextView) viewFindViewById2;
        View viewFindViewById3 = findViewById(R.id.tvBestReaction);
        j.d(viewFindViewById3, "findViewById(...)");
        TextView textView3 = (TextView) viewFindViewById3;
        View viewFindViewById4 = findViewById(R.id.tvQuizLevel1);
        j.d(viewFindViewById4, "findViewById(...)");
        TextView textView4 = (TextView) viewFindViewById4;
        View viewFindViewById5 = findViewById(R.id.tvQuizLevel2);
        j.d(viewFindViewById5, "findViewById(...)");
        TextView textView5 = (TextView) viewFindViewById5;
        View viewFindViewById6 = findViewById(R.id.tvQuizLevel3);
        j.d(viewFindViewById6, "findViewById(...)");
        TextView textView6 = (TextView) viewFindViewById6;
        View viewFindViewById7 = findViewById(R.id.btnBack);
        j.d(viewFindViewById7, "findViewById(...)");
        Button button = (Button) viewFindViewById7;
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        textView.setText("🌟 Total Points: " + storageManager.getTotalPoints());
        StorageManager storageManager2 = this.storageManager;
        if (storageManager2 == null) {
            j.g("storageManager");
            throw null;
        }
        textView2.setText("🎮 Games Played: " + storageManager2.getGamesPlayed());
        StorageManager storageManager3 = this.storageManager;
        if (storageManager3 == null) {
            j.g("storageManager");
            throw null;
        }
        if (storageManager3.getBestReactionTime() == Long.MAX_VALUE) {
            str = "Not set";
        } else {
            StorageManager storageManager4 = this.storageManager;
            if (storageManager4 == null) {
                j.g("storageManager");
                throw null;
            }
            str = storageManager4.getBestReactionTime() + "ms";
        }
        textView3.setText("⚡ Best Reaction: " + str);
        StorageManager storageManager5 = this.storageManager;
        if (storageManager5 == null) {
            j.g("storageManager");
            throw null;
        }
        textView4.setText("📚 Level 1 Quiz: " + storageManager5.getQuizLevel1Score() + "/10");
        StorageManager storageManager6 = this.storageManager;
        if (storageManager6 == null) {
            j.g("storageManager");
            throw null;
        }
        textView5.setText("📚 Level 2 Quiz: " + storageManager6.getQuizLevel2Score() + "/10");
        StorageManager storageManager7 = this.storageManager;
        if (storageManager7 == null) {
            j.g("storageManager");
            throw null;
        }
        textView6.setText("📚 Level 3 Quiz: " + storageManager7.getQuizLevel3Score() + "/10");
        button.setOnClickListener(new q(4, this));
    }
}
