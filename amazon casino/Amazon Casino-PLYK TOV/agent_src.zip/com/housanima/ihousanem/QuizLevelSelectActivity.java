package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import g3.j;

/* loaded from: classes.dex */
public final class QuizLevelSelectActivity extends f.f {
    /* JADX INFO: Access modifiers changed from: private */
    public final void startQuiz(int i4) {
        Intent intent = new Intent(this, (Class<?>) QuizGameActivity.class);
        intent.putExtra("QUIZ_LEVEL", i4);
        startActivity(intent);
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_quiz_level_select);
        View viewFindViewById = findViewById(R.id.btnLevel1);
        j.d(viewFindViewById, "findViewById(...)");
        View viewFindViewById2 = findViewById(R.id.btnLevel2);
        j.d(viewFindViewById2, "findViewById(...)");
        View viewFindViewById3 = findViewById(R.id.btnLevel3);
        j.d(viewFindViewById3, "findViewById(...)");
        View viewFindViewById4 = findViewById(R.id.btnBack);
        j.d(viewFindViewById4, "findViewById(...)");
        final int i4 = 0;
        ((Button) viewFindViewById).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.f
            public final /* synthetic */ QuizLevelSelectActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i4) {
                    case 0:
                        this.g.startQuiz(1);
                        break;
                    case 1:
                        this.g.startQuiz(2);
                        break;
                    case 2:
                        this.g.startQuiz(3);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i5 = 1;
        ((Button) viewFindViewById2).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.f
            public final /* synthetic */ QuizLevelSelectActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i5) {
                    case 0:
                        this.g.startQuiz(1);
                        break;
                    case 1:
                        this.g.startQuiz(2);
                        break;
                    case 2:
                        this.g.startQuiz(3);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i6 = 2;
        ((Button) viewFindViewById3).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.f
            public final /* synthetic */ QuizLevelSelectActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i6) {
                    case 0:
                        this.g.startQuiz(1);
                        break;
                    case 1:
                        this.g.startQuiz(2);
                        break;
                    case 2:
                        this.g.startQuiz(3);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i7 = 3;
        ((Button) viewFindViewById4).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.f
            public final /* synthetic */ QuizLevelSelectActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i7) {
                    case 0:
                        this.g.startQuiz(1);
                        break;
                    case 1:
                        this.g.startQuiz(2);
                        break;
                    case 2:
                        this.g.startQuiz(3);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
    }
}
