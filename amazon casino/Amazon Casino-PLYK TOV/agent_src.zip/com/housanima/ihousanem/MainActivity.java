package com.housanima.ihousanem;

import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.activity.a0;
import androidx.activity.m0;
import androidx.activity.n0;
import androidx.activity.s;
import androidx.activity.t;
import androidx.activity.u;
import androidx.activity.w;
import androidx.activity.y;
import androidx.activity.z;
import g3.j;
import java.util.WeakHashMap;
import p0.r0;
import p0.s1;
import p0.z0;

/* loaded from: classes.dex */
public final class MainActivity extends f.f {
    /* JADX INFO: Access modifiers changed from: private */
    public static final s1 onCreate$lambda$0(View view, s1 s1Var) {
        h0.c cVarG = s1Var.f3359a.g(519);
        view.setPadding(cVarG.f2092a, cVarG.f2093b, cVarG.f2094c, cVarG.f2095d);
        return s1Var;
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i4 = s.f155a;
        n0.a aVar = n0.f144e;
        m0 m0Var = new m0();
        aVar.getClass();
        n0 n0Var = new n0(0, 0, 0, m0Var, null);
        n0 n0Var2 = new n0(s.f155a, s.f156b, 0, new m0(), null);
        View decorView = getWindow().getDecorView();
        j.d(decorView, "getDecorView(...)");
        Resources resources = decorView.getResources();
        j.d(resources, "getResources(...)");
        boolean zBooleanValue = ((Boolean) n0Var.f148d.e(resources)).booleanValue();
        Resources resources2 = decorView.getResources();
        j.d(resources2, "getResources(...)");
        boolean zBooleanValue2 = ((Boolean) n0Var2.f148d.e(resources2)).booleanValue();
        int i5 = Build.VERSION.SDK_INT;
        a0 zVar = i5 >= 30 ? new z() : i5 >= 29 ? new y() : i5 >= 28 ? new w() : i5 >= 26 ? new u() : new t();
        Window window = getWindow();
        j.d(window, "getWindow(...)");
        zVar.b(n0Var, n0Var2, window, decorView, zBooleanValue, zBooleanValue2);
        Window window2 = getWindow();
        j.d(window2, "getWindow(...)");
        zVar.a(window2);
        setContentView(R.layout.activity_main);
        View viewFindViewById = findViewById(R.id.main);
        c cVar = new c(0);
        WeakHashMap weakHashMap = z0.f3380a;
        r0.l(viewFindViewById, cVar);
    }
}
