package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import g3.j;
import i3.d;
import java.util.List;
import w2.n;

/* loaded from: classes.dex */
public final class GardenPlayActivity extends f.f {
    private Button btnContinue;
    private Button btnHarvest;
    private Button btnWater;
    private int currentPlantType;
    private ImageView imgPlant;
    private ProgressBar progressWater;
    private int score;
    private StorageManager storageManager;
    private TextView tvGameResult;
    private TextView tvScore;
    private TextView tvTimer;
    private int waterLevel;
    private int timeLeft = 30;
    private boolean isGameActive = true;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Integer> plantImages = n.b(Integer.valueOf(R.drawable.plant_tomato), Integer.valueOf(R.drawable.plant_carrot), Integer.valueOf(R.drawable.plant_sunflower));

    /* JADX INFO: Access modifiers changed from: private */
    public final void endGame() {
        this.isGameActive = false;
        int i4 = this.score;
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager.addPoints(i4);
        StorageManager storageManager2 = this.storageManager;
        if (storageManager2 == null) {
            j.g("storageManager");
            throw null;
        }
        storageManager2.incrementGamesPlayed();
        Button button = this.btnWater;
        if (button == null) {
            j.g("btnWater");
            throw null;
        }
        button.setVisibility(8);
        Button button2 = this.btnHarvest;
        if (button2 == null) {
            j.g("btnHarvest");
            throw null;
        }
        button2.setVisibility(8);
        TextView textView = this.tvGameResult;
        if (textView == null) {
            j.g("tvGameResult");
            throw null;
        }
        textView.setText("Game Over! 🎉\nYou earned " + i4 + " points!");
        TextView textView2 = this.tvGameResult;
        if (textView2 == null) {
            j.g("tvGameResult");
            throw null;
        }
        textView2.setVisibility(0);
        Button button3 = this.btnContinue;
        if (button3 != null) {
            button3.setVisibility(0);
        } else {
            j.g("btnContinue");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1(GardenPlayActivity gardenPlayActivity, View view) {
        int i4;
        if (!gardenPlayActivity.isGameActive || (i4 = gardenPlayActivity.waterLevel) >= 100) {
            return;
        }
        int i5 = i4 + 25;
        gardenPlayActivity.waterLevel = i5;
        ProgressBar progressBar = gardenPlayActivity.progressWater;
        if (progressBar == null) {
            j.g("progressWater");
            throw null;
        }
        progressBar.setProgress(i5);
        if (gardenPlayActivity.waterLevel == 100) {
            Button button = gardenPlayActivity.btnHarvest;
            if (button == null) {
                j.g("btnHarvest");
                throw null;
            }
            button.setEnabled(true);
            Button button2 = gardenPlayActivity.btnHarvest;
            if (button2 != null) {
                button2.setAlpha(1.0f);
            } else {
                j.g("btnHarvest");
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2(GardenPlayActivity gardenPlayActivity, View view) {
        if (gardenPlayActivity.isGameActive && gardenPlayActivity.waterLevel == 100) {
            int i4 = gardenPlayActivity.score;
            i3.d.f2217f.getClass();
            int iC = i3.d.g.c(50) + i4;
            gardenPlayActivity.score = iC;
            TextView textView = gardenPlayActivity.tvScore;
            if (textView == null) {
                j.g("tvScore");
                throw null;
            }
            textView.setText("🌱 Score: " + iC);
            gardenPlayActivity.spawnNewPlant();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$3(GardenPlayActivity gardenPlayActivity, View view) {
        gardenPlayActivity.startActivity(new Intent(gardenPlayActivity, (Class<?>) MarketPlaceActivity.class));
        gardenPlayActivity.finish();
    }

    private final void spawnNewPlant() {
        d.a aVar = i3.d.f2217f;
        int size = this.plantImages.size();
        aVar.getClass();
        int iNextInt = i3.d.g.f().nextInt(size);
        this.currentPlantType = iNextInt;
        ImageView imageView = this.imgPlant;
        if (imageView == null) {
            j.g("imgPlant");
            throw null;
        }
        imageView.setImageResource(this.plantImages.get(iNextInt).intValue());
        this.waterLevel = 0;
        ProgressBar progressBar = this.progressWater;
        if (progressBar == null) {
            j.g("progressWater");
            throw null;
        }
        progressBar.setProgress(0);
        Button button = this.btnHarvest;
        if (button == null) {
            j.g("btnHarvest");
            throw null;
        }
        button.setEnabled(false);
        Button button2 = this.btnHarvest;
        if (button2 != null) {
            button2.setAlpha(0.5f);
        } else {
            j.g("btnHarvest");
            throw null;
        }
    }

    private final void startTimer() {
        this.handler.post(new Runnable() { // from class: com.housanima.ihousanem.GardenPlayActivity.startTimer.1
            @Override // java.lang.Runnable
            public void run() {
                if (GardenPlayActivity.this.timeLeft <= 0 || !GardenPlayActivity.this.isGameActive) {
                    if (GardenPlayActivity.this.timeLeft == 0) {
                        GardenPlayActivity.this.endGame();
                        return;
                    }
                    return;
                }
                TextView textView = GardenPlayActivity.this.tvTimer;
                if (textView == null) {
                    j.g("tvTimer");
                    throw null;
                }
                textView.setText("⏱️ " + GardenPlayActivity.this.timeLeft + " s");
                GardenPlayActivity.this.timeLeft = GardenPlayActivity.this.timeLeft + (-1);
                GardenPlayActivity.this.handler.postDelayed(this, 1000L);
            }
        });
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_garden_play);
        this.storageManager = new StorageManager(this);
        this.tvScore = (TextView) findViewById(R.id.tvScore);
        this.tvTimer = (TextView) findViewById(R.id.tvTimer);
        this.progressWater = (ProgressBar) findViewById(R.id.progressWater);
        this.imgPlant = (ImageView) findViewById(R.id.imgPlant);
        this.btnWater = (Button) findViewById(R.id.btnWater);
        this.btnHarvest = (Button) findViewById(R.id.btnHarvest);
        this.tvGameResult = (TextView) findViewById(R.id.tvGameResult);
        this.btnContinue = (Button) findViewById(R.id.btnContinue);
        View viewFindViewById = findViewById(R.id.btnBack);
        j.d(viewFindViewById, "findViewById(...)");
        final int i4 = 0;
        ((Button) viewFindViewById).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.a
            public final /* synthetic */ GardenPlayActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i4) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        GardenPlayActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        GardenPlayActivity.onCreate$lambda$2(this.g, view);
                        break;
                    default:
                        GardenPlayActivity.onCreate$lambda$3(this.g, view);
                        break;
                }
            }
        });
        spawnNewPlant();
        startTimer();
        Button button = this.btnWater;
        if (button == null) {
            j.g("btnWater");
            throw null;
        }
        final int i5 = 1;
        button.setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.a
            public final /* synthetic */ GardenPlayActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i5) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        GardenPlayActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        GardenPlayActivity.onCreate$lambda$2(this.g, view);
                        break;
                    default:
                        GardenPlayActivity.onCreate$lambda$3(this.g, view);
                        break;
                }
            }
        });
        Button button2 = this.btnHarvest;
        if (button2 == null) {
            j.g("btnHarvest");
            throw null;
        }
        final int i6 = 2;
        button2.setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.a
            public final /* synthetic */ GardenPlayActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i6) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        GardenPlayActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        GardenPlayActivity.onCreate$lambda$2(this.g, view);
                        break;
                    default:
                        GardenPlayActivity.onCreate$lambda$3(this.g, view);
                        break;
                }
            }
        });
        Button button3 = this.btnContinue;
        if (button3 == null) {
            j.g("btnContinue");
            throw null;
        }
        final int i7 = 3;
        button3.setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.a
            public final /* synthetic */ GardenPlayActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i7) {
                    case 0:
                        this.g.finish();
                        break;
                    case 1:
                        GardenPlayActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        GardenPlayActivity.onCreate$lambda$2(this.g, view);
                        break;
                    default:
                        GardenPlayActivity.onCreate$lambda$3(this.g, view);
                        break;
                }
            }
        });
    }

    @Override // f.f, androidx.fragment.app.z, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.handler.removeCallbacksAndMessages(null);
    }
}
