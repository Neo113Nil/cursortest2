package com.housanima.ihousanem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.recyclerview.widget.RecyclerView;
import g3.j;

/* loaded from: classes.dex */
public final class StatsMenuActivity extends f.f {
    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(StatsMenuActivity statsMenuActivity, View view) {
        statsMenuActivity.startActivity(new Intent(statsMenuActivity, (Class<?>) UserStatsActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1(StatsMenuActivity statsMenuActivity, View view) {
        statsMenuActivity.startActivity(new Intent(statsMenuActivity, (Class<?>) QuizLevelSelectActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2(StatsMenuActivity statsMenuActivity, View view) {
        statsMenuActivity.startActivity(new Intent(statsMenuActivity, (Class<?>) MarketPlaceActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$3(StatsMenuActivity statsMenuActivity, View view) {
        statsMenuActivity.startActivity(new Intent(statsMenuActivity, (Class<?>) EncyclopediaActivity.class));
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_stats_menu);
        View viewFindViewById = findViewById(R.id.btnViewStats);
        j.d(viewFindViewById, "findViewById(...)");
        View viewFindViewById2 = findViewById(R.id.btnTakeQuiz);
        j.d(viewFindViewById2, "findViewById(...)");
        View viewFindViewById3 = findViewById(R.id.btnShop);
        j.d(viewFindViewById3, "findViewById(...)");
        View viewFindViewById4 = findViewById(R.id.btnEncyclopedia);
        j.d(viewFindViewById4, "findViewById(...)");
        View viewFindViewById5 = findViewById(R.id.btnBack);
        j.d(viewFindViewById5, "findViewById(...)");
        final int i4 = 0;
        ((Button) viewFindViewById).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.h
            public final /* synthetic */ StatsMenuActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i4) {
                    case 0:
                        StatsMenuActivity.onCreate$lambda$0(this.g, view);
                        break;
                    case 1:
                        StatsMenuActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        StatsMenuActivity.onCreate$lambda$2(this.g, view);
                        break;
                    case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                        StatsMenuActivity.onCreate$lambda$3(this.g, view);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i5 = 1;
        ((Button) viewFindViewById2).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.h
            public final /* synthetic */ StatsMenuActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i5) {
                    case 0:
                        StatsMenuActivity.onCreate$lambda$0(this.g, view);
                        break;
                    case 1:
                        StatsMenuActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        StatsMenuActivity.onCreate$lambda$2(this.g, view);
                        break;
                    case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                        StatsMenuActivity.onCreate$lambda$3(this.g, view);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i6 = 2;
        ((Button) viewFindViewById3).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.h
            public final /* synthetic */ StatsMenuActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i6) {
                    case 0:
                        StatsMenuActivity.onCreate$lambda$0(this.g, view);
                        break;
                    case 1:
                        StatsMenuActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        StatsMenuActivity.onCreate$lambda$2(this.g, view);
                        break;
                    case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                        StatsMenuActivity.onCreate$lambda$3(this.g, view);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i7 = 3;
        ((Button) viewFindViewById4).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.h
            public final /* synthetic */ StatsMenuActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i7) {
                    case 0:
                        StatsMenuActivity.onCreate$lambda$0(this.g, view);
                        break;
                    case 1:
                        StatsMenuActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        StatsMenuActivity.onCreate$lambda$2(this.g, view);
                        break;
                    case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                        StatsMenuActivity.onCreate$lambda$3(this.g, view);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
        final int i8 = 4;
        ((Button) viewFindViewById5).setOnClickListener(new View.OnClickListener(this) { // from class: com.housanima.ihousanem.h
            public final /* synthetic */ StatsMenuActivity g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i8) {
                    case 0:
                        StatsMenuActivity.onCreate$lambda$0(this.g, view);
                        break;
                    case 1:
                        StatsMenuActivity.onCreate$lambda$1(this.g, view);
                        break;
                    case 2:
                        StatsMenuActivity.onCreate$lambda$2(this.g, view);
                        break;
                    case RecyclerView.EdgeEffectFactory.DIRECTION_BOTTOM /* 3 */:
                        StatsMenuActivity.onCreate$lambda$3(this.g, view);
                        break;
                    default:
                        this.g.finish();
                        break;
                }
            }
        });
    }
}
