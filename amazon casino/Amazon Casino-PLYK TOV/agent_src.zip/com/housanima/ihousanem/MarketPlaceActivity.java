package com.housanima.ihousanem;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.f0;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.datepicker.q;
import com.housanima.ihousanem.MarketPlaceActivity;
import f3.l;
import g3.j;
import java.util.List;
import w2.n;

/* loaded from: classes.dex */
public final class MarketPlaceActivity extends f.f {
    private RecyclerView recyclerView;
    private final List<ShopItem> shopItems = n.b(new ShopItem("Watering Can", "💧", 100, R.drawable.item_watercan), new ShopItem("Garden Shovel", "🔨", 150, R.drawable.item_shovel), new ShopItem("Tomato Seeds", "🍅", 50, R.drawable.plant_tomato), new ShopItem("Carrot Seeds", "🥕", 50, R.drawable.plant_carrot), new ShopItem("Sunflower Seeds", "🌻", 75, R.drawable.plant_sunflower), new ShopItem("Fertilizer", "🧪", 120, R.drawable.item_watercan), new ShopItem("Garden Gloves", "🧤", 80, R.drawable.item_shovel), new ShopItem("Plant Pot", "🪴", 90, R.drawable.plant_sunflower));
    private StorageManager storageManager;
    private TextView tvPoints;

    public final class ShopAdapter extends RecyclerView.Adapter<ViewHolder> {
        private final List<ShopItem> items;
        private final l onItemClick;
        final /* synthetic */ MarketPlaceActivity this$0;

        public final class ViewHolder extends RecyclerView.ViewHolder {
            private final Button btnBuy;
            private final ImageView imgItem;
            final /* synthetic */ ShopAdapter this$0;
            private final TextView tvItemName;
            private final TextView tvItemPrice;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public ViewHolder(ShopAdapter shopAdapter, View view) {
                super(view);
                j.e(view, "view");
                this.this$0 = shopAdapter;
                View viewFindViewById = view.findViewById(R.id.imgItem);
                j.d(viewFindViewById, "findViewById(...)");
                this.imgItem = (ImageView) viewFindViewById;
                View viewFindViewById2 = view.findViewById(R.id.tvItemName);
                j.d(viewFindViewById2, "findViewById(...)");
                this.tvItemName = (TextView) viewFindViewById2;
                View viewFindViewById3 = view.findViewById(R.id.tvItemPrice);
                j.d(viewFindViewById3, "findViewById(...)");
                this.tvItemPrice = (TextView) viewFindViewById3;
                View viewFindViewById4 = view.findViewById(R.id.btnBuy);
                j.d(viewFindViewById4, "findViewById(...)");
                this.btnBuy = (Button) viewFindViewById4;
            }

            public final Button getBtnBuy() {
                return this.btnBuy;
            }

            public final ImageView getImgItem() {
                return this.imgItem;
            }

            public final TextView getTvItemName() {
                return this.tvItemName;
            }

            public final TextView getTvItemPrice() {
                return this.tvItemPrice;
            }
        }

        public ShopAdapter(MarketPlaceActivity marketPlaceActivity, List<ShopItem> list, l lVar) {
            j.e(list, "items");
            j.e(lVar, "onItemClick");
            this.this$0 = marketPlaceActivity;
            this.items = list;
            this.onItemClick = lVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onBindViewHolder$lambda$0(ShopAdapter shopAdapter, ShopItem shopItem, View view) {
            shopAdapter.onItemClick.e(shopItem);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.items.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(ViewHolder viewHolder, int i4) {
            j.e(viewHolder, "holder");
            final ShopItem shopItem = this.items.get(i4);
            viewHolder.getImgItem().setImageResource(shopItem.getImageRes());
            viewHolder.getTvItemName().setText(shopItem.getEmoji() + " " + shopItem.getName());
            viewHolder.getTvItemPrice().setText("🌟 " + shopItem.getPrice());
            viewHolder.getBtnBuy().setOnClickListener(new View.OnClickListener() { // from class: com.housanima.ihousanem.d
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    MarketPlaceActivity.ShopAdapter.onBindViewHolder$lambda$0(this.f1600f, shopItem, view);
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i4) {
            j.e(viewGroup, "parent");
            View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_shop, viewGroup, false);
            j.b(viewInflate);
            return new ViewHolder(this, viewInflate);
        }
    }

    public static final class ShopItem {
        private final String emoji;
        private final int imageRes;
        private final String name;
        private final int price;

        public ShopItem(String str, String str2, int i4, int i5) {
            j.e(str, "name");
            j.e(str2, "emoji");
            this.name = str;
            this.emoji = str2;
            this.price = i4;
            this.imageRes = i5;
        }

        public static /* synthetic */ ShopItem copy$default(ShopItem shopItem, String str, String str2, int i4, int i5, int i6, Object obj) {
            if ((i6 & 1) != 0) {
                str = shopItem.name;
            }
            if ((i6 & 2) != 0) {
                str2 = shopItem.emoji;
            }
            if ((i6 & 4) != 0) {
                i4 = shopItem.price;
            }
            if ((i6 & 8) != 0) {
                i5 = shopItem.imageRes;
            }
            return shopItem.copy(str, str2, i4, i5);
        }

        public final String component1() {
            return this.name;
        }

        public final String component2() {
            return this.emoji;
        }

        public final int component3() {
            return this.price;
        }

        public final int component4() {
            return this.imageRes;
        }

        public final ShopItem copy(String str, String str2, int i4, int i5) {
            j.e(str, "name");
            j.e(str2, "emoji");
            return new ShopItem(str, str2, i4, i5);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof ShopItem)) {
                return false;
            }
            ShopItem shopItem = (ShopItem) obj;
            return j.a(this.name, shopItem.name) && j.a(this.emoji, shopItem.emoji) && this.price == shopItem.price && this.imageRes == shopItem.imageRes;
        }

        public final String getEmoji() {
            return this.emoji;
        }

        public final int getImageRes() {
            return this.imageRes;
        }

        public final String getName() {
            return this.name;
        }

        public final int getPrice() {
            return this.price;
        }

        public int hashCode() {
            return Integer.hashCode(this.imageRes) + ((Integer.hashCode(this.price) + ((this.emoji.hashCode() + (this.name.hashCode() * 31)) * 31)) * 31);
        }

        public String toString() {
            return "ShopItem(name=" + this.name + ", emoji=" + this.emoji + ", price=" + this.price + ", imageRes=" + this.imageRes + ")";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final v2.j onCreate$lambda$0(MarketPlaceActivity marketPlaceActivity, ShopItem shopItem) {
        j.e(shopItem, "item");
        marketPlaceActivity.purchaseItem(shopItem);
        return v2.j.f3914a;
    }

    private final void purchaseItem(ShopItem shopItem) {
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        if (!storageManager.spendPoints(shopItem.getPrice())) {
            Toast.makeText(this, "❌ Not enough points!", 0).show();
            return;
        }
        Toast.makeText(this, "✅ Purchased " + shopItem.getName() + "!", 0).show();
        updatePointsDisplay();
    }

    private final void updatePointsDisplay() {
        TextView textView = this.tvPoints;
        if (textView == null) {
            j.g("tvPoints");
            throw null;
        }
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            j.g("storageManager");
            throw null;
        }
        textView.setText("🌟 Your Points: " + storageManager.getTotalPoints());
    }

    @Override // androidx.fragment.app.z, androidx.activity.ComponentActivity, e0.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_market_place);
        this.storageManager = new StorageManager(this);
        this.tvPoints = (TextView) findViewById(R.id.tvPoints);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerViewShop);
        View viewFindViewById = findViewById(R.id.btnBack);
        j.d(viewFindViewById, "findViewById(...)");
        Button button = (Button) viewFindViewById;
        updatePointsDisplay();
        RecyclerView recyclerView = this.recyclerView;
        if (recyclerView == null) {
            j.g("recyclerView");
            throw null;
        }
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        RecyclerView recyclerView2 = this.recyclerView;
        if (recyclerView2 == null) {
            j.g("recyclerView");
            throw null;
        }
        recyclerView2.setAdapter(new ShopAdapter(this, this.shopItems, new f0(2, this)));
        button.setOnClickListener(new q(3, this));
    }
}
