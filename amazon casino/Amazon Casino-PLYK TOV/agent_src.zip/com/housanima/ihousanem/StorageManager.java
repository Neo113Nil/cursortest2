package com.housanima.ihousanem;

import android.content.Context;
import android.content.SharedPreferences;
import g3.j;

/* loaded from: classes.dex */
public final class StorageManager {
    private final SharedPreferences prefs;

    public StorageManager(Context context) {
        j.e(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("hous_anima_data", 0);
        j.d(sharedPreferences, "getSharedPreferences(...)");
        this.prefs = sharedPreferences;
    }

    public final void addPoints(int i4) {
        setTotalPoints(getTotalPoints() + i4);
    }

    public final long getBestReactionTime() {
        return this.prefs.getLong("best_reaction", Long.MAX_VALUE);
    }

    public final int getGamesPlayed() {
        return this.prefs.getInt("games_played", 0);
    }

    public final boolean getHasCompletedOnboarding() {
        return this.prefs.getBoolean("onboarding_done", false);
    }

    public final int getQuizLevel1Score() {
        return this.prefs.getInt("quiz_level1", 0);
    }

    public final int getQuizLevel2Score() {
        return this.prefs.getInt("quiz_level2", 0);
    }

    public final int getQuizLevel3Score() {
        return this.prefs.getInt("quiz_level3", 0);
    }

    public final int getTotalPoints() {
        return this.prefs.getInt("total_points", 0);
    }

    public final void incrementGamesPlayed() {
        setGamesPlayed(getGamesPlayed() + 1);
    }

    public final void setBestReactionTime(long j4) {
        this.prefs.edit().putLong("best_reaction", j4).apply();
    }

    public final void setGamesPlayed(int i4) {
        this.prefs.edit().putInt("games_played", i4).apply();
    }

    public final void setHasCompletedOnboarding(boolean z3) {
        this.prefs.edit().putBoolean("onboarding_done", z3).apply();
    }

    public final void setQuizLevel1Score(int i4) {
        this.prefs.edit().putInt("quiz_level1", i4).apply();
    }

    public final void setQuizLevel2Score(int i4) {
        this.prefs.edit().putInt("quiz_level2", i4).apply();
    }

    public final void setQuizLevel3Score(int i4) {
        this.prefs.edit().putInt("quiz_level3", i4).apply();
    }

    public final void setTotalPoints(int i4) {
        this.prefs.edit().putInt("total_points", i4).apply();
    }

    public final boolean spendPoints(int i4) {
        if (getTotalPoints() < i4) {
            return false;
        }
        setTotalPoints(getTotalPoints() - i4);
        return true;
    }

    public final void updateReactionTime(long j4) {
        if (j4 < getBestReactionTime()) {
            setBestReactionTime(j4);
        }
    }
}
