package com.kartiop.locak.hagyvagew;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.b60;
import defpackage.bz1;
import defpackage.d5;
import defpackage.ef0;
import defpackage.ey;
import defpackage.hZbg8h9BTLnn;
import defpackage.hn0;
import defpackage.hy1;
import defpackage.in0;
import defpackage.io0;
import defpackage.l72;
import defpackage.lw;
import defpackage.m4;
import defpackage.ms0;
import defpackage.mw;
import defpackage.o20;
import defpackage.p00;
import defpackage.q80;
import defpackage.r80;
import defpackage.r8N2pcVj;
import defpackage.s80;
import defpackage.t20;
import defpackage.t80;
import defpackage.u80;
import defpackage.uy;
import defpackage.v80;
import defpackage.w80;
import defpackage.x80;
import defpackage.y80;
import defpackage.yx;
import defpackage.zx;
import java.util.ArrayList;
import java.util.HashMap;

/* compiled from: r8-map-id-c9ae2a18c816deaaafd4b1b20a02f1a64f2232efc91e19ba4af4474de778ecb0 */
/* loaded from: classes.dex */
public final class MainActivity extends yx {
    public static final /* synthetic */ int RLhVphrXI4t = 0;

    @Override // defpackage.yx, defpackage.xx, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = 13;
        l72 l72Var = new l72(new hy1(i));
        l72 l72Var2 = new l72(new hy1(i));
        y80 y80Var = r80.DtvLLDnp;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        y80 x80Var = r80.DtvLLDnp;
        if (x80Var == null) {
            int i2 = Build.VERSION.SDK_INT;
            x80Var = i2 >= 35 ? new x80() : i2 >= 30 ? new w80() : i2 >= 29 ? new v80() : i2 >= 28 ? new u80() : i2 >= 26 ? new t80() : new s80();
            r80.DtvLLDnp = x80Var;
        }
        y80 y80Var2 = x80Var;
        d5 d5Var = new d5(y80Var2, l72Var, l72Var2, this, decorView, 1);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            if (i4 >= viewGroup.getChildCount()) {
                q80 q80Var = new q80(d5Var, viewGroup.getContext());
                q80Var.setTag(y80Var2);
                q80Var.setVisibility(8);
                q80Var.setWillNotDraw(true);
                viewGroup.addView(q80Var);
                break;
            }
            int i5 = i4 + 1;
            View childAt = viewGroup.getChildAt(i4);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof y80) {
                break;
            } else {
                i4 = i5;
            }
        }
        d5Var.run();
        Window window = getWindow();
        window.getClass();
        y80Var2.DtvLLDnp(window);
        String stringExtra = getIntent().getStringExtra("screen");
        if (lw.t47xqa9Q(mw.npxLV1F5UJ07("main", "game", "skins", "howtoplay"), stringExtra)) {
            stringExtra.getClass();
        } else {
            stringExtra = "main";
        }
        ms0 ms0Var = new ms0(this, i3);
        t20 t20Var = new t20();
        ms0Var.JzPJ9o9HE1(t20Var);
        hZbg8h9BTLnn hzbg8h9btlnn = t20Var.DtvLLDnp;
        o20 o20Var = new o20(new m4((HashMap) hzbg8h9btlnn.uGhypWAKDga, t20Var.fZjUkxUoo8, (ArrayList) hzbg8h9btlnn.JzPJ9o9HE1), null);
        b60 b60VarVmKoalxB = mw.VmKoalxB(o20Var, p00.DtvLLDnp);
        ArrayList arrayList = (ArrayList) hzbg8h9btlnn.Hct6Q66i;
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            ((ef0) obj).JzPJ9o9HE1(b60VarVmKoalxB);
        }
        ey eyVar = new ey(453491842, true, new bz1(5, new r8N2pcVj(12, new r8N2pcVj(o20Var), stringExtra)));
        ViewGroup.LayoutParams layoutParams = zx.DtvLLDnp;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        uy uyVar = childAt2 instanceof uy ? (uy) childAt2 : null;
        if (uyVar != null) {
            uyVar.setParentCompositionContext(null);
            uyVar.setContent(eyVar);
            return;
        }
        uy uyVar2 = new uy(this);
        uyVar2.setParentCompositionContext(null);
        uyVar2.setContent(eyVar);
        View decorView2 = getWindow().getDecorView();
        if (io0.mhts4F5X(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (in0.bf9pb4ht(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (hn0.bf9pb4ht(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(uyVar2, zx.DtvLLDnp);
    }
}
