package com.chickencross.seahop;

/* loaded from: classes12.dex */
public final class R {

    /* JADX INFO: Added by JADX */
    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_in = 0x7f010000;

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_out = 0x7f010001;

        /* JADX INFO: Added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 0x7f010002;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_enter = 0x7f010003;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_exit = 0x7f010004;

        /* JADX INFO: Added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 0x7f010005;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_bottom = 0x7f010006;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_top = 0x7f010007;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_bottom = 0x7f010008;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_top = 0x7f010009;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_enter = 0x7f01000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_exit = 0x7f01000b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_slide_down_animation = 0x7f01000c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_slide_up_animation = 0x7f01000d;

        /* JADX INFO: Added by JADX */
        public static final int bm_bottom_sheet_slide_in = 0x7f01000e;

        /* JADX INFO: Added by JADX */
        public static final int bm_bottom_sheet_slide_out = 0x7f01000f;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 0x7f010010;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 0x7f010011;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 0x7f010012;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 0x7f010013;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 0x7f010014;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 0x7f010015;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 0x7f010016;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 0x7f010017;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 0x7f010018;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 0x7f010019;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 0x7f01001a;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 0x7f01001b;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 0x7f01001c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_activity_open = 0x7f01001d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_activity_stay = 0x7f01001e;

        /* JADX INFO: Added by JADX */
        public static final int store_promo_appear_anim = 0x7f01001f;

        /* JADX INFO: Added by JADX */
        public static final int store_promo_disappear_anim = 0x7f010020;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_animation_dismiss = 0x7f010021;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_animation_show = 0x7f010022;

        /* JADX INFO: Added by JADX */
        public static final int tt_fade_out = 0x7f010023;

        /* JADX INFO: Added by JADX */
        public static final int tt_loading_two_icon_scale = 0x7f010024;

        /* JADX INFO: Added by JADX */
        public static final int tt_text_animation_x_in = 0x7f010025;

        /* JADX INFO: Added by JADX */
        public static final int tt_text_animation_y_in = 0x7f010026;

        /* JADX INFO: Added by JADX */
        public static final int tt_text_animation_y_out = 0x7f010027;
    }

    /* JADX INFO: Added by JADX */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 0x7f020000;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 0x7f020001;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 0x7f020002;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 0x7f020003;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 0x7f020005;
    }

    /* JADX INFO: Added by JADX */
    public static final class array {

        /* JADX INFO: Added by JADX */
        public static final int TACloneCrashConfig = 0x7f030000;

        /* JADX INFO: Added by JADX */
        public static final int com_google_android_gms_fonts_certs = 0x7f030001;

        /* JADX INFO: Added by JADX */
        public static final int com_google_android_gms_fonts_certs_dev = 0x7f030002;

        /* JADX INFO: Added by JADX */
        public static final int com_google_android_gms_fonts_certs_prod = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_playback_speeds = 0x7f030004;

        /* JADX INFO: Added by JADX */
        public static final int preloaded_fonts = 0x7f030005;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_markArray = 0x7f030006;
    }

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int SharedValue = 0x7f040000;

        /* JADX INFO: Added by JADX */
        public static final int SharedValueId = 0x7f040001;

        /* JADX INFO: Added by JADX */
        public static final int actionBarDivider = 0x7f040002;

        /* JADX INFO: Added by JADX */
        public static final int actionBarItemBackground = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int actionBarPopupTheme = 0x7f040004;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSize = 0x7f040005;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSplitStyle = 0x7f040006;

        /* JADX INFO: Added by JADX */
        public static final int actionBarStyle = 0x7f040007;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabBarStyle = 0x7f040008;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabStyle = 0x7f040009;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabTextStyle = 0x7f04000a;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTheme = 0x7f04000b;

        /* JADX INFO: Added by JADX */
        public static final int actionBarWidgetTheme = 0x7f04000c;

        /* JADX INFO: Added by JADX */
        public static final int actionButtonStyle = 0x7f04000d;

        /* JADX INFO: Added by JADX */
        public static final int actionDropDownStyle = 0x7f04000e;

        /* JADX INFO: Added by JADX */
        public static final int actionLayout = 0x7f04000f;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextAppearance = 0x7f040010;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextColor = 0x7f040011;

        /* JADX INFO: Added by JADX */
        public static final int actionModeBackground = 0x7f040012;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseButtonStyle = 0x7f040013;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseContentDescription = 0x7f040014;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseDrawable = 0x7f040015;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCopyDrawable = 0x7f040016;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCutDrawable = 0x7f040017;

        /* JADX INFO: Added by JADX */
        public static final int actionModeFindDrawable = 0x7f040018;

        /* JADX INFO: Added by JADX */
        public static final int actionModePasteDrawable = 0x7f040019;

        /* JADX INFO: Added by JADX */
        public static final int actionModePopupWindowStyle = 0x7f04001a;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSelectAllDrawable = 0x7f04001b;

        /* JADX INFO: Added by JADX */
        public static final int actionModeShareDrawable = 0x7f04001c;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSplitBackground = 0x7f04001d;

        /* JADX INFO: Added by JADX */
        public static final int actionModeStyle = 0x7f04001e;

        /* JADX INFO: Added by JADX */
        public static final int actionModeTheme = 0x7f04001f;

        /* JADX INFO: Added by JADX */
        public static final int actionModeWebSearchDrawable = 0x7f040020;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowButtonStyle = 0x7f040021;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowMenuStyle = 0x7f040022;

        /* JADX INFO: Added by JADX */
        public static final int actionProviderClass = 0x7f040023;

        /* JADX INFO: Added by JADX */
        public static final int actionViewClass = 0x7f040024;

        /* JADX INFO: Added by JADX */
        public static final int activityChooserViewStyle = 0x7f040025;

        /* JADX INFO: Added by JADX */
        public static final int adSize = 0x7f040026;

        /* JADX INFO: Added by JADX */
        public static final int adSizes = 0x7f040027;

        /* JADX INFO: Added by JADX */
        public static final int adUnitId = 0x7f040028;

        /* JADX INFO: Added by JADX */
        public static final int ad_marker_color = 0x7f040029;

        /* JADX INFO: Added by JADX */
        public static final int ad_marker_width = 0x7f04002a;

        /* JADX INFO: Added by JADX */
        public static final int adjustable = 0x7f04002b;

        /* JADX INFO: Added by JADX */
        public static final int ageRestrictionViewId = 0x7f04002c;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogButtonGroupStyle = 0x7f04002d;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogCenterButtons = 0x7f04002e;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogStyle = 0x7f04002f;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogTheme = 0x7f040030;

        /* JADX INFO: Added by JADX */
        public static final int allowDividerAbove = 0x7f040031;

        /* JADX INFO: Added by JADX */
        public static final int allowDividerAfterLastItem = 0x7f040032;

        /* JADX INFO: Added by JADX */
        public static final int allowDividerBelow = 0x7f040033;

        /* JADX INFO: Added by JADX */
        public static final int allowStacking = 0x7f040034;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f040035;

        /* JADX INFO: Added by JADX */
        public static final int alphabeticModifiers = 0x7f040036;

        /* JADX INFO: Added by JADX */
        public static final int altSrc = 0x7f040037;

        /* JADX INFO: Added by JADX */
        public static final int animateCircleAngleTo = 0x7f040038;

        /* JADX INFO: Added by JADX */
        public static final int animateRelativeTo = 0x7f040039;

        /* JADX INFO: Added by JADX */
        public static final int animation_enabled = 0x7f04003a;

        /* JADX INFO: Added by JADX */
        public static final int applyMotionScene = 0x7f04003b;

        /* JADX INFO: Added by JADX */
        public static final int arcMode = 0x7f04003c;

        /* JADX INFO: Added by JADX */
        public static final int arrowHeadLength = 0x7f04003d;

        /* JADX INFO: Added by JADX */
        public static final int arrowShaftLength = 0x7f04003e;

        /* JADX INFO: Added by JADX */
        public static final int artwork_display_mode = 0x7f04003f;

        /* JADX INFO: Added by JADX */
        public static final int attributeName = 0x7f040040;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteMode = 0x7f040041;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteTextViewStyle = 0x7f040042;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMaxTextSize = 0x7f040043;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMinTextSize = 0x7f040044;

        /* JADX INFO: Added by JADX */
        public static final int autoSizePresetSizes = 0x7f040045;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeStepGranularity = 0x7f040046;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeTextType = 0x7f040047;

        /* JADX INFO: Added by JADX */
        public static final int autoTransition = 0x7f040048;

        /* JADX INFO: Added by JADX */
        public static final int auto_show = 0x7f040049;

        /* JADX INFO: Added by JADX */
        public static final int background = 0x7f04004a;

        /* JADX INFO: Added by JADX */
        public static final int backgroundSplit = 0x7f04004b;

        /* JADX INFO: Added by JADX */
        public static final int backgroundStacked = 0x7f04004c;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTint = 0x7f04004d;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTintMode = 0x7f04004e;

        /* JADX INFO: Added by JADX */
        public static final int barLength = 0x7f04004f;

        /* JADX INFO: Added by JADX */
        public static final int bar_gravity = 0x7f040050;

        /* JADX INFO: Added by JADX */
        public static final int bar_height = 0x7f040051;

        /* JADX INFO: Added by JADX */
        public static final int barrierAllowsGoneWidgets = 0x7f040052;

        /* JADX INFO: Added by JADX */
        public static final int barrierDirection = 0x7f040053;

        /* JADX INFO: Added by JADX */
        public static final int barrierMargin = 0x7f040054;

        /* JADX INFO: Added by JADX */
        public static final int bidFloor = 0x7f040055;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_bottomLeftRadius = 0x7f040056;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_bottomRightRadius = 0x7f040057;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_customLayout = 0x7f040058;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_check_circle_color = 0x7f040059;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_check_hook_color = 0x7f04005a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_is_check = 0x7f04005b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_line_width = 0x7f04005c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_style = 0x7f04005d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_uncheck_circle_color = 0x7f04005e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_hcb_uncheck_hook_color = 0x7f04005f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_maxTextSize = 0x7f040060;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_minTextSize = 0x7f040061;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_radius = 0x7f040062;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_shadowColor = 0x7f040063;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_shadowRadius = 0x7f040064;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_topLeftRadius = 0x7f040065;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_topRightRadius = 0x7f040066;

        /* JADX INFO: Added by JADX */
        public static final int blendSrc = 0x7f040067;

        /* JADX INFO: Added by JADX */
        public static final int borderRound = 0x7f040068;

        /* JADX INFO: Added by JADX */
        public static final int borderRoundPercent = 0x7f040069;

        /* JADX INFO: Added by JADX */
        public static final int borderlessButtonStyle = 0x7f04006a;

        /* JADX INFO: Added by JADX */
        public static final int brightness = 0x7f04006b;

        /* JADX INFO: Added by JADX */
        public static final int buffered_color = 0x7f04006c;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarButtonStyle = 0x7f04006d;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNegativeButtonStyle = 0x7f04006e;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNeutralButtonStyle = 0x7f04006f;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarPositiveButtonStyle = 0x7f040070;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarStyle = 0x7f040071;

        /* JADX INFO: Added by JADX */
        public static final int buttonCompat = 0x7f040072;

        /* JADX INFO: Added by JADX */
        public static final int buttonGravity = 0x7f040073;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconDimen = 0x7f040074;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanelSideLayout = 0x7f040075;

        /* JADX INFO: Added by JADX */
        public static final int buttonSize = 0x7f040076;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyle = 0x7f040077;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyleSmall = 0x7f040078;

        /* JADX INFO: Added by JADX */
        public static final int buttonTint = 0x7f040079;

        /* JADX INFO: Added by JADX */
        public static final int buttonTintMode = 0x7f04007a;

        /* JADX INFO: Added by JADX */
        public static final int callToActionViewId = 0x7f04007b;

        /* JADX INFO: Added by JADX */
        public static final int carousel_backwardTransition = 0x7f04007c;

        /* JADX INFO: Added by JADX */
        public static final int carousel_emptyViewsBehavior = 0x7f04007d;

        /* JADX INFO: Added by JADX */
        public static final int carousel_firstView = 0x7f04007e;

        /* JADX INFO: Added by JADX */
        public static final int carousel_forwardTransition = 0x7f04007f;

        /* JADX INFO: Added by JADX */
        public static final int carousel_infinite = 0x7f040080;

        /* JADX INFO: Added by JADX */
        public static final int carousel_nextState = 0x7f040081;

        /* JADX INFO: Added by JADX */
        public static final int carousel_previousState = 0x7f040082;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUpMode = 0x7f040083;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_dampeningFactor = 0x7f040084;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_velocityThreshold = 0x7f040085;

        /* JADX INFO: Added by JADX */
        public static final int chainUseRtl = 0x7f040086;

        /* JADX INFO: Added by JADX */
        public static final int checkBoxPreferenceStyle = 0x7f040087;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkCompat = 0x7f040088;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTint = 0x7f040089;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTintMode = 0x7f04008a;

        /* JADX INFO: Added by JADX */
        public static final int checkboxStyle = 0x7f04008b;

        /* JADX INFO: Added by JADX */
        public static final int checkedTextViewStyle = 0x7f04008c;

        /* JADX INFO: Added by JADX */
        public static final int circleCrop = 0x7f04008d;

        /* JADX INFO: Added by JADX */
        public static final int circleRadius = 0x7f04008e;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_angles = 0x7f04008f;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultAngle = 0x7f040090;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultRadius = 0x7f040091;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_radiusInDP = 0x7f040092;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_viewCenter = 0x7f040093;

        /* JADX INFO: Added by JADX */
        public static final int clearsTag = 0x7f040094;

        /* JADX INFO: Added by JADX */
        public static final int clickAction = 0x7f040095;

        /* JADX INFO: Added by JADX */
        public static final int closeIcon = 0x7f040096;

        /* JADX INFO: Added by JADX */
        public static final int closeItemLayout = 0x7f040097;

        /* JADX INFO: Added by JADX */
        public static final int collapseContentDescription = 0x7f040098;

        /* JADX INFO: Added by JADX */
        public static final int collapseIcon = 0x7f040099;

        /* JADX INFO: Added by JADX */
        public static final int color = 0x7f04009a;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 0x7f04009b;

        /* JADX INFO: Added by JADX */
        public static final int colorBackgroundFloating = 0x7f04009c;

        /* JADX INFO: Added by JADX */
        public static final int colorButtonNormal = 0x7f04009d;

        /* JADX INFO: Added by JADX */
        public static final int colorControlActivated = 0x7f04009e;

        /* JADX INFO: Added by JADX */
        public static final int colorControlHighlight = 0x7f04009f;

        /* JADX INFO: Added by JADX */
        public static final int colorControlNormal = 0x7f0400a0;

        /* JADX INFO: Added by JADX */
        public static final int colorError = 0x7f0400a1;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 0x7f0400a2;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 0x7f0400a3;

        /* JADX INFO: Added by JADX */
        public static final int colorScheme = 0x7f0400a4;

        /* JADX INFO: Added by JADX */
        public static final int colorSwitchThumbNormal = 0x7f0400a5;

        /* JADX INFO: Added by JADX */
        public static final int commitIcon = 0x7f0400a6;

        /* JADX INFO: Added by JADX */
        public static final int constraintRotate = 0x7f0400a7;

        /* JADX INFO: Added by JADX */
        public static final int constraintSet = 0x7f0400a8;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetEnd = 0x7f0400a9;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetStart = 0x7f0400aa;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_ids = 0x7f0400ab;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_tags = 0x7f0400ac;

        /* JADX INFO: Added by JADX */
        public static final int constraints = 0x7f0400ad;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f0400ae;

        /* JADX INFO: Added by JADX */
        public static final int contentDescription = 0x7f0400af;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEnd = 0x7f0400b0;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEndWithActions = 0x7f0400b1;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetLeft = 0x7f0400b2;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetRight = 0x7f0400b3;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStart = 0x7f0400b4;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStartWithNavigation = 0x7f0400b5;

        /* JADX INFO: Added by JADX */
        public static final int contrast = 0x7f0400b6;

        /* JADX INFO: Added by JADX */
        public static final int controlBackground = 0x7f0400b7;

        /* JADX INFO: Added by JADX */
        public static final int controller_layout_id = 0x7f0400b8;

        /* JADX INFO: Added by JADX */
        public static final int coordinatorLayoutStyle = 0x7f0400b9;

        /* JADX INFO: Added by JADX */
        public static final int corner = 0x7f0400ba;

        /* JADX INFO: Added by JADX */
        public static final int crossfade = 0x7f0400bb;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f0400bc;

        /* JADX INFO: Added by JADX */
        public static final int curveFit = 0x7f0400bd;

        /* JADX INFO: Added by JADX */
        public static final int customBoolean = 0x7f0400be;

        /* JADX INFO: Added by JADX */
        public static final int customColorDrawableValue = 0x7f0400bf;

        /* JADX INFO: Added by JADX */
        public static final int customColorValue = 0x7f0400c0;

        /* JADX INFO: Added by JADX */
        public static final int customDimension = 0x7f0400c1;

        /* JADX INFO: Added by JADX */
        public static final int customFloatValue = 0x7f0400c2;

        /* JADX INFO: Added by JADX */
        public static final int customIntegerValue = 0x7f0400c3;

        /* JADX INFO: Added by JADX */
        public static final int customNavigationLayout = 0x7f0400c4;

        /* JADX INFO: Added by JADX */
        public static final int customPixelDimension = 0x7f0400c5;

        /* JADX INFO: Added by JADX */
        public static final int customReference = 0x7f0400c6;

        /* JADX INFO: Added by JADX */
        public static final int customStringValue = 0x7f0400c7;

        /* JADX INFO: Added by JADX */
        public static final int defaultDuration = 0x7f0400c8;

        /* JADX INFO: Added by JADX */
        public static final int defaultQueryHint = 0x7f0400c9;

        /* JADX INFO: Added by JADX */
        public static final int defaultState = 0x7f0400ca;

        /* JADX INFO: Added by JADX */
        public static final int defaultValue = 0x7f0400cb;

        /* JADX INFO: Added by JADX */
        public static final int default_artwork = 0x7f0400cc;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarAngle = 0x7f0400cd;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarRadius = 0x7f0400ce;

        /* JADX INFO: Added by JADX */
        public static final int dependency = 0x7f0400cf;

        /* JADX INFO: Added by JADX */
        public static final int deriveConstraintsFrom = 0x7f0400d0;

        /* JADX INFO: Added by JADX */
        public static final int descriptionViewId = 0x7f0400d1;

        /* JADX INFO: Added by JADX */
        public static final int dialogCornerRadius = 0x7f0400d2;

        /* JADX INFO: Added by JADX */
        public static final int dialogIcon = 0x7f0400d3;

        /* JADX INFO: Added by JADX */
        public static final int dialogLayout = 0x7f0400d4;

        /* JADX INFO: Added by JADX */
        public static final int dialogMessage = 0x7f0400d5;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferenceStyle = 0x7f0400d6;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferredPadding = 0x7f0400d7;

        /* JADX INFO: Added by JADX */
        public static final int dialogTheme = 0x7f0400d8;

        /* JADX INFO: Added by JADX */
        public static final int dialogTitle = 0x7f0400d9;

        /* JADX INFO: Added by JADX */
        public static final int disableDependentsState = 0x7f0400da;

        /* JADX INFO: Added by JADX */
        public static final int displayOptions = 0x7f0400db;

        /* JADX INFO: Added by JADX */
        public static final int divider = 0x7f0400dc;

        /* JADX INFO: Added by JADX */
        public static final int dividerHorizontal = 0x7f0400dd;

        /* JADX INFO: Added by JADX */
        public static final int dividerPadding = 0x7f0400de;

        /* JADX INFO: Added by JADX */
        public static final int dividerVertical = 0x7f0400df;

        /* JADX INFO: Added by JADX */
        public static final int dragDirection = 0x7f0400e0;

        /* JADX INFO: Added by JADX */
        public static final int dragScale = 0x7f0400e1;

        /* JADX INFO: Added by JADX */
        public static final int dragThreshold = 0x7f0400e2;

        /* JADX INFO: Added by JADX */
        public static final int drawPath = 0x7f0400e3;

        /* JADX INFO: Added by JADX */
        public static final int drawableBottomCompat = 0x7f0400e4;

        /* JADX INFO: Added by JADX */
        public static final int drawableEndCompat = 0x7f0400e5;

        /* JADX INFO: Added by JADX */
        public static final int drawableLeftCompat = 0x7f0400e6;

        /* JADX INFO: Added by JADX */
        public static final int drawableRightCompat = 0x7f0400e7;

        /* JADX INFO: Added by JADX */
        public static final int drawableSize = 0x7f0400e8;

        /* JADX INFO: Added by JADX */
        public static final int drawableStartCompat = 0x7f0400e9;

        /* JADX INFO: Added by JADX */
        public static final int drawableTint = 0x7f0400ea;

        /* JADX INFO: Added by JADX */
        public static final int drawableTintMode = 0x7f0400eb;

        /* JADX INFO: Added by JADX */
        public static final int drawableTopCompat = 0x7f0400ec;

        /* JADX INFO: Added by JADX */
        public static final int drawerArrowStyle = 0x7f0400ed;

        /* JADX INFO: Added by JADX */
        public static final int dropDownListViewStyle = 0x7f0400ee;

        /* JADX INFO: Added by JADX */
        public static final int dropdownListPreferredItemHeight = 0x7f0400ef;

        /* JADX INFO: Added by JADX */
        public static final int dropdownPreferenceStyle = 0x7f0400f0;

        /* JADX INFO: Added by JADX */
        public static final int duration = 0x7f0400f1;

        /* JADX INFO: Added by JADX */
        public static final int editTextBackground = 0x7f0400f2;

        /* JADX INFO: Added by JADX */
        public static final int editTextColor = 0x7f0400f3;

        /* JADX INFO: Added by JADX */
        public static final int editTextPreferenceStyle = 0x7f0400f4;

        /* JADX INFO: Added by JADX */
        public static final int editTextStyle = 0x7f0400f5;

        /* JADX INFO: Added by JADX */
        public static final int elevation = 0x7f0400f6;

        /* JADX INFO: Added by JADX */
        public static final int emojiCompatEnabled = 0x7f0400f7;

        /* JADX INFO: Added by JADX */
        public static final int enableCopying = 0x7f0400f8;

        /* JADX INFO: Added by JADX */
        public static final int enabled = 0x7f0400f9;

        /* JADX INFO: Added by JADX */
        public static final int entries = 0x7f0400fa;

        /* JADX INFO: Added by JADX */
        public static final int entryValues = 0x7f0400fb;

        /* JADX INFO: Added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 0x7f0400fc;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollEnabled = 0x7f0400fd;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalThumbDrawable = 0x7f0400fe;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalTrackDrawable = 0x7f0400ff;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalThumbDrawable = 0x7f040100;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalTrackDrawable = 0x7f040101;

        /* JADX INFO: Added by JADX */
        public static final int fastforward_icon = 0x7f040102;

        /* JADX INFO: Added by JADX */
        public static final int firstBaselineToTopHeight = 0x7f040103;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalBias = 0x7f040104;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalStyle = 0x7f040105;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalBias = 0x7f040106;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalStyle = 0x7f040107;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalAlign = 0x7f040108;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalBias = 0x7f040109;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalGap = 0x7f04010a;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalStyle = 0x7f04010b;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalBias = 0x7f04010c;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalStyle = 0x7f04010d;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalBias = 0x7f04010e;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalStyle = 0x7f04010f;

        /* JADX INFO: Added by JADX */
        public static final int flow_maxElementsWrap = 0x7f040110;

        /* JADX INFO: Added by JADX */
        public static final int flow_padding = 0x7f040111;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalAlign = 0x7f040112;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalBias = 0x7f040113;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalGap = 0x7f040114;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalStyle = 0x7f040115;

        /* JADX INFO: Added by JADX */
        public static final int flow_wrapMode = 0x7f040116;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f040117;

        /* JADX INFO: Added by JADX */
        public static final int fontFamily = 0x7f040118;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f040119;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f04011a;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f04011b;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f04011c;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f04011d;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f04011e;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f04011f;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f040120;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f040121;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f040122;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f040123;

        /* JADX INFO: Added by JADX */
        public static final int fragment = 0x7f040124;

        /* JADX INFO: Added by JADX */
        public static final int framePosition = 0x7f040125;

        /* JADX INFO: Added by JADX */
        public static final int fullscreen_enter_icon = 0x7f040126;

        /* JADX INFO: Added by JADX */
        public static final int fullscreen_exit_icon = 0x7f040127;

        /* JADX INFO: Added by JADX */
        public static final int gapBetweenBars = 0x7f040128;

        /* JADX INFO: Added by JADX */
        public static final int goIcon = 0x7f040129;

        /* JADX INFO: Added by JADX */
        public static final int guidelineUseRtl = 0x7f04012a;

        /* JADX INFO: Added by JADX */
        public static final int height = 0x7f04012b;

        /* JADX INFO: Added by JADX */
        public static final int hideOnContentScroll = 0x7f04012c;

        /* JADX INFO: Added by JADX */
        public static final int hide_during_ads = 0x7f04012d;

        /* JADX INFO: Added by JADX */
        public static final int hide_on_touch = 0x7f04012e;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUpIndicator = 0x7f04012f;

        /* JADX INFO: Added by JADX */
        public static final int homeLayout = 0x7f040130;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f040131;

        /* JADX INFO: Added by JADX */
        public static final int iconSpaceReserved = 0x7f040132;

        /* JADX INFO: Added by JADX */
        public static final int iconTint = 0x7f040133;

        /* JADX INFO: Added by JADX */
        public static final int iconTintMode = 0x7f040134;

        /* JADX INFO: Added by JADX */
        public static final int iconViewId = 0x7f040135;

        /* JADX INFO: Added by JADX */
        public static final int iconifiedByDefault = 0x7f040136;

        /* JADX INFO: Added by JADX */
        public static final int ifTagNotSet = 0x7f040137;

        /* JADX INFO: Added by JADX */
        public static final int ifTagSet = 0x7f040138;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatio = 0x7f040139;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatioAdjust = 0x7f04013a;

        /* JADX INFO: Added by JADX */
        public static final int imageButtonStyle = 0x7f04013b;

        /* JADX INFO: Added by JADX */
        public static final int imagePanX = 0x7f04013c;

        /* JADX INFO: Added by JADX */
        public static final int imagePanY = 0x7f04013d;

        /* JADX INFO: Added by JADX */
        public static final int imageRotate = 0x7f04013e;

        /* JADX INFO: Added by JADX */
        public static final int imageZoom = 0x7f04013f;

        /* JADX INFO: Added by JADX */
        public static final int image_display_mode = 0x7f040140;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateProgressStyle = 0x7f040141;

        /* JADX INFO: Added by JADX */
        public static final int initialActivityCount = 0x7f040142;

        /* JADX INFO: Added by JADX */
        public static final int initialExpandedChildrenCount = 0x7f040143;

        /* JADX INFO: Added by JADX */
        public static final int isLightTheme = 0x7f040144;

        /* JADX INFO: Added by JADX */
        public static final int isPreferenceVisible = 0x7f040145;

        /* JADX INFO: Added by JADX */
        public static final int itemPadding = 0x7f040146;

        /* JADX INFO: Added by JADX */
        public static final int keep_content_on_player_reset = 0x7f040147;

        /* JADX INFO: Added by JADX */
        public static final int key = 0x7f040148;

        /* JADX INFO: Added by JADX */
        public static final int keyPositionType = 0x7f040149;

        /* JADX INFO: Added by JADX */
        public static final int keylines = 0x7f04014a;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f04014b;

        /* JADX INFO: Added by JADX */
        public static final int lastBaselineToBottomHeight = 0x7f04014c;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f04014d;

        /* JADX INFO: Added by JADX */
        public static final int layoutDescription = 0x7f04014e;

        /* JADX INFO: Added by JADX */
        public static final int layoutDuringTransition = 0x7f04014f;

        /* JADX INFO: Added by JADX */
        public static final int layoutManager = 0x7f040150;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchor = 0x7f040151;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchorGravity = 0x7f040152;

        /* JADX INFO: Added by JADX */
        public static final int layout_behavior = 0x7f040153;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedHeight = 0x7f040154;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedWidth = 0x7f040155;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_creator = 0x7f040156;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBaselineOf = 0x7f040157;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBottomOf = 0x7f040158;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toTopOf = 0x7f040159;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_creator = 0x7f04015a;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toBottomOf = 0x7f04015b;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toTopOf = 0x7f04015c;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircle = 0x7f04015d;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleAngle = 0x7f04015e;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleRadius = 0x7f04015f;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintDimensionRatio = 0x7f040160;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toEndOf = 0x7f040161;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toStartOf = 0x7f040162;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_begin = 0x7f040163;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_end = 0x7f040164;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_percent = 0x7f040165;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight = 0x7f040166;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_default = 0x7f040167;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_max = 0x7f040168;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_min = 0x7f040169;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_percent = 0x7f04016a;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_bias = 0x7f04016b;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_chainStyle = 0x7f04016c;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_weight = 0x7f04016d;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_creator = 0x7f04016e;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toLeftOf = 0x7f04016f;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toRightOf = 0x7f040170;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_creator = 0x7f040171;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toLeftOf = 0x7f040172;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toRightOf = 0x7f040173;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toEndOf = 0x7f040174;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toStartOf = 0x7f040175;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTag = 0x7f040176;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_creator = 0x7f040177;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toBottomOf = 0x7f040178;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toTopOf = 0x7f040179;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_bias = 0x7f04017a;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_chainStyle = 0x7f04017b;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_weight = 0x7f04017c;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth = 0x7f04017d;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_default = 0x7f04017e;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_max = 0x7f04017f;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_min = 0x7f040180;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_percent = 0x7f040181;

        /* JADX INFO: Added by JADX */
        public static final int layout_dodgeInsetEdges = 0x7f040182;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteX = 0x7f040183;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteY = 0x7f040184;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBaseline = 0x7f040185;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBottom = 0x7f040186;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginEnd = 0x7f040187;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginLeft = 0x7f040188;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginRight = 0x7f040189;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginStart = 0x7f04018a;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginTop = 0x7f04018b;

        /* JADX INFO: Added by JADX */
        public static final int layout_insetEdge = 0x7f04018c;

        /* JADX INFO: Added by JADX */
        public static final int layout_keyline = 0x7f04018d;

        /* JADX INFO: Added by JADX */
        public static final int layout_marginBaseline = 0x7f04018e;

        /* JADX INFO: Added by JADX */
        public static final int layout_optimizationLevel = 0x7f04018f;

        /* JADX INFO: Added by JADX */
        public static final int layout_wrapBehaviorInParent = 0x7f040190;

        /* JADX INFO: Added by JADX */
        public static final int limitBoundsTo = 0x7f040191;

        /* JADX INFO: Added by JADX */
        public static final int lineHeight = 0x7f040192;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceBackgroundIndicator = 0x7f040193;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 0x7f040194;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 0x7f040195;

        /* JADX INFO: Added by JADX */
        public static final int listDividerAlertDialog = 0x7f040196;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayout = 0x7f040197;

        /* JADX INFO: Added by JADX */
        public static final int listLayout = 0x7f040198;

        /* JADX INFO: Added by JADX */
        public static final int listMenuViewStyle = 0x7f040199;

        /* JADX INFO: Added by JADX */
        public static final int listPopupWindowStyle = 0x7f04019a;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeight = 0x7f04019b;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightLarge = 0x7f04019c;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightSmall = 0x7f04019d;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingEnd = 0x7f04019e;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingLeft = 0x7f04019f;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingRight = 0x7f0401a0;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingStart = 0x7f0401a1;

        /* JADX INFO: Added by JADX */
        public static final int logo = 0x7f0401a2;

        /* JADX INFO: Added by JADX */
        public static final int logoDescription = 0x7f0401a3;

        /* JADX INFO: Added by JADX */
        public static final int maxAcceleration = 0x7f0401a4;

        /* JADX INFO: Added by JADX */
        public static final int maxButtonHeight = 0x7f0401a5;

        /* JADX INFO: Added by JADX */
        public static final int maxHeight = 0x7f0401a6;

        /* JADX INFO: Added by JADX */
        public static final int maxVelocity = 0x7f0401a7;

        /* JADX INFO: Added by JADX */
        public static final int maxWidth = 0x7f0401a8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_click = 0x7f0401a9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_data = 0x7f0401aa;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_effect = 0x7f0401ab;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_effect_strategy = 0x7f0401ac;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_imageEffect = 0x7f0401ad;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_radius = 0x7f0401ae;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_report = 0x7f0401af;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_strategy = 0x7f0401b0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_visible = 0x7f0401b1;

        /* JADX INFO: Added by JADX */
        public static final int measureWithLargestChild = 0x7f0401b2;

        /* JADX INFO: Added by JADX */
        public static final int mediaViewId = 0x7f0401b3;

        /* JADX INFO: Added by JADX */
        public static final int menu = 0x7f0401b4;

        /* JADX INFO: Added by JADX */
        public static final int methodName = 0x7f0401b5;

        /* JADX INFO: Added by JADX */
        public static final int min = 0x7f0401b6;

        /* JADX INFO: Added by JADX */
        public static final int minHeight = 0x7f0401b7;

        /* JADX INFO: Added by JADX */
        public static final int minWidth = 0x7f0401b8;

        /* JADX INFO: Added by JADX */
        public static final int mock_diagonalsColor = 0x7f0401b9;

        /* JADX INFO: Added by JADX */
        public static final int mock_label = 0x7f0401ba;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelBackgroundColor = 0x7f0401bb;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelColor = 0x7f0401bc;

        /* JADX INFO: Added by JADX */
        public static final int mock_showDiagonals = 0x7f0401bd;

        /* JADX INFO: Added by JADX */
        public static final int mock_showLabel = 0x7f0401be;

        /* JADX INFO: Added by JADX */
        public static final int motionDebug = 0x7f0401bf;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_alpha = 0x7f0401c0;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_end = 0x7f0401c1;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_move = 0x7f0401c2;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_start = 0x7f0401c3;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_strict = 0x7f0401c4;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationX = 0x7f0401c5;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationY = 0x7f0401c6;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_viewTransition = 0x7f0401c7;

        /* JADX INFO: Added by JADX */
        public static final int motionInterpolator = 0x7f0401c8;

        /* JADX INFO: Added by JADX */
        public static final int motionPathRotate = 0x7f0401c9;

        /* JADX INFO: Added by JADX */
        public static final int motionProgress = 0x7f0401ca;

        /* JADX INFO: Added by JADX */
        public static final int motionStagger = 0x7f0401cb;

        /* JADX INFO: Added by JADX */
        public static final int motionTarget = 0x7f0401cc;

        /* JADX INFO: Added by JADX */
        public static final int motion_postLayoutCollision = 0x7f0401cd;

        /* JADX INFO: Added by JADX */
        public static final int motion_triggerOnCollision = 0x7f0401ce;

        /* JADX INFO: Added by JADX */
        public static final int moveWhenScrollAtTop = 0x7f0401cf;

        /* JADX INFO: Added by JADX */
        public static final int multiChoiceItemLayout = 0x7f0401d0;

        /* JADX INFO: Added by JADX */
        public static final int navigationContentDescription = 0x7f0401d1;

        /* JADX INFO: Added by JADX */
        public static final int navigationIcon = 0x7f0401d2;

        /* JADX INFO: Added by JADX */
        public static final int navigationMode = 0x7f0401d3;

        /* JADX INFO: Added by JADX */
        public static final int negativeButtonText = 0x7f0401d4;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollFlags = 0x7f0401d5;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 0x7f0401d6;

        /* JADX INFO: Added by JADX */
        public static final int next_icon = 0x7f0401d7;

        /* JADX INFO: Added by JADX */
        public static final int numericModifiers = 0x7f0401d8;

        /* JADX INFO: Added by JADX */
        public static final int onCross = 0x7f0401d9;

        /* JADX INFO: Added by JADX */
        public static final int onHide = 0x7f0401da;

        /* JADX INFO: Added by JADX */
        public static final int onNegativeCross = 0x7f0401db;

        /* JADX INFO: Added by JADX */
        public static final int onPositiveCross = 0x7f0401dc;

        /* JADX INFO: Added by JADX */
        public static final int onShow = 0x7f0401dd;

        /* JADX INFO: Added by JADX */
        public static final int onStateTransition = 0x7f0401de;

        /* JADX INFO: Added by JADX */
        public static final int onTouchUp = 0x7f0401df;

        /* JADX INFO: Added by JADX */
        public static final int order = 0x7f0401e0;

        /* JADX INFO: Added by JADX */
        public static final int orderingFromXml = 0x7f0401e1;

        /* JADX INFO: Added by JADX */
        public static final int overlapAnchor = 0x7f0401e2;

        /* JADX INFO: Added by JADX */
        public static final int overlay = 0x7f0401e3;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomNoButtons = 0x7f0401e4;

        /* JADX INFO: Added by JADX */
        public static final int paddingEnd = 0x7f0401e5;

        /* JADX INFO: Added by JADX */
        public static final int paddingStart = 0x7f0401e6;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopNoTitle = 0x7f0401e7;

        /* JADX INFO: Added by JADX */
        public static final int panelBackground = 0x7f0401e8;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListTheme = 0x7f0401e9;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListWidth = 0x7f0401ea;

        /* JADX INFO: Added by JADX */
        public static final int pathMotionArc = 0x7f0401eb;

        /* JADX INFO: Added by JADX */
        public static final int path_percent = 0x7f0401ec;

        /* JADX INFO: Added by JADX */
        public static final int pause_icon = 0x7f0401ed;

        /* JADX INFO: Added by JADX */
        public static final int percentHeight = 0x7f0401ee;

        /* JADX INFO: Added by JADX */
        public static final int percentWidth = 0x7f0401ef;

        /* JADX INFO: Added by JADX */
        public static final int percentX = 0x7f0401f0;

        /* JADX INFO: Added by JADX */
        public static final int percentY = 0x7f0401f1;

        /* JADX INFO: Added by JADX */
        public static final int perpendicularPath_percent = 0x7f0401f2;

        /* JADX INFO: Added by JADX */
        public static final int persistent = 0x7f0401f3;

        /* JADX INFO: Added by JADX */
        public static final int pivotAnchor = 0x7f0401f4;

        /* JADX INFO: Added by JADX */
        public static final int placeholder_emptyVisibility = 0x7f0401f5;

        /* JADX INFO: Added by JADX */
        public static final int play_icon = 0x7f0401f6;

        /* JADX INFO: Added by JADX */
        public static final int played_ad_marker_color = 0x7f0401f7;

        /* JADX INFO: Added by JADX */
        public static final int played_color = 0x7f0401f8;

        /* JADX INFO: Added by JADX */
        public static final int player_layout_id = 0x7f0401f9;

        /* JADX INFO: Added by JADX */
        public static final int polarRelativeTo = 0x7f0401fa;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuStyle = 0x7f0401fb;

        /* JADX INFO: Added by JADX */
        public static final int popupTheme = 0x7f0401fc;

        /* JADX INFO: Added by JADX */
        public static final int popupWindowStyle = 0x7f0401fd;

        /* JADX INFO: Added by JADX */
        public static final int positiveButtonText = 0x7f0401fe;

        /* JADX INFO: Added by JADX */
        public static final int preferenceCategoryStyle = 0x7f0401ff;

        /* JADX INFO: Added by JADX */
        public static final int preferenceCategoryTitleTextAppearance = 0x7f040200;

        /* JADX INFO: Added by JADX */
        public static final int preferenceFragmentCompatStyle = 0x7f040201;

        /* JADX INFO: Added by JADX */
        public static final int preferenceFragmentListStyle = 0x7f040202;

        /* JADX INFO: Added by JADX */
        public static final int preferenceFragmentStyle = 0x7f040203;

        /* JADX INFO: Added by JADX */
        public static final int preferenceInformationStyle = 0x7f040204;

        /* JADX INFO: Added by JADX */
        public static final int preferenceScreenStyle = 0x7f040205;

        /* JADX INFO: Added by JADX */
        public static final int preferenceStyle = 0x7f040206;

        /* JADX INFO: Added by JADX */
        public static final int preferenceTheme = 0x7f040207;

        /* JADX INFO: Added by JADX */
        public static final int preserveIconSpacing = 0x7f040208;

        /* JADX INFO: Added by JADX */
        public static final int previous_icon = 0x7f040209;

        /* JADX INFO: Added by JADX */
        public static final int progressBarPadding = 0x7f04020a;

        /* JADX INFO: Added by JADX */
        public static final int progressBarStyle = 0x7f04020b;

        /* JADX INFO: Added by JADX */
        public static final int providerViewId = 0x7f04020c;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionInterpolator = 0x7f04020d;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionPhase = 0x7f04020e;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionSteps = 0x7f04020f;

        /* JADX INFO: Added by JADX */
        public static final int queryBackground = 0x7f040210;

        /* JADX INFO: Added by JADX */
        public static final int queryHint = 0x7f040211;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 0x7f040212;

        /* JADX INFO: Added by JADX */
        public static final int radioButtonStyle = 0x7f040213;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyle = 0x7f040214;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleIndicator = 0x7f040215;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleSmall = 0x7f040216;

        /* JADX INFO: Added by JADX */
        public static final int ratingViewId = 0x7f040217;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_animateChange = 0x7f040218;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToAllConstraintSets = 0x7f040219;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToConstraintSet = 0x7f04021a;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_valueId = 0x7f04021b;

        /* JADX INFO: Added by JADX */
        public static final int recyclerViewStyle = 0x7f04021c;

        /* JADX INFO: Added by JADX */
        public static final int region_heightLessThan = 0x7f04021d;

        /* JADX INFO: Added by JADX */
        public static final int region_heightMoreThan = 0x7f04021e;

        /* JADX INFO: Added by JADX */
        public static final int region_widthLessThan = 0x7f04021f;

        /* JADX INFO: Added by JADX */
        public static final int region_widthMoreThan = 0x7f040220;

        /* JADX INFO: Added by JADX */
        public static final int repeat_all_icon = 0x7f040221;

        /* JADX INFO: Added by JADX */
        public static final int repeat_off_icon = 0x7f040222;

        /* JADX INFO: Added by JADX */
        public static final int repeat_one_icon = 0x7f040223;

        /* JADX INFO: Added by JADX */
        public static final int repeat_toggle_modes = 0x7f040224;

        /* JADX INFO: Added by JADX */
        public static final int resize_mode = 0x7f040225;

        /* JADX INFO: Added by JADX */
        public static final int reverseLayout = 0x7f040226;

        /* JADX INFO: Added by JADX */
        public static final int rewind_icon = 0x7f040227;

        /* JADX INFO: Added by JADX */
        public static final int rotationCenterId = 0x7f040228;

        /* JADX INFO: Added by JADX */
        public static final int round = 0x7f040229;

        /* JADX INFO: Added by JADX */
        public static final int roundPercent = 0x7f04022a;

        /* JADX INFO: Added by JADX */
        public static final int saturation = 0x7f04022b;

        /* JADX INFO: Added by JADX */
        public static final int scaleFromTextSize = 0x7f04022c;

        /* JADX INFO: Added by JADX */
        public static final int scopeUris = 0x7f04022d;

        /* JADX INFO: Added by JADX */
        public static final int scrubber_color = 0x7f04022e;

        /* JADX INFO: Added by JADX */
        public static final int scrubber_disabled_size = 0x7f04022f;

        /* JADX INFO: Added by JADX */
        public static final int scrubber_dragged_size = 0x7f040230;

        /* JADX INFO: Added by JADX */
        public static final int scrubber_drawable = 0x7f040231;

        /* JADX INFO: Added by JADX */
        public static final int scrubber_enabled_size = 0x7f040232;

        /* JADX INFO: Added by JADX */
        public static final int searchHintIcon = 0x7f040233;

        /* JADX INFO: Added by JADX */
        public static final int searchIcon = 0x7f040234;

        /* JADX INFO: Added by JADX */
        public static final int searchViewStyle = 0x7f040235;

        /* JADX INFO: Added by JADX */
        public static final int seekBarIncrement = 0x7f040236;

        /* JADX INFO: Added by JADX */
        public static final int seekBarPreferenceStyle = 0x7f040237;

        /* JADX INFO: Added by JADX */
        public static final int seekBarStyle = 0x7f040238;

        /* JADX INFO: Added by JADX */
        public static final int selectable = 0x7f040239;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackground = 0x7f04023a;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackgroundBorderless = 0x7f04023b;

        /* JADX INFO: Added by JADX */
        public static final int setsTag = 0x7f04023c;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 0x7f04023d;

        /* JADX INFO: Added by JADX */
        public static final int shouldDisableView = 0x7f04023e;

        /* JADX INFO: Added by JADX */
        public static final int showAsAction = 0x7f04023f;

        /* JADX INFO: Added by JADX */
        public static final int showDividers = 0x7f040240;

        /* JADX INFO: Added by JADX */
        public static final int showPaths = 0x7f040241;

        /* JADX INFO: Added by JADX */
        public static final int showSeekBarValue = 0x7f040242;

        /* JADX INFO: Added by JADX */
        public static final int showText = 0x7f040243;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f040244;

        /* JADX INFO: Added by JADX */
        public static final int show_buffering = 0x7f040245;

        /* JADX INFO: Added by JADX */
        public static final int show_fastforward_button = 0x7f040246;

        /* JADX INFO: Added by JADX */
        public static final int show_next_button = 0x7f040247;

        /* JADX INFO: Added by JADX */
        public static final int show_previous_button = 0x7f040248;

        /* JADX INFO: Added by JADX */
        public static final int show_rewind_button = 0x7f040249;

        /* JADX INFO: Added by JADX */
        public static final int show_shuffle_button = 0x7f04024a;

        /* JADX INFO: Added by JADX */
        public static final int show_subtitle_button = 0x7f04024b;

        /* JADX INFO: Added by JADX */
        public static final int show_timeout = 0x7f04024c;

        /* JADX INFO: Added by JADX */
        public static final int show_vr_button = 0x7f04024d;

        /* JADX INFO: Added by JADX */
        public static final int shuffle_off_icon = 0x7f04024e;

        /* JADX INFO: Added by JADX */
        public static final int shuffle_on_icon = 0x7f04024f;

        /* JADX INFO: Added by JADX */
        public static final int shutter_background_color = 0x7f040250;

        /* JADX INFO: Added by JADX */
        public static final int singleChoiceItemLayout = 0x7f040251;

        /* JADX INFO: Added by JADX */
        public static final int singleLineTitle = 0x7f040252;

        /* JADX INFO: Added by JADX */
        public static final int sizePercent = 0x7f040253;

        /* JADX INFO: Added by JADX */
        public static final int spanCount = 0x7f040254;

        /* JADX INFO: Added by JADX */
        public static final int spinBars = 0x7f040255;

        /* JADX INFO: Added by JADX */
        public static final int spinnerDropDownItemStyle = 0x7f040256;

        /* JADX INFO: Added by JADX */
        public static final int spinnerStyle = 0x7f040257;

        /* JADX INFO: Added by JADX */
        public static final int splitTrack = 0x7f040258;

        /* JADX INFO: Added by JADX */
        public static final int springBoundary = 0x7f040259;

        /* JADX INFO: Added by JADX */
        public static final int springDamping = 0x7f04025a;

        /* JADX INFO: Added by JADX */
        public static final int springMass = 0x7f04025b;

        /* JADX INFO: Added by JADX */
        public static final int springStiffness = 0x7f04025c;

        /* JADX INFO: Added by JADX */
        public static final int springStopThreshold = 0x7f04025d;

        /* JADX INFO: Added by JADX */
        public static final int srcCompat = 0x7f04025e;

        /* JADX INFO: Added by JADX */
        public static final int stackFromEnd = 0x7f04025f;

        /* JADX INFO: Added by JADX */
        public static final int staggered = 0x7f040260;

        /* JADX INFO: Added by JADX */
        public static final int state_above_anchor = 0x7f040261;

        /* JADX INFO: Added by JADX */
        public static final int statusBarBackground = 0x7f040262;

        /* JADX INFO: Added by JADX */
        public static final int subMenuArrow = 0x7f040263;

        /* JADX INFO: Added by JADX */
        public static final int submitBackground = 0x7f040264;

        /* JADX INFO: Added by JADX */
        public static final int subtitle = 0x7f040265;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextAppearance = 0x7f040266;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextColor = 0x7f040267;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextStyle = 0x7f040268;

        /* JADX INFO: Added by JADX */
        public static final int subtitle_off_icon = 0x7f040269;

        /* JADX INFO: Added by JADX */
        public static final int subtitle_on_icon = 0x7f04026a;

        /* JADX INFO: Added by JADX */
        public static final int suggestionRowLayout = 0x7f04026b;

        /* JADX INFO: Added by JADX */
        public static final int summary = 0x7f04026c;

        /* JADX INFO: Added by JADX */
        public static final int summaryOff = 0x7f04026d;

        /* JADX INFO: Added by JADX */
        public static final int summaryOn = 0x7f04026e;

        /* JADX INFO: Added by JADX */
        public static final int surface_type = 0x7f04026f;

        /* JADX INFO: Added by JADX */
        public static final int switchMinWidth = 0x7f040270;

        /* JADX INFO: Added by JADX */
        public static final int switchPadding = 0x7f040271;

        /* JADX INFO: Added by JADX */
        public static final int switchPreferenceCompatStyle = 0x7f040272;

        /* JADX INFO: Added by JADX */
        public static final int switchPreferenceStyle = 0x7f040273;

        /* JADX INFO: Added by JADX */
        public static final int switchStyle = 0x7f040274;

        /* JADX INFO: Added by JADX */
        public static final int switchTextAppearance = 0x7f040275;

        /* JADX INFO: Added by JADX */
        public static final int switchTextOff = 0x7f040276;

        /* JADX INFO: Added by JADX */
        public static final int switchTextOn = 0x7f040277;

        /* JADX INFO: Added by JADX */
        public static final int targetId = 0x7f040278;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailColor = 0x7f040279;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailScale = 0x7f04027a;

        /* JADX INFO: Added by JADX */
        public static final int telltales_velocityMode = 0x7f04027b;

        /* JADX INFO: Added by JADX */
        public static final int textAllCaps = 0x7f04027c;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLargePopupMenu = 0x7f04027d;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItem = 0x7f04027e;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSecondary = 0x7f04027f;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSmall = 0x7f040280;

        /* JADX INFO: Added by JADX */
        public static final int textAppearancePopupMenuHeader = 0x7f040281;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 0x7f040282;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultTitle = 0x7f040283;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSmallPopupMenu = 0x7f040284;

        /* JADX INFO: Added by JADX */
        public static final int textBackground = 0x7f040285;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanX = 0x7f040286;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanY = 0x7f040287;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundRotate = 0x7f040288;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundZoom = 0x7f040289;

        /* JADX INFO: Added by JADX */
        public static final int textColorAlertDialogListItem = 0x7f04028a;

        /* JADX INFO: Added by JADX */
        public static final int textColorSearchUrl = 0x7f04028b;

        /* JADX INFO: Added by JADX */
        public static final int textFillColor = 0x7f04028c;

        /* JADX INFO: Added by JADX */
        public static final int textLocale = 0x7f04028d;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineColor = 0x7f04028e;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineThickness = 0x7f04028f;

        /* JADX INFO: Added by JADX */
        public static final int textPanX = 0x7f040290;

        /* JADX INFO: Added by JADX */
        public static final int textPanY = 0x7f040291;

        /* JADX INFO: Added by JADX */
        public static final int textureBlurFactor = 0x7f040292;

        /* JADX INFO: Added by JADX */
        public static final int textureEffect = 0x7f040293;

        /* JADX INFO: Added by JADX */
        public static final int textureHeight = 0x7f040294;

        /* JADX INFO: Added by JADX */
        public static final int textureWidth = 0x7f040295;

        /* JADX INFO: Added by JADX */
        public static final int theme = 0x7f040296;

        /* JADX INFO: Added by JADX */
        public static final int thickness = 0x7f040297;

        /* JADX INFO: Added by JADX */
        public static final int thumbTextPadding = 0x7f040298;

        /* JADX INFO: Added by JADX */
        public static final int thumbTint = 0x7f040299;

        /* JADX INFO: Added by JADX */
        public static final int thumbTintMode = 0x7f04029a;

        /* JADX INFO: Added by JADX */
        public static final int tickMark = 0x7f04029b;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTint = 0x7f04029c;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTintMode = 0x7f04029d;

        /* JADX INFO: Added by JADX */
        public static final int time_bar_min_update_interval = 0x7f04029e;

        /* JADX INFO: Added by JADX */
        public static final int tint = 0x7f04029f;

        /* JADX INFO: Added by JADX */
        public static final int tintMode = 0x7f0402a0;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f0402a1;

        /* JADX INFO: Added by JADX */
        public static final int titleMargin = 0x7f0402a2;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginBottom = 0x7f0402a3;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginEnd = 0x7f0402a4;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginStart = 0x7f0402a5;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginTop = 0x7f0402a6;

        /* JADX INFO: Added by JADX */
        public static final int titleMargins = 0x7f0402a7;

        /* JADX INFO: Added by JADX */
        public static final int titleTextAppearance = 0x7f0402a8;

        /* JADX INFO: Added by JADX */
        public static final int titleTextColor = 0x7f0402a9;

        /* JADX INFO: Added by JADX */
        public static final int titleTextStyle = 0x7f0402aa;

        /* JADX INFO: Added by JADX */
        public static final int titleViewId = 0x7f0402ab;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonStyle = 0x7f0402ac;

        /* JADX INFO: Added by JADX */
        public static final int toolbarStyle = 0x7f0402ad;

        /* JADX INFO: Added by JADX */
        public static final int tooltipForegroundColor = 0x7f0402ae;

        /* JADX INFO: Added by JADX */
        public static final int tooltipFrameBackground = 0x7f0402af;

        /* JADX INFO: Added by JADX */
        public static final int tooltipText = 0x7f0402b0;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorId = 0x7f0402b1;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorSide = 0x7f0402b2;

        /* JADX INFO: Added by JADX */
        public static final int touchRegionId = 0x7f0402b3;

        /* JADX INFO: Added by JADX */
        public static final int touch_target_height = 0x7f0402b4;

        /* JADX INFO: Added by JADX */
        public static final int track = 0x7f0402b5;

        /* JADX INFO: Added by JADX */
        public static final int trackTint = 0x7f0402b6;

        /* JADX INFO: Added by JADX */
        public static final int trackTintMode = 0x7f0402b7;

        /* JADX INFO: Added by JADX */
        public static final int transformPivotTarget = 0x7f0402b8;

        /* JADX INFO: Added by JADX */
        public static final int transitionDisable = 0x7f0402b9;

        /* JADX INFO: Added by JADX */
        public static final int transitionEasing = 0x7f0402ba;

        /* JADX INFO: Added by JADX */
        public static final int transitionFlags = 0x7f0402bb;

        /* JADX INFO: Added by JADX */
        public static final int transitionPathRotate = 0x7f0402bc;

        /* JADX INFO: Added by JADX */
        public static final int triggerId = 0x7f0402bd;

        /* JADX INFO: Added by JADX */
        public static final int triggerReceiver = 0x7f0402be;

        /* JADX INFO: Added by JADX */
        public static final int triggerSlack = 0x7f0402bf;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f0402c0;

        /* JADX INFO: Added by JADX */
        public static final int unplayed_color = 0x7f0402c1;

        /* JADX INFO: Added by JADX */
        public static final int upDuration = 0x7f0402c2;

        /* JADX INFO: Added by JADX */
        public static final int updatesContinuously = 0x7f0402c3;

        /* JADX INFO: Added by JADX */
        public static final int useSimpleSummaryProvider = 0x7f0402c4;

        /* JADX INFO: Added by JADX */
        public static final int use_artwork = 0x7f0402c5;

        /* JADX INFO: Added by JADX */
        public static final int use_controller = 0x7f0402c6;

        /* JADX INFO: Added by JADX */
        public static final int viewInflaterClass = 0x7f0402c7;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionMode = 0x7f0402c8;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnCross = 0x7f0402c9;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnNegativeCross = 0x7f0402ca;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnPositiveCross = 0x7f0402cb;

        /* JADX INFO: Added by JADX */
        public static final int visibilityMode = 0x7f0402cc;

        /* JADX INFO: Added by JADX */
        public static final int voiceIcon = 0x7f0402cd;

        /* JADX INFO: Added by JADX */
        public static final int vr_icon = 0x7f0402ce;

        /* JADX INFO: Added by JADX */
        public static final int warmth = 0x7f0402cf;

        /* JADX INFO: Added by JADX */
        public static final int waveDecay = 0x7f0402d0;

        /* JADX INFO: Added by JADX */
        public static final int waveOffset = 0x7f0402d1;

        /* JADX INFO: Added by JADX */
        public static final int wavePeriod = 0x7f0402d2;

        /* JADX INFO: Added by JADX */
        public static final int wavePhase = 0x7f0402d3;

        /* JADX INFO: Added by JADX */
        public static final int waveShape = 0x7f0402d4;

        /* JADX INFO: Added by JADX */
        public static final int waveVariesBy = 0x7f0402d5;

        /* JADX INFO: Added by JADX */
        public static final int widgetLayout = 0x7f0402d6;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBar = 0x7f0402d7;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBarOverlay = 0x7f0402d8;

        /* JADX INFO: Added by JADX */
        public static final int windowActionModeOverlay = 0x7f0402d9;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMajor = 0x7f0402da;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMinor = 0x7f0402db;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMajor = 0x7f0402dc;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMinor = 0x7f0402dd;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMajor = 0x7f0402de;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMinor = 0x7f0402df;

        /* JADX INFO: Added by JADX */
        public static final int windowNoTitle = 0x7f0402e0;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_template_type = 0x7f0402e1;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_gravity = 0x7f0402e2;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_arrow_size = 0x7f0402e3;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_background_color = 0x7f0402e4;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_drawable = 0x7f0402e5;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_height = 0x7f0402e6;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_margin = 0x7f0402e7;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_padding_bottom = 0x7f0402e8;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_padding_left = 0x7f0402e9;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_padding_right = 0x7f0402ea;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_padding_top = 0x7f0402eb;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_radius = 0x7f0402ec;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_show_mode = 0x7f0402ed;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_text_color = 0x7f0402ee;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_text_size = 0x7f0402ef;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_indicator_width = 0x7f0402f0;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_max = 0x7f0402f1;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_min = 0x7f0402f2;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_min_interval = 0x7f0402f3;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_mode = 0x7f0402f4;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_color = 0x7f0402f5;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_default_color = 0x7f0402f6;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_drawable = 0x7f0402f7;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_drawable_default = 0x7f0402f8;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_height = 0x7f0402f9;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_progress_radius = 0x7f0402fa;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_auto_bonding = 0x7f0402fb;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_color = 0x7f0402fc;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_drawable = 0x7f0402fd;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_height = 0x7f0402fe;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_radius = 0x7f0402ff;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_step_width = 0x7f040300;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_steps = 0x7f040301;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_thumb_drawable = 0x7f040302;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_thumb_height = 0x7f040303;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_thumb_inactivated_drawable = 0x7f040304;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_thumb_scale_ratio = 0x7f040305;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_thumb_width = 0x7f040306;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_gravity = 0x7f040307;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_in_range_text_color = 0x7f040308;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_layout_gravity = 0x7f040309;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_mode = 0x7f04030a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_number = 0x7f04030b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_text_array = 0x7f04030c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_text_color = 0x7f04030d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_text_margin = 0x7f04030e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_tick_mark_text_size = 0x7f04030f;
    }

    /* JADX INFO: Added by JADX */
    public static final class bool {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_embed_tabs = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int config_materialPreferenceIconSpaceReserved = 0x7f050002;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_alarm_service_default = 0x7f050003;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_foreground_service_default = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_job_service_default = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int isTablet = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int workmanager_test_configuration = 0x7f050007;
    }

    /* JADX INFO: Added by JADX */
    public static final class color {

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 0x7f060000;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 0x7f060001;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 0x7f060002;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_text_material = 0x7f060003;

        /* JADX INFO: Added by JADX */
        public static final int abc_color_highlight_material = 0x7f060004;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard = 0x7f060005;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard_light = 0x7f060006;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_dark = 0x7f060007;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_light = 0x7f060008;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 0x7f060009;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 0x7f06000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_dark = 0x7f06000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_light = 0x7f06000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text = 0x7f06000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_normal = 0x7f06000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_pressed = 0x7f06000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_selected = 0x7f060010;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_dark = 0x7f060011;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_light = 0x7f060012;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_btn_checkable = 0x7f060013;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_default = 0x7f060014;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_edittext = 0x7f060015;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_seek_thumb = 0x7f060016;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_spinner = 0x7f060017;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_switch_track = 0x7f060018;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_dark = 0x7f060019;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_light = 0x7f06001a;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_ad_badge_green = 0x7f06001b;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_button_blue = 0x7f06001c;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_button_light_blue = 0x7f06001d;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_outline = 0x7f06001e;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_white = 0x7f06001f;

        /* JADX INFO: Added by JADX */
        public static final int ah_blue = 0x7f060020;

        /* JADX INFO: Added by JADX */
        public static final int ah_error_red = 0x7f060021;

        /* JADX INFO: Added by JADX */
        public static final int ah_success_green = 0x7f060022;

        /* JADX INFO: Added by JADX */
        public static final int ah_warning_yellow = 0x7f060023;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 0x7f060024;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 0x7f060025;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_adBadgeTextColor = 0x7f060026;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_adControlbutton_brightBlueColor = 0x7f060027;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_brand_color = 0x7f060028;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_brand_color_dark = 0x7f060029;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_checkmarkColor = 0x7f06002a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_ctaButtonColor = 0x7f06002b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_ctaButtonPressedColor = 0x7f06002c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_disclosureButtonColor = 0x7f06002d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_grayColor = 0x7f06002e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_greenColor = 0x7f06002f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_highlightListItemColor = 0x7f060030;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_highlightTextColor = 0x7f060031;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_listViewBackground = 0x7f060032;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_listViewSectionTextColor = 0x7f060033;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_orangeColor = 0x7f060034;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_starColor = 0x7f060035;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_switchThumbColor = 0x7f060036;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_switchTrackDisabledColor = 0x7f060037;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_textColorPrimary = 0x7f060038;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_warningColor = 0x7f060039;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_xmarkColor = 0x7f06003a;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_dark = 0x7f06003b;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_light = 0x7f06003c;

        /* JADX INFO: Added by JADX */
        public static final int background_material_dark = 0x7f06003d;

        /* JADX INFO: Added by JADX */
        public static final int background_material_light = 0x7f06003e;

        /* JADX INFO: Added by JADX */
        public static final int black = 0x7f06003f;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_button_bg_color = 0x7f060040;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_button_icon_color = 0x7f060041;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_button_ripple_color = 0x7f060042;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_button_text_color = 0x7f060043;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_icon_ripple_color = 0x7f060044;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_sheet_bg_color = 0x7f060045;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_subtitle_color = 0x7f060046;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_title_color = 0x7f060047;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_dark = 0x7f060048;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_light = 0x7f060049;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_dark = 0x7f06004a;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_light = 0x7f06004b;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_dark = 0x7f06004c;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_light = 0x7f06004d;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_bg_grey = 0x7f06004e;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_divider_color = 0x7f06004f;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_text_color = 0x7f060050;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_title_color = 0x7f060051;

        /* JADX INFO: Added by JADX */
        public static final int button_material_dark = 0x7f060052;

        /* JADX INFO: Added by JADX */
        public static final int button_material_light = 0x7f060053;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 0x7f060054;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 0x7f060055;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f060056;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_default = 0x7f060057;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_disabled = 0x7f060058;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f060059;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_pressed = 0x7f06005a;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f06005b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_default = 0x7f06005c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_disabled = 0x7f06005d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f06005e;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_pressed = 0x7f06005f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_tint = 0x7f060060;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_dark = 0x7f060061;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_light = 0x7f060062;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_dark = 0x7f060063;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_light = 0x7f060064;

        /* JADX INFO: Added by JADX */
        public static final int dtx_store_promo_bg_fade = 0x7f060065;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_dark = 0x7f060066;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_light = 0x7f060067;

        /* JADX INFO: Added by JADX */
        public static final int exo_black_opacity_60 = 0x7f060068;

        /* JADX INFO: Added by JADX */
        public static final int exo_black_opacity_70 = 0x7f060069;

        /* JADX INFO: Added by JADX */
        public static final int exo_bottom_bar_background = 0x7f06006a;

        /* JADX INFO: Added by JADX */
        public static final int exo_edit_mode_background_color = 0x7f06006b;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_background_color = 0x7f06006c;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_error_message_background = 0x7f06006d;

        /* JADX INFO: Added by JADX */
        public static final int exo_white = 0x7f06006e;

        /* JADX INFO: Added by JADX */
        public static final int exo_white_opacity_70 = 0x7f06006f;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_dark = 0x7f060070;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_light = 0x7f060071;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_dark = 0x7f060072;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_light = 0x7f060073;

        /* JADX INFO: Added by JADX */
        public static final int ia_blank_background = 0x7f060074;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_rewarded_button_background_color = 0x7f060075;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_rewarded_button_color = 0x7f060076;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_rewarded_dialog_background = 0x7f060077;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_rewarded_sub_title_color = 0x7f060078;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_rewarded_title_color = 0x7f060079;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_background = 0x7f06007a;

        /* JADX INFO: Added by JADX */
        public static final int ia_fullscreen_background = 0x7f06007b;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_accent = 0x7f06007c;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_identifier_bg_color = 0x7f06007d;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_white = 0x7f06007e;

        /* JADX INFO: Added by JADX */
        public static final int ia_mraid_expanded_dimmed_bk = 0x7f06007f;

        /* JADX INFO: Added by JADX */
        public static final int ia_overlay_bg_color = 0x7f060080;

        /* JADX INFO: Added by JADX */
        public static final int ia_overlay_stroke_color = 0x7f060081;

        /* JADX INFO: Added by JADX */
        public static final int ia_transparent_background = 0x7f060082;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_background_color = 0x7f060083;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_stroke = 0x7f060084;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text = 0x7f060085;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_background = 0x7f060086;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_background_pressed = 0x7f060087;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_shadow = 0x7f060088;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_progressbar = 0x7f060089;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_progressbar_background = 0x7f06008a;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_progressbar_green = 0x7f06008b;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_transparent_overlay = 0x7f06008c;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_800 = 0x7f06008d;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_900 = 0x7f06008e;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_950 = 0x7f06008f;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_200 = 0x7f060090;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_500 = 0x7f060091;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_100 = 0x7f060092;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_300 = 0x7f060093;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_50 = 0x7f060094;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_600 = 0x7f060095;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_800 = 0x7f060096;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_850 = 0x7f060097;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_900 = 0x7f060098;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_black = 0x7f060099;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_black_66 = 0x7f06009a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_black_alpha_50 = 0x7f06009b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_chice_bg_pressed = 0x7f06009c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_rb_text_color_color_list = 0x7f06009d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_color_999999 = 0x7f06009e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_color_cc000000 = 0x7f06009f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_color_cc0000001 = 0x7f0600a0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_common_white = 0x7f0600a1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_blue = 0x7f0600a2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_blue_dark = 0x7f0600a3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_green = 0x7f0600a4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_green_dark = 0x7f0600a5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_grey = 0x7f0600a6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_red = 0x7f0600a7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_red_dark = 0x7f0600a8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cpb_white = 0x7f0600a9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_dd_grey = 0x7f0600aa;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_ee_grey = 0x7f0600ab;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_black = 0x7f0600ac;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_white = 0x7f0600ad;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_more_offer_list_bg = 0x7f0600ae;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_txt_nor = 0x7f0600af;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_txt_pre = 0x7f0600b0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_land_cta_bg_nor = 0x7f0600b1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_por_cta_bg_nor = 0x7f0600b2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_por_cta_bg_pre = 0x7f0600b3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound_bg = 0x7f0600b4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_purple_200 = 0x7f0600b5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_purple_500 = 0x7f0600b6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_purple_700 = 0x7f0600b7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_black = 0x7f0600b8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_cta_bg = 0x7f0600b9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_desc_textcolor = 0x7f0600ba;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_hor_bg = 0x7f0600bb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_land_bg = 0x7f0600bc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_line_bg = 0x7f0600bd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_vast_bg = 0x7f0600be;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_kiloo_background = 0x7f0600bf;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_text_bg = 0x7f0600c0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_minicard_bg = 0x7f0600c1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_six_black_transparent = 0x7f0600c2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_six_black_transparent1 = 0x7f0600c3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_six_black_transparent2 = 0x7f0600c4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_title_textcolor = 0x7f0600c5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_white = 0x7f0600c6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_count_time_skip_text_color = 0x7f0600c7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_teal_200 = 0x7f0600c8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_teal_700 = 0x7f0600c9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_bg = 0x7f0600ca;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_cancel_button_bg_default = 0x7f0600cb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_cancel_button_bg_pressed = 0x7f0600cc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_cancel_button_textcolor = 0x7f0600cd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_confirm_button_bg_default = 0x7f0600ce;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_confirm_button_bg_pressed = 0x7f0600cf;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_confirm_button_textcolor = 0x7f0600d0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_content_textcolor = 0x7f0600d1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_feedback_rb_bg = 0x7f0600d2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_title_textcolor = 0x7f0600d3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_white = 0x7f0600d4;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 0x7f0600d5;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 0x7f0600d6;

        /* JADX INFO: Added by JADX */
        public static final int notification_material_background_media_default_color = 0x7f0600d7;

        /* JADX INFO: Added by JADX */
        public static final int pink = 0x7f0600d8;

        /* JADX INFO: Added by JADX */
        public static final int preference_fallback_accent_color = 0x7f0600d9;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_dark = 0x7f0600da;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_light = 0x7f0600db;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_dark = 0x7f0600dc;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_light = 0x7f0600dd;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_dark = 0x7f0600de;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_light = 0x7f0600df;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_dark = 0x7f0600e0;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_light = 0x7f0600e1;

        /* JADX INFO: Added by JADX */
        public static final int red = 0x7f0600e2;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_dark = 0x7f0600e3;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_light = 0x7f0600e4;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_dark = 0x7f0600e5;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_light = 0x7f0600e6;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_dark = 0x7f0600e7;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_light = 0x7f0600e8;

        /* JADX INFO: Added by JADX */
        public static final int staticSplashScreenBackgroundColor = 0x7f0600e9;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_dark = 0x7f0600ea;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_light = 0x7f0600eb;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_dark = 0x7f0600ec;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_light = 0x7f0600ed;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_dark = 0x7f0600ee;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_light = 0x7f0600ef;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_dark = 0x7f0600f0;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_light = 0x7f0600f1;

        /* JADX INFO: Added by JADX */
        public static final int tt_000000 = 0x7f0600f2;

        /* JADX INFO: Added by JADX */
        public static final int tt_00000000 = 0x7f0600f3;

        /* JADX INFO: Added by JADX */
        public static final int tt_1e000000 = 0x7f0600f4;

        /* JADX INFO: Added by JADX */
        public static final int tt_2a90d7 = 0x7f0600f5;

        /* JADX INFO: Added by JADX */
        public static final int tt_4a90e2 = 0x7f0600f6;

        /* JADX INFO: Added by JADX */
        public static final int tt_72000000 = 0x7f0600f7;

        /* JADX INFO: Added by JADX */
        public static final int tt_7f2a90d7 = 0x7f0600f8;

        /* JADX INFO: Added by JADX */
        public static final int tt_88000000 = 0x7f0600f9;

        /* JADX INFO: Added by JADX */
        public static final int tt_b2000000 = 0x7f0600fa;

        /* JADX INFO: Added by JADX */
        public static final int tt_bf161823 = 0x7f0600fb;

        /* JADX INFO: Added by JADX */
        public static final int tt_e0e0e0 = 0x7f0600fc;

        /* JADX INFO: Added by JADX */
        public static final int tt_e4ffffff = 0x7f0600fd;

        /* JADX INFO: Added by JADX */
        public static final int tt_fde6e6e6 = 0x7f0600fe;

        /* JADX INFO: Added by JADX */
        public static final int tt_fdffffff = 0x7f0600ff;

        /* JADX INFO: Added by JADX */
        public static final int tt_ff1a1a1a = 0x7f060100;

        /* JADX INFO: Added by JADX */
        public static final int tt_ffffff = 0x7f060101;

        /* JADX INFO: Added by JADX */
        public static final int vector_tint_color = 0x7f060102;

        /* JADX INFO: Added by JADX */
        public static final int vector_tint_theme_color = 0x7f060103;

        /* JADX INFO: Added by JADX */
        public static final int white = 0x7f060104;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenAnimatedIconColor = 0x7f060105;

        /* JADX INFO: Added by JADX */
        public static final int windowSplashScreenIconBackgroundColor = 0x7f060106;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_card_background = 0x7f060107;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_cashier_color_text = 0x7f060108;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_colorAccent = 0x7f060109;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_colorProgress = 0x7f06010a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_colorProgressDefault = 0x7f06010b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_colorRed = 0x7f06010c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_green = 0x7f06010d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_black = 0x7f06010e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_blue = 0x7f06010f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_gray = 0x7f060110;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_green = 0x7f060111;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_outline = 0x7f060112;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_red = 0x7f060113;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_test_background_color = 0x7f060114;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_test_background_color_2 = 0x7f060115;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_white = 0x7f060116;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_lite_blue = 0x7f060117;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_privacy_dialog_button_default = 0x7f060118;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_privacy_dialog_rangebar_default = 0x7f060119;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_dialog_layout_dark_default = 0x7f06011a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsbColorThumbBorder = 0x7f06011b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsbColorThumbDefault = 0x7f06011c;
    }

    /* JADX INFO: Added by JADX */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_material = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_height_material = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_elevation_material = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_max_height = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_height_material = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_material = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_dimen = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_horizontal_material = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_vertical_material = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_horizontal_material = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_vertical_material = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_prefDialogWidth = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_corner_material = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_inset_material = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_padding_material = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_corner_radius_material = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_major = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_minor = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_major = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_minor = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_major = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_minor = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_material = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_top_material = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_divider_material = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_dark = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_light = 0x7f070028;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_icon_width = 0x7f070029;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 0x7f07002a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 0x7f07002d;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_top_material = 0x7f07002e;

        /* JADX INFO: Added by JADX */
        public static final int abc_floating_window_z = 0x7f07002f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_large_material = 0x7f070030;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_material = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_small_material = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 0x7f070033;

        /* JADX INFO: Added by JADX */
        public static final int abc_panel_menu_list_width = 0x7f070034;

        /* JADX INFO: Added by JADX */
        public static final int abc_progress_bar_height_material = 0x7f070035;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_height = 0x7f070036;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_width = 0x7f070037;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_background_height_material = 0x7f070038;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 0x7f070039;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_padding_start_material = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_big = 0x7f07003b;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_medium = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_small = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_padding = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_1_material = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_2_material = 0x7f070040;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_button_material = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_caption_material = 0x7f070042;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_1_material = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_2_material = 0x7f070044;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_3_material = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_4_material = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_headline_material = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_large_material = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_medium_material = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_header_material = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_material = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_small_material = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subhead_material = 0x7f07004d;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 0x7f07004e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material = 0x7f07004f;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material_toolbar = 0x7f070050;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_ad_indicator_height = 0x7f070051;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_ad_indicator_text_size = 0x7f070052;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_ad_indicator_width = 0x7f070053;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_default_margin = 0x7f070054;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_large_margin = 0x7f070055;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_medium_cta_button_height = 0x7f070056;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_medium_margin = 0x7f070057;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_no_margin = 0x7f070058;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_small_cta_button_height = 0x7f070059;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_test_size_small = 0x7f07005a;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_text_size_large = 0x7f07005b;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_text_size_medium = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_actionBarHeight = 0x7f07005d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_adControlButton_height = 0x7f07005e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_adControlButton_width = 0x7f07005f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_mediationDebuggerDetailListItemTextSize = 0x7f070060;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_mediationDebuggerSectionHeight = 0x7f070061;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_mediationDebuggerSectionTextSize = 0x7f070062;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_mrec_height = 0x7f070063;

        /* JADX INFO: Added by JADX */
        public static final int applovin_sdk_mrec_width = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_replay_size = 0x7f070065;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_volume_padding = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_volume_size = 0x7f070067;

        /* JADX INFO: Added by JADX */
        public static final int bm_bottom_sheet_round_radius = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_max_width = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_min_padding = 0x7f07006a;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 0x7f07006c;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 0x7f07006e;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 0x7f07006f;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 0x7f070070;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 0x7f070071;

        /* JADX INFO: Added by JADX */
        public static final int default_margin = 0x7f070072;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_dark = 0x7f070073;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_light = 0x7f070074;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_height = 0x7f070075;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_margin_bottom = 0x7f070076;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_text_padding_horizontal = 0x7f070077;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_text_padding_vertical = 0x7f070078;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message_text_size = 0x7f070079;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_horizontal_margin = 0x7f07007a;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_padding = 0x7f07007b;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_padding_bottom = 0x7f07007c;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_size = 0x7f07007d;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_text_size = 0x7f07007e;

        /* JADX INFO: Added by JADX */
        public static final int exo_media_button_height = 0x7f07007f;

        /* JADX INFO: Added by JADX */
        public static final int exo_media_button_width = 0x7f070080;

        /* JADX INFO: Added by JADX */
        public static final int exo_setting_width = 0x7f070081;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_height = 0x7f070082;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_icon_size = 0x7f070083;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_main_text_size = 0x7f070084;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_offset = 0x7f070085;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_sub_text_size = 0x7f070086;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_text_height = 0x7f070087;

        /* JADX INFO: Added by JADX */
        public static final int exo_small_icon_height = 0x7f070088;

        /* JADX INFO: Added by JADX */
        public static final int exo_small_icon_horizontal_margin = 0x7f070089;

        /* JADX INFO: Added by JADX */
        public static final int exo_small_icon_padding_horizontal = 0x7f07008a;

        /* JADX INFO: Added by JADX */
        public static final int exo_small_icon_padding_vertical = 0x7f07008b;

        /* JADX INFO: Added by JADX */
        public static final int exo_small_icon_width = 0x7f07008c;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_bottom_bar_height = 0x7f07008d;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_bottom_bar_margin_top = 0x7f07008e;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_bottom_bar_time_padding = 0x7f07008f;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_padding = 0x7f070090;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_minimal_controls_margin_bottom = 0x7f070091;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_bar_height = 0x7f070092;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_dragged_thumb_size = 0x7f070093;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_enabled_thumb_size = 0x7f070094;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_layout_height = 0x7f070095;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_margin_bottom = 0x7f070096;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_progress_touch_target_height = 0x7f070097;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_default_thickness = 0x7f070098;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_margin = 0x7f070099;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_minimum_range = 0x7f07009a;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_colored = 0x7f07009b;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_dark = 0x7f07009c;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_light = 0x7f07009d;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_dark = 0x7f07009e;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_light = 0x7f07009f;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_dark = 0x7f0700a0;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_light = 0x7f0700a1;

        /* JADX INFO: Added by JADX */
        public static final int ia_bg_corner_radius = 0x7f0700a2;

        /* JADX INFO: Added by JADX */
        public static final int ia_button_padding_lateral = 0x7f0700a3;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_button_margin_bottom = 0x7f0700a4;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_button_padding_vertical = 0x7f0700a5;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_overlay_button_height_large = 0x7f0700a6;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_overlay_button_height_medium = 0x7f0700a7;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_overlay_button_width_large = 0x7f0700a8;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_overlay_button_width_medium = 0x7f0700a9;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_image_height = 0x7f0700aa;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_image_width = 0x7f0700ab;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_layout_height = 0x7f0700ac;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_layout_width = 0x7f0700ad;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_overlay_margin_bottom = 0x7f0700ae;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_overlay_margin_left = 0x7f0700af;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_padding = 0x7f0700b0;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_text_height = 0x7f0700b1;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_text_text_size = 0x7f0700b2;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_text_width = 0x7f0700b3;

        /* JADX INFO: Added by JADX */
        public static final int ia_image_control_padding = 0x7f0700b4;

        /* JADX INFO: Added by JADX */
        public static final int ia_image_control_size = 0x7f0700b5;

        /* JADX INFO: Added by JADX */
        public static final int ia_inner_drawable_padding = 0x7f0700b6;

        /* JADX INFO: Added by JADX */
        public static final int ia_overlay_control_margin = 0x7f0700b7;

        /* JADX INFO: Added by JADX */
        public static final int ia_overlay_stroke_width = 0x7f0700b8;

        /* JADX INFO: Added by JADX */
        public static final int ia_play_button_size = 0x7f0700b9;

        /* JADX INFO: Added by JADX */
        public static final int ia_progress_bar_height = 0x7f0700ba;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_control_padding = 0x7f0700bb;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_control_size = 0x7f0700bc;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_control_size_clickable = 0x7f0700bd;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_overlay_radius = 0x7f0700be;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_control_margin = 0x7f0700bf;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_button_width = 0x7f0700c0;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_cta_button_height = 0x7f0700c1;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_cta_button_margin = 0x7f0700c2;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_cta_button_padding = 0x7f0700c3;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_cta_button_width = 0x7f0700c4;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_margin_bottom = 0x7f0700c5;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_large = 0x7f0700c6;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_large_for_cta = 0x7f0700c7;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_large_plus = 0x7f0700c8;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_small = 0x7f0700c9;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_text_padding = 0x7f0700ca;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f0700cb;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_max_velocity = 0x7f0700cc;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_velocity = 0x7f0700cd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_bg_padding = 0x7f0700ce;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_button_height = 0x7f0700cf;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_button_margintop = 0x7f0700d0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_button_radius = 0x7f0700d1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_button_textsize = 0x7f0700d2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_button_width = 0x7f0700d3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_content_margintop = 0x7f0700d4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_content_size = 0x7f0700d5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_contentview_maxwidth = 0x7f0700d6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_contentview_minwidth = 0x7f0700d7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_title_size = 0x7f0700d8;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 0x7f0700d9;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 0x7f0700da;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 0x7f0700db;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 0x7f0700dc;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 0x7f0700dd;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 0x7f0700de;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 0x7f0700df;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 0x7f0700e0;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 0x7f0700e1;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 0x7f0700e2;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 0x7f0700e3;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 0x7f0700e4;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 0x7f0700e5;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 0x7f0700e6;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 0x7f0700e7;

        /* JADX INFO: Added by JADX */
        public static final int preference_dropdown_padding_start = 0x7f0700e8;

        /* JADX INFO: Added by JADX */
        public static final int preference_icon_minWidth = 0x7f0700e9;

        /* JADX INFO: Added by JADX */
        public static final int preference_seekbar_padding_horizontal = 0x7f0700ea;

        /* JADX INFO: Added by JADX */
        public static final int preference_seekbar_padding_vertical = 0x7f0700eb;

        /* JADX INFO: Added by JADX */
        public static final int preference_seekbar_value_minWidth = 0x7f0700ec;

        /* JADX INFO: Added by JADX */
        public static final int text_margin = 0x7f0700ed;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_corner_radius = 0x7f0700ee;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_horizontal_padding = 0x7f0700ef;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_margin = 0x7f0700f0;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 0x7f0700f1;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_threshold = 0x7f0700f2;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_vertical_padding = 0x7f0700f3;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_non_touch = 0x7f0700f4;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_touch = 0x7f0700f5;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_bar_height = 0x7f0700f6;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_bottom_margin = 0x7f0700f7;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_height = 0x7f0700f8;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_text_size = 0x7f0700f9;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_top_margin = 0x7f0700fa;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_ad_indicator_width = 0x7f0700fb;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_default_margin = 0x7f0700fc;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_media_view_weight = 0x7f0700fd;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_medium_cta_button_height = 0x7f0700fe;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_medium_template_bottom_weight = 0x7f0700ff;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_medium_template_top_weight = 0x7f070100;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_no_margin = 0x7f070101;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_no_size = 0x7f070102;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_small_cta_button_height = 0x7f070103;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_small_margin = 0x7f070104;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_text_row_weight = 0x7f070105;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_text_size_large = 0x7f070106;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_text_size_small = 0x7f070107;
    }

    /* JADX INFO: Added by JADX */
    public static final class drawable {

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_mute_to_unmute__0_res_0x7f080000 = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_mute_to_unmute__1_res_0x7f080001 = 0x7f080001;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_mute_to_unmute__2_res_0x7f080002 = 0x7f080002;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_mute_to_unmute__3_res_0x7f080003 = 0x7f080003;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_mute_to_unmute__4_res_0x7f080004 = 0x7f080004;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_unmute_to_mute__0_res_0x7f080005 = 0x7f080005;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_unmute_to_mute__1_res_0x7f080006 = 0x7f080006;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_unmute_to_mute__2_res_0x7f080007 = 0x7f080007;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_unmute_to_mute__3_res_0x7f080008 = 0x7f080008;

        /* JADX INFO: Added by JADX */
        public static final int _applovin_ic_unmute_to_mute__4_res_0x7f080009 = 0x7f080009;

        /* JADX INFO: Added by JADX */
        public static final int abc_ab_share_pack_mtrl_alpha = 0x7f08000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_item_background_material = 0x7f08000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_borderless_material = 0x7f08000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material = 0x7f08000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material_anim = 0x7f08000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_to_on_mtrl_000 = 0x7f08000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_to_on_mtrl_015 = 0x7f080010;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_material = 0x7f080011;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_default_mtrl_shape = 0x7f080012;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material = 0x7f080013;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material_anim = 0x7f080014;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_000 = 0x7f080015;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_015 = 0x7f080016;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00001 = 0x7f080017;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00012 = 0x7f080018;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_internal_bg = 0x7f080019;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_material = 0x7f08001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_mtrl_alpha = 0x7f08001b;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_background_material = 0x7f08001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_material_background = 0x7f08001d;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_material = 0x7f08001e;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_ab_back_material = 0x7f08001f;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 0x7f080020;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_clear_material = 0x7f080021;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_commit_search_api_mtrl_alpha = 0x7f080022;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_go_search_api_material = 0x7f080023;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f080024;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f080025;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_overflow_material = 0x7f080026;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f080027;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f080028;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f080029;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_search_api_material = 0x7f08002a;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_voice_search_api_material = 0x7f08002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_dark = 0x7f08002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_light = 0x7f08002d;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_material = 0x7f08002e;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_mtrl_alpha = 0x7f08002f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_focused_holo = 0x7f080030;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_longpressed_holo = 0x7f080031;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_pressed_holo_dark = 0x7f080032;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_pressed_holo_light = 0x7f080033;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f080034;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 0x7f080035;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_disabled_holo_dark = 0x7f080036;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_disabled_holo_light = 0x7f080037;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_dark = 0x7f080038;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_light = 0x7f080039;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_hardkey_panel_mtrl_mult = 0x7f08003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_background_mtrl_mult = 0x7f08003b;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_indicator_material = 0x7f08003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_material = 0x7f08003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_small_material = 0x7f08003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_off_mtrl_alpha = 0x7f08003f;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 0x7f080040;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 0x7f080041;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_primary_mtrl_alpha = 0x7f080042;

        /* JADX INFO: Added by JADX */
        public static final int abc_scrubber_track_mtrl_alpha = 0x7f080043;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_thumb_material = 0x7f080044;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_tick_mark_material = 0x7f080045;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_material = 0x7f080046;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_mtrl_am_alpha = 0x7f080047;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_textfield_background_material = 0x7f080048;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_black_48dp = 0x7f080049;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_half_black_48dp = 0x7f08004a;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_thumb_material = 0x7f08004b;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_track_mtrl_alpha = 0x7f08004c;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_material = 0x7f08004d;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_mtrl_alpha = 0x7f08004e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_cursor_material = 0x7f08004f;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_left_mtrl = 0x7f080050;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_middle_mtrl = 0x7f080051;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_select_handle_right_mtrl = 0x7f080052;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_activated_mtrl_alpha = 0x7f080053;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_default_mtrl_alpha = 0x7f080054;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_activated_mtrl_alpha = 0x7f080055;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_default_mtrl_alpha = 0x7f080056;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_material = 0x7f080057;

        /* JADX INFO: Added by JADX */
        public static final int abc_vector_test = 0x7f080058;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_outline_shape = 0x7f080059;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_rounded_button_shape = 0x7f08005a;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_rounded_corners_shape = 0x7f08005b;

        /* JADX INFO: Added by JADX */
        public static final int admob_close_button_black_circle_white_cross = 0x7f08005c;

        /* JADX INFO: Added by JADX */
        public static final int admob_close_button_white_circle_black_cross = 0x7f08005d;

        /* JADX INFO: Added by JADX */
        public static final int admob_close_button_white_cross = 0x7f08005e;

        /* JADX INFO: Added by JADX */
        public static final int ah_bg_gradient = 0x7f08005f;

        /* JADX INFO: Added by JADX */
        public static final int ah_ic_check = 0x7f080060;

        /* JADX INFO: Added by JADX */
        public static final int ah_ic_error = 0x7f080061;

        /* JADX INFO: Added by JADX */
        public static final int ah_ic_warning = 0x7f080062;

        /* JADX INFO: Added by JADX */
        public static final int ah_switch = 0x7f080063;

        /* JADX INFO: Added by JADX */
        public static final int ah_white_rounded_corners_shape = 0x7f080064;

        /* JADX INFO: Added by JADX */
        public static final int applovin_creative_debugger_report_ad_rounded_button = 0x7f080065;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_baseline_add_circle_outline = 0x7f080066;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_check_mark_bordered = 0x7f080067;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_check_mark_borderless = 0x7f080068;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_disclosure_arrow = 0x7f080069;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_adjoe = 0x7f08006a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_admob = 0x7f08006b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_amazon_marketplace = 0x7f08006c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_applovin = 0x7f08006d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_bidmachine = 0x7f08006e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_bigo = 0x7f08006f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_chartboost = 0x7f080070;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_facebook = 0x7f080071;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_fyber = 0x7f080072;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_google_ad_manager = 0x7f080073;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_inmobi = 0x7f080074;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_ironsource = 0x7f080075;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_line = 0x7f080076;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_mintegral = 0x7f080077;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_mobilefuse = 0x7f080078;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_moloco = 0x7f080079;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_mytarget = 0x7f08007a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_ogury_presage = 0x7f08007b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_pangle = 0x7f08007c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_placeholder = 0x7f08007d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_pubmatic = 0x7f08007e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_smaato = 0x7f08007f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_tiktok = 0x7f080080;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_unity = 0x7f080081;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_verve = 0x7f080082;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_vungle = 0x7f080083;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_yandex = 0x7f080084;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mediation_yso = 0x7f080085;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_mute_to_unmute = 0x7f080086;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_pause_icon = 0x7f080087;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_play_icon = 0x7f080088;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_privacy_icon = 0x7f080089;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_privacy_icon_layered_list = 0x7f08008a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_replay_icon = 0x7f08008b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_unmute_to_mute = 0x7f08008c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_warning = 0x7f08008d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_warning_outline = 0x7f08008e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_white_small = 0x7f08008f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_ic_x_mark = 0x7f080090;

        /* JADX INFO: Added by JADX */
        public static final int applovin_mediation_debugger_switch_thumb = 0x7f080091;

        /* JADX INFO: Added by JADX */
        public static final int applovin_mediation_debugger_switch_track = 0x7f080092;

        /* JADX INFO: Added by JADX */
        public static final int applovin_rounded_black_background = 0x7f080093;

        /* JADX INFO: Added by JADX */
        public static final int applovin_rounded_button = 0x7f080094;

        /* JADX INFO: Added by JADX */
        public static final int applovin_rounded_text_view_border = 0x7f080095;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_advertiser_background = 0x7f080096;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_arrow_right = 0x7f080097;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_advertiser_background = 0x7f080098;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_button_bg_rectangle_blue = 0x7f080099;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_clickguide = 0x7f08009a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_bg_ad_tag_white_border = 0x7f08009b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_bg_mask = 0x7f08009c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_background = 0x7f08009d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_background_white = 0x7f08009e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_background_white_dark = 0x7f08009f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_bg_circle_grey = 0x7f0800a0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_bg_rectangle_blue = 0x7f0800a1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_bg_rectangle_blue_2 = 0x7f0800a2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_bg_rectangle_green = 0x7f0800a3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_bg_rectangle_green_radius8 = 0x7f0800a4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_countdown_close = 0x7f0800a5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_button_stroke_circle_white = 0x7f0800a6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_cardview_bg = 0x7f0800a7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_guide = 0x7f0800a8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_guide2 = 0x7f0800a9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_guide_landscape = 0x7f0800aa;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_guide_shadow = 0x7f0800ab;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_ripple = 0x7f0800ac;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_close_btn_background = 0x7f0800ad;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_default_base_image = 0x7f0800ae;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_default_progressbar = 0x7f0800af;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_domain_left_drawable = 0x7f0800b0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_double_video_play = 0x7f0800b1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_double_video_small_play = 0x7f0800b2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_edit_background = 0x7f0800b3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_edit_background_dark = 0x7f0800b4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feeback_arrow_right = 0x7f0800b5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_advertise_info_background = 0x7f0800b6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_background = 0x7f0800b7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_top_slide_bar = 0x7f0800b8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_flash = 0x7f0800b9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_icon_back_up = 0x7f0800ba;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_gift_widget = 0x7f0800bb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_gradual_background = 0x7f0800bc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_grey_btn_background = 0x7f0800bd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_heart_widget = 0x7f0800be;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_ad_label = 0x7f0800bf;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_arrow_down = 0x7f0800c0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_arrow_right = 0x7f0800c1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_back_gray = 0x7f0800c2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close = 0x7f0800c3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close2 = 0x7f0800c4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close3 = 0x7f0800c5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close4 = 0x7f0800c6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close5 = 0x7f0800c7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close_gray = 0x7f0800c8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_close_gray_light = 0x7f0800c9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_download = 0x7f0800ca;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_download_box = 0x7f0800cb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_download_box_white = 0x7f0800cc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_everyone = 0x7f0800cd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_everyone_ic_info = 0x7f0800ce;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_everyone_white = 0x7f0800cf;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_info = 0x7f0800d0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_info_gray = 0x7f0800d1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_info_popup = 0x7f0800d2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_info_white = 0x7f0800d3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_left_round_black = 0x7f0800d4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_left_round_white = 0x7f0800d5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_loading_gp = 0x7f0800d6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_media_mute = 0x7f0800d7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_media_pause = 0x7f0800d8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_media_play = 0x7f0800d9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_media_unmute = 0x7f0800da;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_phone = 0x7f0800db;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_phone_white = 0x7f0800dc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_recommend = 0x7f0800dd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_recommend_white = 0x7f0800de;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_right_black = 0x7f0800df;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_right_round_black = 0x7f0800e0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_right_round_white = 0x7f0800e1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_right_white = 0x7f0800e2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_safe = 0x7f0800e3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star = 0x7f0800e4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star2 = 0x7f0800e5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star2_white = 0x7f0800e6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star_half = 0x7f0800e7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star_half_white = 0x7f0800e8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star_normal = 0x7f0800e9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star_normal_white = 0x7f0800ea;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_star_white = 0x7f0800eb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web = 0x7f0800ec;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_back = 0x7f0800ed;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_back_disable = 0x7f0800ee;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_copy = 0x7f0800ef;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_forward = 0x7f0800f0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_forward_enable = 0x7f0800f1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_open_browser = 0x7f0800f2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_refresh = 0x7f0800f3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web_white = 0x7f0800f4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_background = 0x7f0800f5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_background_dark = 0x7f0800f6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_default = 0x7f0800f7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_default_img = 0x7f0800f8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_default_only_icon = 0x7f0800f9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_default_radius22 = 0x7f0800fa;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_default_radius6 = 0x7f0800fb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_icon_novideo_default = 0x7f0800fc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_animation_bg = 0x7f0800fd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_shake_arrow = 0x7f0800fe;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_shake_landscape_phone = 0x7f0800ff;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_shake_phone = 0x7f080100;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_slide_hand = 0x7f080101;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_slide_line = 0x7f080102;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_twist_arrow = 0x7f080103;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_twist_landscape_phone = 0x7f080104;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_twist_phone = 0x7f080105;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interstitial_landscape_ad_info_bg = 0x7f080106;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interstitial_rich_video_end_landscape_mask = 0x7f080107;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_label_advertiser_background_raduis7 = 0x7f080108;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_label_background = 0x7f080109;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_landing_bottom_bar_bg = 0x7f08010a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_landing_progress_bar = 0x7f08010b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_landing_top_bar_bg = 0x7f08010c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_landing_top_indicator = 0x7f08010d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_landscape_slide_view = 0x7f08010e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layer_gift_color = 0x7f08010f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layer_gift_shadow = 0x7f080110;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layer_heart_color = 0x7f080111;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layer_heart_shadow = 0x7f080112;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_mid_page_ic_gp_right = 0x7f080113;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_multi_img_advertiser_background = 0x7f080114;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_multi_img_horizontal_mask = 0x7f080115;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_multi_img_vertical_mask = 0x7f080116;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_popup_ad_info_background = 0x7f080117;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_progressbar_white = 0x7f080118;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ru_background = 0x7f080119;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_slide = 0x7f08011a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_slide_gesture = 0x7f08011b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_bg = 0x7f08011c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_slide_bg = 0x7f08011d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_header_bg = 0x7f08011e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_star_icon = 0x7f08011f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_success = 0x7f080120;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_background = 0x7f080121;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_top_left_advertiser_background = 0x7f080122;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_ripple = 0x7f080123;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_warning_background_radius8 = 0x7f080124;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_web_loading_progress_bar = 0x7f080125;

        /* JADX INFO: Added by JADX */
        public static final int bm_bg_privacy_button = 0x7f080126;

        /* JADX INFO: Added by JADX */
        public static final int bm_bg_privacy_divider = 0x7f080127;

        /* JADX INFO: Added by JADX */
        public static final int bm_bg_privacy_sheet = 0x7f080128;

        /* JADX INFO: Added by JADX */
        public static final int bm_bg_ripple_circle = 0x7f080129;

        /* JADX INFO: Added by JADX */
        public static final int bm_ic_close = 0x7f08012a;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl = 0x7f08012b;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 0x7f08012c;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 0x7f08012d;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 0x7f08012e;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_mtrl = 0x7f08012f;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 0x7f080130;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_mtrl = 0x7f080131;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 0x7f080132;

        /* JADX INFO: Added by JADX */
        public static final int btn_yodo1_close = 0x7f080133;

        /* JADX INFO: Added by JADX */
        public static final int common_full_open_on_phone = 0x7f080134;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark = 0x7f080135;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_focused = 0x7f080136;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_normal = 0x7f080137;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_normal_background = 0x7f080138;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_disabled = 0x7f080139;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light = 0x7f08013a;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_focused = 0x7f08013b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_normal = 0x7f08013c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_normal_background = 0x7f08013d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f08013e;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f08013f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_normal = 0x7f080140;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_normal_background = 0x7f080141;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_disabled = 0x7f080142;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f080143;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f080144;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_normal = 0x7f080145;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_normal_background = 0x7f080146;

        /* JADX INFO: Added by JADX */
        public static final int dashboard_selected_tab_bg = 0x7f080147;

        /* JADX INFO: Added by JADX */
        public static final int dashboard_tab_layout_bg = 0x7f080148;

        /* JADX INFO: Added by JADX */
        public static final int double_arrow_24 = 0x7f080149;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fastforward = 0x7f08014a;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fullscreen_enter = 0x7f08014b;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fullscreen_exit = 0x7f08014c;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_next = 0x7f08014d;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_pause = 0x7f08014e;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_play = 0x7f08014f;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_previous = 0x7f080150;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_all = 0x7f080151;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_off = 0x7f080152;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_one = 0x7f080153;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_rewind = 0x7f080154;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_shuffle_off = 0x7f080155;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_shuffle_on = 0x7f080156;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_vr = 0x7f080157;

        /* JADX INFO: Added by JADX */
        public static final int exo_edit_mode_logo = 0x7f080158;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_audiotrack = 0x7f080159;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_check = 0x7f08015a;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_chevron_left = 0x7f08015b;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_chevron_right = 0x7f08015c;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_default_album_image = 0x7f08015d;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_forward = 0x7f08015e;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_fullscreen_enter = 0x7f08015f;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_fullscreen_exit = 0x7f080160;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_pause_circle_filled = 0x7f080161;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_play_circle_filled = 0x7f080162;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_rewind = 0x7f080163;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_settings = 0x7f080164;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_skip_next = 0x7f080165;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_skip_previous = 0x7f080166;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_speed = 0x7f080167;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_subtitle_off = 0x7f080168;

        /* JADX INFO: Added by JADX */
        public static final int exo_ic_subtitle_on = 0x7f080169;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_circular_play = 0x7f08016a;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_fastforward = 0x7f08016b;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_fullscreen_enter = 0x7f08016c;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_fullscreen_exit = 0x7f08016d;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_next = 0x7f08016e;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_pause = 0x7f08016f;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_play = 0x7f080170;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_previous = 0x7f080171;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_repeat_all = 0x7f080172;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_repeat_off = 0x7f080173;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_repeat_one = 0x7f080174;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_rewind = 0x7f080175;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_shuffle_off = 0x7f080176;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_shuffle_on = 0x7f080177;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_stop = 0x7f080178;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon_vr = 0x7f080179;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_fastforward = 0x7f08017a;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_fullscreen_enter = 0x7f08017b;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_fullscreen_exit = 0x7f08017c;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_next = 0x7f08017d;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_pause = 0x7f08017e;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_play = 0x7f08017f;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_previous = 0x7f080180;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_repeat_all = 0x7f080181;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_repeat_off = 0x7f080182;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_repeat_one = 0x7f080183;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_rewind = 0x7f080184;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_shuffle_off = 0x7f080185;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_shuffle_on = 0x7f080186;

        /* JADX INFO: Added by JADX */
        public static final int exo_legacy_controls_vr = 0x7f080187;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_fastforward = 0x7f080188;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_next = 0x7f080189;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_pause = 0x7f08018a;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_play = 0x7f08018b;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_previous = 0x7f08018c;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_rewind = 0x7f08018d;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_small_icon = 0x7f08018e;

        /* JADX INFO: Added by JADX */
        public static final int exo_notification_stop = 0x7f08018f;

        /* JADX INFO: Added by JADX */
        public static final int exo_rounded_rectangle = 0x7f080190;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_audiotrack = 0x7f080191;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_check = 0x7f080192;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_fastforward = 0x7f080193;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_fullscreen_enter = 0x7f080194;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_fullscreen_exit = 0x7f080195;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_next = 0x7f080196;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_overflow_hide = 0x7f080197;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_overflow_show = 0x7f080198;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_pause = 0x7f080199;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_play = 0x7f08019a;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_previous = 0x7f08019b;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_repeat_all = 0x7f08019c;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_repeat_off = 0x7f08019d;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_repeat_one = 0x7f08019e;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_rewind = 0x7f08019f;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_settings = 0x7f0801a0;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_shuffle_off = 0x7f0801a1;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_shuffle_on = 0x7f0801a2;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_simple_fastforward = 0x7f0801a3;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_simple_rewind = 0x7f0801a4;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_speed = 0x7f0801a5;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_subtitle_off = 0x7f0801a6;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_subtitle_on = 0x7f0801a7;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_controls_vr = 0x7f0801a8;

        /* JADX INFO: Added by JADX */
        public static final int googleg_disabled_color_18 = 0x7f0801a9;

        /* JADX INFO: Added by JADX */
        public static final int googleg_standard_color_18 = 0x7f0801aa;

        /* JADX INFO: Added by JADX */
        public static final int ia_bg_circle_overlay = 0x7f0801ab;

        /* JADX INFO: Added by JADX */
        public static final int ia_bg_green = 0x7f0801ac;

        /* JADX INFO: Added by JADX */
        public static final int ia_bg_text_overlay = 0x7f0801ad;

        /* JADX INFO: Added by JADX */
        public static final int ia_circle_overlay_bg = 0x7f0801ae;

        /* JADX INFO: Added by JADX */
        public static final int ia_close = 0x7f0801af;

        /* JADX INFO: Added by JADX */
        public static final int ia_collapse = 0x7f0801b0;

        /* JADX INFO: Added by JADX */
        public static final int ia_digital_turbine_logo = 0x7f0801b1;

        /* JADX INFO: Added by JADX */
        public static final int ia_expand = 0x7f0801b2;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_clip_drawable = 0x7f0801b3;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_info_button = 0x7f0801b4;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_background = 0x7f0801b5;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_close = 0x7f0801b6;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_left_arrow = 0x7f0801b7;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_refresh = 0x7f0801b8;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_right_arrow = 0x7f0801b9;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_unleft_arrow = 0x7f0801ba;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_unright_arrow = 0x7f0801bb;

        /* JADX INFO: Added by JADX */
        public static final int ia_mute = 0x7f0801bc;

        /* JADX INFO: Added by JADX */
        public static final int ia_play = 0x7f0801bd;

        /* JADX INFO: Added by JADX */
        public static final int ia_progress_bar_drawable = 0x7f0801be;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_overlay_bg = 0x7f0801bf;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_overlay_bg_fyber = 0x7f0801c0;

        /* JADX INFO: Added by JADX */
        public static final int ia_round_overlay_bg_with_close = 0x7f0801c1;

        /* JADX INFO: Added by JADX */
        public static final int ia_sel_expand_collapse = 0x7f0801c2;

        /* JADX INFO: Added by JADX */
        public static final int ia_sel_mute = 0x7f0801c3;

        /* JADX INFO: Added by JADX */
        public static final int ia_unmute = 0x7f0801c4;

        /* JADX INFO: Added by JADX */
        public static final int ic_100tb = 0x7f0801c5;

        /* JADX INFO: Added by JADX */
        public static final int ic_arrow_down_24dp = 0x7f0801c6;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer = 0x7f0801c7;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_low = 0x7f0801c8;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video = 0x7f0801c9;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video_low = 0x7f0801ca;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 0x7f0801cb;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline_low = 0x7f0801cc;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher = 0x7f0801cd;

        /* JADX INFO: Added by JADX */
        public static final int ic_menu_forward = 0x7f0801ce;

        /* JADX INFO: Added by JADX */
        public static final int ic_round_close_24 = 0x7f0801cf;

        /* JADX INFO: Added by JADX */
        public static final int ic_round_replay_24 = 0x7f0801d0;

        /* JADX INFO: Added by JADX */
        public static final int ic_round_skip_next_24 = 0x7f0801d1;

        /* JADX INFO: Added by JADX */
        public static final int ic_round_volume_off_24 = 0x7f0801d2;

        /* JADX INFO: Added by JADX */
        public static final int ic_round_volume_up_24 = 0x7f0801d3;

        /* JADX INFO: Added by JADX */
        public static final int im_back = 0x7f0801d4;

        /* JADX INFO: Added by JADX */
        public static final int im_close_button = 0x7f0801d5;

        /* JADX INFO: Added by JADX */
        public static final int im_close_icon = 0x7f0801d6;

        /* JADX INFO: Added by JADX */
        public static final int im_close_transparent = 0x7f0801d7;

        /* JADX INFO: Added by JADX */
        public static final int im_forward_active = 0x7f0801d8;

        /* JADX INFO: Added by JADX */
        public static final int im_forward_inactive = 0x7f0801d9;

        /* JADX INFO: Added by JADX */
        public static final int im_mute = 0x7f0801da;

        /* JADX INFO: Added by JADX */
        public static final int im_refresh = 0x7f0801db;

        /* JADX INFO: Added by JADX */
        public static final int im_unmute = 0x7f0801dc;

        /* JADX INFO: Added by JADX */
        public static final int info_badge = 0x7f0801dd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_arrow_down_white = 0x7f0801de;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_arrow_down_white_blackbg = 0x7f0801df;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_arrow_up_black = 0x7f0801e0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_arrow_up_white = 0x7f0801e1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_banner_close = 0x7f0801e2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_media_control = 0x7f0801e3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_bg = 0x7f0801e4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_cancel_bg = 0x7f0801e5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_cancel_bg_nor = 0x7f0801e6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_cancel_bg_pressed = 0x7f0801e7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_confirm_bg = 0x7f0801e8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_confirm_bg_nor = 0x7f0801e9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview_confirm_bg_pressed = 0x7f0801ea;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_backward = 0x7f0801eb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_backward_disabled = 0x7f0801ec;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_backward_nor = 0x7f0801ed;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_backward_selected = 0x7f0801ee;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_browser = 0x7f0801ef;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_btn_shake = 0x7f0801f0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_circle_50black = 0x7f0801f1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_end_animation = 0x7f0801f2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_exits = 0x7f0801f3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_exits_nor = 0x7f0801f4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_exits_selected = 0x7f0801f5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_btn_bg = 0x7f0801f6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_choice_btn_bg = 0x7f0801f7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_choice_btn_bg_nor = 0x7f0801f8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_choice_btn_bg_pressed = 0x7f0801f9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_view_bg = 0x7f0801fa;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_view_btn_bg = 0x7f0801fb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_forward = 0x7f0801fc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_forward_disabled = 0x7f0801fd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_forward_nor = 0x7f0801fe;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_forward_selected = 0x7f0801ff;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_head = 0x7f080200;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_highlight = 0x7f080201;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_progress = 0x7f080202;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_progress_drawable = 0x7f080203;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_progress_icon = 0x7f080204;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_refresh = 0x7f080205;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_refresh_nor = 0x7f080206;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_refresh_selected = 0x7f080207;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_tail = 0x7f080208;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cta_bg = 0x7f080209;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_demo_star_nor = 0x7f08020a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_demo_star_sel = 0x7f08020b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_finger_media_control = 0x7f08020c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_icon_click_circle = 0x7f08020d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_icon_click_hand = 0x7f08020e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_icon_play_bg = 0x7f08020f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_close = 0x7f080210;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_over = 0x7f080211;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_advanced_close_icon = 0x7f080212;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_bg_loading_camera = 0x7f080213;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_close = 0x7f080214;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_land_nor = 0x7f080215;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_land_pre = 0x7f080216;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_por_nor = 0x7f080217;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_cta_por_pre = 0x7f080218;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_full_land_close = 0x7f080219;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_full_protial_close = 0x7f08021a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_fullview_background = 0x7f08021b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_pause = 0x7f08021c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_play = 0x7f08021d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_play_bg = 0x7f08021e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_play_progress = 0x7f08021f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound1 = 0x7f080220;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound2 = 0x7f080221;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound3 = 0x7f080222;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound4 = 0x7f080223;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound5 = 0x7f080224;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound6 = 0x7f080225;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound7 = 0x7f080226;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound8 = 0x7f080227;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound_animation = 0x7f080228;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound_bg = 0x7f080229;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound_close = 0x7f08022a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_sound_open = 0x7f08022b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_layout_list_bg = 0x7f08022c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_activity_ad_end_land_des_rl_hot = 0x7f08022d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_close = 0x7f08022e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_close_ec = 0x7f08022f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_shape_bg = 0x7f080230;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_close_shape_oval = 0x7f080231;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_land_shape = 0x7f080232;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_pager_logo = 0x7f080233;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_shape_oval = 0x7f080234;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_flag_cn = 0x7f080235;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_flag_en = 0x7f080236;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_more_offer_default_bg = 0x7f080237;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_notice = 0x7f080238;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_popview_close = 0x7f080239;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_choice = 0x7f08023a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_choice_rl = 0x7f08023b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_end_pager = 0x7f08023c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_mf_selector = 0x7f08023d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_mof_like_normal = 0x7f08023e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_mof_like_pressed = 0x7f08023f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_order = 0x7f080240;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_order_history = 0x7f080241;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_progress = 0x7f080242;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_shape_videoend_buttonbg = 0x7f080243;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_sound_close = 0x7f080244;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_sound_open = 0x7f080245;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_arabia_land = 0x7f080246;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_arabia_por = 0x7f080247;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_en_land = 0x7f080248;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_en_por = 0x7f080249;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_france_land = 0x7f08024a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_france_por = 0x7f08024b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_germany_land = 0x7f08024c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_germany_por = 0x7f08024d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_japan_land = 0x7f08024e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_japan_por = 0x7f08024f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_korea_land = 0x7f080250;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_korea_por = 0x7f080251;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_russian_land = 0x7f080252;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_russian_por = 0x7f080253;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_zh = 0x7f080254;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_two_title_zh_trad = 0x7f080255;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_user = 0x7f080256;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_vast_end_close = 0x7f080257;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_vast_end_ok = 0x7f080258;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_icon = 0x7f080259;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_progress_bg = 0x7f08025a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_progressbar_bg = 0x7f08025b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_time_count_num_bg = 0x7f08025c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_btn = 0x7f08025d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_corners_bg = 0x7f08025e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_line = 0x7f08025f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_splash_circle_14 = 0x7f080260;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_splash_corners_14 = 0x7f080261;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_shape_splash_rightbottom_corners_10 = 0x7f080262;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_slide_hand = 0x7f080263;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_slide_rightarrow = 0x7f080264;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_ad_right_bottom_corner_en = 0x7f080265;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_ad_right_bottom_corner_zh = 0x7f080266;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_btn_arrow_right = 0x7f080267;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_btn_circle = 0x7f080268;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_btn_finger = 0x7f080269;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_btn_go = 0x7f08026a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_btn_light = 0x7f08026b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_button_bg_gray = 0x7f08026c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_button_bg_gray_55 = 0x7f08026d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_button_bg_green = 0x7f08026e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_close_bg = 0x7f08026f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_m_circle = 0x7f080270;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_notice = 0x7f080271;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_pop_ad = 0x7f080272;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_pop_ad_en = 0x7f080273;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_popview_close = 0x7f080274;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_popview_default = 0x7f080275;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_full_star = 0x7f080276;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_full_while_star = 0x7f080277;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_half_star = 0x7f080278;

        /* JADX INFO: Added by JADX */
        public static final int moloco_close = 0x7f080279;

        /* JADX INFO: Added by JADX */
        public static final int moloco_privacy = 0x7f08027a;

        /* JADX INFO: Added by JADX */
        public static final int moloco_replay = 0x7f08027b;

        /* JADX INFO: Added by JADX */
        public static final int moloco_skip = 0x7f08027c;

        /* JADX INFO: Added by JADX */
        public static final int moloco_star = 0x7f08027d;

        /* JADX INFO: Added by JADX */
        public static final int moloco_twotone_pause_24 = 0x7f08027e;

        /* JADX INFO: Added by JADX */
        public static final int moloco_twotone_play_arrow_24 = 0x7f08027f;

        /* JADX INFO: Added by JADX */
        public static final int moloco_twotone_volume_off_24 = 0x7f080280;

        /* JADX INFO: Added by JADX */
        public static final int moloco_twotone_volume_up_24 = 0x7f080281;

        /* JADX INFO: Added by JADX */
        public static final int moloco_volume_off = 0x7f080282;

        /* JADX INFO: Added by JADX */
        public static final int moloco_volume_on = 0x7f080283;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 0x7f080284;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 0x7f080285;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 0x7f080286;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_normal = 0x7f080287;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_pressed = 0x7f080288;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal = 0x7f080289;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal_pressed = 0x7f08028a;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 0x7f08028b;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 0x7f08028c;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 0x7f08028d;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 0x7f08028e;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 0x7f08028f;

        /* JADX INFO: Added by JADX */
        public static final int notify_panel_notification_icon_bg = 0x7f080290;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_background = 0x7f080291;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_default_icon_42dp = 0x7f080292;

        /* JADX INFO: Added by JADX */
        public static final int preference_list_divider_material = 0x7f080293;

        /* JADX INFO: Added by JADX */
        public static final int switch_off = 0x7f080294;

        /* JADX INFO: Added by JADX */
        public static final int switch_on = 0x7f080295;

        /* JADX INFO: Added by JADX */
        public static final int test_level_drawable = 0x7f080296;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_dark = 0x7f080297;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_light = 0x7f080298;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_arrow_backward = 0x7f080299;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_arrow_forward = 0x7f08029a;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_arrow_right = 0x7f08029b;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_bg_header_gradient = 0x7f08029c;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_closed_background_300_250 = 0x7f08029d;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_closed_background_320_50 = 0x7f08029e;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_feedback = 0x7f08029f;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_feedback_new = 0x7f0802a0;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_link = 0x7f0802a1;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_logo = 0x7f0802a2;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_refresh = 0x7f0802a3;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_threedots = 0x7f0802a4;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_xmark = 0x7f0802a5;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_zoom_down = 0x7f0802a6;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_zoom_up = 0x7f0802a7;

        /* JADX INFO: Added by JADX */
        public static final int tt_app_open_top_bg = 0x7f0802a8;

        /* JADX INFO: Added by JADX */
        public static final int tt_blue_hand = 0x7f0802a9;

        /* JADX INFO: Added by JADX */
        public static final int tt_button_back = 0x7f0802aa;

        /* JADX INFO: Added by JADX */
        public static final int tt_button_blue_back = 0x7f0802ab;

        /* JADX INFO: Added by JADX */
        public static final int tt_close_btn = 0x7f0802ac;

        /* JADX INFO: Added by JADX */
        public static final int tt_close_move_details_normal = 0x7f0802ad;

        /* JADX INFO: Added by JADX */
        public static final int tt_close_move_details_pressed = 0x7f0802ae;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_icon = 0x7f0802af;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_icon2 = 0x7f0802b0;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_toast = 0x7f0802b1;

        /* JADX INFO: Added by JADX */
        public static final int tt_enlarge_video = 0x7f0802b2;

        /* JADX INFO: Added by JADX */
        public static final int tt_item_background_material = 0x7f0802b3;

        /* JADX INFO: Added by JADX */
        public static final int tt_lefterbackicon_titlebar = 0x7f0802b4;

        /* JADX INFO: Added by JADX */
        public static final int tt_lefterbackicon_titlebar_for_dark = 0x7f0802b5;

        /* JADX INFO: Added by JADX */
        public static final int tt_lefterbackicon_titlebar_press = 0x7f0802b6;

        /* JADX INFO: Added by JADX */
        public static final int tt_lefterbackicon_titlebar_press_for_dark = 0x7f0802b7;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_browser_icon = 0x7f0802b8;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_copy_icon = 0x7f0802b9;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_history_icon = 0x7f0802ba;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_report_icon = 0x7f0802bb;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_retry_icon = 0x7f0802bc;

        /* JADX INFO: Added by JADX */
        public static final int tt_mute = 0x7f0802bd;

        /* JADX INFO: Added by JADX */
        public static final int tt_new_pause_video = 0x7f0802be;

        /* JADX INFO: Added by JADX */
        public static final int tt_new_pause_video_press = 0x7f0802bf;

        /* JADX INFO: Added by JADX */
        public static final int tt_new_play_video = 0x7f0802c0;

        /* JADX INFO: Added by JADX */
        public static final int tt_normalscreen_loading = 0x7f0802c1;

        /* JADX INFO: Added by JADX */
        public static final int tt_pangle_ad_close_drawable = 0x7f0802c2;

        /* JADX INFO: Added by JADX */
        public static final int tt_refreshing_video_textpage_normal = 0x7f0802c3;

        /* JADX INFO: Added by JADX */
        public static final int tt_refreshing_video_textpage_pressed = 0x7f0802c4;

        /* JADX INFO: Added by JADX */
        public static final int tt_report_ad_arrow = 0x7f0802c5;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_full_feedback = 0x7f0802c6;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_full_mute = 0x7f0802c7;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_full_unmute = 0x7f0802c8;

        /* JADX INFO: Added by JADX */
        public static final int tt_shadow_fullscreen_top = 0x7f0802c9;

        /* JADX INFO: Added by JADX */
        public static final int tt_shadow_lefterback_titlebar = 0x7f0802ca;

        /* JADX INFO: Added by JADX */
        public static final int tt_shadow_lefterback_titlebar_press = 0x7f0802cb;

        /* JADX INFO: Added by JADX */
        public static final int tt_shadow_lefterback_titlebar_press_withoutnight = 0x7f0802cc;

        /* JADX INFO: Added by JADX */
        public static final int tt_shadow_lefterback_titlebar_withoutnight = 0x7f0802cd;

        /* JADX INFO: Added by JADX */
        public static final int tt_shrink_fullscreen = 0x7f0802ce;

        /* JADX INFO: Added by JADX */
        public static final int tt_shrink_video = 0x7f0802cf;

        /* JADX INFO: Added by JADX */
        public static final int tt_skip_btn = 0x7f0802d0;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_hand = 0x7f0802d1;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_hand2 = 0x7f0802d2;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_rock = 0x7f0802d3;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_shake_hand = 0x7f0802d4;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_right_bg = 0x7f0802d5;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_right_circle = 0x7f0802d6;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_up_10 = 0x7f0802d7;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_up_arrow = 0x7f0802d8;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_up_bg = 0x7f0802d9;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_up_circle = 0x7f0802da;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_slide_up_finger = 0x7f0802db;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_twist = 0x7f0802dc;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_unlock_btn_bg = 0x7f0802dd;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_unlock_icon_empty = 0x7f0802de;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_unlock_image_arrow = 0x7f0802df;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_unlock_image_go = 0x7f0802e0;

        /* JADX INFO: Added by JADX */
        public static final int tt_star = 0x7f0802e1;

        /* JADX INFO: Added by JADX */
        public static final int tt_star_thick = 0x7f0802e2;

        /* JADX INFO: Added by JADX */
        public static final int tt_star_thick_dark = 0x7f0802e3;

        /* JADX INFO: Added by JADX */
        public static final int tt_suggestion_logo = 0x7f0802e4;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_backward = 0x7f0802e5;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_close_drawable = 0x7f0802e6;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_close_for_dark = 0x7f0802e7;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_close_new = 0x7f0802e8;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_close_press = 0x7f0802e9;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_close_press_for_dark = 0x7f0802ea;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_forward = 0x7f0802eb;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_lock = 0x7f0802ec;

        /* JADX INFO: Added by JADX */
        public static final int tt_titlebar_more = 0x7f0802ed;

        /* JADX INFO: Added by JADX */
        public static final int tt_ugen_rating_star = 0x7f0802ee;

        /* JADX INFO: Added by JADX */
        public static final int tt_unmute = 0x7f0802ef;

        /* JADX INFO: Added by JADX */
        public static final int tt_up_slide = 0x7f0802f0;

        /* JADX INFO: Added by JADX */
        public static final int tt_user = 0x7f0802f1;

        /* JADX INFO: Added by JADX */
        public static final int tt_user_info = 0x7f0802f2;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_close_drawable = 0x7f0802f3;

        /* JADX INFO: Added by JADX */
        public static final int tt_white_hand = 0x7f0802f4;

        /* JADX INFO: Added by JADX */
        public static final int tt_white_lefterbackicon_titlebar = 0x7f0802f5;

        /* JADX INFO: Added by JADX */
        public static final int tt_white_lefterbackicon_titlebar_press = 0x7f0802f6;

        /* JADX INFO: Added by JADX */
        public static final int tt_white_righterbackicon_titlebar = 0x7f0802f7;

        /* JADX INFO: Added by JADX */
        public static final int tt_white_slide_up = 0x7f0802f8;

        /* JADX INFO: Added by JADX */
        public static final int tt_wriggle_union = 0x7f0802f9;

        /* JADX INFO: Added by JADX */
        public static final int tt_wriggle_union_white = 0x7f0802fa;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_arrow_right = 0x7f0802fb;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_button_default = 0x7f0802fc;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_button_uc = 0x7f0802fd;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_check_error = 0x7f0802fe;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_check_pass = 0x7f0802ff;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_check_warn = 0x7f080300;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_edit_background = 0x7f080301;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_button_default = 0x7f080302;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_outline_shape = 0x7f080303;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_rounded_corners_shape = 0x7f080304;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_privacy_dialog_bg = 0x7f080305;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_progress = 0x7f080306;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_progress_defalut = 0x7f080307;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_rsb_default_thumb = 0x7f080308;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_thumb_gradient = 0x7f080309;

        /* JADX INFO: Added by JADX */
        public static final int yodo1mas_darrow_mark = 0x7f08030a;
    }

    /* JADX INFO: Added by JADX */
    public static final class font {

        /* JADX INFO: Added by JADX */
        public static final int inter = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int roboto_medium_numbers = 0x7f090001;
    }

    /* JADX INFO: Added by JADX */
    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int ALT = 0x7f0a0000;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 0x7f0a0001;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 0x7f0a0002;

        /* JADX INFO: Added by JADX */
        public static final int META = 0x7f0a0003;

        /* JADX INFO: Added by JADX */
        public static final int NO_DEBUG = 0x7f0a0004;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 0x7f0a0005;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_ALL = 0x7f0a0006;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PATH = 0x7f0a0007;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PROGRESS = 0x7f0a0008;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 0x7f0a0009;

        /* JADX INFO: Added by JADX */
        public static final int accelerate = 0x7f0a000a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f0a000b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f0a000c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f0a000d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f0a000e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f0a000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f0a0010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f0a0011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f0a0012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f0a0013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f0a0014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f0a0015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f0a0016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f0a0017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f0a0018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f0a0019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f0a001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f0a001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f0a001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f0a001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f0a001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f0a001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f0a0020;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f0a0021;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f0a0022;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f0a0023;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f0a0024;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f0a0025;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f0a0026;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f0a0027;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f0a0028;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f0a0029;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f0a002a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f0a002b;

        /* JADX INFO: Added by JADX */
        public static final int action0 = 0x7f0a002c;

        /* JADX INFO: Added by JADX */
        public static final int actionDown = 0x7f0a002d;

        /* JADX INFO: Added by JADX */
        public static final int actionDownUp = 0x7f0a002e;

        /* JADX INFO: Added by JADX */
        public static final int actionUp = 0x7f0a002f;

        /* JADX INFO: Added by JADX */
        public static final int action_bar = 0x7f0a0030;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_activity_content = 0x7f0a0031;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_container = 0x7f0a0032;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_root = 0x7f0a0033;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_spinner = 0x7f0a0034;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_subtitle = 0x7f0a0035;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_title = 0x7f0a0036;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f0a0037;

        /* JADX INFO: Added by JADX */
        public static final int action_context_bar = 0x7f0a0038;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f0a0039;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f0a003a;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_divider = 0x7f0a003b;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_presenter = 0x7f0a003c;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar = 0x7f0a003d;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar_stub = 0x7f0a003e;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_close_button = 0x7f0a003f;

        /* JADX INFO: Added by JADX */
        public static final int action_share = 0x7f0a0040;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f0a0041;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f0a0042;

        /* JADX INFO: Added by JADX */
        public static final int activity_chooser_view_content = 0x7f0a0043;

        /* JADX INFO: Added by JADX */
        public static final int ad_advertiser = 0x7f0a0044;

        /* JADX INFO: Added by JADX */
        public static final int ad_app_icon = 0x7f0a0045;

        /* JADX INFO: Added by JADX */
        public static final int ad_body = 0x7f0a0046;

        /* JADX INFO: Added by JADX */
        public static final int ad_call_to_action = 0x7f0a0047;

        /* JADX INFO: Added by JADX */
        public static final int ad_control_button = 0x7f0a0048;

        /* JADX INFO: Added by JADX */
        public static final int ad_controls_view = 0x7f0a0049;

        /* JADX INFO: Added by JADX */
        public static final int ad_headline = 0x7f0a004a;

        /* JADX INFO: Added by JADX */
        public static final int ad_media = 0x7f0a004b;

        /* JADX INFO: Added by JADX */
        public static final int ad_notification_view = 0x7f0a004c;

        /* JADX INFO: Added by JADX */
        public static final int ad_presenter_view = 0x7f0a004d;

        /* JADX INFO: Added by JADX */
        public static final int ad_view_container = 0x7f0a004e;

        /* JADX INFO: Added by JADX */
        public static final int add = 0x7f0a004f;

        /* JADX INFO: Added by JADX */
        public static final int adjust_height = 0x7f0a0050;

        /* JADX INFO: Added by JADX */
        public static final int adjust_width = 0x7f0a0051;

        /* JADX INFO: Added by JADX */
        public static final int alertTitle = 0x7f0a0052;

        /* JADX INFO: Added by JADX */
        public static final int aligned = 0x7f0a0053;

        /* JADX INFO: Added by JADX */
        public static final int all = 0x7f0a0054;

        /* JADX INFO: Added by JADX */
        public static final int allStates = 0x7f0a0055;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f0a0056;

        /* JADX INFO: Added by JADX */
        public static final int alwaysHide = 0x7f0a0057;

        /* JADX INFO: Added by JADX */
        public static final int alwaysShow = 0x7f0a0058;

        /* JADX INFO: Added by JADX */
        public static final int alwaysShowAfterTouch = 0x7f0a0059;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_composition_context = 0x7f0a005a;

        /* JADX INFO: Added by JADX */
        public static final int animateToEnd = 0x7f0a005b;

        /* JADX INFO: Added by JADX */
        public static final int animateToStart = 0x7f0a005c;

        /* JADX INFO: Added by JADX */
        public static final int antiClockwise = 0x7f0a005d;

        /* JADX INFO: Added by JADX */
        public static final int anticipate = 0x7f0a005e;

        /* JADX INFO: Added by JADX */
        public static final int app_open_ad_control_button = 0x7f0a005f;

        /* JADX INFO: Added by JADX */
        public static final int app_open_ad_control_view = 0x7f0a0060;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_ad_content_linear_layout = 0x7f0a0061;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_ad_view_container = 0x7f0a0062;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_advertiser_text_view = 0x7f0a0063;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_badge_text_view = 0x7f0a0064;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_body_text_view = 0x7f0a0065;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_cta_button = 0x7f0a0066;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_icon_and_text_layout = 0x7f0a0067;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_icon_image_view = 0x7f0a0068;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_icon_view = 0x7f0a0069;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_inner_linear_layout = 0x7f0a006a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_inner_parent_layout = 0x7f0a006b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_leader_icon_and_text_layout = 0x7f0a006c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_media_content_view = 0x7f0a006d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_options_view = 0x7f0a006e;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_star_rating_view = 0x7f0a006f;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_title_text_view = 0x7f0a0070;

        /* JADX INFO: Added by JADX */
        public static final int asConfigured = 0x7f0a0071;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f0a0072;

        /* JADX INFO: Added by JADX */
        public static final int auto = 0x7f0a0073;

        /* JADX INFO: Added by JADX */
        public static final int autoComplete = 0x7f0a0074;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToEnd = 0x7f0a0075;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToStart = 0x7f0a0076;

        /* JADX INFO: Added by JADX */
        public static final int background = 0x7f0a0077;

        /* JADX INFO: Added by JADX */
        public static final int banner_ad_view_container = 0x7f0a0078;

        /* JADX INFO: Added by JADX */
        public static final int banner_control_button = 0x7f0a0079;

        /* JADX INFO: Added by JADX */
        public static final int banner_control_view = 0x7f0a007a;

        /* JADX INFO: Added by JADX */
        public static final int banner_label = 0x7f0a007b;

        /* JADX INFO: Added by JADX */
        public static final int barrier = 0x7f0a007c;

        /* JADX INFO: Added by JADX */
        public static final int baseline = 0x7f0a007d;

        /* JADX INFO: Added by JADX */
        public static final int beginOnFirstDraw = 0x7f0a007e;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 0x7f0a007f;

        /* JADX INFO: Added by JADX */
        public static final int bestChoice = 0x7f0a0080;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_background_view = 0x7f0a0081;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_background_text = 0x7f0a0082;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_image_description = 0x7f0a0083;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_image_domain = 0x7f0a0084;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_placeholder_view = 0x7f0a0085;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_bottom_privacy_content = 0x7f0a0086;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_ad_copy_link = 0x7f0a0087;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_class = 0x7f0a0088;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_close = 0x7f0a0089;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_cta = 0x7f0a008a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_cta_inner = 0x7f0a008b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_rec_rule = 0x7f0a008c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_resume = 0x7f0a008d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_skip = 0x7f0a008e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_user_privacy = 0x7f0a008f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_btn_why_this_ad = 0x7f0a0090;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_check_box_expand = 0x7f0a0091;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_close_progress_container = 0x7f0a0092;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_page_content = 0x7f0a0093;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_1_all_wrap = 0x7f0a0094;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_1_half_wrap = 0x7f0a0095;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_1_img_wrap = 0x7f0a0096;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_2_all_wrap = 0x7f0a0097;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_2_half_wrap = 0x7f0a0098;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_end_stub_2_img_wrap = 0x7f0a0099;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_background = 0x7f0a009a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_btn_agree = 0x7f0a009b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_btn_cancel = 0x7f0a009c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_desc_iv = 0x7f0a009d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_desc_layout = 0x7f0a009e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_desc_txt = 0x7f0a009f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_title_iv = 0x7f0a00a0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_title_layout = 0x7f0a00a1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_title_txt = 0x7f0a00a2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_id_form_question = 0x7f0a00a3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_image_title = 0x7f0a00a4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_info_card_background = 0x7f0a00a5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_info_layout = 0x7f0a00a6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_inter_gp_container = 0x7f0a00a7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_inter_layout_end_page = 0x7f0a00a8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interstitial_below_area_click = 0x7f0a00a9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_click_guide = 0x7f0a00aa;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_loading_content = 0x7f0a00ab;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_mask_horizontal = 0x7f0a00ac;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_mask_vertical = 0x7f0a00ad;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_material_container = 0x7f0a00ae;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_mix_end_content = 0x7f0a00af;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_more_img = 0x7f0a00b0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_more_txt = 0x7f0a00b1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_native_ad_view_stub = 0x7f0a00b2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_scroll_images = 0x7f0a00b3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_ad_container = 0x7f0a00b4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_btn_cta = 0x7f0a00b5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_btn_cta_container = 0x7f0a00b6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_btn_cta_container_round = 0x7f0a00b7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_btn_skip = 0x7f0a00b8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_container_root = 0x7f0a00b9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_cta_inner = 0x7f0a00ba;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_description = 0x7f0a00bb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_icon = 0x7f0a00bc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_media = 0x7f0a00bd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_media_container = 0x7f0a00be;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_options = 0x7f0a00bf;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_title = 0x7f0a00c0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_sub_bottom_component = 0x7f0a00c1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tv_more = 0x7f0a00c2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_twins_sub_ad_container = 0x7f0a00c3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_webview_loading_progress = 0x7f0a00c4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_web_loading_container = 0x7f0a00c5;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f0a00c6;

        /* JADX INFO: Added by JADX */
        public static final int bmPrivacySheetActionButtonsContainer = 0x7f0a00c7;

        /* JADX INFO: Added by JADX */
        public static final int bmPrivacySheetClose = 0x7f0a00c8;

        /* JADX INFO: Added by JADX */
        public static final int bmPrivacySheetSubtitle = 0x7f0a00c9;

        /* JADX INFO: Added by JADX */
        public static final int bmPrivacySheetTitle = 0x7f0a00ca;

        /* JADX INFO: Added by JADX */
        public static final int body = 0x7f0a00cb;

        /* JADX INFO: Added by JADX */
        public static final int bottom = 0x7f0a00cc;

        /* JADX INFO: Added by JADX */
        public static final int bounce = 0x7f0a00cd;

        /* JADX INFO: Added by JADX */
        public static final int bounceBoth = 0x7f0a00ce;

        /* JADX INFO: Added by JADX */
        public static final int bounceEnd = 0x7f0a00cf;

        /* JADX INFO: Added by JADX */
        public static final int bounceStart = 0x7f0a00d0;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_header_text = 0x7f0a00d1;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_icon = 0x7f0a00d2;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_text = 0x7f0a00d3;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_items = 0x7f0a00d4;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_view = 0x7f0a00d5;

        /* JADX INFO: Added by JADX */
        public static final int btn_class = 0x7f0a00d6;

        /* JADX INFO: Added by JADX */
        public static final int btn_done = 0x7f0a00d7;

        /* JADX INFO: Added by JADX */
        public static final int btn_hide = 0x7f0a00d8;

        /* JADX INFO: Added by JADX */
        public static final int btn_report = 0x7f0a00d9;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanel = 0x7f0a00da;

        /* JADX INFO: Added by JADX */
        public static final int cache_measures = 0x7f0a00db;

        /* JADX INFO: Added by JADX */
        public static final int callMeasure = 0x7f0a00dc;

        /* JADX INFO: Added by JADX */
        public static final int cancel_action = 0x7f0a00dd;

        /* JADX INFO: Added by JADX */
        public static final int carryVelocity = 0x7f0a00de;

        /* JADX INFO: Added by JADX */
        public static final int center = 0x7f0a00df;

        /* JADX INFO: Added by JADX */
        public static final int center_horizontal = 0x7f0a00e0;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 0x7f0a00e1;

        /* JADX INFO: Added by JADX */
        public static final int chain = 0x7f0a00e2;

        /* JADX INFO: Added by JADX */
        public static final int chain2 = 0x7f0a00e3;

        /* JADX INFO: Added by JADX */
        public static final int chains = 0x7f0a00e4;

        /* JADX INFO: Added by JADX */
        public static final int checkbox = 0x7f0a00e5;

        /* JADX INFO: Added by JADX */
        public static final int checked = 0x7f0a00e6;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f0a00e7;

        /* JADX INFO: Added by JADX */
        public static final int click_gesture = 0x7f0a00e8;

        /* JADX INFO: Added by JADX */
        public static final int click_guide_container = 0x7f0a00e9;

        /* JADX INFO: Added by JADX */
        public static final int click_proxy = 0x7f0a00ea;

        /* JADX INFO: Added by JADX */
        public static final int click_ripple = 0x7f0a00eb;

        /* JADX INFO: Added by JADX */
        public static final int clip_horizontal = 0x7f0a00ec;

        /* JADX INFO: Added by JADX */
        public static final int clip_vertical = 0x7f0a00ed;

        /* JADX INFO: Added by JADX */
        public static final int clockwise = 0x7f0a00ee;

        /* JADX INFO: Added by JADX */
        public static final int close_button_container = 0x7f0a00ef;

        /* JADX INFO: Added by JADX */
        public static final int close_text = 0x7f0a00f0;

        /* JADX INFO: Added by JADX */
        public static final int closest = 0x7f0a00f1;

        /* JADX INFO: Added by JADX */
        public static final int coil_request_manager = 0x7f0a00f2;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 0x7f0a00f3;

        /* JADX INFO: Added by JADX */
        public static final int compose_view_saveable_id_tag = 0x7f0a00f4;

        /* JADX INFO: Added by JADX */
        public static final int constraint = 0x7f0a00f5;

        /* JADX INFO: Added by JADX */
        public static final int consume_window_insets_tag = 0x7f0a00f6;

        /* JADX INFO: Added by JADX */
        public static final int container_click_progress = 0x7f0a00f7;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f0a00f8;

        /* JADX INFO: Added by JADX */
        public static final int contentPanel = 0x7f0a00f9;

        /* JADX INFO: Added by JADX */
        public static final int content_layout = 0x7f0a00fa;

        /* JADX INFO: Added by JADX */
        public static final int continuousVelocity = 0x7f0a00fb;

        /* JADX INFO: Added by JADX */
        public static final int cos = 0x7f0a00fc;

        /* JADX INFO: Added by JADX */
        public static final int cta = 0x7f0a00fd;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f0a00fe;

        /* JADX INFO: Added by JADX */
        public static final int custom = 0x7f0a00ff;

        /* JADX INFO: Added by JADX */
        public static final int customPanel = 0x7f0a0100;

        /* JADX INFO: Added by JADX */
        public static final int dark = 0x7f0a0101;

        /* JADX INFO: Added by JADX */
        public static final int dashboard_tabs = 0x7f0a0102;

        /* JADX INFO: Added by JADX */
        public static final int decelerate = 0x7f0a0103;

        /* JADX INFO: Added by JADX */
        public static final int decelerateAndComplete = 0x7f0a0104;

        /* JADX INFO: Added by JADX */
        public static final int decor_content_parent = 0x7f0a0105;

        /* JADX INFO: Added by JADX */
        public static final int default_activity_button = 0x7f0a0106;

        /* JADX INFO: Added by JADX */
        public static final int deltaRelative = 0x7f0a0107;

        /* JADX INFO: Added by JADX */
        public static final int dependency_ordering = 0x7f0a0108;

        /* JADX INFO: Added by JADX */
        public static final int detailImageView = 0x7f0a0109;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f0a010a;

        /* JADX INFO: Added by JADX */
        public static final int dimensions = 0x7f0a010b;

        /* JADX INFO: Added by JADX */
        public static final int direct = 0x7f0a010c;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 0x7f0a010d;

        /* JADX INFO: Added by JADX */
        public static final int disableIntraAutoTransition = 0x7f0a010e;

        /* JADX INFO: Added by JADX */
        public static final int disablePostScroll = 0x7f0a010f;

        /* JADX INFO: Added by JADX */
        public static final int disableScroll = 0x7f0a0110;

        /* JADX INFO: Added by JADX */
        public static final int download_msg_list = 0x7f0a0111;

        /* JADX INFO: Added by JADX */
        public static final int dragAnticlockwise = 0x7f0a0112;

        /* JADX INFO: Added by JADX */
        public static final int dragClockwise = 0x7f0a0113;

        /* JADX INFO: Added by JADX */
        public static final int dragDown = 0x7f0a0114;

        /* JADX INFO: Added by JADX */
        public static final int dragEnd = 0x7f0a0115;

        /* JADX INFO: Added by JADX */
        public static final int dragLeft = 0x7f0a0116;

        /* JADX INFO: Added by JADX */
        public static final int dragRight = 0x7f0a0117;

        /* JADX INFO: Added by JADX */
        public static final int dragStart = 0x7f0a0118;

        /* JADX INFO: Added by JADX */
        public static final int dragUp = 0x7f0a0119;

        /* JADX INFO: Added by JADX */
        public static final int easeIn = 0x7f0a011a;

        /* JADX INFO: Added by JADX */
        public static final int easeInOut = 0x7f0a011b;

        /* JADX INFO: Added by JADX */
        public static final int easeOut = 0x7f0a011c;

        /* JADX INFO: Added by JADX */
        public static final int east = 0x7f0a011d;

        /* JADX INFO: Added by JADX */
        public static final int edit_query = 0x7f0a011e;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f0a011f;

        /* JADX INFO: Added by JADX */
        public static final int email_report_tv = 0x7f0a0120;

        /* JADX INFO: Added by JADX */
        public static final int end = 0x7f0a0121;

        /* JADX INFO: Added by JADX */
        public static final int end_padder = 0x7f0a0122;

        /* JADX INFO: Added by JADX */
        public static final int exo_ad_overlay = 0x7f0a0123;

        /* JADX INFO: Added by JADX */
        public static final int exo_artwork = 0x7f0a0124;

        /* JADX INFO: Added by JADX */
        public static final int exo_audio_track = 0x7f0a0125;

        /* JADX INFO: Added by JADX */
        public static final int exo_basic_controls = 0x7f0a0126;

        /* JADX INFO: Added by JADX */
        public static final int exo_bottom_bar = 0x7f0a0127;

        /* JADX INFO: Added by JADX */
        public static final int exo_buffering = 0x7f0a0128;

        /* JADX INFO: Added by JADX */
        public static final int exo_center_controls = 0x7f0a0129;

        /* JADX INFO: Added by JADX */
        public static final int exo_check = 0x7f0a012a;

        /* JADX INFO: Added by JADX */
        public static final int exo_content_frame = 0x7f0a012b;

        /* JADX INFO: Added by JADX */
        public static final int exo_controller = 0x7f0a012c;

        /* JADX INFO: Added by JADX */
        public static final int exo_controller_placeholder = 0x7f0a012d;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_background = 0x7f0a012e;

        /* JADX INFO: Added by JADX */
        public static final int exo_duration = 0x7f0a012f;

        /* JADX INFO: Added by JADX */
        public static final int exo_error_message = 0x7f0a0130;

        /* JADX INFO: Added by JADX */
        public static final int exo_extra_controls = 0x7f0a0131;

        /* JADX INFO: Added by JADX */
        public static final int exo_extra_controls_scroll_view = 0x7f0a0132;

        /* JADX INFO: Added by JADX */
        public static final int exo_ffwd = 0x7f0a0133;

        /* JADX INFO: Added by JADX */
        public static final int exo_ffwd_with_amount = 0x7f0a0134;

        /* JADX INFO: Added by JADX */
        public static final int exo_fullscreen = 0x7f0a0135;

        /* JADX INFO: Added by JADX */
        public static final int exo_icon = 0x7f0a0136;

        /* JADX INFO: Added by JADX */
        public static final int exo_image = 0x7f0a0137;

        /* JADX INFO: Added by JADX */
        public static final int exo_main_text = 0x7f0a0138;

        /* JADX INFO: Added by JADX */
        public static final int exo_minimal_controls = 0x7f0a0139;

        /* JADX INFO: Added by JADX */
        public static final int exo_minimal_fullscreen = 0x7f0a013a;

        /* JADX INFO: Added by JADX */
        public static final int exo_next = 0x7f0a013b;

        /* JADX INFO: Added by JADX */
        public static final int exo_overflow_hide = 0x7f0a013c;

        /* JADX INFO: Added by JADX */
        public static final int exo_overflow_show = 0x7f0a013d;

        /* JADX INFO: Added by JADX */
        public static final int exo_overlay = 0x7f0a013e;

        /* JADX INFO: Added by JADX */
        public static final int exo_pause = 0x7f0a013f;

        /* JADX INFO: Added by JADX */
        public static final int exo_play = 0x7f0a0140;

        /* JADX INFO: Added by JADX */
        public static final int exo_play_pause = 0x7f0a0141;

        /* JADX INFO: Added by JADX */
        public static final int exo_playback_speed = 0x7f0a0142;

        /* JADX INFO: Added by JADX */
        public static final int exo_position = 0x7f0a0143;

        /* JADX INFO: Added by JADX */
        public static final int exo_prev = 0x7f0a0144;

        /* JADX INFO: Added by JADX */
        public static final int exo_progress = 0x7f0a0145;

        /* JADX INFO: Added by JADX */
        public static final int exo_progress_placeholder = 0x7f0a0146;

        /* JADX INFO: Added by JADX */
        public static final int exo_repeat_toggle = 0x7f0a0147;

        /* JADX INFO: Added by JADX */
        public static final int exo_rew = 0x7f0a0148;

        /* JADX INFO: Added by JADX */
        public static final int exo_rew_with_amount = 0x7f0a0149;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings = 0x7f0a014a;

        /* JADX INFO: Added by JADX */
        public static final int exo_settings_listview = 0x7f0a014b;

        /* JADX INFO: Added by JADX */
        public static final int exo_shuffle = 0x7f0a014c;

        /* JADX INFO: Added by JADX */
        public static final int exo_shutter = 0x7f0a014d;

        /* JADX INFO: Added by JADX */
        public static final int exo_sub_text = 0x7f0a014e;

        /* JADX INFO: Added by JADX */
        public static final int exo_subtitle = 0x7f0a014f;

        /* JADX INFO: Added by JADX */
        public static final int exo_subtitles = 0x7f0a0150;

        /* JADX INFO: Added by JADX */
        public static final int exo_text = 0x7f0a0151;

        /* JADX INFO: Added by JADX */
        public static final int exo_time = 0x7f0a0152;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_view = 0x7f0a0153;

        /* JADX INFO: Added by JADX */
        public static final int exo_vr = 0x7f0a0154;

        /* JADX INFO: Added by JADX */
        public static final int expand_activities_button = 0x7f0a0155;

        /* JADX INFO: Added by JADX */
        public static final int expanded_menu = 0x7f0a0156;

        /* JADX INFO: Added by JADX */
        public static final int fbl_genre = 0x7f0a0157;

        /* JADX INFO: Added by JADX */
        public static final int fill = 0x7f0a0158;

        /* JADX INFO: Added by JADX */
        public static final int fill_horizontal = 0x7f0a0159;

        /* JADX INFO: Added by JADX */
        public static final int fill_vertical = 0x7f0a015a;

        /* JADX INFO: Added by JADX */
        public static final int fit = 0x7f0a015b;

        /* JADX INFO: Added by JADX */
        public static final int fixed_height = 0x7f0a015c;

        /* JADX INFO: Added by JADX */
        public static final int fixed_width = 0x7f0a015d;

        /* JADX INFO: Added by JADX */
        public static final int fl_multi_container = 0x7f0a015e;

        /* JADX INFO: Added by JADX */
        public static final int flip = 0x7f0a015f;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f0a0160;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 0x7f0a0161;

        /* JADX INFO: Added by JADX */
        public static final int frost = 0x7f0a0162;

        /* JADX INFO: Added by JADX */
        public static final int gift_widget = 0x7f0a0163;

        /* JADX INFO: Added by JADX */
        public static final int gone = 0x7f0a0164;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f0a0165;

        /* JADX INFO: Added by JADX */
        public static final int graph_wrap = 0x7f0a0166;

        /* JADX INFO: Added by JADX */
        public static final int group_divider = 0x7f0a0167;

        /* JADX INFO: Added by JADX */
        public static final int grouping = 0x7f0a0168;

        /* JADX INFO: Added by JADX */
        public static final int groups = 0x7f0a0169;

        /* JADX INFO: Added by JADX */
        public static final int headline = 0x7f0a016a;

        /* JADX INFO: Added by JADX */
        public static final int heart_widget = 0x7f0a016b;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f0a016c;

        /* JADX INFO: Added by JADX */
        public static final int hide_in_inspector_tag = 0x7f0a016d;

        /* JADX INFO: Added by JADX */
        public static final int hollow_out = 0x7f0a016e;

        /* JADX INFO: Added by JADX */
        public static final int home = 0x7f0a016f;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 0x7f0a0170;

        /* JADX INFO: Added by JADX */
        public static final int honorRequest = 0x7f0a0171;

        /* JADX INFO: Added by JADX */
        public static final int horizontal_only = 0x7f0a0172;

        /* JADX INFO: Added by JADX */
        public static final int ia_ad_content = 0x7f0a0173;

        /* JADX INFO: Added by JADX */
        public static final int ia_b_end_card_call_to_action = 0x7f0a0174;

        /* JADX INFO: Added by JADX */
        public static final int ia_buffering_overlay = 0x7f0a0175;

        /* JADX INFO: Added by JADX */
        public static final int ia_click_overlay = 0x7f0a0176;

        /* JADX INFO: Added by JADX */
        public static final int ia_clickable_close_button = 0x7f0a0177;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_button = 0x7f0a0178;

        /* JADX INFO: Added by JADX */
        public static final int ia_close_button_background_item = 0x7f0a0179;

        /* JADX INFO: Added by JADX */
        public static final int ia_default_endcard_video_overlay = 0x7f0a017a;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_container = 0x7f0a017b;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_tv_app_info_button = 0x7f0a017c;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_video_overlay = 0x7f0a017d;

        /* JADX INFO: Added by JADX */
        public static final int ia_fl_close_button = 0x7f0a017e;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_identifier_image = 0x7f0a017f;

        /* JADX INFO: Added by JADX */
        public static final int ia_fyber_identifier_text = 0x7f0a0180;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_overlay = 0x7f0a0181;

        /* JADX INFO: Added by JADX */
        public static final int ia_inn_texture_view = 0x7f0a0182;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_vast_endcard_gif = 0x7f0a0183;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_vast_endcard_html = 0x7f0a0184;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_vast_endcard_iframe = 0x7f0a0185;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_vast_endcard_static = 0x7f0a0186;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_webview_internal_browser = 0x7f0a0187;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_webview_mraid = 0x7f0a0188;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_webview_report_ad = 0x7f0a0189;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_webview_vast_endcard = 0x7f0a018a;

        /* JADX INFO: Added by JADX */
        public static final int ia_inneractive_webview_vast_vpaid = 0x7f0a018b;

        /* JADX INFO: Added by JADX */
        public static final int ia_iv_close_button = 0x7f0a018c;

        /* JADX INFO: Added by JADX */
        public static final int ia_iv_expand_collapse_button = 0x7f0a018d;

        /* JADX INFO: Added by JADX */
        public static final int ia_iv_mute_button = 0x7f0a018e;

        /* JADX INFO: Added by JADX */
        public static final int ia_iv_play_button = 0x7f0a018f;

        /* JADX INFO: Added by JADX */
        public static final int ia_keep_watching_button = 0x7f0a0190;

        /* JADX INFO: Added by JADX */
        public static final int ia_paused_video_overlay = 0x7f0a0191;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_dialog_sub_title_textview = 0x7f0a0192;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_dialog_title_textview = 0x7f0a0193;

        /* JADX INFO: Added by JADX */
        public static final int ia_texture_view_host = 0x7f0a0194;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_app_info_button = 0x7f0a0195;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_call_to_action = 0x7f0a0196;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_close_button = 0x7f0a0197;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_remaining_time = 0x7f0a0198;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_skip = 0x7f0a0199;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_progressbar = 0x7f0a019a;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f0a019b;

        /* JADX INFO: Added by JADX */
        public static final int icon_ads_container = 0x7f0a019c;

        /* JADX INFO: Added by JADX */
        public static final int icon_frame = 0x7f0a019d;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f0a019e;

        /* JADX INFO: Added by JADX */
        public static final int icon_layout = 0x7f0a019f;

        /* JADX INFO: Added by JADX */
        public static final int icon_only = 0x7f0a01a0;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 0x7f0a01a1;

        /* JADX INFO: Added by JADX */
        public static final int ignore = 0x7f0a01a2;

        /* JADX INFO: Added by JADX */
        public static final int ignoreRequest = 0x7f0a01a3;

        /* JADX INFO: Added by JADX */
        public static final int image = 0x7f0a01a4;

        /* JADX INFO: Added by JADX */
        public static final int imageView = 0x7f0a01a5;

        /* JADX INFO: Added by JADX */
        public static final int image_view = 0x7f0a01a6;

        /* JADX INFO: Added by JADX */
        public static final int immediateStop = 0x7f0a01a7;

        /* JADX INFO: Added by JADX */
        public static final int included = 0x7f0a01a8;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f0a01a9;

        /* JADX INFO: Added by JADX */
        public static final int inspection_slot_table_set = 0x7f0a01aa;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info = 0x7f0a01ab;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_background = 0x7f0a01ac;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_card_right_bottom = 0x7f0a01ad;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_down = 0x7f0a01ae;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_exclude_warning = 0x7f0a01af;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_inner = 0x7f0a01b0;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_info_new = 0x7f0a01b1;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_label = 0x7f0a01b2;

        /* JADX INFO: Added by JADX */
        public static final int inter_ad_tag_layout = 0x7f0a01b3;

        /* JADX INFO: Added by JADX */
        public static final int inter_advertiser = 0x7f0a01b4;

        /* JADX INFO: Added by JADX */
        public static final int inter_banner_click_guide_contain = 0x7f0a01b5;

        /* JADX INFO: Added by JADX */
        public static final int inter_banner_click_guide_layer = 0x7f0a01b6;

        /* JADX INFO: Added by JADX */
        public static final int inter_banner_click_img = 0x7f0a01b7;

        /* JADX INFO: Added by JADX */
        public static final int inter_banner_container = 0x7f0a01b8;

        /* JADX INFO: Added by JADX */
        public static final int inter_blank_viewholder = 0x7f0a01b9;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_close = 0x7f0a01ba;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_cta = 0x7f0a01bb;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_cta_layout = 0x7f0a01bc;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_cta_main = 0x7f0a01bd;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_cta_main_layout = 0x7f0a01be;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_end_page_cta_layout = 0x7f0a01bf;

        /* JADX INFO: Added by JADX */
        public static final int inter_btn_mute = 0x7f0a01c0;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide = 0x7f0a01c1;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_container = 0x7f0a01c2;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_icon_layout = 0x7f0a01c3;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_image = 0x7f0a01c4;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_image_background = 0x7f0a01c5;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_image_layout = 0x7f0a01c6;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_guide_title_layout = 0x7f0a01c7;

        /* JADX INFO: Added by JADX */
        public static final int inter_click_ripple = 0x7f0a01c8;

        /* JADX INFO: Added by JADX */
        public static final int inter_commit_num = 0x7f0a01c9;

        /* JADX INFO: Added by JADX */
        public static final int inter_company = 0x7f0a01ca;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_19 = 0x7f0a01cb;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_20 = 0x7f0a01cc;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_21 = 0x7f0a01cd;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_22 = 0x7f0a01ce;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_23 = 0x7f0a01cf;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_24 = 0x7f0a01d0;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_25 = 0x7f0a01d1;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_26 = 0x7f0a01d2;

        /* JADX INFO: Added by JADX */
        public static final int inter_component_layout = 0x7f0a01d3;

        /* JADX INFO: Added by JADX */
        public static final int inter_container = 0x7f0a01d4;

        /* JADX INFO: Added by JADX */
        public static final int inter_description = 0x7f0a01d5;

        /* JADX INFO: Added by JADX */
        public static final int inter_download_layout = 0x7f0a01d6;

        /* JADX INFO: Added by JADX */
        public static final int inter_download_msg = 0x7f0a01d7;

        /* JADX INFO: Added by JADX */
        public static final int inter_download_num = 0x7f0a01d8;

        /* JADX INFO: Added by JADX */
        public static final int inter_download_num_layout = 0x7f0a01d9;

        /* JADX INFO: Added by JADX */
        public static final int inter_end_page = 0x7f0a01da;

        /* JADX INFO: Added by JADX */
        public static final int inter_end_page_image = 0x7f0a01db;

        /* JADX INFO: Added by JADX */
        public static final int inter_end_page_image_background = 0x7f0a01dc;

        /* JADX INFO: Added by JADX */
        public static final int inter_end_page_image_layout = 0x7f0a01dd;

        /* JADX INFO: Added by JADX */
        public static final int inter_everyone_icon = 0x7f0a01de;

        /* JADX INFO: Added by JADX */
        public static final int inter_everyone_layout = 0x7f0a01df;

        /* JADX INFO: Added by JADX */
        public static final int inter_fbl_genre = 0x7f0a01e0;

        /* JADX INFO: Added by JADX */
        public static final int inter_feedback_cta = 0x7f0a01e1;

        /* JADX INFO: Added by JADX */
        public static final int inter_feedback_dec = 0x7f0a01e2;

        /* JADX INFO: Added by JADX */
        public static final int inter_feedback_title = 0x7f0a01e3;

        /* JADX INFO: Added by JADX */
        public static final int inter_fl_icon = 0x7f0a01e4;

        /* JADX INFO: Added by JADX */
        public static final int inter_fl_interaction = 0x7f0a01e5;

        /* JADX INFO: Added by JADX */
        public static final int inter_fl_interaction_container = 0x7f0a01e6;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_check_box = 0x7f0a01e7;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_content = 0x7f0a01e8;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_content_description = 0x7f0a01e9;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_content_icon = 0x7f0a01ea;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_content_layout = 0x7f0a01eb;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_content_title = 0x7f0a01ec;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_edit_content = 0x7f0a01ed;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_edit_title = 0x7f0a01ee;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_edit_warning = 0x7f0a01ef;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_icon_layout = 0x7f0a01f0;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_privacy_desc = 0x7f0a01f1;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_privacy_notice = 0x7f0a01f2;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_question_layout = 0x7f0a01f3;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_question_purpose = 0x7f0a01f4;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_scroll = 0x7f0a01f5;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_submit = 0x7f0a01f6;

        /* JADX INFO: Added by JADX */
        public static final int inter_form_submit_layout = 0x7f0a01f7;

        /* JADX INFO: Added by JADX */
        public static final int inter_gesture_slide_layout = 0x7f0a01f8;

        /* JADX INFO: Added by JADX */
        public static final int inter_gesture_zoom_layout = 0x7f0a01f9;

        /* JADX INFO: Added by JADX */
        public static final int inter_gp_btn_close = 0x7f0a01fa;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon = 0x7f0a01fb;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_icon_item_layout = 0x7f0a01fc;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_item_btn_cta = 0x7f0a01fd;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_item_desc = 0x7f0a01fe;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_item_icon = 0x7f0a01ff;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_item_sponsored = 0x7f0a0200;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_item_title = 0x7f0a0201;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_ads_view_flow = 0x7f0a0202;

        /* JADX INFO: Added by JADX */
        public static final int inter_icon_layout = 0x7f0a0203;

        /* JADX INFO: Added by JADX */
        public static final int inter_iconlist_download_msg_list = 0x7f0a0204;

        /* JADX INFO: Added by JADX */
        public static final int inter_icons_bottom_anchor = 0x7f0a0205;

        /* JADX INFO: Added by JADX */
        public static final int inter_icons_center_anchor = 0x7f0a0206;

        /* JADX INFO: Added by JADX */
        public static final int inter_image_indicator = 0x7f0a0207;

        /* JADX INFO: Added by JADX */
        public static final int inter_image_layout = 0x7f0a0208;

        /* JADX INFO: Added by JADX */
        public static final int inter_image_view_flow = 0x7f0a0209;

        /* JADX INFO: Added by JADX */
        public static final int inter_info_area = 0x7f0a020a;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_age = 0x7f0a020b;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_fallback_media = 0x7f0a020c;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_gp_info_extra_arrow = 0x7f0a020d;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_icon = 0x7f0a020e;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_interaction_arrow = 0x7f0a020f;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_interaction_phone = 0x7f0a0210;

        /* JADX INFO: Added by JADX */
        public static final int inter_iv_slide_view = 0x7f0a0211;

        /* JADX INFO: Added by JADX */
        public static final int inter_landpage_webview_page = 0x7f0a0212;

        /* JADX INFO: Added by JADX */
        public static final int inter_landscape_media_container = 0x7f0a0213;

        /* JADX INFO: Added by JADX */
        public static final int inter_landscape_media_container_wrap = 0x7f0a0214;

        /* JADX INFO: Added by JADX */
        public static final int inter_layout_ad_tag = 0x7f0a0215;

        /* JADX INFO: Added by JADX */
        public static final int inter_layout_end_page = 0x7f0a0216;

        /* JADX INFO: Added by JADX */
        public static final int inter_layout_mask = 0x7f0a0217;

        /* JADX INFO: Added by JADX */
        public static final int inter_layout_playable_loading = 0x7f0a0218;

        /* JADX INFO: Added by JADX */
        public static final int inter_ll_fallback_media = 0x7f0a0219;

        /* JADX INFO: Added by JADX */
        public static final int inter_ll_media = 0x7f0a021a;

        /* JADX INFO: Added by JADX */
        public static final int inter_ll_native_extra = 0x7f0a021b;

        /* JADX INFO: Added by JADX */
        public static final int inter_ll_start_rate = 0x7f0a021c;

        /* JADX INFO: Added by JADX */
        public static final int inter_main = 0x7f0a021d;

        /* JADX INFO: Added by JADX */
        public static final int inter_media = 0x7f0a021e;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_card_container = 0x7f0a021f;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_card_info_container = 0x7f0a0220;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_card_layout = 0x7f0a0221;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_card_top_layout = 0x7f0a0222;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_desc = 0x7f0a0223;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_extra = 0x7f0a0224;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_ad_view_flow = 0x7f0a0225;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_bottom_layout = 0x7f0a0226;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_bottom_left = 0x7f0a0227;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_component = 0x7f0a0228;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_container = 0x7f0a0229;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_gp_background = 0x7f0a022a;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_gp_container = 0x7f0a022b;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_gp_content = 0x7f0a022c;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_item = 0x7f0a022d;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_item_background = 0x7f0a022e;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_item_container = 0x7f0a022f;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_item_layout = 0x7f0a0230;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_layout = 0x7f0a0231;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_main_background = 0x7f0a0232;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_main_container = 0x7f0a0233;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_multi_img_extra = 0x7f0a0234;

        /* JADX INFO: Added by JADX */
        public static final int inter_media_rounded = 0x7f0a0235;

        /* JADX INFO: Added by JADX */
        public static final int inter_mid_native_view = 0x7f0a0236;

        /* JADX INFO: Added by JADX */
        public static final int inter_more = 0x7f0a0237;

        /* JADX INFO: Added by JADX */
        public static final int inter_native_ad_view = 0x7f0a0238;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_btn_copy_ru_ad_marker = 0x7f0a0239;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_layout_start = 0x7f0a023a;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_line = 0x7f0a023b;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_ll_ad_info = 0x7f0a023c;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_text_copy_ru_ad_marker = 0x7f0a023d;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_tv_ad_copy_link = 0x7f0a023e;

        /* JADX INFO: Added by JADX */
        public static final int inter_option_tv_ad_info = 0x7f0a023f;

        /* JADX INFO: Added by JADX */
        public static final int inter_options = 0x7f0a0240;

        /* JADX INFO: Added by JADX */
        public static final int inter_other_layout = 0x7f0a0241;

        /* JADX INFO: Added by JADX */
        public static final int inter_play_page = 0x7f0a0242;

        /* JADX INFO: Added by JADX */
        public static final int inter_popup_close_btn = 0x7f0a0243;

        /* JADX INFO: Added by JADX */
        public static final int inter_popup_msg = 0x7f0a0244;

        /* JADX INFO: Added by JADX */
        public static final int inter_privacy_btn_layout = 0x7f0a0245;

        /* JADX INFO: Added by JADX */
        public static final int inter_privacy_notice_container = 0x7f0a0246;

        /* JADX INFO: Added by JADX */
        public static final int inter_rounded_icon_layout = 0x7f0a0247;

        /* JADX INFO: Added by JADX */
        public static final int inter_separator = 0x7f0a0248;

        /* JADX INFO: Added by JADX */
        public static final int inter_slide_gesture = 0x7f0a0249;

        /* JADX INFO: Added by JADX */
        public static final int inter_slide_gesture_contain = 0x7f0a024a;

        /* JADX INFO: Added by JADX */
        public static final int inter_slide_text = 0x7f0a024b;

        /* JADX INFO: Added by JADX */
        public static final int inter_splash_adtage = 0x7f0a024c;

        /* JADX INFO: Added by JADX */
        public static final int inter_splash_advertiser = 0x7f0a024d;

        /* JADX INFO: Added by JADX */
        public static final int inter_splash_slide = 0x7f0a024e;

        /* JADX INFO: Added by JADX */
        public static final int inter_star = 0x7f0a024f;

        /* JADX INFO: Added by JADX */
        public static final int inter_star_layout = 0x7f0a0250;

        /* JADX INFO: Added by JADX */
        public static final int inter_star_num = 0x7f0a0251;

        /* JADX INFO: Added by JADX */
        public static final int inter_submit_success_container = 0x7f0a0252;

        /* JADX INFO: Added by JADX */
        public static final int inter_text_countdown = 0x7f0a0253;

        /* JADX INFO: Added by JADX */
        public static final int inter_text_layout = 0x7f0a0254;

        /* JADX INFO: Added by JADX */
        public static final int inter_title = 0x7f0a0255;

        /* JADX INFO: Added by JADX */
        public static final int inter_title_container = 0x7f0a0256;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_age = 0x7f0a0257;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_comment = 0x7f0a0258;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_company_name = 0x7f0a0259;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_desc = 0x7f0a025a;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_desc_below = 0x7f0a025b;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_download_num = 0x7f0a025c;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_download_num_desc = 0x7f0a025d;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_gp_info_extra_about = 0x7f0a025e;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_interaction_type = 0x7f0a025f;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_slide_view = 0x7f0a0260;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_start_rate = 0x7f0a0261;

        /* JADX INFO: Added by JADX */
        public static final int inter_tv_title = 0x7f0a0262;

        /* JADX INFO: Added by JADX */
        public static final int inter_vf_indicator = 0x7f0a0263;

        /* JADX INFO: Added by JADX */
        public static final int inter_view_stroke = 0x7f0a0264;

        /* JADX INFO: Added by JADX */
        public static final int inter_warning = 0x7f0a0265;

        /* JADX INFO: Added by JADX */
        public static final int inter_warning_layout = 0x7f0a0266;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_back = 0x7f0a0267;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_bottom_bar = 0x7f0a0268;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_close = 0x7f0a0269;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_container = 0x7f0a026a;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_copy = 0x7f0a026b;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_forward = 0x7f0a026c;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_host = 0x7f0a026d;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_host_layout = 0x7f0a026e;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_open = 0x7f0a026f;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_progress_bar = 0x7f0a0270;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_refresh = 0x7f0a0271;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_safe = 0x7f0a0272;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_title = 0x7f0a0273;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_top_action_bar = 0x7f0a0274;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_top_bar = 0x7f0a0275;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_top_indicator = 0x7f0a0276;

        /* JADX INFO: Added by JADX */
        public static final int inter_webview_top_middle = 0x7f0a0277;

        /* JADX INFO: Added by JADX */
        public static final int interaction_root = 0x7f0a0278;

        /* JADX INFO: Added by JADX */
        public static final int internal_store_content = 0x7f0a0279;

        /* JADX INFO: Added by JADX */
        public static final int interstitial_control_button = 0x7f0a027a;

        /* JADX INFO: Added by JADX */
        public static final int interstitial_control_view = 0x7f0a027b;

        /* JADX INFO: Added by JADX */
        public static final int invisible = 0x7f0a027c;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f0a027d;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f0a027e;

        /* JADX INFO: Added by JADX */
        public static final int item = 0x7f0a027f;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_previous_elevation = 0x7f0a0280;

        /* JADX INFO: Added by JADX */
        public static final int iv_blur_bg = 0x7f0a0281;

        /* JADX INFO: Added by JADX */
        public static final int iv_blur_bg_mask = 0x7f0a0282;

        /* JADX INFO: Added by JADX */
        public static final int iv_gp_info_extra_arrow = 0x7f0a0283;

        /* JADX INFO: Added by JADX */
        public static final int iv_media_blur_bg = 0x7f0a0284;

        /* JADX INFO: Added by JADX */
        public static final int iv_media_blur_bg_mask = 0x7f0a0285;

        /* JADX INFO: Added by JADX */
        public static final int iv_switch = 0x7f0a0286;

        /* JADX INFO: Added by JADX */
        public static final int jumpToEnd = 0x7f0a0287;

        /* JADX INFO: Added by JADX */
        public static final int jumpToStart = 0x7f0a0288;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f0a0289;

        /* JADX INFO: Added by JADX */
        public static final int layout_ad_component = 0x7f0a028a;

        /* JADX INFO: Added by JADX */
        public static final int layout_contain_view = 0x7f0a028b;

        /* JADX INFO: Added by JADX */
        public static final int layout_cta_widget_inner = 0x7f0a028c;

        /* JADX INFO: Added by JADX */
        public static final int layout_playable_loading = 0x7f0a028d;

        /* JADX INFO: Added by JADX */
        public static final int left = 0x7f0a028e;

        /* JADX INFO: Added by JADX */
        public static final int legacy = 0x7f0a028f;

        /* JADX INFO: Added by JADX */
        public static final int light = 0x7f0a0290;

        /* JADX INFO: Added by JADX */
        public static final int line = 0x7f0a0291;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f0a0292;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f0a0293;

        /* JADX INFO: Added by JADX */
        public static final int linear = 0x7f0a0294;

        /* JADX INFO: Added by JADX */
        public static final int listMode = 0x7f0a0295;

        /* JADX INFO: Added by JADX */
        public static final int listView = 0x7f0a0296;

        /* JADX INFO: Added by JADX */
        public static final int list_item = 0x7f0a0297;

        /* JADX INFO: Added by JADX */
        public static final int ll_items = 0x7f0a0298;

        /* JADX INFO: Added by JADX */
        public static final int ll_native_extra = 0x7f0a0299;

        /* JADX INFO: Added by JADX */
        public static final int match_constraint = 0x7f0a029a;

        /* JADX INFO: Added by JADX */
        public static final int match_parent = 0x7f0a029b;

        /* JADX INFO: Added by JADX */
        public static final int mbridgeAttached = 0x7f0a029c;

        /* JADX INFO: Added by JADX */
        public static final int mbridgeClicked = 0x7f0a029d;

        /* JADX INFO: Added by JADX */
        public static final int mbridgeDetached = 0x7f0a029e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_alertview_close_button = 0x7f0a029f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_alertview_contentview = 0x7f0a02a0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_alertview_continue_button = 0x7f0a02a1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_alertview_titleview = 0x7f0a02a2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_animation_click_view = 0x7f0a02a3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_finger_bg = 0x7f0a02a4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_icon_iv = 0x7f0a02a5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_item_rl = 0x7f0a02a6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_iv = 0x7f0a02a7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_play_bg = 0x7f0a02a8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_ration = 0x7f0a02a9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bottom_title_tv = 0x7f0a02aa;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bt_container = 0x7f0a02ab;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bt_container_root = 0x7f0a02ac;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_center_view = 0x7f0a02ad;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_choice_frl = 0x7f0a02ae;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_choice_one_countdown_tv = 0x7f0a02af;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cta_layout = 0x7f0a02b0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_ec_layout_center = 0x7f0a02b1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_ec_layout_top = 0x7f0a02b2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_animation_content = 0x7f0a02b3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_animation_player = 0x7f0a02b4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_iv_close = 0x7f0a02b5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_pb_loading = 0x7f0a02b6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_player_parent = 0x7f0a02b7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_rl_close = 0x7f0a02b8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_rl_playcontainer = 0x7f0a02b9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_display_content = 0x7f0a02ba;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_display_description = 0x7f0a02bb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_display_icon = 0x7f0a02bc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_display_title = 0x7f0a02bd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_feeds_star = 0x7f0a02be;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_full_tv_install = 0x7f0a02bf;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_iv_close = 0x7f0a02c0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_pb = 0x7f0a02c1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_wv = 0x7f0a02c2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_adbanner = 0x7f0a02c3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_adbanner_bg = 0x7f0a02c4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_appicon = 0x7f0a02c5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_close = 0x7f0a02c6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_flag = 0x7f0a02c7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_icon = 0x7f0a02c8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_iconbg = 0x7f0a02c9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_link = 0x7f0a02ca;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_logo = 0x7f0a02cb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_pause = 0x7f0a02cc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_play = 0x7f0a02cd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_playend_pic = 0x7f0a02ce;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_sound = 0x7f0a02cf;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_sound_animation = 0x7f0a02d0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_vastclose = 0x7f0a02d1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_iv_vastok = 0x7f0a02d2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_layout_bottomLayout = 0x7f0a02d3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_ll_loading = 0x7f0a02d4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_ll_playerview_container = 0x7f0a02d5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_desc_tv = 0x7f0a02d6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_icon_iv = 0x7f0a02d7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_item_rl = 0x7f0a02d8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_iv = 0x7f0a02d9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_iv_bg = 0x7f0a02da;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_iv_burl = 0x7f0a02db;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_iv_cover = 0x7f0a02dc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_sv_starlevel = 0x7f0a02dd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_title_tv = 0x7f0a02de;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_lv_tv_install = 0x7f0a02df;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_more_offer_ll_item = 0x7f0a02e0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_moreoffer_hls = 0x7f0a02e1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_my_big_img = 0x7f0a02e2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_ec_controller = 0x7f0a02e3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_ec_layer_layout = 0x7f0a02e4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_ec_layout = 0x7f0a02e5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_ec_rl = 0x7f0a02e6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_endcard_feed_btn = 0x7f0a02e7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_order_camp_controller = 0x7f0a02e8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_order_camp_feed_btn = 0x7f0a02e9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_pb = 0x7f0a02ea;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_native_rl_root = 0x7f0a02eb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_webview_layout = 0x7f0a02ec;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_webview_layout_webview = 0x7f0a02ed;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_view_h_lv = 0x7f0a02ee;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_view_iv_close = 0x7f0a02ef;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_view_lv = 0x7f0a02f0;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_viewed_tv = 0x7f0a02f1;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_playercommon_ll_loading = 0x7f0a02f2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_playercommon_ll_sur_container = 0x7f0a02f3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_playercommon_rl_root = 0x7f0a02f4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_progress = 0x7f0a02f5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_progressBar = 0x7f0a02f6;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_progressBar1 = 0x7f0a02f7;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_bottom_layout = 0x7f0a02f8;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_bottom_widget = 0x7f0a02f9;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_choice_one_like_iv = 0x7f0a02fa;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_click_tv = 0x7f0a02fb;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_cta_layout = 0x7f0a02fc;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_desc_tv = 0x7f0a02fd;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_item_iv = 0x7f0a02fe;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_item_title_tv = 0x7f0a02ff;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_like_tv = 0x7f0a0300;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_more_offer_rl = 0x7f0a0301;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_offer_title_rl = 0x7f0a0302;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_header_layout = 0x7f0a0303;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_icon_riv = 0x7f0a0304;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_logo_iv = 0x7f0a0305;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_popview = 0x7f0a0306;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_root_container = 0x7f0a0307;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_scale_webview_layout = 0x7f0a0308;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_segment_progressbar = 0x7f0a0309;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_stars_mllv = 0x7f0a030a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_title_tv = 0x7f0a030b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_rl_content = 0x7f0a030c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_rl_mediaview_root = 0x7f0a030d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_rl_playing_close = 0x7f0a030e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_sound_switch = 0x7f0a030f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_feedback = 0x7f0a0310;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_iv_foregroundimage = 0x7f0a0311;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_iv_icon = 0x7f0a0312;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_iv_image = 0x7f0a0313;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_iv_image_bg = 0x7f0a0314;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_iv_link = 0x7f0a0315;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_landscape_foreground = 0x7f0a0316;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_layout_appinfo = 0x7f0a0317;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_layout_foreground = 0x7f0a0318;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_topcontroller = 0x7f0a0319;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_adcircle = 0x7f0a031a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_adrect = 0x7f0a031b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_app_desc = 0x7f0a031c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_appinfo = 0x7f0a031d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_click = 0x7f0a031e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_permission = 0x7f0a031f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_privacy = 0x7f0a0320;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_skip = 0x7f0a0321;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_tv_title = 0x7f0a0322;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_sv_starlevel = 0x7f0a0323;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tag_icon = 0x7f0a0324;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tag_title = 0x7f0a0325;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_temp_container = 0x7f0a0326;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_textView = 0x7f0a0327;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_text_layout = 0x7f0a0328;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_textureview = 0x7f0a0329;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_title_layout = 0x7f0a032a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_control = 0x7f0a032b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_finger_bg = 0x7f0a032c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_icon_iv = 0x7f0a032d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_item_rl = 0x7f0a032e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_iv = 0x7f0a032f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_play_bg = 0x7f0a0330;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_ration = 0x7f0a0331;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_top_title_tv = 0x7f0a0332;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_appdesc = 0x7f0a0333;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_apptitle = 0x7f0a0334;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_count = 0x7f0a0335;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_cta = 0x7f0a0336;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_desc = 0x7f0a0337;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_flag = 0x7f0a0338;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_install = 0x7f0a0339;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_number = 0x7f0a033a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_number_layout = 0x7f0a033b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_reward_status = 0x7f0a033c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_title = 0x7f0a033d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_vasttag = 0x7f0a033e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_tv_vasttitle = 0x7f0a033f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vec_btn = 0x7f0a0340;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vec_iv_close = 0x7f0a0341;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vec_iv_icon = 0x7f0a0342;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vec_tv_desc = 0x7f0a0343;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vec_tv_title = 0x7f0a0344;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vfpv = 0x7f0a0345;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_vfpv_fl = 0x7f0a0346;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_cancel_button = 0x7f0a0347;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_confirm_button = 0x7f0a0348;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_contentview = 0x7f0a0349;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_contentview_scrollview = 0x7f0a034a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_private_action_button = 0x7f0a034b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_common_alertview_titleview = 0x7f0a034c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_progress_bar = 0x7f0a034d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_templete_container = 0x7f0a034e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_templete_progressbar = 0x7f0a034f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_templete_videoview = 0x7f0a0350;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_video_templete_webview_parent = 0x7f0a0351;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_videoview_bg = 0x7f0a0352;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_view_cover = 0x7f0a0353;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_viewgroup_ctaroot = 0x7f0a0354;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_windwv_close = 0x7f0a0355;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_windwv_content_rl = 0x7f0a0356;

        /* JADX INFO: Added by JADX */
        public static final int media_actions = 0x7f0a0357;

        /* JADX INFO: Added by JADX */
        public static final int media_controller_compat_view_tag = 0x7f0a0358;

        /* JADX INFO: Added by JADX */
        public static final int media_layout = 0x7f0a0359;

        /* JADX INFO: Added by JADX */
        public static final int media_view = 0x7f0a035a;

        /* JADX INFO: Added by JADX */
        public static final int message = 0x7f0a035b;

        /* JADX INFO: Added by JADX */
        public static final int middle = 0x7f0a035c;

        /* JADX INFO: Added by JADX */
        public static final int moloco_fullscreen_ad_view_id = 0x7f0a035d;

        /* JADX INFO: Added by JADX */
        public static final int motion_base = 0x7f0a035e;

        /* JADX INFO: Added by JADX */
        public static final int mraid_video_view = 0x7f0a035f;

        /* JADX INFO: Added by JADX */
        public static final int mrec_ad_view_container = 0x7f0a0360;

        /* JADX INFO: Added by JADX */
        public static final int mrec_control_button = 0x7f0a0361;

        /* JADX INFO: Added by JADX */
        public static final int mrec_control_view = 0x7f0a0362;

        /* JADX INFO: Added by JADX */
        public static final int multiply = 0x7f0a0363;

        /* JADX INFO: Added by JADX */
        public static final int native_ad_label = 0x7f0a0364;

        /* JADX INFO: Added by JADX */
        public static final int native_ad_view = 0x7f0a0365;

        /* JADX INFO: Added by JADX */
        public static final int native_ad_view_container = 0x7f0a0366;

        /* JADX INFO: Added by JADX */
        public static final int native_advertiser = 0x7f0a0367;

        /* JADX INFO: Added by JADX */
        public static final int native_banner_switch = 0x7f0a0368;

        /* JADX INFO: Added by JADX */
        public static final int native_control_button = 0x7f0a0369;

        /* JADX INFO: Added by JADX */
        public static final int native_control_view = 0x7f0a036a;

        /* JADX INFO: Added by JADX */
        public static final int native_cta = 0x7f0a036b;

        /* JADX INFO: Added by JADX */
        public static final int native_description = 0x7f0a036c;

        /* JADX INFO: Added by JADX */
        public static final int native_icon_view = 0x7f0a036d;

        /* JADX INFO: Added by JADX */
        public static final int native_media_view = 0x7f0a036e;

        /* JADX INFO: Added by JADX */
        public static final int native_mrec_switch = 0x7f0a036f;

        /* JADX INFO: Added by JADX */
        public static final int native_option_view = 0x7f0a0370;

        /* JADX INFO: Added by JADX */
        public static final int native_title = 0x7f0a0371;

        /* JADX INFO: Added by JADX */
        public static final int native_view = 0x7f0a0372;

        /* JADX INFO: Added by JADX */
        public static final int native_warning = 0x7f0a0373;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f0a0374;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToEnd = 0x7f0a0375;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToStart = 0x7f0a0376;

        /* JADX INFO: Added by JADX */
        public static final int noState = 0x7f0a0377;

        /* JADX INFO: Added by JADX */
        public static final int none = 0x7f0a0378;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f0a0379;

        /* JADX INFO: Added by JADX */
        public static final int north = 0x7f0a037a;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f0a037b;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f0a037c;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f0a037d;

        /* JADX INFO: Added by JADX */
        public static final int number = 0x7f0a037e;

        /* JADX INFO: Added by JADX */
        public static final int off = 0x7f0a037f;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_advertiser_name = 0x7f0a0380;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_image = 0x7f0a0381;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_text = 0x7f0a0382;

        /* JADX INFO: Added by JADX */
        public static final int on = 0x7f0a0383;

        /* JADX INFO: Added by JADX */
        public static final int onInterceptTouchReturnSwipe = 0x7f0a0384;

        /* JADX INFO: Added by JADX */
        public static final int one = 0x7f0a0385;

        /* JADX INFO: Added by JADX */
        public static final int other = 0x7f0a0386;

        /* JADX INFO: Added by JADX */
        public static final int overshoot = 0x7f0a0387;

        /* JADX INFO: Added by JADX */
        public static final int packed = 0x7f0a0388;

        /* JADX INFO: Added by JADX */
        public static final int parent = 0x7f0a0389;

        /* JADX INFO: Added by JADX */
        public static final int parentPanel = 0x7f0a038a;

        /* JADX INFO: Added by JADX */
        public static final int parentRelative = 0x7f0a038b;

        /* JADX INFO: Added by JADX */
        public static final int path = 0x7f0a038c;

        /* JADX INFO: Added by JADX */
        public static final int pathRelative = 0x7f0a038d;

        /* JADX INFO: Added by JADX */
        public static final int percent = 0x7f0a038e;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f0a038f;

        /* JADX INFO: Added by JADX */
        public static final int pop_up_bottom_layout = 0x7f0a0390;

        /* JADX INFO: Added by JADX */
        public static final int position = 0x7f0a0391;

        /* JADX INFO: Added by JADX */
        public static final int postLayout = 0x7f0a0392;

        /* JADX INFO: Added by JADX */
        public static final int primary = 0x7f0a0393;

        /* JADX INFO: Added by JADX */
        public static final int privacy_icon_button = 0x7f0a0394;

        /* JADX INFO: Added by JADX */
        public static final int progress_circular = 0x7f0a0395;

        /* JADX INFO: Added by JADX */
        public static final int progress_horizontal = 0x7f0a0396;

        /* JADX INFO: Added by JADX */
        public static final int radio = 0x7f0a0397;

        /* JADX INFO: Added by JADX */
        public static final int range = 0x7f0a0398;

        /* JADX INFO: Added by JADX */
        public static final int rating_bar = 0x7f0a0399;

        /* JADX INFO: Added by JADX */
        public static final int ratio = 0x7f0a039a;

        /* JADX INFO: Added by JADX */
        public static final int rectangles = 0x7f0a039b;

        /* JADX INFO: Added by JADX */
        public static final int recycler_view = 0x7f0a039c;

        /* JADX INFO: Added by JADX */
        public static final int report_ad_button = 0x7f0a039d;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f0a039e;

        /* JADX INFO: Added by JADX */
        public static final int reportad_adtye_slect_layout = 0x7f0a039f;

        /* JADX INFO: Added by JADX */
        public static final int reportad_adtye_slected_arrow = 0x7f0a03a0;

        /* JADX INFO: Added by JADX */
        public static final int reportad_adtye_slected_tv = 0x7f0a03a1;

        /* JADX INFO: Added by JADX */
        public static final int reportad_desc_et = 0x7f0a03a2;

        /* JADX INFO: Added by JADX */
        public static final int reportad_emial_et = 0x7f0a03a3;

        /* JADX INFO: Added by JADX */
        public static final int reportad_issue_type_slect_layout = 0x7f0a03a4;

        /* JADX INFO: Added by JADX */
        public static final int reportad_issue_type_slected_arrow = 0x7f0a03a5;

        /* JADX INFO: Added by JADX */
        public static final int reportad_issue_type_slected_tv = 0x7f0a03a6;

        /* JADX INFO: Added by JADX */
        public static final int reverseSawtooth = 0x7f0a03a7;

        /* JADX INFO: Added by JADX */
        public static final int rewarded_control_button = 0x7f0a03a8;

        /* JADX INFO: Added by JADX */
        public static final int rewarded_control_view = 0x7f0a03a9;

        /* JADX INFO: Added by JADX */
        public static final int right = 0x7f0a03aa;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f0a03ab;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f0a03ac;

        /* JADX INFO: Added by JADX */
        public static final int row_two = 0x7f0a03ad;

        /* JADX INFO: Added by JADX */
        public static final int rv_ad_networks_section = 0x7f0a03ae;

        /* JADX INFO: Added by JADX */
        public static final int rv_features_test_section = 0x7f0a03af;

        /* JADX INFO: Added by JADX */
        public static final int rv_general_info_section = 0x7f0a03b0;

        /* JADX INFO: Added by JADX */
        public static final int rv_mediations_section = 0x7f0a03b1;

        /* JADX INFO: Added by JADX */
        public static final int sawtooth = 0x7f0a03b2;

        /* JADX INFO: Added by JADX */
        public static final int screen = 0x7f0a03b3;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorDown = 0x7f0a03b4;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorUp = 0x7f0a03b5;

        /* JADX INFO: Added by JADX */
        public static final int scrollView = 0x7f0a03b6;

        /* JADX INFO: Added by JADX */
        public static final int search_badge = 0x7f0a03b7;

        /* JADX INFO: Added by JADX */
        public static final int search_bar = 0x7f0a03b8;

        /* JADX INFO: Added by JADX */
        public static final int search_button = 0x7f0a03b9;

        /* JADX INFO: Added by JADX */
        public static final int search_close_btn = 0x7f0a03ba;

        /* JADX INFO: Added by JADX */
        public static final int search_edit_frame = 0x7f0a03bb;

        /* JADX INFO: Added by JADX */
        public static final int search_go_btn = 0x7f0a03bc;

        /* JADX INFO: Added by JADX */
        public static final int search_mag_icon = 0x7f0a03bd;

        /* JADX INFO: Added by JADX */
        public static final int search_plate = 0x7f0a03be;

        /* JADX INFO: Added by JADX */
        public static final int search_src_text = 0x7f0a03bf;

        /* JADX INFO: Added by JADX */
        public static final int search_voice_btn = 0x7f0a03c0;

        /* JADX INFO: Added by JADX */
        public static final int second_text = 0x7f0a03c1;

        /* JADX INFO: Added by JADX */
        public static final int secondary = 0x7f0a03c2;

        /* JADX INFO: Added by JADX */
        public static final int seekbar = 0x7f0a03c3;

        /* JADX INFO: Added by JADX */
        public static final int seekbar_value = 0x7f0a03c4;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_listview = 0x7f0a03c5;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueSet = 0x7f0a03c6;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueUnset = 0x7f0a03c7;

        /* JADX INFO: Added by JADX */
        public static final int shortcut = 0x7f0a03c8;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 0x7f0a03c9;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 0x7f0a03ca;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f0a03cb;

        /* JADX INFO: Added by JADX */
        public static final int showWhenTouch = 0x7f0a03cc;

        /* JADX INFO: Added by JADX */
        public static final int show_mrec_button = 0x7f0a03cd;

        /* JADX INFO: Added by JADX */
        public static final int show_native_button = 0x7f0a03ce;

        /* JADX INFO: Added by JADX */
        public static final int sin = 0x7f0a03cf;

        /* JADX INFO: Added by JADX */
        public static final int single = 0x7f0a03d0;

        /* JADX INFO: Added by JADX */
        public static final int skipped = 0x7f0a03d1;

        /* JADX INFO: Added by JADX */
        public static final int south = 0x7f0a03d2;

        /* JADX INFO: Added by JADX */
        public static final int spacer = 0x7f0a03d3;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 0x7f0a03d4;

        /* JADX INFO: Added by JADX */
        public static final int spherical_gl_surface_view = 0x7f0a03d5;

        /* JADX INFO: Added by JADX */
        public static final int spinner = 0x7f0a03d6;

        /* JADX INFO: Added by JADX */
        public static final int splash_footer_bg = 0x7f0a03d7;

        /* JADX INFO: Added by JADX */
        public static final int splash_rating_star = 0x7f0a03d8;

        /* JADX INFO: Added by JADX */
        public static final int splash_slide = 0x7f0a03d9;

        /* JADX INFO: Added by JADX */
        public static final int splash_slide_hand = 0x7f0a03da;

        /* JADX INFO: Added by JADX */
        public static final int spline = 0x7f0a03db;

        /* JADX INFO: Added by JADX */
        public static final int split_action_bar = 0x7f0a03dc;

        /* JADX INFO: Added by JADX */
        public static final int spread = 0x7f0a03dd;

        /* JADX INFO: Added by JADX */
        public static final int spread_inside = 0x7f0a03de;

        /* JADX INFO: Added by JADX */
        public static final int spring = 0x7f0a03df;

        /* JADX INFO: Added by JADX */
        public static final int square = 0x7f0a03e0;

        /* JADX INFO: Added by JADX */
        public static final int src_atop = 0x7f0a03e1;

        /* JADX INFO: Added by JADX */
        public static final int src_in = 0x7f0a03e2;

        /* JADX INFO: Added by JADX */
        public static final int src_over = 0x7f0a03e3;

        /* JADX INFO: Added by JADX */
        public static final int standard = 0x7f0a03e4;

        /* JADX INFO: Added by JADX */
        public static final int start = 0x7f0a03e5;

        /* JADX INFO: Added by JADX */
        public static final int startHorizontal = 0x7f0a03e6;

        /* JADX INFO: Added by JADX */
        public static final int startVertical = 0x7f0a03e7;

        /* JADX INFO: Added by JADX */
        public static final int staticLayout = 0x7f0a03e8;

        /* JADX INFO: Added by JADX */
        public static final int staticPostLayout = 0x7f0a03e9;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_latest_event_content = 0x7f0a03ea;

        /* JADX INFO: Added by JADX */
        public static final int status_textview = 0x7f0a03eb;

        /* JADX INFO: Added by JADX */
        public static final int stop = 0x7f0a03ec;

        /* JADX INFO: Added by JADX */
        public static final int submenuarrow = 0x7f0a03ed;

        /* JADX INFO: Added by JADX */
        public static final int submit_area = 0x7f0a03ee;

        /* JADX INFO: Added by JADX */
        public static final int supportScrollUp = 0x7f0a03ef;

        /* JADX INFO: Added by JADX */
        public static final int surface_view = 0x7f0a03f0;

        /* JADX INFO: Added by JADX */
        public static final int switchWidget = 0x7f0a03f1;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 0x7f0a03f2;

        /* JADX INFO: Added by JADX */
        public static final int tab_ad_networks = 0x7f0a03f3;

        /* JADX INFO: Added by JADX */
        public static final int tab_features = 0x7f0a03f4;

        /* JADX INFO: Added by JADX */
        public static final int tab_general_info = 0x7f0a03f5;

        /* JADX INFO: Added by JADX */
        public static final int tab_mediations = 0x7f0a03f6;

        /* JADX INFO: Added by JADX */
        public static final int tab_separator1 = 0x7f0a03f7;

        /* JADX INFO: Added by JADX */
        public static final int tab_separator2 = 0x7f0a03f8;

        /* JADX INFO: Added by JADX */
        public static final int tab_separator3 = 0x7f0a03f9;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f0a03fa;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f0a03fb;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f0a03fc;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f0a03fd;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f0a03fe;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f0a03ff;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f0a0400;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f0a0401;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f0a0402;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f0a0403;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f0a0404;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f0a0405;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f0a0406;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f0a0407;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f0a0408;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoButtons = 0x7f0a0409;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoTitle = 0x7f0a040a;

        /* JADX INFO: Added by JADX */
        public static final int textView = 0x7f0a040b;

        /* JADX INFO: Added by JADX */
        public static final int texture_view = 0x7f0a040c;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_fragment_name = 0x7f0a040d;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_id = 0x7f0a040e;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_ignored = 0x7f0a040f;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_onclick_timestamp = 0x7f0a0410;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_properties = 0x7f0a0411;

        /* JADX INFO: Added by JADX */
        public static final int thinking_analytics_clone_tag_view_value = 0x7f0a0412;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f0a0413;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f0a0414;

        /* JADX INFO: Added by JADX */
        public static final int titleDividerNoCustom = 0x7f0a0415;

        /* JADX INFO: Added by JADX */
        public static final int title_template = 0x7f0a0416;

        /* JADX INFO: Added by JADX */
        public static final int toggle = 0x7f0a0417;

        /* JADX INFO: Added by JADX */
        public static final int top = 0x7f0a0418;

        /* JADX INFO: Added by JADX */
        public static final int topPanel = 0x7f0a0419;

        /* JADX INFO: Added by JADX */
        public static final int transitionToEnd = 0x7f0a041a;

        /* JADX INFO: Added by JADX */
        public static final int transitionToStart = 0x7f0a041b;

        /* JADX INFO: Added by JADX */
        public static final int triangle = 0x7f0a041c;

        /* JADX INFO: Added by JADX */
        public static final int tv_ad_format_header = 0x7f0a041d;

        /* JADX INFO: Added by JADX */
        public static final int tv_desc_below = 0x7f0a041e;

        /* JADX INFO: Added by JADX */
        public static final int tv_features_test_disclaimer = 0x7f0a041f;

        /* JADX INFO: Added by JADX */
        public static final int tv_gp_info_extra_about = 0x7f0a0420;

        /* JADX INFO: Added by JADX */
        public static final int tv_header = 0x7f0a0421;

        /* JADX INFO: Added by JADX */
        public static final int tv_interstitial_time_limit = 0x7f0a0422;

        /* JADX INFO: Added by JADX */
        public static final int tv_label = 0x7f0a0423;

        /* JADX INFO: Added by JADX */
        public static final int tv_network_name = 0x7f0a0424;

        /* JADX INFO: Added by JADX */
        public static final int tv_rewarded_time_limit = 0x7f0a0425;

        /* JADX INFO: Added by JADX */
        public static final int tv_sdk_version = 0x7f0a0426;

        /* JADX INFO: Added by JADX */
        public static final int tv_status = 0x7f0a0427;

        /* JADX INFO: Added by JADX */
        public static final int tv_supported_sdk_versions = 0x7f0a0428;

        /* JADX INFO: Added by JADX */
        public static final int tv_switch_description = 0x7f0a0429;

        /* JADX INFO: Added by JADX */
        public static final int tv_switch_title = 0x7f0a042a;

        /* JADX INFO: Added by JADX */
        public static final int tv_title = 0x7f0a042b;

        /* JADX INFO: Added by JADX */
        public static final int tv_value = 0x7f0a042c;

        /* JADX INFO: Added by JADX */
        public static final int unchecked = 0x7f0a042d;

        /* JADX INFO: Added by JADX */
        public static final int uniform = 0x7f0a042e;

        /* JADX INFO: Added by JADX */
        public static final int unitySurfaceView = 0x7f0a042f;

        /* JADX INFO: Added by JADX */
        public static final int up = 0x7f0a0430;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 0x7f0a0431;

        /* JADX INFO: Added by JADX */
        public static final int vertical_only = 0x7f0a0432;

        /* JADX INFO: Added by JADX */
        public static final int vf_indicator = 0x7f0a0433;

        /* JADX INFO: Added by JADX */
        public static final int video_decoder_gl_surface_view = 0x7f0a0434;

        /* JADX INFO: Added by JADX */
        public static final int view_transition = 0x7f0a0435;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f0a0436;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f0a0437;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f0a0438;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f0a0439;

        /* JADX INFO: Added by JADX */
        public static final int visible = 0x7f0a043a;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 0x7f0a043b;

        /* JADX INFO: Added by JADX */
        public static final int west = 0x7f0a043c;

        /* JADX INFO: Added by JADX */
        public static final int when_playing = 0x7f0a043d;

        /* JADX INFO: Added by JADX */
        public static final int wide = 0x7f0a043e;

        /* JADX INFO: Added by JADX */
        public static final int withText = 0x7f0a043f;

        /* JADX INFO: Added by JADX */
        public static final int word_icon_container = 0x7f0a0440;

        /* JADX INFO: Added by JADX */
        public static final int wrap = 0x7f0a0441;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content = 0x7f0a0442;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content_constrained = 0x7f0a0443;

        /* JADX INFO: Added by JADX */
        public static final int wrapped_composition_tag = 0x7f0a0444;

        /* JADX INFO: Added by JADX */
        public static final int x_left = 0x7f0a0445;

        /* JADX INFO: Added by JADX */
        public static final int x_right = 0x7f0a0446;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_banner_background = 0x7f0a0447;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_banner_icon = 0x7f0a0448;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_banner_message = 0x7f0a0449;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_banner_visit_site = 0x7f0a044a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_iv_bgimage = 0x7f0a044b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_iv_close = 0x7f0a044c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_iv_interclose = 0x7f0a044d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_iv_interimg = 0x7f0a044e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_actions = 0x7f0a044f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_ad_status = 0x7f0a0450;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_code = 0x7f0a0451;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_content = 0x7f0a0452;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_format = 0x7f0a0453;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_network = 0x7f0a0454;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_header_detail = 0x7f0a0455;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_header_icon = 0x7f0a0456;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_header_title = 0x7f0a0457;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_header_title = 0x7f0a0458;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_item_detail = 0x7f0a0459;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_item_icon = 0x7f0a045a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_item_title = 0x7f0a045b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_list = 0x7f0a045c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item_arrow = 0x7f0a045d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item_image = 0x7f0a045e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item_status = 0x7f0a045f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item_title = 0x7f0a0460;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item_version = 0x7f0a0461;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_list = 0x7f0a0462;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_item_detail = 0x7f0a0463;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_item_icon = 0x7f0a0464;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_item_title = 0x7f0a0465;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_list = 0x7f0a0466;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_age = 0x7f0a0467;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_confirm = 0x7f0a0468;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_msg = 0x7f0a0469;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_prompt = 0x7f0a046a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_sc = 0x7f0a046b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_seekbar = 0x7f0a046c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_title = 0x7f0a046d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_year = 0x7f0a046e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_dialog_uc_year_suffix = 0x7f0a046f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_sc = 0x7f0a0470;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_title = 0x7f0a0471;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_root = 0x7f0a0472;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_app_icon = 0x7f0a0473;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_close_iv = 0x7f0a0474;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_content_layout = 0x7f0a0475;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_contnet_link = 0x7f0a0476;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_contnet_open = 0x7f0a0477;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_contnet_tv1 = 0x7f0a0478;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_contnet_tv2 = 0x7f0a0479;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_top_app_name_tv = 0x7f0a047a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_top_layout = 0x7f0a047b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_openad_top_notice_tv = 0x7f0a047c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_rel_closepage = 0x7f0a047d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_rel_player = 0x7f0a047e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_surfaceview_player = 0x7f0a047f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_view_countdowm = 0x7f0a0480;

        /* JADX INFO: Added by JADX */
        public static final int yodo1mas_reportad_cancel = 0x7f0a0481;

        /* JADX INFO: Added by JADX */
        public static final int yodo1mas_reportad_submit = 0x7f0a0482;

        /* JADX INFO: Added by JADX */
        public static final int zoom = 0x7f0a0483;
    }

    /* JADX INFO: Added by JADX */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityDefaultDur = 0x7f0b0000;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityShortDur = 0x7f0b0001;

        /* JADX INFO: Added by JADX */
        public static final int bm_bottom_sheet_slide_duration = 0x7f0b0002;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button_image_alpha = 0x7f0b0003;

        /* JADX INFO: Added by JADX */
        public static final int config_tooltipAnimTime = 0x7f0b0004;

        /* JADX INFO: Added by JADX */
        public static final int exo_media_button_opacity_percentage_disabled = 0x7f0b0005;

        /* JADX INFO: Added by JADX */
        public static final int exo_media_button_opacity_percentage_enabled = 0x7f0b0006;

        /* JADX INFO: Added by JADX */
        public static final int google_play_services_version = 0x7f0b0007;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_button_size_dp = 0x7f0b0008;

        /* JADX INFO: Added by JADX */
        public static final int ia_ib_toolbar_height_dp = 0x7f0b0009;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 0x7f0b000a;
    }

    /* JADX INFO: Added by JADX */
    public static final class interpolator {

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 0x7f0c0000;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 0x7f0c0001;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 0x7f0c0002;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 0x7f0c0003;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 0x7f0c0004;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 0x7f0c0005;

        /* JADX INFO: Added by JADX */
        public static final int fast_out_slow_in = 0x7f0c0006;
    }

    /* JADX INFO: Added by JADX */
    public static final class layout {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_title_item = 0x7f0d0000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_container = 0x7f0d0001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_item_layout = 0x7f0d0002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_layout = 0x7f0d0003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_bar = 0x7f0d0004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_close_item_material = 0x7f0d0005;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view = 0x7f0d0006;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_list_item = 0x7f0d0007;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 0x7f0d0008;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_material = 0x7f0d0009;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_title_material = 0x7f0d000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menu_item_layout = 0x7f0d000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_material = 0x7f0d000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_expanded_menu_layout = 0x7f0d000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_checkbox = 0x7f0d000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_icon = 0x7f0d000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_layout = 0x7f0d0010;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_radio = 0x7f0d0011;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_header_item_layout = 0x7f0d0012;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_item_layout = 0x7f0d0013;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_content_include = 0x7f0d0014;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple = 0x7f0d0015;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 0x7f0d0016;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_toolbar = 0x7f0d0017;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 0x7f0d0018;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view = 0x7f0d0019;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_material = 0x7f0d001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip = 0x7f0d001b;

        /* JADX INFO: Added by JADX */
        public static final int activity_dashboard = 0x7f0d001c;

        /* JADX INFO: Added by JADX */
        public static final int ad_format_header = 0x7f0d001d;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_native_banner_template_basic_layout = 0x7f0d001e;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_native_banner_template_icon_text_layout = 0x7f0d001f;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_native_banner_template_rect_layout = 0x7f0d0020;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_native_banner_template_text_cta_layout = 0x7f0d0021;

        /* JADX INFO: Added by JADX */
        public static final int ad_network_item = 0x7f0d0022;

        /* JADX INFO: Added by JADX */
        public static final int ad_unit_ids_item = 0x7f0d0023;

        /* JADX INFO: Added by JADX */
        public static final int admob_empty_layout = 0x7f0d0024;

        /* JADX INFO: Added by JADX */
        public static final int applovin_debugger_list_item_detail = 0x7f0d0025;

        /* JADX INFO: Added by JADX */
        public static final int applovin_native_ad_media_view = 0x7f0d0026;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_form = 0x7f0d0027;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial = 0x7f0d0028;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_banner = 0x7f0d0029;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_bottom_card = 0x7f0d002a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_landingpage = 0x7f0d002b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_landingpage_7_8 = 0x7f0d002c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_end_all_wrap_item = 0x7f0d002d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_end_half_wrap_item = 0x7f0d002e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_end_img_item = 0x7f0d002f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_mix_end = 0x7f0d0030;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_owner_native = 0x7f0d0031;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_multi_single_end = 0x7f0d0032;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_native_center = 0x7f0d0033;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_native_top = 0x7f0d0034;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_percent_warning = 0x7f0d0035;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_percent_warning_landscape = 0x7f0d0036;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_play_page = 0x7f0d0037;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video = 0x7f0d0038;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_19_29 = 0x7f0d0039;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_2 = 0x7f0d003a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_3 = 0x7f0d003b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_4 = 0x7f0d003c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_5 = 0x7f0d003d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_19 = 0x7f0d003e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_20 = 0x7f0d003f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_21 = 0x7f0d0040;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_22 = 0x7f0d0041;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_23 = 0x7f0d0042;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_24 = 0x7f0d0043;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_25 = 0x7f0d0044;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_component_26 = 0x7f0d0045;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_10 = 0x7f0d0046;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_11 = 0x7f0d0047;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_12 = 0x7f0d0048;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_6 = 0x7f0d0049;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_7 = 0x7f0d004a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_8 = 0x7f0d004b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_download_9 = 0x7f0d004c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_empty_end = 0x7f0d004d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end = 0x7f0d004e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_14_15 = 0x7f0d004f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_16_17 = 0x7f0d0050;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_18 = 0x7f0d0051;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_19 = 0x7f0d0052;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_2 = 0x7f0d0053;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_3 = 0x7f0d0054;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_4 = 0x7f0d0055;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_6 = 0x7f0d0056;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_7 = 0x7f0d0057;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_8 = 0x7f0d0058;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_9 = 0x7f0d0059;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_landscape = 0x7f0d005a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_end_landscape_2 = 0x7f0d005b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_land_material_31_32 = 0x7f0d005c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_left_material_31 = 0x7f0d005d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_13 = 0x7f0d005e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_14 = 0x7f0d005f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_15 = 0x7f0d0060;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_16 = 0x7f0d0061;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_17 = 0x7f0d0062;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_item_layout = 0x7f0d0063;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_multi_img_media_layout = 0x7f0d0064;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_rich_video_right_material_32 = 0x7f0d0065;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_sab = 0x7f0d0066;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_1 = 0x7f0d0067;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_1_full_media = 0x7f0d0068;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_2 = 0x7f0d0069;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_2_full_media = 0x7f0d006a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_3 = 0x7f0d006b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_3_no_gp_element = 0x7f0d006c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_4 = 0x7f0d006d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_style_landscape_4_full_media = 0x7f0d006e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_interstitial_vpaid = 0x7f0d006f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_1 = 0x7f0d0070;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_2 = 0x7f0d0071;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_3 = 0x7f0d0072;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_4 = 0x7f0d0073;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_5 = 0x7f0d0074;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_pop_up_style_6 = 0x7f0d0075;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_popup = 0x7f0d0076;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_popup_banner = 0x7f0d0077;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_popup_vpaid = 0x7f0d0078;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_reward = 0x7f0d0079;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_sub_interstitial_rich_video_1_3 = 0x7f0d007a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_vertical_twins_owner = 0x7f0d007b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_vertical_twins_sub = 0x7f0d007c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_activity_webview = 0x7f0d007d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_banner_placeholder_img = 0x7f0d007e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_default_loading_layout = 0x7f0d007f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_dialog_reward_retain = 0x7f0d0080;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_download_msg = 0x7f0d0081;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_download_msg_white = 0x7f0d0082;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_endpage_cta_click_guide = 0x7f0d0083;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_content = 0x7f0d0084;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_content_dark = 0x7f0d0085;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_fill_question = 0x7f0d0086;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_fill_question_dark = 0x7f0d0087;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_layout = 0x7f0d0088;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_layout_dark = 0x7f0d0089;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_notice_privacy = 0x7f0d008a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_notice_privacy_dark = 0x7f0d008b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_question = 0x7f0d008c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_question_dark = 0x7f0d008d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_select_question = 0x7f0d008e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_select_question_dark = 0x7f0d008f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_item_inter_countdown_bg = 0x7f0d0090;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_item_inter_default_countdown_bg = 0x7f0d0091;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_item_interaction_horizontal = 0x7f0d0092;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_item_interaction_vertical = 0x7f0d0093;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_item_splash_countdown_bg = 0x7f0d0094;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_label_layout = 0x7f0d0095;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_gesture_slide = 0x7f0d0096;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_gesture_zoom = 0x7f0d0097;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_ic_item = 0x7f0d0098;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_ad_mark_top_left = 0x7f0d0099;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_ad_warning_bottom = 0x7f0d009a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_item_cta_des_style1 = 0x7f0d009b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_item_cta_des_style2 = 0x7f0d009c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_item_cta_style1 = 0x7f0d009d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_item_cta_style2 = 0x7f0d009e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_item_style = 0x7f0d009f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_icon_view_flow = 0x7f0d00a0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_loading_view = 0x7f0d00a1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_loading_view_landscape = 0x7f0d00a2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_native_fallback_view_download_info_landscape = 0x7f0d00a3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_native_fallback_view_landscape = 0x7f0d00a4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_native_view = 0x7f0d00a5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_mid_page_native_view_landscape = 0x7f0d00a6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_interstitial_rich_video_multi_img_bottom = 0x7f0d00a7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_more = 0x7f0d00a8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_space = 0x7f0d00a9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_space_black = 0x7f0d00aa;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_word_icon = 0x7f0d00ab;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_layout_word_icon_first_page = 0x7f0d00ac;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_native_banner_medium = 0x7f0d00ad;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_native_banner_small = 0x7f0d00ae;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_one2n_activity_interstitial = 0x7f0d00af;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_optionview_feedback = 0x7f0d00b0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_pop_up_ad_msg = 0x7f0d00b1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_popup_close_btn = 0x7f0d00b2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_ad_label = 0x7f0d00b3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage1 = 0x7f0d00b4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage1_slide = 0x7f0d00b5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_item_click_guide = 0x7f0d00b6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_item_cta = 0x7f0d00b7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_item_flash = 0x7f0d00b8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_endpage_item_slide = 0x7f0d00b9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_arrow = 0x7f0d00ba;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_click_guide = 0x7f0d00bb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_cta = 0x7f0d00bc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_cta_bg = 0x7f0d00bd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_flash = 0x7f0d00be;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_ripple = 0x7f0d00bf;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_item_slide = 0x7f0d00c0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_3_item_cta = 0x7f0d00c1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_3_multi_img = 0x7f0d00c2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_4_cta_widget = 0x7f0d00c3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_5_card_widget = 0x7f0d00c4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_fullscreen = 0x7f0d00c5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_fullscreen_immersive = 0x7f0d00c6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_fullscreen_interaction = 0x7f0d00c7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_fullscreen_interaction_immersive = 0x7f0d00c8;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_fullscreen_vpaid = 0x7f0d00c9;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_halfscreen = 0x7f0d00ca;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_halfscreen_interaction = 0x7f0d00cb;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_halfscreen_vpaid = 0x7f0d00cc;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_style_root = 0x7f0d00cd;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_success_submit = 0x7f0d00ce;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_success_submit_dark = 0x7f0d00cf;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide = 0x7f0d00d0;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_1 = 0x7f0d00d1;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_2 = 0x7f0d00d2;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_3 = 0x7f0d00d3;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_landscape_1 = 0x7f0d00d4;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_landscape_2 = 0x7f0d00d5;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_click_guide_landscape_3 = 0x7f0d00d6;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_view_slide_gesture = 0x7f0d00d7;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_webview_loading = 0x7f0d00d8;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_legacy_player_control_view = 0x7f0d00d9;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_list_divider = 0x7f0d00da;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_player_control_ffwd_button = 0x7f0d00db;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_player_control_rewind_button = 0x7f0d00dc;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_player_control_view = 0x7f0d00dd;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_player_view = 0x7f0d00de;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_styled_settings_list = 0x7f0d00df;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_styled_settings_list_item = 0x7f0d00e0;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_styled_sub_settings_list_item = 0x7f0d00e1;

        /* JADX INFO: Added by JADX */
        public static final int bm_exo_track_selection_dialog = 0x7f0d00e2;

        /* JADX INFO: Added by JADX */
        public static final int bm_privacy_sheet = 0x7f0d00e3;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_page = 0x7f0d00e4;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_row = 0x7f0d00e5;

        /* JADX INFO: Added by JADX */
        public static final int creative_debugger_displayed_ad_detail_activity = 0x7f0d00e6;

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 0x7f0d00e7;

        /* JADX INFO: Added by JADX */
        public static final int dt_store_promo_layout = 0x7f0d00e8;

        /* JADX INFO: Added by JADX */
        public static final int exo_list_divider = 0x7f0d00e9;

        /* JADX INFO: Added by JADX */
        public static final int exo_player_control_ffwd_button = 0x7f0d00ea;

        /* JADX INFO: Added by JADX */
        public static final int exo_player_control_rewind_button = 0x7f0d00eb;

        /* JADX INFO: Added by JADX */
        public static final int exo_player_control_view = 0x7f0d00ec;

        /* JADX INFO: Added by JADX */
        public static final int exo_player_view = 0x7f0d00ed;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_player_control_ffwd_button = 0x7f0d00ee;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_player_control_rewind_button = 0x7f0d00ef;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_player_control_view = 0x7f0d00f0;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_player_view = 0x7f0d00f1;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_settings_list = 0x7f0d00f2;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_settings_list_item = 0x7f0d00f3;

        /* JADX INFO: Added by JADX */
        public static final int exo_styled_sub_settings_list_item = 0x7f0d00f4;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_dialog = 0x7f0d00f5;

        /* JADX INFO: Added by JADX */
        public static final int expand_button = 0x7f0d00f6;

        /* JADX INFO: Added by JADX */
        public static final int ia_endcard_container = 0x7f0d00f7;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_activity_internal_store_webpage = 0x7f0d00f8;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_buffering_overlay = 0x7f0d00f9;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_click_overlay = 0x7f0d00fa;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_default_video_end_card = 0x7f0d00fb;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_fullscreen_activity = 0x7f0d00fc;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_fyber_ad_identifier = 0x7f0d00fd;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_fyber_ad_identifier_relative = 0x7f0d00fe;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_rich_media_video = 0x7f0d00ff;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_skip_rewarded_dialog = 0x7f0d0100;

        /* JADX INFO: Added by JADX */
        public static final int ia_layout_video_view = 0x7f0d0101;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_view_remote_ui = 0x7f0d0102;

        /* JADX INFO: Added by JADX */
        public static final int image_frame = 0x7f0d0103;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 0x7f0d0104;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 0x7f0d0105;

        /* JADX INFO: Added by JADX */
        public static final int label_value_item = 0x7f0d0106;

        /* JADX INFO: Added by JADX */
        public static final int loading_alert = 0x7f0d0107;

        /* JADX INFO: Added by JADX */
        public static final int mainlayout = 0x7f0d0108;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_banner_icon_and_text_layout = 0x7f0d0109;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_banner_view = 0x7f0d010a;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_leader_view = 0x7f0d010b;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_media_banner_view = 0x7f0d010c;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_mrec_view = 0x7f0d010d;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_recycler_view_item = 0x7f0d010e;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_template_1 = 0x7f0d010f;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_vertical_banner_view = 0x7f0d0110;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_vertical_leader_view = 0x7f0d0111;

        /* JADX INFO: Added by JADX */
        public static final int max_native_ad_vertical_media_banner_view = 0x7f0d0112;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_activity = 0x7f0d0113;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_alertview_layout = 0x7f0d0114;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_bt_container = 0x7f0d0115;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_alertview = 0x7f0d0116;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_notice_layout = 0x7f0d0117;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedbackview = 0x7f0d0118;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_loading_layout = 0x7f0d0119;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_interstitial_activity = 0x7f0d011a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_more_offer_activity = 0x7f0d011b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_fullbasescreen = 0x7f0d011c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_fullscreen_top = 0x7f0d011d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_mbmediaview = 0x7f0d011e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_nativex_playerview = 0x7f0d011f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_layout_item = 0x7f0d0120;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_layout_list_landscape = 0x7f0d0121;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_order_layout_list_portrait = 0x7f0d0122;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_playercommon_player_view = 0x7f0d0123;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_activity_video_templete = 0x7f0d0124;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_activity_video_templete_transparent = 0x7f0d0125;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_clickable_cta = 0x7f0d0126;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_layout_landscape = 0x7f0d0127;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_layout_landscape_1302 = 0x7f0d0128;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_layout_portrait = 0x7f0d0129;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_layout_portrait_1302 = 0x7f0d012a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_end_card_more_offer_item = 0x7f0d012b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_h5 = 0x7f0d012c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_native_half_landscape = 0x7f0d012d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_native_half_portrait = 0x7f0d012e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_native_hor = 0x7f0d012f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_native_land = 0x7f0d0130;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_vast = 0x7f0d0131;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor = 0x7f0d0132;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_302 = 0x7f0d0133;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_5002010 = 0x7f0d0134;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_802 = 0x7f0d0135;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_902 = 0x7f0d0136;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_904 = 0x7f0d0137;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_bottom = 0x7f0d0138;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_layer_floor_half_portrait = 0x7f0d0139;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_more_offer_view = 0x7f0d013a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_videoend_cover = 0x7f0d013b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_videoview_item = 0x7f0d013c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_view_tag_item = 0x7f0d013d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_same_choice_one_layout_landscape = 0x7f0d013e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_same_choice_one_layout_portrait = 0x7f0d013f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_landscape = 0x7f0d0140;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_portrait = 0x7f0d0141;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_ad_unit_detail_activity = 0x7f0d0142;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_list_item_right_detail = 0x7f0d0143;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_list_section = 0x7f0d0144;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_list_section_centered = 0x7f0d0145;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_list_view = 0x7f0d0146;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_multi_ad_activity = 0x7f0d0147;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_text_view_activity = 0x7f0d0148;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 0x7f0d0149;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 0x7f0d014a;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_action = 0x7f0d014b;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_cancel_action = 0x7f0d014c;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_big_media = 0x7f0d014d;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_big_media_custom = 0x7f0d014e;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_big_media_narrow = 0x7f0d014f;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_big_media_narrow_custom = 0x7f0d0150;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 0x7f0d0151;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 0x7f0d0152;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_lines_media = 0x7f0d0153;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_media = 0x7f0d0154;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_media_custom = 0x7f0d0155;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 0x7f0d0156;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 0x7f0d0157;

        /* JADX INFO: Added by JADX */
        public static final int offline_ads_dialog = 0x7f0d0158;

        /* JADX INFO: Added by JADX */
        public static final int preference = 0x7f0d0159;

        /* JADX INFO: Added by JADX */
        public static final int preference_category = 0x7f0d015a;

        /* JADX INFO: Added by JADX */
        public static final int preference_category_material = 0x7f0d015b;

        /* JADX INFO: Added by JADX */
        public static final int preference_dialog_edittext = 0x7f0d015c;

        /* JADX INFO: Added by JADX */
        public static final int preference_dropdown = 0x7f0d015d;

        /* JADX INFO: Added by JADX */
        public static final int preference_dropdown_material = 0x7f0d015e;

        /* JADX INFO: Added by JADX */
        public static final int preference_information = 0x7f0d015f;

        /* JADX INFO: Added by JADX */
        public static final int preference_information_material = 0x7f0d0160;

        /* JADX INFO: Added by JADX */
        public static final int preference_list_fragment = 0x7f0d0161;

        /* JADX INFO: Added by JADX */
        public static final int preference_material = 0x7f0d0162;

        /* JADX INFO: Added by JADX */
        public static final int preference_recyclerview = 0x7f0d0163;

        /* JADX INFO: Added by JADX */
        public static final int preference_widget_checkbox = 0x7f0d0164;

        /* JADX INFO: Added by JADX */
        public static final int preference_widget_seekbar = 0x7f0d0165;

        /* JADX INFO: Added by JADX */
        public static final int preference_widget_seekbar_material = 0x7f0d0166;

        /* JADX INFO: Added by JADX */
        public static final int preference_widget_switch = 0x7f0d0167;

        /* JADX INFO: Added by JADX */
        public static final int preference_widget_switch_compat = 0x7f0d0168;

        /* JADX INFO: Added by JADX */
        public static final int section_item = 0x7f0d0169;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_item_material = 0x7f0d016a;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_multichoice_material = 0x7f0d016b;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_singlechoice_material = 0x7f0d016c;

        /* JADX INFO: Added by JADX */
        public static final int separator = 0x7f0d016d;

        /* JADX INFO: Added by JADX */
        public static final int support_simple_spinner_dropdown_item = 0x7f0d016e;

        /* JADX INFO: Added by JADX */
        public static final int switch_item = 0x7f0d016f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_app_openad_view_land = 0x7f0d0170;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_app_openad_view_port = 0x7f0d0171;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_banner_view = 0x7f0d0172;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_inter_view = 0x7f0d0173;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_activity = 0x7f0d0174;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_activity = 0x7f0d0175;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_header = 0x7f0d0176;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_activity = 0x7f0d0177;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_activity = 0x7f0d0178;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_header = 0x7f0d0179;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_detail_item = 0x7f0d017a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_integration_item = 0x7f0d017b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_item = 0x7f0d017c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_games_dialog_usercontent = 0x7f0d017d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_medium_template_view = 0x7f0d017e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_gnt_small_template_view = 0x7f0d017f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_layout_item_native = 0x7f0d0180;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_dialog = 0x7f0d0181;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_vp_activity = 0x7f0d0182;
    }

    /* JADX INFO: Added by JADX */
    public static final class menu {

        /* JADX INFO: Added by JADX */
        public static final int creative_debugger_displayed_ad_activity_menu = 0x7f0e0000;

        /* JADX INFO: Added by JADX */
        public static final int mediation_debugger_activity_menu = 0x7f0e0001;

        /* JADX INFO: Added by JADX */
        public static final int reportad_adissue_menu = 0x7f0e0002;

        /* JADX INFO: Added by JADX */
        public static final int reportad_adtype_menu = 0x7f0e0003;
    }

    public static final class mipmap {
        public static int app_icon = 0x7f0f0000;
        public static int app_icon_round = 0x7f0f0001;

        private mipmap() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class plurals {

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fastforward_by_amount_description = 0x7f100000;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_rewind_by_amount_description = 0x7f100001;
    }

    /* JADX INFO: Added by JADX */
    public static final class raw {

        /* JADX INFO: Added by JADX */
        public static final int applovin_consent_flow_unified_cmp = 0x7f110000;

        /* JADX INFO: Added by JADX */
        public static final int com_android_billingclient_heterodyne_info = 0x7f110001;

        /* JADX INFO: Added by JADX */
        public static final int com_android_billingclient_registration_info = 0x7f110002;

        /* JADX INFO: Added by JADX */
        public static final int inmobi_omid_js = 0x7f110003;

        /* JADX INFO: Added by JADX */
        public static final int keep_cronet_api = 0x7f110004;

        /* JADX INFO: Added by JADX */
        public static final int omid_session_client_v1_5_7 = 0x7f110005;

        /* JADX INFO: Added by JADX */
        public static final int omsdk_v1_5_3 = 0x7f110006;

        /* JADX INFO: Added by JADX */
        public static final int omsdk_v1_5_7 = 0x7f110007;
    }

    public static final class string {
        public static int app_name = 0x7f120053;

        /* JADX INFO: Added by JADX */
        public static final int CronetProviderClassName = 0x7f120000;

        /* JADX INFO: Added by JADX */
        public static final int FreeformWindowOrientation_landscape = 0x7f120001;

        /* JADX INFO: Added by JADX */
        public static final int FreeformWindowOrientation_portrait = 0x7f120002;

        /* JADX INFO: Added by JADX */
        public static final int FreeformWindowSize_maximize = 0x7f120003;

        /* JADX INFO: Added by JADX */
        public static final int FreeformWindowSize_phone = 0x7f120004;

        /* JADX INFO: Added by JADX */
        public static final int FreeformWindowSize_tablet = 0x7f120005;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_home_description = 0x7f120006;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_description = 0x7f120007;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_overflow_description = 0x7f120008;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_done = 0x7f120009;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_see_all = 0x7f12000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_activitychooserview_choose_application = 0x7f12000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_off = 0x7f12000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_on = 0x7f12000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_alt_shortcut_label = 0x7f12000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 0x7f12000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_delete_shortcut_label = 0x7f120010;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_enter_shortcut_label = 0x7f120011;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_function_shortcut_label = 0x7f120012;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_meta_shortcut_label = 0x7f120013;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_shift_shortcut_label = 0x7f120014;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_space_shortcut_label = 0x7f120015;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_sym_shortcut_label = 0x7f120016;

        /* JADX INFO: Added by JADX */
        public static final int abc_prepend_shortcut_label = 0x7f120017;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_hint = 0x7f120018;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_clear = 0x7f120019;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_query = 0x7f12001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_search = 0x7f12001b;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_submit = 0x7f12001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_voice = 0x7f12001d;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with = 0x7f12001e;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 0x7f12001f;

        /* JADX INFO: Added by JADX */
        public static final int abc_toolbar_collapse_description = 0x7f120020;

        /* JADX INFO: Added by JADX */
        public static final int ad_mob_ad_badge = 0x7f120021;

        /* JADX INFO: Added by JADX */
        public static final int ah_ad_networks = 0x7f120022;

        /* JADX INFO: Added by JADX */
        public static final int ah_ad_unit_ids = 0x7f120023;

        /* JADX INFO: Added by JADX */
        public static final int ah_ad_unit_no_data = 0x7f120024;

        /* JADX INFO: Added by JADX */
        public static final int ah_app_info = 0x7f120025;

        /* JADX INFO: Added by JADX */
        public static final int ah_app_version = 0x7f120026;

        /* JADX INFO: Added by JADX */
        public static final int ah_appharbr_info = 0x7f120027;

        /* JADX INFO: Added by JADX */
        public static final int ah_block_all = 0x7f120028;

        /* JADX INFO: Added by JADX */
        public static final int ah_block_all_desc = 0x7f120029;

        /* JADX INFO: Added by JADX */
        public static final int ah_blocklist_version = 0x7f12002a;

        /* JADX INFO: Added by JADX */
        public static final int ah_bundle_id = 0x7f12002b;

        /* JADX INFO: Added by JADX */
        public static final int ah_complete = 0x7f12002c;

        /* JADX INFO: Added by JADX */
        public static final int ah_config_version = 0x7f12002d;

        /* JADX INFO: Added by JADX */
        public static final int ah_dashboard_tli = 0x7f12002e;

        /* JADX INFO: Added by JADX */
        public static final int ah_dashboard_tli_desc = 0x7f12002f;

        /* JADX INFO: Added by JADX */
        public static final int ah_dashboard_tlr = 0x7f120030;

        /* JADX INFO: Added by JADX */
        public static final int ah_dashboard_tlr_desc = 0x7f120031;

        /* JADX INFO: Added by JADX */
        public static final int ah_debug_enabled = 0x7f120032;

        /* JADX INFO: Added by JADX */
        public static final int ah_disabled = 0x7f120033;

        /* JADX INFO: Added by JADX */
        public static final int ah_done = 0x7f120034;

        /* JADX INFO: Added by JADX */
        public static final int ah_enabled = 0x7f120035;

        /* JADX INFO: Added by JADX */
        public static final int ah_failure = 0x7f120036;

        /* JADX INFO: Added by JADX */
        public static final int ah_features_test = 0x7f120037;

        /* JADX INFO: Added by JADX */
        public static final int ah_features_test_disclaimer = 0x7f120038;

        /* JADX INFO: Added by JADX */
        public static final int ah_general_info = 0x7f120039;

        /* JADX INFO: Added by JADX */
        public static final int ah_impression_recorded = 0x7f12003a;

        /* JADX INFO: Added by JADX */
        public static final int ah_initialization_state = 0x7f12003b;

        /* JADX INFO: Added by JADX */
        public static final int ah_integrated = 0x7f12003c;

        /* JADX INFO: Added by JADX */
        public static final int ah_integration_dashboard = 0x7f12003d;

        /* JADX INFO: Added by JADX */
        public static final int ah_integration_status = 0x7f12003e;

        /* JADX INFO: Added by JADX */
        public static final int ah_interstitial_time_limit = 0x7f12003f;

        /* JADX INFO: Added by JADX */
        public static final int ah_interstitial_time_limit_arg = 0x7f120040;

        /* JADX INFO: Added by JADX */
        public static final int ah_mediations = 0x7f120041;

        /* JADX INFO: Added by JADX */
        public static final int ah_mute_auto_play_sound = 0x7f120042;

        /* JADX INFO: Added by JADX */
        public static final int ah_report_all = 0x7f120043;

        /* JADX INFO: Added by JADX */
        public static final int ah_report_all_desc = 0x7f120044;

        /* JADX INFO: Added by JADX */
        public static final int ah_rewarded_time_limit = 0x7f120045;

        /* JADX INFO: Added by JADX */
        public static final int ah_rewarded_time_limit_arg = 0x7f120046;

        /* JADX INFO: Added by JADX */
        public static final int ah_sdk_initialization_status = 0x7f120047;

        /* JADX INFO: Added by JADX */
        public static final int ah_sdk_version = 0x7f120048;

        /* JADX INFO: Added by JADX */
        public static final int ah_sdk_version_arg = 0x7f120049;

        /* JADX INFO: Added by JADX */
        public static final int ah_status_arg = 0x7f12004a;

        /* JADX INFO: Added by JADX */
        public static final int ah_successful = 0x7f12004b;

        /* JADX INFO: Added by JADX */
        public static final int ah_supported_sdk_versions_arg = 0x7f12004c;

        /* JADX INFO: Added by JADX */
        public static final int ah_time_limit_status = 0x7f12004d;

        /* JADX INFO: Added by JADX */
        public static final int ah_version_mismatch = 0x7f12004e;

        /* JADX INFO: Added by JADX */
        public static final int ah_waiting_for_ad_load = 0x7f12004f;

        /* JADX INFO: Added by JADX */
        public static final int ah_waiting_for_an_impression = 0x7f120050;

        /* JADX INFO: Added by JADX */
        public static final int ah_waiting_for_display = 0x7f120051;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f120052;

        /* JADX INFO: Added by JADX */
        public static final int applovin_agree_message = 0x7f120054;

        /* JADX INFO: Added by JADX */
        public static final int applovin_alt_privacy_policy_text = 0x7f120055;

        /* JADX INFO: Added by JADX */
        public static final int applovin_continue_button_text = 0x7f120056;

        /* JADX INFO: Added by JADX */
        public static final int applovin_creative_debugger_disabled_text = 0x7f120057;

        /* JADX INFO: Added by JADX */
        public static final int applovin_creative_debugger_no_ads_text = 0x7f120058;

        /* JADX INFO: Added by JADX */
        public static final int applovin_list_item_image_description = 0x7f120059;

        /* JADX INFO: Added by JADX */
        public static final int applovin_pp_and_tos_title = 0x7f12005a;

        /* JADX INFO: Added by JADX */
        public static final int applovin_pp_title = 0x7f12005b;

        /* JADX INFO: Added by JADX */
        public static final int applovin_privacy_policy_text = 0x7f12005c;

        /* JADX INFO: Added by JADX */
        public static final int applovin_terms_of_service_text = 0x7f12005d;

        /* JADX INFO: Added by JADX */
        public static final int applovin_terms_of_use_text = 0x7f12005e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_about_app_default = 0x7f12005f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_click_to_try = 0x7f120060;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_comment_num_text = 0x7f120061;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_cta_default = 0x7f120062;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_cta_download_default = 0x7f120063;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_description_default = 0x7f120064;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_double_video_choose_video = 0x7f120065;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_double_video_count_down = 0x7f120066;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_download_num_text = 0x7f120067;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_copied = 0x7f120068;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_copy_ad_id = 0x7f120069;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_copy_link = 0x7f12006a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_hide_ads = 0x7f12006b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_link_copied = 0x7f12006c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_rec_rule = 0x7f12006d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_report_ads = 0x7f12006e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_user_privacy = 0x7f12006f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_feedback_why_this_ad = 0x7f120070;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_agree = 0x7f120071;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_cancel = 0x7f120072;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_privacy_content = 0x7f120073;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_privacy_notice = 0x7f120074;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_question_hint = 0x7f120075;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_submit = 0x7f120076;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_form_warning = 0x7f120077;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_application = 0x7f120078;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_blank = 0x7f120079;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_everyone = 0x7f12007a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_recommended = 0x7f12007b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_ic_web = 0x7f12007c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_jump_hint = 0x7f12007d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_shake = 0x7f12007e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_slide = 0x7f12007f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_interaction_twist = 0x7f120080;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_link_copied = 0x7f120081;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_lose_reward = 0x7f120082;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_multi_img_more_text = 0x7f120083;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_resume = 0x7f120084;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_skip = 0x7f120085;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_skip_video = 0x7f120086;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_skip = 0x7f120087;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_splash_skip_after = 0x7f120088;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag = 0x7f120089;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_back = 0x7f12008a;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_close = 0x7f12008b;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_forward = 0x7f12008c;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_progressbar = 0x7f12008d;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_tag_title = 0x7f12008e;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_title_default = 0x7f12008f;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_webview_loading = 0x7f120090;

        /* JADX INFO: Added by JADX */
        public static final int bigo_ad_word_icon_guid = 0x7f120091;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 0x7f120092;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 0x7f120093;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 0x7f120094;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 0x7f120095;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 0x7f120096;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 0x7f120097;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 0x7f120098;

        /* JADX INFO: Added by JADX */
        public static final int campaign_appName = 0x7f120099;

        /* JADX INFO: Added by JADX */
        public static final int campaign_iconUrl = 0x7f12009a;

        /* JADX INFO: Added by JADX */
        public static final int campaign_imageUrl = 0x7f12009b;

        /* JADX INFO: Added by JADX */
        public static final int close_drawer = 0x7f12009c;

        /* JADX INFO: Added by JADX */
        public static final int close_sheet = 0x7f12009d;

        /* JADX INFO: Added by JADX */
        public static final int com_moloco_sdk_xenoss_player_learn_more = 0x7f12009e;

        /* JADX INFO: Added by JADX */
        public static final int com_moloco_sdk_xenoss_player_skip = 0x7f12009f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_button = 0x7f1200a0;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_text = 0x7f1200a1;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_title = 0x7f1200a2;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_button = 0x7f1200a3;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_text = 0x7f1200a4;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_title = 0x7f1200a5;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_channel_name = 0x7f1200a6;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_ticker = 0x7f1200a7;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unknown_issue = 0x7f1200a8;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unsupported_text = 0x7f1200a9;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_button = 0x7f1200aa;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_text = 0x7f1200ab;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_title = 0x7f1200ac;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_updating_text = 0x7f1200ad;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_wear_update_text = 0x7f1200ae;

        /* JADX INFO: Added by JADX */
        public static final int common_open_on_phone = 0x7f1200af;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text = 0x7f1200b0;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text_long = 0x7f1200b1;

        /* JADX INFO: Added by JADX */
        public static final int copy = 0x7f1200b2;

        /* JADX INFO: Added by JADX */
        public static final int copy_toast_msg = 0x7f1200b3;

        /* JADX INFO: Added by JADX */
        public static final int default_error_message = 0x7f1200b4;

        /* JADX INFO: Added by JADX */
        public static final int default_popup_window_title = 0x7f1200b5;

        /* JADX INFO: Added by JADX */
        public static final int defaults = 0x7f1200b6;

        /* JADX INFO: Added by JADX */
        public static final int dropdown_menu = 0x7f1200b7;

        /* JADX INFO: Added by JADX */
        public static final int dyAction_getClick = 0x7f1200b8;

        /* JADX INFO: Added by JADX */
        public static final int dyAction_getLogicClick = 0x7f1200b9;

        /* JADX INFO: Added by JADX */
        public static final int dyAction_getLongClick = 0x7f1200ba;

        /* JADX INFO: Added by JADX */
        public static final int dyAction_getMove = 0x7f1200bb;

        /* JADX INFO: Added by JADX */
        public static final int dyAction_getWobble = 0x7f1200bc;

        /* JADX INFO: Added by JADX */
        public static final int dyEffect_getCountDown = 0x7f1200bd;

        /* JADX INFO: Added by JADX */
        public static final int dyEffect_getVisible = 0x7f1200be;

        /* JADX INFO: Added by JADX */
        public static final int dyEffect_getVisibleParam = 0x7f1200bf;

        /* JADX INFO: Added by JADX */
        public static final int dyEffect_getWobble = 0x7f1200c0;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_feedback = 0x7f1200c1;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_getActivity = 0x7f1200c2;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_getClose = 0x7f1200c3;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_getDeeplink = 0x7f1200c4;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_getDownload = 0x7f1200c5;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_notice = 0x7f1200c6;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_permissionInfo = 0x7f1200c7;

        /* JADX INFO: Added by JADX */
        public static final int dyStrategy_privateAddress = 0x7f1200c8;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_cc_disabled_description = 0x7f1200c9;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_cc_enabled_description = 0x7f1200ca;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_custom_playback_speed = 0x7f1200cb;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fastforward_description = 0x7f1200cc;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fullscreen_enter_description = 0x7f1200cd;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_fullscreen_exit_description = 0x7f1200ce;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_hide = 0x7f1200cf;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_next_description = 0x7f1200d0;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_overflow_hide_description = 0x7f1200d1;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_overflow_show_description = 0x7f1200d2;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_pause_description = 0x7f1200d3;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_play_description = 0x7f1200d4;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_playback_speed = 0x7f1200d5;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_previous_description = 0x7f1200d6;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_all_description = 0x7f1200d7;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_off_description = 0x7f1200d8;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_repeat_one_description = 0x7f1200d9;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_rewind_description = 0x7f1200da;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_seek_bar_description = 0x7f1200db;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_settings_description = 0x7f1200dc;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_show = 0x7f1200dd;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_shuffle_off_description = 0x7f1200de;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_shuffle_on_description = 0x7f1200df;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_stop_description = 0x7f1200e0;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_time_placeholder = 0x7f1200e1;

        /* JADX INFO: Added by JADX */
        public static final int exo_controls_vr_description = 0x7f1200e2;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_completed = 0x7f1200e3;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_description = 0x7f1200e4;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_downloading = 0x7f1200e5;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_failed = 0x7f1200e6;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_notification_channel_name = 0x7f1200e7;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_paused = 0x7f1200e8;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_paused_for_network = 0x7f1200e9;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_paused_for_wifi = 0x7f1200ea;

        /* JADX INFO: Added by JADX */
        public static final int exo_download_removing = 0x7f1200eb;

        /* JADX INFO: Added by JADX */
        public static final int exo_item_list = 0x7f1200ec;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_bitrate = 0x7f1200ed;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_mono = 0x7f1200ee;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_resolution = 0x7f1200ef;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_role_alternate = 0x7f1200f0;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_role_closed_captions = 0x7f1200f1;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_role_commentary = 0x7f1200f2;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_role_supplementary = 0x7f1200f3;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_auto = 0x7f1200f4;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_none = 0x7f1200f5;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_title_audio = 0x7f1200f6;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_title_text = 0x7f1200f7;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_selection_title_video = 0x7f1200f8;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_stereo = 0x7f1200f9;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_surround = 0x7f1200fa;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_surround_5_point_1 = 0x7f1200fb;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_surround_7_point_1 = 0x7f1200fc;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_unknown = 0x7f1200fd;

        /* JADX INFO: Added by JADX */
        public static final int exo_track_unknown_name = 0x7f1200fe;

        /* JADX INFO: Added by JADX */
        public static final int expand_button_title = 0x7f1200ff;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_copy_link = 0x7f120100;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_open_in_browser = 0x7f120101;

        /* JADX INFO: Added by JADX */
        public static final int fallback_menu_item_share_link = 0x7f120102;

        /* JADX INFO: Added by JADX */
        public static final int game_view_content_description = 0x7f120103;

        /* JADX INFO: Added by JADX */
        public static final int ia_ad_identifier = 0x7f120104;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_rewarded_dialog_close_button = 0x7f120105;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_rewarded_dialog_keep_watching = 0x7f120106;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_rewarded_dialog_sub_title = 0x7f120107;

        /* JADX INFO: Added by JADX */
        public static final int ia_skip_rewarded_dialog_title = 0x7f120108;

        /* JADX INFO: Added by JADX */
        public static final int ia_str_video_error = 0x7f120109;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_app_info_text = 0x7f12010a;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_before_skip_format = 0x7f12010b;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_install_now_text = 0x7f12010c;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_instant_install_text = 0x7f12010d;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_skip_text = 0x7f12010e;

        /* JADX INFO: Added by JADX */
        public static final int in_progress = 0x7f12010f;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f120110;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setAdClickText = 0x7f120111;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setAppInfo = 0x7f120112;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setCountDownText = 0x7f120113;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setLogoImage = 0x7f120114;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setLogoText = 0x7f120115;

        /* JADX INFO: Added by JADX */
        public static final int mSplashData_setNoticeImage = 0x7f120116;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_btn_text = 0x7f120117;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_close_close = 0x7f120118;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_close_submit = 0x7f120119;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_fraud = 0x7f12011a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_misleading = 0x7f12011b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_not_play = 0x7f12011c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_other = 0x7f12011d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_por_violence = 0x7f12011e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_content_sound_problems = 0x7f12011f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_privacy_des = 0x7f120120;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_submit_notice = 0x7f120121;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_cm_feedback_dialog_title = 0x7f120122;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_cancel = 0x7f120123;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_continue = 0x7f120124;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_download_failed = 0x7f120125;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_download_finish_to_install = 0x7f120126;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_download_interrupt = 0x7f120127;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_downloading = 0x7f120128;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_ins = 0x7f120129;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_ins_progress_des = 0x7f12012a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_network_error = 0x7f12012b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_open = 0x7f12012c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_open_progress_des = 0x7f12012d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_pause = 0x7f12012e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_prefix_download = 0x7f12012f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_prefix_pause = 0x7f120130;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_start_download = 0x7f120131;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_update_finish_to_install = 0x7f120132;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_download_notify_update_package = 0x7f120133;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_appdesc = 0x7f120134;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_apptitle = 0x7f120135;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_clickable_cta_btntext = 0x7f120136;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_dialog_close = 0x7f120137;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_dialog_content = 0x7f120138;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_dialog_continue = 0x7f120139;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_dialog_title = 0x7f12013a;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_ad = 0x7f12013b;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_endcard_vast_notice = 0x7f12013c;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_heat_count_unit = 0x7f12013d;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_install = 0x7f12013e;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_view_reward_time_complete = 0x7f12013f;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_view_reward_time_left = 0x7f120140;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_video_view_reward_time_left_skip_time = 0x7f120141;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_viewed_text_str = 0x7f120142;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_count_time_can_skip = 0x7f120143;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_count_time_can_skip_not = 0x7f120144;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_splash_count_time_can_skip_s = 0x7f120145;

        /* JADX INFO: Added by JADX */
        public static final int moloco_sponsored = 0x7f120146;

        /* JADX INFO: Added by JADX */
        public static final int native_body = 0x7f120147;

        /* JADX INFO: Added by JADX */
        public static final int native_headline = 0x7f120148;

        /* JADX INFO: Added by JADX */
        public static final int native_media_view = 0x7f120149;

        /* JADX INFO: Added by JADX */
        public static final int navigation_menu = 0x7f12014a;

        /* JADX INFO: Added by JADX */
        public static final int not_selected = 0x7f12014b;

        /* JADX INFO: Added by JADX */
        public static final int not_set = 0x7f12014c;

        /* JADX INFO: Added by JADX */
        public static final int notifications_permission_confirm = 0x7f12014d;

        /* JADX INFO: Added by JADX */
        public static final int notifications_permission_decline = 0x7f12014e;

        /* JADX INFO: Added by JADX */
        public static final int notifications_permission_title = 0x7f12014f;

        /* JADX INFO: Added by JADX */
        public static final int off = 0x7f120150;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_image_description = 0x7f120151;

        /* JADX INFO: Added by JADX */
        public static final int offline_dialog_text = 0x7f120152;

        /* JADX INFO: Added by JADX */
        public static final int offline_notification_title = 0x7f120153;

        /* JADX INFO: Added by JADX */
        public static final int offline_notification_title_with_advertiser = 0x7f120154;

        /* JADX INFO: Added by JADX */
        public static final int offline_opt_in_confirm = 0x7f120155;

        /* JADX INFO: Added by JADX */
        public static final int offline_opt_in_decline = 0x7f120156;

        /* JADX INFO: Added by JADX */
        public static final int offline_opt_in_message = 0x7f120157;

        /* JADX INFO: Added by JADX */
        public static final int offline_opt_in_title = 0x7f120158;

        /* JADX INFO: Added by JADX */
        public static final int on = 0x7f120159;

        /* JADX INFO: Added by JADX */
        public static final int play_games_sdk_version = 0x7f12015a;

        /* JADX INFO: Added by JADX */
        public static final int preference_copied = 0x7f12015b;

        /* JADX INFO: Added by JADX */
        public static final int range_end = 0x7f12015c;

        /* JADX INFO: Added by JADX */
        public static final int range_start = 0x7f12015d;

        /* JADX INFO: Added by JADX */
        public static final int s1 = 0x7f12015e;

        /* JADX INFO: Added by JADX */
        public static final int s2 = 0x7f12015f;

        /* JADX INFO: Added by JADX */
        public static final int s3 = 0x7f120160;

        /* JADX INFO: Added by JADX */
        public static final int s4 = 0x7f120161;

        /* JADX INFO: Added by JADX */
        public static final int s5 = 0x7f120162;

        /* JADX INFO: Added by JADX */
        public static final int s6 = 0x7f120163;

        /* JADX INFO: Added by JADX */
        public static final int s7 = 0x7f120164;

        /* JADX INFO: Added by JADX */
        public static final int search_menu_title = 0x7f120165;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f120166;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 0x7f120167;

        /* JADX INFO: Added by JADX */
        public static final int summary_collapsed_preference_list = 0x7f120168;

        /* JADX INFO: Added by JADX */
        public static final int tab = 0x7f120169;

        /* JADX INFO: Added by JADX */
        public static final int template_percent = 0x7f12016a;

        /* JADX INFO: Added by JADX */
        public static final int tt_00_00 = 0x7f12016b;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_close_text = 0x7f12016c;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_data_error = 0x7f12016d;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_is_closed = 0x7f12016e;

        /* JADX INFO: Added by JADX */
        public static final int tt_ad_logo_txt = 0x7f12016f;

        /* JADX INFO: Added by JADX */
        public static final int tt_add_bad_reason = 0x7f120170;

        /* JADX INFO: Added by JADX */
        public static final int tt_adslot_empty = 0x7f120171;

        /* JADX INFO: Added by JADX */
        public static final int tt_adslot_id_error = 0x7f120172;

        /* JADX INFO: Added by JADX */
        public static final int tt_adslot_size_empty = 0x7f120173;

        /* JADX INFO: Added by JADX */
        public static final int tt_app_empty = 0x7f120174;

        /* JADX INFO: Added by JADX */
        public static final int tt_bad = 0x7f120175;

        /* JADX INFO: Added by JADX */
        public static final int tt_banner_ad_load_image_error = 0x7f120176;

        /* JADX INFO: Added by JADX */
        public static final int tt_choose_language = 0x7f120177;

        /* JADX INFO: Added by JADX */
        public static final int tt_comment_num = 0x7f120178;

        /* JADX INFO: Added by JADX */
        public static final int tt_content_type = 0x7f120179;

        /* JADX INFO: Added by JADX */
        public static final int tt_count_down_view = 0x7f12017a;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_header_tv_back = 0x7f12017b;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislike_header_tv_title = 0x7f12017c;

        /* JADX INFO: Added by JADX */
        public static final int tt_display_error = 0x7f12017d;

        /* JADX INFO: Added by JADX */
        public static final int tt_done = 0x7f12017e;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_access_method_pass = 0x7f12017f;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_ad_able_false_msg = 0x7f120180;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_ad_type = 0x7f120181;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_adtype_differ = 0x7f120182;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_apk_sign_check_error = 0x7f120183;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_bidding_type = 0x7f120184;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_code_adcount_error = 0x7f120185;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_code_click_event_error = 0x7f120186;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_device_ip = 0x7f120187;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_empty_content = 0x7f120188;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_image_size = 0x7f120189;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_interstitial_version = 0x7f12018a;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_media_id = 0x7f12018b;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_media_type = 0x7f12018c;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_new_register_limit = 0x7f12018d;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_origin_ad_error = 0x7f12018e;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_package_name = 0x7f12018f;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_redirect = 0x7f120190;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_request_invalid = 0x7f120191;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_slot_id_app_id_differ = 0x7f120192;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_splash_ad_type = 0x7f120193;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_union_os_error = 0x7f120194;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_union_sdk_too_old = 0x7f120195;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_unknow = 0x7f120196;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_update_version = 0x7f120197;

        /* JADX INFO: Added by JADX */
        public static final int tt_error_verify_reward = 0x7f120198;

        /* JADX INFO: Added by JADX */
        public static final int tt_feedback_experience_text = 0x7f120199;

        /* JADX INFO: Added by JADX */
        public static final int tt_feedback_submit_text = 0x7f12019a;

        /* JADX INFO: Added by JADX */
        public static final int tt_feedback_thank_text = 0x7f12019b;

        /* JADX INFO: Added by JADX */
        public static final int tt_feel_hint = 0x7f12019c;

        /* JADX INFO: Added by JADX */
        public static final int tt_frequent_call_erroe = 0x7f12019d;

        /* JADX INFO: Added by JADX */
        public static final int tt_full_screen_skip_tx = 0x7f12019e;

        /* JADX INFO: Added by JADX */
        public static final int tt_good = 0x7f12019f;

        /* JADX INFO: Added by JADX */
        public static final int tt_init_setting_config_not_complete = 0x7f1201a0;

        /* JADX INFO: Added by JADX */
        public static final int tt_insert_ad_load_image_error = 0x7f1201a1;

        /* JADX INFO: Added by JADX */
        public static final int tt_lack_android_manifest_configuration = 0x7f1201a2;

        /* JADX INFO: Added by JADX */
        public static final int tt_like_this_ad = 0x7f1201a3;

        /* JADX INFO: Added by JADX */
        public static final int tt_list_end_tip = 0x7f1201a4;

        /* JADX INFO: Added by JADX */
        public static final int tt_load_creative_icon_error = 0x7f1201a5;

        /* JADX INFO: Added by JADX */
        public static final int tt_load_creative_icon_response_error = 0x7f1201a6;

        /* JADX INFO: Added by JADX */
        public static final int tt_loading_language = 0x7f1201a7;

        /* JADX INFO: Added by JADX */
        public static final int tt_loading_more = 0x7f1201a8;

        /* JADX INFO: Added by JADX */
        public static final int tt_logo_cn = 0x7f1201a9;

        /* JADX INFO: Added by JADX */
        public static final int tt_logo_en = 0x7f1201aa;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_copy_link = 0x7f1201ab;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_history = 0x7f1201ac;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_open_browser = 0x7f1201ad;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_report = 0x7f1201ae;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_retry = 0x7f1201af;

        /* JADX INFO: Added by JADX */
        public static final int tt_more_title = 0x7f1201b0;

        /* JADX INFO: Added by JADX */
        public static final int tt_msgPlayable = 0x7f1201b1;

        /* JADX INFO: Added by JADX */
        public static final int tt_multiple_ad_indicator = 0x7f1201b2;

        /* JADX INFO: Added by JADX */
        public static final int tt_multiple_playable_next_ad_tips = 0x7f1201b3;

        /* JADX INFO: Added by JADX */
        public static final int tt_multiple_playable_wait_tips = 0x7f1201b4;

        /* JADX INFO: Added by JADX */
        public static final int tt_negtiveBtnBtnText = 0x7f1201b5;

        /* JADX INFO: Added by JADX */
        public static final int tt_negtive_txt = 0x7f1201b6;

        /* JADX INFO: Added by JADX */
        public static final int tt_net_error = 0x7f1201b7;

        /* JADX INFO: Added by JADX */
        public static final int tt_no_ad = 0x7f1201b8;

        /* JADX INFO: Added by JADX */
        public static final int tt_no_ad_parse = 0x7f1201b9;

        /* JADX INFO: Added by JADX */
        public static final int tt_no_network = 0x7f1201ba;

        /* JADX INFO: Added by JADX */
        public static final int tt_not_bad = 0x7f1201bb;

        /* JADX INFO: Added by JADX */
        public static final int tt_other_reason = 0x7f1201bc;

        /* JADX INFO: Added by JADX */
        public static final int tt_parse_fail = 0x7f1201bd;

        /* JADX INFO: Added by JADX */
        public static final int tt_postiveBtnText = 0x7f1201be;

        /* JADX INFO: Added by JADX */
        public static final int tt_postiveBtnTextPlayable = 0x7f1201bf;

        /* JADX INFO: Added by JADX */
        public static final int tt_postive_txt = 0x7f1201c0;

        /* JADX INFO: Added by JADX */
        public static final int tt_privacy_title = 0x7f1201c1;

        /* JADX INFO: Added by JADX */
        public static final int tt_reder_ad_load_timeout = 0x7f1201c2;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_diff_template_invalid = 0x7f1201c3;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_fail_meta_invalid = 0x7f1201c4;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_fail_template_parse_error = 0x7f1201c5;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_fail_timeout = 0x7f1201c6;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_fail_unknown = 0x7f1201c7;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_main_template_invalid = 0x7f1201c8;

        /* JADX INFO: Added by JADX */
        public static final int tt_render_render_parse_error = 0x7f1201c9;

        /* JADX INFO: Added by JADX */
        public static final int tt_report_this_ad = 0x7f1201ca;

        /* JADX INFO: Added by JADX */
        public static final int tt_request_body_error = 0x7f1201cb;

        /* JADX INFO: Added by JADX */
        public static final int tt_request_pb_error = 0x7f1201cc;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_feedback = 0x7f1201cd;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_full_skip = 0x7f1201ce;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_msg = 0x7f1201cf;

        /* JADX INFO: Added by JADX */
        public static final int tt_reward_screen_skip_tx = 0x7f1201d0;

        /* JADX INFO: Added by JADX */
        public static final int tt_ror_code_show_event_error = 0x7f1201d1;

        /* JADX INFO: Added by JADX */
        public static final int tt_select_reason = 0x7f1201d2;

        /* JADX INFO: Added by JADX */
        public static final int tt_skip_ad_time_text = 0x7f1201d3;

        /* JADX INFO: Added by JADX */
        public static final int tt_slide_up_3d = 0x7f1201d4;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_ad_load_image_error = 0x7f1201d5;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_brush_mask_hint = 0x7f1201d6;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_brush_mask_title = 0x7f1201d7;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_cache_expired_error = 0x7f1201d8;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_cache_parse_error = 0x7f1201d9;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_default_click_shake = 0x7f1201da;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_not_have_cache_error = 0x7f1201db;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_rock_text = 0x7f1201dc;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_rock_top_text = 0x7f1201dd;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_wriggle_text = 0x7f1201de;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_wriggle_top_text = 0x7f1201df;

        /* JADX INFO: Added by JADX */
        public static final int tt_splash_wriggle_top_text_style_17 = 0x7f1201e0;

        /* JADX INFO: Added by JADX */
        public static final int tt_suggestion_commit = 0x7f1201e1;

        /* JADX INFO: Added by JADX */
        public static final int tt_sys_error = 0x7f1201e2;

        /* JADX INFO: Added by JADX */
        public static final int tt_template_load_fail = 0x7f1201e3;

        /* JADX INFO: Added by JADX */
        public static final int tt_text_privacy_app_version = 0x7f1201e4;

        /* JADX INFO: Added by JADX */
        public static final int tt_text_privacy_development = 0x7f1201e5;

        /* JADX INFO: Added by JADX */
        public static final int tt_try_now = 0x7f1201e6;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_bytesize = 0x7f1201e7;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_dial_phone = 0x7f1201e8;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_download_apk = 0x7f1201e9;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_mobile_go_detail = 0x7f1201ea;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_retry_des_txt = 0x7f1201eb;

        /* JADX INFO: Added by JADX */
        public static final int tt_video_without_wifi_tips = 0x7f1201ec;

        /* JADX INFO: Added by JADX */
        public static final int tt_wap_empty = 0x7f1201ed;

        /* JADX INFO: Added by JADX */
        public static final int tt_web_title_default = 0x7f1201ee;

        /* JADX INFO: Added by JADX */
        public static final int unity_plugin_version = 0x7f1201ef;

        /* JADX INFO: Added by JADX */
        public static final int v7_preference_off = 0x7f1201f0;

        /* JADX INFO: Added by JADX */
        public static final int v7_preference_on = 0x7f1201f1;

        /* JADX INFO: Added by JADX */
        public static final int watermark_label_prefix = 0x7f1201f2;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ad_format = 0x7f1201f3;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_code = 0x7f1201f4;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_load_ad = 0x7f1201f5;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_network = 0x7f1201f6;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_show_ad = 0x7f1201f7;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_ads_config_try_again = 0x7f1201f8;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_debugger_title = 0x7f1201f9;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_adtype_appopen = 0x7f1201fa;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_adtype_iv = 0x7f1201fb;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_adtype_riv = 0x7f1201fc;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_adtype_rv = 0x7f1201fd;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_adcontent = 0x7f1201fe;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_adnotskip = 0x7f1201ff;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_adsizenotfit = 0x7f120200;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_blackscreen = 0x7f120201;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_gamecrash = 0x7f120202;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_noncloseable = 0x7f120203;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_others = 0x7f120204;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_rvnotgranted = 0x7f120205;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_menu_issue_whitescreen = 0x7f120206;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_adtype_select = 0x7f120207;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_adtype_title = 0x7f120208;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_cancel = 0x7f120209;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_desc_hint = 0x7f12020a;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_desc_title = 0x7f12020b;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_email_hint = 0x7f12020c;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_email_title = 0x7f12020d;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_issue_type_select = 0x7f12020e;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_issue_type_title = 0x7f12020f;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_submit = 0x7f120210;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_reportad_title = 0x7f120211;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_age = 0x7f120212;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_protocol_privacy = 0x7f120213;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_protocol_term = 0x7f120214;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_uc_accept = 0x7f120215;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_uc_age = 0x7f120216;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_uc_msg = 0x7f120217;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_uc_prompt = 0x7f120218;

        /* JADX INFO: Added by JADX */
        public static final int yodo1_mas_string_uc_select_age = 0x7f120219;

        private string() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class style {

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat = 0x7f130000;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat_Light = 0x7f130001;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Dialog = 0x7f130002;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 0x7f130003;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Tooltip = 0x7f130004;

        /* JADX INFO: Added by JADX */
        public static final int AppBaseTheme = 0x7f130005;

        /* JADX INFO: Added by JADX */
        public static final int AppTheme = 0x7f130006;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat = 0x7f130007;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 0x7f130008;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 0x7f130009;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 0x7f13000a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 0x7f13000b;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 0x7f13000c;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 0x7f13000d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat = 0x7f13000e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f13000f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f130010;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f130011;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f130012;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f130013;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f130014;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f130015;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f130016;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f130017;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f130018;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f130019;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f13001a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f13001b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f13001c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f13001d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f13001e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f13001f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 0x7f130020;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f130021;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f130022;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f130023;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f130024;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f130025;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f130026;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f130027;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f130028;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 0x7f130029;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f13002a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f13002b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f13002c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f13002d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f13002e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f13002f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f130030;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 0x7f130031;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f130032;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 0x7f130033;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f130034;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f130035;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f130036;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f130037;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f130038;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f130039;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f13003a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f13003b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f13003c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f13003d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat = 0x7f13003e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f13003f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 0x7f130040;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 0x7f130041;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f130042;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f130043;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f130044;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light = 0x7f130045;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f130046;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f130047;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f130048;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f130049;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f13004a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f13004b;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 0x7f13004c;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f13004d;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f13004e;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f13004f;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 0x7f130050;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 0x7f130051;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f130052;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat = 0x7f130053;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f130054;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f130055;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f130056;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 0x7f130057;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat = 0x7f130058;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 0x7f130059;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat = 0x7f13005a;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 0x7f13005b;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat = 0x7f13005c;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 0x7f13005d;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 0x7f13005e;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat = 0x7f13005f;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 0x7f130060;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat = 0x7f130061;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f130062;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f130063;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f130064;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 0x7f130065;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 0x7f130066;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 0x7f130067;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 0x7f130068;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f130069;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f13006a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f13006b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f13006c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f13006d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f13006e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f13006f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f130070;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f130071;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f130072;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f130073;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button = 0x7f130074;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 0x7f130075;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f130076;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f130077;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 0x7f130078;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 0x7f130079;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 0x7f13007a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f13007b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f13007c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f13007d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f13007e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f13007f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f130080;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f130081;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 0x7f130082;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 0x7f130083;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f130084;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f130085;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f130086;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f130087;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f130088;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f130089;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f13008a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f13008b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 0x7f13008c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f13008d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 0x7f13008e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f13008f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f130090;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f130091;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f130092;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 0x7f130093;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 0x7f130094;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f130095;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 0x7f130096;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 0x7f130097;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 0x7f130098;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 0x7f130099;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f13009a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 0x7f13009b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 0x7f13009c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 0x7f13009d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 0x7f13009e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 0x7f13009f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f1300a0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f1300a1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f1300a2;

        /* JADX INFO: Added by JADX */
        public static final int BaseUnityGameActivityTheme = 0x7f1300a3;

        /* JADX INFO: Added by JADX */
        public static final int BaseUnityGameActivityTheme_Translucent = 0x7f1300a4;

        /* JADX INFO: Added by JADX */
        public static final int BaseUnityTheme = 0x7f1300a5;

        /* JADX INFO: Added by JADX */
        public static final int BigoAd_Dialog_Fullscreen = 0x7f1300a6;

        /* JADX INFO: Added by JADX */
        public static final int Bm_Animation_BottomSheetDialog = 0x7f1300a7;

        /* JADX INFO: Added by JADX */
        public static final int Bm_BottomSheetDialog = 0x7f1300a8;

        /* JADX INFO: Added by JADX */
        public static final int Dialog_FullScreen = 0x7f1300a9;

        /* JADX INFO: Added by JADX */
        public static final int DialogWindowTheme = 0x7f1300aa;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton = 0x7f1300ab;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_FastForward = 0x7f1300ac;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_Next = 0x7f1300ad;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_Pause = 0x7f1300ae;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_Play = 0x7f1300af;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_Previous = 0x7f1300b0;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_Rewind = 0x7f1300b1;

        /* JADX INFO: Added by JADX */
        public static final int ExoMediaButton_VR = 0x7f1300b2;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls = 0x7f1300b3;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button = 0x7f1300b4;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom = 0x7f1300b5;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_AudioTrack = 0x7f1300b6;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_CC = 0x7f1300b7;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_FullScreen = 0x7f1300b8;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_OverflowHide = 0x7f1300b9;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_OverflowShow = 0x7f1300ba;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_PlaybackSpeed = 0x7f1300bb;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_RepeatToggle = 0x7f1300bc;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_Settings = 0x7f1300bd;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_Shuffle = 0x7f1300be;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Bottom_VR = 0x7f1300bf;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center = 0x7f1300c0;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center_FfwdWithAmount = 0x7f1300c1;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center_Next = 0x7f1300c2;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center_PlayPause = 0x7f1300c3;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center_Previous = 0x7f1300c4;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_Button_Center_RewWithAmount = 0x7f1300c5;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_TimeBar = 0x7f1300c6;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_TimeText = 0x7f1300c7;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_TimeText_Duration = 0x7f1300c8;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_TimeText_Position = 0x7f1300c9;

        /* JADX INFO: Added by JADX */
        public static final int ExoStyledControls_TimeText_Separator = 0x7f1300ca;

        /* JADX INFO: Added by JADX */
        public static final int FullscreenAdActivity = 0x7f1300cb;

        /* JADX INFO: Added by JADX */
        public static final int InneractiveAppTheme_Home = 0x7f1300cc;

        /* JADX INFO: Added by JADX */
        public static final int LandingPageStyle = 0x7f1300cd;

        /* JADX INFO: Added by JADX */
        public static final int LargeIconView = 0x7f1300ce;

        /* JADX INFO: Added by JADX */
        public static final int MBridgeAppTheme = 0x7f1300cf;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat = 0x7f1300d0;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat_Light = 0x7f1300d1;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 0x7f1300d2;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 0x7f1300d3;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 0x7f1300d4;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat = 0x7f1300d5;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat_Light = 0x7f1300d6;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat = 0x7f1300d7;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat_Light = 0x7f1300d8;

        /* JADX INFO: Added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 0x7f1300d9;

        /* JADX INFO: Added by JADX */
        public static final int PopupTransparent = 0x7f1300da;

        /* JADX INFO: Added by JADX */
        public static final int Preference = 0x7f1300db;

        /* JADX INFO: Added by JADX */
        public static final int Preference_Category = 0x7f1300dc;

        /* JADX INFO: Added by JADX */
        public static final int Preference_Category_Material = 0x7f1300dd;

        /* JADX INFO: Added by JADX */
        public static final int Preference_CheckBoxPreference = 0x7f1300de;

        /* JADX INFO: Added by JADX */
        public static final int Preference_CheckBoxPreference_Material = 0x7f1300df;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DialogPreference = 0x7f1300e0;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DialogPreference_EditTextPreference = 0x7f1300e1;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DialogPreference_EditTextPreference_Material = 0x7f1300e2;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DialogPreference_Material = 0x7f1300e3;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DropDown = 0x7f1300e4;

        /* JADX INFO: Added by JADX */
        public static final int Preference_DropDown_Material = 0x7f1300e5;

        /* JADX INFO: Added by JADX */
        public static final int Preference_Information = 0x7f1300e6;

        /* JADX INFO: Added by JADX */
        public static final int Preference_Information_Material = 0x7f1300e7;

        /* JADX INFO: Added by JADX */
        public static final int Preference_Material = 0x7f1300e8;

        /* JADX INFO: Added by JADX */
        public static final int Preference_PreferenceScreen = 0x7f1300e9;

        /* JADX INFO: Added by JADX */
        public static final int Preference_PreferenceScreen_Material = 0x7f1300ea;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SeekBarPreference = 0x7f1300eb;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SeekBarPreference_Material = 0x7f1300ec;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SwitchPreference = 0x7f1300ed;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SwitchPreference_Material = 0x7f1300ee;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SwitchPreferenceCompat = 0x7f1300ef;

        /* JADX INFO: Added by JADX */
        public static final int Preference_SwitchPreferenceCompat_Material = 0x7f1300f0;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceCategoryTitleTextStyle = 0x7f1300f1;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceFragment = 0x7f1300f2;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceFragment_Material = 0x7f1300f3;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceFragmentList = 0x7f1300f4;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceFragmentList_Material = 0x7f1300f5;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceSummaryTextStyle = 0x7f1300f6;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceThemeOverlay = 0x7f1300f7;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceThemeOverlay_v14 = 0x7f1300f8;

        /* JADX INFO: Added by JADX */
        public static final int PreferenceThemeOverlay_v14_Material = 0x7f1300f9;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f1300fa;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f1300fb;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 0x7f1300fc;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f1300fd;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f1300fe;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 0x7f1300ff;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 0x7f130100;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f130101;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 0x7f130102;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f130103;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f130104;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f130105;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f130106;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f130107;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f130108;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 0x7f130109;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 0x7f13010a;

        /* JADX INFO: Added by JADX */
        public static final int SmallIconView = 0x7f13010b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat = 0x7f13010c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 0x7f13010d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 0x7f13010e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Button = 0x7f13010f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 0x7f130110;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 0x7f130111;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 0x7f130112;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 0x7f130113;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 0x7f130114;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 0x7f130115;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 0x7f130116;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large = 0x7f130117;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f130118;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f130119;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f13011a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f13011b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f13011c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 0x7f13011d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f13011e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 0x7f13011f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f130120;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f130121;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small = 0x7f130122;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f130123;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 0x7f130124;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f130125;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title = 0x7f130126;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f130127;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 0x7f130128;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f130129;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f13012a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f13012b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f13012c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f13012d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f13012e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f13012f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f130130;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f130131;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 0x7f130132;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f130133;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 0x7f130134;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f130135;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f130136;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f130137;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f130138;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f130139;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f13013a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f13013b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 0x7f13013c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 0x7f13013d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info_Media = 0x7f13013e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f13013f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2_Media = 0x7f130140;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Media = 0x7f130141;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 0x7f130142;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time_Media = 0x7f130143;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 0x7f130144;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title_Media = 0x7f130145;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f130146;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f130147;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f130148;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat = 0x7f130149;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 0x7f13014a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight = 0x7f13014b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 0x7f13014c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 0x7f13014d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 0x7f13014e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 0x7f13014f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 0x7f130150;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 0x7f130151;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog = 0x7f130152;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 0x7f130153;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 0x7f130154;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f130155;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Empty = 0x7f130156;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light = 0x7f130157;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f130158;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 0x7f130159;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 0x7f13015a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f13015b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f13015c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f13015d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 0x7f13015e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Games_Transparent = 0x7f13015f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_IAPTheme = 0x7f130160;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat = 0x7f130161;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f130162;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f130163;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f130164;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 0x7f130165;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 0x7f130166;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 0x7f130167;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 0x7f130168;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 0x7f130169;

        /* JADX INFO: Added by JADX */
        public static final int TransparentDialog = 0x7f13016a;

        /* JADX INFO: Added by JADX */
        public static final int UnityThemeSelector = 0x7f13016b;

        /* JADX INFO: Added by JADX */
        public static final int UnityThemeSelector_Translucent = 0x7f13016c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar = 0x7f13016d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f13016e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f13016f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f130170;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f130171;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton = 0x7f130172;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f130173;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f130174;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionMode = 0x7f130175;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f130176;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f130177;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button = 0x7f130178;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 0x7f130179;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 0x7f13017a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f13017b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 0x7f13017c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Small = 0x7f13017d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 0x7f13017e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f13017f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 0x7f130180;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 0x7f130181;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f130182;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f130183;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f130184;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_EditText = 0x7f130185;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ImageButton = 0x7f130186;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f130187;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f130188;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f130189;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f13018a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f13018b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f13018c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f13018d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f13018e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f13018f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f130190;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f130191;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f130192;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f130193;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f130194;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f130195;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f130196;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f130197;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f130198;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f130199;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f13019a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 0x7f13019b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f13019c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 0x7f13019d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f13019e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView = 0x7f13019f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f1301a0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 0x7f1301a1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 0x7f1301a2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f1301a3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 0x7f1301a4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 0x7f1301a5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f1301a6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar = 0x7f1301a7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 0x7f1301a8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 0x7f1301a9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView = 0x7f1301aa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 0x7f1301ab;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar = 0x7f1301ac;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 0x7f1301ad;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner = 0x7f1301ae;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f1301af;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f1301b0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 0x7f1301b1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView = 0x7f1301b2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 0x7f1301b3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar = 0x7f1301b4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f1301b5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 0x7f1301b6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 0x7f1301b7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Support_CoordinatorLayout = 0x7f1301b8;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar = 0x7f1301b9;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar_TitleTextStyle = 0x7f1301ba;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_creative_CreativeDebuggerActivity_Theme = 0x7f1301bb;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_creative_debugger_ui_DisplayedAdActivity_ReportAdButton = 0x7f1301bc;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar = 0x7f1301bd;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_Live = 0x7f1301be;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_TitleTextStyle = 0x7f1301bf;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_MaxDebuggerActivity_Theme = 0x7f1301c0;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_MaxDebuggerActivity_Theme_Live = 0x7f1301c1;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AdBadgeTextView = 0x7f1301c2;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AutoScrollingTextView = 0x7f1301c3;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_CTAButton = 0x7f1301c4;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ExtraSmallAdBadgeTextView = 0x7f1301c5;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ExtraSmallScrollingBodyTextView = 0x7f1301c6;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ExtraSmallScrollingTitleTextView = 0x7f1301c7;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeAdBadgeTextView = 0x7f1301c8;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingBodyTextView = 0x7f1301c9;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingTitleTextView = 0x7f1301ca;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalBodyTextSize = 0x7f1301cb;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalTitleTextSize = 0x7f1301cc;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ScrollingTitleTextView = 0x7f1301cd;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallAdBadgeTextView = 0x7f1301ce;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingBodyTextView = 0x7f1301cf;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingTitleTextView = 0x7f1301d0;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalBodyTextSize = 0x7f1301d1;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalTitleTextSize = 0x7f1301d2;

        /* JADX INFO: Added by JADX */
        public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_TitleTextStyle = 0x7f1301d3;

        /* JADX INFO: Added by JADX */
        public static final int ia_bottom_left_overlay = 0x7f1301d4;

        /* JADX INFO: Added by JADX */
        public static final int ia_bottom_right_overlay = 0x7f1301d5;

        /* JADX INFO: Added by JADX */
        public static final int ia_expand_collapse_button_style = 0x7f1301d6;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_banner_overlay_style = 0x7f1301d7;

        /* JADX INFO: Added by JADX */
        public static final int ia_identifier_overlay_style = 0x7f1301d8;

        /* JADX INFO: Added by JADX */
        public static final int ia_mute_button_style = 0x7f1301d9;

        /* JADX INFO: Added by JADX */
        public static final int ia_play_button_style = 0x7f1301da;

        /* JADX INFO: Added by JADX */
        public static final int ia_top_left_overlay = 0x7f1301db;

        /* JADX INFO: Added by JADX */
        public static final int ia_top_right_overlay = 0x7f1301dc;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_app_info_btn_style = 0x7f1301dd;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_call_to_action_style = 0x7f1301de;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_remaining_time_style = 0x7f1301df;

        /* JADX INFO: Added by JADX */
        public static final int ia_tv_skip_style = 0x7f1301e0;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_overlay_text_view = 0x7f1301e1;

        /* JADX INFO: Added by JADX */
        public static final int ia_video_progressbar_style = 0x7f1301e2;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_common_activity_style = 0x7f1301e3;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_reward_theme = 0x7f1301e4;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_transparent_common_activity_style = 0x7f1301e5;

        /* JADX INFO: Added by JADX */
        public static final int mbridge_transparent_theme = 0x7f1301e6;

        /* JADX INFO: Added by JADX */
        public static final int myDialog = 0x7f1301e7;

        /* JADX INFO: Added by JADX */
        public static final int myProgressBarStyle = 0x7f1301e8;

        /* JADX INFO: Added by JADX */
        public static final int tt_animation = 0x7f1301e9;

        /* JADX INFO: Added by JADX */
        public static final int tt_app_open_ad_no_animation = 0x7f1301ea;

        /* JADX INFO: Added by JADX */
        public static final int tt_app_open_ad_no_animation_trans = 0x7f1301eb;

        /* JADX INFO: Added by JADX */
        public static final int tt_custom_dialog = 0x7f1301ec;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislikeDialog = 0x7f1301ed;

        /* JADX INFO: Added by JADX */
        public static final int tt_dislikeDialogAnimation = 0x7f1301ee;

        /* JADX INFO: Added by JADX */
        public static final int tt_full_screen = 0x7f1301ef;

        /* JADX INFO: Added by JADX */
        public static final int tt_full_screen_interaction = 0x7f1301f0;

        /* JADX INFO: Added by JADX */
        public static final int tt_full_screen_new = 0x7f1301f1;

        /* JADX INFO: Added by JADX */
        public static final int tt_landing_page = 0x7f1301f2;

        /* JADX INFO: Added by JADX */
        public static final int tt_privacy_dialog_theme_ad_report = 0x7f1301f3;

        /* JADX INFO: Added by JADX */
        public static final int tt_privacy_landing_page = 0x7f1301f4;

        /* JADX INFO: Added by JADX */
        public static final int tt_quick_option_dialog = 0x7f1301f5;
    }

    /* JADX INFO: Added by JADX */
    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int com_android_billingclient_phenotype = 0x7f150000;

        /* JADX INFO: Added by JADX */
        public static final int image_share_filepaths = 0x7f150001;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f150002;
    }

    private R() {
    }
}
