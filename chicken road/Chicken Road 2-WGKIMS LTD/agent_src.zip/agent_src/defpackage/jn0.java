package defpackage;

/* loaded from: classes.dex */
public abstract class jn0 {
    public static final defpackage.nj AqsOwbEF;
    public static final float BCxB3l2DENQ;
    public static final defpackage.ve1 EUGsszWpP4;
    public static final defpackage.nj LQkLH9RtdoX;
    public static final defpackage.nj PJFAWmtS;
    public static final defpackage.rk1 SOLzqtJLiD8g;
    public static final defpackage.hl Ts5Bfxu7gi;
    public static final defpackage.g1 Wg7Cen3syT;
    public static final defpackage.yn1 X2zla1VHV;
    public static final defpackage.tu1 X9gUlnc07R;
    public static final defpackage.nj acT0gEliM;
    public static final defpackage.rk1 cAUonbdEve;
    public static final java.lang.StackTraceElement[] h86pw74rDIBM;
    public static final java.lang.Object lWYAEQgM;
    public static final defpackage.nj neoVPlKKu;
    public static final defpackage.h90 oA3oVL3lY;
    public static final defpackage.k20 ybb6jpEh;
    public static final defpackage.y71 ywSpSBoL;
    public static final defpackage.e51 CGnIndwjik9 = new defpackage.e51("wallet");
    public static final defpackage.e51 wk61Lrtj = new defpackage.e51("unlocked_skins");
    public static final defpackage.e51 m4CNag5J8Y = new defpackage.e51("selected_skin");
    public static final defpackage.e51 ShamLDIR = new defpackage.e51("preferred_mode");
    public static final defpackage.e51 hyi5MRgVJpZU = new defpackage.e51("runs_played");
    public static final defpackage.e51 bGtyfE77Qpby = new defpackage.e51("victories");
    public static final defpackage.e51 AdtkbTq73SIl = new defpackage.e51("best_chapter");
    public static final defpackage.e51 KImmPBu5u = new defpackage.e51("maestro_victory");
    public static final defpackage.e51 EX2ajLj518q3 = new defpackage.e51("leaderboard");
    public static final defpackage.e51 O21Gh3JCO74 = new defpackage.e51("checkpoint");

    static {
        defpackage.rk1 rk1Var = defpackage.rk1.bGtyfE77Qpby;
        SOLzqtJLiD8g = rk1Var;
        Ts5Bfxu7gi = new defpackage.hl(1803997696, new defpackage.m7(2), false);
        ybb6jpEh = new defpackage.k20(7);
        oA3oVL3lY = new defpackage.h90(false);
        Wg7Cen3syT = new defpackage.g1(5);
        acT0gEliM = defpackage.nj.bGtyfE77Qpby;
        AqsOwbEF = defpackage.nj.Ts5Bfxu7gi;
        cAUonbdEve = rk1Var;
        LQkLH9RtdoX = defpackage.nj.SOLzqtJLiD8g;
        defpackage.nj njVar = defpackage.nj.KImmPBu5u;
        neoVPlKKu = njVar;
        PJFAWmtS = njVar;
        BCxB3l2DENQ = 80.0f;
        X9gUlnc07R = defpackage.tu1.KImmPBu5u;
        h86pw74rDIBM = new java.lang.StackTraceElement[0];
        EUGsszWpP4 = new defpackage.ve1();
        ywSpSBoL = new defpackage.y71(0.0f, 0.0f, 10.0f, 10.0f);
        lWYAEQgM = new java.lang.Object();
        X2zla1VHV = new defpackage.yn1(10);
    }

    public static final void AdtkbTq73SIl(java.lang.String str, java.lang.String str2, defpackage.z30 z30Var, defpackage.h60 h60Var, int i) {
        int i2;
        defpackage.h60 h60Var2;
        h60Var.vkFkPUN4(-1963741265);
        if ((i & 6) == 0) {
            i2 = (h60Var.bGtyfE77Qpby(str) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= h60Var.bGtyfE77Qpby(str2) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= h60Var.KImmPBu5u(z30Var) ? 256 : 128;
        }
        if (h60Var.eMSp92M2t(i2 & 1, (i2 & 147) != 146)) {
            defpackage.io0 io0VarHwJeYkFOwb2F = defpackage.yr.hwJeYkFOwb2F(defpackage.l.oA3oVL3lY, 0.0f, 6.0f);
            defpackage.of1 of1VarCGnIndwjik9 = defpackage.nf1.CGnIndwjik9(defpackage.f12.CGnIndwjik9, defpackage.kl1.acT0gEliM, h60Var, 48);
            int iHashCode = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var, io0VarHwJeYkFOwb2F);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.n2 n2Var = defpackage.bm.hyi5MRgVJpZU;
            defpackage.j20.eMSp92M2t(n2Var, h60Var, of1VarCGnIndwjik9);
            defpackage.n2 n2Var2 = defpackage.bm.ShamLDIR;
            defpackage.j20.eMSp92M2t(n2Var2, h60Var, y21VarTs5Bfxu7gi);
            java.lang.Integer numValueOf = java.lang.Integer.valueOf(iHashCode);
            defpackage.n2 n2Var3 = defpackage.bm.bGtyfE77Qpby;
            defpackage.j20.eMSp92M2t(n2Var3, h60Var, numValueOf);
            defpackage.hbKzxEMvi3Xb hbkzxemvi3xb = defpackage.bm.AdtkbTq73SIl;
            defpackage.j20.QTXOIjVJtE(h60Var, hbkzxemvi3xb);
            defpackage.n2 n2Var4 = defpackage.bm.m4CNag5J8Y;
            defpackage.j20.eMSp92M2t(n2Var4, h60Var, io0VarZsS39c8E7oY);
            defpackage.io0 io0VarXy7yDq1ZM = defpackage.yr.xy7yDq1ZM(defpackage.f12.AqsOwbEF(defpackage.l.eMSp92M2t(defpackage.fo0.CGnIndwjik9, 56.0f), defpackage.kf1.CGnIndwjik9(12.0f)), defpackage.ij.wk61Lrtj(defpackage.q11.ybb6jpEh, 0.22f), defpackage.fc0.AdtkbTq73SIl);
            defpackage.pn0 pn0VarM4CNag5J8Y = defpackage.oe.m4CNag5J8Y(defpackage.kl1.SOLzqtJLiD8g, false);
            int iHashCode2 = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi2 = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY2 = defpackage.yr.ZsS39c8E7oY(h60Var, io0VarXy7yDq1ZM);
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(n2Var, h60Var, pn0VarM4CNag5J8Y);
            defpackage.j20.eMSp92M2t(n2Var2, h60Var, y21VarTs5Bfxu7gi2);
            defpackage.n51.Wg7Cen3syT(iHashCode2, h60Var, n2Var3, h60Var, hbkzxemvi3xb);
            defpackage.j20.eMSp92M2t(n2Var4, h60Var, io0VarZsS39c8E7oY2);
            defpackage.yr.X2zla1VHV(46.0f, null, z30Var, h60Var, (i2 & 896) | 6);
            h60Var.acT0gEliM(true);
            defpackage.i20.hyi5MRgVJpZU(h60Var, defpackage.l.ZsS39c8E7oY(12.0f));
            defpackage.pf0 pf0Var = new defpackage.pf0(1.0f, true);
            defpackage.wj wjVarCGnIndwjik9 = defpackage.uj.CGnIndwjik9(defpackage.f12.wk61Lrtj, defpackage.kl1.cAUonbdEve, h60Var, 0);
            int i3 = i2;
            int iHashCode3 = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi3 = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY3 = defpackage.yr.ZsS39c8E7oY(h60Var, pf0Var);
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(n2Var, h60Var, wjVarCGnIndwjik9);
            defpackage.j20.eMSp92M2t(n2Var2, h60Var, y21VarTs5Bfxu7gi3);
            defpackage.n51.Wg7Cen3syT(iHashCode3, h60Var, n2Var3, h60Var, hbkzxemvi3xb);
            defpackage.j20.eMSp92M2t(n2Var4, h60Var, io0VarZsS39c8E7oY3);
            defpackage.uw uwVar = defpackage.uu1.CGnIndwjik9;
            defpackage.gr1.wk61Lrtj(str, null, defpackage.q11.KImmPBu5u, 0L, null, 0L, null, 0L, 0, false, 0, 0, ((defpackage.su1) h60Var.O21Gh3JCO74(uwVar)).EX2ajLj518q3, h60Var, (i3 & 14) | 384, 0, 131066);
            h60Var2 = h60Var;
            defpackage.gr1.wk61Lrtj(str2, null, defpackage.q11.ShamLDIR, 0L, null, 0L, null, 0L, 0, false, 0, 0, ((defpackage.su1) h60Var2.O21Gh3JCO74(uwVar)).SOLzqtJLiD8g, h60Var, ((i3 >> 3) & 14) | 384, 0, 131066);
            h60Var2.acT0gEliM(true);
            h60Var2.acT0gEliM(true);
        } else {
            h60Var2 = h60Var;
            h60Var2.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var2.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.fl(str, str2, z30Var, i, 1);
        }
    }

    public static final java.lang.Object AqsOwbEF(defpackage.nn1 nn1Var, int i) {
        java.lang.Object obj;
        nn1Var.getClass();
        int iAuXIgCKsG = defpackage.yr.auXIgCKsG(nn1Var.hyi5MRgVJpZU, nn1Var.AdtkbTq73SIl, i);
        if (iAuXIgCKsG < 0 || (obj = nn1Var.bGtyfE77Qpby[iAuXIgCKsG]) == lWYAEQgM) {
            return null;
        }
        return obj;
    }

    public static final void BCxB3l2DENQ(defpackage.us0 us0Var, defpackage.ej1 ej1Var, defpackage.ej1 ej1Var2) {
        defpackage.af0 af0Var;
        defpackage.ej1 ej1VarTs5Bfxu7gi = ej1Var2.Ts5Bfxu7gi();
        defpackage.y71 y71VarAdtkbTq73SIl = (ej1VarTs5Bfxu7gi == null || (af0Var = ej1VarTs5Bfxu7gi.m4CNag5J8Y) == null || !af0Var.auXIgCKsG()) ? ywSpSBoL : ej1VarTs5Bfxu7gi.AdtkbTq73SIl();
        int i = ej1Var2.bGtyfE77Qpby;
        if (i == ej1Var.bGtyfE77Qpby) {
            i = -1;
        }
        us0Var.KImmPBu5u(i, new defpackage.gj1(ej1Var2, defpackage.i20.mbwb7dCOYb(y71VarAdtkbTq73SIl)));
    }

    public static final void CGnIndwjik9(final defpackage.o30 o30Var, final defpackage.hl hlVar, defpackage.io0 io0Var, final defpackage.d40 d40Var, final defpackage.d40 d40Var2, final defpackage.d40 d40Var3, defpackage.pk1 pk1Var, final long j, long j2, final long j3, final long j4, defpackage.du duVar, defpackage.h60 h60Var, final int i) {
        defpackage.o30 o30Var2;
        int i2;
        defpackage.hl hlVar2;
        defpackage.d40 d40Var4;
        defpackage.d40 d40Var5;
        final defpackage.io0 io0Var2;
        final defpackage.pk1 pk1Var2;
        final long j5;
        final defpackage.du duVar2;
        int i3;
        defpackage.io0 io0Var3;
        defpackage.pk1 pk1Var3;
        defpackage.du duVar3;
        long j6;
        h60Var.vkFkPUN4(94478519);
        if ((i & 6) == 0) {
            o30Var2 = o30Var;
            i2 = (h60Var.KImmPBu5u(o30Var2) ? 4 : 2) | i;
        } else {
            o30Var2 = o30Var;
            i2 = i;
        }
        if ((i & 48) == 0) {
            hlVar2 = hlVar;
            i2 |= h60Var.KImmPBu5u(hlVar2) ? 32 : 16;
        } else {
            hlVar2 = hlVar;
        }
        int i4 = i2 | 384;
        if ((i & 3072) == 0) {
            d40Var4 = d40Var;
            i4 |= h60Var.KImmPBu5u(d40Var4) ? 2048 : 1024;
        } else {
            d40Var4 = d40Var;
        }
        int i5 = i4 | 24576;
        if ((196608 & i) == 0) {
            i5 |= h60Var.KImmPBu5u(d40Var2) ? 131072 : 65536;
        }
        if ((1572864 & i) == 0) {
            d40Var5 = d40Var3;
            i5 |= h60Var.KImmPBu5u(d40Var5) ? 1048576 : 524288;
        } else {
            d40Var5 = d40Var3;
        }
        if ((12582912 & i) == 0) {
            i5 |= 4194304;
        }
        if ((100663296 & i) == 0) {
            i5 |= h60Var.hyi5MRgVJpZU(j) ? 67108864 : 33554432;
        }
        if ((805306368 & i) == 0) {
            i5 |= 268435456;
        }
        if (h60Var.eMSp92M2t(i5 & 1, (306783379 & i5) != 306783378)) {
            h60Var.ZsS39c8E7oY();
            if ((i & 1) == 0 || h60Var.EUGsszWpP4()) {
                defpackage.pk1 pk1VarCGnIndwjik9 = defpackage.uk1.CGnIndwjik9(defpackage.zt1.bGtyfE77Qpby, h60Var);
                long jM4CNag5J8Y = defpackage.oj.m4CNag5J8Y(defpackage.zt1.EX2ajLj518q3, h60Var);
                i3 = i5 & (-1908408321);
                defpackage.du duVar4 = new defpackage.du();
                io0Var3 = defpackage.fo0.CGnIndwjik9;
                pk1Var3 = pk1VarCGnIndwjik9;
                duVar3 = duVar4;
                j6 = jM4CNag5J8Y;
            } else {
                h60Var.w9n6oNBhm();
                i3 = i5 & (-1908408321);
                io0Var3 = io0Var;
                pk1Var3 = pk1Var;
                j6 = j2;
                duVar3 = duVar;
            }
            h60Var.AqsOwbEF();
            defpackage.io0 io0Var4 = io0Var3;
            defpackage.P6SUAoVulJo8.m4CNag5J8Y(o30Var2, hlVar2, io0Var4, d40Var4, d40Var2, d40Var5, pk1Var3, j, j6, j3, j4, duVar3, h60Var, i3 & 2147483646, 3510);
            io0Var2 = io0Var4;
            pk1Var2 = pk1Var3;
            j5 = j6;
            duVar2 = duVar3;
        } else {
            h60Var.w9n6oNBhm();
            io0Var2 = io0Var;
            pk1Var2 = pk1Var;
            j5 = j2;
            duVar2 = duVar;
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.d40() { // from class: aj8QHlEQ
                @Override // defpackage.d40
                public final java.lang.Object ShamLDIR(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iM80ht0VsJ = defpackage.h10.M80ht0VsJ(i | 1);
                    defpackage.jn0.CGnIndwjik9(o30Var, hlVar, io0Var2, d40Var, d40Var2, d40Var3, pk1Var2, j, j5, j3, j4, duVar2, (defpackage.h60) obj, iM80ht0VsJ);
                    return defpackage.fv1.CGnIndwjik9;
                }
            };
        }
    }

    public static final java.util.List CO8Wxv6r(int i, int i2, java.util.ArrayList arrayList, java.util.List list) {
        if (arrayList.isEmpty()) {
            return defpackage.ey.hyi5MRgVJpZU;
        }
        java.util.ArrayList arrayList2 = new java.util.ArrayList(list);
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            defpackage.kh0 kh0Var = (defpackage.kh0) arrayList.get(i3);
            int index = kh0Var.getIndex();
            if (i <= index && index <= i2) {
                arrayList2.add(kh0Var);
            }
        }
        defpackage.fj.d5vh3ApcY(arrayList2, Wg7Cen3syT);
        return arrayList2;
    }

    public static java.util.Set EUGsszWpP4() {
        try {
            java.lang.Object objInvoke = java.lang.Class.forName("android.text.EmojiConsistency").getMethod("getEmojiConsistencySet", null).invoke(null, null);
            if (objInvoke == null) {
                return java.util.Collections.EMPTY_SET;
            }
            java.util.Set set = (java.util.Set) objInvoke;
            java.util.Iterator it = set.iterator();
            while (it.hasNext()) {
                if (!(it.next() instanceof int[])) {
                    return java.util.Collections.EMPTY_SET;
                }
            }
            return set;
        } catch (java.lang.Throwable unused) {
            return java.util.Collections.EMPTY_SET;
        }
    }

    public static final void EX2ajLj518q3(defpackage.y41 y41Var, defpackage.j11 j11Var, defpackage.o30 o30Var, defpackage.h60 h60Var, int i) {
        defpackage.h60 h60Var2;
        defpackage.kh1 kh1Var;
        defpackage.y41 y41Var2 = y41Var;
        y41Var2.getClass();
        o30Var.getClass();
        h60Var.vkFkPUN4(-769105573);
        int i2 = i | (h60Var.KImmPBu5u(y41Var2) ? 4 : 2) | (h60Var.bGtyfE77Qpby(j11Var) ? 32 : 16) | (h60Var.KImmPBu5u(o30Var) ? 256 : 128);
        int i3 = 0;
        if (h60Var.eMSp92M2t(i2 & 1, (i2 & 147) != 146)) {
            defpackage.ot0 ot0VarAcT0gEliM = acT0gEliM(y41Var2.m4CNag5J8Y, h60Var);
            defpackage.io0 io0VarHwJeYkFOwb2F = defpackage.yr.hwJeYkFOwb2F(defpackage.yr.S1LnOOn8(defpackage.yr.UJW17wJvbt(defpackage.l.PJFAWmtS(1.0f), j11Var), defpackage.yr.mqHNYIdy(h60Var)), 16.0f, 8.0f);
            defpackage.wj wjVarCGnIndwjik9 = defpackage.uj.CGnIndwjik9(new defpackage.x5(10.0f, new defpackage.t5(i3)), defpackage.kl1.cAUonbdEve, h60Var, 6);
            int iHashCode = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var, io0VarHwJeYkFOwb2F);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.n2 n2Var = defpackage.bm.hyi5MRgVJpZU;
            defpackage.j20.eMSp92M2t(n2Var, h60Var, wjVarCGnIndwjik9);
            defpackage.n2 n2Var2 = defpackage.bm.ShamLDIR;
            defpackage.j20.eMSp92M2t(n2Var2, h60Var, y21VarTs5Bfxu7gi);
            java.lang.Integer numValueOf = java.lang.Integer.valueOf(iHashCode);
            defpackage.n2 n2Var3 = defpackage.bm.bGtyfE77Qpby;
            defpackage.j20.eMSp92M2t(n2Var3, h60Var, numValueOf);
            defpackage.hbKzxEMvi3Xb hbkzxemvi3xb = defpackage.bm.AdtkbTq73SIl;
            defpackage.j20.QTXOIjVJtE(h60Var, hbkzxemvi3xb);
            defpackage.n2 n2Var4 = defpackage.bm.m4CNag5J8Y;
            defpackage.j20.eMSp92M2t(n2Var4, h60Var, io0VarZsS39c8E7oY);
            defpackage.d00 d00Var = defpackage.l.oA3oVL3lY;
            defpackage.of1 of1VarCGnIndwjik9 = defpackage.nf1.CGnIndwjik9(new defpackage.x5(8.0f, new defpackage.t5(i3)), defpackage.kl1.acT0gEliM, h60Var, 6);
            int iHashCode2 = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi2 = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY2 = defpackage.yr.ZsS39c8E7oY(h60Var, d00Var);
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(n2Var, h60Var, of1VarCGnIndwjik9);
            defpackage.j20.eMSp92M2t(n2Var2, h60Var, y21VarTs5Bfxu7gi2);
            defpackage.n51.Wg7Cen3syT(iHashCode2, h60Var, n2Var3, h60Var, hbkzxemvi3xb);
            defpackage.j20.eMSp92M2t(n2Var4, h60Var, io0VarZsS39c8E7oY2);
            h60Var.hwJeYkFOwb2F(-667411056);
            defpackage.wy wyVar = defpackage.w70.EX2ajLj518q3;
            wyVar.getClass();
            defpackage.neoVPlKKu neovplkku = new defpackage.neoVPlKKu(wyVar);
            while (true) {
                boolean zHasNext = neovplkku.hasNext();
                kh1Var = defpackage.im.CGnIndwjik9;
                if (!zHasNext) {
                    break;
                }
                defpackage.w70 w70Var = (defpackage.w70) neovplkku.next();
                java.lang.String str = w70Var.hyi5MRgVJpZU;
                boolean z = ((defpackage.x41) ot0VarAcT0gEliM.getValue()).CGnIndwjik9 == w70Var;
                boolean zKImmPBu5u = h60Var.KImmPBu5u(y41Var2) | h60Var.ShamLDIR(w70Var.ordinal());
                java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
                if (zKImmPBu5u || objCO8Wxv6r == kh1Var) {
                    objCO8Wxv6r = new defpackage.c2(8, y41Var2, w70Var);
                    h60Var.XEWVqqb5t6J(objCO8Wxv6r);
                }
                KImmPBu5u(str, z, (defpackage.o30) objCO8Wxv6r, new defpackage.pf0(1.0f, true), h60Var, 0);
            }
            h60Var2 = h60Var;
            h60Var2.acT0gEliM(false);
            h60Var2.acT0gEliM(true);
            int iOrdinal = ((defpackage.x41) ot0VarAcT0gEliM.getValue()).CGnIndwjik9.ordinal();
            if (iOrdinal == 0) {
                h60Var2.hwJeYkFOwb2F(2118770564);
                boolean zKImmPBu5u2 = h60Var2.KImmPBu5u(y41Var2);
                java.lang.Object objCO8Wxv6r2 = h60Var2.CO8Wxv6r();
                if (zKImmPBu5u2 || objCO8Wxv6r2 == kh1Var) {
                    objCO8Wxv6r2 = new defpackage.j1(6, y41Var2);
                    h60Var2.XEWVqqb5t6J(objCO8Wxv6r2);
                }
                m4CNag5J8Y((defpackage.o30) objCO8Wxv6r2, h60Var2, 0);
                h60Var2.acT0gEliM(false);
            } else if (iOrdinal == 1) {
                h60Var2.hwJeYkFOwb2F(2118774647);
                oA3oVL3lY(h60Var2, 0);
                h60Var2.acT0gEliM(false);
            } else {
                if (iOrdinal != 2) {
                    h60Var2.hwJeYkFOwb2F(2118769190);
                    h60Var2.acT0gEliM(false);
                    defpackage.t5.ShamLDIR();
                    return;
                }
                h60Var2.hwJeYkFOwb2F(2118776372);
                defpackage.x41 x41Var = (defpackage.x41) ot0VarAcT0gEliM.getValue();
                boolean zKImmPBu5u3 = h60Var2.KImmPBu5u(y41Var2);
                java.lang.Object objCO8Wxv6r3 = h60Var2.CO8Wxv6r();
                if (zKImmPBu5u3 || objCO8Wxv6r3 == kh1Var) {
                    defpackage.hyi5MRgVJpZU hyi5mrgvjpzu = new defpackage.hyi5MRgVJpZU(1, y41Var, defpackage.y41.class, "onIntent", "onIntent(Ljava/lang/Object;)V", 0, 2);
                    y41Var2 = y41Var;
                    h60Var2.XEWVqqb5t6J(hyi5mrgvjpzu);
                    objCO8Wxv6r3 = hyi5mrgvjpzu;
                }
                SOLzqtJLiD8g(x41Var, (defpackage.z30) ((defpackage.n40) objCO8Wxv6r3), o30Var, h60Var2, i2 & 896);
                h60Var2.acT0gEliM(false);
            }
            h60Var2.acT0gEliM(true);
        } else {
            h60Var2 = h60Var;
            h60Var2.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var2.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.l50(y41Var2, j11Var, o30Var, i, 3);
        }
    }

    public static final boolean JcNBqlq8RG(defpackage.ej1 ej1Var) {
        defpackage.zx0 zx0VarShamLDIR = ej1Var.ShamLDIR();
        defpackage.jt0 jt0Var = ej1Var.ShamLDIR.hyi5MRgVJpZU;
        return (zx0VarShamLDIR != null ? zx0VarShamLDIR.llsKPgWWJAw() : false) || jt0Var.m4CNag5J8Y(defpackage.ij1.AqsOwbEF) || jt0Var.m4CNag5J8Y(defpackage.ij1.acT0gEliM);
    }

    public static final void KImmPBu5u(java.lang.String str, boolean z, defpackage.o30 o30Var, defpackage.io0 io0Var, defpackage.h60 h60Var, int i) {
        defpackage.h60 h60Var2;
        h60Var.vkFkPUN4(-1496322287);
        int i2 = i | (h60Var.bGtyfE77Qpby(str) ? 4 : 2) | (h60Var.AdtkbTq73SIl(z) ? 32 : 16) | (h60Var.KImmPBu5u(o30Var) ? 256 : 128) | (h60Var.bGtyfE77Qpby(io0Var) ? 2048 : 1024);
        if (h60Var.eMSp92M2t(i2 & 1, (i2 & 1171) != 1170)) {
            defpackage.jf1 jf1Var = defpackage.kf1.CGnIndwjik9;
            defpackage.w21 w21Var = new defpackage.w21(50.0f);
            defpackage.jf1 jf1Var2 = new defpackage.jf1(w21Var, w21Var, w21Var, w21Var);
            defpackage.io0 io0VarHwJeYkFOwb2F = defpackage.yr.hwJeYkFOwb2F(defpackage.f12.acT0gEliM(defpackage.f12.ybb6jpEh(defpackage.yr.xy7yDq1ZM(defpackage.f12.AqsOwbEF(io0Var, jf1Var2), z ? defpackage.q11.AdtkbTq73SIl : defpackage.ij.hyi5MRgVJpZU, defpackage.fc0.AdtkbTq73SIl), 1.0f, defpackage.q11.AdtkbTq73SIl, jf1Var2), false, o30Var, 15), 0.0f, 10.0f);
            defpackage.pn0 pn0VarM4CNag5J8Y = defpackage.oe.m4CNag5J8Y(defpackage.kl1.SOLzqtJLiD8g, false);
            int iHashCode = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var, io0VarHwJeYkFOwb2F);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(defpackage.bm.hyi5MRgVJpZU, h60Var, pn0VarM4CNag5J8Y);
            defpackage.j20.eMSp92M2t(defpackage.bm.ShamLDIR, h60Var, y21VarTs5Bfxu7gi);
            defpackage.j20.eMSp92M2t(defpackage.bm.bGtyfE77Qpby, h60Var, java.lang.Integer.valueOf(iHashCode));
            defpackage.j20.QTXOIjVJtE(h60Var, defpackage.bm.AdtkbTq73SIl);
            defpackage.j20.eMSp92M2t(defpackage.bm.m4CNag5J8Y, h60Var, io0VarZsS39c8E7oY);
            defpackage.gr1.wk61Lrtj(str, null, z ? defpackage.q11.CGnIndwjik9 : defpackage.q11.ShamLDIR, 0L, null, 0L, null, 0L, 0, false, 1, 0, ((defpackage.su1) h60Var.O21Gh3JCO74(defpackage.uu1.CGnIndwjik9)).ybb6jpEh, h60Var, i2 & 14, 24576, 114682);
            h60Var2 = h60Var;
            h60Var2.acT0gEliM(true);
        } else {
            h60Var2 = h60Var;
            h60Var2.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var2.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.w80(str, z, o30Var, io0Var, i, 0);
        }
    }

    public static final boolean LQkLH9RtdoX(long j, long j2) {
        return j == j2;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0054  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final boolean M80ht0VsJ(defpackage.ej1 ej1Var) {
        if (!JcNBqlq8RG(ej1Var)) {
            defpackage.zi1 zi1Var = ej1Var.ShamLDIR;
            if (zi1Var.AdtkbTq73SIl) {
                return true;
            }
            defpackage.jt0 jt0Var = zi1Var.hyi5MRgVJpZU;
            java.lang.Object[] objArr = jt0Var.wk61Lrtj;
            java.lang.Object[] objArr2 = jt0Var.m4CNag5J8Y;
            long[] jArr = jt0Var.CGnIndwjik9;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i = 0;
                while (true) {
                    long j = jArr[i];
                    if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i2 = 8 - ((~(i - length)) >>> 31);
                        for (int i3 = 0; i3 < i2; i3++) {
                            if ((255 & j) < 128) {
                                int i4 = (i << 3) + i3;
                                java.lang.Object obj = objArr[i4];
                                java.lang.Object obj2 = objArr2[i4];
                                if (((defpackage.lj1) obj).m4CNag5J8Y) {
                                    return true;
                                }
                            }
                            j >>= 8;
                        }
                        if (i2 != 8) {
                            break;
                        }
                        if (i == length) {
                            break;
                        }
                        i++;
                    }
                }
            }
        }
        return false;
    }

    public static final void O21Gh3JCO74(defpackage.o30 o30Var, defpackage.io0 io0Var, defpackage.pk1 pk1Var, defpackage.uf ufVar, defpackage.ge geVar, defpackage.j11 j11Var, defpackage.hl hlVar, defpackage.h60 h60Var, int i) {
        int i2;
        h60Var.vkFkPUN4(399974542);
        if ((i & 6) == 0) {
            i2 = (h60Var.KImmPBu5u(o30Var) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= h60Var.bGtyfE77Qpby(io0Var) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= h60Var.AdtkbTq73SIl(true) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= h60Var.bGtyfE77Qpby(pk1Var) ? 2048 : 1024;
        }
        if ((i & 24576) == 0) {
            i2 |= h60Var.bGtyfE77Qpby(ufVar) ? 16384 : 8192;
        }
        int i3 = i2 | 196608;
        if ((1572864 & i) == 0) {
            i3 |= h60Var.bGtyfE77Qpby(geVar) ? 1048576 : 524288;
        }
        if ((12582912 & i) == 0) {
            i3 |= h60Var.bGtyfE77Qpby(j11Var) ? 8388608 : 4194304;
        }
        int i4 = i3 | 100663296;
        if ((805306368 & i) == 0) {
            i4 |= h60Var.KImmPBu5u(hlVar) ? 536870912 : 268435456;
        }
        if (h60Var.eMSp92M2t(i4 & 1, (306783379 & i4) != 306783378)) {
            h60Var.ZsS39c8E7oY();
            if ((i & 1) != 0 && !h60Var.EUGsszWpP4()) {
                h60Var.w9n6oNBhm();
            }
            h60Var.AqsOwbEF();
            ShamLDIR(o30Var, io0Var, true, pk1Var, ufVar, null, geVar, j11Var, hlVar, h60Var, i4 & 2147483646, 0);
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.ag(o30Var, io0Var, pk1Var, ufVar, geVar, j11Var, hlVar, i);
        }
    }

    public static final void PJFAWmtS(defpackage.z30 z30Var, defpackage.rm0 rm0Var, defpackage.rm0 rm0Var2, defpackage.us0 us0Var, defpackage.ej1 ej1Var, defpackage.ej1 ej1Var2) {
        defpackage.rm0 rm0Var3 = rm0Var;
        android.graphics.Region region = (android.graphics.Region) rm0Var3.bGtyfE77Qpby;
        defpackage.rm0 rm0Var4 = rm0Var2;
        android.graphics.Region region2 = (android.graphics.Region) rm0Var4.bGtyfE77Qpby;
        defpackage.af0 af0Var = ej1Var2.m4CNag5J8Y;
        defpackage.af0 af0Var2 = ej1Var2.m4CNag5J8Y;
        if (!af0Var.auXIgCKsG() || !af0Var2.xy7yDq1ZM() || region2.isEmpty()) {
            if (ej1Var2.oA3oVL3lY()) {
                BCxB3l2DENQ(us0Var, ej1Var, ej1Var2);
                return;
            }
            return;
        }
        defpackage.y71 y71VarYbb6jpEh = ej1Var2.ybb6jpEh();
        if ((y71VarYbb6jpEh.CGnIndwjik9 >= y71VarYbb6jpEh.m4CNag5J8Y) | (y71VarYbb6jpEh.wk61Lrtj >= y71VarYbb6jpEh.ShamLDIR)) {
            java.lang.Object objBGtyfE77Qpby = ej1Var2.bGtyfE77Qpby();
            if (objBGtyfE77Qpby == null) {
                defpackage.ua0 ua0Var = af0Var2.hfi1lqIFl.m4CNag5J8Y;
                y71VarYbb6jpEh = defpackage.j20.Wg7Cen3syT(ua0Var).MebIjqkiUJ(ua0Var, false);
            } else {
                defpackage.ho0 ho0Var = ((defpackage.ho0) objBGtyfE77Qpby).hyi5MRgVJpZU;
                java.lang.Object objAdtkbTq73SIl = ej1Var2.ShamLDIR.hyi5MRgVJpZU.AdtkbTq73SIl(defpackage.yi1.wk61Lrtj);
                if (objAdtkbTq73SIl == null) {
                    objAdtkbTq73SIl = null;
                }
                y71VarYbb6jpEh = defpackage.h10.KImmPBu5u(ho0Var, objAdtkbTq73SIl != null, false);
            }
        }
        defpackage.rb0 rb0VarMbwb7dCOYb = defpackage.i20.mbwb7dCOYb(y71VarYbb6jpEh);
        rm0Var3.KImmPBu5u(rb0VarMbwb7dCOYb);
        if (region.op(region2, android.graphics.Region.Op.INTERSECT)) {
            int i = ej1Var2.bGtyfE77Qpby;
            defpackage.ej1 ej1Var3 = ej1Var;
            if (i == ej1Var3.bGtyfE77Qpby) {
                i = -1;
            }
            android.graphics.Rect bounds = region.getBounds();
            defpackage.gj1 gj1Var = new defpackage.gj1(ej1Var2, new defpackage.rb0(bounds.left, bounds.top, bounds.right, bounds.bottom));
            defpackage.us0 us0Var2 = us0Var;
            us0Var2.KImmPBu5u(i, gj1Var);
            java.util.List listO21Gh3JCO74 = defpackage.ej1.O21Gh3JCO74(4, ej1Var2);
            int size = listO21Gh3JCO74.size() - 1;
            while (-1 < size) {
                if (!((java.lang.Boolean) z30Var.KImmPBu5u(listO21Gh3JCO74.get(size))).booleanValue()) {
                    PJFAWmtS(z30Var, rm0Var3, rm0Var4, us0Var2, ej1Var3, (defpackage.ej1) listO21Gh3JCO74.get(size));
                }
                size--;
                rm0Var3 = rm0Var;
                rm0Var4 = rm0Var2;
                us0Var2 = us0Var;
                ej1Var3 = ej1Var;
            }
            if (M80ht0VsJ(ej1Var2)) {
                region2.op(rb0VarMbwb7dCOYb.CGnIndwjik9, rb0VarMbwb7dCOYb.wk61Lrtj, rb0VarMbwb7dCOYb.m4CNag5J8Y, rb0VarMbwb7dCOYb.ShamLDIR, android.graphics.Region.Op.DIFFERENCE);
            }
        }
    }

    public static final void Q23EIYzrs(java.lang.String str, long j) {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            android.os.Trace.setCounter(str, j);
        }
    }

    public static java.lang.String QTXOIjVJtE(int i) {
        return i == 0 ? "Clear" : i == 1 ? "Src" : i == 2 ? "Dst" : i == 3 ? "SrcOver" : i == 4 ? "DstOver" : i == 5 ? "SrcIn" : i == 6 ? "DstIn" : i == 7 ? "SrcOut" : i == 8 ? "DstOut" : i == 9 ? "SrcAtop" : i == 10 ? "DstAtop" : i == 11 ? "Xor" : i == 12 ? "Plus" : i == 13 ? "Modulate" : i == 14 ? "Screen" : i == 15 ? "Overlay" : i == 16 ? "Darken" : i == 17 ? "Lighten" : i == 18 ? "ColorDodge" : i == 19 ? "ColorBurn" : i == 20 ? "HardLight" : i == 21 ? "Softlight" : i == 22 ? "Difference" : i == 23 ? "Exclusion" : i == 24 ? "Multiply" : i == 25 ? "Hue" : i == 26 ? "Saturation" : i == 27 ? "Color" : i == 28 ? "Luminosity" : "Unknown";
    }

    public static final void SOLzqtJLiD8g(defpackage.x41 x41Var, defpackage.z30 z30Var, defpackage.o30 o30Var, defpackage.h60 h60Var, int i) {
        int i2;
        defpackage.z30 z30Var2;
        defpackage.o30 o30Var2;
        defpackage.kh1 kh1Var;
        boolean z;
        h60Var.vkFkPUN4(1669046613);
        int i3 = i | (h60Var.KImmPBu5u(x41Var) ? 4 : 2) | (h60Var.KImmPBu5u(z30Var) ? 32 : 16) | (h60Var.KImmPBu5u(o30Var) ? 256 : 128);
        if (h60Var.eMSp92M2t(i3 & 1, (i3 & 147) != 146)) {
            defpackage.zd zdVar = x41Var.wk61Lrtj;
            defpackage.nj0 nj0Var = zdVar.CGnIndwjik9;
            boolean z2 = x41Var.m4CNag5J8Y;
            java.lang.String str = x41Var.hyi5MRgVJpZU;
            defpackage.uw uwVar = defpackage.uu1.CGnIndwjik9;
            defpackage.vr1 vr1Var = ((defpackage.su1) h60Var.O21Gh3JCO74(uwVar)).SOLzqtJLiD8g;
            long j = defpackage.q11.ShamLDIR;
            defpackage.d00 d00Var = defpackage.l.oA3oVL3lY;
            defpackage.gr1.wk61Lrtj(str, d00Var, j, 0L, null, 0L, new defpackage.uq1(3), 0L, 0, false, 0, 0, vr1Var, h60Var, 432, 0, 130040);
            defpackage.of1 of1VarCGnIndwjik9 = defpackage.nf1.CGnIndwjik9(defpackage.f12.ShamLDIR, defpackage.kl1.acT0gEliM, h60Var, 6);
            int iHashCode = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var, d00Var);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(defpackage.bm.hyi5MRgVJpZU, h60Var, of1VarCGnIndwjik9);
            defpackage.j20.eMSp92M2t(defpackage.bm.ShamLDIR, h60Var, y21VarTs5Bfxu7gi);
            defpackage.j20.eMSp92M2t(defpackage.bm.bGtyfE77Qpby, h60Var, java.lang.Integer.valueOf(iHashCode));
            defpackage.j20.QTXOIjVJtE(h60Var, defpackage.bm.AdtkbTq73SIl);
            defpackage.j20.eMSp92M2t(defpackage.bm.m4CNag5J8Y, h60Var, io0VarZsS39c8E7oY);
            java.lang.String strEX2ajLj518q3 = defpackage.n51.EX2ajLj518q3("Pages ", nj0Var.CGnIndwjik9() - zdVar.AdtkbTq73SIl, "/", nj0Var.CGnIndwjik9());
            defpackage.vr1 vr1Var2 = ((defpackage.su1) h60Var.O21Gh3JCO74(uwVar)).oA3oVL3lY;
            long j2 = defpackage.q11.hyi5MRgVJpZU;
            defpackage.gr1.wk61Lrtj(strEX2ajLj518q3, null, j2, 0L, null, 0L, null, 0L, 0, false, 0, 0, vr1Var2, h60Var, 384, 0, 131066);
            defpackage.gr1.wk61Lrtj(defpackage.n51.AdtkbTq73SIl("Candle ", zdVar.KImmPBu5u), null, j2, 0L, null, 0L, null, 0L, 0, false, 0, 0, ((defpackage.su1) h60Var.O21Gh3JCO74(uwVar)).oA3oVL3lY, h60Var, 384, 0, 131066);
            defpackage.gr1.wk61Lrtj(defpackage.n51.AdtkbTq73SIl("Setbacks ", x41Var.ShamLDIR), null, j2, 0L, null, 0L, null, 0L, 0, false, 0, 0, ((defpackage.su1) h60Var.O21Gh3JCO74(uwVar)).oA3oVL3lY, h60Var, 384, 0, 131066);
            h60Var.acT0gEliM(true);
            z30Var2 = z30Var;
            defpackage.l.CGnIndwjik9(d00Var, defpackage.kl1.SOLzqtJLiD8g, defpackage.fc0.hfi1lqIFl(959051455, new defpackage.cj0(3, zdVar, z30Var2), h60Var), h60Var, 3126, 4);
            int i4 = i3 & 112;
            boolean z3 = i4 == 32;
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            defpackage.kh1 kh1Var2 = defpackage.im.CGnIndwjik9;
            if (z3 || objCO8Wxv6r == kh1Var2) {
                objCO8Wxv6r = new defpackage.zk(z30Var2, 4);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r);
            }
            defpackage.z30 z30Var3 = (defpackage.z30) objCO8Wxv6r;
            boolean z4 = i4 == 32;
            java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
            if (z4 || objCO8Wxv6r2 == kh1Var2) {
                objCO8Wxv6r2 = new defpackage.pq(z30Var2, 6);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r2);
            }
            defpackage.ec0.hyi5MRgVJpZU(z30Var3, (defpackage.o30) objCO8Wxv6r2, d00Var, 50.0f, !z2, h60Var, 3456, 0);
            defpackage.i20.hyi5MRgVJpZU(h60Var, defpackage.l.JcNBqlq8RG(defpackage.fo0.CGnIndwjik9, 4.0f));
            if (z2) {
                h60Var.hwJeYkFOwb2F(-266995149);
                i2 = i;
                kh1Var = kh1Var2;
                defpackage.yr.PJFAWmtS("Begin a real journey", o30Var, d00Var, null, false, h60Var, ((i3 >> 3) & 112) | 390, 24);
                o30Var2 = o30Var;
                z = false;
            } else {
                o30Var2 = o30Var;
                i2 = i;
                kh1Var = kh1Var2;
                z = false;
                h60Var.hwJeYkFOwb2F(-278887059);
            }
            h60Var.acT0gEliM(z);
            boolean z5 = i4 == 32 ? true : z;
            java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
            if (z5 || objCO8Wxv6r3 == kh1Var) {
                objCO8Wxv6r3 = new defpackage.pq(z30Var2, 7);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r3);
            }
            defpackage.yr.PJFAWmtS("Restart practice", (defpackage.o30) objCO8Wxv6r3, d00Var, defpackage.zf.AdtkbTq73SIl, false, h60Var, 3462, 16);
        } else {
            i2 = i;
            z30Var2 = z30Var;
            o30Var2 = o30Var;
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.l50(x41Var, z30Var2, o30Var2, i2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:178:0x02fb  */
    /* JADX WARN: Removed duplicated region for block: B:181:0x0308  */
    /* JADX WARN: Removed duplicated region for block: B:183:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x00f8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ShamLDIR(defpackage.o30 o30Var, defpackage.io0 io0Var, boolean z, defpackage.pk1 pk1Var, defpackage.uf ufVar, defpackage.yf yfVar, defpackage.ge geVar, defpackage.j11 j11Var, defpackage.hl hlVar, defpackage.h60 h60Var, int i, int i2) {
        int i3;
        defpackage.yf yfVar2;
        defpackage.h60 h60Var2;
        defpackage.ge geVar2;
        defpackage.yf yfVar3;
        defpackage.o71 o71VarCAUonbdEve;
        defpackage.ge geVar3;
        defpackage.h60 h60Var3;
        defpackage.ws0 ws0Var;
        defpackage.kh1 kh1Var;
        long j;
        boolean z2;
        defpackage.yf yfVar4;
        defpackage.g3 g3Var;
        h60Var.vkFkPUN4(-1310015664);
        if ((i & 6) == 0) {
            i3 = (h60Var.KImmPBu5u(o30Var) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= h60Var.bGtyfE77Qpby(io0Var) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= h60Var.AdtkbTq73SIl(z) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= h60Var.bGtyfE77Qpby(pk1Var) ? 2048 : 1024;
        }
        if ((i & 24576) == 0) {
            i3 |= h60Var.bGtyfE77Qpby(ufVar) ? 16384 : 8192;
        }
        if ((196608 & i) == 0) {
            if ((i2 & 32) == 0) {
                yfVar2 = yfVar;
                int i4 = h60Var.bGtyfE77Qpby(yfVar2) ? 131072 : 65536;
                i3 |= i4;
            } else {
                yfVar2 = yfVar;
            }
            i3 |= i4;
        } else {
            yfVar2 = yfVar;
        }
        int i5 = i2 & 64;
        if (i5 == 0) {
            if ((1572864 & i) == 0) {
                i3 |= h60Var.bGtyfE77Qpby(geVar) ? 1048576 : 524288;
            }
            if ((i & 12582912) == 0) {
                i3 |= h60Var.bGtyfE77Qpby(j11Var) ? 8388608 : 4194304;
            }
            if ((i2 & 256) == 0) {
                i3 |= 100663296;
            } else if ((i & 100663296) == 0) {
                i3 |= h60Var.bGtyfE77Qpby(null) ? 67108864 : 33554432;
            }
            if ((805306368 & i) == 0) {
                i3 |= h60Var.KImmPBu5u(hlVar) ? 536870912 : 268435456;
            }
            boolean z3 = true;
            if (h60Var.eMSp92M2t(i3 & 1, (306783379 & i3) == 306783378)) {
                h60Var2 = h60Var;
                h60Var2.w9n6oNBhm();
                geVar2 = geVar;
                yfVar3 = yfVar2;
            } else {
                h60Var.ZsS39c8E7oY();
                if ((i & 1) == 0 || h60Var.EUGsszWpP4()) {
                    if ((i2 & 32) != 0) {
                        defpackage.l11 l11Var = defpackage.vf.CGnIndwjik9;
                        yfVar2 = new defpackage.yf(defpackage.f12.oA3oVL3lY);
                        i3 &= -458753;
                    }
                    geVar3 = i5 != 0 ? null : geVar;
                } else {
                    h60Var.w9n6oNBhm();
                    if ((i2 & 32) != 0) {
                        i3 &= -458753;
                    }
                    geVar3 = geVar;
                }
                defpackage.yf yfVar5 = yfVar2;
                h60Var.AqsOwbEF();
                h60Var.hwJeYkFOwb2F(1691738187);
                java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
                defpackage.kh1 kh1Var2 = defpackage.im.CGnIndwjik9;
                if (objCO8Wxv6r == kh1Var2) {
                    objCO8Wxv6r = new defpackage.ws0();
                    h60Var.XEWVqqb5t6J(objCO8Wxv6r);
                }
                defpackage.ws0 ws0Var2 = (defpackage.ws0) objCO8Wxv6r;
                h60Var.acT0gEliM(false);
                long j2 = z ? ufVar.CGnIndwjik9 : ufVar.m4CNag5J8Y;
                long j3 = z ? ufVar.wk61Lrtj : ufVar.ShamLDIR;
                if (yfVar5 == null) {
                    h60Var3 = h60Var;
                    h60Var3.hwJeYkFOwb2F(1691921830);
                    h60Var3.acT0gEliM(false);
                    j = j3;
                    ws0Var = ws0Var2;
                    kh1Var = kh1Var2;
                    yfVar4 = yfVar5;
                    z2 = false;
                    g3Var = null;
                } else {
                    h60Var3 = h60Var;
                    h60Var3.hwJeYkFOwb2F(-499611205);
                    int i6 = ((i3 >> 9) & 896) | ((i3 >> 6) & 14);
                    java.lang.Object objCO8Wxv6r2 = h60Var3.CO8Wxv6r();
                    if (objCO8Wxv6r2 == kh1Var2) {
                        objCO8Wxv6r2 = new defpackage.dn1();
                        h60Var3.XEWVqqb5t6J(objCO8Wxv6r2);
                    }
                    defpackage.dn1 dn1Var = (defpackage.dn1) objCO8Wxv6r2;
                    boolean zBGtyfE77Qpby = h60Var3.bGtyfE77Qpby(ws0Var2);
                    java.lang.Object objCO8Wxv6r3 = h60Var3.CO8Wxv6r();
                    if (zBGtyfE77Qpby || objCO8Wxv6r3 == kh1Var2) {
                        objCO8Wxv6r3 = new defpackage.ShamLDIR(ws0Var2, dn1Var, null, 3);
                        h60Var3.XEWVqqb5t6J(objCO8Wxv6r3);
                    }
                    defpackage.fc0.SOLzqtJLiD8g((defpackage.d40) objCO8Wxv6r3, h60Var3, ws0Var2);
                    defpackage.wb0 wb0Var = (defpackage.wb0) defpackage.bj.NlyAKJE3Icp(dn1Var);
                    float f = (z && !(wb0Var instanceof defpackage.w51) && (wb0Var instanceof defpackage.t80)) ? yfVar5.CGnIndwjik9 : 0.0f;
                    java.lang.Object objCO8Wxv6r4 = h60Var3.CO8Wxv6r();
                    if (objCO8Wxv6r4 == kh1Var2) {
                        ws0Var = ws0Var2;
                        objCO8Wxv6r4 = new defpackage.b2(new defpackage.hv(f), defpackage.ec0.cAUonbdEve, null, 12);
                        h60Var3.XEWVqqb5t6J(objCO8Wxv6r4);
                    } else {
                        ws0Var = ws0Var2;
                    }
                    defpackage.b2 b2Var = (defpackage.b2) objCO8Wxv6r4;
                    defpackage.hv hvVar = new defpackage.hv(f);
                    boolean zKImmPBu5u = h60Var3.KImmPBu5u(b2Var) | h60Var3.m4CNag5J8Y(f) | ((((i6 & 14) ^ 6) > 4 && h60Var3.AdtkbTq73SIl(z)) || (i6 & 6) == 4);
                    if ((((i6 & 896) ^ 384) <= 256 || !h60Var3.bGtyfE77Qpby(yfVar5)) && (i6 & 384) != 256) {
                        z3 = false;
                    }
                    boolean zKImmPBu5u2 = zKImmPBu5u | z3 | h60Var3.KImmPBu5u(wb0Var);
                    java.lang.Object objCO8Wxv6r5 = h60Var3.CO8Wxv6r();
                    if (zKImmPBu5u2 || objCO8Wxv6r5 == kh1Var2) {
                        float f2 = f;
                        kh1Var = kh1Var2;
                        j = j3;
                        z2 = false;
                        defpackage.xf xfVar = new defpackage.xf(b2Var, f2, z, yfVar5, wb0Var, null);
                        yfVar4 = yfVar5;
                        h60Var3.XEWVqqb5t6J(xfVar);
                        objCO8Wxv6r5 = xfVar;
                    } else {
                        j = j3;
                        kh1Var = kh1Var2;
                        yfVar4 = yfVar5;
                        z2 = false;
                    }
                    defpackage.fc0.SOLzqtJLiD8g((defpackage.d40) objCO8Wxv6r5, h60Var3, hvVar);
                    g3Var = b2Var.m4CNag5J8Y;
                    h60Var3.acT0gEliM(z2);
                }
                float f3 = g3Var != null ? ((defpackage.hv) g3Var.bGtyfE77Qpby.getValue()).hyi5MRgVJpZU : 0.0f;
                java.lang.Object objCO8Wxv6r6 = h60Var3.CO8Wxv6r();
                if (objCO8Wxv6r6 == kh1Var) {
                    objCO8Wxv6r6 = new defpackage.z3(14);
                    h60Var3.XEWVqqb5t6J(objCO8Wxv6r6);
                }
                defpackage.io0 io0VarCGnIndwjik9 = defpackage.bj1.CGnIndwjik9(io0Var, (defpackage.z30) objCO8Wxv6r6);
                defpackage.hl hlVarHfi1lqIFl = defpackage.fc0.hfi1lqIFl(-535639973, new defpackage.eg(j, j11Var, hlVar), h60Var3);
                defpackage.uw uwVar = defpackage.yp1.CGnIndwjik9;
                if (ws0Var == null) {
                    h60Var3.hwJeYkFOwb2F(-1701037204);
                    java.lang.Object objCO8Wxv6r7 = h60Var3.CO8Wxv6r();
                    if (objCO8Wxv6r7 == kh1Var) {
                        objCO8Wxv6r7 = new defpackage.ws0();
                        h60Var3.XEWVqqb5t6J(objCO8Wxv6r7);
                    }
                    h60Var3.acT0gEliM(z2);
                    ws0Var = (defpackage.ws0) objCO8Wxv6r7;
                } else {
                    h60Var3.hwJeYkFOwb2F(2023337163);
                    h60Var3.acT0gEliM(z2);
                }
                defpackage.uw uwVar2 = defpackage.yp1.CGnIndwjik9;
                float f4 = ((defpackage.hv) h60Var3.O21Gh3JCO74(uwVar2)).hyi5MRgVJpZU + 0.0f;
                h60Var2 = h60Var3;
                defpackage.ge geVar4 = geVar3;
                defpackage.fc0.AdtkbTq73SIl(new defpackage.c71[]{defpackage.tn.CGnIndwjik9.CGnIndwjik9(new defpackage.ij(j)), uwVar2.CGnIndwjik9(new defpackage.hv(f4))}, defpackage.fc0.hfi1lqIFl(849208527, new defpackage.xp1(io0VarCGnIndwjik9, pk1Var, j2, f4, geVar4, ws0Var, z, o30Var, f3, hlVarHfi1lqIFl), h60Var2), h60Var2, 56);
                geVar2 = geVar4;
                yfVar3 = yfVar4;
            }
            o71VarCAUonbdEve = h60Var2.cAUonbdEve();
            if (o71VarCAUonbdEve == null) {
                o71VarCAUonbdEve.ShamLDIR = new defpackage.bg(o30Var, io0Var, z, pk1Var, ufVar, yfVar3, geVar2, j11Var, hlVar, i, i2);
                return;
            }
            return;
        }
        i3 |= 1572864;
        if ((i & 12582912) == 0) {
        }
        if ((i2 & 256) == 0) {
        }
        if ((805306368 & i) == 0) {
        }
        boolean z32 = true;
        if (h60Var.eMSp92M2t(i3 & 1, (306783379 & i3) == 306783378)) {
        }
        o71VarCAUonbdEve = h60Var2.cAUonbdEve();
        if (o71VarCAUonbdEve == null) {
        }
    }

    public static final void Ts5Bfxu7gi(java.lang.String str, java.lang.String str2, defpackage.h60 h60Var, int i) {
        int i2;
        java.lang.String str3 = str2;
        defpackage.h60 h60Var2 = h60Var;
        h60Var2.vkFkPUN4(-964176688);
        if ((i & 48) == 0) {
            i2 = i | (h60Var2.bGtyfE77Qpby(str3) ? 32 : 16);
        } else {
            i2 = i;
        }
        if (h60Var2.eMSp92M2t(i2 & 1, (i2 & 19) != 18)) {
            defpackage.io0 io0VarHwJeYkFOwb2F = defpackage.yr.hwJeYkFOwb2F(defpackage.l.oA3oVL3lY, 0.0f, 3.0f);
            defpackage.of1 of1VarCGnIndwjik9 = defpackage.nf1.CGnIndwjik9(defpackage.f12.CGnIndwjik9, defpackage.kl1.acT0gEliM, h60Var2, 0);
            int iHashCode = java.lang.Long.hashCode(h60Var2.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var2.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var2, io0VarHwJeYkFOwb2F);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            h60Var2.ixcZHu7WE();
            if (h60Var2.BWtb0lBv) {
                h60Var2.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var2.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(defpackage.bm.hyi5MRgVJpZU, h60Var2, of1VarCGnIndwjik9);
            defpackage.j20.eMSp92M2t(defpackage.bm.ShamLDIR, h60Var2, y21VarTs5Bfxu7gi);
            defpackage.j20.eMSp92M2t(defpackage.bm.bGtyfE77Qpby, h60Var2, java.lang.Integer.valueOf(iHashCode));
            defpackage.j20.QTXOIjVJtE(h60Var2, defpackage.bm.AdtkbTq73SIl);
            defpackage.j20.eMSp92M2t(defpackage.bm.m4CNag5J8Y, h60Var2, io0VarZsS39c8E7oY);
            defpackage.uw uwVar = defpackage.uu1.CGnIndwjik9;
            defpackage.gr1.wk61Lrtj(str, new defpackage.pf0(1.0f, true), defpackage.q11.hyi5MRgVJpZU, 0L, null, 0L, null, 0L, 0, false, 0, 0, ((defpackage.su1) h60Var2.O21Gh3JCO74(uwVar)).SOLzqtJLiD8g, h60Var2, 390, 0, 131064);
            str3 = str2;
            defpackage.gr1.wk61Lrtj(str3, null, defpackage.q11.ShamLDIR, 0L, defpackage.g30.O21Gh3JCO74, 0L, new defpackage.uq1(6), 0L, 0, false, 0, 0, ((defpackage.su1) h60Var2.O21Gh3JCO74(uwVar)).SOLzqtJLiD8g, h60Var, ((i2 >> 3) & 14) | 1573248, 0, 129978);
            h60Var2 = h60Var;
            h60Var2.acT0gEliM(true);
        } else {
            h60Var2.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var2.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.ah(i, 5, str, str3);
        }
    }

    public static final void Wg7Cen3syT(long j, defpackage.u01 u01Var) {
        if (u01Var == defpackage.u01.hyi5MRgVJpZU) {
            if (defpackage.kn.AdtkbTq73SIl(j) != Integer.MAX_VALUE) {
                return;
            }
            defpackage.ra0.m4CNag5J8Y("Vertically scrollable component was measured with an infinity maximum height constraints, which is disallowed. One of the common reasons is nesting layouts like LazyColumn and Column(Modifier.verticalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyColumn scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        } else {
            if (defpackage.kn.KImmPBu5u(j) != Integer.MAX_VALUE) {
                return;
            }
            defpackage.ra0.m4CNag5J8Y("Horizontally scrollable component was measured with an infinity maximum width constraints, which is disallowed. One of the common reasons is nesting layouts like LazyRow and Row(Modifier.horizontalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyRow scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        }
    }

    public static final void X2zla1VHV(defpackage.mo moVar, java.lang.Throwable th) {
        java.lang.Throwable runtimeException;
        java.util.Iterator it = defpackage.qo.CGnIndwjik9.iterator();
        while (it.hasNext()) {
            try {
                ((defpackage.po) it.next()).ybb6jpEh(moVar, th);
            } catch (java.lang.Throwable th2) {
                if (th == th2) {
                    runtimeException = th;
                } else {
                    runtimeException = new java.lang.RuntimeException("Exception while trying to handle coroutine exception", th2);
                    defpackage.f12.SOLzqtJLiD8g(runtimeException, th);
                }
                java.lang.Thread threadCurrentThread = java.lang.Thread.currentThread();
                threadCurrentThread.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread, runtimeException);
            }
        }
        try {
            defpackage.f12.SOLzqtJLiD8g(th, new defpackage.au(moVar));
        } catch (java.lang.Throwable unused) {
        }
        java.lang.Thread threadCurrentThread2 = java.lang.Thread.currentThread();
        threadCurrentThread2.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread2, th);
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00c4  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0159  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void X9gUlnc07R(defpackage.z30 z30Var, defpackage.rm0 rm0Var, defpackage.rm0 rm0Var2, defpackage.us0 us0Var, defpackage.ej1 ej1Var, defpackage.ej1 ej1Var2) {
        boolean z;
        defpackage.y71 y71VarKImmPBu5u;
        defpackage.zx0 zx0VarShamLDIR;
        defpackage.z30 z30Var2 = z30Var;
        defpackage.ej1 ej1Var3 = ej1Var;
        int i = ej1Var3.bGtyfE77Qpby;
        android.graphics.Region region = (android.graphics.Region) rm0Var.bGtyfE77Qpby;
        defpackage.rm0 rm0Var3 = rm0Var2;
        android.graphics.Region region2 = (android.graphics.Region) rm0Var3.bGtyfE77Qpby;
        defpackage.af0 af0Var = ej1Var2.m4CNag5J8Y;
        defpackage.zi1 zi1Var = ej1Var2.ShamLDIR;
        defpackage.af0 af0Var2 = ej1Var2.m4CNag5J8Y;
        int i2 = ej1Var2.bGtyfE77Qpby;
        boolean z2 = (af0Var.auXIgCKsG() && af0Var2.xy7yDq1ZM()) ? false : true;
        if (!region2.isEmpty() || i2 == i) {
            if (!z2 || ej1Var2.oA3oVL3lY()) {
                defpackage.rb0 rb0VarMbwb7dCOYb = defpackage.i20.mbwb7dCOYb(ej1Var2.ybb6jpEh());
                rm0Var.KImmPBu5u(rb0VarMbwb7dCOYb);
                if (i2 == i) {
                    i2 = -1;
                }
                if (!region.op(region2, android.graphics.Region.Op.INTERSECT)) {
                    if (ej1Var2.oA3oVL3lY()) {
                        BCxB3l2DENQ(us0Var, ej1Var, ej1Var2);
                        return;
                    } else {
                        if (i2 == -1) {
                            android.graphics.Rect bounds = region.getBounds();
                            us0Var.KImmPBu5u(i2, new defpackage.gj1(ej1Var2, new defpackage.rb0(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                            return;
                        }
                        return;
                    }
                }
                android.graphics.Rect bounds2 = region.getBounds();
                us0Var.KImmPBu5u(i2, new defpackage.gj1(ej1Var2, new defpackage.rb0(bounds2.left, bounds2.top, bounds2.right, bounds2.bottom)));
                java.util.List listO21Gh3JCO74 = defpackage.ej1.O21Gh3JCO74(4, ej1Var2);
                if (zi1Var.AdtkbTq73SIl) {
                    defpackage.ej1 ej1VarTs5Bfxu7gi = ej1Var2.Ts5Bfxu7gi();
                    while (true) {
                        if (ej1VarTs5Bfxu7gi == null) {
                            ej1VarTs5Bfxu7gi = null;
                            break;
                        }
                        defpackage.jt0 jt0Var = ej1VarTs5Bfxu7gi.ShamLDIR.hyi5MRgVJpZU;
                        if (jt0Var.m4CNag5J8Y(defpackage.ij1.X9gUlnc07R) || jt0Var.m4CNag5J8Y(defpackage.ij1.BCxB3l2DENQ)) {
                            break;
                        } else {
                            ej1VarTs5Bfxu7gi = ej1VarTs5Bfxu7gi.Ts5Bfxu7gi();
                        }
                    }
                    if (ej1VarTs5Bfxu7gi == null) {
                        z = false;
                        if (z) {
                            defpackage.rm0 rm0Var4 = new defpackage.rm0(16);
                            java.lang.Object objBGtyfE77Qpby = ej1Var2.bGtyfE77Qpby();
                            if (objBGtyfE77Qpby == null) {
                                defpackage.ua0 ua0Var = af0Var2.hfi1lqIFl.m4CNag5J8Y;
                                y71VarKImmPBu5u = defpackage.j20.Wg7Cen3syT(ua0Var).MebIjqkiUJ(ua0Var, false);
                            } else {
                                defpackage.ho0 ho0Var = ((defpackage.ho0) objBGtyfE77Qpby).hyi5MRgVJpZU;
                                java.lang.Object objAdtkbTq73SIl = zi1Var.hyi5MRgVJpZU.AdtkbTq73SIl(defpackage.yi1.wk61Lrtj);
                                y71VarKImmPBu5u = defpackage.h10.KImmPBu5u(ho0Var, (objAdtkbTq73SIl == null ? null : objAdtkbTq73SIl) != null, false);
                            }
                            rm0Var4.KImmPBu5u(defpackage.i20.mbwb7dCOYb(y71VarKImmPBu5u));
                            int size = listO21Gh3JCO74.size() - 1;
                            while (-1 < size) {
                                if (!((java.lang.Boolean) z30Var2.KImmPBu5u(listO21Gh3JCO74.get(size))).booleanValue()) {
                                    PJFAWmtS(z30Var2, new defpackage.rm0(16), rm0Var4, us0Var, ej1Var3, (defpackage.ej1) listO21Gh3JCO74.get(size));
                                }
                                size--;
                                ej1Var3 = ej1Var;
                            }
                        } else {
                            int size2 = listO21Gh3JCO74.size() - 1;
                            while (-1 < size2) {
                                if (!((java.lang.Boolean) z30Var2.KImmPBu5u(listO21Gh3JCO74.get(size2))).booleanValue()) {
                                    X9gUlnc07R(z30Var2, rm0Var, rm0Var3, us0Var, ej1Var, (defpackage.ej1) listO21Gh3JCO74.get(size2));
                                }
                                size2--;
                                z30Var2 = z30Var;
                                rm0Var3 = rm0Var2;
                            }
                        }
                    } else {
                        defpackage.zx0 zx0VarShamLDIR2 = ej1Var2.ShamLDIR();
                        if (zx0VarShamLDIR2 == null) {
                            zx0VarShamLDIR2 = null;
                            zx0VarShamLDIR = ej1VarTs5Bfxu7gi.ShamLDIR();
                            if (zx0VarShamLDIR == null) {
                                zx0VarShamLDIR = null;
                                if (zx0VarShamLDIR2 == null && zx0VarShamLDIR != null) {
                                    defpackage.y71 y71VarMebIjqkiUJ = zx0VarShamLDIR.MebIjqkiUJ(zx0VarShamLDIR2, false);
                                    z = !y71VarMebIjqkiUJ.equals(y71VarMebIjqkiUJ.m4CNag5J8Y(defpackage.i20.m4CNag5J8Y(0L, defpackage.j20.hwJeYkFOwb2F(zx0VarShamLDIR.AdtkbTq73SIl))));
                                }
                                if (z) {
                                }
                            } else {
                                if (!zx0VarShamLDIR.oPZmPu1Bx().cAUonbdEve) {
                                    zx0VarShamLDIR = null;
                                }
                                if (zx0VarShamLDIR == null) {
                                }
                                if (zx0VarShamLDIR2 == null) {
                                    z = false;
                                    if (z) {
                                    }
                                }
                            }
                        } else {
                            if (!zx0VarShamLDIR2.oPZmPu1Bx().cAUonbdEve) {
                                zx0VarShamLDIR2 = null;
                            }
                            if (zx0VarShamLDIR2 == null) {
                            }
                            zx0VarShamLDIR = ej1VarTs5Bfxu7gi.ShamLDIR();
                            if (zx0VarShamLDIR == null) {
                            }
                        }
                    }
                }
                if (M80ht0VsJ(ej1Var2)) {
                    region2.op(rb0VarMbwb7dCOYb.CGnIndwjik9, rb0VarMbwb7dCOYb.wk61Lrtj, rb0VarMbwb7dCOYb.m4CNag5J8Y, rb0VarMbwb7dCOYb.ShamLDIR, android.graphics.Region.Op.DIFFERENCE);
                }
            }
        }
    }

    public static final defpackage.ot0 acT0gEliM(defpackage.l71 l71Var, defpackage.h60 h60Var) {
        defpackage.yj0 yj0Var = (defpackage.yj0) h60Var.O21Gh3JCO74(defpackage.ll0.CGnIndwjik9);
        java.lang.Object value = l71Var.hyi5MRgVJpZU.getValue();
        defpackage.bk0 bk0VarAdtkbTq73SIl = yj0Var.AdtkbTq73SIl();
        defpackage.rj0 rj0Var = defpackage.rj0.KImmPBu5u;
        defpackage.cy cyVar = defpackage.cy.hyi5MRgVJpZU;
        java.lang.Object[] objArr = {l71Var, bk0VarAdtkbTq73SIl, rj0Var, cyVar};
        boolean zKImmPBu5u = h60Var.KImmPBu5u(bk0VarAdtkbTq73SIl) | h60Var.ShamLDIR(rj0Var.ordinal()) | h60Var.KImmPBu5u(cyVar) | h60Var.KImmPBu5u(l71Var);
        java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
        java.lang.Object obj = defpackage.im.CGnIndwjik9;
        if (zKImmPBu5u || objCO8Wxv6r == obj) {
            java.lang.Object yqVar = new defpackage.yq(bk0VarAdtkbTq73SIl, rj0Var, cyVar, l71Var, (defpackage.go) null);
            h60Var.XEWVqqb5t6J(yqVar);
            objCO8Wxv6r = yqVar;
        }
        defpackage.d40 d40Var = (defpackage.d40) objCO8Wxv6r;
        java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
        if (objCO8Wxv6r2 == obj) {
            objCO8Wxv6r2 = defpackage.d10.JcNBqlq8RG(value);
            h60Var.XEWVqqb5t6J(objCO8Wxv6r2);
        }
        defpackage.ot0 ot0Var = (defpackage.ot0) objCO8Wxv6r2;
        java.lang.Object[] objArrCopyOf = java.util.Arrays.copyOf(objArr, 4);
        boolean zKImmPBu5u2 = h60Var.KImmPBu5u(d40Var);
        java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
        if (zKImmPBu5u2 || objCO8Wxv6r3 == obj) {
            objCO8Wxv6r3 = new defpackage.bn1(d40Var, ot0Var, null, 1);
            h60Var.XEWVqqb5t6J(objCO8Wxv6r3);
        }
        defpackage.d40 d40Var2 = (defpackage.d40) objCO8Wxv6r3;
        defpackage.mo moVar = h60Var.w9n6oNBhm;
        boolean zBGtyfE77Qpby = false;
        for (java.lang.Object obj2 : java.util.Arrays.copyOf(objArrCopyOf, objArrCopyOf.length)) {
            zBGtyfE77Qpby |= h60Var.bGtyfE77Qpby(obj2);
        }
        java.lang.Object objCO8Wxv6r4 = h60Var.CO8Wxv6r();
        if (!zBGtyfE77Qpby && objCO8Wxv6r4 != obj) {
            return ot0Var;
        }
        h60Var.XEWVqqb5t6J(new defpackage.fe0(moVar, d40Var2));
        return ot0Var;
    }

    public static int auXIgCKsG(float f) {
        if (!java.lang.Float.isNaN(f)) {
            return java.lang.Math.round(f);
        }
        defpackage.t5.acT0gEliM("Cannot round NaN value.");
        return 0;
    }

    public static final void bGtyfE77Qpby(defpackage.io0 io0Var, defpackage.d40 d40Var, defpackage.h60 h60Var, int i) {
        h60Var.vkFkPUN4(1090521195);
        int i2 = (h60Var.bGtyfE77Qpby(io0Var) ? 4 : 2) | i | (h60Var.KImmPBu5u(d40Var) ? 32 : 16);
        if (h60Var.eMSp92M2t(i2 & 1, (i2 & 19) != 18)) {
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r == defpackage.im.CGnIndwjik9) {
                objCO8Wxv6r = defpackage.d0.wk61Lrtj;
                h60Var.XEWVqqb5t6J(objCO8Wxv6r);
            }
            defpackage.pn0 pn0Var = (defpackage.pn0) objCO8Wxv6r;
            int iHashCode = java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
            defpackage.y21 y21VarTs5Bfxu7gi = h60Var.Ts5Bfxu7gi();
            defpackage.io0 io0VarZsS39c8E7oY = defpackage.yr.ZsS39c8E7oY(h60Var, io0Var);
            defpackage.cm.m4CNag5J8Y.getClass();
            defpackage.xm xmVar = defpackage.bm.wk61Lrtj;
            int i3 = (((((i2 << 3) & 112) | (((i2 >> 3) & 14) | 384)) << 6) & 896) | 6;
            h60Var.ixcZHu7WE();
            if (h60Var.BWtb0lBv) {
                h60Var.SOLzqtJLiD8g(xmVar);
            } else {
                h60Var.fpvKaAaF3V3();
            }
            defpackage.j20.eMSp92M2t(defpackage.bm.hyi5MRgVJpZU, h60Var, pn0Var);
            defpackage.j20.eMSp92M2t(defpackage.bm.ShamLDIR, h60Var, y21VarTs5Bfxu7gi);
            defpackage.j20.eMSp92M2t(defpackage.bm.bGtyfE77Qpby, h60Var, java.lang.Integer.valueOf(iHashCode));
            defpackage.j20.QTXOIjVJtE(h60Var, defpackage.bm.AdtkbTq73SIl);
            defpackage.j20.eMSp92M2t(defpackage.bm.m4CNag5J8Y, h60Var, io0VarZsS39c8E7oY);
            d40Var.ShamLDIR(h60Var, java.lang.Integer.valueOf((i3 >> 6) & 14));
            h60Var.acT0gEliM(true);
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.s(io0Var, d40Var, i);
        }
    }

    public static defpackage.a30 cAUonbdEve(android.content.Context context) {
        android.content.pm.ProviderInfo providerInfo;
        defpackage.y20 y20Var;
        android.content.pm.ApplicationInfo applicationInfo;
        int i = 0;
        defpackage.fs gsVar = android.os.Build.VERSION.SDK_INT >= 28 ? new defpackage.gs(i) : new defpackage.fs(i);
        android.content.pm.PackageManager packageManager = context.getPackageManager();
        defpackage.r10.Ts5Bfxu7gi(packageManager, "Package manager required to locate emoji font provider");
        java.util.Iterator<android.content.pm.ResolveInfo> it = packageManager.queryIntentContentProviders(new android.content.Intent("androidx.content.action.LOAD_EMOJI_FONT"), 0).iterator();
        while (true) {
            if (!it.hasNext()) {
                providerInfo = null;
                break;
            }
            providerInfo = it.next().providerInfo;
            if (providerInfo != null && (applicationInfo = providerInfo.applicationInfo) != null && (applicationInfo.flags & 1) == 1) {
                break;
            }
        }
        if (providerInfo == null) {
            y20Var = null;
        } else {
            try {
                java.lang.String str = providerInfo.authority;
                java.lang.String str2 = providerInfo.packageName;
                android.content.pm.Signature[] signatureArrYbb6jpEh = gsVar.ybb6jpEh(packageManager, str2);
                java.util.ArrayList arrayList = new java.util.ArrayList();
                int length = signatureArrYbb6jpEh.length;
                while (i < length) {
                    arrayList.add(signatureArrYbb6jpEh[i].toByteArray());
                    i++;
                }
                y20Var = new defpackage.y20(str, str2, "emojicompat-emoji-font", java.util.Collections.singletonList(arrayList), null, null);
            } catch (android.content.pm.PackageManager.NameNotFoundException e) {
                android.util.Log.wtf("emoji2.text.DefaultEmojiConfig", e);
            }
        }
        if (y20Var == null) {
            return null;
        }
        return new defpackage.a30(new defpackage.z20(context, y20Var));
    }

    public static final defpackage.y21 fwzzEzgVd5(defpackage.c71[] c71VarArr, defpackage.y21 y21Var, defpackage.y21 y21Var2) {
        defpackage.x21 x21Var = new defpackage.x21(defpackage.y21.KImmPBu5u);
        for (defpackage.c71 c71Var : c71VarArr) {
            defpackage.a71 a71Var = c71Var.CGnIndwjik9;
            if (c71Var.bGtyfE77Qpby || !y21Var.containsKey(a71Var)) {
                x21Var.put(a71Var, a71Var.m4CNag5J8Y(c71Var, (defpackage.fw1) y21Var2.get(a71Var)));
            }
        }
        return x21Var.CGnIndwjik9();
    }

    public static final int h86pw74rDIBM(defpackage.h60 h60Var) {
        h60Var.getClass();
        return java.lang.Long.hashCode(h60Var.ZsS39c8E7oY);
    }

    public static final java.lang.String hfi1lqIFl(java.lang.reflect.Type type) {
        java.lang.String strHfi1lqIFl;
        if (type instanceof java.lang.Class) {
            java.lang.Class cls = (java.lang.Class) type;
            java.lang.Class<?> enclosingClass = cls.getEnclosingClass();
            return ((enclosingClass == null || (strHfi1lqIFl = hfi1lqIFl(enclosingClass)) == null) ? "" : strHfi1lqIFl.concat(".")).concat(cls.getSimpleName());
        }
        if (type instanceof java.lang.reflect.ParameterizedType) {
            return hfi1lqIFl(defpackage.t10.xy7yDq1ZM((java.lang.reflect.ParameterizedType) type));
        }
        if (type instanceof java.lang.reflect.GenericArrayType) {
            java.lang.reflect.Type genericComponentType = ((java.lang.reflect.GenericArrayType) type).getGenericComponentType();
            genericComponentType.getClass();
            return hfi1lqIFl(genericComponentType);
        }
        if (type instanceof java.lang.reflect.WildcardType) {
            return "*";
        }
        if (type instanceof java.lang.reflect.TypeVariable) {
            java.lang.String name = ((java.lang.reflect.TypeVariable) type).getName();
            name.getClass();
            return name;
        }
        throw new java.lang.IllegalArgumentException("Unknown type " + type.getClass() + " " + type);
    }

    public static final void hyi5MRgVJpZU(defpackage.o30 o30Var, defpackage.du duVar, defpackage.hl hlVar, defpackage.h60 h60Var, int i) {
        int i2;
        java.lang.Object obj;
        h60Var.vkFkPUN4(826668973);
        int i3 = i | (h60Var.KImmPBu5u(o30Var) ? 4 : 2) | (h60Var.bGtyfE77Qpby(duVar) ? 32 : 16);
        if (h60Var.eMSp92M2t(i3 & 1, (i3 & 147) != 146)) {
            android.view.View view = (android.view.View) h60Var.O21Gh3JCO74(defpackage.n.hyi5MRgVJpZU);
            defpackage.mt mtVar = (defpackage.mt) h60Var.O21Gh3JCO74(defpackage.ym.KImmPBu5u);
            defpackage.ke0 ke0Var = (defpackage.ke0) h60Var.O21Gh3JCO74(defpackage.ym.oA3oVL3lY);
            defpackage.f60 f60VarXy7yDq1ZM = xy7yDq1ZM(h60Var);
            defpackage.ot0 ot0VarAuXIgCKsG = defpackage.d10.auXIgCKsG(hlVar, h60Var);
            java.lang.Object[] objArr = new java.lang.Object[0];
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            java.lang.Object obj2 = defpackage.im.CGnIndwjik9;
            java.lang.Object obj3 = objCO8Wxv6r;
            if (objCO8Wxv6r == obj2) {
                java.lang.Object obj4 = defpackage.m.Ts5Bfxu7gi;
                h60Var.XEWVqqb5t6J(obj4);
                obj3 = obj4;
            }
            java.util.UUID uuid = (java.util.UUID) defpackage.j20.Q23EIYzrs(java.util.Arrays.copyOf(objArr, 0), defpackage.f12.h86pw74rDIBM, (defpackage.o30) obj3, h60Var, 3456);
            duVar.getClass();
            boolean zShamLDIR = h60Var.ShamLDIR(2) | h60Var.bGtyfE77Qpby(view) | h60Var.bGtyfE77Qpby(mtVar) | h60Var.bGtyfE77Qpby(null);
            java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
            if (zShamLDIR || objCO8Wxv6r2 == obj2) {
                defpackage.fu fuVar = new defpackage.fu(o30Var, duVar, view, ke0Var, mtVar, uuid);
                defpackage.hl hlVar2 = new defpackage.hl(-1338939603, new defpackage.Wg7Cen3syT(i, ot0VarAuXIgCKsG), true);
                defpackage.cu cuVar = fuVar.Ts5Bfxu7gi;
                cuVar.setParentCompositionContext(f60VarXy7yDq1ZM);
                cuVar.Wg7Cen3syT.setValue(hlVar2);
                cuVar.LQkLH9RtdoX = true;
                cuVar.hyi5MRgVJpZU();
                h60Var.XEWVqqb5t6J(fuVar);
                objCO8Wxv6r2 = fuVar;
            }
            defpackage.fu fuVar2 = (defpackage.fu) objCO8Wxv6r2;
            boolean zKImmPBu5u = h60Var.KImmPBu5u(fuVar2);
            java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
            if (zKImmPBu5u || objCO8Wxv6r3 == obj2) {
                i2 = 0;
                java.lang.Object zVar = new defpackage.z(fuVar2, i2);
                h60Var.XEWVqqb5t6J(zVar);
                obj = zVar;
            } else {
                i2 = 0;
                obj = objCO8Wxv6r3;
            }
            defpackage.fc0.EX2ajLj518q3(fuVar2, (defpackage.z30) obj, h60Var);
            int i4 = (h60Var.KImmPBu5u(fuVar2) ? 1 : 0) | ((i3 & 14) == 4 ? 1 : i2) | ((i3 & 112) != 32 ? i2 : 1) | (h60Var.ShamLDIR(ke0Var.ordinal()) ? 1 : 0);
            java.lang.Object objCO8Wxv6r4 = h60Var.CO8Wxv6r();
            java.lang.Object obj5 = objCO8Wxv6r4;
            if (i4 != 0 || objCO8Wxv6r4 == obj2) {
                java.lang.Object a0Var = new defpackage.a0(fuVar2, o30Var, duVar, ke0Var);
                h60Var.XEWVqqb5t6J(a0Var);
                obj5 = a0Var;
            }
            defpackage.fc0.Ts5Bfxu7gi((defpackage.o30) obj5, h60Var);
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.b0(o30Var, duVar, hlVar, i, 0);
        }
    }

    public static final java.lang.String lWYAEQgM(java.lang.Class cls) {
        java.lang.reflect.TypeVariable[] typeParameters = cls.getTypeParameters();
        typeParameters.getClass();
        if (typeParameters.length == 0) {
            return "";
        }
        int length = cls.getTypeParameters().length;
        java.lang.String[] strArr = new java.lang.String[length];
        for (int i = 0; i < length; i++) {
            strArr[i] = "*";
        }
        return defpackage.i6.d5vh3ApcY(strArr, "<", ">", null, 56);
    }

    public static final void m4CNag5J8Y(defpackage.o30 o30Var, defpackage.h60 h60Var, int i) {
        h60Var.vkFkPUN4(-1537757354);
        int i2 = (h60Var.KImmPBu5u(o30Var) ? 4 : 2) | i;
        if (h60Var.eMSp92M2t(i2 & 1, (i2 & 3) != 2)) {
            defpackage.yr.h86pw74rDIBM("Your quest", null, h60Var, 6);
            java.util.List list = defpackage.ci.CGnIndwjik9;
            java.lang.String str = "A master's codex was torn apart and scattered across " + list.size() + " cities, from " + defpackage.ci.CGnIndwjik9(0) + " to " + defpackage.ci.CGnIndwjik9(list.size() - 1) + ". Recover every page.";
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            defpackage.kh1 kh1Var = defpackage.im.CGnIndwjik9;
            if (objCO8Wxv6r == kh1Var) {
                objCO8Wxv6r = new defpackage.d50(9);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r);
            }
            AdtkbTq73SIl("The apprentice", str, (defpackage.z30) objCO8Wxv6r, h60Var, 390);
            java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r2 == kh1Var) {
                objCO8Wxv6r2 = new defpackage.d50(15);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r2);
            }
            AdtkbTq73SIl("Move and wait", "Swipe on the map or tap the golden pad. Each step is one turn. WAIT lets a turn pass so you can time a patrol.", (defpackage.z30) objCO8Wxv6r2, h60Var, 438);
            java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r3 == kh1Var) {
                objCO8Wxv6r3 = new defpackage.d50(16);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r3);
            }
            AdtkbTq73SIl("Codex pages", "Every city hides several pages. The counter at the top shows how many are still missing.", (defpackage.z30) objCO8Wxv6r3, h60Var, 438);
            java.lang.Object objCO8Wxv6r4 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r4 == kh1Var) {
                objCO8Wxv6r4 = new defpackage.d50(17);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r4);
            }
            AdtkbTq73SIl("Workshop door", "The door stays sealed until all pages of the city are found. Step through it to travel onward.", (defpackage.z30) objCO8Wxv6r4, h60Var, 438);
            defpackage.yr.h86pw74rDIBM("Dangers", null, h60Var, 6);
            java.lang.Object objCO8Wxv6r5 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r5 == kh1Var) {
                objCO8Wxv6r5 = new defpackage.d50(18);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r5);
            }
            AdtkbTq73SIl("City watch", "Guards march back and forth along their beat. Red tiles mark where a guard will stand over the next two turns. Ending your turn on a guard or a red tile costs one life.", (defpackage.z30) objCO8Wxv6r5, h60Var, 438);
            java.lang.Object objCO8Wxv6r6 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r6 == kh1Var) {
                objCO8Wxv6r6 = new defpackage.d50(19);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r6);
            }
            AdtkbTq73SIl("Candle", "Every turn burns the candle. If it goes out you lose a life and restart from the city gate with a fresh candle.", (defpackage.z30) objCO8Wxv6r6, h60Var, 438);
            java.lang.Object objCO8Wxv6r7 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r7 == kh1Var) {
                objCO8Wxv6r7 = new defpackage.d50(20);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r7);
            }
            AdtkbTq73SIl("Night fog", "Only nearby streets are visible. Explore to reveal buildings, treasures and patrols. The gate is marked with a blue frame.", (defpackage.z30) objCO8Wxv6r7, h60Var, 438);
            java.lang.Object objCO8Wxv6r8 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r8 == kh1Var) {
                objCO8Wxv6r8 = new defpackage.d50(21);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r8);
            }
            AdtkbTq73SIl("Lives", "Lose all lives and the journey ends. Pages you already found in a city stay with you after a setback.", (defpackage.z30) objCO8Wxv6r8, h60Var, 438);
            defpackage.yr.PJFAWmtS("Try the practice yard", o30Var, defpackage.l.oA3oVL3lY, defpackage.zf.AdtkbTq73SIl, false, h60Var, ((i2 << 3) & 112) | 3462, 16);
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.dl(o30Var, i);
        }
    }

    public static final java.lang.Object mbwb7dCOYb(defpackage.y21 y21Var, defpackage.a71 a71Var) {
        a71Var.getClass();
        java.lang.Object objWk61Lrtj = y21Var.get(a71Var);
        if (objWk61Lrtj == null) {
            objWk61Lrtj = a71Var.wk61Lrtj();
        }
        return ((defpackage.fw1) objWk61Lrtj).CGnIndwjik9(y21Var);
    }

    public static final defpackage.us0 neoVPlKKu(defpackage.hj1 hj1Var, defpackage.z30 z30Var) {
        android.os.Trace.beginSection("getAllUncoveredSemanticsNodesToIntObjectMap");
        try {
            defpackage.ej1 ej1VarCGnIndwjik9 = hj1Var.CGnIndwjik9();
            defpackage.af0 af0Var = ej1VarCGnIndwjik9.m4CNag5J8Y;
            if (af0Var.auXIgCKsG() && af0Var.xy7yDq1ZM()) {
                defpackage.y71 y71VarAdtkbTq73SIl = ej1VarCGnIndwjik9.AdtkbTq73SIl();
                defpackage.us0 us0Var = new defpackage.us0(48);
                defpackage.rm0 rm0Var = new defpackage.rm0(16);
                rm0Var.KImmPBu5u(defpackage.i20.mbwb7dCOYb(y71VarAdtkbTq73SIl));
                X9gUlnc07R(z30Var, new defpackage.rm0(16), rm0Var, us0Var, ej1VarCGnIndwjik9, ej1VarCGnIndwjik9);
                return us0Var;
            }
            defpackage.us0 us0Var2 = defpackage.mb0.CGnIndwjik9;
            us0Var2.getClass();
            return us0Var2;
        } finally {
            android.os.Trace.endSection();
        }
    }

    public static final void oA3oVL3lY(defpackage.h60 h60Var, int i) {
        java.lang.String str;
        h60Var.vkFkPUN4(523368295);
        int i2 = 0;
        if (h60Var.eMSp92M2t(i & 1, i != 0)) {
            defpackage.yr.h86pw74rDIBM("Treasures", null, h60Var, 6);
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            defpackage.kh1 kh1Var = defpackage.im.CGnIndwjik9;
            if (objCO8Wxv6r == kh1Var) {
                objCO8Wxv6r = new defpackage.d50(10);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r);
            }
            AdtkbTq73SIl("Florin", "Worth 10 points and one coin for the wardrobe. Some lie on patrol routes — risky but rewarding.", (defpackage.z30) objCO8Wxv6r, h60Var, 390);
            java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r2 == kh1Var) {
                objCO8Wxv6r2 = new defpackage.d50(11);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r2);
            }
            AdtkbTq73SIl("Lantern", "Widens your sight through the fog for the rest of the city.", (defpackage.z30) objCO8Wxv6r2, h60Var, 438);
            java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r3 == kh1Var) {
                objCO8Wxv6r3 = new defpackage.d50(12);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r3);
            }
            AdtkbTq73SIl("Shadow cloak", "For 6 turns the watch cannot catch you. Slip straight past the guards.", (defpackage.z30) objCO8Wxv6r3, h60Var, 390);
            java.lang.Object objCO8Wxv6r4 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r4 == kh1Var) {
                objCO8Wxv6r4 = new defpackage.d50(13);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r4);
            }
            AdtkbTq73SIl("Hourglass", "Adds 10 turns to your candle.", (defpackage.z30) objCO8Wxv6r4, h60Var, 390);
            defpackage.yr.h86pw74rDIBM("Scoring", null, h60Var, 6);
            Ts5Bfxu7gi("Codex page", "+50", h60Var, 6);
            Ts5Bfxu7gi("Florin", "+10", h60Var, 6);
            Ts5Bfxu7gi("Lantern, cloak or hourglass", "+15", h60Var, 6);
            Ts5Bfxu7gi("City cleared", "+100 and +3 per unused turn", h60Var, 54);
            Ts5Bfxu7gi("Journey completed", "+500 and +200 per life left", h60Var, 54);
            defpackage.yr.h86pw74rDIBM("Modes", null, h60Var, 6);
            h60Var.hwJeYkFOwb2F(445796397);
            defpackage.wy wyVar = defpackage.c50.oA3oVL3lY;
            wyVar.getClass();
            defpackage.neoVPlKKu neovplkku = new defpackage.neoVPlKKu(wyVar);
            while (neovplkku.hasNext()) {
                defpackage.c50 c50Var = (defpackage.c50) neovplkku.next();
                java.lang.String str2 = c50Var.bGtyfE77Qpby;
                int i3 = c50Var.AdtkbTq73SIl;
                if (c50Var == defpackage.c50.Ts5Bfxu7gi) {
                    str = i3 + " lives, shorter candles and ×1.5 score. Winning here unlocks Il Magnifico.";
                } else {
                    str = i3 + " lives and generous candles. The best way to learn the roads.";
                }
                boolean zShamLDIR = h60Var.ShamLDIR(c50Var.ordinal());
                java.lang.Object objCO8Wxv6r5 = h60Var.CO8Wxv6r();
                if (zShamLDIR || objCO8Wxv6r5 == kh1Var) {
                    objCO8Wxv6r5 = new defpackage.v80(c50Var, i2);
                    h60Var.XEWVqqb5t6J(objCO8Wxv6r5);
                }
                AdtkbTq73SIl(str2, str, (defpackage.z30) objCO8Wxv6r5, h60Var, 0);
            }
            h60Var.acT0gEliM(false);
            defpackage.yr.h86pw74rDIBM("Wardrobe", null, h60Var, 6);
            java.lang.Object objCO8Wxv6r6 = h60Var.CO8Wxv6r();
            if (objCO8Wxv6r6 == kh1Var) {
                objCO8Wxv6r6 = new defpackage.d50(14);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r6);
            }
            AdtkbTq73SIl("Outfits", "Florins found in cleared cities, plus a bonus for each city and for finishing a journey, are added to your purse. Spend them on new outfits in the Skins tab.", (defpackage.z30) objCO8Wxv6r6, h60Var, 438);
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.ck(i);
        }
    }

    public static final void wk61Lrtj(boolean z, final defpackage.o30 o30Var, defpackage.h60 h60Var, final int i, final int i2) {
        final boolean z2;
        int i3;
        h60Var.vkFkPUN4(-361453782);
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            z2 = z;
        } else {
            z2 = z;
            i3 = (h60Var.AdtkbTq73SIl(z2) ? 4 : 2) | i;
        }
        int i5 = i3 | (h60Var.KImmPBu5u(o30Var) ? 32 : 16);
        if (h60Var.eMSp92M2t(i5 & 1, (i5 & 19) != 18)) {
            boolean z3 = i4 != 0 ? true : z2;
            java.lang.Object obj = (defpackage.tu0) h60Var.O21Gh3JCO74(defpackage.ml0.CGnIndwjik9);
            if (obj == null) {
                h60Var.hwJeYkFOwb2F(950836184);
                android.view.View view = (android.view.View) h60Var.O21Gh3JCO74(defpackage.n.hyi5MRgVJpZU);
                view.getClass();
                while (true) {
                    if (view == null) {
                        obj = null;
                        break;
                    }
                    java.lang.Object tag = view.getTag(com.kartiop.locak.spachfykas.R.id.view_tree_navigation_event_dispatcher_owner);
                    java.lang.Object obj2 = tag instanceof defpackage.tu0 ? (defpackage.tu0) tag : null;
                    if (obj2 != null) {
                        obj = obj2;
                        break;
                    } else {
                        java.lang.Object objMbwb7dCOYb = defpackage.t10.mbwb7dCOYb(view);
                        view = objMbwb7dCOYb instanceof android.view.View ? (android.view.View) objMbwb7dCOYb : null;
                    }
                }
                h60Var.acT0gEliM(false);
            } else {
                h60Var.hwJeYkFOwb2F(950834231);
                h60Var.acT0gEliM(false);
            }
            if (obj == null) {
                h60Var.hwJeYkFOwb2F(535274673);
                obj = (defpackage.dz0) h60Var.O21Gh3JCO74(defpackage.nl0.CGnIndwjik9);
                if (obj == null) {
                    h60Var.hwJeYkFOwb2F(1208426157);
                    android.view.View view2 = (android.view.View) h60Var.O21Gh3JCO74(defpackage.n.hyi5MRgVJpZU);
                    view2.getClass();
                    while (true) {
                        if (view2 == null) {
                            obj = null;
                            break;
                        }
                        java.lang.Object tag2 = view2.getTag(com.kartiop.locak.spachfykas.R.id.view_tree_on_back_pressed_dispatcher_owner);
                        java.lang.Object obj3 = tag2 instanceof defpackage.dz0 ? (defpackage.dz0) tag2 : null;
                        if (obj3 != null) {
                            obj = obj3;
                            break;
                        } else {
                            java.lang.Object objMbwb7dCOYb2 = defpackage.t10.mbwb7dCOYb(view2);
                            view2 = objMbwb7dCOYb2 instanceof android.view.View ? (android.view.View) objMbwb7dCOYb2 : null;
                        }
                    }
                } else {
                    h60Var.hwJeYkFOwb2F(1208423708);
                }
                h60Var.acT0gEliM(false);
                if (obj == null) {
                    h60Var.hwJeYkFOwb2F(1208428160);
                    java.lang.Object baseContext = (android.content.Context) h60Var.O21Gh3JCO74(defpackage.n.wk61Lrtj);
                    while (true) {
                        if (!(baseContext instanceof android.content.ContextWrapper)) {
                            baseContext = null;
                            break;
                        } else if (baseContext instanceof defpackage.dz0) {
                            break;
                        } else {
                            baseContext = ((android.content.ContextWrapper) baseContext).getBaseContext();
                        }
                    }
                    obj = (defpackage.dz0) baseContext;
                } else {
                    h60Var.hwJeYkFOwb2F(1208423789);
                }
                h60Var.acT0gEliM(false);
            } else {
                h60Var.hwJeYkFOwb2F(535271790);
            }
            h60Var.acT0gEliM(false);
            if (obj == null) {
                defpackage.t5.Wg7Cen3syT("No NavigationEventDispatcherOwner was provided via LocalNavigationEventDispatcherOwner and no OnBackPressedDispatcherOwner was provided via LocalOnBackPressedDispatcherOwner. Please provide one of the two.");
                return;
            }
            boolean zBGtyfE77Qpby = h60Var.bGtyfE77Qpby(obj);
            java.lang.Object objCO8Wxv6r = h60Var.CO8Wxv6r();
            java.lang.Object obj4 = defpackage.im.CGnIndwjik9;
            if (zBGtyfE77Qpby || objCO8Wxv6r == obj4) {
                defpackage.tu0 tu0Var = obj instanceof defpackage.tu0 ? (defpackage.tu0) obj : null;
                defpackage.llsKPgWWJAw llskpgwwjawCGnIndwjik9 = tu0Var != null ? tu0Var.CGnIndwjik9() : null;
                defpackage.dz0 dz0Var = obj instanceof defpackage.dz0 ? (defpackage.dz0) obj : null;
                objCO8Wxv6r = new defpackage.d7(llskpgwwjawCGnIndwjik9, dz0Var != null ? dz0Var.wk61Lrtj() : null);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r);
            }
            java.lang.Object obj5 = (defpackage.d7) objCO8Wxv6r;
            long j = h60Var.ZsS39c8E7oY;
            boolean zBGtyfE77Qpby2 = h60Var.bGtyfE77Qpby(obj5) | h60Var.hyi5MRgVJpZU(j);
            java.lang.Object objCO8Wxv6r2 = h60Var.CO8Wxv6r();
            java.lang.Object obj6 = objCO8Wxv6r2;
            if (zBGtyfE77Qpby2 || objCO8Wxv6r2 == obj4) {
                defpackage.ol olVar = new defpackage.ol(new defpackage.e7(j, obj));
                olVar.m4CNag5J8Y = new defpackage.uc0(6);
                h60Var.XEWVqqb5t6J(olVar);
                obj6 = olVar;
            }
            defpackage.ol olVar2 = (defpackage.ol) obj6;
            h60Var.hwJeYkFOwb2F(-585307852);
            boolean zKImmPBu5u = h60Var.KImmPBu5u(olVar2) | ((i5 & 112) == 32);
            java.lang.Object objCO8Wxv6r3 = h60Var.CO8Wxv6r();
            int i6 = 3;
            if (zKImmPBu5u || objCO8Wxv6r3 == obj4) {
                objCO8Wxv6r3 = new defpackage.c2(i6, olVar2, o30Var);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r3);
            }
            defpackage.fc0.Ts5Bfxu7gi((defpackage.o30) objCO8Wxv6r3, h60Var);
            java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(z3);
            int i7 = i5 & 14;
            boolean zKImmPBu5u2 = h60Var.KImmPBu5u(olVar2) | (i7 == 4);
            java.lang.Object objCO8Wxv6r4 = h60Var.CO8Wxv6r();
            if (zKImmPBu5u2 || objCO8Wxv6r4 == obj4) {
                objCO8Wxv6r4 = new defpackage.f7(olVar2, z3);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r4);
            }
            defpackage.s20.wk61Lrtj(boolValueOf, olVar2, null, (defpackage.z30) objCO8Wxv6r4, h60Var, i7);
            boolean zKImmPBu5u3 = h60Var.KImmPBu5u(obj5) | h60Var.KImmPBu5u(olVar2);
            java.lang.Object objCO8Wxv6r5 = h60Var.CO8Wxv6r();
            if (zKImmPBu5u3 || objCO8Wxv6r5 == obj4) {
                objCO8Wxv6r5 = new defpackage.m4CNag5J8Y(i6, obj5, olVar2);
                h60Var.XEWVqqb5t6J(objCO8Wxv6r5);
            }
            defpackage.fc0.O21Gh3JCO74(obj5, olVar2, (defpackage.z30) objCO8Wxv6r5, h60Var);
            h60Var.acT0gEliM(false);
            z2 = z3;
        } else {
            h60Var.w9n6oNBhm();
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.d40(z2, o30Var, i, i2) { // from class: g7
                public final /* synthetic */ int AdtkbTq73SIl;
                public final /* synthetic */ defpackage.o30 bGtyfE77Qpby;
                public final /* synthetic */ boolean hyi5MRgVJpZU;

                {
                    this.AdtkbTq73SIl = i2;
                }

                @Override // defpackage.d40
                public final java.lang.Object ShamLDIR(java.lang.Object obj7, java.lang.Object obj8) {
                    ((java.lang.Integer) obj8).getClass();
                    int iM80ht0VsJ = defpackage.h10.M80ht0VsJ(1);
                    defpackage.jn0.wk61Lrtj(this.hyi5MRgVJpZU, this.bGtyfE77Qpby, (defpackage.h60) obj7, iM80ht0VsJ, this.AdtkbTq73SIl);
                    return defpackage.fv1.CGnIndwjik9;
                }
            };
        }
    }

    public static final defpackage.f60 xy7yDq1ZM(defpackage.h60 h60Var) {
        defpackage.h60 h60Var2;
        h60Var.UJW17wJvbt(206, defpackage.km.hyi5MRgVJpZU);
        if (h60Var.BWtb0lBv) {
            defpackage.hm1.EUGsszWpP4(h60Var.QTXOIjVJtE);
        }
        java.lang.Object objM80ht0VsJ = h60Var.M80ht0VsJ();
        defpackage.l60 me1Var = objM80ht0VsJ instanceof defpackage.l60 ? (defpackage.l60) objM80ht0VsJ : null;
        if (me1Var == null) {
            h60Var2 = h60Var;
            me1Var = new defpackage.me1(new defpackage.e60(new defpackage.f60(h60Var2, h60Var.ZsS39c8E7oY, h60Var.AqsOwbEF, h60Var.JcNBqlq8RG, h60Var.KImmPBu5u.h86pw74rDIBM)), -1);
            h60Var2.XXHoeiX492(me1Var);
        } else {
            h60Var2 = h60Var;
        }
        defpackage.f60 f60Var = ((defpackage.e60) me1Var.CGnIndwjik9).hyi5MRgVJpZU;
        f60Var.bGtyfE77Qpby.setValue(h60Var2.Ts5Bfxu7gi());
        h60Var2.acT0gEliM(false);
        return f60Var;
    }

    public static final void ybb6jpEh(final defpackage.o30 o30Var, defpackage.io0 io0Var, boolean z, defpackage.pk1 pk1Var, defpackage.uf ufVar, defpackage.j11 j11Var, final defpackage.hl hlVar, defpackage.h60 h60Var, final int i) {
        final defpackage.io0 io0Var2;
        final boolean z2;
        final defpackage.pk1 pk1Var2;
        final defpackage.uf ufVar2;
        final defpackage.j11 j11Var2;
        defpackage.uf ufVar3;
        int i2;
        defpackage.io0 io0Var3;
        defpackage.pk1 pk1Var3;
        boolean z3;
        defpackage.uf ufVar4;
        h60Var.vkFkPUN4(-1061374109);
        int i3 = i | (h60Var.KImmPBu5u(o30Var) ? 4 : 2) | 115025328;
        if (h60Var.eMSp92M2t(i3 & 1, (306783379 & i3) != 306783378)) {
            h60Var.ZsS39c8E7oY();
            if ((i & 1) == 0 || h60Var.EUGsszWpP4()) {
                defpackage.l11 l11Var = defpackage.vf.CGnIndwjik9;
                defpackage.pk1 pk1VarCGnIndwjik9 = defpackage.uk1.CGnIndwjik9(SOLzqtJLiD8g, h60Var);
                defpackage.mj mjVar = (defpackage.mj) h60Var.O21Gh3JCO74(defpackage.oj.CGnIndwjik9);
                defpackage.uf ufVar5 = mjVar.kvrWLhjanVQ;
                if (ufVar5 == null) {
                    long j = defpackage.ij.hyi5MRgVJpZU;
                    ufVar3 = new defpackage.uf(j, defpackage.oj.wk61Lrtj(mjVar, defpackage.nj.O21Gh3JCO74), j, defpackage.ij.wk61Lrtj(defpackage.oj.wk61Lrtj(mjVar, defpackage.l.acT0gEliM), defpackage.l.AqsOwbEF));
                    mjVar.kvrWLhjanVQ = ufVar3;
                } else {
                    ufVar3 = ufVar5;
                }
                defpackage.l11 l11Var2 = defpackage.vf.CGnIndwjik9;
                i2 = i3 & (-64513);
                io0Var3 = defpackage.fo0.CGnIndwjik9;
                j11Var2 = l11Var2;
                pk1Var3 = pk1VarCGnIndwjik9;
                z3 = true;
                ufVar4 = ufVar3;
            } else {
                h60Var.w9n6oNBhm();
                z3 = z;
                pk1Var3 = pk1Var;
                ufVar4 = ufVar;
                j11Var2 = j11Var;
                i2 = i3 & (-64513);
                io0Var3 = io0Var;
            }
            h60Var.AqsOwbEF();
            ShamLDIR(o30Var, io0Var3, z3, pk1Var3, ufVar4, null, null, j11Var2, hlVar, h60Var, i2 & 2147483646, 0);
            pk1Var2 = pk1Var3;
            ufVar2 = ufVar4;
            io0Var2 = io0Var3;
            z2 = z3;
        } else {
            h60Var.w9n6oNBhm();
            io0Var2 = io0Var;
            z2 = z;
            pk1Var2 = pk1Var;
            ufVar2 = ufVar;
            j11Var2 = j11Var;
        }
        defpackage.o71 o71VarCAUonbdEve = h60Var.cAUonbdEve();
        if (o71VarCAUonbdEve != null) {
            o71VarCAUonbdEve.ShamLDIR = new defpackage.d40(io0Var2, z2, pk1Var2, ufVar2, j11Var2, hlVar, i) { // from class: cg
                public final /* synthetic */ boolean AdtkbTq73SIl;
                public final /* synthetic */ defpackage.uf EX2ajLj518q3;
                public final /* synthetic */ defpackage.pk1 KImmPBu5u;
                public final /* synthetic */ defpackage.j11 O21Gh3JCO74;
                public final /* synthetic */ defpackage.hl SOLzqtJLiD8g;
                public final /* synthetic */ defpackage.io0 bGtyfE77Qpby;

                @Override // defpackage.d40
                public final java.lang.Object ShamLDIR(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iM80ht0VsJ = defpackage.h10.M80ht0VsJ(805306369);
                    defpackage.jn0.ybb6jpEh(this.hyi5MRgVJpZU, this.bGtyfE77Qpby, this.AdtkbTq73SIl, this.KImmPBu5u, this.EX2ajLj518q3, this.O21Gh3JCO74, this.SOLzqtJLiD8g, (defpackage.h60) obj, iM80ht0VsJ);
                    return defpackage.fv1.CGnIndwjik9;
                }
            };
        }
    }

    public static final java.lang.String ywSpSBoL(java.lang.Class cls) {
        if (cls.equals(java.lang.Boolean.TYPE) || cls.equals(java.lang.Boolean.class)) {
            return "Boolean";
        }
        if (cls.equals(java.lang.Byte.TYPE) || cls.equals(java.lang.Byte.class)) {
            return "Byte";
        }
        if (cls.equals(java.lang.Character.TYPE) || cls.equals(java.lang.Character.class)) {
            return "Char";
        }
        if (cls.equals(java.lang.Short.TYPE) || cls.equals(java.lang.Short.class)) {
            return "Short";
        }
        if (cls.equals(java.lang.Integer.TYPE) || cls.equals(java.lang.Integer.class)) {
            return "Int";
        }
        if (cls.equals(java.lang.Long.TYPE) || cls.equals(java.lang.Long.class)) {
            return "Long";
        }
        if (cls.equals(java.lang.Float.TYPE) || cls.equals(java.lang.Float.class)) {
            return "Float";
        }
        if (cls.equals(java.lang.Double.TYPE) || cls.equals(java.lang.Double.class)) {
            return "Double";
        }
        if (cls.equals(java.lang.Object.class)) {
            return "Any";
        }
        return null;
    }
}
