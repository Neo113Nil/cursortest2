package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final /* synthetic */ class w implements defpackage.o30 {
    public final /* synthetic */ android.content.Context bGtyfE77Qpby;
    public final /* synthetic */ int hyi5MRgVJpZU = 0;

    @Override // defpackage.o30
    public final java.lang.Object CGnIndwjik9() {
        int i = this.hyi5MRgVJpZU;
        android.content.Context context = this.bGtyfE77Qpby;
        switch (i) {
            case 0:
                return context;
            default:
                return new java.io.File(context.getApplicationContext().getFilesDir(), "datastore/".concat("florentia_codex".concat(".preferences_pb")));
        }
    }

    public /* synthetic */ w(android.content.Context context, defpackage.d51 d51Var) {
        this.bGtyfE77Qpby = context;
    }
}
