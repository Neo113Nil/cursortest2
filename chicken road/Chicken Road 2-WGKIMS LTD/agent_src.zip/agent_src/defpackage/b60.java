package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final class b60 extends defpackage.fu0 {
    public final defpackage.uh AdtkbTq73SIl;
    public final defpackage.yi0 bGtyfE77Qpby;
    public final defpackage.o61 hyi5MRgVJpZU;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b60(defpackage.uh uhVar, defpackage.yi0 yi0Var, defpackage.o61 o61Var) {
        super(new defpackage.t50(null, false, defpackage.ql1.wk61Lrtj, "", 0));
        o61Var.getClass();
        yi0Var.getClass();
        uhVar.getClass();
        this.hyi5MRgVJpZU = o61Var;
        this.bGtyfE77Qpby = yi0Var;
        this.AdtkbTq73SIl = uhVar;
        defpackage.ec0.xy7yDq1ZM(defpackage.fc0.ywSpSBoL(this), null, new defpackage.cs(this, null, 3), 3);
    }

    public final java.lang.Object AqsOwbEF(defpackage.gu guVar, defpackage.x50 x50Var) {
        java.lang.Object value;
        defpackage.t50 t50VarCGnIndwjik9;
        defpackage.fo1 fo1Var = this.wk61Lrtj;
        defpackage.tf1 tf1Var = ((defpackage.t50) fo1Var.getValue()).CGnIndwjik9;
        if (tf1Var != null) {
            defpackage.zd zdVar = tf1Var.EX2ajLj518q3;
            if (tf1Var.O21Gh3JCO74 == defpackage.sf1.hyi5MRgVJpZU) {
                defpackage.uo1 uo1VarCO8Wxv6r = defpackage.zt1.CO8Wxv6r(zdVar, guVar);
                defpackage.zd zdVar2 = uo1VarCO8Wxv6r.CGnIndwjik9;
                defpackage.tf1 tf1VarCGnIndwjik9 = defpackage.tf1.CGnIndwjik9(tf1Var, 0, 0, 0, 0, 0, zdVar2, null, 0, false, 3839);
                java.util.Iterator it = uo1VarCO8Wxv6r.wk61Lrtj.iterator();
                defpackage.tf1 tf1VarCGnIndwjik92 = tf1VarCGnIndwjik9;
                java.lang.String strKImmPBu5u = null;
                while (true) {
                    if (it.hasNext()) {
                        defpackage.to1 to1Var = (defpackage.to1) it.next();
                        if (defpackage.fc0.oA3oVL3lY(to1Var, defpackage.no1.CGnIndwjik9)) {
                            strKImmPBu5u = "The way is blocked.";
                        } else if (defpackage.fc0.oA3oVL3lY(to1Var, defpackage.po1.CGnIndwjik9)) {
                            strKImmPBu5u = defpackage.n51.KImmPBu5u("The workshop door is sealed. ", zdVar.AdtkbTq73SIl, " pages still missing.");
                        } else if (to1Var instanceof defpackage.ro1) {
                            int i = tf1VarCGnIndwjik92.ShamLDIR;
                            defpackage.c50 c50Var = tf1VarCGnIndwjik92.CGnIndwjik9;
                            defpackage.rc0 rc0Var = ((defpackage.ro1) to1Var).CGnIndwjik9;
                            tf1VarCGnIndwjik92 = defpackage.tf1.CGnIndwjik9(tf1VarCGnIndwjik92, ((rc0Var.bGtyfE77Qpby * c50Var.KImmPBu5u) / 2) + i, 0, 0, tf1VarCGnIndwjik92.AdtkbTq73SIl + (rc0Var == defpackage.rc0.FLORIN ? 1 : 0), 0, null, null, 0, false, 4023);
                            int i2 = zdVar2.AdtkbTq73SIl;
                            int iOrdinal = rc0Var.ordinal();
                            if (iOrdinal == 0) {
                                strKImmPBu5u = i2 == 0 ? "All pages found! The workshop door is open." : defpackage.n51.KImmPBu5u("Codex page recovered. ", i2, " left.");
                            } else if (iOrdinal == 1) {
                                strKImmPBu5u = "A gold florin for your purse.";
                            } else if (iOrdinal == 2) {
                                strKImmPBu5u = "Lantern lit. You see farther through the night.";
                            } else if (iOrdinal == 3) {
                                strKImmPBu5u = "Shadow cloak on. Guards cannot catch you for a while.";
                            } else {
                                if (iOrdinal != 4) {
                                    defpackage.t5.ShamLDIR();
                                    return null;
                                }
                                strKImmPBu5u = "Hourglass turned. +10 moves.";
                            }
                        } else {
                            boolean zOA3oVL3lY = defpackage.fc0.oA3oVL3lY(to1Var, defpackage.so1.CGnIndwjik9);
                            defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
                            if (zOA3oVL3lY) {
                                java.lang.Object objKImmPBu5u = KImmPBu5u(tf1VarCGnIndwjik92, x50Var);
                                if (objKImmPBu5u == woVar) {
                                    return objKImmPBu5u;
                                }
                            } else if (defpackage.fc0.oA3oVL3lY(to1Var, defpackage.oo1.CGnIndwjik9)) {
                                java.lang.Object objYbb6jpEh = ybb6jpEh(tf1VarCGnIndwjik92, defpackage.sf1.AdtkbTq73SIl, x50Var);
                                if (objYbb6jpEh == woVar) {
                                    return objYbb6jpEh;
                                }
                            } else {
                                if (!defpackage.fc0.oA3oVL3lY(to1Var, defpackage.qo1.CGnIndwjik9)) {
                                    defpackage.t5.ShamLDIR();
                                    return null;
                                }
                                java.lang.Object objYbb6jpEh2 = ybb6jpEh(tf1VarCGnIndwjik92, defpackage.sf1.KImmPBu5u, x50Var);
                                if (objYbb6jpEh2 == woVar) {
                                    return objYbb6jpEh2;
                                }
                            }
                        }
                    } else {
                        do {
                            value = fo1Var.getValue();
                            defpackage.tf1 tf1Var2 = tf1VarCGnIndwjik92;
                            defpackage.t50 t50Var = (defpackage.t50) value;
                            t50Var.getClass();
                            java.lang.String str = strKImmPBu5u == null ? t50Var.ShamLDIR : strKImmPBu5u;
                            int i3 = t50Var.hyi5MRgVJpZU;
                            if (strKImmPBu5u != null) {
                                i3++;
                            }
                            t50VarCGnIndwjik9 = defpackage.t50.CGnIndwjik9(t50Var, tf1Var2, false, null, str, i3, 6);
                            tf1VarCGnIndwjik92 = tf1Var2;
                        } while (!fo1Var.KImmPBu5u(value, t50VarCGnIndwjik9));
                    }
                }
            }
        }
        return defpackage.fv1.CGnIndwjik9;
    }

    /* JADX WARN: Removed duplicated region for block: B:52:0x00b2 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object EX2ajLj518q3(defpackage.ho hoVar) {
        defpackage.v50 v50Var;
        defpackage.sf1 sf1Var;
        defpackage.sf1 sf1Var2;
        if (hoVar instanceof defpackage.v50) {
            v50Var = (defpackage.v50) hoVar;
            int i = v50Var.SOLzqtJLiD8g;
            if ((i & Integer.MIN_VALUE) != 0) {
                v50Var.SOLzqtJLiD8g = i - Integer.MIN_VALUE;
            } else {
                v50Var = new defpackage.v50(this, hoVar);
            }
        }
        java.lang.Object objLQkLH9RtdoX = v50Var.EX2ajLj518q3;
        int i2 = v50Var.SOLzqtJLiD8g;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
        if (i2 == 0) {
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            v50Var.SOLzqtJLiD8g = 1;
            objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.AdtkbTq73SIl.wk61Lrtj, v50Var);
            if (objLQkLH9RtdoX != woVar) {
            }
        }
        if (i2 != 1) {
            if (i2 != 2) {
                if (i2 == 3) {
                    defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                    return fv1Var;
                }
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            this = v50Var.KImmPBu5u;
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            defpackage.c50 c50Var = ((defpackage.f61) objLQkLH9RtdoX).ShamLDIR;
            v50Var.KImmPBu5u = null;
            v50Var.SOLzqtJLiD8g = 3;
            return this.acT0gEliM(c50Var, v50Var) != woVar ? woVar : fv1Var;
        }
        defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
        defpackage.qh qhVar = (defpackage.qh) objLQkLH9RtdoX;
        defpackage.tf1 tf1Var = ((defpackage.t50) this.wk61Lrtj.getValue()).CGnIndwjik9;
        defpackage.sf1 sf1Var3 = defpackage.sf1.SOLzqtJLiD8g;
        defpackage.sf1 sf1Var4 = defpackage.sf1.O21Gh3JCO74;
        if (tf1Var != null && (sf1Var2 = tf1Var.O21Gh3JCO74) != sf1Var4 && sf1Var2 != sf1Var3 && qhVar != null && tf1Var.wk61Lrtj == qhVar.wk61Lrtj && tf1Var.m4CNag5J8Y == qhVar.m4CNag5J8Y) {
            defpackage.sf1 sf1Var5 = defpackage.sf1.bGtyfE77Qpby;
            if (sf1Var2 == sf1Var5) {
                cAUonbdEve(sf1Var5, defpackage.sf1.hyi5MRgVJpZU);
                return fv1Var;
            }
        }
        if (qhVar != null) {
            Ts5Bfxu7gi(qhVar);
            return fv1Var;
        }
        if (tf1Var != null && (sf1Var = tf1Var.O21Gh3JCO74) != sf1Var4 && sf1Var != sf1Var3) {
            return fv1Var;
        }
        v50Var.KImmPBu5u = this;
        v50Var.SOLzqtJLiD8g = 2;
        objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.hyi5MRgVJpZU.wk61Lrtj, v50Var);
        if (objLQkLH9RtdoX != woVar) {
            defpackage.c50 c50Var2 = ((defpackage.f61) objLQkLH9RtdoX).ShamLDIR;
            v50Var.KImmPBu5u = null;
            v50Var.SOLzqtJLiD8g = 3;
            if (this.acT0gEliM(c50Var2, v50Var) != woVar) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object KImmPBu5u(defpackage.tf1 tf1Var, defpackage.ho hoVar) {
        defpackage.u50 u50Var;
        defpackage.zd zdVar;
        int i;
        java.lang.Object objCGnIndwjik9;
        defpackage.tf1 tf1Var2;
        int i2;
        defpackage.tf1 tf1Var3;
        if (hoVar instanceof defpackage.u50) {
            u50Var = (defpackage.u50) hoVar;
            int i3 = u50Var.Wg7Cen3syT;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                u50Var.Wg7Cen3syT = i3 - Integer.MIN_VALUE;
            } else {
                u50Var = new defpackage.u50(this, hoVar);
            }
        }
        java.lang.Object obj = u50Var.ybb6jpEh;
        int i4 = u50Var.Wg7Cen3syT;
        java.lang.Object obj2 = defpackage.fv1.CGnIndwjik9;
        java.lang.Object obj3 = defpackage.wo.hyi5MRgVJpZU;
        if (i4 == 0) {
            defpackage.s20.oHwKnjYdY4X3(obj);
            zdVar = tf1Var.EX2ajLj518q3;
            defpackage.c50 c50Var = tf1Var.CGnIndwjik9;
            i = (((zdVar.KImmPBu5u * 3) + 100) * c50Var.KImmPBu5u) / 2;
            int i5 = c50Var.EX2ajLj518q3 + tf1Var.AdtkbTq73SIl;
            u50Var.KImmPBu5u = tf1Var;
            u50Var.EX2ajLj518q3 = zdVar;
            u50Var.SOLzqtJLiD8g = i;
            u50Var.Ts5Bfxu7gi = i5;
            u50Var.Wg7Cen3syT = 1;
            defpackage.o61 o61Var = this.hyi5MRgVJpZU;
            if (i5 > 0) {
                objCGnIndwjik9 = o61Var.CGnIndwjik9.CGnIndwjik9(new defpackage.gi0(i5), u50Var);
                if (objCGnIndwjik9 != obj3) {
                }
                if (objCGnIndwjik9 != obj3) {
                    tf1Var2 = tf1Var;
                    i2 = i5;
                }
                return obj3;
            }
            o61Var.getClass();
            objCGnIndwjik9 = obj2;
            if (objCGnIndwjik9 != obj3) {
            }
            return obj3;
        }
        if (i4 != 1) {
            if (i4 == 2) {
                defpackage.s20.oHwKnjYdY4X3(obj);
                return obj2;
            }
            if (i4 != 3) {
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            tf1Var3 = u50Var.O21Gh3JCO74;
            defpackage.s20.oHwKnjYdY4X3(obj);
            AdtkbTq73SIl(new defpackage.Ts5Bfxu7gi(12, tf1Var3));
            return obj2;
        }
        i2 = u50Var.Ts5Bfxu7gi;
        i = u50Var.SOLzqtJLiD8g;
        zdVar = u50Var.EX2ajLj518q3;
        defpackage.tf1 tf1Var4 = u50Var.KImmPBu5u;
        defpackage.s20.oHwKnjYdY4X3(obj);
        tf1Var2 = tf1Var4;
        int i6 = i;
        defpackage.tf1 tf1VarCGnIndwjik9 = defpackage.tf1.CGnIndwjik9(tf1Var2, tf1Var2.ShamLDIR + i6, 0, tf1Var2.bGtyfE77Qpby + i2, 0, zdVar.CGnIndwjik9.CGnIndwjik9() + tf1Var2.KImmPBu5u, null, null, i6, false, 2839);
        int i7 = tf1VarCGnIndwjik9.m4CNag5J8Y;
        if (i7 >= defpackage.ci.CGnIndwjik9.size() - 1) {
            int i8 = (((tf1VarCGnIndwjik9.hyi5MRgVJpZU * 200) + 500) * tf1Var2.CGnIndwjik9.KImmPBu5u) / 2;
            defpackage.tf1 tf1VarCGnIndwjik92 = defpackage.tf1.CGnIndwjik9(tf1VarCGnIndwjik9, tf1VarCGnIndwjik9.ShamLDIR + i8, 0, 0, 0, 0, null, null, i6 + i8, false, 3063);
            u50Var.KImmPBu5u = null;
            u50Var.EX2ajLj518q3 = null;
            u50Var.O21Gh3JCO74 = null;
            u50Var.SOLzqtJLiD8g = i6;
            u50Var.Ts5Bfxu7gi = i2;
            u50Var.Wg7Cen3syT = 2;
            if (O21Gh3JCO74(tf1VarCGnIndwjik92, true, "The Codex is complete!", u50Var) != obj3) {
                return obj2;
            }
        } else {
            defpackage.qh qhVar = new defpackage.qh(tf1VarCGnIndwjik9.CGnIndwjik9, tf1VarCGnIndwjik9.wk61Lrtj, i7 + 1, tf1VarCGnIndwjik9.ShamLDIR, tf1VarCGnIndwjik9.hyi5MRgVJpZU, tf1VarCGnIndwjik9.bGtyfE77Qpby, tf1VarCGnIndwjik9.KImmPBu5u);
            u50Var.KImmPBu5u = null;
            u50Var.EX2ajLj518q3 = null;
            u50Var.O21Gh3JCO74 = tf1VarCGnIndwjik9;
            u50Var.SOLzqtJLiD8g = i6;
            u50Var.Ts5Bfxu7gi = i2;
            u50Var.Wg7Cen3syT = 3;
            java.lang.Object objCGnIndwjik92 = this.AdtkbTq73SIl.CGnIndwjik9.CGnIndwjik9(new defpackage.Ts5Bfxu7gi(4, qhVar), u50Var);
            if (objCGnIndwjik92 != obj3) {
                objCGnIndwjik92 = obj2;
            }
            if (objCGnIndwjik92 != obj3) {
                tf1Var3 = tf1VarCGnIndwjik9;
                AdtkbTq73SIl(new defpackage.Ts5Bfxu7gi(12, tf1Var3));
                return obj2;
            }
        }
        return obj3;
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0146  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x016f  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0173  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x017b  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0180  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x018b  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x018e  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object O21Gh3JCO74(defpackage.tf1 tf1Var, boolean z, java.lang.String str, defpackage.ho hoVar) {
        defpackage.w50 w50Var;
        java.lang.String str2;
        boolean z2;
        defpackage.tf1 tf1Var2;
        boolean z3;
        int iCGnIndwjik9;
        int i;
        final int i2;
        int i3;
        defpackage.tf1 tf1Var3;
        java.lang.String str3;
        final boolean z4;
        java.lang.Object objCGnIndwjik9;
        int i4;
        boolean z5;
        java.lang.String str4;
        defpackage.tf1 tf1Var4;
        java.lang.Object objCGnIndwjik92;
        int i5;
        int i6;
        int i7;
        java.lang.String str5;
        defpackage.tf1 tf1Var5;
        defpackage.tf1 tf1VarCGnIndwjik9;
        java.lang.Object value;
        defpackage.t50 t50Var;
        if (hoVar instanceof defpackage.w50) {
            w50Var = (defpackage.w50) hoVar;
            int i8 = w50Var.acT0gEliM;
            if ((i8 & Integer.MIN_VALUE) != 0) {
                w50Var.acT0gEliM = i8 - Integer.MIN_VALUE;
            } else {
                w50Var = new defpackage.w50(this, hoVar);
            }
        }
        java.lang.Object objLQkLH9RtdoX = w50Var.oA3oVL3lY;
        int i9 = w50Var.acT0gEliM;
        defpackage.fo1 fo1Var = this.wk61Lrtj;
        defpackage.yi0 yi0Var = this.bGtyfE77Qpby;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
        if (i9 == 0) {
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            defpackage.w5D8CoWjInf3 w5d8cowjinf3 = yi0Var.wk61Lrtj;
            w50Var.KImmPBu5u = tf1Var;
            str2 = str;
            w50Var.EX2ajLj518q3 = str2;
            w50Var.O21Gh3JCO74 = z;
            w50Var.acT0gEliM = 1;
            objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(w5d8cowjinf3, w50Var);
            if (objLQkLH9RtdoX != woVar) {
                z2 = z;
                tf1Var2 = tf1Var;
            }
            return woVar;
        }
        if (i9 != 1) {
            if (i9 == 2) {
                i3 = w50Var.ybb6jpEh;
                i2 = w50Var.Ts5Bfxu7gi;
                i = w50Var.SOLzqtJLiD8g;
                z4 = w50Var.O21Gh3JCO74;
                str3 = w50Var.EX2ajLj518q3;
                tf1Var3 = w50Var.KImmPBu5u;
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                z3 = true;
                final int i10 = tf1Var3.m4CNag5J8Y + 1;
                final defpackage.c50 c50Var = tf1Var3.CGnIndwjik9;
                w50Var.KImmPBu5u = tf1Var3;
                w50Var.EX2ajLj518q3 = str3;
                w50Var.O21Gh3JCO74 = z4;
                w50Var.SOLzqtJLiD8g = i;
                w50Var.Ts5Bfxu7gi = i2;
                w50Var.ybb6jpEh = i3;
                w50Var.acT0gEliM = 3;
                objCGnIndwjik9 = this.hyi5MRgVJpZU.CGnIndwjik9.CGnIndwjik9(new defpackage.z30() { // from class: l61
                    @Override // defpackage.z30
                    public final java.lang.Object KImmPBu5u(java.lang.Object obj) {
                        defpackage.gt0 gt0Var = (defpackage.gt0) obj;
                        gt0Var.getClass();
                        defpackage.e51 e51Var = defpackage.jn0.hyi5MRgVJpZU;
                        java.lang.Integer num = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var);
                        gt0Var.hyi5MRgVJpZU(e51Var, java.lang.Integer.valueOf((num != null ? num.intValue() : 0) + 1));
                        defpackage.e51 e51Var2 = defpackage.jn0.AdtkbTq73SIl;
                        java.lang.Integer num2 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var2);
                        gt0Var.hyi5MRgVJpZU(e51Var2, java.lang.Integer.valueOf(java.lang.Math.max(num2 != null ? num2.intValue() : 0, i10)));
                        if (z4) {
                            defpackage.e51 e51Var3 = defpackage.jn0.bGtyfE77Qpby;
                            java.lang.Integer num3 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var3);
                            gt0Var.hyi5MRgVJpZU(e51Var3, java.lang.Integer.valueOf((num3 != null ? num3.intValue() : 0) + 1));
                            if (c50Var == defpackage.c50.Ts5Bfxu7gi) {
                                gt0Var.ShamLDIR(defpackage.jn0.KImmPBu5u, java.lang.Boolean.TRUE);
                            }
                        }
                        int i11 = i2;
                        if (i11 > 0) {
                            defpackage.e51 e51Var4 = defpackage.jn0.CGnIndwjik9;
                            java.lang.Integer num4 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var4);
                            gt0Var.hyi5MRgVJpZU(e51Var4, java.lang.Integer.valueOf((num4 != null ? num4.intValue() : 0) + i11));
                        }
                        return defpackage.fv1.CGnIndwjik9;
                    }
                }, w50Var);
                if (objCGnIndwjik9 != woVar) {
                    objCGnIndwjik9 = fv1Var;
                }
                if (objCGnIndwjik9 != woVar) {
                    i4 = i;
                    z5 = z4;
                    str4 = str3;
                    tf1Var4 = tf1Var3;
                    w50Var.KImmPBu5u = tf1Var4;
                    w50Var.EX2ajLj518q3 = str4;
                    w50Var.O21Gh3JCO74 = z5;
                    w50Var.SOLzqtJLiD8g = i4;
                    w50Var.Ts5Bfxu7gi = i2;
                    w50Var.ybb6jpEh = i3;
                    w50Var.acT0gEliM = 4;
                    objCGnIndwjik92 = this.AdtkbTq73SIl.CGnIndwjik9.CGnIndwjik9(new defpackage.z3(15), w50Var);
                    if (objCGnIndwjik92 != woVar) {
                    }
                    if (objCGnIndwjik92 != woVar) {
                    }
                }
                return woVar;
            }
            if (i9 != 3) {
                if (i9 != 4) {
                    defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                int i11 = w50Var.ybb6jpEh;
                i6 = w50Var.Ts5Bfxu7gi;
                i7 = w50Var.SOLzqtJLiD8g;
                z5 = w50Var.O21Gh3JCO74;
                java.lang.String str6 = w50Var.EX2ajLj518q3;
                tf1Var5 = w50Var.KImmPBu5u;
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                i5 = i11;
                str5 = str6;
                z3 = true;
                tf1VarCGnIndwjik9 = defpackage.tf1.CGnIndwjik9(tf1Var5, 0, 0, tf1Var5.bGtyfE77Qpby + i6, 0, i5, null, !z5 ? defpackage.sf1.SOLzqtJLiD8g : defpackage.sf1.O21Gh3JCO74, 0, tf1Var5.ShamLDIR <= i7 ? z3 : false, 1311);
                do {
                    value = fo1Var.getValue();
                    t50Var = (defpackage.t50) value;
                    t50Var.getClass();
                } while (!fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, tf1VarCGnIndwjik9, false, null, str5, t50Var.hyi5MRgVJpZU + 1, 6)));
                return fv1Var;
            }
            i3 = w50Var.ybb6jpEh;
            i2 = w50Var.Ts5Bfxu7gi;
            i4 = w50Var.SOLzqtJLiD8g;
            boolean z6 = w50Var.O21Gh3JCO74;
            str4 = w50Var.EX2ajLj518q3;
            tf1Var4 = w50Var.KImmPBu5u;
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            z5 = z6;
            z3 = true;
            w50Var.KImmPBu5u = tf1Var4;
            w50Var.EX2ajLj518q3 = str4;
            w50Var.O21Gh3JCO74 = z5;
            w50Var.SOLzqtJLiD8g = i4;
            w50Var.Ts5Bfxu7gi = i2;
            w50Var.ybb6jpEh = i3;
            w50Var.acT0gEliM = 4;
            objCGnIndwjik92 = this.AdtkbTq73SIl.CGnIndwjik9.CGnIndwjik9(new defpackage.z3(15), w50Var);
            if (objCGnIndwjik92 != woVar) {
                objCGnIndwjik92 = fv1Var;
            }
            if (objCGnIndwjik92 != woVar) {
                i5 = i3;
                i6 = i2;
                i7 = i4;
                str5 = str4;
                tf1Var5 = tf1Var4;
                tf1VarCGnIndwjik9 = defpackage.tf1.CGnIndwjik9(tf1Var5, 0, 0, tf1Var5.bGtyfE77Qpby + i6, 0, i5, null, !z5 ? defpackage.sf1.SOLzqtJLiD8g : defpackage.sf1.O21Gh3JCO74, 0, tf1Var5.ShamLDIR <= i7 ? z3 : false, 1311);
                do {
                    value = fo1Var.getValue();
                    t50Var = (defpackage.t50) value;
                    t50Var.getClass();
                } while (!fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, tf1VarCGnIndwjik9, false, null, str5, t50Var.hyi5MRgVJpZU + 1, 6)));
                return fv1Var;
            }
            return woVar;
        }
        boolean z7 = w50Var.O21Gh3JCO74;
        str2 = w50Var.EX2ajLj518q3;
        tf1Var2 = w50Var.KImmPBu5u;
        defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
        z2 = z7;
        defpackage.mh1 mh1Var = (defpackage.mh1) defpackage.bj.Y1mLGweN((java.util.List) objLQkLH9RtdoX);
        int i12 = mh1Var != null ? mh1Var.CGnIndwjik9 : 0;
        int i13 = z2 ? 50 : tf1Var2.AdtkbTq73SIl;
        if (z2) {
            iCGnIndwjik9 = tf1Var2.KImmPBu5u;
            z3 = true;
        } else {
            int i14 = tf1Var2.KImmPBu5u;
            defpackage.zd zdVar = tf1Var2.EX2ajLj518q3;
            z3 = true;
            iCGnIndwjik9 = i14 + (zdVar.CGnIndwjik9.CGnIndwjik9() - zdVar.AdtkbTq73SIl);
        }
        int i15 = iCGnIndwjik9;
        defpackage.mh1 mh1Var2 = new defpackage.mh1(tf1Var2.ShamLDIR, tf1Var2.m4CNag5J8Y + 1, i15, tf1Var2.CGnIndwjik9, z2, ((defpackage.t50) fo1Var.getValue()).m4CNag5J8Y.wk61Lrtj, java.lang.System.currentTimeMillis());
        boolean z8 = z2;
        w50Var.KImmPBu5u = tf1Var2;
        w50Var.EX2ajLj518q3 = str2;
        w50Var.O21Gh3JCO74 = z8;
        w50Var.SOLzqtJLiD8g = i12;
        w50Var.Ts5Bfxu7gi = i13;
        w50Var.ybb6jpEh = i15;
        w50Var.acT0gEliM = 2;
        java.lang.Object objCGnIndwjik93 = yi0Var.CGnIndwjik9.CGnIndwjik9(new defpackage.m4CNag5J8Y(19, yi0Var, mh1Var2), w50Var);
        if (objCGnIndwjik93 != woVar) {
            objCGnIndwjik93 = fv1Var;
        }
        if (objCGnIndwjik93 != woVar) {
            i = i12;
            i2 = i13;
            i3 = i15;
            tf1Var3 = tf1Var2;
            str3 = str2;
            z4 = z8;
            final int i102 = tf1Var3.m4CNag5J8Y + 1;
            final defpackage.c50 c50Var2 = tf1Var3.CGnIndwjik9;
            w50Var.KImmPBu5u = tf1Var3;
            w50Var.EX2ajLj518q3 = str3;
            w50Var.O21Gh3JCO74 = z4;
            w50Var.SOLzqtJLiD8g = i;
            w50Var.Ts5Bfxu7gi = i2;
            w50Var.ybb6jpEh = i3;
            w50Var.acT0gEliM = 3;
            objCGnIndwjik9 = this.hyi5MRgVJpZU.CGnIndwjik9.CGnIndwjik9(new defpackage.z30() { // from class: l61
                @Override // defpackage.z30
                public final java.lang.Object KImmPBu5u(java.lang.Object obj) {
                    defpackage.gt0 gt0Var = (defpackage.gt0) obj;
                    gt0Var.getClass();
                    defpackage.e51 e51Var = defpackage.jn0.hyi5MRgVJpZU;
                    java.lang.Integer num = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var);
                    gt0Var.hyi5MRgVJpZU(e51Var, java.lang.Integer.valueOf((num != null ? num.intValue() : 0) + 1));
                    defpackage.e51 e51Var2 = defpackage.jn0.AdtkbTq73SIl;
                    java.lang.Integer num2 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var2);
                    gt0Var.hyi5MRgVJpZU(e51Var2, java.lang.Integer.valueOf(java.lang.Math.max(num2 != null ? num2.intValue() : 0, i102)));
                    if (z4) {
                        defpackage.e51 e51Var3 = defpackage.jn0.bGtyfE77Qpby;
                        java.lang.Integer num3 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var3);
                        gt0Var.hyi5MRgVJpZU(e51Var3, java.lang.Integer.valueOf((num3 != null ? num3.intValue() : 0) + 1));
                        if (c50Var2 == defpackage.c50.Ts5Bfxu7gi) {
                            gt0Var.ShamLDIR(defpackage.jn0.KImmPBu5u, java.lang.Boolean.TRUE);
                        }
                    }
                    int i112 = i2;
                    if (i112 > 0) {
                        defpackage.e51 e51Var4 = defpackage.jn0.CGnIndwjik9;
                        java.lang.Integer num4 = (java.lang.Integer) gt0Var.m4CNag5J8Y(e51Var4);
                        gt0Var.hyi5MRgVJpZU(e51Var4, java.lang.Integer.valueOf((num4 != null ? num4.intValue() : 0) + i112));
                    }
                    return defpackage.fv1.CGnIndwjik9;
                }
            }, w50Var);
            if (objCGnIndwjik9 != woVar) {
            }
            if (objCGnIndwjik9 != woVar) {
            }
        }
        return woVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:96:0x014f, code lost:
    
        if (r10 == r4) goto L101;
     */
    /* JADX WARN: Removed duplicated region for block: B:101:0x0162 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0163 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @Override // defpackage.fu0
    /* renamed from: SOLzqtJLiD8g, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object hyi5MRgVJpZU(defpackage.b50 b50Var, defpackage.ho hoVar) {
        defpackage.x50 x50Var;
        defpackage.c50 c50Var;
        defpackage.sf1 sf1Var;
        if (hoVar instanceof defpackage.x50) {
            x50Var = (defpackage.x50) hoVar;
            int i = x50Var.SOLzqtJLiD8g;
            if ((i & Integer.MIN_VALUE) != 0) {
                x50Var.SOLzqtJLiD8g = i - Integer.MIN_VALUE;
            } else {
                x50Var = new defpackage.x50(this, hoVar);
            }
        }
        java.lang.Object objLQkLH9RtdoX = x50Var.EX2ajLj518q3;
        int i2 = x50Var.SOLzqtJLiD8g;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
        switch (i2) {
            case 0:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                boolean zOA3oVL3lY = defpackage.fc0.oA3oVL3lY(b50Var, defpackage.s40.CGnIndwjik9);
                defpackage.fo1 fo1Var = this.wk61Lrtj;
                if (zOA3oVL3lY) {
                    if (((defpackage.t50) fo1Var.getValue()).CGnIndwjik9 == null) {
                        x50Var.SOLzqtJLiD8g = 1;
                        if (Wg7Cen3syT(x50Var) == woVar) {
                            return woVar;
                        }
                    }
                    return fv1Var;
                }
                if (b50Var instanceof defpackage.z40) {
                    defpackage.c50 c50Var2 = ((defpackage.z40) b50Var).CGnIndwjik9;
                    x50Var.SOLzqtJLiD8g = 2;
                    if (acT0gEliM(c50Var2, x50Var) != woVar) {
                        return fv1Var;
                    }
                } else if (defpackage.fc0.oA3oVL3lY(b50Var, defpackage.r40.CGnIndwjik9)) {
                    x50Var.SOLzqtJLiD8g = 3;
                    if (EX2ajLj518q3(x50Var) == woVar) {
                    }
                } else if (b50Var instanceof defpackage.t40) {
                    defpackage.gu guVar = ((defpackage.t40) b50Var).CGnIndwjik9;
                    x50Var.SOLzqtJLiD8g = 4;
                    if (AqsOwbEF(guVar, x50Var) == woVar) {
                    }
                } else {
                    if (!defpackage.fc0.oA3oVL3lY(b50Var, defpackage.a50.CGnIndwjik9)) {
                        boolean zOA3oVL3lY2 = defpackage.fc0.oA3oVL3lY(b50Var, defpackage.v40.CGnIndwjik9);
                        defpackage.sf1 sf1Var2 = defpackage.sf1.bGtyfE77Qpby;
                        defpackage.sf1 sf1Var3 = defpackage.sf1.hyi5MRgVJpZU;
                        if (zOA3oVL3lY2) {
                            cAUonbdEve(sf1Var3, sf1Var2);
                            return fv1Var;
                        }
                        if (defpackage.fc0.oA3oVL3lY(b50Var, defpackage.x40.CGnIndwjik9)) {
                            cAUonbdEve(sf1Var2, sf1Var3);
                            return fv1Var;
                        }
                        if (!defpackage.fc0.oA3oVL3lY(b50Var, defpackage.y40.CGnIndwjik9)) {
                            if (defpackage.fc0.oA3oVL3lY(b50Var, defpackage.u40.CGnIndwjik9)) {
                                x50Var.SOLzqtJLiD8g = 6;
                                if (oA3oVL3lY(x50Var) == woVar) {
                                }
                            } else {
                                if (!defpackage.fc0.oA3oVL3lY(b50Var, defpackage.w40.CGnIndwjik9)) {
                                    defpackage.t5.ShamLDIR();
                                    return null;
                                }
                                defpackage.tf1 tf1Var = ((defpackage.t50) fo1Var.getValue()).CGnIndwjik9;
                                if (tf1Var != null && (sf1Var = tf1Var.O21Gh3JCO74) != defpackage.sf1.O21Gh3JCO74 && sf1Var != defpackage.sf1.SOLzqtJLiD8g) {
                                    return fv1Var;
                                }
                                if (tf1Var == null || (c50Var = tf1Var.CGnIndwjik9) == null) {
                                    x50Var.KImmPBu5u = this;
                                    x50Var.SOLzqtJLiD8g = 7;
                                    objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.hyi5MRgVJpZU.wk61Lrtj, x50Var);
                                    break;
                                } else {
                                    x50Var.KImmPBu5u = null;
                                    x50Var.SOLzqtJLiD8g = 8;
                                    if (this.acT0gEliM(c50Var, x50Var) != woVar) {
                                    }
                                }
                            }
                            return woVar;
                        }
                        defpackage.tf1 tf1Var2 = ((defpackage.t50) fo1Var.getValue()).CGnIndwjik9;
                        if (tf1Var2 != null) {
                            defpackage.sf1 sf1Var4 = tf1Var2.O21Gh3JCO74;
                            defpackage.sf1 sf1Var5 = defpackage.sf1.AdtkbTq73SIl;
                            defpackage.sf1 sf1Var6 = defpackage.sf1.KImmPBu5u;
                            if (sf1Var4 == sf1Var5 || sf1Var4 == sf1Var6) {
                                AdtkbTq73SIl(new defpackage.m4CNag5J8Y(11, tf1Var2, defpackage.zt1.mbwb7dCOYb(tf1Var2.EX2ajLj518q3, sf1Var4 == sf1Var6)));
                                return fv1Var;
                            }
                        }
                        return fv1Var;
                    }
                    x50Var.SOLzqtJLiD8g = 5;
                    if (AqsOwbEF(null, x50Var) == woVar) {
                    }
                }
                break;
            case 1:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.FLOAT_FIELD_NUMBER /* 2 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.INTEGER_FIELD_NUMBER /* 3 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.LONG_FIELD_NUMBER /* 4 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.STRING_FIELD_NUMBER /* 5 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.STRING_SET_FIELD_NUMBER /* 6 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            case defpackage.o51.DOUBLE_FIELD_NUMBER /* 7 */:
                this = x50Var.KImmPBu5u;
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                c50Var = ((defpackage.f61) objLQkLH9RtdoX).ShamLDIR;
                x50Var.KImmPBu5u = null;
                x50Var.SOLzqtJLiD8g = 8;
                if (this.acT0gEliM(c50Var, x50Var) != woVar) {
                }
                break;
            case defpackage.o51.BYTES_FIELD_NUMBER /* 8 */:
                defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                return fv1Var;
            default:
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:108:0x0253  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void Ts5Bfxu7gi(defpackage.qh qhVar) {
        defpackage.nj0 nj0Var;
        int i;
        int i2;
        defpackage.c50 c50Var;
        int i3;
        java.lang.Object next;
        java.util.Map map;
        int i4;
        long j = qhVar.wk61Lrtj;
        int i5 = qhVar.m4CNag5J8Y;
        defpackage.c50 c50Var2 = qhVar.CGnIndwjik9;
        c50Var2.getClass();
        long j2 = (i5 * 7919) + (j * 31) + 17;
        int i6 = (int) j2;
        int i7 = (int) (j2 >> 32);
        int i8 = ~i6;
        defpackage.d12 d12Var = new defpackage.d12();
        d12Var.bGtyfE77Qpby = i6;
        d12Var.AdtkbTq73SIl = i7;
        int i9 = 0;
        d12Var.KImmPBu5u = 0;
        d12Var.EX2ajLj518q3 = 0;
        d12Var.O21Gh3JCO74 = i8;
        d12Var.SOLzqtJLiD8g = (i6 << 10) ^ (i7 >>> 4);
        if ((i6 | i7 | i8) == 0) {
            defpackage.t5.acT0gEliM("Initial state must have at least one non-zero element.");
            return;
        }
        for (int i10 = 0; i10 < 64; i10++) {
            d12Var.ShamLDIR();
        }
        int i11 = 0;
        while (true) {
            defpackage.rc0 rc0Var = defpackage.rc0.HOURGLASS;
            defpackage.rc0 rc0Var2 = defpackage.rc0.PAGE;
            defpackage.rc0 rc0Var3 = defpackage.rc0.FLORIN;
            if (i11 < 300) {
                defpackage.q41 q41Var = new defpackage.q41(d12Var.hyi5MRgVJpZU(7), 8);
                defpackage.q41 q41Var2 = new defpackage.q41(d12Var.hyi5MRgVJpZU(7), i9);
                float f = (i5 * 0.012f) + 0.2f;
                java.util.LinkedHashSet linkedHashSet = new java.util.LinkedHashSet();
                int i12 = 0;
                int i13 = 2;
                while (true) {
                    if (i12 >= 9) {
                        break;
                    }
                    for (int i14 = 0; i14 < 7; i14++) {
                        defpackage.q41 q41Var3 = new defpackage.q41(i14, i12);
                        if (!q41Var3.equals(q41Var) && !q41Var3.equals(q41Var2) && d12Var.m4CNag5J8Y() < f) {
                            linkedHashSet.add(q41Var3);
                        }
                    }
                    i12++;
                }
                java.util.LinkedHashSet linkedHashSet2 = new java.util.LinkedHashSet();
                int i15 = 0;
                for (i = 9; i15 < i; i = 9) {
                    for (int i16 = 0; i16 < 7; i16++) {
                        linkedHashSet2.add(new defpackage.q41(i16, i15));
                    }
                    i15++;
                }
                java.util.Set setKeySet = defpackage.j20.SOLzqtJLiD8g(q41Var, defpackage.lk1.hwJeYkFOwb2F(linkedHashSet2, linkedHashSet)).keySet();
                nj0Var = null;
                if (setKeySet.contains(q41Var2)) {
                    java.util.Set set = setKeySet;
                    defpackage.gj.XQehVY57avk(defpackage.lk1.hwJeYkFOwb2F(linkedHashSet2, set), linkedHashSet);
                    java.util.Map mapSOLzqtJLiD8g = defpackage.j20.SOLzqtJLiD8g(q41Var, setKeySet);
                    java.util.ArrayList arrayList = new java.util.ArrayList();
                    java.util.LinkedHashSet linkedHashSet3 = new java.util.LinkedHashSet();
                    i2 = i11;
                    int iMin = java.lang.Math.min((i5 / 2) + 1, 5);
                    int i17 = 0;
                    while (arrayList.size() < iMin && i17 < 60) {
                        int i18 = i17 + 1;
                        java.util.ArrayList arrayList2 = new java.util.ArrayList();
                        for (java.lang.Object obj : set) {
                            int i19 = iMin;
                            defpackage.q41 q41Var4 = (defpackage.q41) obj;
                            java.lang.Integer num = (java.lang.Integer) mapSOLzqtJLiD8g.get(q41Var4);
                            if (num != null) {
                                int iIntValue = num.intValue();
                                map = mapSOLzqtJLiD8g;
                                i4 = iIntValue;
                            } else {
                                map = mapSOLzqtJLiD8g;
                                i4 = 0;
                            }
                            int i20 = i18;
                            if (i4 >= 3 && !defpackage.fc0.oA3oVL3lY(q41Var4, q41Var2) && !linkedHashSet3.contains(q41Var4)) {
                                arrayList2.add(obj);
                            }
                            iMin = i19;
                            mapSOLzqtJLiD8g = map;
                            i18 = i20;
                        }
                        int i21 = iMin;
                        java.util.Map map2 = mapSOLzqtJLiD8g;
                        int i22 = i18;
                        defpackage.q41 q41Var5 = (defpackage.q41) (arrayList2.isEmpty() ? null : arrayList2.get(d12Var.hyi5MRgVJpZU(arrayList2.size())));
                        if (q41Var5 == null) {
                            break;
                        }
                        boolean zWk61Lrtj = d12Var.wk61Lrtj();
                        int iHyi5MRgVJpZU = d12Var.hyi5MRgVJpZU(3) + 2;
                        defpackage.gu guVar = zWk61Lrtj ? defpackage.gu.O21Gh3JCO74 : defpackage.gu.KImmPBu5u;
                        defpackage.gu guVar2 = zWk61Lrtj ? defpackage.gu.EX2ajLj518q3 : defpackage.gu.AdtkbTq73SIl;
                        defpackage.a6 a6Var = new defpackage.a6();
                        a6Var.addLast(q41Var5);
                        defpackage.rc0 rc0Var4 = rc0Var;
                        defpackage.c50 c50Var3 = c50Var2;
                        boolean z = true;
                        boolean z2 = false;
                        boolean z3 = false;
                        defpackage.q41 q41Var6 = q41Var5;
                        while (a6Var.AdtkbTq73SIl < iHyi5MRgVJpZU && (!z2 || !z3)) {
                            if (z && !z2) {
                                defpackage.q41 q41VarCGnIndwjik9 = q41Var6.CGnIndwjik9(guVar);
                                if (!setKeySet.contains(q41VarCGnIndwjik9) || linkedHashSet3.contains(q41VarCGnIndwjik9) || q41VarCGnIndwjik9.equals(q41Var) || q41VarCGnIndwjik9.equals(q41Var2)) {
                                    z2 = true;
                                } else {
                                    a6Var.addLast(q41VarCGnIndwjik9);
                                    q41Var6 = q41VarCGnIndwjik9;
                                }
                            } else if (!z3) {
                                defpackage.q41 q41VarCGnIndwjik92 = q41Var5.CGnIndwjik9(guVar2);
                                if (!setKeySet.contains(q41VarCGnIndwjik92) || linkedHashSet3.contains(q41VarCGnIndwjik92) || q41VarCGnIndwjik92.equals(q41Var) || q41VarCGnIndwjik92.equals(q41Var2)) {
                                    z3 = true;
                                } else {
                                    a6Var.addFirst(q41VarCGnIndwjik92);
                                    q41Var5 = q41VarCGnIndwjik92;
                                }
                            }
                            z = !z;
                        }
                        java.util.List listP8c71TKA3w = defpackage.bj.P8c71TKA3w(a6Var);
                        if (listP8c71TKA3w.size() >= i13) {
                            java.util.Map mapSOLzqtJLiD8g2 = defpackage.j20.SOLzqtJLiD8g(q41Var, defpackage.lk1.hwJeYkFOwb2F(setKeySet, defpackage.lk1.vkFkPUN4(linkedHashSet3, listP8c71TKA3w)));
                            if (mapSOLzqtJLiD8g2.containsKey(q41Var2) && mapSOLzqtJLiD8g2.size() >= 14) {
                                defpackage.gj.XQehVY57avk(listP8c71TKA3w, linkedHashSet3);
                                arrayList.add(new defpackage.v70(listP8c71TKA3w, d12Var.hyi5MRgVJpZU(listP8c71TKA3w.size()), d12Var.wk61Lrtj()));
                            }
                        }
                        c50Var2 = c50Var3;
                        iMin = i21;
                        mapSOLzqtJLiD8g = map2;
                        i17 = i22;
                        rc0Var = rc0Var4;
                        i13 = 2;
                    }
                    defpackage.rc0 rc0Var5 = rc0Var;
                    c50Var = c50Var2;
                    if (arrayList.isEmpty()) {
                        nj0Var = null;
                    } else {
                        java.util.Map mapSOLzqtJLiD8g3 = defpackage.j20.SOLzqtJLiD8g(q41Var, defpackage.lk1.hwJeYkFOwb2F(setKeySet, linkedHashSet3));
                        java.util.Set setKeySet2 = mapSOLzqtJLiD8g3.keySet();
                        java.util.ArrayList arrayList3 = new java.util.ArrayList();
                        for (java.lang.Object obj2 : setKeySet2) {
                            defpackage.q41 q41Var7 = (defpackage.q41) obj2;
                            if (!defpackage.fc0.oA3oVL3lY(q41Var7, q41Var) && !defpackage.fc0.oA3oVL3lY(q41Var7, q41Var2)) {
                                arrayList3.add(obj2);
                            }
                        }
                        java.util.ArrayList arrayList4 = new java.util.ArrayList(arrayList3);
                        defpackage.bj.S1LnOOn8(arrayList4, d12Var);
                        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
                        int i23 = i5 / 3;
                        int i24 = i23 + 2;
                        java.util.ArrayList arrayList5 = new java.util.ArrayList();
                        int size = arrayList4.size();
                        int i25 = 0;
                        while (i25 < size) {
                            defpackage.q41 q41Var8 = q41Var;
                            java.lang.Object obj3 = arrayList4.get(i25);
                            int i26 = i25 + 1;
                            java.lang.Integer num2 = (java.lang.Integer) mapSOLzqtJLiD8g3.get((defpackage.q41) obj3);
                            java.util.Map map3 = mapSOLzqtJLiD8g3;
                            if ((num2 != null ? num2.intValue() : 0) >= 2) {
                                arrayList5.add(obj3);
                            }
                            q41Var = q41Var8;
                            i25 = i26;
                            mapSOLzqtJLiD8g3 = map3;
                        }
                        defpackage.q41 q41Var9 = q41Var;
                        java.util.List listCflp9DjM = defpackage.bj.Cflp9DjM(i24, arrayList5);
                        if (listCflp9DjM.size() >= i24) {
                            java.util.Iterator it = listCflp9DjM.iterator();
                            while (it.hasNext()) {
                                linkedHashMap.put((defpackage.q41) it.next(), rc0Var2);
                            }
                            java.util.ArrayList arrayList6 = new java.util.ArrayList();
                            int size2 = arrayList4.size();
                            int i27 = 0;
                            while (i27 < size2) {
                                java.lang.Object obj4 = arrayList4.get(i27);
                                i27++;
                                if (!linkedHashMap.containsKey((defpackage.q41) obj4)) {
                                    arrayList6.add(obj4);
                                }
                            }
                            java.util.ArrayList arrayList7 = new java.util.ArrayList(arrayList6);
                            int i28 = i23 + 3;
                            for (int i29 = 0; i29 < i28; i29++) {
                                defpackage.j20.AdtkbTq73SIl(arrayList7, linkedHashMap, rc0Var3);
                            }
                            if (d12Var.m4CNag5J8Y() < 0.55f) {
                                defpackage.j20.AdtkbTq73SIl(arrayList7, linkedHashMap, defpackage.rc0.LANTERN);
                            }
                            if (i5 >= 1 && d12Var.m4CNag5J8Y() < 0.6f) {
                                defpackage.j20.AdtkbTq73SIl(arrayList7, linkedHashMap, defpackage.rc0.CLOAK);
                            }
                            if (d12Var.m4CNag5J8Y() < 0.6f) {
                                defpackage.j20.AdtkbTq73SIl(arrayList7, linkedHashMap, rc0Var5);
                            }
                            java.util.ArrayList arrayList8 = new java.util.ArrayList();
                            int size3 = arrayList.size();
                            int i30 = 0;
                            while (i30 < size3) {
                                java.lang.Object obj5 = arrayList.get(i30);
                                i30++;
                                if (((defpackage.v70) obj5).CGnIndwjik9.size() >= 3) {
                                    arrayList8.add(obj5);
                                }
                            }
                            java.util.ArrayList arrayList9 = new java.util.ArrayList();
                            int size4 = arrayList8.size();
                            int i31 = 0;
                            while (i31 < size4) {
                                java.lang.Object obj6 = arrayList8.get(i31);
                                i31++;
                                defpackage.gj.XQehVY57avk(((defpackage.v70) obj6).CGnIndwjik9, arrayList9);
                            }
                            java.util.List listKZEkJ0vgS = defpackage.bj.KZEkJ0vgS(arrayList9);
                            defpackage.bj.S1LnOOn8(listKZEkJ0vgS, d12Var);
                            java.util.Iterator it2 = defpackage.bj.Cflp9DjM((i5 / 4) + 1, listKZEkJ0vgS).iterator();
                            while (it2.hasNext()) {
                                linkedHashMap.put((defpackage.q41) it2.next(), rc0Var3);
                            }
                            java.util.Set setHwJeYkFOwb2F = defpackage.lk1.hwJeYkFOwb2F(setKeySet, linkedHashSet3);
                            java.util.ArrayList arrayList10 = new java.util.ArrayList(listCflp9DjM);
                            defpackage.q41 q41Var10 = q41Var9;
                            int iIntValue2 = 0;
                            while (!arrayList10.isEmpty()) {
                                java.util.Map mapSOLzqtJLiD8g4 = defpackage.j20.SOLzqtJLiD8g(q41Var10, setHwJeYkFOwb2F);
                                java.util.Iterator it3 = arrayList10.iterator();
                                if (it3.hasNext()) {
                                    next = it3.next();
                                    if (it3.hasNext()) {
                                        java.lang.Integer num3 = (java.lang.Integer) mapSOLzqtJLiD8g4.get((defpackage.q41) next);
                                        int iIntValue3 = num3 != null ? num3.intValue() : Integer.MAX_VALUE;
                                        do {
                                            java.lang.Object next2 = it3.next();
                                            java.lang.Integer num4 = (java.lang.Integer) mapSOLzqtJLiD8g4.get((defpackage.q41) next2);
                                            int iIntValue4 = num4 != null ? num4.intValue() : Integer.MAX_VALUE;
                                            if (iIntValue3 > iIntValue4) {
                                                next = next2;
                                                iIntValue3 = iIntValue4;
                                            }
                                        } while (it3.hasNext());
                                    }
                                } else {
                                    next = null;
                                }
                                defpackage.q41 q41Var11 = (defpackage.q41) next;
                                if (q41Var11 == null) {
                                    break;
                                }
                                java.lang.Integer num5 = (java.lang.Integer) mapSOLzqtJLiD8g4.get(q41Var11);
                                iIntValue2 += num5 != null ? num5.intValue() : 0;
                                arrayList10.remove(q41Var11);
                                q41Var10 = q41Var11;
                            }
                            java.lang.Integer num6 = (java.lang.Integer) defpackage.j20.SOLzqtJLiD8g(q41Var10, setHwJeYkFOwb2F).get(q41Var2);
                            int iIntValue5 = iIntValue2 + (num6 != null ? num6.intValue() : 0);
                            int iOrdinal = c50Var.ordinal();
                            if (iOrdinal == 0) {
                                i3 = ((iIntValue5 * 19) / 10) + 14;
                            } else {
                                if (iOrdinal != 1) {
                                    defpackage.t5.ShamLDIR();
                                    return;
                                }
                                i3 = ((iIntValue5 * 15) / 10) + 10;
                            }
                            nj0Var = new defpackage.nj0(i5, 7, 9, linkedHashSet, q41Var9, q41Var2, linkedHashMap, arrayList, i3);
                        }
                    }
                } else {
                    i2 = i11;
                    c50Var = c50Var2;
                }
                if (nj0Var != null) {
                    break;
                }
                i11 = i2 + 1;
                c50Var2 = c50Var;
                i9 = 0;
            } else {
                defpackage.c50 c50Var4 = c50Var2;
                nj0Var = new defpackage.nj0(i5, 7, 9, defpackage.lk1.ixcZHu7WE(new defpackage.q41(1, 2), new defpackage.q41(2, 2), new defpackage.q41(4, 4), new defpackage.q41(5, 4), new defpackage.q41(1, 6), new defpackage.q41(2, 6)), new defpackage.q41(0, 8), new defpackage.q41(6, 0), defpackage.gn0.XQehVY57avk(new defpackage.p11(new defpackage.q41(0, 3), rc0Var2), new defpackage.p11(new defpackage.q41(6, 6), rc0Var2), new defpackage.p11(new defpackage.q41(3, 7), rc0Var3), new defpackage.p11(new defpackage.q41(2, 0), rc0Var3), new defpackage.p11(new defpackage.q41(5, 1), rc0Var)), defpackage.ec0.hfi1lqIFl(new defpackage.v70(defpackage.ec0.QTXOIjVJtE(new defpackage.q41(3, 3), new defpackage.q41(4, 3), new defpackage.q41(5, 3)), 0, true)), c50Var4 == defpackage.c50.Ts5Bfxu7gi ? 34 : 44);
            }
        }
        defpackage.c50 c50Var5 = qhVar.CGnIndwjik9;
        long j3 = qhVar.wk61Lrtj;
        int i32 = qhVar.m4CNag5J8Y;
        int i33 = qhVar.ShamLDIR;
        int i34 = qhVar.hyi5MRgVJpZU;
        AdtkbTq73SIl(new defpackage.m4CNag5J8Y(12, new defpackage.tf1(c50Var5, j3, i32, i33, i34 < 1 ? 1 : i34, qhVar.bGtyfE77Qpby, 0, qhVar.AdtkbTq73SIl, defpackage.zt1.fwzzEzgVd5(nj0Var), defpackage.sf1.hyi5MRgVJpZU, 0, false), nj0Var));
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0076 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object Wg7Cen3syT(defpackage.ho hoVar) {
        defpackage.z50 z50Var;
        if (hoVar instanceof defpackage.z50) {
            z50Var = (defpackage.z50) hoVar;
            int i = z50Var.SOLzqtJLiD8g;
            if ((i & Integer.MIN_VALUE) != 0) {
                z50Var.SOLzqtJLiD8g = i - Integer.MIN_VALUE;
            } else {
                z50Var = new defpackage.z50(this, hoVar);
            }
        }
        java.lang.Object objLQkLH9RtdoX = z50Var.EX2ajLj518q3;
        int i2 = z50Var.SOLzqtJLiD8g;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
        if (i2 == 0) {
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            z50Var.SOLzqtJLiD8g = 1;
            objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.AdtkbTq73SIl.wk61Lrtj, z50Var);
            if (objLQkLH9RtdoX != woVar) {
            }
        }
        if (i2 != 1) {
            if (i2 != 2) {
                if (i2 == 3) {
                    defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
                    return fv1Var;
                }
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            this = z50Var.KImmPBu5u;
            defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
            defpackage.c50 c50Var = ((defpackage.f61) objLQkLH9RtdoX).ShamLDIR;
            z50Var.KImmPBu5u = null;
            z50Var.SOLzqtJLiD8g = 3;
            return this.acT0gEliM(c50Var, z50Var) != woVar ? woVar : fv1Var;
        }
        defpackage.s20.oHwKnjYdY4X3(objLQkLH9RtdoX);
        defpackage.qh qhVar = (defpackage.qh) objLQkLH9RtdoX;
        if (qhVar != null) {
            Ts5Bfxu7gi(qhVar);
            return fv1Var;
        }
        z50Var.KImmPBu5u = this;
        z50Var.SOLzqtJLiD8g = 2;
        objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.hyi5MRgVJpZU.wk61Lrtj, z50Var);
        if (objLQkLH9RtdoX != woVar) {
            defpackage.c50 c50Var2 = ((defpackage.f61) objLQkLH9RtdoX).ShamLDIR;
            z50Var.KImmPBu5u = null;
            z50Var.SOLzqtJLiD8g = 3;
            if (this.acT0gEliM(c50Var2, z50Var) != woVar) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object acT0gEliM(defpackage.c50 c50Var, defpackage.ho hoVar) {
        defpackage.a60 a60Var;
        defpackage.fo1 fo1Var;
        java.lang.Object value;
        defpackage.t50 t50Var;
        long jAdtkbTq73SIl;
        defpackage.qh qhVar;
        defpackage.qh qhVar2;
        defpackage.c50 c50Var2 = c50Var;
        if (hoVar instanceof defpackage.a60) {
            a60Var = (defpackage.a60) hoVar;
            int i = a60Var.ybb6jpEh;
            if ((i & Integer.MIN_VALUE) != 0) {
                a60Var.ybb6jpEh = i - Integer.MIN_VALUE;
            } else {
                a60Var = new defpackage.a60(this, hoVar);
            }
        }
        defpackage.a60 a60Var2 = a60Var;
        java.lang.Object obj = a60Var2.SOLzqtJLiD8g;
        int i2 = a60Var2.ybb6jpEh;
        defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        int i3 = 1;
        if (i2 == 0) {
            defpackage.s20.oHwKnjYdY4X3(obj);
            do {
                fo1Var = this.wk61Lrtj;
                value = fo1Var.getValue();
                t50Var = (defpackage.t50) value;
                t50Var.getClass();
            } while (!fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, null, true, null, null, 0, 29)));
            jAdtkbTq73SIl = defpackage.g71.hyi5MRgVJpZU.AdtkbTq73SIl();
            qhVar = new defpackage.qh(c50Var2, jAdtkbTq73SIl, 0, 0, c50Var2.AdtkbTq73SIl, 0, 0);
            a60Var2.KImmPBu5u = c50Var2;
            a60Var2.EX2ajLj518q3 = qhVar;
            a60Var2.O21Gh3JCO74 = jAdtkbTq73SIl;
            a60Var2.ybb6jpEh = 1;
            java.lang.Object objCGnIndwjik9 = this.AdtkbTq73SIl.CGnIndwjik9.CGnIndwjik9(new defpackage.Ts5Bfxu7gi(4, qhVar), a60Var2);
            if (objCGnIndwjik9 != woVar) {
                objCGnIndwjik9 = fv1Var;
            }
            if (objCGnIndwjik9 != woVar) {
            }
            return woVar;
        }
        if (i2 != 1) {
            if (i2 != 2) {
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            qhVar2 = a60Var2.EX2ajLj518q3;
            defpackage.s20.oHwKnjYdY4X3(obj);
            Ts5Bfxu7gi(qhVar2);
            return fv1Var;
        }
        long j = a60Var2.O21Gh3JCO74;
        defpackage.qh qhVar3 = a60Var2.EX2ajLj518q3;
        defpackage.c50 c50Var3 = a60Var2.KImmPBu5u;
        defpackage.s20.oHwKnjYdY4X3(obj);
        qhVar = qhVar3;
        jAdtkbTq73SIl = j;
        c50Var2 = c50Var3;
        a60Var2.KImmPBu5u = null;
        a60Var2.EX2ajLj518q3 = qhVar;
        a60Var2.O21Gh3JCO74 = jAdtkbTq73SIl;
        a60Var2.ybb6jpEh = 2;
        java.lang.Object objCGnIndwjik92 = this.hyi5MRgVJpZU.CGnIndwjik9.CGnIndwjik9(new defpackage.v80(c50Var2, i3), a60Var2);
        if (objCGnIndwjik92 != woVar) {
            objCGnIndwjik92 = fv1Var;
        }
        if (objCGnIndwjik92 != woVar) {
            qhVar2 = qhVar;
            Ts5Bfxu7gi(qhVar2);
            return fv1Var;
        }
        return woVar;
    }

    @Override // defpackage.fu0
    public final void bGtyfE77Qpby(java.lang.Exception exc) {
        defpackage.fo1 fo1Var;
        java.lang.Object value;
        defpackage.t50 t50Var;
        do {
            fo1Var = this.wk61Lrtj;
            value = fo1Var.getValue();
            t50Var = (defpackage.t50) value;
            t50Var.getClass();
        } while (!fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, null, false, null, null, 0, 29)));
    }

    public final void cAUonbdEve(defpackage.sf1 sf1Var, defpackage.sf1 sf1Var2) {
        java.lang.Object value;
        defpackage.t50 t50Var;
        defpackage.fo1 fo1Var = this.wk61Lrtj;
        defpackage.tf1 tf1Var = ((defpackage.t50) fo1Var.getValue()).CGnIndwjik9;
        if (tf1Var != null && tf1Var.O21Gh3JCO74 == sf1Var) {
            do {
                value = fo1Var.getValue();
                t50Var = (defpackage.t50) value;
                t50Var.getClass();
            } while (!fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, defpackage.tf1.CGnIndwjik9(tf1Var, 0, 0, 0, 0, 0, null, sf1Var2, 0, false, 3583), false, null, null, 0, 30)));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object oA3oVL3lY(defpackage.ho hoVar) {
        defpackage.y50 y50Var;
        defpackage.tf1 tf1Var;
        if (hoVar instanceof defpackage.y50) {
            y50Var = (defpackage.y50) hoVar;
            int i = y50Var.SOLzqtJLiD8g;
            if ((i & Integer.MIN_VALUE) != 0) {
                y50Var.SOLzqtJLiD8g = i - Integer.MIN_VALUE;
            } else {
                y50Var = new defpackage.y50(this, hoVar);
            }
        }
        java.lang.Object obj = y50Var.EX2ajLj518q3;
        int i2 = y50Var.SOLzqtJLiD8g;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        if (i2 == 0) {
            defpackage.s20.oHwKnjYdY4X3(obj);
            defpackage.tf1 tf1Var2 = ((defpackage.t50) this.wk61Lrtj.getValue()).CGnIndwjik9;
            if (tf1Var2 == null || tf1Var2.O21Gh3JCO74 != defpackage.sf1.EX2ajLj518q3) {
                return fv1Var;
            }
            y50Var.KImmPBu5u = tf1Var2;
            y50Var.SOLzqtJLiD8g = 1;
            java.lang.Object objLQkLH9RtdoX = defpackage.r10.LQkLH9RtdoX(this.AdtkbTq73SIl.wk61Lrtj, y50Var);
            defpackage.wo woVar = defpackage.wo.hyi5MRgVJpZU;
            if (objLQkLH9RtdoX == woVar) {
                return woVar;
            }
            tf1Var = tf1Var2;
            obj = objLQkLH9RtdoX;
        } else {
            if (i2 != 1) {
                defpackage.t5.Wg7Cen3syT("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            tf1Var = y50Var.KImmPBu5u;
            defpackage.s20.oHwKnjYdY4X3(obj);
        }
        defpackage.qh qhVar = (defpackage.qh) obj;
        if (qhVar != null && qhVar.wk61Lrtj == tf1Var.wk61Lrtj && qhVar.m4CNag5J8Y == tf1Var.m4CNag5J8Y + 1) {
            Ts5Bfxu7gi(qhVar);
            return fv1Var;
        }
        Ts5Bfxu7gi(new defpackage.qh(tf1Var.CGnIndwjik9, tf1Var.wk61Lrtj, tf1Var.m4CNag5J8Y + 1, tf1Var.ShamLDIR, tf1Var.hyi5MRgVJpZU, tf1Var.bGtyfE77Qpby, tf1Var.KImmPBu5u));
        return fv1Var;
    }

    public final java.lang.Object ybb6jpEh(defpackage.tf1 tf1Var, defpackage.sf1 sf1Var, defpackage.x50 x50Var) {
        int i = tf1Var.hyi5MRgVJpZU - 1;
        defpackage.sf1 sf1Var2 = sf1Var;
        java.lang.String str = sf1Var2 == defpackage.sf1.AdtkbTq73SIl ? "A guard caught you!" : "Your candle burned out!";
        if (i <= 0) {
            java.lang.Object objO21Gh3JCO74 = O21Gh3JCO74(defpackage.tf1.CGnIndwjik9(tf1Var, 0, 0, 0, 0, 0, null, null, 0, false, 4079), false, str, x50Var);
            if (objO21Gh3JCO74 == defpackage.wo.hyi5MRgVJpZU) {
                return objO21Gh3JCO74;
            }
        } else {
            while (true) {
                defpackage.fo1 fo1Var = this.wk61Lrtj;
                java.lang.Object value = fo1Var.getValue();
                defpackage.t50 t50Var = (defpackage.t50) value;
                t50Var.getClass();
                java.lang.String str2 = str;
                if (fo1Var.KImmPBu5u(value, defpackage.t50.CGnIndwjik9(t50Var, defpackage.tf1.CGnIndwjik9(tf1Var, 0, i, 0, 0, 0, null, sf1Var2, 0, false, 3567), false, null, str2, t50Var.hyi5MRgVJpZU + 1, 6))) {
                    break;
                }
                str = str2;
                sf1Var2 = sf1Var;
            }
        }
        return defpackage.fv1.CGnIndwjik9;
    }
}
