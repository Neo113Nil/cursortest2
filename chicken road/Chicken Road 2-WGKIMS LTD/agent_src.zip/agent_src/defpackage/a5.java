package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final /* synthetic */ class a5 implements defpackage.d40 {
    public final /* synthetic */ java.lang.Object AdtkbTq73SIl;
    public final /* synthetic */ java.lang.Object bGtyfE77Qpby;
    public final /* synthetic */ int hyi5MRgVJpZU;

    public /* synthetic */ a5(int i, int i2, java.lang.Object obj, java.lang.Object obj2) {
        this.hyi5MRgVJpZU = i2;
        this.bGtyfE77Qpby = obj;
        this.AdtkbTq73SIl = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.d40
    public final java.lang.Object ShamLDIR(java.lang.Object obj, java.lang.Object obj2) {
        defpackage.h60 h60Var;
        int i = this.hyi5MRgVJpZU;
        defpackage.kh1 kh1Var = defpackage.im.CGnIndwjik9;
        int i2 = 4;
        int i3 = 2;
        defpackage.fv1 fv1Var = defpackage.fv1.CGnIndwjik9;
        java.lang.Object obj3 = this.AdtkbTq73SIl;
        java.lang.Object obj4 = this.bGtyfE77Qpby;
        switch (i) {
            case 0:
                ((java.lang.Integer) obj2).getClass();
                defpackage.yr.ybb6jpEh((defpackage.vt) obj4, (defpackage.z30) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(1));
                break;
            case 1:
                defpackage.pp1 pp1Var = (defpackage.pp1) obj;
                defpackage.kn knVar = (defpackage.kn) obj2;
                break;
            case defpackage.o51.FLOAT_FIELD_NUMBER /* 2 */:
                defpackage.hl hlVar = (defpackage.hl) obj4;
                java.lang.Object obj5 = (defpackage.te) obj3;
                defpackage.h60 h60Var2 = (defpackage.h60) obj;
                int iIntValue = ((java.lang.Integer) obj2).intValue();
                if (!h60Var2.eMSp92M2t(iIntValue & 1, (iIntValue & 3) != 2)) {
                    h60Var2.w9n6oNBhm();
                    break;
                } else {
                    hlVar.m4CNag5J8Y(obj5, h60Var2, 0);
                    break;
                }
            case defpackage.o51.INTEGER_FIELD_NUMBER /* 3 */:
                ((java.lang.Integer) obj2).getClass();
                defpackage.yr.h86pw74rDIBM((java.lang.String) obj4, (defpackage.io0) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(7));
                break;
            case defpackage.o51.LONG_FIELD_NUMBER /* 4 */:
                ((java.lang.Integer) obj2).getClass();
                defpackage.yr.X9gUlnc07R((defpackage.io0) obj4, (defpackage.hl) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(49));
                break;
            case defpackage.o51.STRING_FIELD_NUMBER /* 5 */:
                defpackage.o30 o30Var = (defpackage.o30) obj4;
                java.lang.String str = (java.lang.String) obj3;
                defpackage.h60 h60Var3 = (defpackage.h60) obj;
                int iIntValue2 = ((java.lang.Integer) obj2).intValue();
                if (!h60Var3.eMSp92M2t(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    h60Var3.w9n6oNBhm();
                    break;
                } else {
                    defpackage.jn0.ybb6jpEh(o30Var, null, false, null, null, null, defpackage.fc0.hfi1lqIFl(-1779203747, new defpackage.xk(str, null == true ? 1 : 0), h60Var3), h60Var3, 805306368);
                    break;
                }
            case defpackage.o51.STRING_SET_FIELD_NUMBER /* 6 */:
                ((java.lang.Integer) obj2).getClass();
                ((defpackage.bs) obj4).CGnIndwjik9((defpackage.llsKPgWWJAw) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(1));
                break;
            case defpackage.o51.DOUBLE_FIELD_NUMBER /* 7 */:
                ((java.lang.Integer) obj2).getClass();
                ((defpackage.ws) obj4).CGnIndwjik9((defpackage.ru0) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(1));
                break;
            case defpackage.o51.BYTES_FIELD_NUMBER /* 8 */:
                ((java.lang.Integer) obj2).getClass();
                defpackage.yr.BCxB3l2DENQ((java.lang.String) obj4, (java.lang.String) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(7));
                break;
            case 9:
                defpackage.tf1 tf1Var = (defpackage.tf1) obj4;
                defpackage.zd zdVar = (defpackage.zd) obj3;
                int i4 = zdVar.KImmPBu5u;
                defpackage.h60 h60Var4 = (defpackage.h60) obj;
                int iIntValue3 = ((java.lang.Integer) obj2).intValue();
                if (!h60Var4.eMSp92M2t(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    h60Var4.w9n6oNBhm();
                    break;
                } else {
                    java.lang.String strValueOf = java.lang.String.valueOf(tf1Var.hyi5MRgVJpZU);
                    java.lang.Object objCO8Wxv6r = h60Var4.CO8Wxv6r();
                    if (objCO8Wxv6r == kh1Var) {
                        objCO8Wxv6r = new defpackage.d50(3);
                        h60Var4.XEWVqqb5t6J(objCO8Wxv6r);
                    }
                    defpackage.yr.EX2ajLj518q3(strValueOf, "Lives", null, 0L, (defpackage.z30) objCO8Wxv6r, h60Var4, 24624, 12);
                    int i5 = zdVar.EX2ajLj518q3;
                    defpackage.nj0 nj0Var = zdVar.CGnIndwjik9;
                    java.lang.String strValueOf2 = java.lang.String.valueOf(i4);
                    int i6 = 5;
                    long j = i4 <= 5 ? defpackage.q11.acT0gEliM : defpackage.q11.ShamLDIR;
                    boolean zKImmPBu5u = h60Var4.KImmPBu5u(zdVar);
                    java.lang.Object objCO8Wxv6r2 = h60Var4.CO8Wxv6r();
                    if (zKImmPBu5u || objCO8Wxv6r2 == kh1Var) {
                        objCO8Wxv6r2 = new defpackage.Ts5Bfxu7gi(11, zdVar);
                        h60Var4.XEWVqqb5t6J(objCO8Wxv6r2);
                    }
                    defpackage.yr.EX2ajLj518q3(strValueOf2, "Candle", null, j, (defpackage.z30) objCO8Wxv6r2, h60Var4, 48, 4);
                    java.lang.String str2 = (nj0Var.CGnIndwjik9() - zdVar.AdtkbTq73SIl) + "/" + nj0Var.CGnIndwjik9();
                    java.lang.Object objCO8Wxv6r3 = h60Var4.CO8Wxv6r();
                    if (objCO8Wxv6r3 == kh1Var) {
                        objCO8Wxv6r3 = new defpackage.d50(i2);
                        h60Var4.XEWVqqb5t6J(objCO8Wxv6r3);
                    }
                    defpackage.yr.EX2ajLj518q3(str2, "Pages", null, 0L, (defpackage.z30) objCO8Wxv6r3, h60Var4, 24624, 12);
                    java.lang.String strValueOf3 = java.lang.String.valueOf(tf1Var.AdtkbTq73SIl);
                    java.lang.Object objCO8Wxv6r4 = h60Var4.CO8Wxv6r();
                    if (objCO8Wxv6r4 == kh1Var) {
                        objCO8Wxv6r4 = new defpackage.d50(i6);
                        h60Var4.XEWVqqb5t6J(objCO8Wxv6r4);
                    }
                    defpackage.yr.EX2ajLj518q3(strValueOf3, "Florins", null, 0L, (defpackage.z30) objCO8Wxv6r4, h60Var4, 24624, 12);
                    if (i5 > 0) {
                        h60Var4.hwJeYkFOwb2F(-1491848092);
                        java.lang.String strValueOf4 = java.lang.String.valueOf(i5);
                        java.lang.Object objCO8Wxv6r5 = h60Var4.CO8Wxv6r();
                        if (objCO8Wxv6r5 == kh1Var) {
                            objCO8Wxv6r5 = new defpackage.d50(6);
                            h60Var4.XEWVqqb5t6J(objCO8Wxv6r5);
                        }
                        defpackage.yr.EX2ajLj518q3(strValueOf4, "Cloak", null, 0L, (defpackage.z30) objCO8Wxv6r5, h60Var4, 24624, 12);
                    } else {
                        h60Var4.hwJeYkFOwb2F(-1499857500);
                    }
                    h60Var4.acT0gEliM(false);
                    break;
                }
            case 10:
                defpackage.m81 m81Var = (defpackage.m81) obj4;
                defpackage.hm1 hm1Var = (defpackage.hm1) obj3;
                int iIntValue4 = ((java.lang.Integer) obj).intValue();
                if (!(obj2 instanceof defpackage.ql)) {
                    if (!(obj2 instanceof defpackage.me1)) {
                        if (!(obj2 instanceof defpackage.l60)) {
                            if (obj2 instanceof defpackage.o71) {
                                defpackage.ec0.w9n6oNBhm(hm1Var, iIntValue4, obj2);
                                ((defpackage.o71) obj2).m4CNag5J8Y();
                                break;
                            }
                        } else {
                            defpackage.ec0.w9n6oNBhm(hm1Var, iIntValue4, obj2);
                            m81Var.hyi5MRgVJpZU((defpackage.l60) obj2);
                            break;
                        }
                    }
                } else {
                    m81Var.bGtyfE77Qpby.wk61Lrtj((defpackage.ql) obj2);
                    break;
                }
                break;
            case 11:
                defpackage.hh0 hh0Var = (defpackage.hh0) obj4;
                defpackage.gh0 gh0Var = (defpackage.gh0) obj3;
                defpackage.h60 h60Var5 = (defpackage.h60) obj;
                int iIntValue5 = ((java.lang.Integer) obj2).intValue();
                if (!h60Var5.eMSp92M2t(iIntValue5 & 1, (iIntValue5 & 3) != 2)) {
                    h60Var5.w9n6oNBhm();
                    break;
                } else {
                    defpackage.ih0 ih0Var = (defpackage.ih0) hh0Var.wk61Lrtj.CGnIndwjik9();
                    int iHyi5MRgVJpZU = gh0Var.m4CNag5J8Y;
                    java.lang.Object obj6 = gh0Var.CGnIndwjik9;
                    if ((iHyi5MRgVJpZU >= ih0Var.CGnIndwjik9() || !ih0Var.wk61Lrtj(iHyi5MRgVJpZU).equals(obj6)) && (iHyi5MRgVJpZU = ih0Var.hyi5MRgVJpZU(obj6)) != -1) {
                        gh0Var.m4CNag5J8Y = iHyi5MRgVJpZU;
                    }
                    int i7 = iHyi5MRgVJpZU;
                    if (i7 != -1) {
                        h60Var5.hwJeYkFOwb2F(-1664741271);
                        defpackage.i20.ShamLDIR(ih0Var, hh0Var.CGnIndwjik9, i7, gh0Var.CGnIndwjik9, h60Var5, 0);
                        h60Var = h60Var5;
                        h60Var.acT0gEliM(false);
                    } else {
                        h60Var = h60Var5;
                        h60Var.hwJeYkFOwb2F(-1664505826);
                        h60Var.acT0gEliM(false);
                    }
                    boolean zKImmPBu5u2 = h60Var.KImmPBu5u(gh0Var);
                    java.lang.Object objCO8Wxv6r6 = h60Var.CO8Wxv6r();
                    if (zKImmPBu5u2 || objCO8Wxv6r6 == kh1Var) {
                        objCO8Wxv6r6 = new defpackage.Ts5Bfxu7gi(15, gh0Var);
                        h60Var.XEWVqqb5t6J(objCO8Wxv6r6);
                    }
                    defpackage.fc0.EX2ajLj518q3(obj6, (defpackage.z30) objCO8Wxv6r6, h60Var);
                    break;
                }
                break;
            case 12:
                break;
            case 13:
                defpackage.hl hlVar2 = (defpackage.hl) obj4;
                java.lang.Object obj7 = (defpackage.ki0) obj3;
                defpackage.h60 h60Var6 = (defpackage.h60) obj;
                int iIntValue6 = ((java.lang.Integer) obj2).intValue();
                if (!h60Var6.eMSp92M2t(iIntValue6 & 1, (iIntValue6 & 3) != 2)) {
                    h60Var6.w9n6oNBhm();
                    break;
                } else {
                    hlVar2.m4CNag5J8Y(obj7, h60Var6, 0);
                    break;
                }
            case 14:
                com.kartiop.locak.spachfykas.MainActivity mainActivity = (com.kartiop.locak.spachfykas.MainActivity) obj4;
                java.lang.String str3 = (java.lang.String) obj3;
                defpackage.h60 h60Var7 = (defpackage.h60) obj;
                int iIntValue7 = ((java.lang.Integer) obj2).intValue();
                int i8 = com.kartiop.locak.spachfykas.MainActivity.h86pw74rDIBM;
                if (!h60Var7.eMSp92M2t(iIntValue7 & 1, (iIntValue7 & 3) != 2)) {
                    h60Var7.w9n6oNBhm();
                    break;
                } else {
                    android.app.Application application = mainActivity.getApplication();
                    application.getClass();
                    defpackage.s20.UrzhsTkV((defpackage.sf0) ((com.kartiop.locak.spachfykas.FlorentiaApp) application).CGnIndwjik9(), defpackage.fc0.hfi1lqIFl(-545938419, new defpackage.e5(str3, i2), h60Var7), h60Var7, 48);
                    break;
                }
            case defpackage.i20.hyi5MRgVJpZU /* 15 */:
                ((java.lang.Integer) obj2).getClass();
                defpackage.yr.lWYAEQgM((defpackage.cm1) obj4, (defpackage.j11) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(1));
                break;
            case 16:
                ((java.lang.Integer) obj2).getClass();
                defpackage.gr1.CGnIndwjik9((defpackage.vr1) obj4, (defpackage.hl) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(1));
                break;
            default:
                ((java.lang.Integer) obj2).getClass();
                defpackage.s20.UrzhsTkV((defpackage.sf0) obj4, (defpackage.hl) obj3, (defpackage.h60) obj, defpackage.h10.M80ht0VsJ(49));
                break;
        }
        return fv1Var;
    }

    public /* synthetic */ a5(int i, java.lang.Object obj, java.lang.Object obj2) {
        this.hyi5MRgVJpZU = i;
        this.bGtyfE77Qpby = obj;
        this.AdtkbTq73SIl = obj2;
    }
}
