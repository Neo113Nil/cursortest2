package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public abstract class o5 {
    public static final /* synthetic */ defpackage.ud0[] CGnIndwjik9;
    public static final defpackage.d51 wk61Lrtj;

    static {
        defpackage.w61 w61Var = new defpackage.w61(defpackage.o5.class, "florentiaStore", "getFlorentiaStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", 1);
        defpackage.g81.CGnIndwjik9.getClass();
        CGnIndwjik9 = new defpackage.ud0[]{w61Var};
        defpackage.vi0 vi0Var = new defpackage.vi0(14);
        defpackage.xs xsVar = defpackage.qu.CGnIndwjik9;
        defpackage.ps psVar = defpackage.ps.AdtkbTq73SIl;
        defpackage.up1 up1Var = new defpackage.up1(null);
        psVar.getClass();
        wk61Lrtj = new defpackage.d51(vi0Var, defpackage.f12.ShamLDIR(defpackage.ec0.KWCPqjSF(psVar, up1Var)));
    }
}
