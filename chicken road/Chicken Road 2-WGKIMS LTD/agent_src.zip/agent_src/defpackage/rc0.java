package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public enum rc0 {
    PAGE("Codex page", 50),
    FLORIN("Florin", 10),
    LANTERN("Lantern", 15),
    CLOAK("Shadow cloak", 15),
    HOURGLASS("Hourglass", 15);

    public final int bGtyfE77Qpby;
    public final java.lang.String hyi5MRgVJpZU;

    rc0(java.lang.String str, int i) {
        this.hyi5MRgVJpZU = str;
        this.bGtyfE77Qpby = i;
    }
}
