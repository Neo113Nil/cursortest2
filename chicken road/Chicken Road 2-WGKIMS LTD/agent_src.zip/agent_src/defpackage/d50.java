package defpackage;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final /* synthetic */ class d50 implements defpackage.z30 {
    public final /* synthetic */ int hyi5MRgVJpZU;

    public /* synthetic */ d50(int i, defpackage.ei0 ei0Var) {
        this.hyi5MRgVJpZU = 29;
    }

    @Override // defpackage.z30
    public final java.lang.Object KImmPBu5u(java.lang.Object obj) {
        switch (this.hyi5MRgVJpZU) {
            case 0:
                defpackage.nw nwVar = (defpackage.nw) obj;
                nwVar.getClass();
                float fIntBitsToFloat = java.lang.Float.intBitsToFloat((int) (nwVar.ShamLDIR() >> 32)) * 0.1f;
                float fIntBitsToFloat2 = java.lang.Float.intBitsToFloat((int) (nwVar.ShamLDIR() & 4294967295L)) * 0.1f;
                defpackage.rn1.hyi5MRgVJpZU(nwVar, (java.lang.Float.floatToRawIntBits(fIntBitsToFloat2) & 4294967295L) | (java.lang.Float.floatToRawIntBits(fIntBitsToFloat) << 32), defpackage.ll1.wk61Lrtj(nwVar.ShamLDIR()) * 0.8f, true, 1.0f);
                return defpackage.fv1.CGnIndwjik9;
            case 1:
                defpackage.mj1 mj1Var = (defpackage.mj1) obj;
                mj1Var.getClass();
                defpackage.ud0[] ud0VarArr = defpackage.kj1.CGnIndwjik9;
                mj1Var.CGnIndwjik9(defpackage.ij1.CGnIndwjik9, defpackage.ec0.hfi1lqIFl("Pause"));
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.FLOAT_FIELD_NUMBER /* 2 */:
                defpackage.nw nwVar2 = (defpackage.nw) obj;
                nwVar2.getClass();
                float fIntBitsToFloat3 = java.lang.Float.intBitsToFloat((int) (nwVar2.ShamLDIR() >> 32));
                long j = defpackage.q11.ShamLDIR;
                float fIntBitsToFloat4 = java.lang.Float.intBitsToFloat((int) (nwVar2.ShamLDIR() & 4294967295L));
                defpackage.nw.SOLzqtJLiD8g(nwVar2, j, (java.lang.Float.floatToRawIntBits(0.12f * fIntBitsToFloat3) << 32) | (java.lang.Float.floatToRawIntBits(0.0f) & 4294967295L), (java.lang.Float.floatToRawIntBits(fIntBitsToFloat4) & 4294967295L) | (java.lang.Float.floatToRawIntBits(fIntBitsToFloat3 * 0.26f) << 32), null, 120);
                long jFloatToRawIntBits = (java.lang.Float.floatToRawIntBits(fIntBitsToFloat3 * 0.62f) << 32) | (java.lang.Float.floatToRawIntBits(0.0f) & 4294967295L);
                float fIntBitsToFloat5 = java.lang.Float.intBitsToFloat((int) (nwVar2.ShamLDIR() & 4294967295L));
                defpackage.nw.SOLzqtJLiD8g(nwVar2, j, jFloatToRawIntBits, (java.lang.Float.floatToRawIntBits(r17) << 32) | (java.lang.Float.floatToRawIntBits(fIntBitsToFloat5) & 4294967295L), null, 120);
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.INTEGER_FIELD_NUMBER /* 3 */:
                defpackage.nw nwVar3 = (defpackage.nw) obj;
                nwVar3.getClass();
                defpackage.rn1.KImmPBu5u(nwVar3, nwVar3.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar3.ShamLDIR()), defpackage.q11.acT0gEliM);
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.LONG_FIELD_NUMBER /* 4 */:
                defpackage.nw nwVar4 = (defpackage.nw) obj;
                nwVar4.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar4, defpackage.rc0.PAGE, nwVar4.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar4.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.STRING_FIELD_NUMBER /* 5 */:
                defpackage.nw nwVar5 = (defpackage.nw) obj;
                nwVar5.getClass();
                defpackage.rn1.ShamLDIR(nwVar5, nwVar5.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar5.ShamLDIR()) * 0.45f);
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.STRING_SET_FIELD_NUMBER /* 6 */:
                defpackage.nw nwVar6 = (defpackage.nw) obj;
                nwVar6.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar6, defpackage.rc0.CLOAK, nwVar6.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar6.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.o51.DOUBLE_FIELD_NUMBER /* 7 */:
                ((defpackage.w2) obj).getClass();
                return new defpackage.zn(defpackage.oy.CGnIndwjik9(null, 3), defpackage.oy.wk61Lrtj(null, 3));
            case defpackage.o51.BYTES_FIELD_NUMBER /* 8 */:
                synchronized (defpackage.tm1.m4CNag5J8Y) {
                    java.util.List list = defpackage.tm1.EX2ajLj518q3;
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        ((defpackage.z30) list.get(i)).KImmPBu5u(obj);
                    }
                }
                return defpackage.fv1.CGnIndwjik9;
            case 9:
                defpackage.nw nwVar7 = (defpackage.nw) obj;
                nwVar7.getClass();
                defpackage.rn1.CGnIndwjik9(nwVar7, nwVar7.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar7.ShamLDIR()), defpackage.ql1.wk61Lrtj);
                return defpackage.fv1.CGnIndwjik9;
            case 10:
                defpackage.nw nwVar8 = (defpackage.nw) obj;
                nwVar8.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar8, defpackage.rc0.FLORIN, nwVar8.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar8.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case 11:
                defpackage.nw nwVar9 = (defpackage.nw) obj;
                nwVar9.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar9, defpackage.rc0.LANTERN, nwVar9.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar9.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case 12:
                defpackage.nw nwVar10 = (defpackage.nw) obj;
                nwVar10.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar10, defpackage.rc0.CLOAK, nwVar10.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar10.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case 13:
                defpackage.nw nwVar11 = (defpackage.nw) obj;
                nwVar11.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar11, defpackage.rc0.HOURGLASS, nwVar11.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar11.ShamLDIR()));
                return defpackage.fv1.CGnIndwjik9;
            case 14:
                defpackage.nw nwVar12 = (defpackage.nw) obj;
                nwVar12.getClass();
                defpackage.rn1.O21Gh3JCO74(nwVar12, nwVar12.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar12.ShamLDIR()) * 0.45f, defpackage.q11.KImmPBu5u);
                return defpackage.fv1.CGnIndwjik9;
            case defpackage.i20.hyi5MRgVJpZU /* 15 */:
                defpackage.nw nwVar13 = (defpackage.nw) obj;
                nwVar13.getClass();
                defpackage.nw.SOLzqtJLiD8g(nwVar13, defpackage.q11.ybb6jpEh, 0L, 0L, null, 126);
                defpackage.rn1.CGnIndwjik9(nwVar13, nwVar13.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar13.ShamLDIR()) * 0.8f, defpackage.ql1.wk61Lrtj);
                return defpackage.fv1.CGnIndwjik9;
            case 16:
                defpackage.nw nwVar14 = (defpackage.nw) obj;
                nwVar14.getClass();
                defpackage.rn1.EX2ajLj518q3(nwVar14, defpackage.rc0.PAGE, nwVar14.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar14.ShamLDIR()) * 0.8f);
                return defpackage.fv1.CGnIndwjik9;
            case 17:
                defpackage.nw nwVar15 = (defpackage.nw) obj;
                nwVar15.getClass();
                defpackage.rn1.hyi5MRgVJpZU(nwVar15, 0L, defpackage.ll1.wk61Lrtj(nwVar15.ShamLDIR()), true, 0.6f);
                return defpackage.fv1.CGnIndwjik9;
            case 18:
                defpackage.nw nwVar16 = (defpackage.nw) obj;
                nwVar16.getClass();
                defpackage.rn1.AdtkbTq73SIl(nwVar16, nwVar16.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar16.ShamLDIR()) * 0.9f, true);
                return defpackage.fv1.CGnIndwjik9;
            case 19:
                defpackage.nw nwVar17 = (defpackage.nw) obj;
                nwVar17.getClass();
                defpackage.rn1.m4CNag5J8Y(nwVar17, nwVar17.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar17.ShamLDIR()) * 0.9f, true);
                return defpackage.fv1.CGnIndwjik9;
            case 20:
                defpackage.nw nwVar18 = (defpackage.nw) obj;
                nwVar18.getClass();
                defpackage.rn1.bGtyfE77Qpby(nwVar18, 0L, defpackage.ll1.wk61Lrtj(nwVar18.ShamLDIR()));
                float fIntBitsToFloat6 = java.lang.Float.intBitsToFloat((int) (nwVar18.ShamLDIR() >> 32)) * 0.25f;
                float fIntBitsToFloat7 = java.lang.Float.intBitsToFloat((int) (nwVar18.ShamLDIR() & 4294967295L)) * 0.25f;
                defpackage.rn1.wk61Lrtj(nwVar18, (java.lang.Float.floatToRawIntBits(fIntBitsToFloat6) << 32) | (java.lang.Float.floatToRawIntBits(fIntBitsToFloat7) & 4294967295L), defpackage.ll1.wk61Lrtj(nwVar18.ShamLDIR()) * 0.5f, 1);
                return defpackage.fv1.CGnIndwjik9;
            case 21:
                defpackage.nw nwVar19 = (defpackage.nw) obj;
                nwVar19.getClass();
                defpackage.rn1.KImmPBu5u(nwVar19, nwVar19.w9n6oNBhm(), defpackage.ll1.wk61Lrtj(nwVar19.ShamLDIR()) * 0.8f, defpackage.q11.acT0gEliM);
                return defpackage.fv1.CGnIndwjik9;
            case 22:
                return defpackage.fv1.CGnIndwjik9;
            case 23:
                java.util.List list2 = (java.util.List) obj;
                return new defpackage.rg0(((java.lang.Number) list2.get(0)).intValue(), ((java.lang.Number) list2.get(1)).intValue());
            case 24:
                ((java.lang.Integer) obj).getClass();
                return defpackage.ey.hyi5MRgVJpZU;
            case 25:
                ((java.lang.Integer) obj).getClass();
                return -1;
            case 26:
                ((java.lang.Integer) obj).getClass();
                return null;
            case 27:
                return defpackage.fv1.CGnIndwjik9;
            case 28:
                java.util.List list3 = (java.util.List) obj;
                return new defpackage.ii0(((java.lang.Number) list3.get(0)).intValue(), ((java.lang.Number) list3.get(1)).intValue());
            default:
                return defpackage.fv1.CGnIndwjik9;
        }
    }

    public /* synthetic */ d50(int i) {
        this.hyi5MRgVJpZU = i;
    }
}
