package com.kartiop.locak.spachfykas;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final class FlorentiaApp extends android.app.Application implements defpackage.mp {
    public static final /* synthetic */ defpackage.ud0[] bGtyfE77Qpby;
    public final defpackage.sf0 hyi5MRgVJpZU = new defpackage.sf0(new defpackage.j1(3, new defpackage.Ts5Bfxu7gi(8, this)));

    static {
        defpackage.w61 w61Var = new defpackage.w61(com.kartiop.locak.spachfykas.FlorentiaApp.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        defpackage.g81.CGnIndwjik9.getClass();
        bGtyfE77Qpby = new defpackage.ud0[]{w61Var};
    }

    @Override // defpackage.mp
    public final defpackage.lp CGnIndwjik9() {
        defpackage.ud0 ud0Var = bGtyfE77Qpby[0];
        defpackage.sf0 sf0Var = this.hyi5MRgVJpZU;
        sf0Var.getClass();
        ud0Var.getClass();
        return sf0Var;
    }

    @Override // defpackage.mp
    public final defpackage.iq wk61Lrtj() {
        return defpackage.co.CGnIndwjik9;
    }
}
