package com.kartiop.locak.spachfykas;

/* compiled from: r8-map-id-da29370aee8bbe1cc6d86bf9d6dcffd0b7fddf3f402d9f3632cbdc79a5f162db */
/* loaded from: classes.dex */
public final class MainActivity extends defpackage.uk {
    public static final /* synthetic */ int h86pw74rDIBM = 0;

    @Override // defpackage.uk, defpackage.tk, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        super.onCreate(bundle);
        int i = 9;
        defpackage.jq1 jq1Var = new defpackage.jq1(new defpackage.wl1(i));
        defpackage.jq1 jq1Var2 = new defpackage.jq1(new defpackage.wl1(i));
        defpackage.ix ixVar = defpackage.bx.CGnIndwjik9;
        android.view.View decorView = getWindow().getDecorView();
        decorView.getClass();
        defpackage.ix hxVar = defpackage.bx.CGnIndwjik9;
        if (hxVar == null) {
            int i2 = android.os.Build.VERSION.SDK_INT;
            hxVar = i2 >= 35 ? new defpackage.hx() : i2 >= 30 ? new defpackage.gx() : i2 >= 29 ? new defpackage.fx() : i2 >= 28 ? new defpackage.ex() : i2 >= 26 ? new defpackage.dx() : new defpackage.cx();
            defpackage.bx.CGnIndwjik9 = hxVar;
        }
        defpackage.ix ixVar2 = hxVar;
        defpackage.r7 r7Var = new defpackage.r7(ixVar2, jq1Var, jq1Var2, this, decorView, 1);
        android.view.ViewGroup viewGroup = (android.view.ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                defpackage.ax axVar = new defpackage.ax(r7Var, viewGroup.getContext());
                axVar.setTag(ixVar2);
                axVar.setVisibility(8);
                axVar.setWillNotDraw(true);
                viewGroup.addView(axVar);
                break;
            }
            int i4 = i3 + 1;
            android.view.View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new java.lang.IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof defpackage.ix) {
                break;
            } else {
                i3 = i4;
            }
        }
        r7Var.run();
        android.view.Window window = getWindow();
        window.getClass();
        ixVar2.CGnIndwjik9(window);
        android.content.Intent intent = getIntent();
        defpackage.hl hlVar = new defpackage.hl(1401028372, new defpackage.a5(14, this, intent != null ? intent.getStringExtra("screen") : null), true);
        android.view.ViewGroup.LayoutParams layoutParams = defpackage.vk.CGnIndwjik9;
        android.view.View childAt2 = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        defpackage.dm dmVar = childAt2 instanceof defpackage.dm ? (defpackage.dm) childAt2 : null;
        if (dmVar != null) {
            dmVar.setParentCompositionContext(null);
            dmVar.setContent(hlVar);
            return;
        }
        defpackage.dm dmVar2 = new defpackage.dm(this);
        dmVar2.setParentCompositionContext(null);
        dmVar2.setContent(hlVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (defpackage.i20.Wg7Cen3syT(decorView2) == null) {
            decorView2.setTag(com.kartiop.locak.spachfykas.R.id.view_tree_lifecycle_owner, this);
        }
        if (defpackage.s20.lWYAEQgM(decorView2) == null) {
            decorView2.setTag(com.kartiop.locak.spachfykas.R.id.view_tree_view_model_store_owner, this);
        }
        if (defpackage.j20.cAUonbdEve(decorView2) == null) {
            decorView2.setTag(com.kartiop.locak.spachfykas.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(dmVar2, defpackage.vk.CGnIndwjik9);
    }
}
