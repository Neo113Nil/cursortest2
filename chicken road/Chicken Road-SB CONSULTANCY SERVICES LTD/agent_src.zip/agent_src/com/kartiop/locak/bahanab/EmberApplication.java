package com.kartiop.locak.bahanab;

import android.app.Application;
import defpackage.UWan5TXS;
import defpackage.c00;
import defpackage.ph;
import defpackage.qvHpEybgrt;

/* compiled from: r8-map-id-c945079a09133534849985aacdd8a8c7d1894e9249f0fd55da95079b29620fb3 */
/* loaded from: classes.dex */
public class EmberApplication extends Application {
    public static final /* synthetic */ int cUBlkByIyBuN = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        UWan5TXS uWan5TXS = new UWan5TXS(5, this);
        synchronized (qvHpEybgrt.L8dqt8exRhM) {
            c00 c00Var = new c00();
            if (qvHpEybgrt.sednlyPiz5 != null) {
                throw new ph("A Koin Application has already been started");
            }
            qvHpEybgrt.sednlyPiz5 = c00Var.BRGcXAw2j;
            uWan5TXS.eior7xzBT(c00Var);
            c00Var.BRGcXAw2j.z4VIKNtTy();
        }
    }
}
