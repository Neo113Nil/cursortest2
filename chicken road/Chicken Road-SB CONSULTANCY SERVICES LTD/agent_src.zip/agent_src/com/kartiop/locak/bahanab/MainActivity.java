package com.kartiop.locak.bahanab;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.hl;
import defpackage.i31;
import defpackage.il;
import defpackage.j01;
import defpackage.jf;
import defpackage.jl;
import defpackage.kl;
import defpackage.l9;
import defpackage.ll;
import defpackage.lr;
import defpackage.lt0;
import defpackage.md0;
import defpackage.ml;
import defpackage.nl;
import defpackage.of0;
import defpackage.ol;
import defpackage.pc;
import defpackage.pl;
import defpackage.qc0;
import defpackage.rl;
import defpackage.st;
import defpackage.tf0;
import defpackage.ti0;
import defpackage.ub;
import defpackage.v4;
import defpackage.vb;
import defpackage.vl0;
import defpackage.x2;
import defpackage.y3aUKHji;
import defpackage.yr0;
import defpackage.zb;

/* compiled from: r8-map-id-c945079a09133534849985aacdd8a8c7d1894e9249f0fd55da95079b29620fb3 */
/* loaded from: classes.dex */
public final class MainActivity extends ub {
    public static final /* synthetic */ int bGqzs9Th8R = 0;

    @Override // defpackage.ub, defpackage.tb, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = 18;
        lt0 lt0Var = new lt0(new vl0(i));
        lt0 lt0Var2 = new lt0(new vl0(i));
        pl plVar = il.BRGcXAw2j;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        pl olVar = il.BRGcXAw2j;
        if (olVar == null) {
            int i2 = Build.VERSION.SDK_INT;
            olVar = i2 >= 35 ? new ol() : i2 >= 30 ? new nl() : i2 >= 29 ? new ml() : i2 >= 28 ? new ll() : i2 >= 26 ? new kl() : new jl();
            il.BRGcXAw2j = olVar;
        }
        pl plVar2 = olVar;
        v4 v4Var = new v4(plVar2, lt0Var, lt0Var2, this, decorView, 1);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                hl hlVar = new hl(v4Var, viewGroup.getContext());
                hlVar.setTag(plVar2);
                hlVar.setVisibility(8);
                hlVar.setWillNotDraw(true);
                viewGroup.addView(hlVar);
                break;
            }
            int i4 = i3 + 1;
            View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof pl) {
                break;
            } else {
                i3 = i4;
            }
        }
        v4Var.run();
        Window window = getWindow();
        window.getClass();
        plVar2.BRGcXAw2j(window);
        String stringExtra = getIntent().getStringExtra("screen");
        String str = "main";
        if (stringExtra != null) {
            if (!i31.FpJgXv02J9("main", "game", "skins", "howtoplay").contains(stringExtra)) {
                stringExtra = null;
            }
            if (stringExtra != null) {
                str = stringExtra;
            }
        }
        lr lrVar = new lr(this);
        j01 j01VarCUBlkByIyBuN = cUBlkByIyBuN();
        jf jfVarSv1y8mVOH = md0.sv1y8mVOH(this);
        jfVarSv1y8mVOH.getClass();
        y3aUKHji y3aukhji = new y3aUKHji(j01VarCUBlkByIyBuN, lrVar, jfVarSv1y8mVOH);
        l9 l9VarBRGcXAw2j = ti0.BRGcXAw2j(st.class);
        String strBRGcXAw2j = l9VarBRGcXAw2j.BRGcXAw2j();
        if (strBRGcXAw2j == null) {
            x2.UWan5TXS("Local and anonymous classes can not be ViewModels");
            return;
        }
        st stVar = (st) y3aukhji.c7eu7eprjIB(l9VarBRGcXAw2j, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strBRGcXAw2j));
        if (!stVar.raTyHFGOCV8U) {
            stVar.raTyHFGOCV8U = true;
            if (str.equals("game")) {
                stVar.taRe44pprTm3();
            } else {
                yr0 yr0Var = stVar.eior7xzBT;
                yr0Var.getClass();
                yr0Var.taRe44pprTm3(null, str);
            }
        }
        zb zbVar = new zb(-1510748562, true, new rl(stVar));
        ViewGroup.LayoutParams layoutParams = vb.BRGcXAw2j;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        pc pcVar = childAt2 instanceof pc ? (pc) childAt2 : null;
        if (pcVar != null) {
            pcVar.setParentCompositionContext(null);
            pcVar.setContent(zbVar);
            return;
        }
        pc pcVar2 = new pc(this);
        pcVar2.setParentCompositionContext(null);
        pcVar2.setContent(zbVar);
        View decorView2 = getWindow().getDecorView();
        if (of0.AWduV5Sf1U8Z(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (qc0.cutD7cbhv6c(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (tf0.kZ1EgPvE4rf(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(pcVar2, vb.BRGcXAw2j);
    }
}
