package com.watchfacestudio.cardilot_cts41;

/* loaded from: classes.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.watchfacestudio.cardilot_cts41";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 2;
    public static final String VERSION_NAME = "1.0.2";
}
