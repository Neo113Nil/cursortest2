package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Spinner;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;
import com.google.android.material.textfield.TextInputEditText;

/* loaded from: classes.dex */
public final class DialogQuoteRequestBinding implements ViewBinding {
    public final Button btnCancel;
    public final Button btnSubmit;
    public final TextInputEditText editEmail;
    public final TextInputEditText editMessage;
    public final TextInputEditText editName;
    public final TextInputEditText editPhone;
    private final ScrollView rootView;
    public final Spinner spinnerDumpsterSize;
    public final Spinner spinnerDuration;
    public final Spinner spinnerProjectType;

    private DialogQuoteRequestBinding(ScrollView scrollView, Button button, Button button2, TextInputEditText textInputEditText, TextInputEditText textInputEditText2, TextInputEditText textInputEditText3, TextInputEditText textInputEditText4, Spinner spinner, Spinner spinner2, Spinner spinner3) {
        this.rootView = scrollView;
        this.btnCancel = button;
        this.btnSubmit = button2;
        this.editEmail = textInputEditText;
        this.editMessage = textInputEditText2;
        this.editName = textInputEditText3;
        this.editPhone = textInputEditText4;
        this.spinnerDumpsterSize = spinner;
        this.spinnerDuration = spinner2;
        this.spinnerProjectType = spinner3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ScrollView getRoot() {
        return this.rootView;
    }

    public static DialogQuoteRequestBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static DialogQuoteRequestBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.dialog_quote_request, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static DialogQuoteRequestBinding bind(View view) {
        int i = R.id.btn_cancel;
        Button button = (Button) ViewBindings.findChildViewById(view, i);
        if (button != null) {
            i = R.id.btn_submit;
            Button button2 = (Button) ViewBindings.findChildViewById(view, i);
            if (button2 != null) {
                i = R.id.edit_email;
                TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                if (textInputEditText != null) {
                    i = R.id.edit_message;
                    TextInputEditText textInputEditText2 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                    if (textInputEditText2 != null) {
                        i = R.id.edit_name;
                        TextInputEditText textInputEditText3 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                        if (textInputEditText3 != null) {
                            i = R.id.edit_phone;
                            TextInputEditText textInputEditText4 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                            if (textInputEditText4 != null) {
                                i = R.id.spinner_dumpster_size;
                                Spinner spinner = (Spinner) ViewBindings.findChildViewById(view, i);
                                if (spinner != null) {
                                    i = R.id.spinner_duration;
                                    Spinner spinner2 = (Spinner) ViewBindings.findChildViewById(view, i);
                                    if (spinner2 != null) {
                                        i = R.id.spinner_project_type;
                                        Spinner spinner3 = (Spinner) ViewBindings.findChildViewById(view, i);
                                        if (spinner3 != null) {
                                            return new DialogQuoteRequestBinding((ScrollView) view, button, button2, textInputEditText, textInputEditText2, textInputEditText3, textInputEditText4, spinner, spinner2, spinner3);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
