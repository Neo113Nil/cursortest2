package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;

/* loaded from: classes.dex */
public final class ItemServiceBinding implements ViewBinding {
    public final CardView cardService;
    public final ImageView imageService;
    private final CardView rootView;
    public final TextView textServiceCapacity;
    public final TextView textServiceName;
    public final TextView textServiceSize;

    private ItemServiceBinding(CardView cardView, CardView cardView2, ImageView imageView, TextView textView, TextView textView2, TextView textView3) {
        this.rootView = cardView;
        this.cardService = cardView2;
        this.imageService = imageView;
        this.textServiceCapacity = textView;
        this.textServiceName = textView2;
        this.textServiceSize = textView3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public CardView getRoot() {
        return this.rootView;
    }

    public static ItemServiceBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemServiceBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_service, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemServiceBinding bind(View view) {
        CardView cardView = (CardView) view;
        int i = R.id.image_service;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.text_service_capacity;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.text_service_name;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView2 != null) {
                    i = R.id.text_service_size;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView3 != null) {
                        return new ItemServiceBinding(cardView, cardView, imageView, textView, textView2, textView3);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
