package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;

/* loaded from: classes.dex */
public final class ActivityDetailBinding implements ViewBinding {
    public final Button btnContact;
    public final Button btnRequestQuote;
    public final Button btnShare;
    public final ImageView imageService;
    private final ScrollView rootView;
    public final TextView textCapacity;
    public final TextView textDescription;
    public final TextView textDimensions;
    public final TextView textIdealFor;
    public final TextView textServiceName;
    public final Toolbar toolbar;

    private ActivityDetailBinding(ScrollView scrollView, Button button, Button button2, Button button3, ImageView imageView, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, Toolbar toolbar) {
        this.rootView = scrollView;
        this.btnContact = button;
        this.btnRequestQuote = button2;
        this.btnShare = button3;
        this.imageService = imageView;
        this.textCapacity = textView;
        this.textDescription = textView2;
        this.textDimensions = textView3;
        this.textIdealFor = textView4;
        this.textServiceName = textView5;
        this.toolbar = toolbar;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ScrollView getRoot() {
        return this.rootView;
    }

    public static ActivityDetailBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityDetailBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_detail, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityDetailBinding bind(View view) {
        int i = R.id.btn_contact;
        Button button = (Button) ViewBindings.findChildViewById(view, i);
        if (button != null) {
            i = R.id.btn_request_quote;
            Button button2 = (Button) ViewBindings.findChildViewById(view, i);
            if (button2 != null) {
                i = R.id.btn_share;
                Button button3 = (Button) ViewBindings.findChildViewById(view, i);
                if (button3 != null) {
                    i = R.id.image_service;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView != null) {
                        i = R.id.text_capacity;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView != null) {
                            i = R.id.text_description;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView2 != null) {
                                i = R.id.text_dimensions;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView3 != null) {
                                    i = R.id.text_ideal_for;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView4 != null) {
                                        i = R.id.text_service_name;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView5 != null) {
                                            i = R.id.toolbar;
                                            Toolbar toolbar = (Toolbar) ViewBindings.findChildViewById(view, i);
                                            if (toolbar != null) {
                                                return new ActivityDetailBinding((ScrollView) view, button, button2, button3, imageView, textView, textView2, textView3, textView4, textView5, toolbar);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
