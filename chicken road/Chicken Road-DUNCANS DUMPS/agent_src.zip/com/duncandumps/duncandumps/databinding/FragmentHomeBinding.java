package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;

/* loaded from: classes.dex */
public final class FragmentHomeBinding implements ViewBinding {
    public final Button btnGetQuote;
    private final ScrollView rootView;

    private FragmentHomeBinding(ScrollView scrollView, Button button) {
        this.rootView = scrollView;
        this.btnGetQuote = button;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ScrollView getRoot() {
        return this.rootView;
    }

    public static FragmentHomeBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentHomeBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_home, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentHomeBinding bind(View view) {
        int i = R.id.btn_get_quote;
        Button button = (Button) ViewBindings.findChildViewById(view, i);
        if (button != null) {
            return new FragmentHomeBinding((ScrollView) view, button);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
