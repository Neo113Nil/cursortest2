package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;

/* loaded from: classes.dex */
public final class ItemGalleryBinding implements ViewBinding {
    public final CardView cardGallery;
    public final ImageView imageGallery;
    private final CardView rootView;

    private ItemGalleryBinding(CardView cardView, CardView cardView2, ImageView imageView) {
        this.rootView = cardView;
        this.cardGallery = cardView2;
        this.imageGallery = imageView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public CardView getRoot() {
        return this.rootView;
    }

    public static ItemGalleryBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemGalleryBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_gallery, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemGalleryBinding bind(View view) {
        CardView cardView = (CardView) view;
        int i = R.id.image_gallery;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            return new ItemGalleryBinding(cardView, cardView, imageView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
