package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Spinner;
import androidx.appcompat.widget.Toolbar;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;
import com.google.android.material.textfield.TextInputEditText;

/* loaded from: classes.dex */
public final class ActivityQuoteRequestBinding implements ViewBinding {
    public final Button btnSubmit;
    public final TextInputEditText editEmail;
    public final TextInputEditText editMessage;
    public final TextInputEditText editName;
    public final TextInputEditText editPhone;
    private final ScrollView rootView;
    public final Spinner spinnerDumpsterSize;
    public final Spinner spinnerDuration;
    public final Spinner spinnerProjectType;
    public final Toolbar toolbar;

    private ActivityQuoteRequestBinding(ScrollView scrollView, Button button, TextInputEditText textInputEditText, TextInputEditText textInputEditText2, TextInputEditText textInputEditText3, TextInputEditText textInputEditText4, Spinner spinner, Spinner spinner2, Spinner spinner3, Toolbar toolbar) {
        this.rootView = scrollView;
        this.btnSubmit = button;
        this.editEmail = textInputEditText;
        this.editMessage = textInputEditText2;
        this.editName = textInputEditText3;
        this.editPhone = textInputEditText4;
        this.spinnerDumpsterSize = spinner;
        this.spinnerDuration = spinner2;
        this.spinnerProjectType = spinner3;
        this.toolbar = toolbar;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ScrollView getRoot() {
        return this.rootView;
    }

    public static ActivityQuoteRequestBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityQuoteRequestBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_quote_request, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityQuoteRequestBinding bind(View view) {
        int i = R.id.btn_submit;
        Button button = (Button) ViewBindings.findChildViewById(view, i);
        if (button != null) {
            i = R.id.edit_email;
            TextInputEditText textInputEditText = (TextInputEditText) ViewBindings.findChildViewById(view, i);
            if (textInputEditText != null) {
                i = R.id.edit_message;
                TextInputEditText textInputEditText2 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                if (textInputEditText2 != null) {
                    i = R.id.edit_name;
                    TextInputEditText textInputEditText3 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                    if (textInputEditText3 != null) {
                        i = R.id.edit_phone;
                        TextInputEditText textInputEditText4 = (TextInputEditText) ViewBindings.findChildViewById(view, i);
                        if (textInputEditText4 != null) {
                            i = R.id.spinner_dumpster_size;
                            Spinner spinner = (Spinner) ViewBindings.findChildViewById(view, i);
                            if (spinner != null) {
                                i = R.id.spinner_duration;
                                Spinner spinner2 = (Spinner) ViewBindings.findChildViewById(view, i);
                                if (spinner2 != null) {
                                    i = R.id.spinner_project_type;
                                    Spinner spinner3 = (Spinner) ViewBindings.findChildViewById(view, i);
                                    if (spinner3 != null) {
                                        i = R.id.toolbar;
                                        Toolbar toolbar = (Toolbar) ViewBindings.findChildViewById(view, i);
                                        if (toolbar != null) {
                                            return new ActivityQuoteRequestBinding((ScrollView) view, button, textInputEditText, textInputEditText2, textInputEditText3, textInputEditText4, spinner, spinner2, spinner3, toolbar);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
