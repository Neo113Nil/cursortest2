package com.duncandumps.duncandumps.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.duncandumps.duncandumps.R;

/* loaded from: classes.dex */
public final class ItemPricingBinding implements ViewBinding {
    public final CardView cardPricing;
    private final CardView rootView;
    public final TextView textPricingDaily;
    public final TextView textPricingSize;
    public final TextView textPricingWeekly;

    private ItemPricingBinding(CardView cardView, CardView cardView2, TextView textView, TextView textView2, TextView textView3) {
        this.rootView = cardView;
        this.cardPricing = cardView2;
        this.textPricingDaily = textView;
        this.textPricingSize = textView2;
        this.textPricingWeekly = textView3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public CardView getRoot() {
        return this.rootView;
    }

    public static ItemPricingBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemPricingBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_pricing, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemPricingBinding bind(View view) {
        CardView cardView = (CardView) view;
        int i = R.id.text_pricing_daily;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.text_pricing_size;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.text_pricing_weekly;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView3 != null) {
                    return new ItemPricingBinding(cardView, cardView, textView, textView2, textView3);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
