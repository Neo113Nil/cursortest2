package com.duncandumps.duncandumps;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.duncandumps.duncandumps.databinding.ActivityDetailBinding;

/* loaded from: classes.dex */
public class DetailActivity extends AppCompatActivity {
    private ActivityDetailBinding binding;
    private DatabaseHelper dbHelper;
    private Service service;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityDetailBinding activityDetailBindingInflate = ActivityDetailBinding.inflate(getLayoutInflater());
        this.binding = activityDetailBindingInflate;
        setContentView(activityDetailBindingInflate.getRoot());
        setSupportActionBar(this.binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        this.dbHelper = new DatabaseHelper(this);
        int intExtra = getIntent().getIntExtra("service_id", -1);
        if (intExtra != -1) {
            Service serviceById = this.dbHelper.getServiceById(intExtra);
            this.service = serviceById;
            if (serviceById != null) {
                displayServiceDetails();
            }
        }
        this.binding.btnRequestQuote.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.DetailActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m95lambda$onCreate$0$comduncandumpsduncandumpsDetailActivity(view);
            }
        });
        this.binding.btnShare.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.DetailActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m96lambda$onCreate$1$comduncandumpsduncandumpsDetailActivity(view);
            }
        });
        this.binding.btnContact.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.DetailActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m97lambda$onCreate$2$comduncandumpsduncandumpsDetailActivity(view);
            }
        });
    }

    /* renamed from: lambda$onCreate$0$com-duncandumps-duncandumps-DetailActivity, reason: not valid java name */
    /* synthetic */ void m95lambda$onCreate$0$comduncandumpsduncandumpsDetailActivity(View view) {
        QuoteRequestDialog.newInstance(this.service.getSize()).show(getSupportFragmentManager(), "QuoteRequestDialog");
    }

    /* renamed from: lambda$onCreate$1$com-duncandumps-duncandumps-DetailActivity, reason: not valid java name */
    /* synthetic */ void m96lambda$onCreate$1$comduncandumpsduncandumpsDetailActivity(View view) {
        shareService();
    }

    /* renamed from: lambda$onCreate$2$com-duncandumps-duncandumps-DetailActivity, reason: not valid java name */
    /* synthetic */ void m97lambda$onCreate$2$comduncandumpsduncandumpsDetailActivity(View view) {
        Intent intent = new Intent("android.intent.action.SENDTO");
        intent.setData(Uri.parse("mailto:info@duncandumps.com"));
        intent.putExtra("android.intent.extra.SUBJECT", "Inquiry about " + this.service.getName());
        startActivity(Intent.createChooser(intent, "Send Email"));
    }

    private void displayServiceDetails() {
        this.binding.textServiceName.setText(this.service.getName());
        this.binding.textCapacity.setText(this.service.getCapacity());
        this.binding.textDimensions.setText(this.service.getDimensions());
        this.binding.textDescription.setText(this.service.getDescription());
        this.binding.textIdealFor.setText(this.service.getIdealFor());
        Glide.with((FragmentActivity) this).load(this.service.getImageUrl()).placeholder(R.drawable.card_background).error(R.drawable.card_background).into(this.binding.imageService);
    }

    private void shareService() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", getString(R.string.share_text) + "\n\n" + this.service.getName() + " - " + this.service.getCapacity() + "\n" + this.service.getDescription());
        startActivity(Intent.createChooser(intent, "Share via"));
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
