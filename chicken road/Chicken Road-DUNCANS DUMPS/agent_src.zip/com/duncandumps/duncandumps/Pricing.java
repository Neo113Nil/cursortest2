package com.duncandumps.duncandumps;

/* loaded from: classes.dex */
public class Pricing {
    private String dailyRate;
    private int id;
    private String size;
    private String weeklyRate;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public String getWeeklyRate() {
        return this.weeklyRate;
    }

    public void setWeeklyRate(String str) {
        this.weeklyRate = str;
    }

    public String getDailyRate() {
        return this.dailyRate;
    }

    public void setDailyRate(String str) {
        this.dailyRate = str;
    }
}
