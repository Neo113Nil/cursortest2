package com.duncandumps.duncandumps;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.duncandumps.duncandumps.databinding.FragmentHomeBinding;

/* loaded from: classes.dex */
public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentHomeBinding fragmentHomeBindingInflate = FragmentHomeBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = fragmentHomeBindingInflate;
        return fragmentHomeBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.binding.btnGetQuote.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.HomeFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m98lambda$onViewCreated$0$comduncandumpsduncandumpsHomeFragment(view2);
            }
        });
    }

    /* renamed from: lambda$onViewCreated$0$com-duncandumps-duncandumps-HomeFragment, reason: not valid java name */
    /* synthetic */ void m98lambda$onViewCreated$0$comduncandumpsduncandumpsHomeFragment(View view) {
        startActivity(new Intent(getActivity(), (Class<?>) QuoteRequestActivity.class));
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
