package com.duncandumps.duncandumps;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.duncandumps.duncandumps.databinding.FragmentContactBinding;

/* loaded from: classes.dex */
public class ContactFragment extends Fragment {
    private static final String ADDRESS = "10102 N 17TH St\nTampa, FL 33612-7050\nUnited States";
    private static final String EMAIL = "Jeremy@duncandumps.info";
    private static final String MAP_URI = "geo:0,0?q=10102+N+17TH+St,+Tampa,+FL+33612-7050";
    private static final String PHONE = "+17692276624";
    private FragmentContactBinding binding;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentContactBinding fragmentContactBindingInflate = FragmentContactBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = fragmentContactBindingInflate;
        return fragmentContactBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.binding.textPhone.setText(PHONE);
        this.binding.textEmail.setText(EMAIL);
        this.binding.textAddress.setText(ADDRESS);
        this.binding.textHours.setText(getString(R.string.contact_business_hours));
        this.binding.btnCall.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.ContactFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m92x919b9711(view2);
            }
        });
        this.binding.btnEmail.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.ContactFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m93x2c3c5992(view2);
            }
        });
        this.binding.btnDirections.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.ContactFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m94xc6dd1c13(view2);
            }
        });
    }

    /* renamed from: lambda$onViewCreated$0$com-duncandumps-duncandumps-ContactFragment, reason: not valid java name */
    /* synthetic */ void m92x919b9711(View view) {
        Intent intent = new Intent("android.intent.action.DIAL");
        intent.setData(Uri.parse("tel:+17692276624"));
        startActivity(intent);
    }

    /* renamed from: lambda$onViewCreated$1$com-duncandumps-duncandumps-ContactFragment, reason: not valid java name */
    /* synthetic */ void m93x2c3c5992(View view) {
        Intent intent = new Intent("android.intent.action.SENDTO");
        intent.setData(Uri.parse("mailto:Jeremy@duncandumps.info"));
        intent.putExtra("android.intent.extra.SUBJECT", "Dumpster Rental Inquiry");
        startActivity(Intent.createChooser(intent, "Send Email"));
    }

    /* renamed from: lambda$onViewCreated$2$com-duncandumps-duncandumps-ContactFragment, reason: not valid java name */
    /* synthetic */ void m94xc6dd1c13(View view) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MAP_URI)));
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
