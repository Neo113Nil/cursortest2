package com.duncandumps.duncandumps;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.duncandumps.duncandumps.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationBarView;

/* loaded from: classes.dex */
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityMainBinding activityMainBindingInflate = ActivityMainBinding.inflate(getLayoutInflater());
        this.binding = activityMainBindingInflate;
        setContentView(activityMainBindingInflate.getRoot());
        if (bundle == null) {
            loadFragment(new HomeFragment());
        }
        this.binding.bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() { // from class: com.duncandumps.duncandumps.MainActivity$$ExternalSyntheticLambda0
            @Override // com.google.android.material.navigation.NavigationBarView.OnItemSelectedListener
            public final boolean onNavigationItemSelected(MenuItem menuItem) {
                return this.f$0.m99lambda$onCreate$0$comduncandumpsduncandumpsMainActivity(menuItem);
            }
        });
    }

    /* renamed from: lambda$onCreate$0$com-duncandumps-duncandumps-MainActivity, reason: not valid java name */
    /* synthetic */ boolean m99lambda$onCreate$0$comduncandumpsduncandumpsMainActivity(MenuItem menuItem) {
        Fragment contactFragment;
        int itemId = menuItem.getItemId();
        if (itemId == R.id.nav_home) {
            contactFragment = new HomeFragment();
        } else if (itemId == R.id.nav_services) {
            contactFragment = new ServicesFragment();
        } else if (itemId == R.id.nav_gallery) {
            contactFragment = new GalleryFragment();
        } else if (itemId == R.id.nav_pricing) {
            contactFragment = new PricingFragment();
        } else {
            contactFragment = itemId == R.id.nav_contact ? new ContactFragment() : null;
        }
        return loadFragment(contactFragment);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment == null) {
            return false;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
        return true;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.binding.bottomNavigation.getSelectedItemId() != R.id.nav_home) {
            this.binding.bottomNavigation.setSelectedItemId(R.id.nav_home);
            loadFragment(new HomeFragment());
        } else {
            super.onBackPressed();
        }
    }
}
