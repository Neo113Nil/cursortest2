package com.duncandumps.duncandumps;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String COL_GALLERY_DESCRIPTION = "description";
    private static final String COL_GALLERY_ID = "id";
    private static final String COL_GALLERY_IMAGE_URL = "image_url";
    private static final String COL_GALLERY_TITLE = "title";
    private static final String COL_PRICING_DAILY = "daily_rate";
    private static final String COL_PRICING_ID = "id";
    private static final String COL_PRICING_SIZE = "size";
    private static final String COL_PRICING_WEEKLY = "weekly_rate";
    private static final String COL_SERVICE_CAPACITY = "capacity";
    private static final String COL_SERVICE_DESCRIPTION = "description";
    private static final String COL_SERVICE_DIMENSIONS = "dimensions";
    private static final String COL_SERVICE_ID = "id";
    private static final String COL_SERVICE_IDEAL_FOR = "ideal_for";
    private static final String COL_SERVICE_IMAGE_URL = "image_url";
    private static final String COL_SERVICE_NAME = "name";
    private static final String COL_SERVICE_SIZE = "size";
    private static final String DATABASE_NAME = "duncans_dumps.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_GALLERY = "gallery";
    private static final String TABLE_PRICING = "pricing";
    private static final String TABLE_SERVICES = "services";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) throws SQLException {
        sQLiteDatabase.execSQL("CREATE TABLE services (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, size TEXT NOT NULL, capacity TEXT NOT NULL, dimensions TEXT NOT NULL, description TEXT NOT NULL, ideal_for TEXT NOT NULL, image_url TEXT NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE pricing (id INTEGER PRIMARY KEY AUTOINCREMENT, size TEXT NOT NULL, weekly_rate TEXT NOT NULL, daily_rate TEXT NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE gallery (id INTEGER PRIMARY KEY AUTOINCREMENT, image_url TEXT NOT NULL, title TEXT, description TEXT)");
        insertInitialData(sQLiteDatabase);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) throws SQLException {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS services");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS pricing");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS gallery");
        onCreate(sQLiteDatabase);
    }

    private void insertInitialData(SQLiteDatabase sQLiteDatabase) {
        insertService(sQLiteDatabase, "10 Yard Dumpster", "10", "10 cubic yards", "12' x 8' x 3.5'", "Perfect for small home cleanouts, garage cleanups, and small renovation projects. This compact dumpster is ideal for residential use.", "Small home renovations, Garage cleanouts, Basement cleanups, Yard waste removal, Small construction debris", "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800");
        insertService(sQLiteDatabase, "20 Yard Dumpster", "20", "20 cubic yards", "22' x 8' x 4.5'", "Our most popular size for medium-sized projects. Great for larger home renovations, roofing projects, and medium construction jobs.", "Medium home renovations, Roofing projects, Kitchen remodels, Bathroom remodels, Medium construction debris", "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800");
        insertService(sQLiteDatabase, "30 Yard Dumpster", "30", "30 cubic yards", "22' x 8' x 6'", "The largest dumpster we offer, perfect for major construction projects, large-scale renovations, and commercial cleanouts.", "Large construction projects, Major home renovations, Commercial cleanouts, Large-scale demolition, Commercial construction", "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800");
        insertPricing(sQLiteDatabase, "10 Yard", "$350", "$50");
        insertPricing(sQLiteDatabase, "20 Yard", "$450", "$65");
        insertPricing(sQLiteDatabase, "30 Yard", "$550", "$80");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800", "Construction Site", "Our dumpsters in action at a construction site");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800", "Residential Project", "Helping homeowners with their renovation projects");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800", "Commercial Cleanup", "Large-scale commercial waste management");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800", "Our Fleet", "Modern and reliable dumpster fleet");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800", "Project Completion", "Successful project completion");
        insertGalleryItem(sQLiteDatabase, "https://images.unsplash.com/photo-1541976590-713941681591?w=800", "Team at Work", "Our professional team delivering quality service");
    }

    private void insertService(SQLiteDatabase sQLiteDatabase, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_SERVICE_NAME, str);
        contentValues.put("size", str2);
        contentValues.put(COL_SERVICE_CAPACITY, str3);
        contentValues.put(COL_SERVICE_DIMENSIONS, str4);
        contentValues.put("description", str5);
        contentValues.put(COL_SERVICE_IDEAL_FOR, str6);
        contentValues.put("image_url", str7);
        sQLiteDatabase.insert(TABLE_SERVICES, null, contentValues);
    }

    private void insertPricing(SQLiteDatabase sQLiteDatabase, String str, String str2, String str3) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("size", str);
        contentValues.put(COL_PRICING_WEEKLY, str2);
        contentValues.put(COL_PRICING_DAILY, str3);
        sQLiteDatabase.insert(TABLE_PRICING, null, contentValues);
    }

    private void insertGalleryItem(SQLiteDatabase sQLiteDatabase, String str, String str2, String str3) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("image_url", str);
        contentValues.put(COL_GALLERY_TITLE, str2);
        contentValues.put("description", str3);
        sQLiteDatabase.insert(TABLE_GALLERY, null, contentValues);
    }

    public List<Service> getAllServices() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor cursorQuery = readableDatabase.query(TABLE_SERVICES, null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                Service service = new Service();
                service.setId(cursorQuery.getInt(cursorQuery.getColumnIndexOrThrow("id")));
                service.setName(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_NAME)));
                service.setSize(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("size")));
                service.setCapacity(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_CAPACITY)));
                service.setDimensions(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_DIMENSIONS)));
                service.setDescription(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("description")));
                service.setIdealFor(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_IDEAL_FOR)));
                service.setImageUrl(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("image_url")));
                arrayList.add(service);
            } while (cursorQuery.moveToNext());
        }
        cursorQuery.close();
        readableDatabase.close();
        return arrayList;
    }

    public Service getServiceById(int i) {
        Service service;
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor cursorQuery = readableDatabase.query(TABLE_SERVICES, null, "id=?", new String[]{String.valueOf(i)}, null, null, null);
        if (cursorQuery.moveToFirst()) {
            service = new Service();
            service.setId(cursorQuery.getInt(cursorQuery.getColumnIndexOrThrow("id")));
            service.setName(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_NAME)));
            service.setSize(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("size")));
            service.setCapacity(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_CAPACITY)));
            service.setDimensions(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_DIMENSIONS)));
            service.setDescription(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("description")));
            service.setIdealFor(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_SERVICE_IDEAL_FOR)));
            service.setImageUrl(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("image_url")));
        } else {
            service = null;
        }
        cursorQuery.close();
        readableDatabase.close();
        return service;
    }

    public List<Pricing> getAllPricing() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor cursorQuery = readableDatabase.query(TABLE_PRICING, null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                Pricing pricing = new Pricing();
                pricing.setId(cursorQuery.getInt(cursorQuery.getColumnIndexOrThrow("id")));
                pricing.setSize(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("size")));
                pricing.setWeeklyRate(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_PRICING_WEEKLY)));
                pricing.setDailyRate(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_PRICING_DAILY)));
                arrayList.add(pricing);
            } while (cursorQuery.moveToNext());
        }
        cursorQuery.close();
        readableDatabase.close();
        return arrayList;
    }

    public List<GalleryItem> getAllGalleryItems() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor cursorQuery = readableDatabase.query(TABLE_GALLERY, null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                GalleryItem galleryItem = new GalleryItem();
                galleryItem.setId(cursorQuery.getInt(cursorQuery.getColumnIndexOrThrow("id")));
                galleryItem.setImageUrl(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("image_url")));
                galleryItem.setTitle(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(COL_GALLERY_TITLE)));
                galleryItem.setDescription(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("description")));
                arrayList.add(galleryItem);
            } while (cursorQuery.moveToNext());
        }
        cursorQuery.close();
        readableDatabase.close();
        return arrayList;
    }
}
