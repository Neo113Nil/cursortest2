package com.duncandumps.duncandumps;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.duncandumps.duncandumps.ServiceAdapter;
import com.duncandumps.duncandumps.databinding.FragmentServicesBinding;

/* loaded from: classes.dex */
public class ServicesFragment extends Fragment {
    private ServiceAdapter adapter;
    private FragmentServicesBinding binding;
    private DatabaseHelper dbHelper;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentServicesBinding fragmentServicesBindingInflate = FragmentServicesBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = fragmentServicesBindingInflate;
        return fragmentServicesBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.dbHelper = new DatabaseHelper(getActivity());
        this.binding.recyclerViewServices.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.adapter = new ServiceAdapter(this.dbHelper.getAllServices(), new ServiceAdapter.OnServiceClickListener() { // from class: com.duncandumps.duncandumps.ServicesFragment$$ExternalSyntheticLambda0
            @Override // com.duncandumps.duncandumps.ServiceAdapter.OnServiceClickListener
            public final void onServiceClick(Service service) {
                this.f$0.m107x382f5c6d(service);
            }
        });
        this.binding.recyclerViewServices.setAdapter(this.adapter);
    }

    /* renamed from: lambda$onViewCreated$0$com-duncandumps-duncandumps-ServicesFragment, reason: not valid java name */
    /* synthetic */ void m107x382f5c6d(Service service) {
        Intent intent = new Intent(getActivity(), (Class<?>) DetailActivity.class);
        intent.putExtra("service_id", service.getId());
        startActivity(intent);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
