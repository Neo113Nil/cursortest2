package com.duncandumps.duncandumps;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

/* loaded from: classes.dex */
public class GalleryAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<GalleryItem> galleryItems;

    public GalleryAdapter(List<GalleryItem> list) {
        this.galleryItems = list;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_gallery, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.bind(this.galleryItems.get(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.galleryItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private ImageView imageView;

        ViewHolder(View view) {
            super(view);
            this.cardView = (CardView) view.findViewById(R.id.card_gallery);
            this.imageView = (ImageView) view.findViewById(R.id.image_gallery);
        }

        void bind(GalleryItem galleryItem) {
            Glide.with(this.itemView.getContext()).load(galleryItem.getImageUrl()).placeholder(R.drawable.card_background).error(R.drawable.card_background).centerCrop().into(this.imageView);
        }
    }
}
