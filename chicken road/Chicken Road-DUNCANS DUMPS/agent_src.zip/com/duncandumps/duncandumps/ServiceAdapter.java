package com.duncandumps.duncandumps;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

/* loaded from: classes.dex */
public class ServiceAdapter extends RecyclerView.Adapter<ViewHolder> {
    private OnServiceClickListener listener;
    private List<Service> services;

    public interface OnServiceClickListener {
        void onServiceClick(Service service);
    }

    public ServiceAdapter(List<Service> list, OnServiceClickListener onServiceClickListener) {
        this.services = list;
        this.listener = onServiceClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_service, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.bind(this.services.get(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.services.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private ImageView imageView;
        private TextView textCapacity;
        private TextView textName;
        private TextView textSize;

        ViewHolder(View view) {
            super(view);
            this.cardView = (CardView) view.findViewById(R.id.card_service);
            this.imageView = (ImageView) view.findViewById(R.id.image_service);
            this.textName = (TextView) view.findViewById(R.id.text_service_name);
            this.textSize = (TextView) view.findViewById(R.id.text_service_size);
            this.textCapacity = (TextView) view.findViewById(R.id.text_service_capacity);
            this.cardView.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.ServiceAdapter$ViewHolder$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m106xe626cc58(view2);
                }
            });
        }

        /* renamed from: lambda$new$0$com-duncandumps-duncandumps-ServiceAdapter$ViewHolder, reason: not valid java name */
        /* synthetic */ void m106xe626cc58(View view) {
            int adapterPosition = getAdapterPosition();
            if (adapterPosition == -1 || ServiceAdapter.this.listener == null) {
                return;
            }
            ServiceAdapter.this.listener.onServiceClick((Service) ServiceAdapter.this.services.get(adapterPosition));
        }

        void bind(Service service) {
            this.textName.setText(service.getName());
            this.textSize.setText(service.getSize() + " Yard");
            this.textCapacity.setText(service.getCapacity());
            Glide.with(this.itemView.getContext()).load(service.getImageUrl()).placeholder(R.drawable.card_background).error(R.drawable.card_background).into(this.imageView);
        }
    }
}
