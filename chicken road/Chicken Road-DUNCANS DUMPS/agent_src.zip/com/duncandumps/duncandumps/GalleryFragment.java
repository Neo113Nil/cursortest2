package com.duncandumps.duncandumps;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import com.duncandumps.duncandumps.databinding.FragmentGalleryBinding;

/* loaded from: classes.dex */
public class GalleryFragment extends Fragment {
    private GalleryAdapter adapter;
    private FragmentGalleryBinding binding;
    private DatabaseHelper dbHelper;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentGalleryBinding fragmentGalleryBindingInflate = FragmentGalleryBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = fragmentGalleryBindingInflate;
        return fragmentGalleryBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.dbHelper = new DatabaseHelper(getActivity());
        this.binding.recyclerViewGallery.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        this.adapter = new GalleryAdapter(this.dbHelper.getAllGalleryItems());
        this.binding.recyclerViewGallery.setAdapter(this.adapter);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
