package com.duncandumps.duncandumps;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/* loaded from: classes.dex */
public class PricingAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<Pricing> pricingList;

    public PricingAdapter(List<Pricing> list) {
        this.pricingList = list;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_pricing, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.bind(this.pricingList.get(i));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.pricingList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private TextView textDaily;
        private TextView textSize;
        private TextView textWeekly;

        ViewHolder(View view) {
            super(view);
            this.cardView = (CardView) view.findViewById(R.id.card_pricing);
            this.textSize = (TextView) view.findViewById(R.id.text_pricing_size);
            this.textWeekly = (TextView) view.findViewById(R.id.text_pricing_weekly);
            this.textDaily = (TextView) view.findViewById(R.id.text_pricing_daily);
        }

        void bind(Pricing pricing) {
            this.textSize.setText(pricing.getSize());
            this.textWeekly.setText(pricing.getWeeklyRate());
            this.textDaily.setText(pricing.getDailyRate());
        }
    }
}
