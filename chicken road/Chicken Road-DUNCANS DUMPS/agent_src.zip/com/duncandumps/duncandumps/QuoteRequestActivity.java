package com.duncandumps.duncandumps;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.duncandumps.duncandumps.databinding.ActivityQuoteRequestBinding;

/* loaded from: classes.dex */
public class QuoteRequestActivity extends AppCompatActivity {
    private ActivityQuoteRequestBinding binding;
    private String preselectedSize;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityQuoteRequestBinding activityQuoteRequestBindingInflate = ActivityQuoteRequestBinding.inflate(getLayoutInflater());
        this.binding = activityQuoteRequestBindingInflate;
        setContentView(activityQuoteRequestBindingInflate.getRoot());
        setSupportActionBar(this.binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        this.preselectedSize = getIntent().getStringExtra("service_size");
        setupSpinners();
        this.binding.btnSubmit.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.QuoteRequestActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m101xc0f83430(view);
            }
        });
    }

    /* renamed from: lambda$onCreate$0$com-duncandumps-duncandumps-QuoteRequestActivity, reason: not valid java name */
    /* synthetic */ void m101xc0f83430(View view) {
        submitQuoteRequest();
    }

    private void setupSpinners() {
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource = ArrayAdapter.createFromResource(this, R.array.project_types, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerProjectType.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource);
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource2 = ArrayAdapter.createFromResource(this, R.array.dumpster_sizes, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerDumpsterSize.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource2);
        if (this.preselectedSize != null) {
            int i = 0;
            while (true) {
                if (i >= this.binding.spinnerDumpsterSize.getCount()) {
                    break;
                }
                if (this.binding.spinnerDumpsterSize.getItemAtPosition(i).toString().contains(this.preselectedSize)) {
                    this.binding.spinnerDumpsterSize.setSelection(i);
                    break;
                }
                i++;
            }
        }
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource3 = ArrayAdapter.createFromResource(this, R.array.durations, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerDuration.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource3);
    }

    private void submitQuoteRequest() {
        String strTrim = this.binding.editName.getText().toString().trim();
        String strTrim2 = this.binding.editPhone.getText().toString().trim();
        String strTrim3 = this.binding.editEmail.getText().toString().trim();
        String string = this.binding.spinnerProjectType.getSelectedItem().toString();
        String string2 = this.binding.spinnerDumpsterSize.getSelectedItem().toString();
        String string3 = this.binding.spinnerDuration.getSelectedItem().toString();
        String strTrim4 = this.binding.editMessage.getText().toString().trim();
        if (TextUtils.isEmpty(strTrim) || TextUtils.isEmpty(strTrim2) || TextUtils.isEmpty(strTrim3)) {
            Toast.makeText(this, R.string.quote_error, 0).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(strTrim3).matches()) {
            Toast.makeText(this, "Please enter a valid email address", 0).show();
        } else {
            sendQuoteEmail(strTrim, strTrim2, strTrim3, string, string2, string3, strTrim4);
        }
    }

    private void sendQuoteEmail(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("message/rfc822");
        intent.putExtra("android.intent.extra.EMAIL", new String[]{"Jeremy@duncandumps.info"});
        intent.putExtra("android.intent.extra.SUBJECT", "Quote Request - " + str);
        StringBuilder sbAppend = new StringBuilder("Quote Request Details:\n\nName: ").append(str).append("\nPhone: ").append(str2).append("\nEmail: ").append(str3).append("\nProject Type: ").append(str4).append("\nDumpster Size: ").append(str5).append("\nDuration: ").append(str6).append("\nAdditional Details: ");
        if (str7.isEmpty()) {
            str7 = "None";
        }
        intent.putExtra("android.intent.extra.TEXT", sbAppend.append(str7).toString());
        try {
            startActivity(Intent.createChooser(intent, "Send Quote Request"));
            Toast.makeText(this, R.string.quote_success, 1).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Error sending email: " + e.getMessage(), 0).show();
        }
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
