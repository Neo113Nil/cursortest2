package com.duncandumps.duncandumps;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.duncandumps.duncandumps.databinding.FragmentPricingBinding;

/* loaded from: classes.dex */
public class PricingFragment extends Fragment {
    private PricingAdapter adapter;
    private FragmentPricingBinding binding;
    private DatabaseHelper dbHelper;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentPricingBinding fragmentPricingBindingInflate = FragmentPricingBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = fragmentPricingBindingInflate;
        return fragmentPricingBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.dbHelper = new DatabaseHelper(getActivity());
        this.binding.recyclerViewPricing.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.adapter = new PricingAdapter(this.dbHelper.getAllPricing());
        this.binding.recyclerViewPricing.setAdapter(this.adapter);
        this.binding.btnGetQuote.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.PricingFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m100x3ad20cb7(view2);
            }
        });
    }

    /* renamed from: lambda$onViewCreated$0$com-duncandumps-duncandumps-PricingFragment, reason: not valid java name */
    /* synthetic */ void m100x3ad20cb7(View view) {
        startActivity(new Intent(getActivity(), (Class<?>) QuoteRequestActivity.class));
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
