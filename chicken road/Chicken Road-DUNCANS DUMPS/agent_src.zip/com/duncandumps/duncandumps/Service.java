package com.duncandumps.duncandumps;

/* loaded from: classes.dex */
public class Service {
    private String capacity;
    private String description;
    private String dimensions;
    private int id;
    private String idealFor;
    private String imageUrl;
    private String name;
    private String size;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public String getCapacity() {
        return this.capacity;
    }

    public void setCapacity(String str) {
        this.capacity = str;
    }

    public String getDimensions() {
        return this.dimensions;
    }

    public void setDimensions(String str) {
        this.dimensions = str;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public String getIdealFor() {
        return this.idealFor;
    }

    public void setIdealFor(String str) {
        this.idealFor = str;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public void setImageUrl(String str) {
        this.imageUrl = str;
    }
}
