package com.duncandumps.duncandumps;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.Toast;
import androidx.fragment.app.DialogFragment;
import com.duncandumps.duncandumps.databinding.DialogQuoteRequestBinding;

/* loaded from: classes.dex */
public class QuoteRequestDialog extends DialogFragment {
    private DialogQuoteRequestBinding binding;
    private OnQuoteSubmittedListener listener;
    private String preselectedSize;

    public interface OnQuoteSubmittedListener {
        void onQuoteSubmitted();
    }

    public static QuoteRequestDialog newInstance(String str) {
        QuoteRequestDialog quoteRequestDialog = new QuoteRequestDialog();
        Bundle bundle = new Bundle();
        bundle.putString("service_size", str);
        quoteRequestDialog.setArguments(bundle);
        return quoteRequestDialog;
    }

    public void setOnQuoteSubmittedListener(OnQuoteSubmittedListener onQuoteSubmittedListener) {
        this.listener = onQuoteSubmittedListener;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            this.preselectedSize = getArguments().getString("service_size");
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        Dialog dialogOnCreateDialog = super.onCreateDialog(bundle);
        dialogOnCreateDialog.requestWindowFeature(1);
        if (dialogOnCreateDialog.getWindow() != null) {
            dialogOnCreateDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialogOnCreateDialog.getWindow().setLayout(-1, -2);
        }
        return dialogOnCreateDialog;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog == null || dialog.getWindow() == null) {
            return;
        }
        dialog.getWindow().setLayout(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.9d));
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        DialogQuoteRequestBinding dialogQuoteRequestBindingInflate = DialogQuoteRequestBinding.inflate(layoutInflater, viewGroup, false);
        this.binding = dialogQuoteRequestBindingInflate;
        return dialogQuoteRequestBindingInflate.getRoot();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        setupSpinners();
        this.binding.btnCancel.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.QuoteRequestDialog$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m102x94a7a77a(view2);
            }
        });
        this.binding.btnSubmit.setOnClickListener(new View.OnClickListener() { // from class: com.duncandumps.duncandumps.QuoteRequestDialog$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m103xce724959(view2);
            }
        });
    }

    /* renamed from: lambda$onViewCreated$0$com-duncandumps-duncandumps-QuoteRequestDialog, reason: not valid java name */
    /* synthetic */ void m102x94a7a77a(View view) {
        dismiss();
    }

    /* renamed from: lambda$onViewCreated$1$com-duncandumps-duncandumps-QuoteRequestDialog, reason: not valid java name */
    /* synthetic */ void m103xce724959(View view) {
        submitQuoteRequest();
    }

    private void setupSpinners() {
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource = ArrayAdapter.createFromResource(getContext(), R.array.project_types, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerProjectType.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource);
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource2 = ArrayAdapter.createFromResource(getContext(), R.array.dumpster_sizes, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerDumpsterSize.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource2);
        if (this.preselectedSize != null) {
            int i = 0;
            while (true) {
                if (i >= this.binding.spinnerDumpsterSize.getCount()) {
                    break;
                }
                if (this.binding.spinnerDumpsterSize.getItemAtPosition(i).toString().contains(this.preselectedSize)) {
                    this.binding.spinnerDumpsterSize.setSelection(i);
                    break;
                }
                i++;
            }
        }
        ArrayAdapter<CharSequence> arrayAdapterCreateFromResource3 = ArrayAdapter.createFromResource(getContext(), R.array.durations, android.R.layout.simple_spinner_item);
        arrayAdapterCreateFromResource3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.binding.spinnerDuration.setAdapter((SpinnerAdapter) arrayAdapterCreateFromResource3);
    }

    private void submitQuoteRequest() {
        String strTrim = this.binding.editName.getText().toString().trim();
        String strTrim2 = this.binding.editPhone.getText().toString().trim();
        String strTrim3 = this.binding.editEmail.getText().toString().trim();
        String string = this.binding.spinnerProjectType.getSelectedItem().toString();
        String string2 = this.binding.spinnerDumpsterSize.getSelectedItem().toString();
        String string3 = this.binding.spinnerDuration.getSelectedItem().toString();
        String strTrim4 = this.binding.editMessage.getText().toString().trim();
        if (TextUtils.isEmpty(strTrim) || TextUtils.isEmpty(strTrim2) || TextUtils.isEmpty(strTrim3)) {
            Toast.makeText(getContext(), R.string.quote_error, 0).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(strTrim3).matches()) {
            Toast.makeText(getContext(), "Please enter a valid email address", 0).show();
        } else {
            sendQuoteEmail(strTrim, strTrim2, strTrim3, string, string2, string3, strTrim4);
        }
    }

    private void sendQuoteEmail(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("message/rfc822");
        intent.putExtra("android.intent.extra.EMAIL", new String[]{"Jeremy@duncandumps.info"});
        intent.putExtra("android.intent.extra.SUBJECT", "Quote Request - " + str);
        StringBuilder sbAppend = new StringBuilder("Quote Request Details:\n\nName: ").append(str).append("\nPhone: ").append(str2).append("\nEmail: ").append(str3).append("\nProject Type: ").append(str4).append("\nDumpster Size: ").append(str5).append("\nDuration: ").append(str6).append("\nAdditional Details: ");
        if (str7.isEmpty()) {
            str7 = "None";
        }
        intent.putExtra("android.intent.extra.TEXT", sbAppend.append(str7).toString());
        try {
            startActivity(Intent.createChooser(intent, "Send Quote Request"));
            Toast.makeText(getContext(), R.string.quote_success, 1).show();
            OnQuoteSubmittedListener onQuoteSubmittedListener = this.listener;
            if (onQuoteSubmittedListener != null) {
                onQuoteSubmittedListener.onQuoteSubmitted();
            }
            dismiss();
        } catch (Exception e) {
            Toast.makeText(getContext(), "Error sending email: " + e.getMessage(), 0).show();
        }
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.binding = null;
    }
}
