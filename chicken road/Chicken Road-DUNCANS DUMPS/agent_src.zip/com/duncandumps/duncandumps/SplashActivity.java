package com.duncandumps.duncandumps;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

/* loaded from: classes.dex */
public class SplashActivity extends AppCompatActivity {
    private static final int SPLASH_DURATION = 2000;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        new DatabaseHelper(this).getReadableDatabase();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.duncandumps.duncandumps.SplashActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m108lambda$onCreate$0$comduncandumpsduncandumpsSplashActivity();
            }
        }, 2000L);
    }

    /* renamed from: lambda$onCreate$0$com-duncandumps-duncandumps-SplashActivity, reason: not valid java name */
    /* synthetic */ void m108lambda$onCreate$0$comduncandumpsduncandumpsSplashActivity() {
        startActivity(new Intent(this, (Class<?>) MainActivity.class));
        finish();
    }
}
