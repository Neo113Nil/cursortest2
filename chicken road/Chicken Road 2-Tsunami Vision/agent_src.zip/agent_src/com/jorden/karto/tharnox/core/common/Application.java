package com.jorden.karto.tharnox.core.common;

import defpackage.b60;
import defpackage.c7;
import defpackage.e7;
import defpackage.fm0;

/* compiled from: r8-map-id-0ef116201bfba75a5e23d2a2fd2694ebb482d2746575d9f5ff2cb05c4953491c */
/* loaded from: classes.dex */
public final class Application extends android.app.Application implements b60 {
    public boolean nDR3Uogi2xaQ2D = false;
    public final c7 Pn1NpG9cDjs1OP = new c7(new fm0(this, (byte) 17));

    @Override // defpackage.b60
    public final Object CIgcrF0bZ8iJHa() {
        return this.Pn1NpG9cDjs1OP.CIgcrF0bZ8iJHa();
    }

    @Override // android.app.Application
    public final void onCreate() {
        if (!this.nDR3Uogi2xaQ2D) {
            this.nDR3Uogi2xaQ2D = true;
            ((e7) this.Pn1NpG9cDjs1OP.CIgcrF0bZ8iJHa()).getClass();
        }
        super.onCreate();
    }
}
