package com.jorden.karto.tharnox.data.local;

import com.jorden.karto.tharnox.data.local.AppDatabase_Impl;
import defpackage.f81;
import defpackage.fh;
import defpackage.ix0;
import defpackage.ka1;
import defpackage.kd0;
import defpackage.le;
import defpackage.ln1;
import defpackage.mx;
import defpackage.n40;
import defpackage.o30;
import defpackage.v6;
import defpackage.xa1;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-0ef116201bfba75a5e23d2a2fd2694ebb482d2746575d9f5ff2cb05c4953491c */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final ln1 IkoTysJPbVmEqE;
    public final ln1 MVETIjJbbXkmQY;
    public final ln1 RGJBi0kIUO37rD;
    public final ln1 YULV1J4uSBGJOh;

    public AppDatabase_Impl() {
        final byte b = 0;
        this.MVETIjJbbXkmQY = new ln1(new n40(this) { // from class: u6
            public final /* synthetic */ AppDatabase_Impl Pn1NpG9cDjs1OP;

            {
                this.Pn1NpG9cDjs1OP = this;
            }

            @Override // defpackage.n40
            public final Object FkjWety0564VM8() {
                byte b2 = b;
                AppDatabase_Impl appDatabase_Impl = this.Pn1NpG9cDjs1OP;
                switch (b2) {
                    case 0:
                        return new o30(appDatabase_Impl);
                    case 1:
                        return new xa1(appDatabase_Impl);
                    case i51.FLOAT_FIELD_NUMBER /* 2 */:
                        return new fh(appDatabase_Impl);
                    default:
                        return new ix0(appDatabase_Impl);
                }
            }
        });
        final byte b2 = 1;
        this.IkoTysJPbVmEqE = new ln1(new n40(this) { // from class: u6
            public final /* synthetic */ AppDatabase_Impl Pn1NpG9cDjs1OP;

            {
                this.Pn1NpG9cDjs1OP = this;
            }

            @Override // defpackage.n40
            public final Object FkjWety0564VM8() {
                byte b22 = b2;
                AppDatabase_Impl appDatabase_Impl = this.Pn1NpG9cDjs1OP;
                switch (b22) {
                    case 0:
                        return new o30(appDatabase_Impl);
                    case 1:
                        return new xa1(appDatabase_Impl);
                    case i51.FLOAT_FIELD_NUMBER /* 2 */:
                        return new fh(appDatabase_Impl);
                    default:
                        return new ix0(appDatabase_Impl);
                }
            }
        });
        final byte b3 = 2;
        this.RGJBi0kIUO37rD = new ln1(new n40(this) { // from class: u6
            public final /* synthetic */ AppDatabase_Impl Pn1NpG9cDjs1OP;

            {
                this.Pn1NpG9cDjs1OP = this;
            }

            @Override // defpackage.n40
            public final Object FkjWety0564VM8() {
                byte b22 = b3;
                AppDatabase_Impl appDatabase_Impl = this.Pn1NpG9cDjs1OP;
                switch (b22) {
                    case 0:
                        return new o30(appDatabase_Impl);
                    case 1:
                        return new xa1(appDatabase_Impl);
                    case i51.FLOAT_FIELD_NUMBER /* 2 */:
                        return new fh(appDatabase_Impl);
                    default:
                        return new ix0(appDatabase_Impl);
                }
            }
        });
        final byte b4 = 3;
        this.YULV1J4uSBGJOh = new ln1(new n40(this) { // from class: u6
            public final /* synthetic */ AppDatabase_Impl Pn1NpG9cDjs1OP;

            {
                this.Pn1NpG9cDjs1OP = this;
            }

            @Override // defpackage.n40
            public final Object FkjWety0564VM8() {
                byte b22 = b4;
                AppDatabase_Impl appDatabase_Impl = this.Pn1NpG9cDjs1OP;
                switch (b22) {
                    case 0:
                        return new o30(appDatabase_Impl);
                    case 1:
                        return new xa1(appDatabase_Impl);
                    case i51.FLOAT_FIELD_NUMBER /* 2 */:
                        return new fh(appDatabase_Impl);
                    default:
                        return new ix0(appDatabase_Impl);
                }
            }
        });
    }

    @Override // defpackage.ha1
    public final List FkjWety0564VM8(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // com.jorden.karto.tharnox.data.local.AppDatabase
    public final o30 IkoTysJPbVmEqE() {
        return (o30) this.MVETIjJbbXkmQY.getValue();
    }

    @Override // com.jorden.karto.tharnox.data.local.AppDatabase
    public final fh MVETIjJbbXkmQY() {
        return (fh) this.RGJBi0kIUO37rD.getValue();
    }

    @Override // defpackage.ha1
    public final LinkedHashMap Pn1NpG9cDjs1OP() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        le leVarFkjWety0564VM8 = f81.FkjWety0564VM8(o30.class);
        mx mxVar = mx.nDR3Uogi2xaQ2D;
        linkedHashMap.put(leVarFkjWety0564VM8, mxVar);
        linkedHashMap.put(f81.FkjWety0564VM8(xa1.class), mxVar);
        linkedHashMap.put(f81.FkjWety0564VM8(fh.class), mxVar);
        linkedHashMap.put(f81.FkjWety0564VM8(ix0.class), mxVar);
        return linkedHashMap;
    }

    @Override // com.jorden.karto.tharnox.data.local.AppDatabase
    public final ix0 RGJBi0kIUO37rD() {
        return (ix0) this.YULV1J4uSBGJOh.getValue();
    }

    @Override // com.jorden.karto.tharnox.data.local.AppDatabase
    public final xa1 YULV1J4uSBGJOh() {
        return (xa1) this.IkoTysJPbVmEqE.getValue();
    }

    @Override // defpackage.ha1
    public final ka1 cAfQz1b2384y5N() {
        return new v6(this);
    }

    @Override // defpackage.ha1
    public final Set nDR3Uogi2xaQ2D() {
        return new LinkedHashSet();
    }

    @Override // defpackage.ha1
    public final kd0 pcCugQFxLtvOB6() {
        return new kd0(this, new LinkedHashMap(), new LinkedHashMap(), "frames", "runs", "compare_pairs", "open_events");
    }
}
