package com.jorden.karto.tharnox.data.local;

import defpackage.fh;
import defpackage.ha1;
import defpackage.ix0;
import defpackage.o30;
import defpackage.xa1;

/* compiled from: r8-map-id-0ef116201bfba75a5e23d2a2fd2694ebb482d2746575d9f5ff2cb05c4953491c */
/* loaded from: classes.dex */
public abstract class AppDatabase extends ha1 {
    public abstract o30 IkoTysJPbVmEqE();

    public abstract fh MVETIjJbbXkmQY();

    public abstract ix0 RGJBi0kIUO37rD();

    public abstract xa1 YULV1J4uSBGJOh();
}
