package com.jorden.karto.tharnox.presentation;

import android.R;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.b60;
import defpackage.bi;
import defpackage.br;
import defpackage.cb0;
import defpackage.ci;
import defpackage.eo;
import defpackage.eo1;
import defpackage.ew;
import defpackage.f81;
import defpackage.fw;
import defpackage.g30;
import defpackage.gw;
import defpackage.h80;
import defpackage.hw;
import defpackage.i7;
import defpackage.ig0;
import defpackage.ii;
import defpackage.ij;
import defpackage.il1;
import defpackage.iw;
import defpackage.j80;
import defpackage.jd1;
import defpackage.jl1;
import defpackage.jw;
import defpackage.kK3V1TlE7VYqev;
import defpackage.kp0;
import defpackage.kw;
import defpackage.le;
import defpackage.lw;
import defpackage.m2PWC63cAv3pgk;
import defpackage.mn1;
import defpackage.mw;
import defpackage.nG9eglvHuuEsjO;
import defpackage.nm;
import defpackage.nw;
import defpackage.ol;
import defpackage.qz1;
import defpackage.rn1;
import defpackage.sn;
import defpackage.sz1;
import defpackage.wp;
import defpackage.xo;
import defpackage.zCpaUnEYHNaE36;

/* compiled from: r8-map-id-0ef116201bfba75a5e23d2a2fd2694ebb482d2746575d9f5ff2cb05c4953491c */
/* loaded from: classes.dex */
public final class MainActivity extends bi implements b60 {
    public volatile zCpaUnEYHNaE36 gxRpJE8pSEo0rk;
    public final Object tkCPMUzf1vO1QG = new Object();
    public boolean GuL8j1Iqe69D7s = false;

    public MainActivity() {
        j80 j80Var = new j80(this);
        ol olVar = this.Pn1NpG9cDjs1OP;
        olVar.getClass();
        bi biVar = olVar.pcCugQFxLtvOB6;
        if (biVar != null) {
            j80Var.FkjWety0564VM8(biVar);
        }
        olVar.FkjWety0564VM8.add(j80Var);
    }

    @Override // defpackage.b60
    public final Object CIgcrF0bZ8iJHa() {
        return MVETIjJbbXkmQY().CIgcrF0bZ8iJHa();
    }

    public final void IkoTysJPbVmEqE(Bundle bundle) {
        super.onCreate(bundle);
        zCpaUnEYHNaE36 zcpauneyhnae36MVETIjJbbXkmQY = MVETIjJbbXkmQY();
        kK3V1TlE7VYqev kk3v1tle7vyqev = zcpauneyhnae36MVETIjJbbXkmQY.qW8RbmLZuYuLHe;
        MainActivity mainActivity = kk3v1tle7vyqev.nDR3Uogi2xaQ2D;
        nG9eglvHuuEsjO ng9eglvhuuesjo = new nG9eglvHuuEsjO(kk3v1tle7vyqev.Pn1NpG9cDjs1OP, (byte) 0);
        sz1 sz1VarFY5PJrtQy0M6CO = mainActivity.fY5PJrtQy0M6CO();
        sn snVarQW8RbmLZuYuLHe = rn1.qW8RbmLZuYuLHe(mainActivity);
        snVarQW8RbmLZuYuLHe.getClass();
        xo xoVar = new xo(sz1VarFY5PJrtQy0M6CO, ng9eglvhuuesjo, snVarQW8RbmLZuYuLHe);
        le leVarFkjWety0564VM8 = f81.FkjWety0564VM8(m2PWC63cAv3pgk.class);
        String strPcCugQFxLtvOB6 = leVarFkjWety0564VM8.pcCugQFxLtvOB6();
        if (strPcCugQFxLtvOB6 == null) {
            i7.eQ83NNNvjDo37z("Local and anonymous classes can not be ViewModels");
            return;
        }
        g30 g30Var = ((m2PWC63cAv3pgk) xoVar.eQ83NNNvjDo37z(leVarFkjWety0564VM8, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strPcCugQFxLtvOB6))).cAfQz1b2384y5N;
        zcpauneyhnae36MVETIjJbbXkmQY.m8q1wcUjawyDdM = g30Var;
        if (((kp0) g30Var.Pn1NpG9cDjs1OP) == null) {
            kp0 kp0VarPn1NpG9cDjs1OP = zcpauneyhnae36MVETIjJbbXkmQY.fY5PJrtQy0M6CO.Pn1NpG9cDjs1OP();
            if (g30Var.nDR3Uogi2xaQ2D) {
                g30Var.Pn1NpG9cDjs1OP = kp0VarPn1NpG9cDjs1OP;
            } else {
                i7.lO97CL2MzFoEOk("setExtras should only be called for an Activity that extends ComponentActivity");
            }
        }
    }

    public final zCpaUnEYHNaE36 MVETIjJbbXkmQY() {
        if (this.gxRpJE8pSEo0rk == null) {
            synchronized (this.tkCPMUzf1vO1QG) {
                try {
                    if (this.gxRpJE8pSEo0rk == null) {
                        this.gxRpJE8pSEo0rk = new zCpaUnEYHNaE36(this);
                    }
                } finally {
                }
            }
        }
        return this.gxRpJE8pSEo0rk;
    }

    @Override // defpackage.y70
    public final qz1 nDR3Uogi2xaQ2D() {
        qz1 qz1Var = (qz1) this.kAD5uYHmhKh2j5.getValue();
        eo eoVar = (eo) ((br) nm.RpNLTigAiGiRX3(this, br.class));
        ig0 ig0VarFkjWety0564VM8 = eoVar.FkjWety0564VM8();
        cb0 cb0Var = new cb0((Object) eoVar.FkjWety0564VM8, (Object) eoVar.pcCugQFxLtvOB6, (byte) 6);
        qz1Var.getClass();
        return new h80(ig0VarFkjWety0564VM8, qz1Var, cb0Var);
    }

    @Override // defpackage.bi, defpackage.ai, android.app.Activity
    public final void onCreate(Bundle bundle) {
        byte b = 10;
        mn1 mn1Var = new mn1(new jd1(b));
        mn1 mn1Var2 = new mn1(new jd1(b));
        nw nwVar = gw.FkjWety0564VM8;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        nw mwVar = gw.FkjWety0564VM8;
        if (mwVar == null) {
            int i = Build.VERSION.SDK_INT;
            mwVar = i >= 35 ? new mw() : i >= 30 ? new lw() : i >= 29 ? new kw() : i >= 28 ? new jw() : i >= 26 ? new iw() : new hw();
            gw.FkjWety0564VM8 = mwVar;
        }
        nw nwVar2 = mwVar;
        ew ewVar = new ew(nwVar2, mn1Var, mn1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                fw fwVar = new fw(ewVar, viewGroup.getContext());
                fwVar.setTag(nwVar2);
                fwVar.setVisibility(8);
                fwVar.setWillNotDraw(true);
                viewGroup.addView(fwVar);
                break;
            }
            int i3 = i2 + 1;
            View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof nw) {
                break;
            } else {
                i2 = i3;
            }
        }
        ewVar.run();
        Window window = getWindow();
        window.getClass();
        nwVar2.FkjWety0564VM8(window);
        IkoTysJPbVmEqE(bundle);
        ii iiVar = wp.qW8RbmLZuYuLHe;
        ViewGroup.LayoutParams layoutParams = ci.FkjWety0564VM8;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(R.id.content)).getChildAt(0);
        ij ijVar = childAt2 instanceof ij ? (ij) childAt2 : null;
        if (ijVar != null) {
            ijVar.setParentCompositionContext(null);
            ijVar.setContent(iiVar);
            return;
        }
        ij ijVar2 = new ij(this);
        ijVar2.setParentCompositionContext(null);
        ijVar2.setContent(iiVar);
        View decorView2 = getWindow().getDecorView();
        if (eo1.nDR3Uogi2xaQ2D(decorView2) == null) {
            decorView2.setTag(com.jorden.karto.tharnox.R.id.view_tree_lifecycle_owner, this);
        }
        if (jl1.cAfQz1b2384y5N(decorView2) == null) {
            decorView2.setTag(com.jorden.karto.tharnox.R.id.view_tree_view_model_store_owner, this);
        }
        if (il1.znlx3dfm2Jie8F(decorView2) == null) {
            decorView2.setTag(com.jorden.karto.tharnox.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(ijVar2, ci.FkjWety0564VM8);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        g30 g30Var = MVETIjJbbXkmQY().m8q1wcUjawyDdM;
        if (g30Var != null) {
            g30Var.Pn1NpG9cDjs1OP = null;
        }
    }
}
