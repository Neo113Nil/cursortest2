package com.watchfacestudio.wartan;

/* loaded from: classes.dex */
public final class R {

    /* JADX INFO: Added by JADX */
    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_in = 0x7f010000;

        /* JADX INFO: Added by JADX */
        public static final int abc_fade_out = 0x7f010001;

        /* JADX INFO: Added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 0x7f010002;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_enter = 0x7f010003;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_exit = 0x7f010004;

        /* JADX INFO: Added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 0x7f010005;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_bottom = 0x7f010006;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_in_top = 0x7f010007;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_bottom = 0x7f010008;

        /* JADX INFO: Added by JADX */
        public static final int abc_slide_out_top = 0x7f010009;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_enter = 0x7f01000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip_exit = 0x7f01000b;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 0x7f01000c;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 0x7f01000d;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 0x7f01000e;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 0x7f01000f;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 0x7f010010;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 0x7f010011;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 0x7f010012;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 0x7f010013;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 0x7f010014;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 0x7f010015;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 0x7f010016;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 0x7f010017;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_slide_in = 0x7f010018;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_slide_out = 0x7f010019;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_in = 0x7f01001a;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_out = 0x7f01001b;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 0x7f01001c;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line1_head_interpolator = 0x7f01001d;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line1_tail_interpolator = 0x7f01001e;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line2_head_interpolator = 0x7f01001f;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line2_tail_interpolator = 0x7f010020;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_slide_in = 0x7f010021;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_slide_out = 0x7f010022;

        /* JADX INFO: Added by JADX */
        public static final int m3_motion_fade_enter = 0x7f010023;

        /* JADX INFO: Added by JADX */
        public static final int m3_motion_fade_exit = 0x7f010024;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_enter_from_left = 0x7f010025;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_enter_from_right = 0x7f010026;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_exit_to_left = 0x7f010027;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_exit_to_right = 0x7f010028;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottom_sheet_slide_in = 0x7f010029;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottom_sheet_slide_out = 0x7f01002a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_lowers_interpolator = 0x7f01002b;
    }

    /* JADX INFO: Added by JADX */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int chevron_checked_unchecked = 0x7f020000;

        /* JADX INFO: Added by JADX */
        public static final int chevron_unchecked_checked = 0x7f020001;

        /* JADX INFO: Added by JADX */
        public static final int design_appbar_state_list_animator = 0x7f020002;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_hide_motion_spec = 0x7f020003;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_show_motion_spec = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 0x7f020005;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 0x7f020006;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 0x7f020007;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 0x7f020008;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 0x7f020009;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 0x7f02000a;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_state_list_animator = 0x7f02000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_elevated_btn_state_list_anim = 0x7f02000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_state_list_anim = 0x7f02000d;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_state_list_anim = 0x7f02000e;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_state_list_anim = 0x7f02000f;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_state_list_anim = 0x7f020010;

        /* JADX INFO: Added by JADX */
        public static final int m3_elevated_chip_state_list_anim = 0x7f020011;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_change_size_collapse_motion_spec = 0x7f020012;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_change_size_expand_motion_spec = 0x7f020013;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_hide_motion_spec = 0x7f020014;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_show_motion_spec = 0x7f020015;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_state_list_animator = 0x7f020016;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_state_list_animator = 0x7f020017;

        /* JADX INFO: Added by JADX */
        public static final int m3_split_button_chevron_overshoot_interpolator = 0x7f020018;

        /* JADX INFO: Added by JADX */
        public static final int m3_split_button_chevron_reverse_rotation = 0x7f020019;

        /* JADX INFO: Added by JADX */
        public static final int m3_split_button_chevron_rotation = 0x7f02001a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_state_list_anim = 0x7f02001b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_unelevated_state_list_anim = 0x7f02001c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_state_list_anim = 0x7f02001d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_state_list_anim = 0x7f02001e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_change_size_collapse_motion_spec = 0x7f02001f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_change_size_expand_motion_spec = 0x7f020020;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_hide_motion_spec = 0x7f020021;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_show_motion_spec = 0x7f020022;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_state_list_animator = 0x7f020023;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_hide_motion_spec = 0x7f020024;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_show_motion_spec = 0x7f020025;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_transformation_sheet_collapse_spec = 0x7f020026;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_transformation_sheet_expand_spec = 0x7f020027;
    }

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int SharedValue = 0x7f030000;

        /* JADX INFO: Added by JADX */
        public static final int SharedValueId = 0x7f030001;

        /* JADX INFO: Added by JADX */
        public static final int actionBarDivider = 0x7f030002;

        /* JADX INFO: Added by JADX */
        public static final int actionBarItemBackground = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int actionBarPopupTheme = 0x7f030004;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSize = 0x7f030005;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSplitStyle = 0x7f030006;

        /* JADX INFO: Added by JADX */
        public static final int actionBarStyle = 0x7f030007;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabBarStyle = 0x7f030008;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabStyle = 0x7f030009;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabTextStyle = 0x7f03000a;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTheme = 0x7f03000b;

        /* JADX INFO: Added by JADX */
        public static final int actionBarWidgetTheme = 0x7f03000c;

        /* JADX INFO: Added by JADX */
        public static final int actionButtonStyle = 0x7f03000d;

        /* JADX INFO: Added by JADX */
        public static final int actionDropDownStyle = 0x7f03000e;

        /* JADX INFO: Added by JADX */
        public static final int actionLayout = 0x7f03000f;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextAppearance = 0x7f030010;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextColor = 0x7f030011;

        /* JADX INFO: Added by JADX */
        public static final int actionModeBackground = 0x7f030012;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseButtonStyle = 0x7f030013;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseContentDescription = 0x7f030014;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseDrawable = 0x7f030015;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCopyDrawable = 0x7f030016;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCutDrawable = 0x7f030017;

        /* JADX INFO: Added by JADX */
        public static final int actionModeFindDrawable = 0x7f030018;

        /* JADX INFO: Added by JADX */
        public static final int actionModePasteDrawable = 0x7f030019;

        /* JADX INFO: Added by JADX */
        public static final int actionModePopupWindowStyle = 0x7f03001a;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSelectAllDrawable = 0x7f03001b;

        /* JADX INFO: Added by JADX */
        public static final int actionModeShareDrawable = 0x7f03001c;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSplitBackground = 0x7f03001d;

        /* JADX INFO: Added by JADX */
        public static final int actionModeStyle = 0x7f03001e;

        /* JADX INFO: Added by JADX */
        public static final int actionModeTheme = 0x7f03001f;

        /* JADX INFO: Added by JADX */
        public static final int actionModeWebSearchDrawable = 0x7f030020;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowButtonStyle = 0x7f030021;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowMenuStyle = 0x7f030022;

        /* JADX INFO: Added by JADX */
        public static final int actionProviderClass = 0x7f030023;

        /* JADX INFO: Added by JADX */
        public static final int actionTextColorAlpha = 0x7f030024;

        /* JADX INFO: Added by JADX */
        public static final int actionViewClass = 0x7f030025;

        /* JADX INFO: Added by JADX */
        public static final int activeIndicatorLabelPadding = 0x7f030026;

        /* JADX INFO: Added by JADX */
        public static final int activityChooserViewStyle = 0x7f030027;

        /* JADX INFO: Added by JADX */
        public static final int adaptiveMaxWidthEnabled = 0x7f030028;

        /* JADX INFO: Added by JADX */
        public static final int addElevationShadow = 0x7f030029;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogButtonGroupStyle = 0x7f03002a;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogCenterButtons = 0x7f03002b;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogStyle = 0x7f03002c;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogTheme = 0x7f03002d;

        /* JADX INFO: Added by JADX */
        public static final int allowStacking = 0x7f03002e;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f03002f;

        /* JADX INFO: Added by JADX */
        public static final int alphabeticModifiers = 0x7f030030;

        /* JADX INFO: Added by JADX */
        public static final int altSrc = 0x7f030031;

        /* JADX INFO: Added by JADX */
        public static final int animateCircleAngleTo = 0x7f030032;

        /* JADX INFO: Added by JADX */
        public static final int animateMenuItems = 0x7f030033;

        /* JADX INFO: Added by JADX */
        public static final int animateNavigationIcon = 0x7f030034;

        /* JADX INFO: Added by JADX */
        public static final int animateRelativeTo = 0x7f030035;

        /* JADX INFO: Added by JADX */
        public static final int animationMode = 0x7f030036;

        /* JADX INFO: Added by JADX */
        public static final int appBarLayoutStyle = 0x7f030037;

        /* JADX INFO: Added by JADX */
        public static final int applyMotionScene = 0x7f030038;

        /* JADX INFO: Added by JADX */
        public static final int arcMode = 0x7f030039;

        /* JADX INFO: Added by JADX */
        public static final int arrowHeadLength = 0x7f03003a;

        /* JADX INFO: Added by JADX */
        public static final int arrowShaftLength = 0x7f03003b;

        /* JADX INFO: Added by JADX */
        public static final int attributeName = 0x7f03003c;

        /* JADX INFO: Added by JADX */
        public static final int autoAdjustToWithinGrandparentBounds = 0x7f03003d;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteMode = 0x7f03003e;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteTextViewStyle = 0x7f03003f;

        /* JADX INFO: Added by JADX */
        public static final int autoShowKeyboard = 0x7f030040;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMaxTextSize = 0x7f030041;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMinTextSize = 0x7f030042;

        /* JADX INFO: Added by JADX */
        public static final int autoSizePresetSizes = 0x7f030043;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeStepGranularity = 0x7f030044;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeTextType = 0x7f030045;

        /* JADX INFO: Added by JADX */
        public static final int autoTransition = 0x7f030046;

        /* JADX INFO: Added by JADX */
        public static final int backHandlingEnabled = 0x7f030047;

        /* JADX INFO: Added by JADX */
        public static final int background = 0x7f030048;

        /* JADX INFO: Added by JADX */
        public static final int backgroundColor = 0x7f030049;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetBottom = 0x7f03004a;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetEnd = 0x7f03004b;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetStart = 0x7f03004c;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetTop = 0x7f03004d;

        /* JADX INFO: Added by JADX */
        public static final int backgroundOverlayColorAlpha = 0x7f03004e;

        /* JADX INFO: Added by JADX */
        public static final int backgroundSplit = 0x7f03004f;

        /* JADX INFO: Added by JADX */
        public static final int backgroundStacked = 0x7f030050;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTint = 0x7f030051;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTintMode = 0x7f030052;

        /* JADX INFO: Added by JADX */
        public static final int badgeFixedEdge = 0x7f030053;

        /* JADX INFO: Added by JADX */
        public static final int badgeGravity = 0x7f030054;

        /* JADX INFO: Added by JADX */
        public static final int badgeHeight = 0x7f030055;

        /* JADX INFO: Added by JADX */
        public static final int badgeRadius = 0x7f030056;

        /* JADX INFO: Added by JADX */
        public static final int badgeShapeAppearance = 0x7f030057;

        /* JADX INFO: Added by JADX */
        public static final int badgeShapeAppearanceOverlay = 0x7f030058;

        /* JADX INFO: Added by JADX */
        public static final int badgeStyle = 0x7f030059;

        /* JADX INFO: Added by JADX */
        public static final int badgeText = 0x7f03005a;

        /* JADX INFO: Added by JADX */
        public static final int badgeTextAppearance = 0x7f03005b;

        /* JADX INFO: Added by JADX */
        public static final int badgeTextColor = 0x7f03005c;

        /* JADX INFO: Added by JADX */
        public static final int badgeVerticalPadding = 0x7f03005d;

        /* JADX INFO: Added by JADX */
        public static final int badgeWidePadding = 0x7f03005e;

        /* JADX INFO: Added by JADX */
        public static final int badgeWidth = 0x7f03005f;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextHeight = 0x7f030060;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextRadius = 0x7f030061;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextShapeAppearance = 0x7f030062;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextShapeAppearanceOverlay = 0x7f030063;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextWidth = 0x7f030064;

        /* JADX INFO: Added by JADX */
        public static final int barLength = 0x7f030065;

        /* JADX INFO: Added by JADX */
        public static final int barrierAllowsGoneWidgets = 0x7f030066;

        /* JADX INFO: Added by JADX */
        public static final int barrierDirection = 0x7f030067;

        /* JADX INFO: Added by JADX */
        public static final int barrierMargin = 0x7f030068;

        /* JADX INFO: Added by JADX */
        public static final int behavior_autoExpandOnRequestChildRectangleOffscreen = 0x7f030069;

        /* JADX INFO: Added by JADX */
        public static final int behavior_autoHide = 0x7f03006a;

        /* JADX INFO: Added by JADX */
        public static final int behavior_autoShrink = 0x7f03006b;

        /* JADX INFO: Added by JADX */
        public static final int behavior_draggable = 0x7f03006c;

        /* JADX INFO: Added by JADX */
        public static final int behavior_draggableOnNestedScroll = 0x7f03006d;

        /* JADX INFO: Added by JADX */
        public static final int behavior_expandedOffset = 0x7f03006e;

        /* JADX INFO: Added by JADX */
        public static final int behavior_fitToContents = 0x7f03006f;

        /* JADX INFO: Added by JADX */
        public static final int behavior_halfExpandedRatio = 0x7f030070;

        /* JADX INFO: Added by JADX */
        public static final int behavior_hideable = 0x7f030071;

        /* JADX INFO: Added by JADX */
        public static final int behavior_multipleScrollingChildrenSupported = 0x7f030072;

        /* JADX INFO: Added by JADX */
        public static final int behavior_overlapTop = 0x7f030073;

        /* JADX INFO: Added by JADX */
        public static final int behavior_peekHeight = 0x7f030074;

        /* JADX INFO: Added by JADX */
        public static final int behavior_saveFlags = 0x7f030075;

        /* JADX INFO: Added by JADX */
        public static final int behavior_significantVelocityThreshold = 0x7f030076;

        /* JADX INFO: Added by JADX */
        public static final int behavior_skipCollapsed = 0x7f030077;

        /* JADX INFO: Added by JADX */
        public static final int blendSrc = 0x7f030078;

        /* JADX INFO: Added by JADX */
        public static final int borderRound = 0x7f030079;

        /* JADX INFO: Added by JADX */
        public static final int borderRoundPercent = 0x7f03007a;

        /* JADX INFO: Added by JADX */
        public static final int borderWidth = 0x7f03007b;

        /* JADX INFO: Added by JADX */
        public static final int borderlessButtonStyle = 0x7f03007c;

        /* JADX INFO: Added by JADX */
        public static final int bottomAppBarStyle = 0x7f03007d;

        /* JADX INFO: Added by JADX */
        public static final int bottomInsetScrimEnabled = 0x7f03007e;

        /* JADX INFO: Added by JADX */
        public static final int bottomNavigationStyle = 0x7f03007f;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetDialogTheme = 0x7f030080;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetDragHandleStyle = 0x7f030081;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetStyle = 0x7f030082;

        /* JADX INFO: Added by JADX */
        public static final int boxBackgroundColor = 0x7f030083;

        /* JADX INFO: Added by JADX */
        public static final int boxBackgroundMode = 0x7f030084;

        /* JADX INFO: Added by JADX */
        public static final int boxCollapsedPaddingTop = 0x7f030085;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusBottomEnd = 0x7f030086;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusBottomStart = 0x7f030087;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusTopEnd = 0x7f030088;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusTopStart = 0x7f030089;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeColor = 0x7f03008a;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeErrorColor = 0x7f03008b;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeWidth = 0x7f03008c;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeWidthFocused = 0x7f03008d;

        /* JADX INFO: Added by JADX */
        public static final int brightness = 0x7f03008e;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarButtonStyle = 0x7f03008f;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNegativeButtonStyle = 0x7f030090;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNeutralButtonStyle = 0x7f030091;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarPositiveButtonStyle = 0x7f030092;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarStyle = 0x7f030093;

        /* JADX INFO: Added by JADX */
        public static final int buttonCompat = 0x7f030094;

        /* JADX INFO: Added by JADX */
        public static final int buttonGravity = 0x7f030095;

        /* JADX INFO: Added by JADX */
        public static final int buttonIcon = 0x7f030096;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconDimen = 0x7f030097;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconTint = 0x7f030098;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconTintMode = 0x7f030099;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanelSideLayout = 0x7f03009a;

        /* JADX INFO: Added by JADX */
        public static final int buttonSize = 0x7f03009b;

        /* JADX INFO: Added by JADX */
        public static final int buttonSizeChange = 0x7f03009c;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyle = 0x7f03009d;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyleSmall = 0x7f03009e;

        /* JADX INFO: Added by JADX */
        public static final int buttonTint = 0x7f03009f;

        /* JADX INFO: Added by JADX */
        public static final int buttonTintMode = 0x7f0300a0;

        /* JADX INFO: Added by JADX */
        public static final int cardBackgroundColor = 0x7f0300a1;

        /* JADX INFO: Added by JADX */
        public static final int cardCornerRadius = 0x7f0300a2;

        /* JADX INFO: Added by JADX */
        public static final int cardElevation = 0x7f0300a3;

        /* JADX INFO: Added by JADX */
        public static final int cardForegroundColor = 0x7f0300a4;

        /* JADX INFO: Added by JADX */
        public static final int cardMaxElevation = 0x7f0300a5;

        /* JADX INFO: Added by JADX */
        public static final int cardPreventCornerOverlap = 0x7f0300a6;

        /* JADX INFO: Added by JADX */
        public static final int cardUseCompatPadding = 0x7f0300a7;

        /* JADX INFO: Added by JADX */
        public static final int cardViewStyle = 0x7f0300a8;

        /* JADX INFO: Added by JADX */
        public static final int carousel_alignment = 0x7f0300a9;

        /* JADX INFO: Added by JADX */
        public static final int carousel_backwardTransition = 0x7f0300aa;

        /* JADX INFO: Added by JADX */
        public static final int carousel_emptyViewsBehavior = 0x7f0300ab;

        /* JADX INFO: Added by JADX */
        public static final int carousel_firstView = 0x7f0300ac;

        /* JADX INFO: Added by JADX */
        public static final int carousel_forwardTransition = 0x7f0300ad;

        /* JADX INFO: Added by JADX */
        public static final int carousel_infinite = 0x7f0300ae;

        /* JADX INFO: Added by JADX */
        public static final int carousel_nextState = 0x7f0300af;

        /* JADX INFO: Added by JADX */
        public static final int carousel_previousState = 0x7f0300b0;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUpMode = 0x7f0300b1;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_dampeningFactor = 0x7f0300b2;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_velocityThreshold = 0x7f0300b3;

        /* JADX INFO: Added by JADX */
        public static final int centerIfNoTextEnabled = 0x7f0300b4;

        /* JADX INFO: Added by JADX */
        public static final int centered = 0x7f0300b5;

        /* JADX INFO: Added by JADX */
        public static final int chainUseRtl = 0x7f0300b6;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkCompat = 0x7f0300b7;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTint = 0x7f0300b8;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTintMode = 0x7f0300b9;

        /* JADX INFO: Added by JADX */
        public static final int checkboxStyle = 0x7f0300ba;

        /* JADX INFO: Added by JADX */
        public static final int checkedButton = 0x7f0300bb;

        /* JADX INFO: Added by JADX */
        public static final int checkedChip = 0x7f0300bc;

        /* JADX INFO: Added by JADX */
        public static final int checkedIcon = 0x7f0300bd;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconEnabled = 0x7f0300be;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconGravity = 0x7f0300bf;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconMargin = 0x7f0300c0;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconSize = 0x7f0300c1;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconTint = 0x7f0300c2;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconVisible = 0x7f0300c3;

        /* JADX INFO: Added by JADX */
        public static final int checkedState = 0x7f0300c4;

        /* JADX INFO: Added by JADX */
        public static final int checkedTextViewStyle = 0x7f0300c5;

        /* JADX INFO: Added by JADX */
        public static final int chipBackgroundColor = 0x7f0300c6;

        /* JADX INFO: Added by JADX */
        public static final int chipCornerRadius = 0x7f0300c7;

        /* JADX INFO: Added by JADX */
        public static final int chipEndPadding = 0x7f0300c8;

        /* JADX INFO: Added by JADX */
        public static final int chipGroupStyle = 0x7f0300c9;

        /* JADX INFO: Added by JADX */
        public static final int chipIcon = 0x7f0300ca;

        /* JADX INFO: Added by JADX */
        public static final int chipIconEnabled = 0x7f0300cb;

        /* JADX INFO: Added by JADX */
        public static final int chipIconSize = 0x7f0300cc;

        /* JADX INFO: Added by JADX */
        public static final int chipIconTint = 0x7f0300cd;

        /* JADX INFO: Added by JADX */
        public static final int chipIconVisible = 0x7f0300ce;

        /* JADX INFO: Added by JADX */
        public static final int chipMinHeight = 0x7f0300cf;

        /* JADX INFO: Added by JADX */
        public static final int chipMinTouchTargetSize = 0x7f0300d0;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacing = 0x7f0300d1;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacingHorizontal = 0x7f0300d2;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacingVertical = 0x7f0300d3;

        /* JADX INFO: Added by JADX */
        public static final int chipStandaloneStyle = 0x7f0300d4;

        /* JADX INFO: Added by JADX */
        public static final int chipStartPadding = 0x7f0300d5;

        /* JADX INFO: Added by JADX */
        public static final int chipStrokeColor = 0x7f0300d6;

        /* JADX INFO: Added by JADX */
        public static final int chipStrokeWidth = 0x7f0300d7;

        /* JADX INFO: Added by JADX */
        public static final int chipStyle = 0x7f0300d8;

        /* JADX INFO: Added by JADX */
        public static final int chipSurfaceColor = 0x7f0300d9;

        /* JADX INFO: Added by JADX */
        public static final int circleCrop = 0x7f0300da;

        /* JADX INFO: Added by JADX */
        public static final int circleRadius = 0x7f0300db;

        /* JADX INFO: Added by JADX */
        public static final int circularProgressIndicatorStyle = 0x7f0300dc;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_angles = 0x7f0300dd;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultAngle = 0x7f0300de;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultRadius = 0x7f0300df;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_radiusInDP = 0x7f0300e0;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_viewCenter = 0x7f0300e1;

        /* JADX INFO: Added by JADX */
        public static final int clearsTag = 0x7f0300e2;

        /* JADX INFO: Added by JADX */
        public static final int clickAction = 0x7f0300e3;

        /* JADX INFO: Added by JADX */
        public static final int clockFaceBackgroundColor = 0x7f0300e4;

        /* JADX INFO: Added by JADX */
        public static final int clockHandColor = 0x7f0300e5;

        /* JADX INFO: Added by JADX */
        public static final int clockIcon = 0x7f0300e6;

        /* JADX INFO: Added by JADX */
        public static final int clockNumberTextColor = 0x7f0300e7;

        /* JADX INFO: Added by JADX */
        public static final int closeIcon = 0x7f0300e8;

        /* JADX INFO: Added by JADX */
        public static final int closeIconEnabled = 0x7f0300e9;

        /* JADX INFO: Added by JADX */
        public static final int closeIconEndPadding = 0x7f0300ea;

        /* JADX INFO: Added by JADX */
        public static final int closeIconSize = 0x7f0300eb;

        /* JADX INFO: Added by JADX */
        public static final int closeIconStartPadding = 0x7f0300ec;

        /* JADX INFO: Added by JADX */
        public static final int closeIconTint = 0x7f0300ed;

        /* JADX INFO: Added by JADX */
        public static final int closeIconVisible = 0x7f0300ee;

        /* JADX INFO: Added by JADX */
        public static final int closeItemLayout = 0x7f0300ef;

        /* JADX INFO: Added by JADX */
        public static final int collapseContentDescription = 0x7f0300f0;

        /* JADX INFO: Added by JADX */
        public static final int collapseIcon = 0x7f0300f1;

        /* JADX INFO: Added by JADX */
        public static final int collapsedItemMinHeight = 0x7f0300f2;

        /* JADX INFO: Added by JADX */
        public static final int collapsedSize = 0x7f0300f3;

        /* JADX INFO: Added by JADX */
        public static final int collapsedSubtitleTextAppearance = 0x7f0300f4;

        /* JADX INFO: Added by JADX */
        public static final int collapsedSubtitleTextColor = 0x7f0300f5;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleGravity = 0x7f0300f6;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleGravityMode = 0x7f0300f7;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleTextAppearance = 0x7f0300f8;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleTextColor = 0x7f0300f9;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutLargeSize = 0x7f0300fa;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutLargeStyle = 0x7f0300fb;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutMediumSize = 0x7f0300fc;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutMediumStyle = 0x7f0300fd;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutStyle = 0x7f0300fe;

        /* JADX INFO: Added by JADX */
        public static final int color = 0x7f0300ff;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 0x7f030100;

        /* JADX INFO: Added by JADX */
        public static final int colorBackgroundFloating = 0x7f030101;

        /* JADX INFO: Added by JADX */
        public static final int colorButtonNormal = 0x7f030102;

        /* JADX INFO: Added by JADX */
        public static final int colorContainer = 0x7f030103;

        /* JADX INFO: Added by JADX */
        public static final int colorContainerChecked = 0x7f030104;

        /* JADX INFO: Added by JADX */
        public static final int colorContainerUnchecked = 0x7f030105;

        /* JADX INFO: Added by JADX */
        public static final int colorControlActivated = 0x7f030106;

        /* JADX INFO: Added by JADX */
        public static final int colorControlHighlight = 0x7f030107;

        /* JADX INFO: Added by JADX */
        public static final int colorControlNormal = 0x7f030108;

        /* JADX INFO: Added by JADX */
        public static final int colorError = 0x7f030109;

        /* JADX INFO: Added by JADX */
        public static final int colorErrorContainer = 0x7f03010a;

        /* JADX INFO: Added by JADX */
        public static final int colorOnBackground = 0x7f03010b;

        /* JADX INFO: Added by JADX */
        public static final int colorOnContainer = 0x7f03010c;

        /* JADX INFO: Added by JADX */
        public static final int colorOnContainerChecked = 0x7f03010d;

        /* JADX INFO: Added by JADX */
        public static final int colorOnContainerUnchecked = 0x7f03010e;

        /* JADX INFO: Added by JADX */
        public static final int colorOnError = 0x7f03010f;

        /* JADX INFO: Added by JADX */
        public static final int colorOnErrorContainer = 0x7f030110;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimary = 0x7f030111;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryContainer = 0x7f030112;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryFixed = 0x7f030113;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryFixedVariant = 0x7f030114;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimarySurface = 0x7f030115;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondary = 0x7f030116;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryContainer = 0x7f030117;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryFixed = 0x7f030118;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryFixedVariant = 0x7f030119;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurface = 0x7f03011a;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurfaceInverse = 0x7f03011b;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurfaceVariant = 0x7f03011c;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiary = 0x7f03011d;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryContainer = 0x7f03011e;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryFixed = 0x7f03011f;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryFixedVariant = 0x7f030120;

        /* JADX INFO: Added by JADX */
        public static final int colorOutline = 0x7f030121;

        /* JADX INFO: Added by JADX */
        public static final int colorOutlineVariant = 0x7f030122;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 0x7f030123;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryContainer = 0x7f030124;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 0x7f030125;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryFixed = 0x7f030126;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryFixedDim = 0x7f030127;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryInverse = 0x7f030128;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimarySurface = 0x7f030129;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryVariant = 0x7f03012a;

        /* JADX INFO: Added by JADX */
        public static final int colorScheme = 0x7f03012b;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondary = 0x7f03012c;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryContainer = 0x7f03012d;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryFixed = 0x7f03012e;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryFixedDim = 0x7f03012f;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryVariant = 0x7f030130;

        /* JADX INFO: Added by JADX */
        public static final int colorSurface = 0x7f030131;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceBright = 0x7f030132;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainer = 0x7f030133;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerHigh = 0x7f030134;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerHighest = 0x7f030135;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerLow = 0x7f030136;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerLowest = 0x7f030137;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceDim = 0x7f030138;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceInverse = 0x7f030139;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceVariant = 0x7f03013a;

        /* JADX INFO: Added by JADX */
        public static final int colorSwitchThumbNormal = 0x7f03013b;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiary = 0x7f03013c;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryContainer = 0x7f03013d;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryFixed = 0x7f03013e;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryFixedDim = 0x7f03013f;

        /* JADX INFO: Added by JADX */
        public static final int commitIcon = 0x7f030140;

        /* JADX INFO: Added by JADX */
        public static final int compatShadowEnabled = 0x7f030141;

        /* JADX INFO: Added by JADX */
        public static final int constraintRotate = 0x7f030142;

        /* JADX INFO: Added by JADX */
        public static final int constraintSet = 0x7f030143;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetEnd = 0x7f030144;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetStart = 0x7f030145;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_ids = 0x7f030146;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_tags = 0x7f030147;

        /* JADX INFO: Added by JADX */
        public static final int constraints = 0x7f030148;

        /* JADX INFO: Added by JADX */
        public static final int containedAnimationEnabled = 0x7f030149;

        /* JADX INFO: Added by JADX */
        public static final int containerColor = 0x7f03014a;

        /* JADX INFO: Added by JADX */
        public static final int containerHeight = 0x7f03014b;

        /* JADX INFO: Added by JADX */
        public static final int containerIconPadding = 0x7f03014c;

        /* JADX INFO: Added by JADX */
        public static final int containerIconSize = 0x7f03014d;

        /* JADX INFO: Added by JADX */
        public static final int containerInsetBottom = 0x7f03014e;

        /* JADX INFO: Added by JADX */
        public static final int containerInsetLeft = 0x7f03014f;

        /* JADX INFO: Added by JADX */
        public static final int containerInsetRight = 0x7f030150;

        /* JADX INFO: Added by JADX */
        public static final int containerInsetTop = 0x7f030151;

        /* JADX INFO: Added by JADX */
        public static final int containerPaddingBottom = 0x7f030152;

        /* JADX INFO: Added by JADX */
        public static final int containerPaddingEnd = 0x7f030153;

        /* JADX INFO: Added by JADX */
        public static final int containerPaddingStart = 0x7f030154;

        /* JADX INFO: Added by JADX */
        public static final int containerPaddingTop = 0x7f030155;

        /* JADX INFO: Added by JADX */
        public static final int containerShapeChecked = 0x7f030156;

        /* JADX INFO: Added by JADX */
        public static final int containerShapeDefault = 0x7f030157;

        /* JADX INFO: Added by JADX */
        public static final int containerShapePressed = 0x7f030158;

        /* JADX INFO: Added by JADX */
        public static final int containerStrokeWidth = 0x7f030159;

        /* JADX INFO: Added by JADX */
        public static final int containerWidth = 0x7f03015a;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f03015b;

        /* JADX INFO: Added by JADX */
        public static final int contentDescription = 0x7f03015c;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEnd = 0x7f03015d;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEndWithActions = 0x7f03015e;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetLeft = 0x7f03015f;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetRight = 0x7f030160;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStart = 0x7f030161;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStartWithNavigation = 0x7f030162;

        /* JADX INFO: Added by JADX */
        public static final int contentMarginTop = 0x7f030163;

        /* JADX INFO: Added by JADX */
        public static final int contentPadding = 0x7f030164;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingBottom = 0x7f030165;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingEnd = 0x7f030166;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingLeft = 0x7f030167;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingRight = 0x7f030168;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingStart = 0x7f030169;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingTop = 0x7f03016a;

        /* JADX INFO: Added by JADX */
        public static final int contentScrim = 0x7f03016b;

        /* JADX INFO: Added by JADX */
        public static final int continuousModeTickCount = 0x7f03016c;

        /* JADX INFO: Added by JADX */
        public static final int contrast = 0x7f03016d;

        /* JADX INFO: Added by JADX */
        public static final int controlBackground = 0x7f03016e;

        /* JADX INFO: Added by JADX */
        public static final int coordinatorLayoutStyle = 0x7f03016f;

        /* JADX INFO: Added by JADX */
        public static final int coplanarSiblingViewId = 0x7f030170;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamily = 0x7f030171;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyBottomLeft = 0x7f030172;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyBottomRight = 0x7f030173;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyTopLeft = 0x7f030174;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyTopRight = 0x7f030175;

        /* JADX INFO: Added by JADX */
        public static final int cornerRadius = 0x7f030176;

        /* JADX INFO: Added by JADX */
        public static final int cornerSize = 0x7f030177;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeBottomLeft = 0x7f030178;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeBottomRight = 0x7f030179;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeTopLeft = 0x7f03017a;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeTopRight = 0x7f03017b;

        /* JADX INFO: Added by JADX */
        public static final int counterEnabled = 0x7f03017c;

        /* JADX INFO: Added by JADX */
        public static final int counterMaxLength = 0x7f03017d;

        /* JADX INFO: Added by JADX */
        public static final int counterOverflowTextAppearance = 0x7f03017e;

        /* JADX INFO: Added by JADX */
        public static final int counterOverflowTextColor = 0x7f03017f;

        /* JADX INFO: Added by JADX */
        public static final int counterTextAppearance = 0x7f030180;

        /* JADX INFO: Added by JADX */
        public static final int counterTextColor = 0x7f030181;

        /* JADX INFO: Added by JADX */
        public static final int crossfade = 0x7f030182;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f030183;

        /* JADX INFO: Added by JADX */
        public static final int cursorColor = 0x7f030184;

        /* JADX INFO: Added by JADX */
        public static final int cursorErrorColor = 0x7f030185;

        /* JADX INFO: Added by JADX */
        public static final int curveFit = 0x7f030186;

        /* JADX INFO: Added by JADX */
        public static final int customBoolean = 0x7f030187;

        /* JADX INFO: Added by JADX */
        public static final int customColorDrawableValue = 0x7f030188;

        /* JADX INFO: Added by JADX */
        public static final int customColorValue = 0x7f030189;

        /* JADX INFO: Added by JADX */
        public static final int customDimension = 0x7f03018a;

        /* JADX INFO: Added by JADX */
        public static final int customFloatValue = 0x7f03018b;

        /* JADX INFO: Added by JADX */
        public static final int customIntegerValue = 0x7f03018c;

        /* JADX INFO: Added by JADX */
        public static final int customNavigationLayout = 0x7f03018d;

        /* JADX INFO: Added by JADX */
        public static final int customPixelDimension = 0x7f03018e;

        /* JADX INFO: Added by JADX */
        public static final int customReference = 0x7f03018f;

        /* JADX INFO: Added by JADX */
        public static final int customStringValue = 0x7f030190;

        /* JADX INFO: Added by JADX */
        public static final int damping = 0x7f030191;

        /* JADX INFO: Added by JADX */
        public static final int dayInvalidStyle = 0x7f030192;

        /* JADX INFO: Added by JADX */
        public static final int daySelectedStyle = 0x7f030193;

        /* JADX INFO: Added by JADX */
        public static final int dayStyle = 0x7f030194;

        /* JADX INFO: Added by JADX */
        public static final int dayTodayStyle = 0x7f030195;

        /* JADX INFO: Added by JADX */
        public static final int defaultDuration = 0x7f030196;

        /* JADX INFO: Added by JADX */
        public static final int defaultMarginsEnabled = 0x7f030197;

        /* JADX INFO: Added by JADX */
        public static final int defaultQueryHint = 0x7f030198;

        /* JADX INFO: Added by JADX */
        public static final int defaultScrollFlagsEnabled = 0x7f030199;

        /* JADX INFO: Added by JADX */
        public static final int defaultState = 0x7f03019a;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarAngle = 0x7f03019b;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarRadius = 0x7f03019c;

        /* JADX INFO: Added by JADX */
        public static final int deriveConstraintsFrom = 0x7f03019d;

        /* JADX INFO: Added by JADX */
        public static final int dialogCornerRadius = 0x7f03019e;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferredPadding = 0x7f03019f;

        /* JADX INFO: Added by JADX */
        public static final int dialogTheme = 0x7f0301a0;

        /* JADX INFO: Added by JADX */
        public static final int displayOptions = 0x7f0301a1;

        /* JADX INFO: Added by JADX */
        public static final int divider = 0x7f0301a2;

        /* JADX INFO: Added by JADX */
        public static final int dividerColor = 0x7f0301a3;

        /* JADX INFO: Added by JADX */
        public static final int dividerHorizontal = 0x7f0301a4;

        /* JADX INFO: Added by JADX */
        public static final int dividerInsetEnd = 0x7f0301a5;

        /* JADX INFO: Added by JADX */
        public static final int dividerInsetStart = 0x7f0301a6;

        /* JADX INFO: Added by JADX */
        public static final int dividerPadding = 0x7f0301a7;

        /* JADX INFO: Added by JADX */
        public static final int dividerThickness = 0x7f0301a8;

        /* JADX INFO: Added by JADX */
        public static final int dividerVertical = 0x7f0301a9;

        /* JADX INFO: Added by JADX */
        public static final int dividerVisible = 0x7f0301aa;

        /* JADX INFO: Added by JADX */
        public static final int dockedToolbarStyle = 0x7f0301ab;

        /* JADX INFO: Added by JADX */
        public static final int dockedToolbarVibrantStyle = 0x7f0301ac;

        /* JADX INFO: Added by JADX */
        public static final int dragDirection = 0x7f0301ad;

        /* JADX INFO: Added by JADX */
        public static final int dragScale = 0x7f0301ae;

        /* JADX INFO: Added by JADX */
        public static final int dragThreshold = 0x7f0301af;

        /* JADX INFO: Added by JADX */
        public static final int drawPath = 0x7f0301b0;

        /* JADX INFO: Added by JADX */
        public static final int drawableBottomCompat = 0x7f0301b1;

        /* JADX INFO: Added by JADX */
        public static final int drawableEndCompat = 0x7f0301b2;

        /* JADX INFO: Added by JADX */
        public static final int drawableLeftCompat = 0x7f0301b3;

        /* JADX INFO: Added by JADX */
        public static final int drawableRightCompat = 0x7f0301b4;

        /* JADX INFO: Added by JADX */
        public static final int drawableSize = 0x7f0301b5;

        /* JADX INFO: Added by JADX */
        public static final int drawableStartCompat = 0x7f0301b6;

        /* JADX INFO: Added by JADX */
        public static final int drawableTint = 0x7f0301b7;

        /* JADX INFO: Added by JADX */
        public static final int drawableTintMode = 0x7f0301b8;

        /* JADX INFO: Added by JADX */
        public static final int drawableTopCompat = 0x7f0301b9;

        /* JADX INFO: Added by JADX */
        public static final int drawerArrowStyle = 0x7f0301ba;

        /* JADX INFO: Added by JADX */
        public static final int drawerLayoutCornerSize = 0x7f0301bb;

        /* JADX INFO: Added by JADX */
        public static final int drawerLayoutStyle = 0x7f0301bc;

        /* JADX INFO: Added by JADX */
        public static final int dropDownBackgroundTint = 0x7f0301bd;

        /* JADX INFO: Added by JADX */
        public static final int dropDownListViewStyle = 0x7f0301be;

        /* JADX INFO: Added by JADX */
        public static final int dropdownListPreferredItemHeight = 0x7f0301bf;

        /* JADX INFO: Added by JADX */
        public static final int duration = 0x7f0301c0;

        /* JADX INFO: Added by JADX */
        public static final int dynamicColorThemeOverlay = 0x7f0301c1;

        /* JADX INFO: Added by JADX */
        public static final int editTextBackground = 0x7f0301c2;

        /* JADX INFO: Added by JADX */
        public static final int editTextColor = 0x7f0301c3;

        /* JADX INFO: Added by JADX */
        public static final int editTextStyle = 0x7f0301c4;

        /* JADX INFO: Added by JADX */
        public static final int elevation = 0x7f0301c5;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayAccentColor = 0x7f0301c6;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayColor = 0x7f0301c7;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayEnabled = 0x7f0301c8;

        /* JADX INFO: Added by JADX */
        public static final int emojiCompatEnabled = 0x7f0301c9;

        /* JADX INFO: Added by JADX */
        public static final int enableEdgeToEdge = 0x7f0301ca;

        /* JADX INFO: Added by JADX */
        public static final int endIconCheckable = 0x7f0301cb;

        /* JADX INFO: Added by JADX */
        public static final int endIconContentDescription = 0x7f0301cc;

        /* JADX INFO: Added by JADX */
        public static final int endIconDrawable = 0x7f0301cd;

        /* JADX INFO: Added by JADX */
        public static final int endIconMinSize = 0x7f0301ce;

        /* JADX INFO: Added by JADX */
        public static final int endIconMode = 0x7f0301cf;

        /* JADX INFO: Added by JADX */
        public static final int endIconScaleType = 0x7f0301d0;

        /* JADX INFO: Added by JADX */
        public static final int endIconTint = 0x7f0301d1;

        /* JADX INFO: Added by JADX */
        public static final int endIconTintMode = 0x7f0301d2;

        /* JADX INFO: Added by JADX */
        public static final int endInsetScrimEnabled = 0x7f0301d3;

        /* JADX INFO: Added by JADX */
        public static final int endSiblingViewId = 0x7f0301d4;

        /* JADX INFO: Added by JADX */
        public static final int enforceMaterialTheme = 0x7f0301d5;

        /* JADX INFO: Added by JADX */
        public static final int enforceTextAppearance = 0x7f0301d6;

        /* JADX INFO: Added by JADX */
        public static final int ensureMinTouchTargetSize = 0x7f0301d7;

        /* JADX INFO: Added by JADX */
        public static final int errorAccessibilityLabel = 0x7f0301d8;

        /* JADX INFO: Added by JADX */
        public static final int errorAccessibilityLiveRegion = 0x7f0301d9;

        /* JADX INFO: Added by JADX */
        public static final int errorContentDescription = 0x7f0301da;

        /* JADX INFO: Added by JADX */
        public static final int errorEnabled = 0x7f0301db;

        /* JADX INFO: Added by JADX */
        public static final int errorIconDrawable = 0x7f0301dc;

        /* JADX INFO: Added by JADX */
        public static final int errorIconTint = 0x7f0301dd;

        /* JADX INFO: Added by JADX */
        public static final int errorIconTintMode = 0x7f0301de;

        /* JADX INFO: Added by JADX */
        public static final int errorShown = 0x7f0301df;

        /* JADX INFO: Added by JADX */
        public static final int errorTextAppearance = 0x7f0301e0;

        /* JADX INFO: Added by JADX */
        public static final int errorTextColor = 0x7f0301e1;

        /* JADX INFO: Added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 0x7f0301e2;

        /* JADX INFO: Added by JADX */
        public static final int expanded = 0x7f0301e3;

        /* JADX INFO: Added by JADX */
        public static final int expandedActiveIndicatorPaddingBottom = 0x7f0301e4;

        /* JADX INFO: Added by JADX */
        public static final int expandedActiveIndicatorPaddingEnd = 0x7f0301e5;

        /* JADX INFO: Added by JADX */
        public static final int expandedActiveIndicatorPaddingStart = 0x7f0301e6;

        /* JADX INFO: Added by JADX */
        public static final int expandedActiveIndicatorPaddingTop = 0x7f0301e7;

        /* JADX INFO: Added by JADX */
        public static final int expandedHeight = 0x7f0301e8;

        /* JADX INFO: Added by JADX */
        public static final int expandedHintEnabled = 0x7f0301e9;

        /* JADX INFO: Added by JADX */
        public static final int expandedItemMinHeight = 0x7f0301ea;

        /* JADX INFO: Added by JADX */
        public static final int expandedMarginHorizontal = 0x7f0301eb;

        /* JADX INFO: Added by JADX */
        public static final int expandedMaxWidth = 0x7f0301ec;

        /* JADX INFO: Added by JADX */
        public static final int expandedMinWidth = 0x7f0301ed;

        /* JADX INFO: Added by JADX */
        public static final int expandedSubtitleTextAppearance = 0x7f0301ee;

        /* JADX INFO: Added by JADX */
        public static final int expandedSubtitleTextColor = 0x7f0301ef;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleGravity = 0x7f0301f0;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMargin = 0x7f0301f1;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginBottom = 0x7f0301f2;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginEnd = 0x7f0301f3;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginStart = 0x7f0301f4;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginTop = 0x7f0301f5;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleSpacing = 0x7f0301f6;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleTextAppearance = 0x7f0301f7;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleTextColor = 0x7f0301f8;

        /* JADX INFO: Added by JADX */
        public static final int expandedWidth = 0x7f0301f9;

        /* JADX INFO: Added by JADX */
        public static final int extendMotionSpec = 0x7f0301fa;

        /* JADX INFO: Added by JADX */
        public static final int extendStrategy = 0x7f0301fb;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonLargeStyle = 0x7f0301fc;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonMediumStyle = 0x7f0301fd;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonPrimaryStyle = 0x7f0301fe;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonSecondaryStyle = 0x7f0301ff;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonSmallStyle = 0x7f030200;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonStyle = 0x7f030201;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonSurfaceStyle = 0x7f030202;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonTertiaryStyle = 0x7f030203;

        /* JADX INFO: Added by JADX */
        public static final int extraMultilineHeightEnabled = 0x7f030204;

        /* JADX INFO: Added by JADX */
        public static final int fabAlignmentMode = 0x7f030205;

        /* JADX INFO: Added by JADX */
        public static final int fabAlignmentModeEndMargin = 0x7f030206;

        /* JADX INFO: Added by JADX */
        public static final int fabAnchorMode = 0x7f030207;

        /* JADX INFO: Added by JADX */
        public static final int fabAnimationMode = 0x7f030208;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleMargin = 0x7f030209;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleRoundedCornerRadius = 0x7f03020a;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleVerticalOffset = 0x7f03020b;

        /* JADX INFO: Added by JADX */
        public static final int fabCustomSize = 0x7f03020c;

        /* JADX INFO: Added by JADX */
        public static final int fabSize = 0x7f03020d;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollEnabled = 0x7f03020e;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalThumbDrawable = 0x7f03020f;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalTrackDrawable = 0x7f030210;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalThumbDrawable = 0x7f030211;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalTrackDrawable = 0x7f030212;

        /* JADX INFO: Added by JADX */
        public static final int firstBaselineToTopHeight = 0x7f030213;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargePrimaryStyle = 0x7f030214;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeSecondaryStyle = 0x7f030215;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeStyle = 0x7f030216;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeSurfaceStyle = 0x7f030217;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeTertiaryStyle = 0x7f030218;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonMediumStyle = 0x7f030219;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonPrimaryStyle = 0x7f03021a;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSecondaryStyle = 0x7f03021b;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallPrimaryStyle = 0x7f03021c;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallSecondaryStyle = 0x7f03021d;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallStyle = 0x7f03021e;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallSurfaceStyle = 0x7f03021f;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallTertiaryStyle = 0x7f030220;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonStyle = 0x7f030221;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSurfaceStyle = 0x7f030222;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonTertiaryStyle = 0x7f030223;

        /* JADX INFO: Added by JADX */
        public static final int floatingToolbarStyle = 0x7f030224;

        /* JADX INFO: Added by JADX */
        public static final int floatingToolbarVibrantStyle = 0x7f030225;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalBias = 0x7f030226;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalStyle = 0x7f030227;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalBias = 0x7f030228;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalStyle = 0x7f030229;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalAlign = 0x7f03022a;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalBias = 0x7f03022b;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalGap = 0x7f03022c;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalStyle = 0x7f03022d;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalBias = 0x7f03022e;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalStyle = 0x7f03022f;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalBias = 0x7f030230;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalStyle = 0x7f030231;

        /* JADX INFO: Added by JADX */
        public static final int flow_maxElementsWrap = 0x7f030232;

        /* JADX INFO: Added by JADX */
        public static final int flow_padding = 0x7f030233;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalAlign = 0x7f030234;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalBias = 0x7f030235;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalGap = 0x7f030236;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalStyle = 0x7f030237;

        /* JADX INFO: Added by JADX */
        public static final int flow_wrapMode = 0x7f030238;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsEnabled = 0x7f030239;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsInnerStrokeColor = 0x7f03023a;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsInnerStrokeInset = 0x7f03023b;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsInnerStrokeWidth = 0x7f03023c;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsInset = 0x7f03023d;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsOuterStrokeColor = 0x7f03023e;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsOuterStrokeWidth = 0x7f03023f;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsRadius = 0x7f030240;

        /* JADX INFO: Added by JADX */
        public static final int focusRingsShapeAppearance = 0x7f030241;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f030242;

        /* JADX INFO: Added by JADX */
        public static final int fontFamily = 0x7f030243;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f030244;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f030245;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f030246;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f030247;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f030248;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f030249;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f03024a;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f03024b;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f03024c;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f03024d;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f03024e;

        /* JADX INFO: Added by JADX */
        public static final int forceApplySystemWindowInsetTop = 0x7f03024f;

        /* JADX INFO: Added by JADX */
        public static final int forceDefaultNavigationOnClickListener = 0x7f030250;

        /* JADX INFO: Added by JADX */
        public static final int foregroundInsidePadding = 0x7f030251;

        /* JADX INFO: Added by JADX */
        public static final int framePosition = 0x7f030252;

        /* JADX INFO: Added by JADX */
        public static final int gapBetweenBars = 0x7f030253;

        /* JADX INFO: Added by JADX */
        public static final int gestureInsetBottomIgnored = 0x7f030254;

        /* JADX INFO: Added by JADX */
        public static final int goIcon = 0x7f030255;

        /* JADX INFO: Added by JADX */
        public static final int grid_columnWeights = 0x7f030256;

        /* JADX INFO: Added by JADX */
        public static final int grid_columns = 0x7f030257;

        /* JADX INFO: Added by JADX */
        public static final int grid_horizontalGaps = 0x7f030258;

        /* JADX INFO: Added by JADX */
        public static final int grid_orientation = 0x7f030259;

        /* JADX INFO: Added by JADX */
        public static final int grid_rowWeights = 0x7f03025a;

        /* JADX INFO: Added by JADX */
        public static final int grid_rows = 0x7f03025b;

        /* JADX INFO: Added by JADX */
        public static final int grid_skips = 0x7f03025c;

        /* JADX INFO: Added by JADX */
        public static final int grid_spans = 0x7f03025d;

        /* JADX INFO: Added by JADX */
        public static final int grid_useRtl = 0x7f03025e;

        /* JADX INFO: Added by JADX */
        public static final int grid_validateInputs = 0x7f03025f;

        /* JADX INFO: Added by JADX */
        public static final int grid_verticalGaps = 0x7f030260;

        /* JADX INFO: Added by JADX */
        public static final int guidelineUseRtl = 0x7f030261;

        /* JADX INFO: Added by JADX */
        public static final int haloColor = 0x7f030262;

        /* JADX INFO: Added by JADX */
        public static final int haloRadius = 0x7f030263;

        /* JADX INFO: Added by JADX */
        public static final int headerLayout = 0x7f030264;

        /* JADX INFO: Added by JADX */
        public static final int headerMarginBottom = 0x7f030265;

        /* JADX INFO: Added by JADX */
        public static final int height = 0x7f030266;

        /* JADX INFO: Added by JADX */
        public static final int helperText = 0x7f030267;

        /* JADX INFO: Added by JADX */
        public static final int helperTextEnabled = 0x7f030268;

        /* JADX INFO: Added by JADX */
        public static final int helperTextTextAppearance = 0x7f030269;

        /* JADX INFO: Added by JADX */
        public static final int helperTextTextColor = 0x7f03026a;

        /* JADX INFO: Added by JADX */
        public static final int hideAnimationBehavior = 0x7f03026b;

        /* JADX INFO: Added by JADX */
        public static final int hideMotionSpec = 0x7f03026c;

        /* JADX INFO: Added by JADX */
        public static final int hideNavigationIcon = 0x7f03026d;

        /* JADX INFO: Added by JADX */
        public static final int hideOnContentScroll = 0x7f03026e;

        /* JADX INFO: Added by JADX */
        public static final int hideOnScroll = 0x7f03026f;

        /* JADX INFO: Added by JADX */
        public static final int hintAnimationEnabled = 0x7f030270;

        /* JADX INFO: Added by JADX */
        public static final int hintEnabled = 0x7f030271;

        /* JADX INFO: Added by JADX */
        public static final int hintMaxLines = 0x7f030272;

        /* JADX INFO: Added by JADX */
        public static final int hintTextAppearance = 0x7f030273;

        /* JADX INFO: Added by JADX */
        public static final int hintTextColor = 0x7f030274;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUpIndicator = 0x7f030275;

        /* JADX INFO: Added by JADX */
        public static final int homeLayout = 0x7f030276;

        /* JADX INFO: Added by JADX */
        public static final int horizontalItemSpacing = 0x7f030277;

        /* JADX INFO: Added by JADX */
        public static final int horizontalItemTextAppearanceActive = 0x7f030278;

        /* JADX INFO: Added by JADX */
        public static final int horizontalItemTextAppearanceInactive = 0x7f030279;

        /* JADX INFO: Added by JADX */
        public static final int horizontalOffset = 0x7f03027a;

        /* JADX INFO: Added by JADX */
        public static final int horizontalOffsetWithText = 0x7f03027b;

        /* JADX INFO: Added by JADX */
        public static final int hoveredFocusedTranslationZ = 0x7f03027c;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f03027d;

        /* JADX INFO: Added by JADX */
        public static final int iconEndPadding = 0x7f03027e;

        /* JADX INFO: Added by JADX */
        public static final int iconGravity = 0x7f03027f;

        /* JADX INFO: Added by JADX */
        public static final int iconLabelHorizontalSpacing = 0x7f030280;

        /* JADX INFO: Added by JADX */
        public static final int iconPadding = 0x7f030281;

        /* JADX INFO: Added by JADX */
        public static final int iconSize = 0x7f030282;

        /* JADX INFO: Added by JADX */
        public static final int iconStartPadding = 0x7f030283;

        /* JADX INFO: Added by JADX */
        public static final int iconTint = 0x7f030284;

        /* JADX INFO: Added by JADX */
        public static final int iconTintMode = 0x7f030285;

        /* JADX INFO: Added by JADX */
        public static final int iconifiedByDefault = 0x7f030286;

        /* JADX INFO: Added by JADX */
        public static final int ifTagNotSet = 0x7f030287;

        /* JADX INFO: Added by JADX */
        public static final int ifTagSet = 0x7f030288;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatio = 0x7f030289;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatioAdjust = 0x7f03028a;

        /* JADX INFO: Added by JADX */
        public static final int imageButtonStyle = 0x7f03028b;

        /* JADX INFO: Added by JADX */
        public static final int imagePanX = 0x7f03028c;

        /* JADX INFO: Added by JADX */
        public static final int imagePanY = 0x7f03028d;

        /* JADX INFO: Added by JADX */
        public static final int imageRotate = 0x7f03028e;

        /* JADX INFO: Added by JADX */
        public static final int imageZoom = 0x7f03028f;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateAnimationType = 0x7f030290;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateAnimationTypeCircular = 0x7f030291;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateAnimatorDurationScale = 0x7f030292;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateProgressStyle = 0x7f030293;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateTrackVisible = 0x7f030294;

        /* JADX INFO: Added by JADX */
        public static final int indicatorColor = 0x7f030295;

        /* JADX INFO: Added by JADX */
        public static final int indicatorDirectionCircular = 0x7f030296;

        /* JADX INFO: Added by JADX */
        public static final int indicatorDirectionLinear = 0x7f030297;

        /* JADX INFO: Added by JADX */
        public static final int indicatorInset = 0x7f030298;

        /* JADX INFO: Added by JADX */
        public static final int indicatorSize = 0x7f030299;

        /* JADX INFO: Added by JADX */
        public static final int indicatorTrackGapSize = 0x7f03029a;

        /* JADX INFO: Added by JADX */
        public static final int initialActivityCount = 0x7f03029b;

        /* JADX INFO: Added by JADX */
        public static final int innerCornerSize = 0x7f03029c;

        /* JADX INFO: Added by JADX */
        public static final int insetForeground = 0x7f03029d;

        /* JADX INFO: Added by JADX */
        public static final int isLightTheme = 0x7f03029e;

        /* JADX INFO: Added by JADX */
        public static final int isMaterial3DynamicColorApplied = 0x7f03029f;

        /* JADX INFO: Added by JADX */
        public static final int isMaterial3Theme = 0x7f0302a0;

        /* JADX INFO: Added by JADX */
        public static final int isMaterialTheme = 0x7f0302a1;

        /* JADX INFO: Added by JADX */
        public static final int itemActiveIndicatorStyle = 0x7f0302a2;

        /* JADX INFO: Added by JADX */
        public static final int itemBackground = 0x7f0302a3;

        /* JADX INFO: Added by JADX */
        public static final int itemFillColor = 0x7f0302a4;

        /* JADX INFO: Added by JADX */
        public static final int itemGravity = 0x7f0302a5;

        /* JADX INFO: Added by JADX */
        public static final int itemHorizontalPadding = 0x7f0302a6;

        /* JADX INFO: Added by JADX */
        public static final int itemHorizontalTranslationEnabled = 0x7f0302a7;

        /* JADX INFO: Added by JADX */
        public static final int itemIconGravity = 0x7f0302a8;

        /* JADX INFO: Added by JADX */
        public static final int itemIconPadding = 0x7f0302a9;

        /* JADX INFO: Added by JADX */
        public static final int itemIconSize = 0x7f0302aa;

        /* JADX INFO: Added by JADX */
        public static final int itemIconTint = 0x7f0302ab;

        /* JADX INFO: Added by JADX */
        public static final int itemMaxLines = 0x7f0302ac;

        /* JADX INFO: Added by JADX */
        public static final int itemMinHeight = 0x7f0302ad;

        /* JADX INFO: Added by JADX */
        public static final int itemPadding = 0x7f0302ae;

        /* JADX INFO: Added by JADX */
        public static final int itemPaddingBottom = 0x7f0302af;

        /* JADX INFO: Added by JADX */
        public static final int itemPaddingTop = 0x7f0302b0;

        /* JADX INFO: Added by JADX */
        public static final int itemRippleColor = 0x7f0302b1;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeAppearance = 0x7f0302b2;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeAppearanceOverlay = 0x7f0302b3;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeFillColor = 0x7f0302b4;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetBottom = 0x7f0302b5;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetEnd = 0x7f0302b6;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetStart = 0x7f0302b7;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetTop = 0x7f0302b8;

        /* JADX INFO: Added by JADX */
        public static final int itemSpacing = 0x7f0302b9;

        /* JADX INFO: Added by JADX */
        public static final int itemStrokeColor = 0x7f0302ba;

        /* JADX INFO: Added by JADX */
        public static final int itemStrokeWidth = 0x7f0302bb;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearance = 0x7f0302bc;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceActive = 0x7f0302bd;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceActiveBoldEnabled = 0x7f0302be;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceInactive = 0x7f0302bf;

        /* JADX INFO: Added by JADX */
        public static final int itemTextColor = 0x7f0302c0;

        /* JADX INFO: Added by JADX */
        public static final int itemVerticalPadding = 0x7f0302c1;

        /* JADX INFO: Added by JADX */
        public static final int keyPositionType = 0x7f0302c2;

        /* JADX INFO: Added by JADX */
        public static final int keyboardIcon = 0x7f0302c3;

        /* JADX INFO: Added by JADX */
        public static final int keylines = 0x7f0302c4;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f0302c5;

        /* JADX INFO: Added by JADX */
        public static final int labelBehavior = 0x7f0302c6;

        /* JADX INFO: Added by JADX */
        public static final int labelFontScalingEnabled = 0x7f0302c7;

        /* JADX INFO: Added by JADX */
        public static final int labelMaxLines = 0x7f0302c8;

        /* JADX INFO: Added by JADX */
        public static final int labelStyle = 0x7f0302c9;

        /* JADX INFO: Added by JADX */
        public static final int labelTextAppearance = 0x7f0302ca;

        /* JADX INFO: Added by JADX */
        public static final int labelVisibilityMode = 0x7f0302cb;

        /* JADX INFO: Added by JADX */
        public static final int largeFontVerticalOffsetAdjustment = 0x7f0302cc;

        /* JADX INFO: Added by JADX */
        public static final int lastBaselineToBottomHeight = 0x7f0302cd;

        /* JADX INFO: Added by JADX */
        public static final int lastItemDecorated = 0x7f0302ce;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f0302cf;

        /* JADX INFO: Added by JADX */
        public static final int layoutDescription = 0x7f0302d0;

        /* JADX INFO: Added by JADX */
        public static final int layoutDuringTransition = 0x7f0302d1;

        /* JADX INFO: Added by JADX */
        public static final int layoutManager = 0x7f0302d2;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchor = 0x7f0302d3;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchorGravity = 0x7f0302d4;

        /* JADX INFO: Added by JADX */
        public static final int layout_behavior = 0x7f0302d5;

        /* JADX INFO: Added by JADX */
        public static final int layout_collapseMode = 0x7f0302d6;

        /* JADX INFO: Added by JADX */
        public static final int layout_collapseParallaxMultiplier = 0x7f0302d7;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedHeight = 0x7f0302d8;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedWidth = 0x7f0302d9;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_creator = 0x7f0302da;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBaselineOf = 0x7f0302db;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBottomOf = 0x7f0302dc;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toTopOf = 0x7f0302dd;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_creator = 0x7f0302de;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toBottomOf = 0x7f0302df;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toTopOf = 0x7f0302e0;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircle = 0x7f0302e1;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleAngle = 0x7f0302e2;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleRadius = 0x7f0302e3;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintDimensionRatio = 0x7f0302e4;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toEndOf = 0x7f0302e5;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toStartOf = 0x7f0302e6;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_begin = 0x7f0302e7;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_end = 0x7f0302e8;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_percent = 0x7f0302e9;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight = 0x7f0302ea;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_default = 0x7f0302eb;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_max = 0x7f0302ec;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_min = 0x7f0302ed;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_percent = 0x7f0302ee;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_bias = 0x7f0302ef;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_chainStyle = 0x7f0302f0;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_weight = 0x7f0302f1;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_creator = 0x7f0302f2;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toLeftOf = 0x7f0302f3;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toRightOf = 0x7f0302f4;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_creator = 0x7f0302f5;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toLeftOf = 0x7f0302f6;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toRightOf = 0x7f0302f7;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toEndOf = 0x7f0302f8;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toStartOf = 0x7f0302f9;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTag = 0x7f0302fa;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_creator = 0x7f0302fb;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toBottomOf = 0x7f0302fc;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toTopOf = 0x7f0302fd;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_bias = 0x7f0302fe;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_chainStyle = 0x7f0302ff;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_weight = 0x7f030300;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth = 0x7f030301;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_default = 0x7f030302;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_max = 0x7f030303;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_min = 0x7f030304;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_percent = 0x7f030305;

        /* JADX INFO: Added by JADX */
        public static final int layout_dodgeInsetEdges = 0x7f030306;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteX = 0x7f030307;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteY = 0x7f030308;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBaseline = 0x7f030309;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBottom = 0x7f03030a;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginEnd = 0x7f03030b;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginLeft = 0x7f03030c;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginRight = 0x7f03030d;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginStart = 0x7f03030e;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginTop = 0x7f03030f;

        /* JADX INFO: Added by JADX */
        public static final int layout_insetEdge = 0x7f030310;

        /* JADX INFO: Added by JADX */
        public static final int layout_keyline = 0x7f030311;

        /* JADX INFO: Added by JADX */
        public static final int layout_marginBaseline = 0x7f030312;

        /* JADX INFO: Added by JADX */
        public static final int layout_optimizationLevel = 0x7f030313;

        /* JADX INFO: Added by JADX */
        public static final int layout_overflowIcon = 0x7f030314;

        /* JADX INFO: Added by JADX */
        public static final int layout_overflowText = 0x7f030315;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollEffect = 0x7f030316;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollFlags = 0x7f030317;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollInterpolator = 0x7f030318;

        /* JADX INFO: Added by JADX */
        public static final int layout_wrapBehaviorInParent = 0x7f030319;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScroll = 0x7f03031a;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScrollColor = 0x7f03031b;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScrollTargetViewId = 0x7f03031c;

        /* JADX INFO: Added by JADX */
        public static final int limitBoundsTo = 0x7f03031d;

        /* JADX INFO: Added by JADX */
        public static final int lineHeight = 0x7f03031e;

        /* JADX INFO: Added by JADX */
        public static final int lineSpacing = 0x7f03031f;

        /* JADX INFO: Added by JADX */
        public static final int linearProgressIndicatorStyle = 0x7f030320;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceBackgroundIndicator = 0x7f030321;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 0x7f030322;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 0x7f030323;

        /* JADX INFO: Added by JADX */
        public static final int listDividerAlertDialog = 0x7f030324;

        /* JADX INFO: Added by JADX */
        public static final int listItemCardViewSegmentedStyle = 0x7f030325;

        /* JADX INFO: Added by JADX */
        public static final int listItemCardViewStyle = 0x7f030326;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayout = 0x7f030327;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayoutStyle = 0x7f030328;

        /* JADX INFO: Added by JADX */
        public static final int listItemRevealLayoutStyle = 0x7f030329;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceChecked = 0x7f03032a;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceFirst = 0x7f03032b;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceFocused = 0x7f03032c;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceHovered = 0x7f03032d;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceLast = 0x7f03032e;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceMiddle = 0x7f03032f;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearancePressed = 0x7f030330;

        /* JADX INFO: Added by JADX */
        public static final int listItemShapeAppearanceSingle = 0x7f030331;

        /* JADX INFO: Added by JADX */
        public static final int listLayout = 0x7f030332;

        /* JADX INFO: Added by JADX */
        public static final int listMenuViewStyle = 0x7f030333;

        /* JADX INFO: Added by JADX */
        public static final int listPopupWindowStyle = 0x7f030334;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeight = 0x7f030335;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightLarge = 0x7f030336;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightSmall = 0x7f030337;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingEnd = 0x7f030338;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingLeft = 0x7f030339;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingRight = 0x7f03033a;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingStart = 0x7f03033b;

        /* JADX INFO: Added by JADX */
        public static final int loadingIndicatorStyle = 0x7f03033c;

        /* JADX INFO: Added by JADX */
        public static final int logo = 0x7f03033d;

        /* JADX INFO: Added by JADX */
        public static final int logoAdjustViewBounds = 0x7f03033e;

        /* JADX INFO: Added by JADX */
        public static final int logoDescription = 0x7f03033f;

        /* JADX INFO: Added by JADX */
        public static final int logoScaleType = 0x7f030340;

        /* JADX INFO: Added by JADX */
        public static final int marginBottomSystemWindowInsets = 0x7f030341;

        /* JADX INFO: Added by JADX */
        public static final int marginHorizontal = 0x7f030342;

        /* JADX INFO: Added by JADX */
        public static final int marginLeftSystemWindowInsets = 0x7f030343;

        /* JADX INFO: Added by JADX */
        public static final int marginRightSystemWindowInsets = 0x7f030344;

        /* JADX INFO: Added by JADX */
        public static final int marginTopSystemWindowInsets = 0x7f030345;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogBodyTextStyle = 0x7f030346;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogButtonSpacerVisibility = 0x7f030347;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTheme = 0x7f030348;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitleIconStyle = 0x7f030349;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitlePanelStyle = 0x7f03034a;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitleTextStyle = 0x7f03034b;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonElevatedStyle = 0x7f03034c;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonGroupOverflowButtonStyle = 0x7f03034d;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonGroupPopupMenuStyle = 0x7f03034e;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonGroupStyle = 0x7f03034f;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonOutlinedStyle = 0x7f030350;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonStyle = 0x7f030351;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonToggleGroupStyle = 0x7f030352;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonTonalStyle = 0x7f030353;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarDay = 0x7f030354;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarDayOfWeekLabel = 0x7f030355;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarFullscreenTheme = 0x7f030356;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderCancelButton = 0x7f030357;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderConfirmButton = 0x7f030358;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderDivider = 0x7f030359;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderLayout = 0x7f03035a;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderSelection = 0x7f03035b;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderTitle = 0x7f03035c;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderToggleButton = 0x7f03035d;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarMonth = 0x7f03035e;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarMonthNavigationButton = 0x7f03035f;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarStyle = 0x7f030360;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarTheme = 0x7f030361;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarYearNavigationButton = 0x7f030362;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewElevatedStyle = 0x7f030363;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewFilledStyle = 0x7f030364;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewOutlinedStyle = 0x7f030365;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewStyle = 0x7f030366;

        /* JADX INFO: Added by JADX */
        public static final int materialCircleRadius = 0x7f030367;

        /* JADX INFO: Added by JADX */
        public static final int materialClockStyle = 0x7f030368;

        /* JADX INFO: Added by JADX */
        public static final int materialDisplayDividerStyle = 0x7f030369;

        /* JADX INFO: Added by JADX */
        public static final int materialDividerHeavyStyle = 0x7f03036a;

        /* JADX INFO: Added by JADX */
        public static final int materialDividerStyle = 0x7f03036b;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonFilledStyle = 0x7f03036c;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonFilledTonalStyle = 0x7f03036d;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonOutlinedStyle = 0x7f03036e;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonStyle = 0x7f03036f;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchBarStyle = 0x7f030370;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewPrefixStyle = 0x7f030371;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewStyle = 0x7f030372;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewToolbarHeight = 0x7f030373;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewToolbarStyle = 0x7f030374;

        /* JADX INFO: Added by JADX */
        public static final int materialSizeOverlay = 0x7f030375;

        /* JADX INFO: Added by JADX */
        public static final int materialSplitButtonIconFilledStyle = 0x7f030376;

        /* JADX INFO: Added by JADX */
        public static final int materialSplitButtonIconFilledTonalStyle = 0x7f030377;

        /* JADX INFO: Added by JADX */
        public static final int materialSplitButtonLeadingFilledStyle = 0x7f030378;

        /* JADX INFO: Added by JADX */
        public static final int materialSplitButtonLeadingFilledTonalStyle = 0x7f030379;

        /* JADX INFO: Added by JADX */
        public static final int materialSplitButtonStyle = 0x7f03037a;

        /* JADX INFO: Added by JADX */
        public static final int materialSwitchStyle = 0x7f03037b;

        /* JADX INFO: Added by JADX */
        public static final int materialThemeOverlay = 0x7f03037c;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerStyle = 0x7f03037d;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerTheme = 0x7f03037e;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerTitleStyle = 0x7f03037f;

        /* JADX INFO: Added by JADX */
        public static final int materialToolbarActionBarItemBackground = 0x7f030380;

        /* JADX INFO: Added by JADX */
        public static final int materialToolbarSelectableItemBackground = 0x7f030381;

        /* JADX INFO: Added by JADX */
        public static final int materialToolbarSelectableItemBackgroundBorderless = 0x7f030382;

        /* JADX INFO: Added by JADX */
        public static final int maxAcceleration = 0x7f030383;

        /* JADX INFO: Added by JADX */
        public static final int maxActionInlineWidth = 0x7f030384;

        /* JADX INFO: Added by JADX */
        public static final int maxButtonHeight = 0x7f030385;

        /* JADX INFO: Added by JADX */
        public static final int maxCharacterCount = 0x7f030386;

        /* JADX INFO: Added by JADX */
        public static final int maxHeight = 0x7f030387;

        /* JADX INFO: Added by JADX */
        public static final int maxImageSize = 0x7f030388;

        /* JADX INFO: Added by JADX */
        public static final int maxLines = 0x7f030389;

        /* JADX INFO: Added by JADX */
        public static final int maxNumber = 0x7f03038a;

        /* JADX INFO: Added by JADX */
        public static final int maxVelocity = 0x7f03038b;

        /* JADX INFO: Added by JADX */
        public static final int maxWidth = 0x7f03038c;

        /* JADX INFO: Added by JADX */
        public static final int measureBottomPaddingFromLabelBaseline = 0x7f03038d;

        /* JADX INFO: Added by JADX */
        public static final int measureWithLargestChild = 0x7f03038e;

        /* JADX INFO: Added by JADX */
        public static final int menu = 0x7f03038f;

        /* JADX INFO: Added by JADX */
        public static final int menuAlignmentMode = 0x7f030390;

        /* JADX INFO: Added by JADX */
        public static final int menuGravity = 0x7f030391;

        /* JADX INFO: Added by JADX */
        public static final int methodName = 0x7f030392;

        /* JADX INFO: Added by JADX */
        public static final int minChildWidth = 0x7f030393;

        /* JADX INFO: Added by JADX */
        public static final int minHeight = 0x7f030394;

        /* JADX INFO: Added by JADX */
        public static final int minHideDelay = 0x7f030395;

        /* JADX INFO: Added by JADX */
        public static final int minSeparation = 0x7f030396;

        /* JADX INFO: Added by JADX */
        public static final int minTouchTargetSize = 0x7f030397;

        /* JADX INFO: Added by JADX */
        public static final int minWidth = 0x7f030398;

        /* JADX INFO: Added by JADX */
        public static final int mock_diagonalsColor = 0x7f030399;

        /* JADX INFO: Added by JADX */
        public static final int mock_label = 0x7f03039a;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelBackgroundColor = 0x7f03039b;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelColor = 0x7f03039c;

        /* JADX INFO: Added by JADX */
        public static final int mock_showDiagonals = 0x7f03039d;

        /* JADX INFO: Added by JADX */
        public static final int mock_showLabel = 0x7f03039e;

        /* JADX INFO: Added by JADX */
        public static final int motionDebug = 0x7f03039f;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong1 = 0x7f0303a0;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong2 = 0x7f0303a1;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong3 = 0x7f0303a2;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong4 = 0x7f0303a3;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong1 = 0x7f0303a4;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong2 = 0x7f0303a5;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong3 = 0x7f0303a6;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong4 = 0x7f0303a7;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium1 = 0x7f0303a8;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium2 = 0x7f0303a9;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium3 = 0x7f0303aa;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium4 = 0x7f0303ab;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort1 = 0x7f0303ac;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort2 = 0x7f0303ad;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort3 = 0x7f0303ae;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort4 = 0x7f0303af;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingAccelerated = 0x7f0303b0;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingDecelerated = 0x7f0303b1;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasized = 0x7f0303b2;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedAccelerateInterpolator = 0x7f0303b3;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedDecelerateInterpolator = 0x7f0303b4;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedInterpolator = 0x7f0303b5;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingLinear = 0x7f0303b6;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingLinearInterpolator = 0x7f0303b7;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandard = 0x7f0303b8;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardAccelerateInterpolator = 0x7f0303b9;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardDecelerateInterpolator = 0x7f0303ba;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardInterpolator = 0x7f0303bb;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_alpha = 0x7f0303bc;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_end = 0x7f0303bd;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_move = 0x7f0303be;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_start = 0x7f0303bf;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_strict = 0x7f0303c0;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationX = 0x7f0303c1;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationY = 0x7f0303c2;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_viewTransition = 0x7f0303c3;

        /* JADX INFO: Added by JADX */
        public static final int motionInterpolator = 0x7f0303c4;

        /* JADX INFO: Added by JADX */
        public static final int motionPath = 0x7f0303c5;

        /* JADX INFO: Added by JADX */
        public static final int motionPathRotate = 0x7f0303c6;

        /* JADX INFO: Added by JADX */
        public static final int motionProgress = 0x7f0303c7;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringDefaultEffects = 0x7f0303c8;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringDefaultSpatial = 0x7f0303c9;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringFastEffects = 0x7f0303ca;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringFastSpatial = 0x7f0303cb;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringSlowEffects = 0x7f0303cc;

        /* JADX INFO: Added by JADX */
        public static final int motionSpringSlowSpatial = 0x7f0303cd;

        /* JADX INFO: Added by JADX */
        public static final int motionStagger = 0x7f0303ce;

        /* JADX INFO: Added by JADX */
        public static final int motionTarget = 0x7f0303cf;

        /* JADX INFO: Added by JADX */
        public static final int motion_postLayoutCollision = 0x7f0303d0;

        /* JADX INFO: Added by JADX */
        public static final int motion_triggerOnCollision = 0x7f0303d1;

        /* JADX INFO: Added by JADX */
        public static final int moveWhenScrollAtTop = 0x7f0303d2;

        /* JADX INFO: Added by JADX */
        public static final int multiChoiceItemLayout = 0x7f0303d3;

        /* JADX INFO: Added by JADX */
        public static final int navigationContentDescription = 0x7f0303d4;

        /* JADX INFO: Added by JADX */
        public static final int navigationIcon = 0x7f0303d5;

        /* JADX INFO: Added by JADX */
        public static final int navigationIconTint = 0x7f0303d6;

        /* JADX INFO: Added by JADX */
        public static final int navigationMode = 0x7f0303d7;

        /* JADX INFO: Added by JADX */
        public static final int navigationRailStyle = 0x7f0303d8;

        /* JADX INFO: Added by JADX */
        public static final int navigationViewStyle = 0x7f0303d9;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollFlags = 0x7f0303da;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 0x7f0303db;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollable = 0x7f0303dc;

        /* JADX INFO: Added by JADX */
        public static final int number = 0x7f0303dd;

        /* JADX INFO: Added by JADX */
        public static final int numericModifiers = 0x7f0303de;

        /* JADX INFO: Added by JADX */
        public static final int offsetAlignmentMode = 0x7f0303df;

        /* JADX INFO: Added by JADX */
        public static final int onCross = 0x7f0303e0;

        /* JADX INFO: Added by JADX */
        public static final int onHide = 0x7f0303e1;

        /* JADX INFO: Added by JADX */
        public static final int onNegativeCross = 0x7f0303e2;

        /* JADX INFO: Added by JADX */
        public static final int onPositiveCross = 0x7f0303e3;

        /* JADX INFO: Added by JADX */
        public static final int onShow = 0x7f0303e4;

        /* JADX INFO: Added by JADX */
        public static final int onStateTransition = 0x7f0303e5;

        /* JADX INFO: Added by JADX */
        public static final int onTouchUp = 0x7f0303e6;

        /* JADX INFO: Added by JADX */
        public static final int opticalCenterEnabled = 0x7f0303e7;

        /* JADX INFO: Added by JADX */
        public static final int overflowButtonIcon = 0x7f0303e8;

        /* JADX INFO: Added by JADX */
        public static final int overflowLinearLayoutOverflowButtonStyle = 0x7f0303e9;

        /* JADX INFO: Added by JADX */
        public static final int overflowLinearLayoutPopupMenuStyle = 0x7f0303ea;

        /* JADX INFO: Added by JADX */
        public static final int overflowLinearLayoutStyle = 0x7f0303eb;

        /* JADX INFO: Added by JADX */
        public static final int overflowMode = 0x7f0303ec;

        /* JADX INFO: Added by JADX */
        public static final int overlapAnchor = 0x7f0303ed;

        /* JADX INFO: Added by JADX */
        public static final int overlay = 0x7f0303ee;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomNoButtons = 0x7f0303ef;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomSystemWindowInsets = 0x7f0303f0;

        /* JADX INFO: Added by JADX */
        public static final int paddingEnd = 0x7f0303f1;

        /* JADX INFO: Added by JADX */
        public static final int paddingLeftSystemWindowInsets = 0x7f0303f2;

        /* JADX INFO: Added by JADX */
        public static final int paddingRightSystemWindowInsets = 0x7f0303f3;

        /* JADX INFO: Added by JADX */
        public static final int paddingStart = 0x7f0303f4;

        /* JADX INFO: Added by JADX */
        public static final int paddingStartSystemWindowInsets = 0x7f0303f5;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopNoTitle = 0x7f0303f6;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopSystemWindowInsets = 0x7f0303f7;

        /* JADX INFO: Added by JADX */
        public static final int panelBackground = 0x7f0303f8;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListTheme = 0x7f0303f9;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListWidth = 0x7f0303fa;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleContentDescription = 0x7f0303fb;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleDrawable = 0x7f0303fc;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleEnabled = 0x7f0303fd;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleTint = 0x7f0303fe;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleTintMode = 0x7f0303ff;

        /* JADX INFO: Added by JADX */
        public static final int pathMotionArc = 0x7f030400;

        /* JADX INFO: Added by JADX */
        public static final int path_percent = 0x7f030401;

        /* JADX INFO: Added by JADX */
        public static final int percentHeight = 0x7f030402;

        /* JADX INFO: Added by JADX */
        public static final int percentWidth = 0x7f030403;

        /* JADX INFO: Added by JADX */
        public static final int percentX = 0x7f030404;

        /* JADX INFO: Added by JADX */
        public static final int percentY = 0x7f030405;

        /* JADX INFO: Added by JADX */
        public static final int perpendicularPath_percent = 0x7f030406;

        /* JADX INFO: Added by JADX */
        public static final int pivotAnchor = 0x7f030407;

        /* JADX INFO: Added by JADX */
        public static final int placeholderText = 0x7f030408;

        /* JADX INFO: Added by JADX */
        public static final int placeholderTextAppearance = 0x7f030409;

        /* JADX INFO: Added by JADX */
        public static final int placeholderTextColor = 0x7f03040a;

        /* JADX INFO: Added by JADX */
        public static final int placeholder_emptyVisibility = 0x7f03040b;

        /* JADX INFO: Added by JADX */
        public static final int polarRelativeTo = 0x7f03040c;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuBackground = 0x7f03040d;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuStyle = 0x7f03040e;

        /* JADX INFO: Added by JADX */
        public static final int popupTheme = 0x7f03040f;

        /* JADX INFO: Added by JADX */
        public static final int popupWindowStyle = 0x7f030410;

        /* JADX INFO: Added by JADX */
        public static final int prefixText = 0x7f030411;

        /* JADX INFO: Added by JADX */
        public static final int prefixTextAppearance = 0x7f030412;

        /* JADX INFO: Added by JADX */
        public static final int prefixTextColor = 0x7f030413;

        /* JADX INFO: Added by JADX */
        public static final int preserveIconSpacing = 0x7f030414;

        /* JADX INFO: Added by JADX */
        public static final int pressedTranslationZ = 0x7f030415;

        /* JADX INFO: Added by JADX */
        public static final int primaryActionSwipeMode = 0x7f030416;

        /* JADX INFO: Added by JADX */
        public static final int progressBarPadding = 0x7f030417;

        /* JADX INFO: Added by JADX */
        public static final int progressBarStyle = 0x7f030418;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionInterpolator = 0x7f030419;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionPhase = 0x7f03041a;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionSteps = 0x7f03041b;

        /* JADX INFO: Added by JADX */
        public static final int queryBackground = 0x7f03041c;

        /* JADX INFO: Added by JADX */
        public static final int queryHint = 0x7f03041d;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 0x7f03041e;

        /* JADX INFO: Added by JADX */
        public static final int radioButtonStyle = 0x7f03041f;

        /* JADX INFO: Added by JADX */
        public static final int rangeFillColor = 0x7f030420;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyle = 0x7f030421;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleIndicator = 0x7f030422;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleSmall = 0x7f030423;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_animateChange = 0x7f030424;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToAllConstraintSets = 0x7f030425;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToConstraintSet = 0x7f030426;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_valueId = 0x7f030427;

        /* JADX INFO: Added by JADX */
        public static final int recyclerViewStyle = 0x7f030428;

        /* JADX INFO: Added by JADX */
        public static final int region_heightLessThan = 0x7f030429;

        /* JADX INFO: Added by JADX */
        public static final int region_heightMoreThan = 0x7f03042a;

        /* JADX INFO: Added by JADX */
        public static final int region_widthLessThan = 0x7f03042b;

        /* JADX INFO: Added by JADX */
        public static final int region_widthMoreThan = 0x7f03042c;

        /* JADX INFO: Added by JADX */
        public static final int removeEmbeddedFabElevation = 0x7f03042d;

        /* JADX INFO: Added by JADX */
        public static final int reverseLayout = 0x7f03042e;

        /* JADX INFO: Added by JADX */
        public static final int rippleColor = 0x7f03042f;

        /* JADX INFO: Added by JADX */
        public static final int rotationCenterId = 0x7f030430;

        /* JADX INFO: Added by JADX */
        public static final int round = 0x7f030431;

        /* JADX INFO: Added by JADX */
        public static final int roundPercent = 0x7f030432;

        /* JADX INFO: Added by JADX */
        public static final int saturation = 0x7f030433;

        /* JADX INFO: Added by JADX */
        public static final int scaleFromTextSize = 0x7f030434;

        /* JADX INFO: Added by JADX */
        public static final int scopeUris = 0x7f030435;

        /* JADX INFO: Added by JADX */
        public static final int scrimAnimationDuration = 0x7f030436;

        /* JADX INFO: Added by JADX */
        public static final int scrimBackground = 0x7f030437;

        /* JADX INFO: Added by JADX */
        public static final int scrimVisibleHeightTrigger = 0x7f030438;

        /* JADX INFO: Added by JADX */
        public static final int scrollingEnabled = 0x7f030439;

        /* JADX INFO: Added by JADX */
        public static final int searchHintIcon = 0x7f03043a;

        /* JADX INFO: Added by JADX */
        public static final int searchIcon = 0x7f03043b;

        /* JADX INFO: Added by JADX */
        public static final int searchPrefixText = 0x7f03043c;

        /* JADX INFO: Added by JADX */
        public static final int searchViewStyle = 0x7f03043d;

        /* JADX INFO: Added by JADX */
        public static final int secondaryIcon = 0x7f03043e;

        /* JADX INFO: Added by JADX */
        public static final int secondaryIconGravity = 0x7f03043f;

        /* JADX INFO: Added by JADX */
        public static final int secondaryIconTint = 0x7f030440;

        /* JADX INFO: Added by JADX */
        public static final int secondaryIconTintMode = 0x7f030441;

        /* JADX INFO: Added by JADX */
        public static final int seekBarStyle = 0x7f030442;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackground = 0x7f030443;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackgroundBorderless = 0x7f030444;

        /* JADX INFO: Added by JADX */
        public static final int selectionRequired = 0x7f030445;

        /* JADX INFO: Added by JADX */
        public static final int selectorSize = 0x7f030446;

        /* JADX INFO: Added by JADX */
        public static final int setsTag = 0x7f030447;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearance = 0x7f030448;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraExtraLarge = 0x7f030449;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraLarge = 0x7f03044a;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraLargeIncreased = 0x7f03044b;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraSmall = 0x7f03044c;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerLarge = 0x7f03044d;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerLargeIncreased = 0x7f03044e;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerMedium = 0x7f03044f;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerSmall = 0x7f030450;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceLargeComponent = 0x7f030451;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceMediumComponent = 0x7f030452;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceOverlay = 0x7f030453;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceSmallComponent = 0x7f030454;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerFamily = 0x7f030455;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeExtraExtraLarge = 0x7f030456;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeExtraLarge = 0x7f030457;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeExtraLargeIncreased = 0x7f030458;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeExtraSmall = 0x7f030459;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeLarge = 0x7f03045a;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeLargeIncreased = 0x7f03045b;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeMedium = 0x7f03045c;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerSizeSmall = 0x7f03045d;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 0x7f03045e;

        /* JADX INFO: Added by JADX */
        public static final int shouldRemoveExpandedCorners = 0x7f03045f;

        /* JADX INFO: Added by JADX */
        public static final int showAnimationBehavior = 0x7f030460;

        /* JADX INFO: Added by JADX */
        public static final int showAsAction = 0x7f030461;

        /* JADX INFO: Added by JADX */
        public static final int showDelay = 0x7f030462;

        /* JADX INFO: Added by JADX */
        public static final int showDividers = 0x7f030463;

        /* JADX INFO: Added by JADX */
        public static final int showMarker = 0x7f030464;

        /* JADX INFO: Added by JADX */
        public static final int showMotionSpec = 0x7f030465;

        /* JADX INFO: Added by JADX */
        public static final int showPaths = 0x7f030466;

        /* JADX INFO: Added by JADX */
        public static final int showText = 0x7f030467;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f030468;

        /* JADX INFO: Added by JADX */
        public static final int shrinkMotionSpec = 0x7f030469;

        /* JADX INFO: Added by JADX */
        public static final int sideSheetDialogTheme = 0x7f03046a;

        /* JADX INFO: Added by JADX */
        public static final int sideSheetModalStyle = 0x7f03046b;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemLayout = 0x7f03046c;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemSelectedColor = 0x7f03046d;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemSelectedRippleColor = 0x7f03046e;

        /* JADX INFO: Added by JADX */
        public static final int simpleItems = 0x7f03046f;

        /* JADX INFO: Added by JADX */
        public static final int singleChoiceItemLayout = 0x7f030470;

        /* JADX INFO: Added by JADX */
        public static final int singleLine = 0x7f030471;

        /* JADX INFO: Added by JADX */
        public static final int singleSelection = 0x7f030472;

        /* JADX INFO: Added by JADX */
        public static final int sizePercent = 0x7f030473;

        /* JADX INFO: Added by JADX */
        public static final int sliderStyle = 0x7f030474;

        /* JADX INFO: Added by JADX */
        public static final int snackbarButtonStyle = 0x7f030475;

        /* JADX INFO: Added by JADX */
        public static final int snackbarCloseButtonStyle = 0x7f030476;

        /* JADX INFO: Added by JADX */
        public static final int snackbarStyle = 0x7f030477;

        /* JADX INFO: Added by JADX */
        public static final int snackbarTextViewStyle = 0x7f030478;

        /* JADX INFO: Added by JADX */
        public static final int spanCount = 0x7f030479;

        /* JADX INFO: Added by JADX */
        public static final int spinBars = 0x7f03047a;

        /* JADX INFO: Added by JADX */
        public static final int spinnerDropDownItemStyle = 0x7f03047b;

        /* JADX INFO: Added by JADX */
        public static final int spinnerStyle = 0x7f03047c;

        /* JADX INFO: Added by JADX */
        public static final int splitTrack = 0x7f03047d;

        /* JADX INFO: Added by JADX */
        public static final int springBoundary = 0x7f03047e;

        /* JADX INFO: Added by JADX */
        public static final int springDamping = 0x7f03047f;

        /* JADX INFO: Added by JADX */
        public static final int springMass = 0x7f030480;

        /* JADX INFO: Added by JADX */
        public static final int springStiffness = 0x7f030481;

        /* JADX INFO: Added by JADX */
        public static final int springStopThreshold = 0x7f030482;

        /* JADX INFO: Added by JADX */
        public static final int srcCompat = 0x7f030483;

        /* JADX INFO: Added by JADX */
        public static final int stackFromEnd = 0x7f030484;

        /* JADX INFO: Added by JADX */
        public static final int staggered = 0x7f030485;

        /* JADX INFO: Added by JADX */
        public static final int startIconCheckable = 0x7f030486;

        /* JADX INFO: Added by JADX */
        public static final int startIconContentDescription = 0x7f030487;

        /* JADX INFO: Added by JADX */
        public static final int startIconDrawable = 0x7f030488;

        /* JADX INFO: Added by JADX */
        public static final int startIconMinSize = 0x7f030489;

        /* JADX INFO: Added by JADX */
        public static final int startIconScaleType = 0x7f03048a;

        /* JADX INFO: Added by JADX */
        public static final int startIconTint = 0x7f03048b;

        /* JADX INFO: Added by JADX */
        public static final int startIconTintMode = 0x7f03048c;

        /* JADX INFO: Added by JADX */
        public static final int startInsetScrimEnabled = 0x7f03048d;

        /* JADX INFO: Added by JADX */
        public static final int startSiblingViewId = 0x7f03048e;

        /* JADX INFO: Added by JADX */
        public static final int stateLabels = 0x7f03048f;

        /* JADX INFO: Added by JADX */
        public static final int state_above_anchor = 0x7f030490;

        /* JADX INFO: Added by JADX */
        public static final int state_collapsed = 0x7f030491;

        /* JADX INFO: Added by JADX */
        public static final int state_collapsible = 0x7f030492;

        /* JADX INFO: Added by JADX */
        public static final int state_dragged = 0x7f030493;

        /* JADX INFO: Added by JADX */
        public static final int state_error = 0x7f030494;

        /* JADX INFO: Added by JADX */
        public static final int state_indeterminate = 0x7f030495;

        /* JADX INFO: Added by JADX */
        public static final int state_liftable = 0x7f030496;

        /* JADX INFO: Added by JADX */
        public static final int state_lifted = 0x7f030497;

        /* JADX INFO: Added by JADX */
        public static final int state_swiped = 0x7f030498;

        /* JADX INFO: Added by JADX */
        public static final int state_with_icon = 0x7f030499;

        /* JADX INFO: Added by JADX */
        public static final int statusBarBackground = 0x7f03049a;

        /* JADX INFO: Added by JADX */
        public static final int statusBarForeground = 0x7f03049b;

        /* JADX INFO: Added by JADX */
        public static final int statusBarScrim = 0x7f03049c;

        /* JADX INFO: Added by JADX */
        public static final int stiffness = 0x7f03049d;

        /* JADX INFO: Added by JADX */
        public static final int strokeColor = 0x7f03049e;

        /* JADX INFO: Added by JADX */
        public static final int strokeWidth = 0x7f03049f;

        /* JADX INFO: Added by JADX */
        public static final int subMenuArrow = 0x7f0304a0;

        /* JADX INFO: Added by JADX */
        public static final int subheaderColor = 0x7f0304a1;

        /* JADX INFO: Added by JADX */
        public static final int subheaderInsetEnd = 0x7f0304a2;

        /* JADX INFO: Added by JADX */
        public static final int subheaderInsetStart = 0x7f0304a3;

        /* JADX INFO: Added by JADX */
        public static final int subheaderTextAppearance = 0x7f0304a4;

        /* JADX INFO: Added by JADX */
        public static final int submenuDividersEnabled = 0x7f0304a5;

        /* JADX INFO: Added by JADX */
        public static final int submitBackground = 0x7f0304a6;

        /* JADX INFO: Added by JADX */
        public static final int subtitle = 0x7f0304a7;

        /* JADX INFO: Added by JADX */
        public static final int subtitleCentered = 0x7f0304a8;

        /* JADX INFO: Added by JADX */
        public static final int subtitleMaxLines = 0x7f0304a9;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextAppearance = 0x7f0304aa;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextColor = 0x7f0304ab;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextStyle = 0x7f0304ac;

        /* JADX INFO: Added by JADX */
        public static final int suffixText = 0x7f0304ad;

        /* JADX INFO: Added by JADX */
        public static final int suffixTextAppearance = 0x7f0304ae;

        /* JADX INFO: Added by JADX */
        public static final int suffixTextColor = 0x7f0304af;

        /* JADX INFO: Added by JADX */
        public static final int suggestionRowLayout = 0x7f0304b0;

        /* JADX INFO: Added by JADX */
        public static final int swipeEnabled = 0x7f0304b1;

        /* JADX INFO: Added by JADX */
        public static final int switchMinWidth = 0x7f0304b2;

        /* JADX INFO: Added by JADX */
        public static final int switchPadding = 0x7f0304b3;

        /* JADX INFO: Added by JADX */
        public static final int switchStyle = 0x7f0304b4;

        /* JADX INFO: Added by JADX */
        public static final int switchTextAppearance = 0x7f0304b5;

        /* JADX INFO: Added by JADX */
        public static final int tabBackground = 0x7f0304b6;

        /* JADX INFO: Added by JADX */
        public static final int tabContentStart = 0x7f0304b7;

        /* JADX INFO: Added by JADX */
        public static final int tabGravity = 0x7f0304b8;

        /* JADX INFO: Added by JADX */
        public static final int tabIconTint = 0x7f0304b9;

        /* JADX INFO: Added by JADX */
        public static final int tabIconTintMode = 0x7f0304ba;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicator = 0x7f0304bb;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorAnimationDuration = 0x7f0304bc;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorAnimationMode = 0x7f0304bd;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorColor = 0x7f0304be;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorFullWidth = 0x7f0304bf;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorGravity = 0x7f0304c0;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorHeight = 0x7f0304c1;

        /* JADX INFO: Added by JADX */
        public static final int tabInlineLabel = 0x7f0304c2;

        /* JADX INFO: Added by JADX */
        public static final int tabMaxWidth = 0x7f0304c3;

        /* JADX INFO: Added by JADX */
        public static final int tabMinWidth = 0x7f0304c4;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 0x7f0304c5;

        /* JADX INFO: Added by JADX */
        public static final int tabPadding = 0x7f0304c6;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingBottom = 0x7f0304c7;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingEnd = 0x7f0304c8;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingStart = 0x7f0304c9;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingTop = 0x7f0304ca;

        /* JADX INFO: Added by JADX */
        public static final int tabRippleColor = 0x7f0304cb;

        /* JADX INFO: Added by JADX */
        public static final int tabSecondaryStyle = 0x7f0304cc;

        /* JADX INFO: Added by JADX */
        public static final int tabSelectedTextAppearance = 0x7f0304cd;

        /* JADX INFO: Added by JADX */
        public static final int tabSelectedTextColor = 0x7f0304ce;

        /* JADX INFO: Added by JADX */
        public static final int tabStyle = 0x7f0304cf;

        /* JADX INFO: Added by JADX */
        public static final int tabTextAppearance = 0x7f0304d0;

        /* JADX INFO: Added by JADX */
        public static final int tabTextColor = 0x7f0304d1;

        /* JADX INFO: Added by JADX */
        public static final int tabUnboundedRipple = 0x7f0304d2;

        /* JADX INFO: Added by JADX */
        public static final int targetId = 0x7f0304d3;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailColor = 0x7f0304d4;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailScale = 0x7f0304d5;

        /* JADX INFO: Added by JADX */
        public static final int telltales_velocityMode = 0x7f0304d6;

        /* JADX INFO: Added by JADX */
        public static final int textAllCaps = 0x7f0304d7;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBody1 = 0x7f0304d8;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBody2 = 0x7f0304d9;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyLarge = 0x7f0304da;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyLargeEmphasized = 0x7f0304db;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyMedium = 0x7f0304dc;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyMediumEmphasized = 0x7f0304dd;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodySmall = 0x7f0304de;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodySmallEmphasized = 0x7f0304df;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceButton = 0x7f0304e0;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceCaption = 0x7f0304e1;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayLarge = 0x7f0304e2;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayLargeEmphasized = 0x7f0304e3;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayMedium = 0x7f0304e4;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayMediumEmphasized = 0x7f0304e5;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplaySmall = 0x7f0304e6;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplaySmallEmphasized = 0x7f0304e7;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline1 = 0x7f0304e8;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline2 = 0x7f0304e9;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline3 = 0x7f0304ea;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline4 = 0x7f0304eb;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline5 = 0x7f0304ec;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline6 = 0x7f0304ed;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineLarge = 0x7f0304ee;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineLargeEmphasized = 0x7f0304ef;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineMedium = 0x7f0304f0;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineMediumEmphasized = 0x7f0304f1;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineSmall = 0x7f0304f2;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineSmallEmphasized = 0x7f0304f3;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelLarge = 0x7f0304f4;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelLargeEmphasized = 0x7f0304f5;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelMedium = 0x7f0304f6;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelMediumEmphasized = 0x7f0304f7;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelSmall = 0x7f0304f8;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelSmallEmphasized = 0x7f0304f9;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLargePopupMenu = 0x7f0304fa;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLineHeightEnabled = 0x7f0304fb;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItem = 0x7f0304fc;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSecondary = 0x7f0304fd;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSmall = 0x7f0304fe;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceOverline = 0x7f0304ff;

        /* JADX INFO: Added by JADX */
        public static final int textAppearancePopupMenuHeader = 0x7f030500;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 0x7f030501;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultTitle = 0x7f030502;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSmallPopupMenu = 0x7f030503;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSubtitle1 = 0x7f030504;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSubtitle2 = 0x7f030505;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleLarge = 0x7f030506;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleLargeEmphasized = 0x7f030507;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleMedium = 0x7f030508;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleMediumEmphasized = 0x7f030509;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleSmall = 0x7f03050a;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleSmallEmphasized = 0x7f03050b;

        /* JADX INFO: Added by JADX */
        public static final int textBackground = 0x7f03050c;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanX = 0x7f03050d;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanY = 0x7f03050e;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundRotate = 0x7f03050f;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundZoom = 0x7f030510;

        /* JADX INFO: Added by JADX */
        public static final int textCentered = 0x7f030511;

        /* JADX INFO: Added by JADX */
        public static final int textColorAlertDialogListItem = 0x7f030512;

        /* JADX INFO: Added by JADX */
        public static final int textColorSearchUrl = 0x7f030513;

        /* JADX INFO: Added by JADX */
        public static final int textEndPadding = 0x7f030514;

        /* JADX INFO: Added by JADX */
        public static final int textFillColor = 0x7f030515;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledDenseStyle = 0x7f030516;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledExposedDropdownMenuStyle = 0x7f030517;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledStyle = 0x7f030518;

        /* JADX INFO: Added by JADX */
        public static final int textInputLayoutFocusedRectEnabled = 0x7f030519;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedDenseStyle = 0x7f03051a;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedExposedDropdownMenuStyle = 0x7f03051b;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedStyle = 0x7f03051c;

        /* JADX INFO: Added by JADX */
        public static final int textInputStyle = 0x7f03051d;

        /* JADX INFO: Added by JADX */
        public static final int textLocale = 0x7f03051e;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineColor = 0x7f03051f;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineThickness = 0x7f030520;

        /* JADX INFO: Added by JADX */
        public static final int textPanX = 0x7f030521;

        /* JADX INFO: Added by JADX */
        public static final int textPanY = 0x7f030522;

        /* JADX INFO: Added by JADX */
        public static final int textStartPadding = 0x7f030523;

        /* JADX INFO: Added by JADX */
        public static final int textureBlurFactor = 0x7f030524;

        /* JADX INFO: Added by JADX */
        public static final int textureEffect = 0x7f030525;

        /* JADX INFO: Added by JADX */
        public static final int textureHeight = 0x7f030526;

        /* JADX INFO: Added by JADX */
        public static final int textureWidth = 0x7f030527;

        /* JADX INFO: Added by JADX */
        public static final int theme = 0x7f030528;

        /* JADX INFO: Added by JADX */
        public static final int thickness = 0x7f030529;

        /* JADX INFO: Added by JADX */
        public static final int thumbColor = 0x7f03052a;

        /* JADX INFO: Added by JADX */
        public static final int thumbElevation = 0x7f03052b;

        /* JADX INFO: Added by JADX */
        public static final int thumbHeight = 0x7f03052c;

        /* JADX INFO: Added by JADX */
        public static final int thumbIcon = 0x7f03052d;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconSize = 0x7f03052e;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconTint = 0x7f03052f;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconTintMode = 0x7f030530;

        /* JADX INFO: Added by JADX */
        public static final int thumbRadius = 0x7f030531;

        /* JADX INFO: Added by JADX */
        public static final int thumbStrokeColor = 0x7f030532;

        /* JADX INFO: Added by JADX */
        public static final int thumbStrokeWidth = 0x7f030533;

        /* JADX INFO: Added by JADX */
        public static final int thumbTextPadding = 0x7f030534;

        /* JADX INFO: Added by JADX */
        public static final int thumbTint = 0x7f030535;

        /* JADX INFO: Added by JADX */
        public static final int thumbTintMode = 0x7f030536;

        /* JADX INFO: Added by JADX */
        public static final int thumbTrackGapSize = 0x7f030537;

        /* JADX INFO: Added by JADX */
        public static final int thumbWidth = 0x7f030538;

        /* JADX INFO: Added by JADX */
        public static final int tickColor = 0x7f030539;

        /* JADX INFO: Added by JADX */
        public static final int tickColorActive = 0x7f03053a;

        /* JADX INFO: Added by JADX */
        public static final int tickColorInactive = 0x7f03053b;

        /* JADX INFO: Added by JADX */
        public static final int tickMark = 0x7f03053c;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTint = 0x7f03053d;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTintMode = 0x7f03053e;

        /* JADX INFO: Added by JADX */
        public static final int tickRadiusActive = 0x7f03053f;

        /* JADX INFO: Added by JADX */
        public static final int tickRadiusInactive = 0x7f030540;

        /* JADX INFO: Added by JADX */
        public static final int tickVisibilityMode = 0x7f030541;

        /* JADX INFO: Added by JADX */
        public static final int tickVisible = 0x7f030542;

        /* JADX INFO: Added by JADX */
        public static final int tint = 0x7f030543;

        /* JADX INFO: Added by JADX */
        public static final int tintMode = 0x7f030544;

        /* JADX INFO: Added by JADX */
        public static final int tintNavigationIcon = 0x7f030545;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f030546;

        /* JADX INFO: Added by JADX */
        public static final int titleCentered = 0x7f030547;

        /* JADX INFO: Added by JADX */
        public static final int titleCollapseMode = 0x7f030548;

        /* JADX INFO: Added by JADX */
        public static final int titleEnabled = 0x7f030549;

        /* JADX INFO: Added by JADX */
        public static final int titleMargin = 0x7f03054a;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginBottom = 0x7f03054b;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginEnd = 0x7f03054c;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginStart = 0x7f03054d;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginTop = 0x7f03054e;

        /* JADX INFO: Added by JADX */
        public static final int titleMargins = 0x7f03054f;

        /* JADX INFO: Added by JADX */
        public static final int titleMaxLines = 0x7f030550;

        /* JADX INFO: Added by JADX */
        public static final int titlePositionInterpolator = 0x7f030551;

        /* JADX INFO: Added by JADX */
        public static final int titleTextAppearance = 0x7f030552;

        /* JADX INFO: Added by JADX */
        public static final int titleTextColor = 0x7f030553;

        /* JADX INFO: Added by JADX */
        public static final int titleTextEllipsize = 0x7f030554;

        /* JADX INFO: Added by JADX */
        public static final int titleTextStyle = 0x7f030555;

        /* JADX INFO: Added by JADX */
        public static final int toggleCheckedStateOnClick = 0x7f030556;

        /* JADX INFO: Added by JADX */
        public static final int toolbarId = 0x7f030557;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonBackground = 0x7f030558;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonCircleColor = 0x7f030559;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonStyle = 0x7f03055a;

        /* JADX INFO: Added by JADX */
        public static final int toolbarStyle = 0x7f03055b;

        /* JADX INFO: Added by JADX */
        public static final int toolbarSurfaceStyle = 0x7f03055c;

        /* JADX INFO: Added by JADX */
        public static final int tooltipForegroundColor = 0x7f03055d;

        /* JADX INFO: Added by JADX */
        public static final int tooltipFrameBackground = 0x7f03055e;

        /* JADX INFO: Added by JADX */
        public static final int tooltipStyle = 0x7f03055f;

        /* JADX INFO: Added by JADX */
        public static final int tooltipText = 0x7f030560;

        /* JADX INFO: Added by JADX */
        public static final int topInsetScrimEnabled = 0x7f030561;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorId = 0x7f030562;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorSide = 0x7f030563;

        /* JADX INFO: Added by JADX */
        public static final int touchRegionId = 0x7f030564;

        /* JADX INFO: Added by JADX */
        public static final int track = 0x7f030565;

        /* JADX INFO: Added by JADX */
        public static final int trackColor = 0x7f030566;

        /* JADX INFO: Added by JADX */
        public static final int trackColorActive = 0x7f030567;

        /* JADX INFO: Added by JADX */
        public static final int trackColorInactive = 0x7f030568;

        /* JADX INFO: Added by JADX */
        public static final int trackCornerRadius = 0x7f030569;

        /* JADX INFO: Added by JADX */
        public static final int trackCornerSize = 0x7f03056a;

        /* JADX INFO: Added by JADX */
        public static final int trackDecoration = 0x7f03056b;

        /* JADX INFO: Added by JADX */
        public static final int trackDecorationTint = 0x7f03056c;

        /* JADX INFO: Added by JADX */
        public static final int trackDecorationTintMode = 0x7f03056d;

        /* JADX INFO: Added by JADX */
        public static final int trackHeight = 0x7f03056e;

        /* JADX INFO: Added by JADX */
        public static final int trackIconActiveColor = 0x7f03056f;

        /* JADX INFO: Added by JADX */
        public static final int trackIconActiveEnd = 0x7f030570;

        /* JADX INFO: Added by JADX */
        public static final int trackIconActiveStart = 0x7f030571;

        /* JADX INFO: Added by JADX */
        public static final int trackIconInactiveColor = 0x7f030572;

        /* JADX INFO: Added by JADX */
        public static final int trackIconInactiveEnd = 0x7f030573;

        /* JADX INFO: Added by JADX */
        public static final int trackIconInactiveStart = 0x7f030574;

        /* JADX INFO: Added by JADX */
        public static final int trackIconSize = 0x7f030575;

        /* JADX INFO: Added by JADX */
        public static final int trackInnerCornerRadius = 0x7f030576;

        /* JADX INFO: Added by JADX */
        public static final int trackInsideCornerSize = 0x7f030577;

        /* JADX INFO: Added by JADX */
        public static final int trackStopIndicatorPadding = 0x7f030578;

        /* JADX INFO: Added by JADX */
        public static final int trackStopIndicatorSize = 0x7f030579;

        /* JADX INFO: Added by JADX */
        public static final int trackThickness = 0x7f03057a;

        /* JADX INFO: Added by JADX */
        public static final int trackTint = 0x7f03057b;

        /* JADX INFO: Added by JADX */
        public static final int trackTintMode = 0x7f03057c;

        /* JADX INFO: Added by JADX */
        public static final int transformPivotTarget = 0x7f03057d;

        /* JADX INFO: Added by JADX */
        public static final int transitionDisable = 0x7f03057e;

        /* JADX INFO: Added by JADX */
        public static final int transitionEasing = 0x7f03057f;

        /* JADX INFO: Added by JADX */
        public static final int transitionFlags = 0x7f030580;

        /* JADX INFO: Added by JADX */
        public static final int transitionPathRotate = 0x7f030581;

        /* JADX INFO: Added by JADX */
        public static final int transitionShapeAppearance = 0x7f030582;

        /* JADX INFO: Added by JADX */
        public static final int triggerId = 0x7f030583;

        /* JADX INFO: Added by JADX */
        public static final int triggerReceiver = 0x7f030584;

        /* JADX INFO: Added by JADX */
        public static final int triggerSlack = 0x7f030585;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f030586;

        /* JADX INFO: Added by JADX */
        public static final int upDuration = 0x7f030587;

        /* JADX INFO: Added by JADX */
        public static final int useCompatPadding = 0x7f030588;

        /* JADX INFO: Added by JADX */
        public static final int useDrawerArrowDrawable = 0x7f030589;

        /* JADX INFO: Added by JADX */
        public static final int useMaterialThemeColors = 0x7f03058a;

        /* JADX INFO: Added by JADX */
        public static final int values = 0x7f03058b;

        /* JADX INFO: Added by JADX */
        public static final int verticalOffset = 0x7f03058c;

        /* JADX INFO: Added by JADX */
        public static final int verticalOffsetWithText = 0x7f03058d;

        /* JADX INFO: Added by JADX */
        public static final int viewInflaterClass = 0x7f03058e;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionMode = 0x7f03058f;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnCross = 0x7f030590;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnNegativeCross = 0x7f030591;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnPositiveCross = 0x7f030592;

        /* JADX INFO: Added by JADX */
        public static final int visibilityMode = 0x7f030593;

        /* JADX INFO: Added by JADX */
        public static final int voiceIcon = 0x7f030594;

        /* JADX INFO: Added by JADX */
        public static final int warmth = 0x7f030595;

        /* JADX INFO: Added by JADX */
        public static final int waveAmplitude = 0x7f030596;

        /* JADX INFO: Added by JADX */
        public static final int waveAmplitudeRampProgressMax = 0x7f030597;

        /* JADX INFO: Added by JADX */
        public static final int waveAmplitudeRampProgressMin = 0x7f030598;

        /* JADX INFO: Added by JADX */
        public static final int waveDecay = 0x7f030599;

        /* JADX INFO: Added by JADX */
        public static final int waveOffset = 0x7f03059a;

        /* JADX INFO: Added by JADX */
        public static final int wavePeriod = 0x7f03059b;

        /* JADX INFO: Added by JADX */
        public static final int wavePhase = 0x7f03059c;

        /* JADX INFO: Added by JADX */
        public static final int waveShape = 0x7f03059d;

        /* JADX INFO: Added by JADX */
        public static final int waveSpeed = 0x7f03059e;

        /* JADX INFO: Added by JADX */
        public static final int waveVariesBy = 0x7f03059f;

        /* JADX INFO: Added by JADX */
        public static final int wavelength = 0x7f0305a0;

        /* JADX INFO: Added by JADX */
        public static final int wavelengthDeterminate = 0x7f0305a1;

        /* JADX INFO: Added by JADX */
        public static final int wavelengthIndeterminate = 0x7f0305a2;

        /* JADX INFO: Added by JADX */
        public static final int widthChange = 0x7f0305a3;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBar = 0x7f0305a4;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBarOverlay = 0x7f0305a5;

        /* JADX INFO: Added by JADX */
        public static final int windowActionModeOverlay = 0x7f0305a6;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMajor = 0x7f0305a7;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMinor = 0x7f0305a8;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMajor = 0x7f0305a9;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMinor = 0x7f0305aa;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMajor = 0x7f0305ab;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMinor = 0x7f0305ac;

        /* JADX INFO: Added by JADX */
        public static final int windowNoTitle = 0x7f0305ad;

        /* JADX INFO: Added by JADX */
        public static final int yearSelectedStyle = 0x7f0305ae;

        /* JADX INFO: Added by JADX */
        public static final int yearStyle = 0x7f0305af;

        /* JADX INFO: Added by JADX */
        public static final int yearTodayStyle = 0x7f0305b0;
    }

    /* JADX INFO: Added by JADX */
    public static final class bool {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_embed_tabs = 0x7f040000;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 0x7f040001;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_rings_enabled = 0x7f040002;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_textappearance_all_caps = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int timepicker_force_input_mode_keyboard = 0x7f040004;
    }

    public static final class color {
        public static final int black = 0x7f050021;
        public static final int ic_launcher_background = 0x7f05006b;
        public static final int purple_200 = 0x7f0503be;
        public static final int purple_500 = 0x7f0503bf;
        public static final int purple_700 = 0x7f0503c0;
        public static final int teal_200 = 0x7f0503cd;
        public static final int teal_700 = 0x7f0503ce;
        public static final int white = 0x7f0503d1;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 0x7f050002;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_text_material = 0x7f050003;

        /* JADX INFO: Added by JADX */
        public static final int abc_color_highlight_material = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard_light = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_dark = 0x7f050007;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_light = 0x7f050008;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 0x7f050009;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 0x7f05000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_dark = 0x7f05000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_light = 0x7f05000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text = 0x7f05000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_normal = 0x7f05000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_pressed = 0x7f05000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_selected = 0x7f050010;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_dark = 0x7f050011;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_light = 0x7f050012;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_btn_checkable = 0x7f050013;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_default = 0x7f050014;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_edittext = 0x7f050015;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_seek_thumb = 0x7f050016;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_spinner = 0x7f050017;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_switch_track = 0x7f050018;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_dark = 0x7f050019;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_light = 0x7f05001a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 0x7f05001b;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 0x7f05001c;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_dark = 0x7f05001d;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_light = 0x7f05001e;

        /* JADX INFO: Added by JADX */
        public static final int background_material_dark = 0x7f05001f;

        /* JADX INFO: Added by JADX */
        public static final int background_material_light = 0x7f050020;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_dark = 0x7f050022;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_light = 0x7f050023;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_dark = 0x7f050024;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_inverse_material_light = 0x7f050025;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_dark = 0x7f050026;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_light = 0x7f050027;

        /* JADX INFO: Added by JADX */
        public static final int button_material_dark = 0x7f050028;

        /* JADX INFO: Added by JADX */
        public static final int button_material_light = 0x7f050029;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 0x7f05002a;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 0x7f05002b;

        /* JADX INFO: Added by JADX */
        public static final int cardview_dark_background = 0x7f05002c;

        /* JADX INFO: Added by JADX */
        public static final int cardview_light_background = 0x7f05002d;

        /* JADX INFO: Added by JADX */
        public static final int cardview_shadow_end_color = 0x7f05002e;

        /* JADX INFO: Added by JADX */
        public static final int cardview_shadow_start_color = 0x7f05002f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f050030;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_default = 0x7f050031;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_disabled = 0x7f050032;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f050033;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_pressed = 0x7f050034;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f050035;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_default = 0x7f050036;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_disabled = 0x7f050037;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f050038;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_pressed = 0x7f050039;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_tint = 0x7f05003a;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_shadow_color = 0x7f05003b;

        /* JADX INFO: Added by JADX */
        public static final int design_box_stroke_color = 0x7f05003c;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_background = 0x7f05003d;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_error = 0x7f05003e;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_background = 0x7f05003f;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_error = 0x7f050040;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_primary = 0x7f050041;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_secondary = 0x7f050042;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_surface = 0x7f050043;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary = 0x7f050044;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary_dark = 0x7f050045;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary_variant = 0x7f050046;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_secondary = 0x7f050047;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_secondary_variant = 0x7f050048;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_surface = 0x7f050049;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_background = 0x7f05004a;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_error = 0x7f05004b;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_background = 0x7f05004c;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_error = 0x7f05004d;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_primary = 0x7f05004e;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_secondary = 0x7f05004f;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_surface = 0x7f050050;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary = 0x7f050051;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary_dark = 0x7f050052;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary_variant = 0x7f050053;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_secondary = 0x7f050054;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_secondary_variant = 0x7f050055;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_surface = 0x7f050056;

        /* JADX INFO: Added by JADX */
        public static final int design_error = 0x7f050057;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_shadow_end_color = 0x7f050058;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_shadow_mid_color = 0x7f050059;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_shadow_start_color = 0x7f05005a;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_stroke_end_inner_color = 0x7f05005b;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_stroke_end_outer_color = 0x7f05005c;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_stroke_top_inner_color = 0x7f05005d;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_stroke_top_outer_color = 0x7f05005e;

        /* JADX INFO: Added by JADX */
        public static final int design_icon_tint = 0x7f05005f;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background_color = 0x7f050060;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_dark = 0x7f050061;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_disabled_material_light = 0x7f050062;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_dark = 0x7f050063;

        /* JADX INFO: Added by JADX */
        public static final int dim_foreground_material_light = 0x7f050064;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_dark = 0x7f050065;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_light = 0x7f050066;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_dark = 0x7f050067;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_light = 0x7f050068;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_dark = 0x7f050069;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_light = 0x7f05006a;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_overlay_color = 0x7f05006c;

        /* JADX INFO: Added by JADX */
        public static final int m3_assist_chip_icon_tint_color = 0x7f05006d;

        /* JADX INFO: Added by JADX */
        public static final int m3_assist_chip_stroke_color = 0x7f05006e;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle_color = 0x7f05006f;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_background_color_selector = 0x7f050070;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_foreground_color_selector = 0x7f050071;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_outline_color_selector = 0x7f050072;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_ripple_color = 0x7f050073;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_ripple_color_selector = 0x7f050074;

        /* JADX INFO: Added by JADX */
        public static final int m3_calendar_item_disabled_text = 0x7f050075;

        /* JADX INFO: Added by JADX */
        public static final int m3_calendar_item_stroke_color = 0x7f050076;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_foreground_color = 0x7f050077;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_ripple_color = 0x7f050078;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_stroke_color = 0x7f050079;

        /* JADX INFO: Added by JADX */
        public static final int m3_checkbox_button_icon_tint = 0x7f05007a;

        /* JADX INFO: Added by JADX */
        public static final int m3_checkbox_button_tint = 0x7f05007b;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_assist_text_color = 0x7f05007c;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_background_color = 0x7f05007d;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_ripple_color = 0x7f05007e;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_stroke_color = 0x7f05007f;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_text_color = 0x7f050080;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_highlight = 0x7f050081;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_ripple_color_selector = 0x7f050082;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_default_color_primary_text = 0x7f050083;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_default_color_secondary_text = 0x7f050084;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_highlighted_text = 0x7f050085;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_hint_foreground = 0x7f050086;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_primary_text_disable_only = 0x7f050087;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_color_primary_text = 0x7f050088;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_color_secondary_text = 0x7f050089;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_default_color_primary_text = 0x7f05008a;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_default_color_secondary_text = 0x7f05008b;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_highlighted_text = 0x7f05008c;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_hint_foreground = 0x7f05008d;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_primary_text_disable_only = 0x7f05008e;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_default_color_primary_text = 0x7f05008f;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_default_color_secondary_text = 0x7f050090;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_highlighted_text = 0x7f050091;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_hint_foreground = 0x7f050092;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_primary_text_disable_only = 0x7f050093;

        /* JADX INFO: Added by JADX */
        public static final int m3_efab_ripple_color_selector = 0x7f050094;

        /* JADX INFO: Added by JADX */
        public static final int m3_elevated_chip_background_color = 0x7f050095;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_efab_background_color_selector = 0x7f050096;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_efab_foreground_color_selector = 0x7f050097;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_ripple_color_selector = 0x7f050098;

        /* JADX INFO: Added by JADX */
        public static final int m3_filled_icon_button_container_color_selector = 0x7f050099;

        /* JADX INFO: Added by JADX */
        public static final int m3_floating_toolbar_vibrant_icon_button_container_color_selector = 0x7f05009a;

        /* JADX INFO: Added by JADX */
        public static final int m3_floating_toolbar_vibrant_icon_button_text_color_selector = 0x7f05009b;

        /* JADX INFO: Added by JADX */
        public static final int m3_highlighted_text = 0x7f05009c;

        /* JADX INFO: Added by JADX */
        public static final int m3_hint_foreground = 0x7f05009d;

        /* JADX INFO: Added by JADX */
        public static final int m3_icon_button_icon_color_selector = 0x7f05009e;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_highlight = 0x7f05009f;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_background_color_selector = 0x7f0500a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_checkbox_button_tint_selector = 0x7f0500a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_label_text_color_selector = 0x7f0500a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_leading_icon_color_selector = 0x7f0500a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_overline_color_selector = 0x7f0500a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_radio_button_tint_selector = 0x7f0500a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_ripple_color_selector = 0x7f0500a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_supporting_text_color_selector = 0x7f0500a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_switch_track_tint_selector = 0x7f0500a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_trailing_icon_color_selector = 0x7f0500a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_trailing_supporting_text_color_selector = 0x7f0500aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_item_with_indicator_icon_tint = 0x7f0500ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_item_with_indicator_label_tint = 0x7f0500ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_ripple_color_selector = 0x7f0500ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_background_color = 0x7f0500ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_icon_tint = 0x7f0500af;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_ripple_color = 0x7f0500b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_text_color = 0x7f0500b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_with_indicator_icon_tint = 0x7f0500b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_with_indicator_label_tint = 0x7f0500b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_ripple_color_selector = 0x7f0500b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_popupmenu_overlay_color = 0x7f0500b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_primary_text_disable_only = 0x7f0500b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_button_tint = 0x7f0500b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_ripple_tint = 0x7f0500b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_black = 0x7f0500b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue0 = 0x7f0500ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue10 = 0x7f0500bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue100 = 0x7f0500bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue20 = 0x7f0500bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue30 = 0x7f0500be;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue40 = 0x7f0500bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue50 = 0x7f0500c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue60 = 0x7f0500c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue70 = 0x7f0500c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue80 = 0x7f0500c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue90 = 0x7f0500c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue95 = 0x7f0500c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue98 = 0x7f0500c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant0 = 0x7f0500c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant10 = 0x7f0500c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant100 = 0x7f0500c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant20 = 0x7f0500ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant30 = 0x7f0500cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant40 = 0x7f0500cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant50 = 0x7f0500cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant60 = 0x7f0500ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant70 = 0x7f0500cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant80 = 0x7f0500d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant90 = 0x7f0500d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant95 = 0x7f0500d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_blue_variant98 = 0x7f0500d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan0 = 0x7f0500d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan10 = 0x7f0500d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan100 = 0x7f0500d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan20 = 0x7f0500d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan30 = 0x7f0500d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan40 = 0x7f0500d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan50 = 0x7f0500da;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan60 = 0x7f0500db;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan70 = 0x7f0500dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan80 = 0x7f0500dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan90 = 0x7f0500de;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan95 = 0x7f0500df;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_cyan98 = 0x7f0500e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral0 = 0x7f0500e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral10 = 0x7f0500e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral100 = 0x7f0500e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral12 = 0x7f0500e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral17 = 0x7f0500e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral20 = 0x7f0500e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral22 = 0x7f0500e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral24 = 0x7f0500e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral30 = 0x7f0500e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral4 = 0x7f0500ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral40 = 0x7f0500eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral50 = 0x7f0500ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral6 = 0x7f0500ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral60 = 0x7f0500ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral70 = 0x7f0500ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral80 = 0x7f0500f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral87 = 0x7f0500f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral90 = 0x7f0500f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral92 = 0x7f0500f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral94 = 0x7f0500f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral95 = 0x7f0500f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral96 = 0x7f0500f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral98 = 0x7f0500f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral99 = 0x7f0500f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant0 = 0x7f0500f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant10 = 0x7f0500fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant100 = 0x7f0500fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant12 = 0x7f0500fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant17 = 0x7f0500fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant20 = 0x7f0500fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant22 = 0x7f0500ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant24 = 0x7f050100;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant30 = 0x7f050101;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant4 = 0x7f050102;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant40 = 0x7f050103;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant50 = 0x7f050104;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant6 = 0x7f050105;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant60 = 0x7f050106;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant70 = 0x7f050107;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant80 = 0x7f050108;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant87 = 0x7f050109;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant90 = 0x7f05010a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant92 = 0x7f05010b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant94 = 0x7f05010c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant95 = 0x7f05010d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant96 = 0x7f05010e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant98 = 0x7f05010f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant99 = 0x7f050110;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary0 = 0x7f050111;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary10 = 0x7f050112;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary100 = 0x7f050113;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary20 = 0x7f050114;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary30 = 0x7f050115;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary40 = 0x7f050116;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary50 = 0x7f050117;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary60 = 0x7f050118;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary70 = 0x7f050119;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary80 = 0x7f05011a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary90 = 0x7f05011b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary95 = 0x7f05011c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary98 = 0x7f05011d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary99 = 0x7f05011e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary0 = 0x7f05011f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary10 = 0x7f050120;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary100 = 0x7f050121;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary20 = 0x7f050122;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary30 = 0x7f050123;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary40 = 0x7f050124;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary50 = 0x7f050125;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary60 = 0x7f050126;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary70 = 0x7f050127;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary80 = 0x7f050128;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary90 = 0x7f050129;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary95 = 0x7f05012a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary98 = 0x7f05012b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary99 = 0x7f05012c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary0 = 0x7f05012d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary10 = 0x7f05012e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary100 = 0x7f05012f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary20 = 0x7f050130;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary30 = 0x7f050131;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary40 = 0x7f050132;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary50 = 0x7f050133;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary60 = 0x7f050134;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary70 = 0x7f050135;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary80 = 0x7f050136;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary90 = 0x7f050137;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary95 = 0x7f050138;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary98 = 0x7f050139;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary99 = 0x7f05013a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error0 = 0x7f05013b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error10 = 0x7f05013c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error100 = 0x7f05013d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error20 = 0x7f05013e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error30 = 0x7f05013f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error40 = 0x7f050140;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error50 = 0x7f050141;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error60 = 0x7f050142;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error70 = 0x7f050143;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error80 = 0x7f050144;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error90 = 0x7f050145;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error95 = 0x7f050146;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error98 = 0x7f050147;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error99 = 0x7f050148;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green0 = 0x7f050149;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green10 = 0x7f05014a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green100 = 0x7f05014b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green20 = 0x7f05014c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green30 = 0x7f05014d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green40 = 0x7f05014e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green50 = 0x7f05014f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green60 = 0x7f050150;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green70 = 0x7f050151;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green80 = 0x7f050152;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green90 = 0x7f050153;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green95 = 0x7f050154;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_green98 = 0x7f050155;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey0 = 0x7f050156;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey10 = 0x7f050157;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey100 = 0x7f050158;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey20 = 0x7f050159;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey30 = 0x7f05015a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey40 = 0x7f05015b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey50 = 0x7f05015c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey60 = 0x7f05015d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey70 = 0x7f05015e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey80 = 0x7f05015f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey90 = 0x7f050160;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey95 = 0x7f050161;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey98 = 0x7f050162;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant0 = 0x7f050163;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant10 = 0x7f050164;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant100 = 0x7f050165;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant20 = 0x7f050166;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant30 = 0x7f050167;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant40 = 0x7f050168;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant50 = 0x7f050169;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant60 = 0x7f05016a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant70 = 0x7f05016b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant80 = 0x7f05016c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant90 = 0x7f05016d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant95 = 0x7f05016e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_grey_variant98 = 0x7f05016f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral0 = 0x7f050170;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral10 = 0x7f050171;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral100 = 0x7f050172;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral12 = 0x7f050173;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral17 = 0x7f050174;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral20 = 0x7f050175;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral22 = 0x7f050176;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral24 = 0x7f050177;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral30 = 0x7f050178;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral4 = 0x7f050179;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral40 = 0x7f05017a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral50 = 0x7f05017b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral6 = 0x7f05017c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral60 = 0x7f05017d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral70 = 0x7f05017e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral80 = 0x7f05017f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral87 = 0x7f050180;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral90 = 0x7f050181;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral92 = 0x7f050182;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral94 = 0x7f050183;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral95 = 0x7f050184;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral96 = 0x7f050185;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral98 = 0x7f050186;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral99 = 0x7f050187;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant0 = 0x7f050188;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant10 = 0x7f050189;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant100 = 0x7f05018a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant20 = 0x7f05018b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant30 = 0x7f05018c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant40 = 0x7f05018d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant50 = 0x7f05018e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant60 = 0x7f05018f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant70 = 0x7f050190;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant80 = 0x7f050191;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant90 = 0x7f050192;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant95 = 0x7f050193;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant98 = 0x7f050194;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant99 = 0x7f050195;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange0 = 0x7f050196;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange10 = 0x7f050197;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange100 = 0x7f050198;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange20 = 0x7f050199;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange30 = 0x7f05019a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange40 = 0x7f05019b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange50 = 0x7f05019c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange60 = 0x7f05019d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange70 = 0x7f05019e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange80 = 0x7f05019f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange90 = 0x7f0501a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange95 = 0x7f0501a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_orange98 = 0x7f0501a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink0 = 0x7f0501a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink10 = 0x7f0501a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink100 = 0x7f0501a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink20 = 0x7f0501a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink30 = 0x7f0501a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink40 = 0x7f0501a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink50 = 0x7f0501a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink60 = 0x7f0501aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink70 = 0x7f0501ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink80 = 0x7f0501ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink90 = 0x7f0501ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink95 = 0x7f0501ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_pink98 = 0x7f0501af;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary0 = 0x7f0501b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary10 = 0x7f0501b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary100 = 0x7f0501b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary20 = 0x7f0501b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary30 = 0x7f0501b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary40 = 0x7f0501b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary50 = 0x7f0501b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary60 = 0x7f0501b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary70 = 0x7f0501b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary80 = 0x7f0501b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary90 = 0x7f0501ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary95 = 0x7f0501bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary98 = 0x7f0501bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary99 = 0x7f0501bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple0 = 0x7f0501be;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple10 = 0x7f0501bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple100 = 0x7f0501c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple20 = 0x7f0501c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple30 = 0x7f0501c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple40 = 0x7f0501c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple50 = 0x7f0501c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple60 = 0x7f0501c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple70 = 0x7f0501c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple80 = 0x7f0501c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple90 = 0x7f0501c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple95 = 0x7f0501c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_purple98 = 0x7f0501ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red0 = 0x7f0501cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red10 = 0x7f0501cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red100 = 0x7f0501cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red20 = 0x7f0501ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red30 = 0x7f0501cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red40 = 0x7f0501d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red50 = 0x7f0501d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red60 = 0x7f0501d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red70 = 0x7f0501d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red80 = 0x7f0501d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red90 = 0x7f0501d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red95 = 0x7f0501d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_red98 = 0x7f0501d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary0 = 0x7f0501d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary10 = 0x7f0501d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary100 = 0x7f0501da;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary20 = 0x7f0501db;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary30 = 0x7f0501dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary40 = 0x7f0501dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary50 = 0x7f0501de;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary60 = 0x7f0501df;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary70 = 0x7f0501e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary80 = 0x7f0501e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary90 = 0x7f0501e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary95 = 0x7f0501e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary98 = 0x7f0501e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary99 = 0x7f0501e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary0 = 0x7f0501e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary10 = 0x7f0501e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary100 = 0x7f0501e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary20 = 0x7f0501e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary30 = 0x7f0501ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary40 = 0x7f0501eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary50 = 0x7f0501ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary60 = 0x7f0501ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary70 = 0x7f0501ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary80 = 0x7f0501ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary90 = 0x7f0501f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary95 = 0x7f0501f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary98 = 0x7f0501f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary99 = 0x7f0501f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_white = 0x7f0501f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow0 = 0x7f0501f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow10 = 0x7f0501f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow100 = 0x7f0501f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow20 = 0x7f0501f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow30 = 0x7f0501f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow40 = 0x7f0501fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow50 = 0x7f0501fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow60 = 0x7f0501fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow70 = 0x7f0501fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow80 = 0x7f0501fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow90 = 0x7f0501ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow95 = 0x7f050200;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_yellow98 = 0x7f050201;

        /* JADX INFO: Added by JADX */
        public static final int m3_segmented_list_item_background_color_selector = 0x7f050202;

        /* JADX INFO: Added by JADX */
        public static final int m3_selection_control_ripple_color_selector = 0x7f050203;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_ripple_color = 0x7f050204;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_active_tick_marks_color = 0x7f050205;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_active_track_color = 0x7f050206;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_active_track_color_legacy = 0x7f050207;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_halo_color_legacy = 0x7f050208;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_inactive_tick_marks_color = 0x7f050209;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_inactive_track_color = 0x7f05020a;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_inactive_track_color_legacy = 0x7f05020b;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_thumb_color = 0x7f05020c;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_thumb_color_legacy = 0x7f05020d;

        /* JADX INFO: Added by JADX */
        public static final int m3_standard_toolbar_button_text_color_selector = 0x7f05020e;

        /* JADX INFO: Added by JADX */
        public static final int m3_standard_toolbar_icon_button_container_color_selector = 0x7f05020f;

        /* JADX INFO: Added by JADX */
        public static final int m3_standard_toolbar_icon_button_icon_color_selector = 0x7f050210;

        /* JADX INFO: Added by JADX */
        public static final int m3_standard_toolbar_icon_button_ripple_color_selector = 0x7f050211;

        /* JADX INFO: Added by JADX */
        public static final int m3_switch_thumb_tint = 0x7f050212;

        /* JADX INFO: Added by JADX */
        public static final int m3_switch_track_tint = 0x7f050213;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_background = 0x7f050214;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_error = 0x7f050215;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_error_container = 0x7f050216;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_inverse_on_surface = 0x7f050217;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_inverse_primary = 0x7f050218;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_inverse_surface = 0x7f050219;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_background = 0x7f05021a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_error = 0x7f05021b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_error_container = 0x7f05021c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_primary = 0x7f05021d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_primary_container = 0x7f05021e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_secondary = 0x7f05021f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_secondary_container = 0x7f050220;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_surface = 0x7f050221;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_surface_variant = 0x7f050222;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_tertiary = 0x7f050223;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_tertiary_container = 0x7f050224;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_outline = 0x7f050225;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_outline_variant = 0x7f050226;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_primary = 0x7f050227;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_primary_container = 0x7f050228;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_secondary = 0x7f050229;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_secondary_container = 0x7f05022a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface = 0x7f05022b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_bright = 0x7f05022c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_container = 0x7f05022d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_container_high = 0x7f05022e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_container_highest = 0x7f05022f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_container_low = 0x7f050230;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_container_lowest = 0x7f050231;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_dim = 0x7f050232;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_surface_variant = 0x7f050233;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_tertiary = 0x7f050234;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_tertiary_container = 0x7f050235;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_background = 0x7f050236;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_error = 0x7f050237;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_error_container = 0x7f050238;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_inverse_on_surface = 0x7f050239;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_inverse_primary = 0x7f05023a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_inverse_surface = 0x7f05023b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_background = 0x7f05023c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_error = 0x7f05023d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_error_container = 0x7f05023e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_primary = 0x7f05023f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_primary_container = 0x7f050240;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_secondary = 0x7f050241;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_secondary_container = 0x7f050242;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_surface = 0x7f050243;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_surface_variant = 0x7f050244;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_tertiary = 0x7f050245;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_tertiary_container = 0x7f050246;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_outline = 0x7f050247;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_outline_variant = 0x7f050248;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_primary = 0x7f050249;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_primary_container = 0x7f05024a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_secondary = 0x7f05024b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_secondary_container = 0x7f05024c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface = 0x7f05024d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_bright = 0x7f05024e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_container = 0x7f05024f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_container_high = 0x7f050250;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_container_highest = 0x7f050251;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_container_low = 0x7f050252;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_container_lowest = 0x7f050253;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_dim = 0x7f050254;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_surface_variant = 0x7f050255;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_tertiary = 0x7f050256;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_tertiary_container = 0x7f050257;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_background = 0x7f050258;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_error = 0x7f050259;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_error_container = 0x7f05025a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_on_surface = 0x7f05025b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_primary = 0x7f05025c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_surface = 0x7f05025d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_background = 0x7f05025e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_error = 0x7f05025f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_error_container = 0x7f050260;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_primary = 0x7f050261;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_primary_container = 0x7f050262;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_secondary = 0x7f050263;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_secondary_container = 0x7f050264;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_surface = 0x7f050265;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_surface_variant = 0x7f050266;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_tertiary = 0x7f050267;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_tertiary_container = 0x7f050268;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_outline = 0x7f050269;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_outline_variant = 0x7f05026a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_primary = 0x7f05026b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_primary_container = 0x7f05026c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_secondary = 0x7f05026d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_secondary_container = 0x7f05026e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface = 0x7f05026f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_bright = 0x7f050270;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container = 0x7f050271;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_high = 0x7f050272;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_highest = 0x7f050273;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_low = 0x7f050274;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_lowest = 0x7f050275;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_dim = 0x7f050276;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_variant = 0x7f050277;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_tertiary = 0x7f050278;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_tertiary_container = 0x7f050279;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_primary_fixed = 0x7f05027a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_primary_fixed_variant = 0x7f05027b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_secondary_fixed = 0x7f05027c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_secondary_fixed_variant = 0x7f05027d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed = 0x7f05027e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed_variant = 0x7f05027f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_primary_fixed = 0x7f050280;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_primary_fixed_dim = 0x7f050281;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_secondary_fixed = 0x7f050282;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_secondary_fixed_dim = 0x7f050283;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_tertiary_fixed = 0x7f050284;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_tertiary_fixed_dim = 0x7f050285;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_background = 0x7f050286;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_error = 0x7f050287;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_error_container = 0x7f050288;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_on_surface = 0x7f050289;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_primary = 0x7f05028a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_surface = 0x7f05028b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_background = 0x7f05028c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_error = 0x7f05028d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_error_container = 0x7f05028e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_primary = 0x7f05028f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_primary_container = 0x7f050290;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_secondary = 0x7f050291;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_secondary_container = 0x7f050292;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_surface = 0x7f050293;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_surface_variant = 0x7f050294;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_tertiary = 0x7f050295;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_tertiary_container = 0x7f050296;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_outline = 0x7f050297;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_outline_variant = 0x7f050298;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_primary = 0x7f050299;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_primary_container = 0x7f05029a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_secondary = 0x7f05029b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_secondary_container = 0x7f05029c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface = 0x7f05029d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_bright = 0x7f05029e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container = 0x7f05029f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_high = 0x7f0502a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_highest = 0x7f0502a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_low = 0x7f0502a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_lowest = 0x7f0502a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_dim = 0x7f0502a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_variant = 0x7f0502a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_tertiary = 0x7f0502a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_tertiary_container = 0x7f0502a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_primary_fixed = 0x7f0502a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_primary_fixed_variant = 0x7f0502a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_secondary_fixed = 0x7f0502aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_secondary_fixed_variant = 0x7f0502ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_tertiary_fixed = 0x7f0502ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_tertiary_fixed_variant = 0x7f0502ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_primary_fixed = 0x7f0502ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_primary_fixed_dim = 0x7f0502af;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_secondary_fixed = 0x7f0502b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_secondary_fixed_dim = 0x7f0502b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_tertiary_fixed = 0x7f0502b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_tertiary_fixed_dim = 0x7f0502b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_icon_color = 0x7f0502b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_icon_color_secondary = 0x7f0502b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_ripple_color = 0x7f0502b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_ripple_color_secondary = 0x7f0502b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_text_color = 0x7f0502b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_text_color_secondary = 0x7f0502b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_background_color_selector = 0x7f0502ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_foreground_color_selector = 0x7f0502bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_ripple_color_selector = 0x7f0502bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_filled_background_color = 0x7f0502bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_indicator_text_color = 0x7f0502be;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_input_text_color = 0x7f0502bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_label_color = 0x7f0502c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_stroke_color = 0x7f0502c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_background_color = 0x7f0502c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_ripple_color = 0x7f0502c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_text_color = 0x7f0502c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_clock_text_color = 0x7f0502c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_background_color = 0x7f0502c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_ripple_color = 0x7f0502c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_text_color = 0x7f0502c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_secondary_text_button_ripple_color = 0x7f0502c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_secondary_text_button_text_color = 0x7f0502ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_time_input_stroke_color = 0x7f0502cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_tonal_button_ripple_color_selector = 0x7f0502cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_vibrant_toolbar_button_text_color_selector = 0x7f0502cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_vibrant_toolbar_icon_button_container_color_selector = 0x7f0502ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_vibrant_toolbar_icon_button_icon_color_selector = 0x7f0502cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_vibrant_toolbar_icon_button_ripple_color_selector = 0x7f0502d0;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_bottom_nav_item_icon_tint = 0x7f0502d1;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_bottom_nav_item_label_tint = 0x7f0502d2;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_bottom_nav_item_ripple_tint = 0x7f0502d3;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_button_outline_color_selector = 0x7f0502d4;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_button_outlined_background_color_selector = 0x7f0502d5;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_icon_tint = 0x7f0502d6;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_label_tint = 0x7f0502d7;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_ripple_tint = 0x7f0502d8;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_800 = 0x7f0502d9;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_900 = 0x7f0502da;

        /* JADX INFO: Added by JADX */
        public static final int material_blue_grey_950 = 0x7f0502db;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_color = 0x7f0502dc;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_200 = 0x7f0502dd;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_500 = 0x7f0502de;

        /* JADX INFO: Added by JADX */
        public static final int material_divider_color = 0x7f0502df;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_dark_error = 0x7f0502e0;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_dark_error_container = 0x7f0502e1;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_dark_on_error = 0x7f0502e2;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_dark_on_error_container = 0x7f0502e3;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_error = 0x7f0502e4;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_error_container = 0x7f0502e5;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_on_error = 0x7f0502e6;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_on_error_container = 0x7f0502e7;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral0 = 0x7f0502e8;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral10 = 0x7f0502e9;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral100 = 0x7f0502ea;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral20 = 0x7f0502eb;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral30 = 0x7f0502ec;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral40 = 0x7f0502ed;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral50 = 0x7f0502ee;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral60 = 0x7f0502ef;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral70 = 0x7f0502f0;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral80 = 0x7f0502f1;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral90 = 0x7f0502f2;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral95 = 0x7f0502f3;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral99 = 0x7f0502f4;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant0 = 0x7f0502f5;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant10 = 0x7f0502f6;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant100 = 0x7f0502f7;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant20 = 0x7f0502f8;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant30 = 0x7f0502f9;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant40 = 0x7f0502fa;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant50 = 0x7f0502fb;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant60 = 0x7f0502fc;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant70 = 0x7f0502fd;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant80 = 0x7f0502fe;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant90 = 0x7f0502ff;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant95 = 0x7f050300;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_neutral_variant99 = 0x7f050301;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary0 = 0x7f050302;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary10 = 0x7f050303;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary100 = 0x7f050304;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary20 = 0x7f050305;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary30 = 0x7f050306;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary40 = 0x7f050307;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary50 = 0x7f050308;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary60 = 0x7f050309;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary70 = 0x7f05030a;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary80 = 0x7f05030b;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary90 = 0x7f05030c;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary95 = 0x7f05030d;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_primary99 = 0x7f05030e;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary0 = 0x7f05030f;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary10 = 0x7f050310;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary100 = 0x7f050311;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary20 = 0x7f050312;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary30 = 0x7f050313;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary40 = 0x7f050314;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary50 = 0x7f050315;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary60 = 0x7f050316;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary70 = 0x7f050317;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary80 = 0x7f050318;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary90 = 0x7f050319;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary95 = 0x7f05031a;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_secondary99 = 0x7f05031b;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary0 = 0x7f05031c;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary10 = 0x7f05031d;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary100 = 0x7f05031e;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary20 = 0x7f05031f;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary30 = 0x7f050320;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary40 = 0x7f050321;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary50 = 0x7f050322;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary60 = 0x7f050323;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary70 = 0x7f050324;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary80 = 0x7f050325;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary90 = 0x7f050326;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary95 = 0x7f050327;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_tertiary99 = 0x7f050328;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_100 = 0x7f050329;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_300 = 0x7f05032a;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_50 = 0x7f05032b;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_600 = 0x7f05032c;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_800 = 0x7f05032d;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_850 = 0x7f05032e;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_900 = 0x7f05032f;

        /* JADX INFO: Added by JADX */
        public static final int material_harmonized_color_error = 0x7f050330;

        /* JADX INFO: Added by JADX */
        public static final int material_harmonized_color_error_container = 0x7f050331;

        /* JADX INFO: Added by JADX */
        public static final int material_harmonized_color_on_error = 0x7f050332;

        /* JADX INFO: Added by JADX */
        public static final int material_harmonized_color_on_error_container = 0x7f050333;

        /* JADX INFO: Added by JADX */
        public static final int material_on_background_disabled = 0x7f050334;

        /* JADX INFO: Added by JADX */
        public static final int material_on_background_emphasis_high_type = 0x7f050335;

        /* JADX INFO: Added by JADX */
        public static final int material_on_background_emphasis_medium = 0x7f050336;

        /* JADX INFO: Added by JADX */
        public static final int material_on_primary_disabled = 0x7f050337;

        /* JADX INFO: Added by JADX */
        public static final int material_on_primary_emphasis_high_type = 0x7f050338;

        /* JADX INFO: Added by JADX */
        public static final int material_on_primary_emphasis_medium = 0x7f050339;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_disabled = 0x7f05033a;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_emphasis_high_type = 0x7f05033b;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_emphasis_medium = 0x7f05033c;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_stroke = 0x7f05033d;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized__highlighted_text = 0x7f05033e;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized__highlighted_text_inverse = 0x7f05033f;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_background = 0x7f050340;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_activated = 0x7f050341;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_highlight = 0x7f050342;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_normal = 0x7f050343;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_error = 0x7f050344;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_error_container = 0x7f050345;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_background = 0x7f050346;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_error = 0x7f050347;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_error_container = 0x7f050348;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_primary = 0x7f050349;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_primary_container = 0x7f05034a;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_secondary = 0x7f05034b;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_secondary_container = 0x7f05034c;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface = 0x7f05034d;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface_inverse = 0x7f05034e;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface_variant = 0x7f05034f;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_tertiary = 0x7f050350;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_tertiary_container = 0x7f050351;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_outline = 0x7f050352;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_outline_variant = 0x7f050353;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary = 0x7f050354;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_container = 0x7f050355;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_inverse = 0x7f050356;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_text = 0x7f050357;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_text_inverse = 0x7f050358;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary = 0x7f050359;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary_container = 0x7f05035a;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary_text = 0x7f05035b;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary_text_inverse = 0x7f05035c;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface = 0x7f05035d;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_bright = 0x7f05035e;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container = 0x7f05035f;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_high = 0x7f050360;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_highest = 0x7f050361;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_low = 0x7f050362;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_lowest = 0x7f050363;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_dim = 0x7f050364;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_inverse = 0x7f050365;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_variant = 0x7f050366;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_tertiary = 0x7f050367;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_tertiary_container = 0x7f050368;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_hint_foreground_inverse = 0x7f050369;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_primary_inverse = 0x7f05036a;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_primary_inverse_disable_only = 0x7f05036b;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse = 0x7f05036c;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse_disabled = 0x7f05036d;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_hint_foreground = 0x7f05036e;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_hint_foreground_inverse = 0x7f05036f;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_primary_inverse_text_disable_only = 0x7f050370;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_primary_text_disable_only = 0x7f050371;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_active_tick_marks_color = 0x7f050372;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_active_track_color = 0x7f050373;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_halo_color = 0x7f050374;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_inactive_tick_marks_color = 0x7f050375;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_inactive_track_color = 0x7f050376;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_thumb_color = 0x7f050377;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_button_background = 0x7f050378;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_button_stroke = 0x7f050379;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clock_text_color = 0x7f05037a;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clockface = 0x7f05037b;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_modebutton_tint = 0x7f05037c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_bg_color_selector = 0x7f05037d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_ripple_color = 0x7f05037e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_stroke_color_selector = 0x7f05037f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_bg_color_selector = 0x7f050380;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_ripple_color = 0x7f050381;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_color_disabled = 0x7f050382;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_color_selector = 0x7f050383;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_transparent_bg_color = 0x7f050384;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_item_stroke_color = 0x7f050385;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selected_range = 0x7f050386;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_view_foreground = 0x7f050387;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_view_ripple = 0x7f050388;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_background_color = 0x7f050389;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_close_icon_tint = 0x7f05038a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_surface_color = 0x7f05038b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_text_color = 0x7f05038c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_background_color = 0x7f05038d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_ripple_color = 0x7f05038e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_text_color = 0x7f05038f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_error = 0x7f050390;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_bg_color_selector = 0x7f050391;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_icon_text_color_selector = 0x7f050392;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_ripple_color = 0x7f050393;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_background_color = 0x7f050394;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_icon_tint = 0x7f050395;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_stroke_color = 0x7f050396;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_indicator_text_color = 0x7f050397;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_colored_item_tint = 0x7f050398;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_colored_ripple_color = 0x7f050399;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_tint = 0x7f05039a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_ripple_color = 0x7f05039b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_background_color = 0x7f05039c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_tint = 0x7f05039d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_text_color = 0x7f05039e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_on_primary_text_btn_text_color_selector = 0x7f05039f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_on_surface_ripple_color = 0x7f0503a0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_outlined_icon_tint = 0x7f0503a1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_outlined_stroke_color = 0x7f0503a2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_overlay_color = 0x7f0503a3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_scrim_color = 0x7f0503a4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_icon_tint = 0x7f0503a5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_tint = 0x7f0503a6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration_tint = 0x7f0503a7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_tint = 0x7f0503a8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_colored_ripple_color = 0x7f0503a9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_icon_color_selector = 0x7f0503aa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_icon_color_selector_colored = 0x7f0503ab;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_legacy_text_color_selector = 0x7f0503ac;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_ripple_color = 0x7f0503ad;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_text_btn_text_color_selector = 0x7f0503ae;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_default_box_stroke_color = 0x7f0503af;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_disabled_color = 0x7f0503b0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_filled_box_default_background_color = 0x7f0503b1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_focused_box_stroke_color = 0x7f0503b2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_hovered_box_stroke_color = 0x7f0503b3;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 0x7f0503b4;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 0x7f0503b5;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_dark = 0x7f0503b6;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_light = 0x7f0503b7;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_dark = 0x7f0503b8;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_light = 0x7f0503b9;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_dark = 0x7f0503ba;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_light = 0x7f0503bb;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_dark = 0x7f0503bc;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_light = 0x7f0503bd;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_dark = 0x7f0503c1;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_light = 0x7f0503c2;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_dark = 0x7f0503c3;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_light = 0x7f0503c4;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_dark = 0x7f0503c5;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_light = 0x7f0503c6;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_dark = 0x7f0503c7;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_light = 0x7f0503c8;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_dark = 0x7f0503c9;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_light = 0x7f0503ca;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_dark = 0x7f0503cb;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_light = 0x7f0503cc;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_dark = 0x7f0503cf;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_light = 0x7f0503d0;

        private color() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_material = 0x7f060000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 0x7f060001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_height_material = 0x7f060002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 0x7f060003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 0x7f060004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_elevation_material = 0x7f060005;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 0x7f060006;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 0x7f060007;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 0x7f060008;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_max_height = 0x7f060009;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f06000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f06000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f06000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_height_material = 0x7f06000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_material = 0x7f06000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 0x7f06000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 0x7f060010;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_dimen = 0x7f060011;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_horizontal_material = 0x7f060012;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_vertical_material = 0x7f060013;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_horizontal_material = 0x7f060014;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_vertical_material = 0x7f060015;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 0x7f060016;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_prefDialogWidth = 0x7f060017;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_corner_material = 0x7f060018;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_inset_material = 0x7f060019;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_padding_material = 0x7f06001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_corner_radius_material = 0x7f06001b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_major = 0x7f06001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_minor = 0x7f06001d;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_major = 0x7f06001e;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_minor = 0x7f06001f;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 0x7f060020;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 0x7f060021;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_major = 0x7f060022;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_minor = 0x7f060023;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_material = 0x7f060024;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_top_material = 0x7f060025;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_divider_material = 0x7f060026;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_dark = 0x7f060027;

        /* JADX INFO: Added by JADX */
        public static final int abc_disabled_alpha_material_light = 0x7f060028;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_icon_width = 0x7f060029;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 0x7f06002a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 0x7f06002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 0x7f06002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 0x7f06002d;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_top_material = 0x7f06002e;

        /* JADX INFO: Added by JADX */
        public static final int abc_floating_window_z = 0x7f06002f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_large_material = 0x7f060030;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_material = 0x7f060031;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_small_material = 0x7f060032;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 0x7f060033;

        /* JADX INFO: Added by JADX */
        public static final int abc_panel_menu_list_width = 0x7f060034;

        /* JADX INFO: Added by JADX */
        public static final int abc_progress_bar_height_material = 0x7f060035;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_height = 0x7f060036;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_width = 0x7f060037;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_background_height_material = 0x7f060038;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 0x7f060039;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_padding_start_material = 0x7f06003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_big = 0x7f06003b;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_medium = 0x7f06003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_small = 0x7f06003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_padding = 0x7f06003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_1_material = 0x7f06003f;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_body_2_material = 0x7f060040;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_button_material = 0x7f060041;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_caption_material = 0x7f060042;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_1_material = 0x7f060043;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_2_material = 0x7f060044;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_3_material = 0x7f060045;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_display_4_material = 0x7f060046;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_headline_material = 0x7f060047;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_large_material = 0x7f060048;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_medium_material = 0x7f060049;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_header_material = 0x7f06004a;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_material = 0x7f06004b;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_small_material = 0x7f06004c;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subhead_material = 0x7f06004d;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 0x7f06004e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material = 0x7f06004f;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_title_material_toolbar = 0x7f060050;

        /* JADX INFO: Added by JADX */
        public static final int appcompat_dialog_background_inset = 0x7f060051;

        /* JADX INFO: Added by JADX */
        public static final int cardview_compat_inset_shadow = 0x7f060052;

        /* JADX INFO: Added by JADX */
        public static final int cardview_default_elevation = 0x7f060053;

        /* JADX INFO: Added by JADX */
        public static final int cardview_default_radius = 0x7f060054;

        /* JADX INFO: Added by JADX */
        public static final int clock_face_margin_start = 0x7f060055;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 0x7f060056;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 0x7f060057;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 0x7f060058;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 0x7f060059;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 0x7f06005a;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 0x7f06005b;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 0x7f06005c;

        /* JADX INFO: Added by JADX */
        public static final int def_drawer_elevation = 0x7f06005d;

        /* JADX INFO: Added by JADX */
        public static final int default_navigation_active_text_size = 0x7f06005e;

        /* JADX INFO: Added by JADX */
        public static final int default_navigation_text_size = 0x7f06005f;

        /* JADX INFO: Added by JADX */
        public static final int design_appbar_elevation = 0x7f060060;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_item_max_width = 0x7f060061;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_item_min_width = 0x7f060062;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_text_size = 0x7f060063;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_elevation = 0x7f060064;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_height = 0x7f060065;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_icon_size = 0x7f060066;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item_max_width = 0x7f060067;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item_min_width = 0x7f060068;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_label_padding = 0x7f060069;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_margin = 0x7f06006a;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_shadow_height = 0x7f06006b;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_text_size = 0x7f06006c;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_elevation = 0x7f06006d;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_modal_elevation = 0x7f06006e;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_peek_height_min = 0x7f06006f;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_border_width = 0x7f060070;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_elevation = 0x7f060071;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_image_size = 0x7f060072;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_size_mini = 0x7f060073;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_size_normal = 0x7f060074;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_translation_z_hovered_focused = 0x7f060075;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_translation_z_pressed = 0x7f060076;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_elevation = 0x7f060077;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_icon_padding = 0x7f060078;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_icon_size = 0x7f060079;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_horizontal_padding = 0x7f06007a;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_icon_padding = 0x7f06007b;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_vertical_padding = 0x7f06007c;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_max_width = 0x7f06007d;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_padding_bottom = 0x7f06007e;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_separator_vertical_padding = 0x7f06007f;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_action_inline_max_width = 0x7f060080;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_action_text_color_alpha = 0x7f060081;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background_corner_radius = 0x7f060082;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_elevation = 0x7f060083;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_extra_spacing_horizontal = 0x7f060084;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_max_width = 0x7f060085;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_min_width = 0x7f060086;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_horizontal = 0x7f060087;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_vertical = 0x7f060088;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_vertical_2lines = 0x7f060089;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_text_size = 0x7f06008a;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_max_width = 0x7f06008b;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_scrollable_min_width = 0x7f06008c;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_text_size = 0x7f06008d;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_text_size_2line = 0x7f06008e;

        /* JADX INFO: Added by JADX */
        public static final int design_textinput_caption_translate_y = 0x7f06008f;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_dark = 0x7f060090;

        /* JADX INFO: Added by JADX */
        public static final int disabled_alpha_material_light = 0x7f060091;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_default_thickness = 0x7f060092;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_margin = 0x7f060093;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_minimum_range = 0x7f060094;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_colored = 0x7f060095;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_dark = 0x7f060096;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_light = 0x7f060097;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_dark = 0x7f060098;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_light = 0x7f060099;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_dark = 0x7f06009a;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_light = 0x7f06009b;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f06009c;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_max_velocity = 0x7f06009d;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_velocity = 0x7f06009e;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_action_bottom_padding = 0x7f06009f;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_action_top_padding = 0x7f0600a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_corner_size = 0x7f0600a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_elevation = 0x7f0600a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_icon_margin = 0x7f0600a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_icon_size = 0x7f0600a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_title_bottom_margin = 0x7f0600a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_expanded_title_margin_bottom = 0x7f0600a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_expanded_title_margin_horizontal = 0x7f0600a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger = 0x7f0600a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger_large = 0x7f0600a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger_medium = 0x7f0600aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_compact = 0x7f0600ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_large = 0x7f0600ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_large_with_subtitle = 0x7f0600ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_medium = 0x7f0600ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_medium_with_subtitle = 0x7f0600af;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_bottom_container_max_scale_x_distance = 0x7f0600b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_bottom_container_max_scale_y_distance = 0x7f0600b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_main_container_max_translation_y = 0x7f0600b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_main_container_min_edge_gap = 0x7f0600b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_x_distance_grow = 0x7f0600b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_x_distance_shrink = 0x7f0600b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_y_distance = 0x7f0600b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_horizontal_offset = 0x7f0600b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_offset = 0x7f0600b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_size = 0x7f0600b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_vertical_offset = 0x7f0600ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_horizontal_offset = 0x7f0600bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_offset = 0x7f0600bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_size = 0x7f0600bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_vertical_offset = 0x7f0600be;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_vertical_padding = 0x7f0600bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_height = 0x7f0600c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_margin_horizontal = 0x7f0600c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_width = 0x7f0600c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_expanded_active_indicator_height = 0x7f0600c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_padding_bottom = 0x7f0600c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_padding_top = 0x7f0600c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_min_height = 0x7f0600c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle_bottom_padding = 0x7f0600c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_elevation = 0x7f0600c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_modal_elevation = 0x7f0600c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_margin = 0x7f0600ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f0600cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_vertical_offset = 0x7f0600cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_end_margin = 0x7f0600cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_height = 0x7f0600ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_horizontal_padding = 0x7f0600cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_dialog_btn_min_width = 0x7f0600d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_dialog_btn_spacing = 0x7f0600d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_disabled_elevation = 0x7f0600d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_disabled_translation_z = 0x7f0600d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_elevated_translation_z_hovered = 0x7f0600d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_elevation = 0x7f0600d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_group_overflow_item_icon_horizontal_padding = 0x7f0600d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_btn_padding_left = 0x7f0600d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_btn_padding_right = 0x7f0600d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_default_padding = 0x7f0600d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_default_size = 0x7f0600da;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_icon_padding = 0x7f0600db;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_min_width = 0x7f0600dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_inset = 0x7f0600dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_max_width = 0x7f0600de;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_bottom = 0x7f0600df;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_left = 0x7f0600e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_right = 0x7f0600e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_top = 0x7f0600e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_stroke_size = 0x7f0600e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_icon_padding_left = 0x7f0600e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_icon_padding_right = 0x7f0600e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_padding_left = 0x7f0600e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_padding_right = 0x7f0600e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_translation_z_base = 0x7f0600e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_translation_z_hovered = 0x7f0600e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_disabled_z = 0x7f0600ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_dragged_z = 0x7f0600eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_disabled_z = 0x7f0600ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_dragged_z = 0x7f0600ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_elevation = 0x7f0600ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_hovered_z = 0x7f0600ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevation = 0x7f0600f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_hovered_z = 0x7f0600f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_stroke_width = 0x7f0600f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_debug_keyline_width = 0x7f0600f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_extra_small_item_size = 0x7f0600f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_gone_size = 0x7f0600f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_small_item_default_corner_size = 0x7f0600f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_small_item_size_max = 0x7f0600f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_small_item_size_min = 0x7f0600f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_checked_hovered_translation_z = 0x7f0600f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_corner_size = 0x7f0600fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_disabled_translation_z = 0x7f0600fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_dragged_translation_z = 0x7f0600fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_elevated_elevation = 0x7f0600fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_hovered_translation_z = 0x7f0600fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_icon_size = 0x7f0600ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_container_elevation = 0x7f060100;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_large_container_height = 0x7f060101;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_large_flexible_container_height = 0x7f060102;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_medium_container_height = 0x7f060103;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_medium_flexible_container_height = 0x7f060104;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_on_scroll_container_elevation = 0x7f060105;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_search_leading_space = 0x7f060106;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_search_trailing_space = 0x7f060107;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_small_container_height = 0x7f060108;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_app_bar_small_search_container_height = 0x7f060109;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_container_height = 0x7f06010a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_elevated_container_elevation = 0x7f06010b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_flat_container_elevation = 0x7f06010c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_flat_outline_width = 0x7f06010d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_with_icon_icon_size = 0x7f06010e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_badge_large_size = 0x7f06010f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_badge_size = 0x7f060110;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_bottom_app_bar_container_elevation = 0x7f060111;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_bottom_app_bar_container_height = 0x7f060112;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_elevated_container_elevation = 0x7f060113;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_elevated_disabled_container_elevation = 0x7f060114;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_filled_container_elevation = 0x7f060115;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_filled_disabled_container_elevation = 0x7f060116;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_group_connected_small_between_space = 0x7f060117;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_group_standard_small_between_space = 0x7f060118;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_large_icon_label_space = 0x7f060119;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_large_icon_size = 0x7f06011a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_large_leading_space = 0x7f06011b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_large_outlined_outline_width = 0x7f06011c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_large_trailing_space = 0x7f06011d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_medium_icon_label_space = 0x7f06011e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_medium_icon_size = 0x7f06011f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_medium_leading_space = 0x7f060120;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_medium_outlined_outline_width = 0x7f060121;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_medium_trailing_space = 0x7f060122;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_outlined_focused_state_layer_opacity = 0x7f060123;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_outlined_hovered_state_layer_opacity = 0x7f060124;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_outlined_pressed_state_layer_opacity = 0x7f060125;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_small_icon_label_space = 0x7f060126;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_small_icon_size = 0x7f060127;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_small_leading_space = 0x7f060128;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_small_outlined_outline_width = 0x7f060129;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_small_trailing_space = 0x7f06012a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_text_focused_state_layer_opacity = 0x7f06012b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_text_hovered_state_layer_opacity = 0x7f06012c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_text_pressed_state_layer_opacity = 0x7f06012d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_tonal_container_elevation = 0x7f06012e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xlarge_icon_label_space = 0x7f06012f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xlarge_icon_size = 0x7f060130;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xlarge_leading_space = 0x7f060131;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xlarge_outlined_outline_width = 0x7f060132;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xlarge_trailing_space = 0x7f060133;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xsmall_icon_label_space = 0x7f060134;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xsmall_icon_size = 0x7f060135;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xsmall_leading_space = 0x7f060136;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xsmall_outlined_outline_width = 0x7f060137;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_button_xsmall_trailing_space = 0x7f060138;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_checkbox_selected_disabled_container_opacity = 0x7f060139;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_date_today_container_outline_width = 0x7f06013a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_header_container_height = 0x7f06013b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_range_selection_header_container_height = 0x7f06013c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_divider_thickness = 0x7f06013d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_elevated_card_container_elevation = 0x7f06013e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_elevated_card_icon_size = 0x7f06013f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_large_container_height = 0x7f060140;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_large_icon_label_space = 0x7f060141;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_large_icon_size = 0x7f060142;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_large_leading_space = 0x7f060143;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_large_trailing_space = 0x7f060144;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_medium_container_height = 0x7f060145;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_medium_icon_label_space = 0x7f060146;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_medium_icon_size = 0x7f060147;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_medium_leading_space = 0x7f060148;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_medium_trailing_space = 0x7f060149;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_container_elevation = 0x7f06014a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_focused_container_elevation = 0x7f06014b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_focused_state_layer_opacity = 0x7f06014c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_hovered_container_elevation = 0x7f06014d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_hovered_state_layer_opacity = 0x7f06014e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_pressed_container_elevation = 0x7f06014f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_pressed_state_layer_opacity = 0x7f060150;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_small_container_height = 0x7f060151;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_small_icon_label_space = 0x7f060152;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_small_icon_size = 0x7f060153;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_small_leading_space = 0x7f060154;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_small_trailing_space = 0x7f060155;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_container_height = 0x7f060156;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_icon_size = 0x7f060157;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_large_container_height = 0x7f060158;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_large_icon_size = 0x7f060159;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_medium_container_height = 0x7f06015a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_medium_icon_size = 0x7f06015b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_container_elevation = 0x7f06015c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_focused_container_elevation = 0x7f06015d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_focused_state_layer_opacity = 0x7f06015e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_hovered_container_elevation = 0x7f06015f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_hovered_state_layer_opacity = 0x7f060160;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_pressed_container_elevation = 0x7f060161;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_pressed_state_layer_opacity = 0x7f060162;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_small_container_height = 0x7f060163;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_small_icon_size = 0x7f060164;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_autocomplete_menu_container_elevation = 0x7f060165;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_container_elevation = 0x7f060166;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_dragged_state_layer_opacity = 0x7f060167;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_focus_state_layer_opacity = 0x7f060168;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_hover_state_layer_opacity = 0x7f060169;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_icon_size = 0x7f06016a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_pressed_state_layer_opacity = 0x7f06016b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_text_field_disabled_active_indicator_opacity = 0x7f06016c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filter_chip_container_height = 0x7f06016d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filter_chip_elevated_container_elevation = 0x7f06016e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filter_chip_flat_container_elevation = 0x7f06016f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filter_chip_flat_unselected_outline_width = 0x7f060170;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filter_chip_with_icon_icon_size = 0x7f060171;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_default_leading_space = 0x7f060172;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_default_trailing_space = 0x7f060173;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_icon_size = 0x7f060174;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_narrow_leading_space = 0x7f060175;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_narrow_trailing_space = 0x7f060176;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_outlined_outline_width = 0x7f060177;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_wide_leading_space = 0x7f060178;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_large_wide_trailing_space = 0x7f060179;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_default_leading_space = 0x7f06017a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_default_trailing_space = 0x7f06017b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_icon_size = 0x7f06017c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_narrow_leading_space = 0x7f06017d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_narrow_trailing_space = 0x7f06017e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_outlined_outline_width = 0x7f06017f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_wide_leading_space = 0x7f060180;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_medium_wide_trailing_space = 0x7f060181;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_default_leading_space = 0x7f060182;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_default_trailing_space = 0x7f060183;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_icon_size = 0x7f060184;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_narrow_leading_space = 0x7f060185;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_narrow_trailing_space = 0x7f060186;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_outlined_outline_width = 0x7f060187;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_wide_leading_space = 0x7f060188;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_small_wide_trailing_space = 0x7f060189;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_default_leading_space = 0x7f06018a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_default_trailing_space = 0x7f06018b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_icon_size = 0x7f06018c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_narrow_leading_space = 0x7f06018d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_narrow_trailing_space = 0x7f06018e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_outlined_outline_width = 0x7f06018f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_wide_leading_space = 0x7f060190;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xlarge_wide_trailing_space = 0x7f060191;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_default_leading_space = 0x7f060192;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_default_trailing_space = 0x7f060193;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_icon_size = 0x7f060194;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_narrow_leading_space = 0x7f060195;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_narrow_trailing_space = 0x7f060196;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_outlined_outline_width = 0x7f060197;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_wide_leading_space = 0x7f060198;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_icon_button_xsmall_wide_trailing_space = 0x7f060199;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_container_elevation = 0x7f06019a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_container_height = 0x7f06019b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_unselected_outline_width = 0x7f06019c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_with_avatar_avatar_size = 0x7f06019d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_with_leading_icon_leading_icon_size = 0x7f06019e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_bottom_space = 0x7f06019f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_container_elevation = 0x7f0601a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_label_text_opacity = 0x7f0601a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_leading_icon_opacity = 0x7f0601a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_overline_opacity = 0x7f0601a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_state_layer_opacity = 0x7f0601a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_supporting_text_opacity = 0x7f0601a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_disabled_trailing_icon_opacity = 0x7f0601a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_focus_state_layer_opacity = 0x7f0601a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_hover_state_layer_opacity = 0x7f0601a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_leading_space = 0x7f0601a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_pressed_state_layer_opacity = 0x7f0601aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_container_opacity = 0x7f0601ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_label_text_opacity = 0x7f0601ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_leading_icon_opacity = 0x7f0601ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_overline_opacity = 0x7f0601ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_state_layer_opacity = 0x7f0601af;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_supporting_text_opacity = 0x7f0601b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_trailing_icon_opacity = 0x7f0601b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_disabled_trailing_supporting_text_opacity = 0x7f0601b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_focus_state_layer_opacity = 0x7f0601b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_hover_state_layer_opacity = 0x7f0601b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_selected_pressed_state_layer_opacity = 0x7f0601b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_top_space = 0x7f0601b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_list_list_item_trailing_space = 0x7f0601b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_loading_indicator_container_height = 0x7f0601b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_loading_indicator_container_width = 0x7f0601b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_menu_container_elevation = 0x7f0601ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_container_elevation = 0x7f0601bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_container_height = 0x7f0601bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_active_indicator_icon_label_space = 0x7f0601bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_horizontal_active_indicator_height = 0x7f0601be;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_icon_size = 0x7f0601bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_vertical_active_indicator_height = 0x7f0601c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_vertical_active_indicator_width = 0x7f0601c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_bar_item_vertical_container_between_space = 0x7f0601c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_collapsed_container_elevation = 0x7f0601c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_collapsed_container_width = 0x7f0601c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_collapsed_item_vertical_space = 0x7f0601c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_collapsed_narrow_container_width = 0x7f0601c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_collapsed_top_space = 0x7f0601c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_expanded_container_width_maximum = 0x7f0601c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_expanded_container_width_minimum = 0x7f0601c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_active_focused_state_layer_opacity = 0x7f0601ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_active_hovered_state_layer_opacity = 0x7f0601cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_active_pressed_state_layer_opacity = 0x7f0601cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_container_height = 0x7f0601cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_container_vertical_space = 0x7f0601ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_header_space_minimum = 0x7f0601cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_horizontal_active_indicator_height = 0x7f0601d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_horizontal_full_width_leading_space = 0x7f0601d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_horizontal_full_width_trailing_space = 0x7f0601d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_horizontal_icon_label_space = 0x7f0601d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_icon_size = 0x7f0601d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_short_container_height = 0x7f0601d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_vertical_active_indicator_height = 0x7f0601d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_vertical_active_indicator_width = 0x7f0601d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_vertical_icon_label_space = 0x7f0601d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_vertical_leading_space = 0x7f0601d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_nav_rail_item_vertical_trailing_space = 0x7f0601da;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_container_width = 0x7f0601db;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_focus_state_layer_opacity = 0x7f0601dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_hover_state_layer_opacity = 0x7f0601dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_icon_size = 0x7f0601de;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_modal_container_elevation = 0x7f0601df;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_pressed_state_layer_opacity = 0x7f0601e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_standard_container_elevation = 0x7f0601e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_autocomplete_menu_container_elevation = 0x7f0601e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_container_elevation = 0x7f0601e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_disabled_outline_opacity = 0x7f0601e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_icon_size = 0x7f0601e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_outline_width = 0x7f0601e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_input_text_opacity = 0x7f0601e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_label_text_opacity = 0x7f0601e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_supporting_text_opacity = 0x7f0601e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_focus_outline_width = 0x7f0601ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_outline_width = 0x7f0601eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_focus_state_layer_opacity = 0x7f0601ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_hover_state_layer_opacity = 0x7f0601ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_indicator_height = 0x7f0601ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_pressed_state_layer_opacity = 0x7f0601ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_focus_state_layer_opacity = 0x7f0601f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_hover_state_layer_opacity = 0x7f0601f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_pressed_state_layer_opacity = 0x7f0601f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_with_icon_icon_size = 0x7f0601f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_active_indicator_wave_amplitude = 0x7f0601f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_active_indicator_wave_wavelength = 0x7f0601f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_size = 0x7f0601f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_track_active_indicator_space = 0x7f0601f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_track_thickness = 0x7f0601f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_circular_with_wave_size = 0x7f0601f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_active_indicator_wave_amplitude = 0x7f0601fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_active_indicator_wave_wavelength = 0x7f0601fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_indeterminate_active_indicator_wave_wavelength = 0x7f0601fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_stop_indicator_size = 0x7f0601fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_track_active_indicator_space = 0x7f0601fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_linear_track_thickness = 0x7f0601ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_disabled_selected_icon_opacity = 0x7f060200;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_disabled_unselected_icon_opacity = 0x7f060201;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_focus_state_layer_opacity = 0x7f060202;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_hover_state_layer_opacity = 0x7f060203;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_pressed_state_layer_opacity = 0x7f060204;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_focus_state_layer_opacity = 0x7f060205;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_hover_state_layer_opacity = 0x7f060206;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_pressed_state_layer_opacity = 0x7f060207;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_scrim_container_opacity = 0x7f060208;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_avatar_size = 0x7f060209;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_avatar_target_size = 0x7f06020a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_icon_label_gap = 0x7f06020b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_leading_margin = 0x7f06020c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_leading_space = 0x7f06020d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_no_actions_leading_space = 0x7f06020e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_no_actions_trailing_space = 0x7f06020f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_trailing_actions_gap = 0x7f060210;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_trailing_actions_leading_space = 0x7f060211;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_trailing_actions_trailing_space = 0x7f060212;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_trailing_margin = 0x7f060213;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_contained_trailing_space = 0x7f060214;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_container_elevation = 0x7f060215;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_container_height = 0x7f060216;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_hover_state_layer_opacity = 0x7f060217;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_icon_size = 0x7f060218;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_leading_icon_leading_icon_label_space = 0x7f060219;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_leading_space = 0x7f06021a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_pressed_state_layer_opacity = 0x7f06021b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_trailing_icon_label_trailing_icon_space = 0x7f06021c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_trailing_space = 0x7f06021d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_contained_docked_bar_results_gap = 0x7f06021e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_contained_full_screen_bar_container_height = 0x7f06021f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_contained_icon_label_gap = 0x7f060220;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_contained_leading_margin = 0x7f060221;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_contained_trailing_margin = 0x7f060222;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_container_elevation = 0x7f060223;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_docked_header_container_height = 0x7f060224;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_full_screen_header_container_height = 0x7f060225;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_leading_icon_leading_icon_label_space = 0x7f060226;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_leading_space = 0x7f060227;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_trailing_icon_label_trailing_icon_space = 0x7f060228;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_trailing_space = 0x7f060229;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_active_indicator_height = 0x7f06022a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_focus_state_layer_opacity = 0x7f06022b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_hover_state_layer_opacity = 0x7f06022c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_pressed_state_layer_opacity = 0x7f06022d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_height = 0x7f06022e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_width = 0x7f06022f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_modal_container_elevation = 0x7f060230;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_standard_container_elevation = 0x7f060231;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_container_width = 0x7f060232;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_modal_container_elevation = 0x7f060233;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_standard_container_elevation = 0x7f060234;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_height = 0x7f060235;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_leading_space = 0x7f060236;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_width = 0x7f060237;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_stop_indicator_container_opacity = 0x7f060238;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_active_track_opacity = 0x7f060239;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_handle_opacity = 0x7f06023a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_inactive_track_opacity = 0x7f06023b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_inactive_stop_indicator_container_opacity = 0x7f06023c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_inactive_track_height = 0x7f06023d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_large_active_handle_height = 0x7f06023e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_large_active_track_height = 0x7f06023f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_large_active_track_shape_leading = 0x7f060240;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_large_icon_size = 0x7f060241;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_medium_active_handle_height = 0x7f060242;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_medium_active_track_height = 0x7f060243;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_medium_active_track_shape_leading = 0x7f060244;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_medium_icon_size = 0x7f060245;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_small_active_handle_height = 0x7f060246;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_small_active_track_height = 0x7f060247;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_small_active_track_shape_leading = 0x7f060248;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_stop_indicator_size = 0x7f060249;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_value_indicator_active_bottom_space = 0x7f06024a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xlarge_active_handle_height = 0x7f06024b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xlarge_active_track_height = 0x7f06024c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xlarge_active_track_shape_leading = 0x7f06024d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xlarge_icon_size = 0x7f06024e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xsmall_active_handle_height = 0x7f06024f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xsmall_active_track_height = 0x7f060250;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_xsmall_active_track_shape_leading = 0x7f060251;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_snackbar_container_elevation = 0x7f060252;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_large_leading_button_leading_space = 0x7f060253;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_large_leading_button_trailing_space = 0x7f060254;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_large_trailing_button_icon_size = 0x7f060255;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_large_trailing_button_leading_space = 0x7f060256;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_large_trailing_button_trailing_space = 0x7f060257;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_medium_leading_button_leading_space = 0x7f060258;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_medium_leading_button_trailing_space = 0x7f060259;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_medium_trailing_button_icon_size = 0x7f06025a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_medium_trailing_button_leading_space = 0x7f06025b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_medium_trailing_button_trailing_space = 0x7f06025c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_small_leading_button_leading_space = 0x7f06025d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_small_leading_button_trailing_space = 0x7f06025e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_small_trailing_button_icon_size = 0x7f06025f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_small_trailing_button_leading_space = 0x7f060260;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_small_trailing_button_trailing_space = 0x7f060261;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xlarge_leading_button_leading_space = 0x7f060262;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xlarge_leading_button_trailing_space = 0x7f060263;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xlarge_trailing_button_icon_size = 0x7f060264;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xlarge_trailing_button_leading_space = 0x7f060265;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xlarge_trailing_button_trailing_space = 0x7f060266;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xsmall_leading_button_leading_space = 0x7f060267;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xsmall_leading_button_trailing_space = 0x7f060268;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xsmall_trailing_button_icon_size = 0x7f060269;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xsmall_trailing_button_leading_space = 0x7f06026a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_split_button_xsmall_trailing_button_trailing_space = 0x7f06026b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_suggestion_chip_container_height = 0x7f06026c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_suggestion_chip_elevated_container_elevation = 0x7f06026d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_suggestion_chip_flat_container_elevation = 0x7f06026e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_suggestion_chip_flat_outline_width = 0x7f06026f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_suggestion_chip_with_leading_icon_leading_icon_size = 0x7f060270;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_selected_handle_opacity = 0x7f060271;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_selected_icon_opacity = 0x7f060272;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_track_opacity = 0x7f060273;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_unselected_handle_opacity = 0x7f060274;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_unselected_icon_opacity = 0x7f060275;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_selected_focus_state_layer_opacity = 0x7f060276;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_selected_hover_state_layer_opacity = 0x7f060277;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_selected_pressed_state_layer_opacity = 0x7f060278;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_track_height = 0x7f060279;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_track_width = 0x7f06027a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_unselected_focus_state_layer_opacity = 0x7f06027b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_unselected_hover_state_layer_opacity = 0x7f06027c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_unselected_pressed_state_layer_opacity = 0x7f06027d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_input_time_input_field_focus_outline_width = 0x7f06027e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_container_elevation = 0x7f06027f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_focus_state_layer_opacity = 0x7f060280;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_hover_state_layer_opacity = 0x7f060281;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_outline_width = 0x7f060282;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_pressed_state_layer_opacity = 0x7f060283;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_focus_state_layer_opacity = 0x7f060284;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_hover_state_layer_opacity = 0x7f060285;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_pressed_state_layer_opacity = 0x7f060286;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_docked_container_height = 0x7f060287;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_docked_container_leading_space = 0x7f060288;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_docked_container_trailing_space = 0x7f060289;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_floating_container_elevation = 0x7f06028a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_floating_container_leading_space = 0x7f06028b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_floating_container_trailing_space = 0x7f06028c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_floating_horizontal_container_height = 0x7f06028d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_floating_vertical_container_width = 0x7f06028e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_standard_disabled_icon_opacity = 0x7f06028f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_standard_disabled_label_text_opacity = 0x7f060290;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_vibrant_disabled_icon_opacity = 0x7f060291;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_toolbar_vibrant_disabled_label_text_opacity = 0x7f060292;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_ripple_color_selector_default_alpha = 0x7f060293;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_ripple_color_selector_focused_alpha = 0x7f060294;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_ripple_color_selector_hovered_alpha = 0x7f060295;

        /* JADX INFO: Added by JADX */
        public static final int m3_control_ripple_color_selector_pressed_alpha = 0x7f060296;

        /* JADX INFO: Added by JADX */
        public static final int m3_datepicker_elevation = 0x7f060297;

        /* JADX INFO: Added by JADX */
        public static final int m3_divider_heavy_thickness = 0x7f060298;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_bottom_padding = 0x7f060299;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_disabled_elevation = 0x7f06029a;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_disabled_translation_z = 0x7f06029b;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_end_padding = 0x7f06029c;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_icon_padding = 0x7f06029d;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_min_height = 0x7f06029e;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_start_padding = 0x7f06029f;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_top_padding = 0x7f0602a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_translation_z_base = 0x7f0602a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_translation_z_focused = 0x7f0602a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_translation_z_hovered = 0x7f0602a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_translation_z_pressed = 0x7f0602a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_border_width = 0x7f0602a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_corner_size = 0x7f0602a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_disabled_elevation = 0x7f0602a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_disabled_translation_z = 0x7f0602a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_translation_z_base = 0x7f0602a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_translation_z_focused = 0x7f0602aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_translation_z_hovered = 0x7f0602ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_translation_z_pressed = 0x7f0602ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_floatingtoolbar_min_height = 0x7f0602ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_floatingtoolbar_min_width = 0x7f0602ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_large_fab_max_image_size = 0x7f0602af;

        /* JADX INFO: Added by JADX */
        public static final int m3_large_fab_size = 0x7f0602b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_large_text_vertical_offset_adjustment = 0x7f0602b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_max_swipe_overshoot = 0x7f0602b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_reveal_min_child_width = 0x7f0602b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_loading_indicator_container_size = 0x7f0602b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_loading_indicator_shape_size = 0x7f0602b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_menu_elevation = 0x7f0602b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_multiline_hint_filled_text_extra_space = 0x7f0602b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_nav_badge_with_text_vertical_offset = 0x7f0602b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_content_horizontal_margin = 0x7f0602b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_divider_bottom_margin = 0x7f0602ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_divider_top_margin = 0x7f0602bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_drawer_layout_corner_size = 0x7f0602bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_active_indicator_label_padding = 0x7f0602bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_expanded_active_indicator_height_default = 0x7f0602be;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_horizontal_padding = 0x7f0602bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_icon_padding = 0x7f0602c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_leading_trailing_space = 0x7f0602c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_bottom = 0x7f0602c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_end = 0x7f0602c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_start = 0x7f0602c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_top = 0x7f0602c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_vertical_padding = 0x7f0602c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_divider_horizontal_padding = 0x7f0602c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_headline_horizontal_padding = 0x7f0602c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_default_width = 0x7f0602c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_elevation = 0x7f0602ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_expanded_active_indicator_height = 0x7f0602cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_expanded_item_spacing = 0x7f0602cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_expanded_leading_trailing_space = 0x7f0602cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_icon_label_horizontal_padding = 0x7f0602ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_icon_label_padding = 0x7f0602cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_icon_size = 0x7f0602d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_height = 0x7f0602d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_margin_horizontal = 0x7f0602d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_width = 0x7f0602d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_min_height = 0x7f0602d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_bottom = 0x7f0602d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_bottom_with_large_font = 0x7f0602d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_top = 0x7f0602d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_top_with_large_font = 0x7f0602d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_label_padding_horizontal = 0x7f0602d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_max_expanded_width = 0x7f0602da;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_min_expanded_width = 0x7f0602db;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_subheader_horizontal_padding = 0x7f0602dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_subheader_top_margin = 0x7f0602dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_subheader_vertical_padding = 0x7f0602de;

        /* JADX INFO: Added by JADX */
        public static final int m3_overflow_item_icon_horizontal_padding = 0x7f0602df;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_default_alpha = 0x7f0602e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_focused_alpha = 0x7f0602e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_hovered_alpha = 0x7f0602e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_pressed_alpha = 0x7f0602e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_selectable_pressed_alpha = 0x7f0602e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_elevation = 0x7f0602e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_height = 0x7f0602e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_margin_horizontal = 0x7f0602e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_margin_vertical = 0x7f0602e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_outlined_stroke_width = 0x7f0602e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_padding_start = 0x7f0602ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_parent_width_breakpoint = 0x7f0602eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_text_margin_start_no_navigation_icon = 0x7f0602ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_text_size = 0x7f0602ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchview_divider_size = 0x7f0602ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchview_elevation = 0x7f0602ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchview_height = 0x7f0602f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_margin_detached = 0x7f0602f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_modal_elevation = 0x7f0602f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_standard_elevation = 0x7f0602f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_width = 0x7f0602f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_color_hovered_alpha = 0x7f0602f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_color_selected_alpha = 0x7f0602f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_focus_ring_padding = 0x7f0602f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_focus_ring_thumb_height_decrease = 0x7f0602f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_thumb_elevation = 0x7f0602f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_track_icon_padding = 0x7f0602fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_small_fab_max_image_size = 0x7f0602fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_small_fab_size = 0x7f0602fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_snackbar_action_text_color_alpha = 0x7f0602fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_snackbar_margin = 0x7f0602fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level0 = 0x7f0602ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level1 = 0x7f060300;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level2 = 0x7f060301;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level3 = 0x7f060302;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level4 = 0x7f060303;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level5 = 0x7f060304;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x1 = 0x7f060305;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x2 = 0x7f060306;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y1 = 0x7f060307;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y2 = 0x7f060308;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x1 = 0x7f060309;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x2 = 0x7f06030a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y1 = 0x7f06030b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y2 = 0x7f06030c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_x1 = 0x7f06030d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_x2 = 0x7f06030e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_y1 = 0x7f06030f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_y2 = 0x7f060310;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_control_x1 = 0x7f060311;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_control_x2 = 0x7f060312;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_control_y1 = 0x7f060313;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_control_y2 = 0x7f060314;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_x1 = 0x7f060315;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_x2 = 0x7f060316;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_y1 = 0x7f060317;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_y2 = 0x7f060318;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_x1 = 0x7f060319;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_x2 = 0x7f06031a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_y1 = 0x7f06031b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_y2 = 0x7f06031c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x1 = 0x7f06031d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x2 = 0x7f06031e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y1 = 0x7f06031f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y2 = 0x7f060320;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_x1 = 0x7f060321;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_x2 = 0x7f060322;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_y1 = 0x7f060323;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_y2 = 0x7f060324;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x1 = 0x7f060325;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x2 = 0x7f060326;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y1 = 0x7f060327;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y2 = 0x7f060328;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_default_effects_damping = 0x7f060329;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_default_effects_stiffness = 0x7f06032a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_default_spatial_damping = 0x7f06032b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_default_spatial_stiffness = 0x7f06032c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_fast_effects_damping = 0x7f06032d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_fast_effects_stiffness = 0x7f06032e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_fast_spatial_damping = 0x7f06032f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_fast_spatial_stiffness = 0x7f060330;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_slow_effects_damping = 0x7f060331;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_slow_effects_stiffness = 0x7f060332;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_slow_spatial_damping = 0x7f060333;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_expressive_spring_slow_spatial_stiffness = 0x7f060334;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_default_effects_damping = 0x7f060335;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_default_effects_stiffness = 0x7f060336;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_default_spatial_damping = 0x7f060337;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_default_spatial_stiffness = 0x7f060338;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_fast_effects_damping = 0x7f060339;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_fast_effects_stiffness = 0x7f06033a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_fast_spatial_damping = 0x7f06033b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_fast_spatial_stiffness = 0x7f06033c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_slow_effects_damping = 0x7f06033d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_slow_effects_stiffness = 0x7f06033e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_slow_spatial_damping = 0x7f06033f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_standard_spring_slow_spatial_stiffness = 0x7f060340;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_extra_extra_large = 0x7f060341;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_extra_large = 0x7f060342;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_extra_large_increased = 0x7f060343;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_extra_small = 0x7f060344;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_large = 0x7f060345;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_large_increased = 0x7f060346;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_medium = 0x7f060347;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_none = 0x7f060348;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_value_small = 0x7f060349;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_disabled_state_layer_opacity = 0x7f06034a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_dragged_state_layer_opacity = 0x7f06034b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_focus_state_layer_opacity = 0x7f06034c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_hover_state_layer_opacity = 0x7f06034d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_pressed_state_layer_opacity = 0x7f06034e;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_stroke_width = 0x7f06034f;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_window_elevation = 0x7f060350;

        /* JADX INFO: Added by JADX */
        public static final int m3_toolbar_button_circle_size = 0x7f060351;

        /* JADX INFO: Added by JADX */
        public static final int m3_toolbar_text_size_title = 0x7f060352;

        /* JADX INFO: Added by JADX */
        public static final int m3e_searchview_appbarwithsearch_toolbar_height = 0x7f060353;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_alert_dialog_bottom_padding = 0x7f060354;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_alert_dialog_top_padding = 0x7f060355;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_btn_min_height = 0x7f060356;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_btn_min_width = 0x7f060357;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_content_margin_top = 0x7f060358;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_header_items_margin = 0x7f060359;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_leading_trailing_padding = 0x7f06035a;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_min_height = 0x7f06035b;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_spacing = 0x7f06035c;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_item_vertical_padding = 0x7f06035d;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_nav_rail_min_width = 0x7f06035e;

        /* JADX INFO: Added by JADX */
        public static final int material_bottom_sheet_max_width = 0x7f06035f;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_height = 0x7f060360;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_padding = 0x7f060361;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_width = 0x7f060362;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face_margin_bottom = 0x7f060363;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face_margin_top = 0x7f060364;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_center_dot_radius = 0x7f060365;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_padding = 0x7f060366;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_stroke_width = 0x7f060367;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_number_text_size = 0x7f060368;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_height = 0x7f060369;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_horizontal_gap = 0x7f06036a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_vertical_gap = 0x7f06036b;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_width = 0x7f06036c;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_size = 0x7f06036d;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_inset = 0x7f06036e;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_width = 0x7f06036f;

        /* JADX INFO: Added by JADX */
        public static final int material_divider_thickness = 0x7f060370;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_disabled = 0x7f060371;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_disabled_background = 0x7f060372;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_high_type = 0x7f060373;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_medium = 0x7f060374;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_1_3_padding_bottom = 0x7f060375;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_1_3_padding_top = 0x7f060376;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_2_0_padding_bottom = 0x7f060377;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_2_0_padding_top = 0x7f060378;

        /* JADX INFO: Added by JADX */
        public static final int material_font_1_3_box_collapsed_padding_top = 0x7f060379;

        /* JADX INFO: Added by JADX */
        public static final int material_font_2_0_box_collapsed_padding_top = 0x7f06037a;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_default_padding_top = 0x7f06037b;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_font_1_3_padding_horizontal = 0x7f06037c;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_font_1_3_padding_top = 0x7f06037d;

        /* JADX INFO: Added by JADX */
        public static final int material_input_text_to_prefix_suffix_padding = 0x7f06037e;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_default_width = 0x7f06037f;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_max_width = 0x7f060380;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_min_width = 0x7f060381;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_min_width_with_label = 0x7f060382;

        /* JADX INFO: Added by JADX */
        public static final int material_time_picker_minimum_screen_height = 0x7f060383;

        /* JADX INFO: Added by JADX */
        public static final int material_time_picker_minimum_screen_width = 0x7f060384;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_bottom = 0x7f060385;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_end = 0x7f060386;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_start = 0x7f060387;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_top = 0x7f060388;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_picker_background_inset = 0x7f060389;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_horizontal_edge_offset = 0x7f06038a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_long_text_horizontal_padding = 0x7f06038b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_size = 0x7f06038c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_text_horizontal_edge_offset = 0x7f06038d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_text_size = 0x7f06038e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_toolbar_action_menu_item_horizontal_offset = 0x7f06038f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_toolbar_action_menu_item_vertical_offset = 0x7f060390;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_with_text_size = 0x7f060391;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fabOffsetEndMode = 0x7f060392;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_bottom_margin = 0x7f060393;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_margin = 0x7f060394;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f060395;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_vertical_offset = 0x7f060396;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_height = 0x7f060397;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_corner_radius = 0x7f060398;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_dialog_btn_min_width = 0x7f060399;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_disabled_elevation = 0x7f06039a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_disabled_z = 0x7f06039b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_elevation = 0x7f06039c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_focused_z = 0x7f06039d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_hovered_z = 0x7f06039e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_icon_btn_padding_left = 0x7f06039f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_icon_padding = 0x7f0603a0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_inset = 0x7f0603a1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_letter_spacing = 0x7f0603a2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_max_width = 0x7f0603a3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_bottom = 0x7f0603a4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_left = 0x7f0603a5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_right = 0x7f0603a6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_top = 0x7f0603a7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_pressed_z = 0x7f0603a8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_snackbar_margin_horizontal = 0x7f0603a9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_stroke_size = 0x7f0603aa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_icon_padding = 0x7f0603ab;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_padding_left = 0x7f0603ac;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_padding_right = 0x7f0603ad;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_size = 0x7f0603ae;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_z = 0x7f0603af;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_confirm_button_min_width = 0x7f0603b0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_height = 0x7f0603b1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_padding = 0x7f0603b2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_bottom_padding = 0x7f0603b3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_content_padding = 0x7f0603b4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_corner = 0x7f0603b5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_height = 0x7f0603b6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_horizontal_padding = 0x7f0603b7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_today_stroke = 0x7f0603b8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_vertical_padding = 0x7f0603b9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_width = 0x7f0603ba;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week_height = 0x7f0603bb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_dialog_background_inset = 0x7f0603bc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_content_padding = 0x7f0603bd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_content_padding_fullscreen = 0x7f0603be;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_divider_thickness = 0x7f0603bf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_height = 0x7f0603c0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_height_fullscreen = 0x7f0603c1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_selection_line_height = 0x7f0603c2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_text_padding = 0x7f0603c3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_toggle_margin_bottom = 0x7f0603c4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_toggle_margin_top = 0x7f0603c5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_landscape_header_width = 0x7f0603c6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_maximum_default_fullscreen_minor_axis = 0x7f0603c7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_horizontal_padding = 0x7f0603c8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_vertical_padding = 0x7f0603c9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_bottom_padding = 0x7f0603ca;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_height = 0x7f0603cb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_top_padding = 0x7f0603cc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_baseline_to_top_fullscreen = 0x7f0603cd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_baseline_to_bottom = 0x7f0603ce;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_baseline_to_bottom_fullscreen = 0x7f0603cf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_baseline_to_top = 0x7f0603d0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_text_input_padding_top = 0x7f0603d1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_title_baseline_to_top = 0x7f0603d2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_title_baseline_to_top_fullscreen = 0x7f0603d3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_corner = 0x7f0603d4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_height = 0x7f0603d5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_horizontal_padding = 0x7f0603d6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_vertical_padding = 0x7f0603d7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_width = 0x7f0603d8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_icon_margin = 0x7f0603d9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_icon_size = 0x7f0603da;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_corner_radius = 0x7f0603db;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_dragged_z = 0x7f0603dc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_elevation = 0x7f0603dd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_spacing = 0x7f0603de;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_pressed_translation_z = 0x7f0603df;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_text_size = 0x7f0603e0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_elevation = 0x7f0603e1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_offset = 0x7f0603e2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_padding = 0x7f0603e3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_bottom_padding = 0x7f0603e4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_disabled_elevation = 0x7f0603e5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_disabled_translation_z = 0x7f0603e6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_elevation = 0x7f0603e7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_end_padding = 0x7f0603e8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_end_padding_icon = 0x7f0603e9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_icon_size = 0x7f0603ea;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_icon_text_spacing = 0x7f0603eb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_min_height = 0x7f0603ec;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_min_width = 0x7f0603ed;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_start_padding = 0x7f0603ee;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_start_padding_icon = 0x7f0603ef;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_top_padding = 0x7f0603f0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_base = 0x7f0603f1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_hovered_focused = 0x7f0603f2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_pressed = 0x7f0603f3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_elevation = 0x7f0603f4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_min_touch_target = 0x7f0603f5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_translation_z_hovered_focused = 0x7f0603f6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_translation_z_pressed = 0x7f0603f7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_focus_ring_inner_stroke_inset = 0x7f0603f8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_focus_ring_inner_stroke_width = 0x7f0603f9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_focus_ring_outer_stroke_width = 0x7f0603fa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_default_alpha = 0x7f0603fb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_focused_alpha = 0x7f0603fc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_hovered_alpha = 0x7f0603fd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_pressed_alpha = 0x7f0603fe;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_default_alpha = 0x7f0603ff;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_focused_alpha = 0x7f060400;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_hovered_alpha = 0x7f060401;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_pressed_alpha = 0x7f060402;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_min_touch_target_size = 0x7f060403;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_default_icon_size = 0x7f060404;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_default_margin = 0x7f060405;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_elevation = 0x7f060406;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_horizontal_padding = 0x7f060407;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_padding = 0x7f060408;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_size = 0x7f060409;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_shape_horizontal_margin = 0x7f06040a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_shape_vertical_margin = 0x7f06040b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_active_text_size = 0x7f06040c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_compact_width = 0x7f06040d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_default_width = 0x7f06040e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_elevation = 0x7f06040f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_icon_margin = 0x7f060410;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_icon_size = 0x7f060411;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_margin = 0x7f060412;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_text_bottom_margin = 0x7f060413;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_text_size = 0x7f060414;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_inset = 0x7f060415;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_inset_extra_small = 0x7f060416;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_inset_medium = 0x7f060417;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_inset_small = 0x7f060418;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_radius = 0x7f060419;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_size = 0x7f06041a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_size_extra_small = 0x7f06041b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_size_medium = 0x7f06041c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_size_small = 0x7f06041d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_track_thickness_extra_small = 0x7f06041e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_track_thickness_medium = 0x7f06041f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_track_thickness_small = 0x7f060420;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_indicator_full_rounded_corner_radius = 0x7f060421;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_track_thickness = 0x7f060422;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_large_component = 0x7f060423;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_medium_component = 0x7f060424;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_small_component = 0x7f060425;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_halo_radius = 0x7f060426;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_label_padding = 0x7f060427;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_label_radius = 0x7f060428;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_label_square_side = 0x7f060429;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_thumb_elevation = 0x7f06042a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_thumb_radius = 0x7f06042b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_tick_min_spacing = 0x7f06042c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_tick_radius = 0x7f06042d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_track_height = 0x7f06042e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_track_side_padding = 0x7f06042f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_widget_height = 0x7f060430;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_action_text_color_alpha = 0x7f060431;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_background_corner_radius = 0x7f060432;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_background_overlay_color_alpha = 0x7f060433;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_margin = 0x7f060434;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_message_margin_horizontal = 0x7f060435;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_padding_horizontal = 0x7f060436;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_text_padding = 0x7f060437;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_elevation = 0x7f060438;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_icon_size = 0x7f060439;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_size = 0x7f06043a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_height = 0x7f06043b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_width = 0x7f06043c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_corner_radius_medium = 0x7f06043d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_corner_radius_small = 0x7f06043e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_label_cutout_padding = 0x7f06043f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_stroke_width_default = 0x7f060440;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_stroke_width_focused = 0x7f060441;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_counter_margin_start = 0x7f060442;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_end_icon_margin_start = 0x7f060443;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_outline_box_expanded_padding = 0x7f060444;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_start_icon_margin_end = 0x7f060445;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_toolbar_default_height = 0x7f060446;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_arrowSize = 0x7f060447;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_cornerSize = 0x7f060448;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_minHeight = 0x7f060449;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_minWidth = 0x7f06044a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_padding = 0x7f06044b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_transition_shared_axis_slide_distance = 0x7f06044c;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 0x7f06044d;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 0x7f06044e;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 0x7f06044f;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 0x7f060450;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 0x7f060451;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 0x7f060452;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 0x7f060453;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 0x7f060454;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 0x7f060455;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 0x7f060456;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 0x7f060457;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 0x7f060458;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 0x7f060459;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 0x7f06045a;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 0x7f06045b;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_corner_radius = 0x7f06045c;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_horizontal_padding = 0x7f06045d;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_margin = 0x7f06045e;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 0x7f06045f;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_threshold = 0x7f060460;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_vertical_padding = 0x7f060461;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_non_touch = 0x7f060462;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_touch = 0x7f060463;
    }

    public static final class drawable {
        public static final int abc1 = 0x7f070029;
        public static final int ic_launcher_background = 0x7f0700a9;
        public static final int ic_launcher_foreground = 0x7f0700aa;

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__0_res_0x7f070000 = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__1_res_0x7f070001 = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__2_res_0x7f070002 = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__0_res_0x7f070003 = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__1_res_0x7f070004 = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__2_res_0x7f070005 = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int _ic_launcher_foreground__0_res_0x7f070006 = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__0_res_0x7f070007 = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__1_res_0x7f070008 = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__2_res_0x7f070009 = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__0_res_0x7f07000a = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__1_res_0x7f07000b = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__2_res_0x7f07000c = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__0_res_0x7f07000d = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__1_res_0x7f07000e = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__2_res_0x7f07000f = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_indeterminate__0_res_0x7f070010 = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__0_res_0x7f070011 = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__1_res_0x7f070012 = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__2_res_0x7f070013 = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_checked__0_res_0x7f070014 = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__0_res_0x7f070015 = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__1_res_0x7f070016 = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__2_res_0x7f070017 = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__0_res_0x7f070018 = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__1_res_0x7f070019 = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__2_res_0x7f07001a = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__0_res_0x7f07001b = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__1_res_0x7f07001c = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__2_res_0x7f07001d = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__0_res_0x7f07001e = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__1_res_0x7f07001f = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__2_res_0x7f070020 = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_pressed__0_res_0x7f070021 = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_unchecked__0_res_0x7f070022 = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_unchecked__1_res_0x7f070023 = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_pressed_checked__0_res_0x7f070024 = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_pressed_unchecked__0_res_0x7f070025 = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_checked__0_res_0x7f070026 = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_checked__1_res_0x7f070027 = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_pressed__0_res_0x7f070028 = 0x7f070028;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_item_background_material = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_borderless_material = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material = 0x7f07002d;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material_anim = 0x7f07002e;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_material = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_default_mtrl_shape = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material = 0x7f070033;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material_anim = 0x7f070034;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_internal_bg = 0x7f070039;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_material = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_background_material = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_material_background = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_material = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_ab_back_material = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 0x7f070040;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_clear_material = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_go_search_api_material = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f070044;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_overflow_material = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_search_api_material = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_voice_search_api_material = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_dark = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_light = 0x7f07004d;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_material = 0x7f07004e;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f070054;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 0x7f070055;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_dark = 0x7f070058;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_light = 0x7f070059;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_indicator_material = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_material = 0x7f07005d;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_small_material = 0x7f07005e;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_thumb_material = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_tick_mark_material = 0x7f070065;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_material = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_textfield_background_material = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_black_48dp = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_half_black_48dp = 0x7f07006a;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_thumb_material = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_material = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_cursor_material = 0x7f07006f;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_material = 0x7f070077;

        /* JADX INFO: Added by JADX */
        public static final int abc_vector_test = 0x7f070078;

        /* JADX INFO: Added by JADX */
        public static final int avd_hide_password = 0x7f070079;

        /* JADX INFO: Added by JADX */
        public static final int avd_show_password = 0x7f07007a;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl = 0x7f07007b;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 0x7f07007c;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 0x7f07007d;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 0x7f07007e;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_mtrl = 0x7f07007f;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 0x7f070080;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_mtrl = 0x7f070081;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 0x7f070082;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark = 0x7f070084;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_focused = 0x7f070085;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_normal = 0x7f070086;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_disabled = 0x7f070088;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light = 0x7f070089;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_focused = 0x7f07008a;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_normal = 0x7f07008b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f07008d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f07008e;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_normal = 0x7f07008f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_disabled = 0x7f070091;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f070092;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f070093;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_normal = 0x7f070094;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_background = 0x7f070096;

        /* JADX INFO: Added by JADX */
        public static final int design_ic_visibility = 0x7f070097;

        /* JADX INFO: Added by JADX */
        public static final int design_ic_visibility_off = 0x7f070098;

        /* JADX INFO: Added by JADX */
        public static final int design_password_eye = 0x7f070099;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background = 0x7f07009a;

        /* JADX INFO: Added by JADX */
        public static final int ic_arrow_back_black_24 = 0x7f07009d;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer = 0x7f07009e;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_low = 0x7f07009f;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video = 0x7f0700a0;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video_low = 0x7f0700a1;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 0x7f0700a2;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline_low = 0x7f0700a3;

        /* JADX INFO: Added by JADX */
        public static final int ic_clear_black_24 = 0x7f0700a4;

        /* JADX INFO: Added by JADX */
        public static final int ic_clock_black_24dp = 0x7f0700a5;

        /* JADX INFO: Added by JADX */
        public static final int ic_expand_less_22px = 0x7f0700a6;

        /* JADX INFO: Added by JADX */
        public static final int ic_expand_more_22px = 0x7f0700a7;

        /* JADX INFO: Added by JADX */
        public static final int ic_keyboard_black_24dp = 0x7f0700a8;

        /* JADX INFO: Added by JADX */
        public static final int ic_m3_chip_check = 0x7f0700ab;

        /* JADX INFO: Added by JADX */
        public static final int ic_m3_chip_checked_circle = 0x7f0700ac;

        /* JADX INFO: Added by JADX */
        public static final int ic_m3_chip_close = 0x7f0700ad;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_arrow_circle = 0x7f0700ae;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_checked_circle = 0x7f0700af;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_checked_black = 0x7f0700b0;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_checked_circle = 0x7f0700b1;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_close_circle = 0x7f0700b2;

        /* JADX INFO: Added by JADX */
        public static final int ic_search_black_24 = 0x7f0700b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_action_bar_item_background = 0x7f0700b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_avd_hide_password = 0x7f0700b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_avd_show_password = 0x7f0700b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle = 0x7f0700b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_action_bar_item_background = 0x7f0700b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_control_background = 0x7f0700b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_item_background = 0x7f0700ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_item_background_borderless = 0x7f0700bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_list_selector_background = 0x7f0700bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_action_bar_item_background = 0x7f0700bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_control_background = 0x7f0700be;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_framework_button_background = 0x7f0700bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_framework_button_background_borderless = 0x7f0700c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_framework_button_background_shape = 0x7f0700c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_framework_checkbox_background = 0x7f0700c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_item_background = 0x7f0700c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_item_background_borderless = 0x7f0700c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_list_selector_background = 0x7f0700c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_toolbar_action_bar_item_background = 0x7f0700c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_toolbar_selectable_item_background = 0x7f0700c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_focus_ring_toolbar_selectable_item_background_borderless = 0x7f0700c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ic_check_24px = 0x7f0700c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_overflow_item_checkbox = 0x7f0700ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_password_eye = 0x7f0700cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_popupmenu_background_overlay = 0x7f0700cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_ripple = 0x7f0700cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_selectable_item_background = 0x7f0700ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_selectable_item_background_borderless = 0x7f0700cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_selection_control_ripple = 0x7f0700d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_split_button_chevron_avd = 0x7f0700d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_background = 0x7f0700d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_line_indicator = 0x7f0700d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_rounded_line_indicator = 0x7f0700d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_transparent_background = 0x7f0700d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_toolbar_navigation_circle_background = 0x7f0700d6;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_drawable = 0x7f0700d7;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_calendar_black_24dp = 0x7f0700d8;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_clear_black_24dp = 0x7f0700d9;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_edit_black_24dp = 0x7f0700da;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_left_black_24dp = 0x7f0700db;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_next_black_24dp = 0x7f0700dc;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_previous_black_24dp = 0x7f0700dd;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_right_black_24dp = 0x7f0700de;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_menu_arrow_down_black_24dp = 0x7f0700df;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_menu_arrow_up_black_24dp = 0x7f0700e0;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_arch = 0x7f0700e1;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_arrow = 0x7f0700e2;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_boom = 0x7f0700e3;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_bun = 0x7f0700e4;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_burst = 0x7f0700e5;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_circle = 0x7f0700e6;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_clover_4 = 0x7f0700e7;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_clover_8 = 0x7f0700e8;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_cookie_12 = 0x7f0700e9;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_cookie_4 = 0x7f0700ea;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_cookie_6 = 0x7f0700eb;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_cookie_7 = 0x7f0700ec;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_cookie_9 = 0x7f0700ed;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_diamond = 0x7f0700ee;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_fan = 0x7f0700ef;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_flower = 0x7f0700f0;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_gem = 0x7f0700f1;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_ghostish = 0x7f0700f2;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_heart = 0x7f0700f3;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_hexagon = 0x7f0700f4;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_oval = 0x7f0700f5;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_pentagon = 0x7f0700f6;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_pill = 0x7f0700f7;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_pixel_circle = 0x7f0700f8;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_pixel_triangle = 0x7f0700f9;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_puffy = 0x7f0700fa;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_puffy_diamond = 0x7f0700fb;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_semicircle = 0x7f0700fc;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_slanted_square = 0x7f0700fd;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_soft_boom = 0x7f0700fe;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_soft_burst = 0x7f0700ff;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_square = 0x7f070100;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_sunny = 0x7f070101;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_triangle = 0x7f070102;

        /* JADX INFO: Added by JADX */
        public static final int material_shape_very_sunny = 0x7f070103;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomsheet_drag_handle = 0x7f070104;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button = 0x7f070105;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_checked_unchecked = 0x7f070106;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon = 0x7f070107;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_checked_indeterminate = 0x7f070108;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_checked_unchecked = 0x7f070109;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_indeterminate_checked = 0x7f07010a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_indeterminate_unchecked = 0x7f07010b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_unchecked_checked = 0x7f07010c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_unchecked_indeterminate = 0x7f07010d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_unchecked_checked = 0x7f07010e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_close_24px = 0x7f07010f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_dialog_background = 0x7f070110;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_dropdown_arrow = 0x7f070111;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_arrow_drop_down = 0x7f070112;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_arrow_drop_up = 0x7f070113;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_cancel = 0x7f070114;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_check_mark = 0x7f070115;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_checkbox_checked = 0x7f070116;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_checkbox_unchecked = 0x7f070117;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_error = 0x7f070118;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_indeterminate = 0x7f070119;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_background = 0x7f07011a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_background = 0x7f07011b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_background_overlay = 0x7f07011c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb = 0x7f07011d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked = 0x7f07011e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked_pressed = 0x7f07011f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked_unchecked = 0x7f070120;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed = 0x7f070121;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_checked = 0x7f070122;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_unchecked = 0x7f070123;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked = 0x7f070124;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked_checked = 0x7f070125;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked_pressed = 0x7f070126;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track = 0x7f070127;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration = 0x7f070128;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_default_indicator = 0x7f070129;

        /* JADX INFO: Added by JADX */
        public static final int navigation_empty_icon = 0x7f07012a;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 0x7f07012b;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 0x7f07012c;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 0x7f07012d;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 0x7f070132;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 0x7f070133;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 0x7f070134;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 0x7f070135;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 0x7f070136;

        /* JADX INFO: Added by JADX */
        public static final int test_level_drawable = 0x7f070138;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_dark = 0x7f070139;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_light = 0x7f07013a;

        private drawable() {
        }
    }

    public static final class id {
        public static final int image = 0x7f0800ec;

        /* JADX INFO: Added by JADX */
        public static final int ALT = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int BOTTOM_END = 0x7f080001;

        /* JADX INFO: Added by JADX */
        public static final int BOTTOM_START = 0x7f080002;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 0x7f080003;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 0x7f080004;

        /* JADX INFO: Added by JADX */
        public static final int META = 0x7f080005;

        /* JADX INFO: Added by JADX */
        public static final int NO_DEBUG = 0x7f080006;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 0x7f080007;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_ALL = 0x7f080008;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PATH = 0x7f080009;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PROGRESS = 0x7f08000a;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 0x7f08000b;

        /* JADX INFO: Added by JADX */
        public static final int TOP_END = 0x7f08000c;

        /* JADX INFO: Added by JADX */
        public static final int TOP_START = 0x7f08000d;

        /* JADX INFO: Added by JADX */
        public static final int above = 0x7f08000e;

        /* JADX INFO: Added by JADX */
        public static final int accelerate = 0x7f08000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f080010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f080011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f080012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f080013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f080014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f080015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f080016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f080017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f080018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f080019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f08001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f08001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f08001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f08001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f08001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f08001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f080020;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f080021;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f080022;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f080023;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f080024;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f080025;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f080026;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f080027;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f080028;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f080029;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f08002a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f08002b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f08002c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f08002d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f08002e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f08002f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f080030;

        /* JADX INFO: Added by JADX */
        public static final int actionDown = 0x7f080031;

        /* JADX INFO: Added by JADX */
        public static final int actionDownUp = 0x7f080032;

        /* JADX INFO: Added by JADX */
        public static final int actionUp = 0x7f080033;

        /* JADX INFO: Added by JADX */
        public static final int action_bar = 0x7f080034;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_activity_content = 0x7f080035;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_container = 0x7f080036;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_root = 0x7f080037;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_spinner = 0x7f080038;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_subtitle = 0x7f080039;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_title = 0x7f08003a;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f08003b;

        /* JADX INFO: Added by JADX */
        public static final int action_context_bar = 0x7f08003c;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f08003d;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f08003e;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_divider = 0x7f08003f;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_presenter = 0x7f080040;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar = 0x7f080041;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar_stub = 0x7f080042;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_close_button = 0x7f080043;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f080044;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f080045;

        /* JADX INFO: Added by JADX */
        public static final int activity_chooser_view_content = 0x7f080046;

        /* JADX INFO: Added by JADX */
        public static final int add = 0x7f080047;

        /* JADX INFO: Added by JADX */
        public static final int adjust_height = 0x7f080048;

        /* JADX INFO: Added by JADX */
        public static final int adjust_width = 0x7f080049;

        /* JADX INFO: Added by JADX */
        public static final int advance = 0x7f08004a;

        /* JADX INFO: Added by JADX */
        public static final int alertTitle = 0x7f08004b;

        /* JADX INFO: Added by JADX */
        public static final int aligned = 0x7f08004c;

        /* JADX INFO: Added by JADX */
        public static final int all = 0x7f08004d;

        /* JADX INFO: Added by JADX */
        public static final int allStates = 0x7f08004e;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f08004f;

        /* JADX INFO: Added by JADX */
        public static final int animateToEnd = 0x7f080050;

        /* JADX INFO: Added by JADX */
        public static final int animateToStart = 0x7f080051;

        /* JADX INFO: Added by JADX */
        public static final int antiClockwise = 0x7f080052;

        /* JADX INFO: Added by JADX */
        public static final int anticipate = 0x7f080053;

        /* JADX INFO: Added by JADX */
        public static final int arc = 0x7f080054;

        /* JADX INFO: Added by JADX */
        public static final int asConfigured = 0x7f080055;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f080056;

        /* JADX INFO: Added by JADX */
        public static final int auto = 0x7f080057;

        /* JADX INFO: Added by JADX */
        public static final int autoComplete = 0x7f080058;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToEnd = 0x7f080059;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToStart = 0x7f08005a;

        /* JADX INFO: Added by JADX */
        public static final int autoHide = 0x7f08005b;

        /* JADX INFO: Added by JADX */
        public static final int autoLimit = 0x7f08005c;

        /* JADX INFO: Added by JADX */
        public static final int availableSpace = 0x7f08005d;

        /* JADX INFO: Added by JADX */
        public static final int axisRelative = 0x7f08005e;

        /* JADX INFO: Added by JADX */
        public static final int barrier = 0x7f08005f;

        /* JADX INFO: Added by JADX */
        public static final int baseline = 0x7f080060;

        /* JADX INFO: Added by JADX */
        public static final int beginOnFirstDraw = 0x7f080061;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 0x7f080062;

        /* JADX INFO: Added by JADX */
        public static final int below = 0x7f080063;

        /* JADX INFO: Added by JADX */
        public static final int bestChoice = 0x7f080064;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f080065;

        /* JADX INFO: Added by JADX */
        public static final int bottom = 0x7f080066;

        /* JADX INFO: Added by JADX */
        public static final int bounce = 0x7f080067;

        /* JADX INFO: Added by JADX */
        public static final int bounceBoth = 0x7f080068;

        /* JADX INFO: Added by JADX */
        public static final int bounceEnd = 0x7f080069;

        /* JADX INFO: Added by JADX */
        public static final int bounceStart = 0x7f08006a;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanel = 0x7f08006b;

        /* JADX INFO: Added by JADX */
        public static final int cache_measures = 0x7f08006c;

        /* JADX INFO: Added by JADX */
        public static final int callMeasure = 0x7f08006d;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button = 0x7f08006e;

        /* JADX INFO: Added by JADX */
        public static final int carryVelocity = 0x7f08006f;

        /* JADX INFO: Added by JADX */
        public static final int center = 0x7f080070;

        /* JADX INFO: Added by JADX */
        public static final int centerCrop = 0x7f080071;

        /* JADX INFO: Added by JADX */
        public static final int centerInside = 0x7f080072;

        /* JADX INFO: Added by JADX */
        public static final int center_horizontal = 0x7f080073;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 0x7f080074;

        /* JADX INFO: Added by JADX */
        public static final int chain = 0x7f080075;

        /* JADX INFO: Added by JADX */
        public static final int chain2 = 0x7f080076;

        /* JADX INFO: Added by JADX */
        public static final int chains = 0x7f080077;

        /* JADX INFO: Added by JADX */
        public static final int checkbox = 0x7f080078;

        /* JADX INFO: Added by JADX */
        public static final int checked = 0x7f080079;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f08007a;

        /* JADX INFO: Added by JADX */
        public static final int circle_center = 0x7f08007b;

        /* JADX INFO: Added by JADX */
        public static final int clear_text = 0x7f08007c;

        /* JADX INFO: Added by JADX */
        public static final int clip_horizontal = 0x7f08007d;

        /* JADX INFO: Added by JADX */
        public static final int clip_vertical = 0x7f08007e;

        /* JADX INFO: Added by JADX */
        public static final int clockwise = 0x7f08007f;

        /* JADX INFO: Added by JADX */
        public static final int closest = 0x7f080080;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 0x7f080081;

        /* JADX INFO: Added by JADX */
        public static final int compress = 0x7f080082;

        /* JADX INFO: Added by JADX */
        public static final int confirm_button = 0x7f080083;

        /* JADX INFO: Added by JADX */
        public static final int constraint = 0x7f080084;

        /* JADX INFO: Added by JADX */
        public static final int container = 0x7f080085;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f080086;

        /* JADX INFO: Added by JADX */
        public static final int contentPanel = 0x7f080087;

        /* JADX INFO: Added by JADX */
        public static final int contiguous = 0x7f080088;

        /* JADX INFO: Added by JADX */
        public static final int continuousVelocity = 0x7f080089;

        /* JADX INFO: Added by JADX */
        public static final int coordinator = 0x7f08008a;

        /* JADX INFO: Added by JADX */
        public static final int cos = 0x7f08008b;

        /* JADX INFO: Added by JADX */
        public static final int counterclockwise = 0x7f08008c;

        /* JADX INFO: Added by JADX */
        public static final int cradle = 0x7f08008d;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f08008e;

        /* JADX INFO: Added by JADX */
        public static final int custom = 0x7f08008f;

        /* JADX INFO: Added by JADX */
        public static final int customPanel = 0x7f080090;

        /* JADX INFO: Added by JADX */
        public static final int cut = 0x7f080091;

        /* JADX INFO: Added by JADX */
        public static final int dark = 0x7f080092;

        /* JADX INFO: Added by JADX */
        public static final int date_picker_actions = 0x7f080093;

        /* JADX INFO: Added by JADX */
        public static final int decelerate = 0x7f080094;

        /* JADX INFO: Added by JADX */
        public static final int decelerateAndComplete = 0x7f080095;

        /* JADX INFO: Added by JADX */
        public static final int decor_content_parent = 0x7f080096;

        /* JADX INFO: Added by JADX */
        public static final int default_activity_button = 0x7f080097;

        /* JADX INFO: Added by JADX */
        public static final int deltaRelative = 0x7f080098;

        /* JADX INFO: Added by JADX */
        public static final int dependency_ordering = 0x7f080099;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet = 0x7f08009a;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area = 0x7f08009b;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area_stub = 0x7f08009c;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_text = 0x7f08009d;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_view = 0x7f08009e;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f08009f;

        /* JADX INFO: Added by JADX */
        public static final int dimensions = 0x7f0800a0;

        /* JADX INFO: Added by JADX */
        public static final int direct = 0x7f0800a1;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 0x7f0800a2;

        /* JADX INFO: Added by JADX */
        public static final int disableIntraAutoTransition = 0x7f0800a3;

        /* JADX INFO: Added by JADX */
        public static final int disablePostScroll = 0x7f0800a4;

        /* JADX INFO: Added by JADX */
        public static final int disableScroll = 0x7f0800a5;

        /* JADX INFO: Added by JADX */
        public static final int disabled = 0x7f0800a6;

        /* JADX INFO: Added by JADX */
        public static final int disjoint = 0x7f0800a7;

        /* JADX INFO: Added by JADX */
        public static final int dragAnticlockwise = 0x7f0800a8;

        /* JADX INFO: Added by JADX */
        public static final int dragClockwise = 0x7f0800a9;

        /* JADX INFO: Added by JADX */
        public static final int dragDown = 0x7f0800aa;

        /* JADX INFO: Added by JADX */
        public static final int dragEnd = 0x7f0800ab;

        /* JADX INFO: Added by JADX */
        public static final int dragLeft = 0x7f0800ac;

        /* JADX INFO: Added by JADX */
        public static final int dragRight = 0x7f0800ad;

        /* JADX INFO: Added by JADX */
        public static final int dragStart = 0x7f0800ae;

        /* JADX INFO: Added by JADX */
        public static final int dragUp = 0x7f0800af;

        /* JADX INFO: Added by JADX */
        public static final int dropdown_menu = 0x7f0800b0;

        /* JADX INFO: Added by JADX */
        public static final int easeIn = 0x7f0800b1;

        /* JADX INFO: Added by JADX */
        public static final int easeInOut = 0x7f0800b2;

        /* JADX INFO: Added by JADX */
        public static final int easeOut = 0x7f0800b3;

        /* JADX INFO: Added by JADX */
        public static final int east = 0x7f0800b4;

        /* JADX INFO: Added by JADX */
        public static final int edge = 0x7f0800b5;

        /* JADX INFO: Added by JADX */
        public static final int edit_query = 0x7f0800b6;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f0800b7;

        /* JADX INFO: Added by JADX */
        public static final int elastic = 0x7f0800b8;

        /* JADX INFO: Added by JADX */
        public static final int embed = 0x7f0800b9;

        /* JADX INFO: Added by JADX */
        public static final int end = 0x7f0800ba;

        /* JADX INFO: Added by JADX */
        public static final int endToStart = 0x7f0800bb;

        /* JADX INFO: Added by JADX */
        public static final int enterAlways = 0x7f0800bc;

        /* JADX INFO: Added by JADX */
        public static final int enterAlwaysCollapsed = 0x7f0800bd;

        /* JADX INFO: Added by JADX */
        public static final int entireSpace = 0x7f0800be;

        /* JADX INFO: Added by JADX */
        public static final int escape = 0x7f0800bf;

        /* JADX INFO: Added by JADX */
        public static final int exitUntilCollapsed = 0x7f0800c0;

        /* JADX INFO: Added by JADX */
        public static final int expand_activities_button = 0x7f0800c1;

        /* JADX INFO: Added by JADX */
        public static final int expanded_menu = 0x7f0800c2;

        /* JADX INFO: Added by JADX */
        public static final int fade = 0x7f0800c3;

        /* JADX INFO: Added by JADX */
        public static final int fill = 0x7f0800c4;

        /* JADX INFO: Added by JADX */
        public static final int fill_horizontal = 0x7f0800c5;

        /* JADX INFO: Added by JADX */
        public static final int fill_vertical = 0x7f0800c6;

        /* JADX INFO: Added by JADX */
        public static final int filled = 0x7f0800c7;

        /* JADX INFO: Added by JADX */
        public static final int fitCenter = 0x7f0800c8;

        /* JADX INFO: Added by JADX */
        public static final int fitEnd = 0x7f0800c9;

        /* JADX INFO: Added by JADX */
        public static final int fitStart = 0x7f0800ca;

        /* JADX INFO: Added by JADX */
        public static final int fitToContents = 0x7f0800cb;

        /* JADX INFO: Added by JADX */
        public static final int fitXY = 0x7f0800cc;

        /* JADX INFO: Added by JADX */
        public static final int fixed = 0x7f0800cd;

        /* JADX INFO: Added by JADX */
        public static final int flip = 0x7f0800ce;

        /* JADX INFO: Added by JADX */
        public static final int floating = 0x7f0800cf;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f0800d0;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 0x7f0800d1;

        /* JADX INFO: Added by JADX */
        public static final int frost = 0x7f0800d2;

        /* JADX INFO: Added by JADX */
        public static final int fullscreen_header = 0x7f0800d3;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view = 0x7f0800d4;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view_holder = 0x7f0800d5;

        /* JADX INFO: Added by JADX */
        public static final int gone = 0x7f0800d6;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f0800d7;

        /* JADX INFO: Added by JADX */
        public static final int graph_wrap = 0x7f0800d8;

        /* JADX INFO: Added by JADX */
        public static final int group_divider = 0x7f0800d9;

        /* JADX INFO: Added by JADX */
        public static final int grouping = 0x7f0800da;

        /* JADX INFO: Added by JADX */
        public static final int groups = 0x7f0800db;

        /* JADX INFO: Added by JADX */
        public static final int guideline = 0x7f0800dc;

        /* JADX INFO: Added by JADX */
        public static final int header_title = 0x7f0800dd;

        /* JADX INFO: Added by JADX */
        public static final int hidden = 0x7f0800de;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f0800df;

        /* JADX INFO: Added by JADX */
        public static final int hideable = 0x7f0800e0;

        /* JADX INFO: Added by JADX */
        public static final int home = 0x7f0800e1;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 0x7f0800e2;

        /* JADX INFO: Added by JADX */
        public static final int honorRequest = 0x7f0800e3;

        /* JADX INFO: Added by JADX */
        public static final int horizontal = 0x7f0800e4;

        /* JADX INFO: Added by JADX */
        public static final int horizontal_only = 0x7f0800e5;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f0800e6;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f0800e7;

        /* JADX INFO: Added by JADX */
        public static final int icon_only = 0x7f0800e8;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 0x7f0800e9;

        /* JADX INFO: Added by JADX */
        public static final int ignore = 0x7f0800ea;

        /* JADX INFO: Added by JADX */
        public static final int ignoreRequest = 0x7f0800eb;

        /* JADX INFO: Added by JADX */
        public static final int immediateStop = 0x7f0800ed;

        /* JADX INFO: Added by JADX */
        public static final int included = 0x7f0800ee;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f0800ef;

        /* JADX INFO: Added by JADX */
        public static final int indirect = 0x7f0800f0;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f0800f1;

        /* JADX INFO: Added by JADX */
        public static final int invisible = 0x7f0800f2;

        /* JADX INFO: Added by JADX */
        public static final int inward = 0x7f0800f3;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f0800f4;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_previous_elevation = 0x7f0800f5;

        /* JADX INFO: Added by JADX */
        public static final int jumpToEnd = 0x7f0800f6;

        /* JADX INFO: Added by JADX */
        public static final int jumpToStart = 0x7f0800f7;

        /* JADX INFO: Added by JADX */
        public static final int labeled = 0x7f0800f8;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f0800f9;

        /* JADX INFO: Added by JADX */
        public static final int left = 0x7f0800fa;

        /* JADX INFO: Added by JADX */
        public static final int leftToRight = 0x7f0800fb;

        /* JADX INFO: Added by JADX */
        public static final int legacy = 0x7f0800fc;

        /* JADX INFO: Added by JADX */
        public static final int light = 0x7f0800fd;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f0800fe;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f0800ff;

        /* JADX INFO: Added by JADX */
        public static final int linear = 0x7f080100;

        /* JADX INFO: Added by JADX */
        public static final int listMode = 0x7f080101;

        /* JADX INFO: Added by JADX */
        public static final int list_item = 0x7f080102;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet = 0x7f080103;

        /* JADX INFO: Added by JADX */
        public static final int marquee = 0x7f080104;

        /* JADX INFO: Added by JADX */
        public static final int masked = 0x7f080105;

        /* JADX INFO: Added by JADX */
        public static final int match_constraint = 0x7f080106;

        /* JADX INFO: Added by JADX */
        public static final int match_parent = 0x7f080107;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display = 0x7f080108;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_and_toggle = 0x7f080109;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face = 0x7f08010a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand = 0x7f08010b;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_level = 0x7f08010c;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_am_button = 0x7f08010d;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_pm_button = 0x7f08010e;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle = 0x7f08010f;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_text_input = 0x7f080110;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_tv = 0x7f080111;

        /* JADX INFO: Added by JADX */
        public static final int material_label = 0x7f080112;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_text_input = 0x7f080113;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_tv = 0x7f080114;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_timepicker = 0x7f080115;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_cancel_button = 0x7f080116;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_container = 0x7f080117;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_mode_button = 0x7f080118;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_ok_button = 0x7f080119;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_view = 0x7f08011a;

        /* JADX INFO: Added by JADX */
        public static final int material_value_index = 0x7f08011b;

        /* JADX INFO: Added by JADX */
        public static final int matrix = 0x7f08011c;

        /* JADX INFO: Added by JADX */
        public static final int menu = 0x7f08011d;

        /* JADX INFO: Added by JADX */
        public static final int message = 0x7f08011e;

        /* JADX INFO: Added by JADX */
        public static final int middle = 0x7f08011f;

        /* JADX INFO: Added by JADX */
        public static final int mini = 0x7f080120;

        /* JADX INFO: Added by JADX */
        public static final int month_grid = 0x7f080121;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_bar = 0x7f080122;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_fragment_toggle = 0x7f080123;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_next = 0x7f080124;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_previous = 0x7f080125;

        /* JADX INFO: Added by JADX */
        public static final int month_title = 0x7f080126;

        /* JADX INFO: Added by JADX */
        public static final int motion_base = 0x7f080127;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_selector_frame = 0x7f080128;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week = 0x7f080129;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_frame = 0x7f08012a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_main_pane = 0x7f08012b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_months = 0x7f08012c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_frame = 0x7f08012d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_text_input_frame = 0x7f08012e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_selector_frame = 0x7f08012f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_layer_id = 0x7f080130;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_child_content_container = 0x7f080131;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_internal_children_alpha_tag = 0x7f080132;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_motion_snapshot_view = 0x7f080133;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_edit_text_date = 0x7f080134;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_edit_text_range_end = 0x7f080135;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_edit_text_range_start = 0x7f080136;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_fullscreen = 0x7f080137;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header = 0x7f080138;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_selection_text = 0x7f080139;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_title_and_selection = 0x7f08013a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_toggle = 0x7f08013b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date = 0x7f08013c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_range_end = 0x7f08013d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_range_start = 0x7f08013e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_title_text = 0x7f08013f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_close = 0x7f080140;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_tag_bottom_padding = 0x7f080141;

        /* JADX INFO: Added by JADX */
        public static final int multiply = 0x7f080142;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_active_indicator_view = 0x7f080143;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_content_container = 0x7f080144;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_icon_container = 0x7f080145;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_icon_view = 0x7f080146;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_inner_content_container = 0x7f080147;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_labels_group = 0x7f080148;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_large_label_view = 0x7f080149;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_small_label_view = 0x7f08014a;

        /* JADX INFO: Added by JADX */
        public static final int navigation_header_container = 0x7f08014b;

        /* JADX INFO: Added by JADX */
        public static final int navigation_menu_subheader_label = 0x7f08014c;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f08014d;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToEnd = 0x7f08014e;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToStart = 0x7f08014f;

        /* JADX INFO: Added by JADX */
        public static final int noScroll = 0x7f080150;

        /* JADX INFO: Added by JADX */
        public static final int noState = 0x7f080151;

        /* JADX INFO: Added by JADX */
        public static final int none = 0x7f080152;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f080153;

        /* JADX INFO: Added by JADX */
        public static final int north = 0x7f080154;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f080155;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f080156;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f080157;

        /* JADX INFO: Added by JADX */
        public static final int off = 0x7f080158;

        /* JADX INFO: Added by JADX */
        public static final int on = 0x7f080159;

        /* JADX INFO: Added by JADX */
        public static final int onInterceptTouchReturnSwipe = 0x7f08015a;

        /* JADX INFO: Added by JADX */
        public static final int open_search_bar_placeholder_text_view = 0x7f08015b;

        /* JADX INFO: Added by JADX */
        public static final int open_search_bar_text_view = 0x7f08015c;

        /* JADX INFO: Added by JADX */
        public static final int open_search_bar_text_view_container = 0x7f08015d;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_background = 0x7f08015e;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_clear_button = 0x7f08015f;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_content_container = 0x7f080160;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_divider = 0x7f080161;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_dummy_text_view = 0x7f080162;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_dummy_toolbar = 0x7f080163;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_edit_text = 0x7f080164;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_header_container = 0x7f080165;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_root = 0x7f080166;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_scrim = 0x7f080167;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_search_prefix = 0x7f080168;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_status_bar_spacer = 0x7f080169;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_text_container = 0x7f08016a;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_toolbar = 0x7f08016b;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_toolbar_container = 0x7f08016c;

        /* JADX INFO: Added by JADX */
        public static final int outline = 0x7f08016d;

        /* JADX INFO: Added by JADX */
        public static final int outward = 0x7f08016e;

        /* JADX INFO: Added by JADX */
        public static final int overflow_button = 0x7f08016f;

        /* JADX INFO: Added by JADX */
        public static final int overshoot = 0x7f080170;

        /* JADX INFO: Added by JADX */
        public static final int packed = 0x7f080171;

        /* JADX INFO: Added by JADX */
        public static final int parallax = 0x7f080172;

        /* JADX INFO: Added by JADX */
        public static final int parent = 0x7f080173;

        /* JADX INFO: Added by JADX */
        public static final int parentPanel = 0x7f080174;

        /* JADX INFO: Added by JADX */
        public static final int parentRelative = 0x7f080175;

        /* JADX INFO: Added by JADX */
        public static final int parent_matrix = 0x7f080176;

        /* JADX INFO: Added by JADX */
        public static final int password_toggle = 0x7f080177;

        /* JADX INFO: Added by JADX */
        public static final int path = 0x7f080178;

        /* JADX INFO: Added by JADX */
        public static final int pathRelative = 0x7f080179;

        /* JADX INFO: Added by JADX */
        public static final int peekHeight = 0x7f08017a;

        /* JADX INFO: Added by JADX */
        public static final int percent = 0x7f08017b;

        /* JADX INFO: Added by JADX */
        public static final int pin = 0x7f08017c;

        /* JADX INFO: Added by JADX */
        public static final int position = 0x7f08017d;

        /* JADX INFO: Added by JADX */
        public static final int postLayout = 0x7f08017e;

        /* JADX INFO: Added by JADX */
        public static final int pressed = 0x7f08017f;

        /* JADX INFO: Added by JADX */
        public static final int progress_circular = 0x7f080180;

        /* JADX INFO: Added by JADX */
        public static final int progress_horizontal = 0x7f080181;

        /* JADX INFO: Added by JADX */
        public static final int protection_layout = 0x7f080182;

        /* JADX INFO: Added by JADX */
        public static final int radio = 0x7f080183;

        /* JADX INFO: Added by JADX */
        public static final int ratio = 0x7f080184;

        /* JADX INFO: Added by JADX */
        public static final int rectangles = 0x7f080185;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f080186;

        /* JADX INFO: Added by JADX */
        public static final int retreat = 0x7f080187;

        /* JADX INFO: Added by JADX */
        public static final int reverseSawtooth = 0x7f080188;

        /* JADX INFO: Added by JADX */
        public static final int right = 0x7f080189;

        /* JADX INFO: Added by JADX */
        public static final int rightToLeft = 0x7f08018a;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f08018b;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f08018c;

        /* JADX INFO: Added by JADX */
        public static final int rounded = 0x7f08018d;

        /* JADX INFO: Added by JADX */
        public static final int row_index_key = 0x7f08018e;

        /* JADX INFO: Added by JADX */
        public static final int save_non_transition_alpha = 0x7f08018f;

        /* JADX INFO: Added by JADX */
        public static final int save_overlay_view = 0x7f080190;

        /* JADX INFO: Added by JADX */
        public static final int sawtooth = 0x7f080191;

        /* JADX INFO: Added by JADX */
        public static final int scale = 0x7f080192;

        /* JADX INFO: Added by JADX */
        public static final int screen = 0x7f080193;

        /* JADX INFO: Added by JADX */
        public static final int scroll = 0x7f080194;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorDown = 0x7f080195;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorUp = 0x7f080196;

        /* JADX INFO: Added by JADX */
        public static final int scrollView = 0x7f080197;

        /* JADX INFO: Added by JADX */
        public static final int scrollable = 0x7f080198;

        /* JADX INFO: Added by JADX */
        public static final int search_badge = 0x7f080199;

        /* JADX INFO: Added by JADX */
        public static final int search_bar = 0x7f08019a;

        /* JADX INFO: Added by JADX */
        public static final int search_button = 0x7f08019b;

        /* JADX INFO: Added by JADX */
        public static final int search_close_btn = 0x7f08019c;

        /* JADX INFO: Added by JADX */
        public static final int search_edit_frame = 0x7f08019d;

        /* JADX INFO: Added by JADX */
        public static final int search_go_btn = 0x7f08019e;

        /* JADX INFO: Added by JADX */
        public static final int search_mag_icon = 0x7f08019f;

        /* JADX INFO: Added by JADX */
        public static final int search_plate = 0x7f0801a0;

        /* JADX INFO: Added by JADX */
        public static final int search_src_text = 0x7f0801a1;

        /* JADX INFO: Added by JADX */
        public static final int search_voice_btn = 0x7f0801a2;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_listview = 0x7f0801a3;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f0801a4;

        /* JADX INFO: Added by JADX */
        public static final int selection_type = 0x7f0801a5;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueSet = 0x7f0801a6;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueUnset = 0x7f0801a7;

        /* JADX INFO: Added by JADX */
        public static final int shortcut = 0x7f0801a8;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 0x7f0801a9;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 0x7f0801aa;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f0801ab;

        /* JADX INFO: Added by JADX */
        public static final int sin = 0x7f0801ac;

        /* JADX INFO: Added by JADX */
        public static final int skipCollapsed = 0x7f0801ad;

        /* JADX INFO: Added by JADX */
        public static final int skipped = 0x7f0801ae;

        /* JADX INFO: Added by JADX */
        public static final int slide = 0x7f0801af;

        /* JADX INFO: Added by JADX */
        public static final int snackbar_action = 0x7f0801b0;

        /* JADX INFO: Added by JADX */
        public static final int snackbar_text = 0x7f0801b1;

        /* JADX INFO: Added by JADX */
        public static final int snap = 0x7f0801b2;

        /* JADX INFO: Added by JADX */
        public static final int snapMargins = 0x7f0801b3;

        /* JADX INFO: Added by JADX */
        public static final int south = 0x7f0801b4;

        /* JADX INFO: Added by JADX */
        public static final int spacer = 0x7f0801b5;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 0x7f0801b6;

        /* JADX INFO: Added by JADX */
        public static final int spline = 0x7f0801b7;

        /* JADX INFO: Added by JADX */
        public static final int split_action_bar = 0x7f0801b8;

        /* JADX INFO: Added by JADX */
        public static final int spread = 0x7f0801b9;

        /* JADX INFO: Added by JADX */
        public static final int spread_inside = 0x7f0801ba;

        /* JADX INFO: Added by JADX */
        public static final int spring = 0x7f0801bb;

        /* JADX INFO: Added by JADX */
        public static final int square = 0x7f0801bc;

        /* JADX INFO: Added by JADX */
        public static final int src_atop = 0x7f0801bd;

        /* JADX INFO: Added by JADX */
        public static final int src_in = 0x7f0801be;

        /* JADX INFO: Added by JADX */
        public static final int src_over = 0x7f0801bf;

        /* JADX INFO: Added by JADX */
        public static final int standard = 0x7f0801c0;

        /* JADX INFO: Added by JADX */
        public static final int start = 0x7f0801c1;

        /* JADX INFO: Added by JADX */
        public static final int startHorizontal = 0x7f0801c2;

        /* JADX INFO: Added by JADX */
        public static final int startToEnd = 0x7f0801c3;

        /* JADX INFO: Added by JADX */
        public static final int startVertical = 0x7f0801c4;

        /* JADX INFO: Added by JADX */
        public static final int start_center = 0x7f0801c5;

        /* JADX INFO: Added by JADX */
        public static final int staticLayout = 0x7f0801c6;

        /* JADX INFO: Added by JADX */
        public static final int staticPostLayout = 0x7f0801c7;

        /* JADX INFO: Added by JADX */
        public static final int stop = 0x7f0801c8;

        /* JADX INFO: Added by JADX */
        public static final int stretch = 0x7f0801c9;

        /* JADX INFO: Added by JADX */
        public static final int submenuarrow = 0x7f0801ca;

        /* JADX INFO: Added by JADX */
        public static final int submit_area = 0x7f0801cb;

        /* JADX INFO: Added by JADX */
        public static final int supportScrollUp = 0x7f0801cc;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 0x7f0801cd;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f0801ce;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f0801cf;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f0801d0;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f0801d1;

        /* JADX INFO: Added by JADX */
        public static final int tag_compat_insets_dispatch = 0x7f0801d2;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f0801d3;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f0801d4;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f0801d5;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f0801d6;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f0801d7;

        /* JADX INFO: Added by JADX */
        public static final int tag_system_bar_state_monitor = 0x7f0801d8;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f0801d9;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f0801da;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f0801db;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f0801dc;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f0801dd;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f0801de;

        /* JADX INFO: Added by JADX */
        public static final int textEnd = 0x7f0801df;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoButtons = 0x7f0801e0;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoTitle = 0x7f0801e1;

        /* JADX INFO: Added by JADX */
        public static final int textStart = 0x7f0801e2;

        /* JADX INFO: Added by JADX */
        public static final int textTop = 0x7f0801e3;

        /* JADX INFO: Added by JADX */
        public static final int text_input_end_icon = 0x7f0801e4;

        /* JADX INFO: Added by JADX */
        public static final int text_input_error_icon = 0x7f0801e5;

        /* JADX INFO: Added by JADX */
        public static final int text_input_start_icon = 0x7f0801e6;

        /* JADX INFO: Added by JADX */
        public static final int textinput_counter = 0x7f0801e7;

        /* JADX INFO: Added by JADX */
        public static final int textinput_error = 0x7f0801e8;

        /* JADX INFO: Added by JADX */
        public static final int textinput_helper_text = 0x7f0801e9;

        /* JADX INFO: Added by JADX */
        public static final int textinput_placeholder = 0x7f0801ea;

        /* JADX INFO: Added by JADX */
        public static final int textinput_prefix_text = 0x7f0801eb;

        /* JADX INFO: Added by JADX */
        public static final int textinput_suffix_text = 0x7f0801ec;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f0801ed;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f0801ee;

        /* JADX INFO: Added by JADX */
        public static final int titleDividerNoCustom = 0x7f0801ef;

        /* JADX INFO: Added by JADX */
        public static final int title_template = 0x7f0801f0;

        /* JADX INFO: Added by JADX */
        public static final int toggle = 0x7f0801f1;

        /* JADX INFO: Added by JADX */
        public static final int top = 0x7f0801f2;

        /* JADX INFO: Added by JADX */
        public static final int topPanel = 0x7f0801f3;

        /* JADX INFO: Added by JADX */
        public static final int top_center = 0x7f0801f4;

        /* JADX INFO: Added by JADX */
        public static final int touch_outside = 0x7f0801f5;

        /* JADX INFO: Added by JADX */
        public static final int transitionToEnd = 0x7f0801f6;

        /* JADX INFO: Added by JADX */
        public static final int transitionToStart = 0x7f0801f7;

        /* JADX INFO: Added by JADX */
        public static final int transition_clip = 0x7f0801f8;

        /* JADX INFO: Added by JADX */
        public static final int transition_current_scene = 0x7f0801f9;

        /* JADX INFO: Added by JADX */
        public static final int transition_image_transform = 0x7f0801fa;

        /* JADX INFO: Added by JADX */
        public static final int transition_layout_save = 0x7f0801fb;

        /* JADX INFO: Added by JADX */
        public static final int transition_pause_alpha = 0x7f0801fc;

        /* JADX INFO: Added by JADX */
        public static final int transition_position = 0x7f0801fd;

        /* JADX INFO: Added by JADX */
        public static final int transition_scene_layoutid_cache = 0x7f0801fe;

        /* JADX INFO: Added by JADX */
        public static final int transition_transform = 0x7f0801ff;

        /* JADX INFO: Added by JADX */
        public static final int triangle = 0x7f080200;

        /* JADX INFO: Added by JADX */
        public static final int unchecked = 0x7f080201;

        /* JADX INFO: Added by JADX */
        public static final int uniform = 0x7f080202;

        /* JADX INFO: Added by JADX */
        public static final int unlabeled = 0x7f080203;

        /* JADX INFO: Added by JADX */
        public static final int up = 0x7f080204;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 0x7f080205;

        /* JADX INFO: Added by JADX */
        public static final int vertical = 0x7f080206;

        /* JADX INFO: Added by JADX */
        public static final int vertical_only = 0x7f080207;

        /* JADX INFO: Added by JADX */
        public static final int view_offset_helper = 0x7f080208;

        /* JADX INFO: Added by JADX */
        public static final int view_transition = 0x7f080209;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_disjoint_parent = 0x7f08020a;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f08020b;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f08020c;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f08020d;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f08020e;

        /* JADX INFO: Added by JADX */
        public static final int visible = 0x7f08020f;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 0x7f080210;

        /* JADX INFO: Added by JADX */
        public static final int west = 0x7f080211;

        /* JADX INFO: Added by JADX */
        public static final int wide = 0x7f080212;

        /* JADX INFO: Added by JADX */
        public static final int withText = 0x7f080213;

        /* JADX INFO: Added by JADX */
        public static final int with_icon = 0x7f080214;

        /* JADX INFO: Added by JADX */
        public static final int withinBounds = 0x7f080215;

        /* JADX INFO: Added by JADX */
        public static final int wrap = 0x7f080216;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content = 0x7f080217;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content_constrained = 0x7f080218;

        /* JADX INFO: Added by JADX */
        public static final int x_left = 0x7f080219;

        /* JADX INFO: Added by JADX */
        public static final int x_right = 0x7f08021a;

        private id() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityDefaultDur = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityShortDur = 0x7f090001;

        /* JADX INFO: Added by JADX */
        public static final int app_bar_elevation_anim_duration = 0x7f090002;

        /* JADX INFO: Added by JADX */
        public static final int bottom_sheet_slide_duration = 0x7f090003;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button_image_alpha = 0x7f090004;

        /* JADX INFO: Added by JADX */
        public static final int config_tooltipAnimTime = 0x7f090005;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_text_max_lines = 0x7f090006;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_indicator_anim_duration_ms = 0x7f090007;

        /* JADX INFO: Added by JADX */
        public static final int google_play_services_version = 0x7f090008;

        /* JADX INFO: Added by JADX */
        public static final int hide_password_duration = 0x7f090009;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_max_number = 0x7f09000a;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_anim_delay_ms = 0x7f09000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_anim_duration_ms = 0x7f09000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_anim_delay_ms = 0x7f09000d;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_anim_duration_ms = 0x7f09000e;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_anim_duration = 0x7f09000f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long1 = 0x7f090010;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long2 = 0x7f090011;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long3 = 0x7f090012;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long4 = 0x7f090013;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long1 = 0x7f090014;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long2 = 0x7f090015;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long3 = 0x7f090016;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long4 = 0x7f090017;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium1 = 0x7f090018;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium2 = 0x7f090019;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium3 = 0x7f09001a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium4 = 0x7f09001b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short1 = 0x7f09001c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short2 = 0x7f09001d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short3 = 0x7f09001e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short4 = 0x7f09001f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_path = 0x7f090020;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_extra_extra_large_corner_family = 0x7f090021;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_extra_large_corner_family = 0x7f090022;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_extra_large_increased_corner_family = 0x7f090023;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_extra_small_corner_family = 0x7f090024;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_full_corner_family = 0x7f090025;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_large_corner_family = 0x7f090026;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_large_increased_corner_family = 0x7f090027;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_medium_corner_family = 0x7f090028;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_small_corner_family = 0x7f090029;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_bottom_nav_icon_gravity = 0x7f09002a;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_bottom_nav_item_gravity = 0x7f09002b;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_long_1 = 0x7f09002c;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_long_2 = 0x7f09002d;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_medium_1 = 0x7f09002e;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_medium_2 = 0x7f09002f;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_short_1 = 0x7f090030;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_short_2 = 0x7f090031;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_path = 0x7f090032;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_max_character_count = 0x7f090033;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_anim_delay_ms = 0x7f090034;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_anim_duration_ms = 0x7f090035;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_orientation = 0x7f090036;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_lines = 0x7f090037;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_selector_span = 0x7f090038;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_anim_delay_ms = 0x7f090039;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_anim_duration_ms = 0x7f09003a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_anim_duration = 0x7f09003b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_motion_duration = 0x7f09003c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_post_morphing_duration = 0x7f09003d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pre_morphing_duration = 0x7f09003e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_duration = 0x7f09003f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_viewport_center_coordinate = 0x7f090040;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_viewport_size = 0x7f090041;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_viewport_height = 0x7f090042;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_viewport_width = 0x7f090043;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tab_indicator_anim_duration_ms = 0x7f090044;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_gone = 0x7f090045;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_invisible = 0x7f090046;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_visible = 0x7f090047;

        /* JADX INFO: Added by JADX */
        public static final int show_password_duration = 0x7f090048;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 0x7f090049;
    }

    /* JADX INFO: Added by JADX */
    public static final class interpolator {

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 0x7f0a0000;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 0x7f0a0001;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 0x7f0a0002;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 0x7f0a0003;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 0x7f0a0004;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 0x7f0a0005;

        /* JADX INFO: Added by JADX */
        public static final int fast_out_slow_in = 0x7f0a0006;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized = 0x7f0a0007;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate = 0x7f0a0008;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate = 0x7f0a0009;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear = 0x7f0a000a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard = 0x7f0a000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate = 0x7f0a000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate = 0x7f0a000d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fast_out_linear_in = 0x7f0a000e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fast_out_slow_in = 0x7f0a000f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_linear = 0x7f0a0010;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_linear_out_slow_in = 0x7f0a0011;
    }

    public static final class layout {
        public static final int activity_main = 0x7f0b001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_title_item = 0x7f0b0000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_container = 0x7f0b0001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_item_layout = 0x7f0b0002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_layout = 0x7f0b0003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_bar = 0x7f0b0004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_close_item_material = 0x7f0b0005;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view = 0x7f0b0006;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_list_item = 0x7f0b0007;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 0x7f0b0008;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_material = 0x7f0b0009;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_title_material = 0x7f0b000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menu_item_layout = 0x7f0b000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_material = 0x7f0b000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_expanded_menu_layout = 0x7f0b000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_checkbox = 0x7f0b000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_icon = 0x7f0b000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_layout = 0x7f0b0010;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_radio = 0x7f0b0011;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_header_item_layout = 0x7f0b0012;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_item_layout = 0x7f0b0013;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_content_include = 0x7f0b0014;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple = 0x7f0b0015;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 0x7f0b0016;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_toolbar = 0x7f0b0017;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 0x7f0b0018;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view = 0x7f0b0019;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_material = 0x7f0b001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_tooltip = 0x7f0b001b;

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 0x7f0b001d;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item = 0x7f0b001e;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_dialog = 0x7f0b001f;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_snackbar = 0x7f0b0020;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_snackbar_include = 0x7f0b0021;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_tab_icon = 0x7f0b0022;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_tab_text = 0x7f0b0023;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area = 0x7f0b0024;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item = 0x7f0b0025;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_header = 0x7f0b0026;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_separator = 0x7f0b0027;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_subheader = 0x7f0b0028;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_menu = 0x7f0b0029;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_menu_item = 0x7f0b002a;

        /* JADX INFO: Added by JADX */
        public static final int design_text_input_end_icon = 0x7f0b002b;

        /* JADX INFO: Added by JADX */
        public static final int design_text_input_start_icon = 0x7f0b002c;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 0x7f0b002d;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 0x7f0b002e;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog = 0x7f0b002f;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_actions = 0x7f0b0030;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_title = 0x7f0b0031;

        /* JADX INFO: Added by JADX */
        public static final int m3_auto_complete_simple_item = 0x7f0b0032;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_group_overflow_button = 0x7f0b0033;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_divider = 0x7f0b0034;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_subheader = 0x7f0b0035;

        /* JADX INFO: Added by JADX */
        public static final int m3_overflow_linear_layout_overflow_button = 0x7f0b0036;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_dialog = 0x7f0b0037;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_alert_dialog = 0x7f0b0038;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_alert_dialog_title = 0x7f0b0039;

        /* JADX INFO: Added by JADX */
        public static final int material_chip_input_combo = 0x7f0b003a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display = 0x7f0b003b;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_divider = 0x7f0b003c;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle = 0x7f0b003d;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_land = 0x7f0b003e;

        /* JADX INFO: Added by JADX */
        public static final int material_clockface_textview = 0x7f0b003f;

        /* JADX INFO: Added by JADX */
        public static final int material_clockface_view = 0x7f0b0040;

        /* JADX INFO: Added by JADX */
        public static final int material_radial_view_group = 0x7f0b0041;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_timepicker = 0x7f0b0042;

        /* JADX INFO: Added by JADX */
        public static final int material_time_chip = 0x7f0b0043;

        /* JADX INFO: Added by JADX */
        public static final int material_time_input = 0x7f0b0044;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker = 0x7f0b0045;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_dialog = 0x7f0b0046;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_textinput_display = 0x7f0b0047;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog = 0x7f0b0048;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_actions = 0x7f0b0049;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_title = 0x7f0b004a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_item = 0x7f0b004b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_multichoice = 0x7f0b004c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_singlechoice = 0x7f0b004d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_auto_complete_simple_item = 0x7f0b004e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day = 0x7f0b004f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_of_week = 0x7f0b0050;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week = 0x7f0b0051;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_horizontal = 0x7f0b0052;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month = 0x7f0b0053;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_labeled = 0x7f0b0054;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_navigation = 0x7f0b0055;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_months = 0x7f0b0056;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_vertical = 0x7f0b0057;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year = 0x7f0b0058;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_layout_snackbar = 0x7f0b0059;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_layout_snackbar_include = 0x7f0b005a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_item = 0x7f0b005b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_actions = 0x7f0b005c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_dialog = 0x7f0b005d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_fullscreen = 0x7f0b005e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_dialog = 0x7f0b005f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_fullscreen = 0x7f0b0060;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_selection_text = 0x7f0b0061;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_title_text = 0x7f0b0062;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_toggle = 0x7f0b0063;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date = 0x7f0b0064;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range = 0x7f0b0065;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_search_bar = 0x7f0b0066;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_search_view = 0x7f0b0067;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 0x7f0b0068;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 0x7f0b0069;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 0x7f0b006a;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 0x7f0b006b;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 0x7f0b006c;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 0x7f0b006d;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_item_material = 0x7f0b006e;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_multichoice_material = 0x7f0b006f;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_singlechoice_material = 0x7f0b0070;

        /* JADX INFO: Added by JADX */
        public static final int support_simple_spinner_dropdown_item = 0x7f0b0071;

        private layout() {
        }
    }

    public static final class mipmap {
        public static final int ic_launcher = 0x7f0d0000;
        public static final int ic_launcher_foreground = 0x7f0d0001;
        public static final int ic_launcher_round = 0x7f0d0002;

        private mipmap() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class plurals {

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_content_description = 0x7f0e0000;
    }

    public static final class string {
        public static final int app_name = 0x7f0f001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_home_description = 0x7f0f0000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_description = 0x7f0f0001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_overflow_description = 0x7f0f0002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_done = 0x7f0f0003;

        /* JADX INFO: Added by JADX */
        public static final int abc_activity_chooser_view_see_all = 0x7f0f0004;

        /* JADX INFO: Added by JADX */
        public static final int abc_activitychooserview_choose_application = 0x7f0f0005;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_off = 0x7f0f0006;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_on = 0x7f0f0007;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_alt_shortcut_label = 0x7f0f0008;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 0x7f0f0009;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_delete_shortcut_label = 0x7f0f000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_enter_shortcut_label = 0x7f0f000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_function_shortcut_label = 0x7f0f000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_meta_shortcut_label = 0x7f0f000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_shift_shortcut_label = 0x7f0f000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_space_shortcut_label = 0x7f0f000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_sym_shortcut_label = 0x7f0f0010;

        /* JADX INFO: Added by JADX */
        public static final int abc_prepend_shortcut_label = 0x7f0f0011;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_hint = 0x7f0f0012;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_clear = 0x7f0f0013;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_query = 0x7f0f0014;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_search = 0x7f0f0015;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_submit = 0x7f0f0016;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_voice = 0x7f0f0017;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with = 0x7f0f0018;

        /* JADX INFO: Added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 0x7f0f0019;

        /* JADX INFO: Added by JADX */
        public static final int abc_toolbar_collapse_description = 0x7f0f001a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f0f001b;

        /* JADX INFO: Added by JADX */
        public static final int appbar_scrolling_view_behavior = 0x7f0f001d;

        /* JADX INFO: Added by JADX */
        public static final int bottom_sheet_behavior = 0x7f0f001e;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_collapse = 0x7f0f001f;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_collapse_description = 0x7f0f0020;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_expand = 0x7f0f0021;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_expand_description = 0x7f0f0022;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_expand_halfway = 0x7f0f0023;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_half_expand_description = 0x7f0f0024;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_drag_handle_content_description = 0x7f0f0025;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_state_collapsed = 0x7f0f0026;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_state_expanded = 0x7f0f0027;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_state_half_expanded = 0x7f0f0028;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 0x7f0f0029;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 0x7f0f002a;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 0x7f0f002b;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 0x7f0f002c;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 0x7f0f002d;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 0x7f0f002e;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 0x7f0f002f;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_content_description = 0x7f0f0030;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_overflowed_content_description = 0x7f0f0031;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_pattern = 0x7f0f0032;

        /* JADX INFO: Added by JADX */
        public static final int clear_text_end_icon_content_description = 0x7f0f0033;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_button = 0x7f0f0034;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_text = 0x7f0f0035;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_title = 0x7f0f0036;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_button = 0x7f0f0037;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_text = 0x7f0f0038;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_title = 0x7f0f0039;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_channel_name = 0x7f0f003a;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_ticker = 0x7f0f003b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unknown_issue = 0x7f0f003c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unsupported_text = 0x7f0f003d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_button = 0x7f0f003e;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_text = 0x7f0f003f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_title = 0x7f0f0040;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_updating_text = 0x7f0f0041;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_wear_update_text = 0x7f0f0042;

        /* JADX INFO: Added by JADX */
        public static final int common_open_on_phone = 0x7f0f0043;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text = 0x7f0f0044;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text_long = 0x7f0f0045;

        /* JADX INFO: Added by JADX */
        public static final int error_a11y_label = 0x7f0f0046;

        /* JADX INFO: Added by JADX */
        public static final int error_icon_content_description = 0x7f0f0047;

        /* JADX INFO: Added by JADX */
        public static final int exposed_dropdown_menu_content_description = 0x7f0f0048;

        /* JADX INFO: Added by JADX */
        public static final int fab_transformation_scrim_behavior = 0x7f0f0049;

        /* JADX INFO: Added by JADX */
        public static final int fab_transformation_sheet_behavior = 0x7f0f004a;

        /* JADX INFO: Added by JADX */
        public static final int hide_bottom_view_on_scroll_behavior = 0x7f0f004b;

        /* JADX INFO: Added by JADX */
        public static final int icon_content_description = 0x7f0f004c;

        /* JADX INFO: Added by JADX */
        public static final int item_view_role_description = 0x7f0f004d;

        /* JADX INFO: Added by JADX */
        public static final int m3_exceed_max_badge_text_suffix = 0x7f0f004e;

        /* JADX INFO: Added by JADX */
        public static final int m3_loading_indicator_content_description = 0x7f0f004f;

        /* JADX INFO: Added by JADX */
        public static final int m3_overflow_linear_layout_button_content_description = 0x7f0f0050;

        /* JADX INFO: Added by JADX */
        public static final int m3_overflow_linear_layout_button_tooltip_text = 0x7f0f0051;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_brand_medium = 0x7f0f0052;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_brand_regular = 0x7f0f0053;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_plain_medium = 0x7f0f0054;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_plain_regular = 0x7f0f0055;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized = 0x7f0f0056;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate = 0x7f0f0057;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate = 0x7f0f0058;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_path_data = 0x7f0f0059;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy = 0x7f0f005a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate = 0x7f0f005b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate = 0x7f0f005c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear = 0x7f0f005d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard = 0x7f0f005e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate = 0x7f0f005f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate = 0x7f0f0060;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_divider = 0x7f0f0061;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_toggle_content_description = 0x7f0f0062;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_24h_suffix = 0x7f0f0063;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_selection = 0x7f0f0064;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_suffix = 0x7f0f0065;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_selection = 0x7f0f0066;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_suffix = 0x7f0f0067;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_accelerated = 0x7f0f0068;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_decelerated = 0x7f0f0069;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_emphasized = 0x7f0f006a;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_linear = 0x7f0f006b;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_standard = 0x7f0f006c;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_range_end = 0x7f0f006d;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_range_start = 0x7f0f006e;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_value = 0x7f0f006f;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_am = 0x7f0f0070;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clock_mode_description = 0x7f0f0071;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clock_mode_tooltip = 0x7f0f0072;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_hour = 0x7f0f0073;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_hour_error = 0x7f0f0074;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_hour_error_24h = 0x7f0f0075;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_minute = 0x7f0f0076;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_minute_error = 0x7f0f0077;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_pm = 0x7f0f0078;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_select_time = 0x7f0f0079;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_text_input_mode_description = 0x7f0f007a;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_text_input_mode_tooltip = 0x7f0f007b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_numberless_content_description = 0x7f0f007c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_button_collapsed_content_description = 0x7f0f007d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_button_expanded_content_description = 0x7f0f007e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_button_overflow_icon_content_description = 0x7f0f007f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_button_snackbar_close_content_description = 0x7f0f0080;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_checked = 0x7f0f0081;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_group_name = 0x7f0f0082;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_indeterminate = 0x7f0f0083;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_name = 0x7f0f0084;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_checked = 0x7f0f0085;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_group_name = 0x7f0f0086;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_name = 0x7f0f0087;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_unchecked = 0x7f0f0088;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_checked = 0x7f0f0089;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_indeterminate = 0x7f0f008a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_unchecked = 0x7f0f008b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_close_icon_content_description = 0x7f0f008c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exceed_max_badge_number_content_description = 0x7f0f008d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exceed_max_badge_number_suffix = 0x7f0f008e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_a11y_next_month = 0x7f0f008f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_a11y_prev_month = 0x7f0f0090;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_range_selection = 0x7f0f0091;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_selection = 0x7f0f0092;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_selection_none = 0x7f0f0093;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_cancel = 0x7f0f0094;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_confirm = 0x7f0f0095;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_selected = 0x7f0f0096;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_title = 0x7f0f0097;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_unselected = 0x7f0f0098;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_day_of_week_column_header = 0x7f0f0099;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_end_date_description = 0x7f0f009a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format = 0x7f0f009b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format_example = 0x7f0f009c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format_use = 0x7f0f009d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_range = 0x7f0f009e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_navigate_to_current_year_description = 0x7f0f009f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_navigate_to_year_description = 0x7f0f00a0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_next_month_tooltip = 0x7f0f00a1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_out_of_range = 0x7f0f00a2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_pane_title_calendar_view = 0x7f0f00a3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_pane_title_year_view = 0x7f0f00a4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_prev_month_tooltip = 0x7f0f00a5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_only_end_selected = 0x7f0f00a6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_only_start_selected = 0x7f0f00a7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_selected = 0x7f0f00a8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_title = 0x7f0f00a9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_unselected = 0x7f0f00aa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_save = 0x7f0f00ab;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_start_date_description = 0x7f0f00ac;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_hint = 0x7f0f00ad;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range_end_hint = 0x7f0f00ae;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range_start_hint = 0x7f0f00af;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_day_abbr = 0x7f0f00b0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_month_abbr = 0x7f0f00b1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_year_abbr = 0x7f0f00b2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_today_description = 0x7f0f00b3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_calendar_input_mode = 0x7f0f00b4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_calendar_input_mode_tooltip = 0x7f0f00b5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_day_selection = 0x7f0f00b6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_text_input_mode = 0x7f0f00b7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_text_input_mode_tooltip = 0x7f0f00b8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_year_selection = 0x7f0f00b9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_group_name = 0x7f0f00ba;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_checked = 0x7f0f00bb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_morphing = 0x7f0f00bc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_name = 0x7f0f00bd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_pressed = 0x7f0f00be;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_unchecked = 0x7f0f00bf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration_path = 0x7f0f00c0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_path = 0x7f0f00c1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_timepicker_cancel = 0x7f0f00c2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_timepicker_confirm = 0x7f0f00c3;

        /* JADX INFO: Added by JADX */
        public static final int nav_rail_collapsed_a11y_label = 0x7f0f00c4;

        /* JADX INFO: Added by JADX */
        public static final int nav_rail_expanded_a11y_label = 0x7f0f00c5;

        /* JADX INFO: Added by JADX */
        public static final int password_toggle_content_description = 0x7f0f00c6;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye = 0x7f0f00c7;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye_mask_strike_through = 0x7f0f00c8;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye_mask_visible = 0x7f0f00c9;

        /* JADX INFO: Added by JADX */
        public static final int path_password_strike_through = 0x7f0f00ca;

        /* JADX INFO: Added by JADX */
        public static final int search_menu_title = 0x7f0f00cb;

        /* JADX INFO: Added by JADX */
        public static final int searchbar_scrolling_view_behavior = 0x7f0f00cc;

        /* JADX INFO: Added by JADX */
        public static final int searchview_clear_text_content_description = 0x7f0f00cd;

        /* JADX INFO: Added by JADX */
        public static final int searchview_navigation_content_description = 0x7f0f00ce;

        /* JADX INFO: Added by JADX */
        public static final int side_sheet_accessibility_pane_title = 0x7f0f00cf;

        /* JADX INFO: Added by JADX */
        public static final int side_sheet_behavior = 0x7f0f00d0;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 0x7f0f00d1;

        private string() {
        }
    }

    public static final class style {
        public static final int Theme_Dbasic12 = 0x7f1002a7;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat = 0x7f100000;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat_Light = 0x7f100001;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Dialog = 0x7f100002;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 0x7f100003;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Tooltip = 0x7f100004;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Design_BottomSheetDialog = 0x7f100005;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_BottomSheetDialog = 0x7f100006;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog = 0x7f100007;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog_Left = 0x7f100008;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog_Right = 0x7f100009;

        /* JADX INFO: Added by JADX */
        public static final int Animation_MaterialComponents_BottomSheetDialog = 0x7f10000a;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat = 0x7f10000b;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 0x7f10000c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 0x7f10000d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 0x7f10000e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 0x7f10000f;

        /* JADX INFO: Added by JADX */
        public static final int Base_CardView = 0x7f100010;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 0x7f100011;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 0x7f100012;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f100013;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f100014;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f100015;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat = 0x7f100016;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f100017;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f100018;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f100019;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f10001a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f10001b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f10001c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f10001d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f10001e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f10001f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f100020;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f100021;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f100022;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f100023;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f100024;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f100025;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f100026;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f100027;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 0x7f100028;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f100029;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f10002a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f10002b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f10002c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f10002d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f10002e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f10002f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f100030;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 0x7f100031;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f100032;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f100033;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f100034;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f100035;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f100036;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f100037;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f100038;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 0x7f100039;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f10003a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 0x7f10003b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f10003c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f10003d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f10003e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f10003f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f100040;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f100041;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f100042;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Material3_Search = 0x7f100043;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Button = 0x7f100044;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Headline6 = 0x7f100045;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Subtitle2 = 0x7f100046;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f100047;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f100048;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f100049;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat = 0x7f10004a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f10004b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 0x7f10004c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 0x7f10004d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f10004e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f10004f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f100050;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light = 0x7f100051;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f100052;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f100053;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f100054;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f100055;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f100056;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f100057;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark = 0x7f100058;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark_BottomSheetDialog = 0x7f100059;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark_Dialog = 0x7f10005a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark_Dialog_FixedSize = 0x7f10005b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark_DialogWhenLarge = 0x7f10005c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Dark_SideSheetDialog = 0x7f10005d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light = 0x7f10005e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light_BottomSheetDialog = 0x7f10005f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light_Dialog = 0x7f100060;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light_Dialog_FixedSize = 0x7f100061;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light_DialogWhenLarge = 0x7f100062;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light_SideSheetDialog = 0x7f100063;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Dark = 0x7f100064;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Dark_Dialog = 0x7f100065;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Dark_Dialog_FixedSize = 0x7f100066;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Dark_DialogWhenLarge = 0x7f100067;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Light = 0x7f100068;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Light_Dialog = 0x7f100069;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Light_Dialog_FixedSize = 0x7f10006a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3Expressive_Light_DialogWhenLarge = 0x7f10006b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents = 0x7f10006c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Bridge = 0x7f10006d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_CompactMenu = 0x7f10006e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog = 0x7f10006f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_Alert = 0x7f100070;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_Bridge = 0x7f100071;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_FixedSize = 0x7f100072;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_MinWidth = 0x7f100073;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_DialogWhenLarge = 0x7f100074;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light = 0x7f100075;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Bridge = 0x7f100076;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar = 0x7f100077;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f100078;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog = 0x7f100079;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Alert = 0x7f10007a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f10007b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f10007c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f10007d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f10007e;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 0x7f10007f;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f100080;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f100081;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f100082;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 0x7f100083;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 0x7f100084;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f100085;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_AutoCompleteTextView = 0x7f100086;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_BottomSheetDialog = 0x7f100087;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_Dialog = 0x7f100088;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_SideSheetDialog = 0x7f100089;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_TextInputEditText = 0x7f10008a;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3Expressive_Dialog = 0x7f10008b;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog = 0x7f10008c;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f10008d;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f10008e;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f10008f;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f100090;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Dark = 0x7f100091;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Dark_BottomSheetDialog = 0x7f100092;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Dark_Dialog = 0x7f100093;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Dark_SideSheetDialog = 0x7f100094;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Light = 0x7f100095;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Light_BottomSheetDialog = 0x7f100096;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Light_Dialog = 0x7f100097;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Light_SideSheetDialog = 0x7f100098;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents = 0x7f100099;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Bridge = 0x7f10009a;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Dialog = 0x7f10009b;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Dialog_Bridge = 0x7f10009c;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light = 0x7f10009d;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Bridge = 0x7f10009e;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f10009f;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog = 0x7f1000a0;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f1000a1;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_Material3_BottomSheetDialog = 0x7f1000a2;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_Material3_SideSheetDialog = 0x7f1000a3;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog = 0x7f1000a4;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f1000a5;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f1000a6;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Widget_MaterialComponents_AutoCompleteTextView = 0x7f1000a7;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat = 0x7f1000a8;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f1000a9;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f1000aa;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f1000ab;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents = 0x7f1000ac;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Dialog = 0x7f1000ad;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Light = 0x7f1000ae;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Light_Dialog = 0x7f1000af;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 0x7f1000b0;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_Material3_BottomSheetDialog = 0x7f1000b1;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_Material3_SideSheetDialog = 0x7f1000b2;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat = 0x7f1000b3;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 0x7f1000b4;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat = 0x7f1000b5;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 0x7f1000b6;

        /* JADX INFO: Added by JADX */
        public static final int Base_V24_Theme_Material3_Dark = 0x7f1000b7;

        /* JADX INFO: Added by JADX */
        public static final int Base_V24_Theme_Material3_Dark_Dialog = 0x7f1000b8;

        /* JADX INFO: Added by JADX */
        public static final int Base_V24_Theme_Material3_Light = 0x7f1000b9;

        /* JADX INFO: Added by JADX */
        public static final int Base_V24_Theme_Material3_Light_Dialog = 0x7f1000ba;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat = 0x7f1000bb;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 0x7f1000bc;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 0x7f1000bd;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat = 0x7f1000be;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 0x7f1000bf;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat = 0x7f1000c0;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f1000c1;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f1000c2;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f1000c3;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 0x7f1000c4;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 0x7f1000c5;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 0x7f1000c6;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 0x7f1000c7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f1000c8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f1000c9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f1000ca;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f1000cb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f1000cc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f1000cd;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f1000ce;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f1000cf;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f1000d0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f1000d1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f1000d2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button = 0x7f1000d3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 0x7f1000d4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f1000d5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f1000d6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 0x7f1000d7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 0x7f1000d8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 0x7f1000d9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f1000da;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f1000db;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f1000dc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f1000dd;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f1000de;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f1000df;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f1000e0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 0x7f1000e1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 0x7f1000e2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f1000e3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f1000e4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f1000e5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f1000e6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f1000e7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f1000e8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f1000e9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f1000ea;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 0x7f1000eb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f1000ec;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 0x7f1000ed;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f1000ee;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f1000ef;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f1000f0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f1000f1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 0x7f1000f2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 0x7f1000f3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f1000f4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 0x7f1000f5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 0x7f1000f6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 0x7f1000f7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 0x7f1000f8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f1000f9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 0x7f1000fa;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 0x7f1000fb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 0x7f1000fc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 0x7f1000fd;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 0x7f1000fe;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f1000ff;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f100100;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f100101;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Design_TabLayout = 0x7f100102;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ActionBar_Solid = 0x7f100103;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ActionMode = 0x7f100104;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_BottomNavigationView = 0x7f100105;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CardView = 0x7f100106;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Chip = 0x7f100107;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CollapsingToolbar = 0x7f100108;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_CheckBox = 0x7f100109;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_RadioButton = 0x7f10010a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_Switch = 0x7f10010b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_DockedToolbar = 0x7f10010c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton = 0x7f10010d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton_Icon = 0x7f10010e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton_Large = 0x7f10010f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton_Medium = 0x7f100110;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton_Small = 0x7f100111;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton = 0x7f100112;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton_Large = 0x7f100113;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton_Medium = 0x7f100114;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton_Small = 0x7f100115;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingToolbar = 0x7f100116;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Light_ActionBar_Solid = 0x7f100117;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_MaterialCalendar_NavigationButton = 0x7f100118;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Snackbar = 0x7f100119;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_TabLayout = 0x7f10011a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_TabLayout_OnSurface = 0x7f10011b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_TabLayout_Secondary = 0x7f10011c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_AutoCompleteTextView = 0x7f10011d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_CheckedTextView = 0x7f10011e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Chip = 0x7f10011f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f100120;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_MaterialCalendar_NavigationButton = 0x7f100121;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu = 0x7f100122;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f100123;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f100124;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_Overflow = 0x7f100125;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Slider = 0x7f100126;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Snackbar = 0x7f100127;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextInputEditText = 0x7f100128;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextInputLayout = 0x7f100129;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextView = 0x7f10012a;

        /* JADX INFO: Added by JADX */
        public static final int CardView = 0x7f10012b;

        /* JADX INFO: Added by JADX */
        public static final int CardView_Dark = 0x7f10012c;

        /* JADX INFO: Added by JADX */
        public static final int CardView_Light = 0x7f10012d;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3 = 0x7f10012e;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Animation = 0x7f10012f;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Body_Text = 0x7f100130;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Body_Text_CenterStacked = 0x7f100131;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Icon = 0x7f100132;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Icon_CenterStacked = 0x7f100133;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Panel = 0x7f100134;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Panel_CenterStacked = 0x7f100135;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Text = 0x7f100136;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Text_CenterStacked = 0x7f100137;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3Expressive = 0x7f100138;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3Expressive_Title_Panel = 0x7f100139;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3Expressive_Title_Panel_CenterStacked = 0x7f10013a;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3Expressive_Title_Text = 0x7f10013b;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3Expressive_Title_Text_CenterStacked = 0x7f10013c;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents = 0x7f10013d;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Body_Text = 0x7f10013e;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Picker_Date_Calendar = 0x7f10013f;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Picker_Date_Spinner = 0x7f100140;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f100141;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Icon_CenterStacked = 0x7f100142;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f100143;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Panel_CenterStacked = 0x7f100144;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f100145;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Text_CenterStacked = 0x7f100146;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Default_Effects = 0x7f100147;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Default_Spatial = 0x7f100148;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Fast_Effects = 0x7f100149;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Fast_Spatial = 0x7f10014a;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Slow_Effects = 0x7f10014b;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Expressive_Slow_Spatial = 0x7f10014c;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Default_Effects = 0x7f10014d;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Default_Spatial = 0x7f10014e;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Fast_Effects = 0x7f10014f;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Fast_Spatial = 0x7f100150;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Slow_Effects = 0x7f100151;

        /* JADX INFO: Added by JADX */
        public static final int Motion_Material3_Spring_Standard_Slow_Spatial = 0x7f100152;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat = 0x7f100153;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat_Light = 0x7f100154;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents = 0x7f100155;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Dialog = 0x7f100156;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Light = 0x7f100157;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Light_Dialog = 0x7f100158;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 0x7f100159;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 0x7f10015a;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 0x7f10015b;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat = 0x7f10015c;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V21_AppCompat_Light = 0x7f10015d;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat = 0x7f10015e;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat_Light = 0x7f10015f;

        /* JADX INFO: Added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 0x7f100160;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f100161;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f100162;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 0x7f100163;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f100164;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f100165;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 0x7f100166;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 0x7f100167;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f100168;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 0x7f100169;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f10016a;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f10016b;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f10016c;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f10016d;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f10016e;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f10016f;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 0x7f100170;

        /* JADX INFO: Added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 0x7f100171;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_AppBar_Small_Search_Container_Shape = 0x7f100172;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Badge_Large_Shape = 0x7f100173;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Badge_Shape = 0x7f100174;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_BottomAppBar_Container_Shape = 0x7f100175;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Large_Container_Shape_Round = 0x7f100176;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Large_Selected_Container_Shape_Square = 0x7f100177;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Medium_Container_Shape_Round = 0x7f100178;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Medium_Selected_Container_Shape_Square = 0x7f100179;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Small_Container_Shape_Round = 0x7f10017a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Small_Selected_Container_Shape_Square = 0x7f10017b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Xlarge_Container_Shape_Round = 0x7f10017c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Xlarge_Selected_Container_Shape_Square = 0x7f10017d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Xsmall_Container_Shape_Round = 0x7f10017e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Button_Xsmall_Selected_Container_Shape_Square = 0x7f10017f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_ButtonGroup_Connected_Small_Container_Shape = 0x7f100180;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_DatePicker_Modal_Date_Container_Shape = 0x7f100181;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Large_Container_Shape_Round = 0x7f100182;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Large_Selected_Container_Shape_Square = 0x7f100183;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Medium_Container_Shape_Round = 0x7f100184;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Medium_Selected_Container_Shape_Square = 0x7f100185;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Small_Container_Shape_Round = 0x7f100186;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Small_Selected_Container_Shape_Square = 0x7f100187;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Xlarge_Container_Shape_Round = 0x7f100188;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Xlarge_Selected_Container_Shape_Square = 0x7f100189;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Xsmall_Container_Shape_Round = 0x7f10018a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_IconButton_Xsmall_Selected_Container_Shape_Square = 0x7f10018b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavBar_Container_Shape = 0x7f10018c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavBar_Item_ActiveIndicator_Shape = 0x7f10018d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavRail_Collapsed_Container_Shape = 0x7f10018e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavRail_Expanded_Container_Shape = 0x7f10018f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavRail_Item_ActiveIndicator_Shape = 0x7f100190;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavigationDrawer_ActiveIndicator_Shape = 0x7f100191;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchBar_Avatar_Shape = 0x7f100192;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchBar_Container_Shape = 0x7f100193;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchView_Contained_Docked_Bar_Shape = 0x7f100194;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchView_FullScreen_Container_Shape = 0x7f100195;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Sheet_Side_Docked_Container_Shape = 0x7f100196;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Switch_Handle_Shape = 0x7f100197;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Switch_StateLayer_Shape = 0x7f100198;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Switch_Track_Shape = 0x7f100199;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Toolbar_Docked_Container_Shape = 0x7f10019a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Toolbar_Floating_Container_Shape = 0x7f10019b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraExtraLarge = 0x7f10019c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraLarge = 0x7f10019d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraLargeIncreased = 0x7f10019e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraSmall = 0x7f10019f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Full = 0x7f1001a0;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Large = 0x7f1001a1;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_LargeIncreased = 0x7f1001a2;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Medium = 0x7f1001a3;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_None = 0x7f1001a4;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Small = 0x7f1001a5;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraExtraLarge = 0x7f1001a6;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraLarge = 0x7f1001a7;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraLargeIncreased = 0x7f1001a8;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraSmall = 0x7f1001a9;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Full = 0x7f1001aa;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Large = 0x7f1001ab;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_LargeIncreased = 0x7f1001ac;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Medium = 0x7f1001ad;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_None = 0x7f1001ae;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Small = 0x7f1001af;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_LargeComponent = 0x7f1001b0;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_ListItem_Checked = 0x7f1001b1;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_ListItem_First = 0x7f1001b2;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_ListItem_Last = 0x7f1001b3;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_ListItem_Middle = 0x7f1001b4;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_ListItem_Single = 0x7f1001b5;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_MediumComponent = 0x7f1001b6;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_NavigationBarView_ActiveIndicator = 0x7f1001b7;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_SmallComponent = 0x7f1001b8;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Tooltip = 0x7f1001b9;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents = 0x7f1001ba;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_Badge = 0x7f1001bb;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_LargeComponent = 0x7f1001bc;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_MediumComponent = 0x7f1001bd;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_SmallComponent = 0x7f1001be;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_Tooltip = 0x7f1001bf;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Button = 0x7f1001c0;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Chip = 0x7f1001c1;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Corner_Bottom = 0x7f1001c2;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Corner_Left = 0x7f1001c3;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Corner_Right = 0x7f1001c4;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Corner_Top = 0x7f1001c5;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_FloatingActionButton = 0x7f1001c6;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_NavigationView_Item = 0x7f1001c7;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_SearchBar = 0x7f1001c8;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_SearchView = 0x7f1001c9;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialAlertDialog_Material3 = 0x7f1001ca;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_BottomSheet = 0x7f1001cb;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_Chip = 0x7f1001cc;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_ExtendedFloatingActionButton = 0x7f1001cd;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_FloatingActionButton = 0x7f1001ce;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day = 0x7f1001cf;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Window_Fullscreen = 0x7f1001d0;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Year = 0x7f1001d1;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_TextInputLayout_FilledBox = 0x7f1001d2;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large = 0x7f1001d3;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large_Narrow = 0x7f1001d4;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large_Narrow_Square = 0x7f1001d5;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large_Square = 0x7f1001d6;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large_Wide = 0x7f1001d7;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Large_Wide_Square = 0x7f1001d8;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium = 0x7f1001d9;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium_Narrow = 0x7f1001da;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium_Narrow_Square = 0x7f1001db;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium_Square = 0x7f1001dc;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium_Wide = 0x7f1001dd;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Medium_Wide_Square = 0x7f1001de;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small = 0x7f1001df;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small_Narrow = 0x7f1001e0;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small_Narrow_Square = 0x7f1001e1;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small_Square = 0x7f1001e2;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small_Wide = 0x7f1001e3;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Small_Wide_Square = 0x7f1001e4;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge = 0x7f1001e5;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge_Narrow = 0x7f1001e6;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge_Narrow_Square = 0x7f1001e7;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge_Square = 0x7f1001e8;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge_Wide = 0x7f1001e9;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xlarge_Wide_Square = 0x7f1001ea;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall = 0x7f1001eb;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall_Narrow = 0x7f1001ec;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall_Narrow_Square = 0x7f1001ed;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall_Square = 0x7f1001ee;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall_Wide = 0x7f1001ef;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_IconButton_Xsmall_Wide_Square = 0x7f1001f0;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Large = 0x7f1001f1;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Large_Square = 0x7f1001f2;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Medium = 0x7f1001f3;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Medium_Square = 0x7f1001f4;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Small = 0x7f1001f5;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Small_Square = 0x7f1001f6;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Xlarge = 0x7f1001f7;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Xlarge_Square = 0x7f1001f8;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Xsmall = 0x7f1001f9;

        /* JADX INFO: Added by JADX */
        public static final int SizeOverlay_Material3Expressive_Button_Xsmall_Square = 0x7f1001fa;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat = 0x7f1001fb;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 0x7f1001fc;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 0x7f1001fd;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Button = 0x7f1001fe;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 0x7f1001ff;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 0x7f100200;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 0x7f100201;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 0x7f100202;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 0x7f100203;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 0x7f100204;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 0x7f100205;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large = 0x7f100206;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f100207;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f100208;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f100209;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f10020a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f10020b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 0x7f10020c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f10020d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 0x7f10020e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f10020f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f100210;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small = 0x7f100211;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f100212;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 0x7f100213;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f100214;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title = 0x7f100215;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f100216;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 0x7f100217;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f100218;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f100219;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f10021a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f10021b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f10021c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f10021d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f10021e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f10021f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f100220;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 0x7f100221;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f100222;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 0x7f100223;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f100224;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f100225;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f100226;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f100227;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f100228;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f100229;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f10022a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 0x7f10022b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 0x7f10022c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f10022d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 0x7f10022e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 0x7f10022f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_CollapsingToolbar_Expanded = 0x7f100230;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Counter = 0x7f100231;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Counter_Overflow = 0x7f100232;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Error = 0x7f100233;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_HelperText = 0x7f100234;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Hint = 0x7f100235;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Placeholder = 0x7f100236;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Prefix = 0x7f100237;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Snackbar_Message = 0x7f100238;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Suffix = 0x7f100239;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Tab = 0x7f10023a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyLarge = 0x7f10023b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyLarge_Emphasized = 0x7f10023c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyMedium = 0x7f10023d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyMedium_Emphasized = 0x7f10023e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodySmall = 0x7f10023f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodySmall_Emphasized = 0x7f100240;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayLarge = 0x7f100241;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayLarge_Emphasized = 0x7f100242;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayMedium = 0x7f100243;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayMedium_Emphasized = 0x7f100244;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplaySmall = 0x7f100245;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplaySmall_Emphasized = 0x7f100246;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineLarge = 0x7f100247;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineLarge_Emphasized = 0x7f100248;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineMedium = 0x7f100249;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineMedium_Emphasized = 0x7f10024a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineSmall = 0x7f10024b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineSmall_Emphasized = 0x7f10024c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelLarge = 0x7f10024d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelLarge_Emphasized = 0x7f10024e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelMedium = 0x7f10024f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelMedium_Emphasized = 0x7f100250;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelSmall = 0x7f100251;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelSmall_Emphasized = 0x7f100252;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleLarge = 0x7f100253;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleLarge_Emphasized = 0x7f100254;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleMedium = 0x7f100255;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleMedium_Emphasized = 0x7f100256;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleSmall = 0x7f100257;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleSmall_Emphasized = 0x7f100258;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_ActionBar_Subtitle = 0x7f100259;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_ActionBar_Title = 0x7f10025a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyLarge = 0x7f10025b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyLarge_Emphasized = 0x7f10025c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyMedium = 0x7f10025d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyMedium_Emphasized = 0x7f10025e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodySmall = 0x7f10025f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodySmall_Emphasized = 0x7f100260;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayLarge = 0x7f100261;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayLarge_Emphasized = 0x7f100262;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayMedium = 0x7f100263;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayMedium_Emphasized = 0x7f100264;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplaySmall = 0x7f100265;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplaySmall_Emphasized = 0x7f100266;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineLarge = 0x7f100267;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineLarge_Emphasized = 0x7f100268;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineMedium = 0x7f100269;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineMedium_Emphasized = 0x7f10026a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineSmall = 0x7f10026b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineSmall_Emphasized = 0x7f10026c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelLarge = 0x7f10026d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelLarge_Emphasized = 0x7f10026e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelMedium = 0x7f10026f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelMedium_Emphasized = 0x7f100270;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelSmall = 0x7f100271;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelSmall_Emphasized = 0x7f100272;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_MaterialTimePicker_Title = 0x7f100273;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchBar = 0x7f100274;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchView = 0x7f100275;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchView_Prefix = 0x7f100276;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleLarge = 0x7f100277;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleLarge_Emphasized = 0x7f100278;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleMedium = 0x7f100279;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleMedium_Emphasized = 0x7f10027a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleSmall = 0x7f10027b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleSmall_Emphasized = 0x7f10027c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Badge = 0x7f10027d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Body1 = 0x7f10027e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Body2 = 0x7f10027f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Button = 0x7f100280;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Caption = 0x7f100281;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Chip = 0x7f100282;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline1 = 0x7f100283;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline2 = 0x7f100284;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline3 = 0x7f100285;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline4 = 0x7f100286;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline5 = 0x7f100287;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline6 = 0x7f100288;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Overline = 0x7f100289;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Subtitle1 = 0x7f10028a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Subtitle2 = 0x7f10028b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_TimePicker_Title = 0x7f10028c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Tooltip = 0x7f10028d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f10028e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f10028f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f100290;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat = 0x7f100291;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 0x7f100292;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight = 0x7f100293;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 0x7f100294;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 0x7f100295;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 0x7f100296;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 0x7f100297;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 0x7f100298;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 0x7f100299;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog = 0x7f10029a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 0x7f10029b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 0x7f10029c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f10029d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Empty = 0x7f10029e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light = 0x7f10029f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f1002a0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 0x7f1002a1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 0x7f1002a2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f1002a3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f1002a4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f1002a5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 0x7f1002a6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design = 0x7f1002a8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_BottomSheetDialog = 0x7f1002a9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_Light = 0x7f1002aa;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_Light_BottomSheetDialog = 0x7f1002ab;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_Light_NoActionBar = 0x7f1002ac;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_NoActionBar = 0x7f1002ad;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark = 0x7f1002ae;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_BottomSheetDialog = 0x7f1002af;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog = 0x7f1002b0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog_Alert = 0x7f1002b1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog_Alert_FocusRings = 0x7f1002b2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog_FocusRings = 0x7f1002b3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog_MinWidth = 0x7f1002b4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_Dialog_MinWidth_FocusRings = 0x7f1002b5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_DialogWhenLarge = 0x7f1002b6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_FocusRings = 0x7f1002b7;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_NoActionBar = 0x7f1002b8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_NoActionBar_FocusRings = 0x7f1002b9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Dark_SideSheetDialog = 0x7f1002ba;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight = 0x7f1002bb;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_BottomSheetDialog = 0x7f1002bc;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog = 0x7f1002bd;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog_Alert = 0x7f1002be;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog_Alert_FocusRings = 0x7f1002bf;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog_FocusRings = 0x7f1002c0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog_MinWidth = 0x7f1002c1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_Dialog_MinWidth_FocusRings = 0x7f1002c2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_DialogWhenLarge = 0x7f1002c3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_FocusRings = 0x7f1002c4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_NoActionBar = 0x7f1002c5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_NoActionBar_FocusRings = 0x7f1002c6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DayNight_SideSheetDialog = 0x7f1002c7;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Dark = 0x7f1002c8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Dark_FocusRings = 0x7f1002c9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Dark_NoActionBar = 0x7f1002ca;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Dark_NoActionBar_FocusRings = 0x7f1002cb;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_DayNight = 0x7f1002cc;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_DayNight_FocusRings = 0x7f1002cd;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_DayNight_NoActionBar = 0x7f1002ce;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_DayNight_NoActionBar_FocusRings = 0x7f1002cf;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Light = 0x7f1002d0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Light_FocusRings = 0x7f1002d1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Light_NoActionBar = 0x7f1002d2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_DynamicColors_Light_NoActionBar_FocusRings = 0x7f1002d3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light = 0x7f1002d4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_BottomSheetDialog = 0x7f1002d5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog = 0x7f1002d6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog_Alert = 0x7f1002d7;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog_Alert_FocusRings = 0x7f1002d8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog_FocusRings = 0x7f1002d9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog_MinWidth = 0x7f1002da;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_Dialog_MinWidth_FocusRings = 0x7f1002db;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_DialogWhenLarge = 0x7f1002dc;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_FocusRings = 0x7f1002dd;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_NoActionBar = 0x7f1002de;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_NoActionBar_FocusRings = 0x7f1002df;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_SideSheetDialog = 0x7f1002e0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark = 0x7f1002e1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog = 0x7f1002e2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog_Alert = 0x7f1002e3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog_Alert_FocusRings = 0x7f1002e4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog_FocusRings = 0x7f1002e5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog_MinWidth = 0x7f1002e6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_Dialog_MinWidth_FocusRings = 0x7f1002e7;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_DialogWhenLarge = 0x7f1002e8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_FocusRings = 0x7f1002e9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_NoActionBar = 0x7f1002ea;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Dark_NoActionBar_FocusRings = 0x7f1002eb;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight = 0x7f1002ec;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog = 0x7f1002ed;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog_Alert = 0x7f1002ee;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog_Alert_FocusRings = 0x7f1002ef;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog_FocusRings = 0x7f1002f0;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog_MinWidth = 0x7f1002f1;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_Dialog_MinWidth_FocusRings = 0x7f1002f2;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_DialogWhenLarge = 0x7f1002f3;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_FocusRings = 0x7f1002f4;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_NoActionBar = 0x7f1002f5;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DayNight_NoActionBar_FocusRings = 0x7f1002f6;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Dark = 0x7f1002f7;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Dark_FocusRings = 0x7f1002f8;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Dark_NoActionBar = 0x7f1002f9;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Dark_NoActionBar_FocusRings = 0x7f1002fa;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_DayNight = 0x7f1002fb;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_DayNight_FocusRings = 0x7f1002fc;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_DayNight_NoActionBar = 0x7f1002fd;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_DayNight_NoActionBar_FocusRings = 0x7f1002fe;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Light = 0x7f1002ff;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Light_FocusRings = 0x7f100300;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Light_NoActionBar = 0x7f100301;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_DynamicColors_Light_NoActionBar_FocusRings = 0x7f100302;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light = 0x7f100303;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog = 0x7f100304;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog_Alert = 0x7f100305;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog_Alert_FocusRings = 0x7f100306;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog_FocusRings = 0x7f100307;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog_MinWidth = 0x7f100308;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_Dialog_MinWidth_FocusRings = 0x7f100309;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_DialogWhenLarge = 0x7f10030a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_FocusRings = 0x7f10030b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_NoActionBar = 0x7f10030c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3Expressive_Light_NoActionBar_FocusRings = 0x7f10030d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents = 0x7f10030e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_BottomSheetDialog = 0x7f10030f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Bridge = 0x7f100310;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_CompactMenu = 0x7f100311;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight = 0x7f100312;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_BottomSheetDialog = 0x7f100313;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Bridge = 0x7f100314;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar = 0x7f100315;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar_Bridge = 0x7f100316;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar_FocusRings = 0x7f100317;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog = 0x7f100318;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert = 0x7f100319;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge = 0x7f10031a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert_FocusRings = 0x7f10031b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Bridge = 0x7f10031c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize = 0x7f10031d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge = 0x7f10031e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize_FocusRings = 0x7f10031f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FocusRings = 0x7f100320;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth = 0x7f100321;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge = 0x7f100322;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth_FocusRings = 0x7f100323;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DialogWhenLarge = 0x7f100324;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_FocusRings = 0x7f100325;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_NoActionBar = 0x7f100326;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_NoActionBar_Bridge = 0x7f100327;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_NoActionBar_FocusRings = 0x7f100328;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog = 0x7f100329;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Alert = 0x7f10032a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Alert_Bridge = 0x7f10032b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Alert_FocusRings = 0x7f10032c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Bridge = 0x7f10032d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FixedSize = 0x7f10032e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FixedSize_Bridge = 0x7f10032f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FixedSize_FocusRings = 0x7f100330;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FocusRings = 0x7f100331;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_MinWidth = 0x7f100332;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_MinWidth_Bridge = 0x7f100333;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_MinWidth_FocusRings = 0x7f100334;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DialogWhenLarge = 0x7f100335;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_FocusRings = 0x7f100336;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light = 0x7f100337;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_BottomSheetDialog = 0x7f100338;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Bridge = 0x7f100339;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DarkActionBar = 0x7f10033a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f10033b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DarkActionBar_FocusRings = 0x7f10033c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog = 0x7f10033d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Alert = 0x7f10033e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Alert_Bridge = 0x7f10033f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Alert_FocusRings = 0x7f100340;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f100341;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f100342;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge = 0x7f100343;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize_FocusRings = 0x7f100344;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FocusRings = 0x7f100345;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f100346;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge = 0x7f100347;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth_FocusRings = 0x7f100348;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f100349;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_FocusRings = 0x7f10034a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_NoActionBar = 0x7f10034b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_NoActionBar_Bridge = 0x7f10034c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_NoActionBar_FocusRings = 0x7f10034d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_NoActionBar = 0x7f10034e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_NoActionBar_Bridge = 0x7f10034f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_NoActionBar_FocusRings = 0x7f100350;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat = 0x7f100351;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f100352;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f100353;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f100354;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 0x7f100355;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 0x7f100356;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 0x7f100357;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 0x7f100358;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 0x7f100359;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_ClockFaceView = 0x7f10035a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Design_TextInputEditText = 0x7f10035b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material_FocusRings = 0x7f10035c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material_NoFocusRings = 0x7f10035d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3 = 0x7f10035e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ActionBar = 0x7f10035f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView = 0x7f100360;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_FilledBox = 0x7f100361;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_FilledBox_Dense = 0x7f100362;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_OutlinedBox = 0x7f100363;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_OutlinedBox_Dense = 0x7f100364;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomAppBar = 0x7f100365;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomAppBar_Legacy = 0x7f100366;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomNavigationView = 0x7f100367;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomSheetDialog = 0x7f100368;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button = 0x7f100369;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_ElevatedButton = 0x7f10036a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton = 0x7f10036b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton_Filled = 0x7f10036c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton_Filled_Tonal = 0x7f10036d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TextButton = 0x7f10036e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TextButton_Snackbar = 0x7f10036f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TonalButton = 0x7f100370;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_CheckBox = 0x7f100371;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Chip = 0x7f100372;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Chip_Assist = 0x7f100373;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dark = 0x7f100374;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dark_ActionBar = 0x7f100375;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DayNight_BottomSheetDialog = 0x7f100376;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DayNight_SideSheetDialog = 0x7f100377;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dialog = 0x7f100378;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dialog_Alert = 0x7f100379;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dialog_Alert_Framework = 0x7f10037a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DockedToolbar = 0x7f10037b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DockedToolbar_Vibrant = 0x7f10037c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DynamicColors_Dark = 0x7f10037d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DynamicColors_DayNight = 0x7f10037e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DynamicColors_Light = 0x7f10037f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Primary = 0x7f100380;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Secondary = 0x7f100381;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Surface = 0x7f100382;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Tertiary = 0x7f100383;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Primary = 0x7f100384;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Secondary = 0x7f100385;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Surface = 0x7f100386;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Tertiary = 0x7f100387;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingToolbar = 0x7f100388;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingToolbar_Vibrant = 0x7f100389;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_HarmonizedColors = 0x7f10038a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_HarmonizedColors_Empty = 0x7f10038b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Light = 0x7f10038c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Light_Dialog_Alert_Framework = 0x7f10038d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ListItemRevealLayout = 0x7f10038e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialAlertDialog = 0x7f10038f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialAlertDialog_Centered = 0x7f100390;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialButtonGroup_Overflow = 0x7f100391;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar = 0x7f100392;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar_Fullscreen = 0x7f100393;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar_HeaderCancelButton = 0x7f100394;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialSwitch = 0x7f100395;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialTimePicker = 0x7f100396;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f100397;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_NavigationRailView = 0x7f100398;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_NavigationView = 0x7f100399;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_OverflowLinearLayout = 0x7f10039a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_PersonalizedColors = 0x7f10039b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_RadioButton = 0x7f10039c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Search = 0x7f10039d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_SideSheetDialog = 0x7f10039e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Snackbar = 0x7f10039f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_SplitButton_IconButton_Filled = 0x7f1003a0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_SplitButton_IconButton_Filled_Tonal = 0x7f1003a1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TabLayout = 0x7f1003a2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText = 0x7f1003a3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_FilledBox = 0x7f1003a4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_FilledBox_Dense = 0x7f1003a5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_OutlinedBox = 0x7f1003a6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f1003a7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Toolbar = 0x7f1003a8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Toolbar_CircleNavigationButton = 0x7f1003a9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Toolbar_Surface = 0x7f1003aa;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive = 0x7f1003ab;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_AppBarWithSearch = 0x7f1003ac;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_Elevated = 0x7f1003ad;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_Filled = 0x7f1003ae;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_IconButton_Standard = 0x7f1003af;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_Outlined = 0x7f1003b0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_TextButton = 0x7f1003b1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_TextButton_Snackbar = 0x7f1003b2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Button_Tonal = 0x7f1003b3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Dark = 0x7f1003b4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Dialog = 0x7f1003b5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Dialog_Alert = 0x7f1003b6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Dialog_Alert_Framework = 0x7f1003b7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_DynamicColors_Dark = 0x7f1003b8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_DynamicColors_DayNight = 0x7f1003b9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_DynamicColors_Light = 0x7f1003ba;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_Primary = 0x7f1003bb;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_PrimaryContainer = 0x7f1003bc;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_Secondary = 0x7f1003bd;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_SecondaryContainer = 0x7f1003be;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_Tertiary = 0x7f1003bf;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_FloatingActionButton_TertiaryContainer = 0x7f1003c0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Light = 0x7f1003c1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Light_Dialog_Alert_Framework = 0x7f1003c2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_ListItemRevealLayout = 0x7f1003c3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_MaterialAlertDialog = 0x7f1003c4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_MaterialAlertDialog_Centered = 0x7f1003c5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_MaterialButtonGroup_Overflow = 0x7f1003c6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_SearchView_AppBarWithSearch = 0x7f1003c7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3Expressive_Toolbar_Surface = 0x7f1003c8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialAlertDialog_Material3_Title_Icon = 0x7f1003c9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents = 0x7f1003ca;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_ActionBar = 0x7f1003cb;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_ActionBar_Primary = 0x7f1003cc;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_ActionBar_Surface = 0x7f1003cd;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView = 0x7f1003ce;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f1003cf;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 0x7f1003d0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f1003d1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 0x7f1003d2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_BottomAppBar_Primary = 0x7f1003d3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_BottomAppBar_Surface = 0x7f1003d4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f1003d5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dark = 0x7f1003d6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dark_ActionBar = 0x7f1003d7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_DayNight_BottomSheetDialog = 0x7f1003d8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog = 0x7f1003d9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f1003da;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f1003db;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Light = 0x7f1003dc;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f1003dd;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f1003de;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Centered = 0x7f1003df;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date = 0x7f1003e0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Calendar = 0x7f1003e1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text = 0x7f1003e2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text_Day = 0x7f1003e3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Spinner = 0x7f1003e4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar = 0x7f1003e5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f1003e6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText = 0x7f1003e7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox = 0x7f1003e8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f1003e9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f1003ea;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f1003eb;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker = 0x7f1003ec;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker_Display = 0x7f1003ed;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f1003ee;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Toolbar_Popup_Primary = 0x7f1003ef;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Toolbar_Primary = 0x7f1003f0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Toolbar_Surface = 0x7f1003f1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar = 0x7f1003f2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f1003f3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f1003f4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f1003f5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f1003f6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton = 0x7f1003f7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f1003f8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f1003f9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionMode = 0x7f1003fa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f1003fb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f1003fc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button = 0x7f1003fd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 0x7f1003fe;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 0x7f1003ff;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f100400;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 0x7f100401;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Small = 0x7f100402;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 0x7f100403;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f100404;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 0x7f100405;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 0x7f100406;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f100407;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f100408;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f100409;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_EditText = 0x7f10040a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ImageButton = 0x7f10040b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f10040c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f10040d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f10040e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f10040f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f100410;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f100411;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f100412;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f100413;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f100414;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f100415;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f100416;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f100417;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f100418;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f100419;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f10041a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f10041b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f10041c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f10041d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f10041e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f10041f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 0x7f100420;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f100421;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 0x7f100422;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f100423;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView = 0x7f100424;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f100425;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 0x7f100426;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 0x7f100427;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f100428;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 0x7f100429;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 0x7f10042a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f10042b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar = 0x7f10042c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 0x7f10042d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 0x7f10042e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView = 0x7f10042f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 0x7f100430;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar = 0x7f100431;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 0x7f100432;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner = 0x7f100433;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f100434;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f100435;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 0x7f100436;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView = 0x7f100437;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 0x7f100438;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar = 0x7f100439;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f10043a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 0x7f10043b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 0x7f10043c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_AppBarLayout = 0x7f10043d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_BottomNavigationView = 0x7f10043e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_BottomSheet_Modal = 0x7f10043f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_CollapsingToolbar = 0x7f100440;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_FloatingActionButton = 0x7f100441;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_NavigationView = 0x7f100442;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_ScrimInsetsFrameLayout = 0x7f100443;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_Snackbar = 0x7f100444;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TabLayout = 0x7f100445;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TextInputEditText = 0x7f100446;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TextInputLayout = 0x7f100447;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_Button_Borderless_FocusRing = 0x7f100448;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_Button_FocusRing = 0x7f100449;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_Button_Small_FocusRing = 0x7f10044a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_CompoundButton_CheckBox_FocusRing = 0x7f10044b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_CompoundButton_RadioButton_FocusRing = 0x7f10044c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_CompoundButton_Switch_FocusRing = 0x7f10044d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material_ImageButton_FocusRing = 0x7f10044e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ActionBar_Solid = 0x7f10044f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ActionMode = 0x7f100450;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AppBarLayout = 0x7f100451;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_FilledBox = 0x7f100452;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_FilledBox_Dense = 0x7f100453;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_OutlinedBox = 0x7f100454;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_OutlinedBox_Dense = 0x7f100455;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Badge = 0x7f100456;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Badge_AdjustToBounds = 0x7f100457;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomAppBar = 0x7f100458;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomAppBar_Button_Navigation = 0x7f100459;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomAppBar_Legacy = 0x7f10045a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigation_Badge = 0x7f10045b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigationView = 0x7f10045c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigationView_ActiveIndicator = 0x7f10045d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet = 0x7f10045e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet_DragHandle = 0x7f10045f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet_Modal = 0x7f100460;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button = 0x7f100461;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_ElevatedButton = 0x7f100462;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_ElevatedButton_Icon = 0x7f100463;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_Icon = 0x7f100464;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton = 0x7f100465;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Close_Snackbar = 0x7f100466;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled = 0x7f100467;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled_ListItemRevealLayout = 0x7f100468;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled_Tonal = 0x7f100469;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled_Tonal_ListItemRevealLayout = 0x7f10046a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_ListItemRevealLayout = 0x7f10046b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Outlined = 0x7f10046c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Outlined_ListItemRevealLayout = 0x7f10046d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_OutlinedButton = 0x7f10046e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_OutlinedButton_Icon = 0x7f10046f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton = 0x7f100470;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Dialog = 0x7f100471;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Dialog_Flush = 0x7f100472;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Dialog_Icon = 0x7f100473;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Icon = 0x7f100474;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Snackbar = 0x7f100475;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TonalButton = 0x7f100476;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TonalButton_Icon = 0x7f100477;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_UnelevatedButton = 0x7f100478;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Elevated = 0x7f100479;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Filled = 0x7f10047a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Outlined = 0x7f10047b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Checkbox_ListItem = 0x7f10047c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CheckedTextView = 0x7f10047d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Assist = 0x7f10047e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Assist_Elevated = 0x7f10047f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Filter = 0x7f100480;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Filter_Elevated = 0x7f100481;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Input = 0x7f100482;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Input_Elevated = 0x7f100483;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Input_Icon = 0x7f100484;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Input_Icon_Elevated = 0x7f100485;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Suggestion = 0x7f100486;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Suggestion_Elevated = 0x7f100487;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ChipGroup = 0x7f100488;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator = 0x7f100489;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_ExtraSmall = 0x7f10048a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Legacy = 0x7f10048b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Legacy_ExtraSmall = 0x7f10048c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Legacy_Medium = 0x7f10048d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Legacy_Small = 0x7f10048e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Medium = 0x7f10048f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator_Small = 0x7f100490;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar = 0x7f100491;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar_Large = 0x7f100492;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar_Medium = 0x7f100493;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_CheckBox = 0x7f100494;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_MaterialSwitch = 0x7f100495;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_RadioButton = 0x7f100496;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_Switch = 0x7f100497;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar = 0x7f100498;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_Button = 0x7f100499;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_Button_Vibrant = 0x7f10049a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_IconButton = 0x7f10049b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_IconButton_Vibrant = 0x7f10049c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_TextButton = 0x7f10049d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_TextButton_Vibrant = 0x7f10049e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DockedToolbar_Vibrant = 0x7f10049f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DrawerLayout = 0x7f1004a0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Primary = 0x7f1004a1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Secondary = 0x7f1004a2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Surface = 0x7f1004a3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Tertiary = 0x7f1004a4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Large = 0x7f1004a5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Medium = 0x7f1004a6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Primary = 0x7f1004a7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Secondary = 0x7f1004a8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Small = 0x7f1004a9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Surface = 0x7f1004aa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Tertiary = 0x7f1004ab;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Primary = 0x7f1004ac;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Secondary = 0x7f1004ad;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Surface = 0x7f1004ae;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Tertiary = 0x7f1004af;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Medium = 0x7f1004b0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Primary = 0x7f1004b1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Secondary = 0x7f1004b2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Primary = 0x7f1004b3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Secondary = 0x7f1004b4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Surface = 0x7f1004b5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Tertiary = 0x7f1004b6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Surface = 0x7f1004b7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Tertiary = 0x7f1004b8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar = 0x7f1004b9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_Button = 0x7f1004ba;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_Button_Vibrant = 0x7f1004bb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_IconButton = 0x7f1004bc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_IconButton_Vibrant = 0x7f1004bd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_TextButton = 0x7f1004be;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_TextButton_Vibrant = 0x7f1004bf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingToolbar_Vibrant = 0x7f1004c0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ImageView_ListItem_LeadingIcon = 0x7f1004c1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ImageView_ListItem_TrailingIcon = 0x7f1004c2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Light_ActionBar_Solid = 0x7f1004c3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_LinearProgressIndicator = 0x7f1004c4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_LinearProgressIndicator_Legacy = 0x7f1004c5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ListItemCardView = 0x7f1004c6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ListItemCardView_Segmented = 0x7f1004c7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ListItemLayout = 0x7f1004c8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ListItemRevealLayout = 0x7f1004c9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_LoadingIndicator = 0x7f1004ca;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_LoadingIndicator_Contained = 0x7f1004cb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialButtonGroup = 0x7f1004cc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialButtonGroup_Connected = 0x7f1004cd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialButtonGroup_Overflow_CheckBox = 0x7f1004ce;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialButtonToggleGroup = 0x7f1004cf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar = 0x7f1004d0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day = 0x7f1004d1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Invalid = 0x7f1004d2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Selected = 0x7f1004d3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Today = 0x7f1004d4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_DayOfWeekLabel = 0x7f1004d5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_DayTextView = 0x7f1004d6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Fullscreen = 0x7f1004d7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderCancelButton = 0x7f1004d8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderDivider = 0x7f1004d9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderLayout = 0x7f1004da;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f1004db;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderSelection = 0x7f1004dc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f1004dd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderTitle = 0x7f1004de;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderToggleButton = 0x7f1004df;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Item = 0x7f1004e0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_MonthNavigationButton = 0x7f1004e1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_MonthTextView = 0x7f1004e2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year = 0x7f1004e3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year_Selected = 0x7f1004e4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year_Today = 0x7f1004e5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_YearNavigationButton = 0x7f1004e6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialDivider = 0x7f1004e7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialDivider_Heavy = 0x7f1004e8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialSplitButton = 0x7f1004e9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker = 0x7f1004ea;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Button = 0x7f1004eb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Clock = 0x7f1004ec;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display = 0x7f1004ed;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_Divider = 0x7f1004ee;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_HelperText = 0x7f1004ef;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f1004f0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_TextInputLayout = 0x7f1004f1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_ImageButton = 0x7f1004f2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView = 0x7f1004f3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView_ActiveIndicator = 0x7f1004f4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView_Badge = 0x7f1004f5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationView = 0x7f1004f6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_OverflowLinearLayout = 0x7f1004f7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_OverflowLinearLayout_CheckBox = 0x7f1004f8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu = 0x7f1004f9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_ContextMenu = 0x7f1004fa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_ListPopupWindow = 0x7f1004fb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_Overflow = 0x7f1004fc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_RadioButton_ListItem = 0x7f1004fd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Search_ActionButton_Overflow = 0x7f1004fe;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Search_Toolbar_Button_Navigation = 0x7f1004ff;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchBar = 0x7f100500;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchBar_Outlined = 0x7f100501;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView = 0x7f100502;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView_Prefix = 0x7f100503;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView_Toolbar = 0x7f100504;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ShapeableImageView_ListItem_LeadingImage = 0x7f100505;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet = 0x7f100506;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet_Detached = 0x7f100507;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet_Modal = 0x7f100508;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet_Modal_Detached = 0x7f100509;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider = 0x7f10050a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider_Label = 0x7f10050b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider_Legacy = 0x7f10050c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider_Legacy_Label = 0x7f10050d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Snackbar = 0x7f10050e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Snackbar_FullWidth = 0x7f10050f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Snackbar_TextView = 0x7f100510;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SplitButton_IconButton_Filled = 0x7f100511;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SplitButton_IconButton_Filled_Tonal = 0x7f100512;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SplitButton_LeadingButton_Filled = 0x7f100513;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SplitButton_LeadingButton_Filled_Tonal = 0x7f100514;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Switch_ListItem = 0x7f100515;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TabLayout = 0x7f100516;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TabLayout_OnSurface = 0x7f100517;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TabLayout_Secondary = 0x7f100518;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_FilledBox = 0x7f100519;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_FilledBox_Dense = 0x7f10051a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_OutlinedBox = 0x7f10051b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f10051c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox = 0x7f10051d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox_Dense = 0x7f10051e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu = 0x7f10051f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f100520;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox = 0x7f100521;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox_Dense = 0x7f100522;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu = 0x7f100523;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f100524;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextView_ListItem_LabelText = 0x7f100525;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextView_ListItem_Overline = 0x7f100526;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextView_ListItem_SupportingText = 0x7f100527;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextView_ListItem_TrailingSupportingText = 0x7f100528;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar = 0x7f100529;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_Button_Navigation = 0x7f10052a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_Button_Navigation_Circle = 0x7f10052b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_OnSurface = 0x7f10052c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_Surface = 0x7f10052d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Tooltip = 0x7f10052e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_AppBarLayout = 0x7f10052f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_AppBarLayout_AppBarWithSearch = 0x7f100530;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_BottomNavigationView = 0x7f100531;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_BottomNavigationView_ActiveIndicator = 0x7f100532;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button = 0x7f100533;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_ElevatedButton = 0x7f100534;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton = 0x7f100535;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Filled = 0x7f100536;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Filled_ListItemRevealLayout = 0x7f100537;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_ListItemRevealLayout = 0x7f100538;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Outlined = 0x7f100539;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Outlined_ListItemRevealLayout = 0x7f10053a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Standard = 0x7f10053b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Tonal = 0x7f10053c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_IconButton_Tonal_ListItemRevealLayout = 0x7f10053d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_OutlinedButton = 0x7f10053e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TextButton = 0x7f10053f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TextButton_Dialog = 0x7f100540;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TextButton_Dialog_Flush = 0x7f100541;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TextButton_Dialog_Icon = 0x7f100542;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TextButton_Snackbar = 0x7f100543;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Button_TonalButton = 0x7f100544;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_CircularProgressIndicator = 0x7f100545;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_CircularProgressIndicator_Wavy = 0x7f100546;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_CollapsingToolbar = 0x7f100547;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_CollapsingToolbar_Large = 0x7f100548;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_CollapsingToolbar_Medium = 0x7f100549;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_ExtendedFloatingActionButton_Large = 0x7f10054a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_ExtendedFloatingActionButton_Medium = 0x7f10054b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_ExtendedFloatingActionButton_Small = 0x7f10054c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_FloatingActionButton = 0x7f10054d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_FloatingActionButton_Large = 0x7f10054e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_FloatingActionButton_Medium = 0x7f10054f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_LinearProgressIndicator = 0x7f100550;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_LinearProgressIndicator_Wavy = 0x7f100551;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_ListItemRevealLayout = 0x7f100552;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_MaterialButtonGroup = 0x7f100553;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_MaterialButtonGroup_Connected = 0x7f100554;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_MaterialButtonToggleGroup = 0x7f100555;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_NavigationRailView = 0x7f100556;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_NavigationRailView_ActiveIndicator = 0x7f100557;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchBar = 0x7f100558;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchBar_AppBarWithSearch = 0x7f100559;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchBar_CenteredText = 0x7f10055a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchBar_CenteredText_AppBarWithSearch = 0x7f10055b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchBar_Outlined = 0x7f10055c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchView = 0x7f10055d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchView_AppBarWithSearch = 0x7f10055e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchView_Toolbar = 0x7f10055f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_SearchView_Toolbar_AppBarWithSearch = 0x7f100560;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Slider_Large = 0x7f100561;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Slider_Medium = 0x7f100562;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Slider_Small = 0x7f100563;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Slider_Xlarge = 0x7f100564;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Slider_Xsmall = 0x7f100565;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Toolbar = 0x7f100566;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Toolbar_AppBarWithSearch = 0x7f100567;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Toolbar_OnSurface = 0x7f100568;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3Expressive_Toolbar_Surface = 0x7f100569;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionBar_Primary = 0x7f10056a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionBar_PrimarySurface = 0x7f10056b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionBar_Solid = 0x7f10056c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionBar_Surface = 0x7f10056d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionMode = 0x7f10056e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AppBarLayout_Primary = 0x7f10056f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AppBarLayout_PrimarySurface = 0x7f100570;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AppBarLayout_Surface = 0x7f100571;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f100572;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 0x7f100573;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f100574;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 0x7f100575;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Badge = 0x7f100576;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomAppBar = 0x7f100577;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomAppBar_Colored = 0x7f100578;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomAppBar_PrimarySurface = 0x7f100579;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomNavigationView = 0x7f10057a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomNavigationView_Colored = 0x7f10057b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomNavigationView_PrimarySurface = 0x7f10057c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomSheet = 0x7f10057d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomSheet_Modal = 0x7f10057e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button = 0x7f10057f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_Icon = 0x7f100580;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_OutlinedButton = 0x7f100581;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_OutlinedButton_Icon = 0x7f100582;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton = 0x7f100583;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog = 0x7f100584;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Flush = 0x7f100585;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Icon = 0x7f100586;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Icon = 0x7f100587;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Icon_Close_Snackbar = 0x7f100588;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Snackbar = 0x7f100589;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_UnelevatedButton = 0x7f10058a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_UnelevatedButton_Icon = 0x7f10058b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CardView = 0x7f10058c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CheckedTextView = 0x7f10058d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Action = 0x7f10058e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Choice = 0x7f10058f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Entry = 0x7f100590;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Filter = 0x7f100591;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ChipGroup = 0x7f100592;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CircularProgressIndicator = 0x7f100593;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CircularProgressIndicator_ExtraSmall = 0x7f100594;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CircularProgressIndicator_Medium = 0x7f100595;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CircularProgressIndicator_Small = 0x7f100596;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CollapsingToolbar = 0x7f100597;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_CheckBox = 0x7f100598;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_RadioButton = 0x7f100599;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_Switch = 0x7f10059a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton = 0x7f10059b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton_Icon = 0x7f10059c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_FloatingActionButton = 0x7f10059d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Light_ActionBar_Solid = 0x7f10059e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_LinearProgressIndicator = 0x7f10059f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialButtonToggleGroup = 0x7f1005a0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar = 0x7f1005a1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day = 0x7f1005a2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Invalid = 0x7f1005a3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Selected = 0x7f1005a4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Today = 0x7f1005a5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_DayOfWeekLabel = 0x7f1005a6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_DayTextView = 0x7f1005a7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f1005a8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderCancelButton = 0x7f1005a9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderConfirmButton = 0x7f1005aa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderDivider = 0x7f1005ab;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderLayout = 0x7f1005ac;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f1005ad;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection = 0x7f1005ae;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f1005af;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderTitle = 0x7f1005b0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f1005b1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Item = 0x7f1005b2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_MonthNavigationButton = 0x7f1005b3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_MonthTextView = 0x7f1005b4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year = 0x7f1005b5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Selected = 0x7f1005b6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Today = 0x7f1005b7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_YearNavigationButton = 0x7f1005b8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialDivider = 0x7f1005b9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView = 0x7f1005ba;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView_Colored = 0x7f1005bb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView_Colored_Compact = 0x7f1005bc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView_Compact = 0x7f1005bd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView_PrimarySurface = 0x7f1005be;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationView = 0x7f1005bf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu = 0x7f1005c0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f1005c1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f1005c2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_Overflow = 0x7f1005c3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ProgressIndicator = 0x7f1005c4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ShapeableImageView = 0x7f1005c5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Slider = 0x7f1005c6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Snackbar = 0x7f1005c7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Snackbar_FullWidth = 0x7f1005c8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Snackbar_TextView = 0x7f1005c9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TabLayout = 0x7f1005ca;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TabLayout_Colored = 0x7f1005cb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TabLayout_PrimarySurface = 0x7f1005cc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox = 0x7f1005cd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f1005ce;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f1005cf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f1005d0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox = 0x7f1005d1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense = 0x7f1005d2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu = 0x7f1005d3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f1005d4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox = 0x7f1005d5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense = 0x7f1005d6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu = 0x7f1005d7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f1005d8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextView = 0x7f1005d9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker = 0x7f1005da;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Button = 0x7f1005db;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Clock = 0x7f1005dc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display = 0x7f1005dd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_Divider = 0x7f1005de;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_HelperText = 0x7f1005df;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f1005e0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_TextInputLayout = 0x7f1005e1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_ImageButton = 0x7f1005e2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_ImageButton_ShapeAppearance = 0x7f1005e3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Toolbar = 0x7f1005e4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Toolbar_Primary = 0x7f1005e5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Toolbar_PrimarySurface = 0x7f1005e6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Toolbar_Surface = 0x7f1005e7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Tooltip = 0x7f1005e8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Support_CoordinatorLayout = 0x7f1005e9;

        private style() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int m3_button_group_child_size_change = 0x7f120000;

        /* JADX INFO: Added by JADX */
        public static final int m3_list_item_shape_state_list = 0x7f120001;

        /* JADX INFO: Added by JADX */
        public static final int m3_split_button_inner_corner_size_state_list = 0x7f120002;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_button_shape_state_list = 0x7f120003;

        /* JADX INFO: Added by JADX */
        public static final int m3expressive_connected_buttons_inner_corner_size_state_list = 0x7f120004;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f120005;
    }

    private R() {
    }
}
