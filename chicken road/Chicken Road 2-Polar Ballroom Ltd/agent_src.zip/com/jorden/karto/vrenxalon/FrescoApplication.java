package com.jorden.karto.vrenxalon;

/* compiled from: r8-map-id-9647e9156d11b20a1701af8c517155688e95c6949ee2c1b2111201034c3e995f */
/* loaded from: classes.dex */
public class FrescoApplication extends android.app.Application implements defpackage.h10 {
    public boolean fYm8XZLv = false;
    public final defpackage.i5 DJbykCkUx3 = new defpackage.i5(new defpackage.WHHd4r1X(22, this));

    @Override // defpackage.h10
    public final java.lang.Object HVozxM5KQ() {
        return this.DJbykCkUx3.HVozxM5KQ();
    }

    @Override // android.app.Application
    public final void onCreate() {
        if (!this.fYm8XZLv) {
            this.fYm8XZLv = true;
            ((defpackage.wy) this.DJbykCkUx3.HVozxM5KQ()).getClass();
        }
        super.onCreate();
    }
}
