package com.jorden.karto.vrenxalon;

/* compiled from: r8-map-id-9647e9156d11b20a1701af8c517155688e95c6949ee2c1b2111201034c3e995f */
/* loaded from: classes.dex */
public final class MainActivity extends defpackage.cf implements defpackage.h10 {
    public static final /* synthetic */ int nTtlYljQk7K = 0;
    public volatile defpackage.O2nbGkxPKVv oOwEcOxvB;
    public final java.lang.Object fBZAPWqEVL = new java.lang.Object();
    public boolean LFutkhufwHD = false;

    public MainActivity() {
        defpackage.x30 x30Var = new defpackage.x30(this);
        defpackage.li liVar = this.DJbykCkUx3;
        liVar.getClass();
        defpackage.cf cfVar = liVar.TheyeTBu5Gk;
        if (cfVar != null) {
            x30Var.FJ4tRyCFAEX(cfVar);
        }
        liVar.FJ4tRyCFAEX.add(x30Var);
    }

    @Override // defpackage.h10
    public final java.lang.Object HVozxM5KQ() {
        return t3G5C6Gs().HVozxM5KQ();
    }

    public final void SRZCZMJsSan9(android.os.Bundle bundle) {
        super.onCreate(bundle);
        defpackage.O2nbGkxPKVv o2nbGkxPKVvT3G5C6Gs = t3G5C6Gs();
        defpackage.OUxDGqBrKDO oUxDGqBrKDO = o2nbGkxPKVvT3G5C6Gs.Llis1Tt91qTS;
        com.jorden.karto.vrenxalon.MainActivity mainActivity = oUxDGqBrKDO.fYm8XZLv;
        defpackage.UGGOXQzX4E uGGOXQzX4E = new defpackage.UGGOXQzX4E(0, oUxDGqBrKDO.DJbykCkUx3);
        defpackage.yo1 yo1VarKTBjVUpeKM = mainActivity.KTBjVUpeKM();
        defpackage.kj kjVarLlis1Tt91qTS = defpackage.xx0.Llis1Tt91qTS(mainActivity);
        kjVarLlis1Tt91qTS.getClass();
        defpackage.Q58GpTLEi7TD q58GpTLEi7TD = new defpackage.Q58GpTLEi7TD(yo1VarKTBjVUpeKM, uGGOXQzX4E, kjVarLlis1Tt91qTS);
        defpackage.ec ecVarFJ4tRyCFAEX = defpackage.c11.FJ4tRyCFAEX(defpackage.z9EIYAG2n.class);
        java.lang.String strTheyeTBu5Gk = ecVarFJ4tRyCFAEX.TheyeTBu5Gk();
        if (strTheyeTBu5Gk == null) {
            defpackage.o5.LCmmxQR1noP("Local and anonymous classes can not be ViewModels");
            return;
        }
        defpackage.x41 x41Var = ((defpackage.z9EIYAG2n) q58GpTLEi7TD.VXEyz5pKAj5q(ecVarFJ4tRyCFAEX, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strTheyeTBu5Gk))).MH9A7LEhL;
        o2nbGkxPKVvT3G5C6Gs.TgtEDysFIUP = x41Var;
        if (((defpackage.yk0) x41Var.KTBjVUpeKM) == null) {
            defpackage.kj kjVarDJbykCkUx3 = o2nbGkxPKVvT3G5C6Gs.KTBjVUpeKM.DJbykCkUx3();
            if (x41Var.DJbykCkUx3) {
                x41Var.KTBjVUpeKM = (defpackage.yk0) kjVarDJbykCkUx3;
            } else {
                defpackage.xo0.DJbykCkUx3("setExtras should only be called for an Activity that extends ComponentActivity");
            }
        }
    }

    @Override // defpackage.r30
    public final defpackage.wo1 fYm8XZLv() {
        defpackage.wo1 wo1Var = (defpackage.wo1) this.qHMgVbQoz.getValue();
        defpackage.ek ekVar = (defpackage.ek) ((defpackage.ln) defpackage.g70.FRSDkcPYX(this, defpackage.ln.class));
        defpackage.zb0 zb0VarFJ4tRyCFAEX = ekVar.FJ4tRyCFAEX();
        defpackage.pv1 pv1Var = new defpackage.pv1(8, ekVar.FJ4tRyCFAEX, ekVar.TheyeTBu5Gk);
        wo1Var.getClass();
        return new defpackage.v30(zb0VarFJ4tRyCFAEX, wo1Var, pv1Var);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue
    java.lang.NullPointerException: Cannot invoke "java.util.List.iterator()" because the return value of "jadx.core.dex.visitors.regions.SwitchOverStringVisitor$SwitchData.getNewCases()" is null
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(SwitchOverStringVisitor.java:109)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(SwitchOverStringVisitor.java:66)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:77)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:82)
     */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0136  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0151  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x016e  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x0176  */
    @Override // defpackage.cf, defpackage.bf, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(android.os.Bundle bundle) {
        java.lang.String lowerCase;
        java.lang.String str;
        SRZCZMJsSan9(bundle);
        int i = 3;
        defpackage.rf1 rf1Var = new defpackage.rf1(0, 0, new defpackage.oc1(i));
        defpackage.rf1 rf1Var2 = new defpackage.rf1(defpackage.es.FJ4tRyCFAEX, defpackage.es.TheyeTBu5Gk, new defpackage.oc1(i));
        android.view.View decorView = getWindow().getDecorView();
        decorView.getClass();
        defpackage.ls ksVar = defpackage.es.MH9A7LEhL;
        if (ksVar == null) {
            int i2 = android.os.Build.VERSION.SDK_INT;
            ksVar = i2 >= 35 ? new defpackage.ks() : i2 >= 30 ? new defpackage.js() : i2 >= 29 ? new defpackage.is() : i2 >= 28 ? new defpackage.hs() : i2 >= 26 ? new defpackage.gs() : new defpackage.fs();
            defpackage.es.MH9A7LEhL = ksVar;
        }
        defpackage.ls lsVar = ksVar;
        defpackage.s7 s7Var = new defpackage.s7(lsVar, rf1Var, rf1Var2, this, decorView, 1);
        android.view.ViewGroup viewGroup = (android.view.ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                defpackage.ds dsVar = new defpackage.ds(s7Var, viewGroup.getContext());
                dsVar.setTag(lsVar);
                dsVar.setVisibility(8);
                dsVar.setWillNotDraw(true);
                viewGroup.addView(dsVar);
                break;
            }
            int i4 = i3 + 1;
            android.view.View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new java.lang.IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof defpackage.ls) {
                break;
            } else {
                i3 = i4;
            }
        }
        s7Var.run();
        android.view.Window window = getWindow();
        window.getClass();
        lsVar.FJ4tRyCFAEX(window);
        android.content.Intent intent = getIntent();
        java.lang.String stringExtra = intent != null ? intent.getStringExtra("screen") : null;
        if (stringExtra != null) {
            int length = stringExtra.length() - 1;
            int i5 = 0;
            boolean z = false;
            while (i5 <= length) {
                boolean zTUSHKRzGsch3 = defpackage.am.TUSHKRzGsch3(stringExtra.charAt(!z ? i5 : length));
                if (z) {
                    if (!zTUSHKRzGsch3) {
                        break;
                    } else {
                        length--;
                    }
                } else if (zTUSHKRzGsch3) {
                    i5++;
                } else {
                    z = true;
                }
            }
            java.lang.String string = stringExtra.subSequence(i5, length + 1).toString();
            if (string != null) {
                lowerCase = string.toLowerCase(java.util.Locale.ROOT);
                lowerCase.getClass();
            } else {
                lowerCase = null;
            }
        }
        if (lowerCase != null) {
            str = "leaderboard";
            switch (lowerCase.hashCode()) {
                case -1706072195:
                    if (!lowerCase.equals("leaderboard")) {
                        str = "lobby";
                        break;
                    }
                    break;
                case -1672743543:
                    if (lowerCase.equals("how_to_play")) {
                        str = "guide";
                        break;
                    }
                    break;
                case -1447560065:
                    if (!lowerCase.equals("howtoplay")) {
                    }
                    break;
                case -907766751:
                    if (!lowerCase.equals("scores")) {
                    }
                    break;
                case 3165170:
                    if (lowerCase.equals("game")) {
                        str = "game";
                        break;
                    }
                    break;
                case 3198785:
                    if (!lowerCase.equals("help")) {
                    }
                    break;
                case 3443508:
                    if (!lowerCase.equals("play")) {
                    }
                    break;
                case 3532157:
                    if (lowerCase.equals("skin")) {
                        str = "skins";
                        break;
                    }
                    break;
                case 98712316:
                    if (!lowerCase.equals("guide")) {
                    }
                    break;
                case 109496982:
                    if (!lowerCase.equals("skins")) {
                    }
                    break;
                case 1082596930:
                    if (!lowerCase.equals("records")) {
                    }
                    break;
            }
        }
        defpackage.jf jfVar = new defpackage.jf(-1106951971, new defpackage.b5(str, i), true);
        android.view.ViewGroup.LayoutParams layoutParams = defpackage.df.FJ4tRyCFAEX;
        android.view.View childAt2 = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        defpackage.lg lgVar = childAt2 instanceof defpackage.lg ? (defpackage.lg) childAt2 : null;
        if (lgVar != null) {
            lgVar.setParentCompositionContext(null);
            lgVar.setContent(jfVar);
            return;
        }
        defpackage.lg lgVar2 = new defpackage.lg(this);
        lgVar2.setParentCompositionContext(null);
        lgVar2.setContent(jfVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (defpackage.zm1.DJbykCkUx3(decorView2) == null) {
            decorView2.setTag(org.chromium.net.R.id.view_tree_lifecycle_owner, this);
        }
        if (defpackage.zt0.HVozxM5KQ(decorView2) == null) {
            decorView2.setTag(org.chromium.net.R.id.view_tree_view_model_store_owner, this);
        }
        if (defpackage.jt0.MH9A7LEhL(decorView2) == null) {
            decorView2.setTag(org.chromium.net.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(lgVar2, defpackage.df.FJ4tRyCFAEX);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        defpackage.x41 x41Var = t3G5C6Gs().TgtEDysFIUP;
        if (x41Var != null) {
            x41Var.KTBjVUpeKM = null;
        }
    }

    public final defpackage.O2nbGkxPKVv t3G5C6Gs() {
        if (this.oOwEcOxvB == null) {
            synchronized (this.fBZAPWqEVL) {
                try {
                    if (this.oOwEcOxvB == null) {
                        this.oOwEcOxvB = new defpackage.O2nbGkxPKVv(this);
                    }
                } finally {
                }
            }
        }
        return this.oOwEcOxvB;
    }
}
