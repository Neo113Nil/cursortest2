package com.jorden.karto.vrenxalon.splash.domain;

/* compiled from: r8-map-id-9647e9156d11b20a1701af8c517155688e95c6949ee2c1b2111201034c3e995f */
/* loaded from: classes.dex */
public final class RenaissanceData {

    @defpackage.d91("candleLight")
    private final int candleLight;

    @defpackage.d91("comboMultiplier")
    private final int comboMultiplier;

    @defpackage.d91("florinBalance")
    private final int florinBalance;

    @defpackage.d91("frescoPanel")
    private final int frescoPanel;

    @defpackage.d91("isOfflineMode")
    private final boolean isOfflineMode;

    @defpackage.d91("renaissanceSymbol")
    private final java.lang.String renaissanceSymbol;

    @defpackage.d91("restorationTime")
    private final int restorationTime;

    @defpackage.d91("workshopDeck")
    private final java.lang.String workshopDeck;

    public /* synthetic */ RenaissanceData(int i, java.lang.String str, int i2, int i3, int i4, int i5, boolean z, java.lang.String str2, int i6, defpackage.fm fmVar) {
        this((i6 & 1) != 0 ? 0 : i, (i6 & 2) != 0 ? "" : str, (i6 & 4) != 0 ? 0 : i2, (i6 & 8) != 0 ? 0 : i3, (i6 & 16) != 0 ? 0 : i4, (i6 & 32) != 0 ? 0 : i5, (i6 & 64) != 0 ? false : z, (i6 & 128) != 0 ? "" : str2);
    }

    public static /* synthetic */ com.jorden.karto.vrenxalon.splash.domain.RenaissanceData copy$default(com.jorden.karto.vrenxalon.splash.domain.RenaissanceData renaissanceData, int i, java.lang.String str, int i2, int i3, int i4, int i5, boolean z, java.lang.String str2, int i6, java.lang.Object obj) {
        if ((i6 & 1) != 0) {
            i = renaissanceData.frescoPanel;
        }
        if ((i6 & 2) != 0) {
            str = renaissanceData.renaissanceSymbol;
        }
        if ((i6 & 4) != 0) {
            i2 = renaissanceData.comboMultiplier;
        }
        if ((i6 & 8) != 0) {
            i3 = renaissanceData.candleLight;
        }
        if ((i6 & 16) != 0) {
            i4 = renaissanceData.florinBalance;
        }
        if ((i6 & 32) != 0) {
            i5 = renaissanceData.restorationTime;
        }
        if ((i6 & 64) != 0) {
            z = renaissanceData.isOfflineMode;
        }
        if ((i6 & 128) != 0) {
            str2 = renaissanceData.workshopDeck;
        }
        boolean z2 = z;
        java.lang.String str3 = str2;
        int i7 = i4;
        int i8 = i5;
        return renaissanceData.copy(i, str, i2, i3, i7, i8, z2, str3);
    }

    public final int component1() {
        return this.frescoPanel;
    }

    public final java.lang.String component2() {
        return this.renaissanceSymbol;
    }

    public final int component3() {
        return this.comboMultiplier;
    }

    public final int component4() {
        return this.candleLight;
    }

    public final int component5() {
        return this.florinBalance;
    }

    public final int component6() {
        return this.restorationTime;
    }

    public final boolean component7() {
        return this.isOfflineMode;
    }

    public final java.lang.String component8() {
        return this.workshopDeck;
    }

    public final com.jorden.karto.vrenxalon.splash.domain.RenaissanceData copy(int i, java.lang.String str, int i2, int i3, int i4, int i5, boolean z, java.lang.String str2) {
        str.getClass();
        str2.getClass();
        return new com.jorden.karto.vrenxalon.splash.domain.RenaissanceData(i, str, i2, i3, i4, i5, z, str2);
    }

    public boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.vrenxalon.splash.domain.RenaissanceData)) {
            return false;
        }
        com.jorden.karto.vrenxalon.splash.domain.RenaissanceData renaissanceData = (com.jorden.karto.vrenxalon.splash.domain.RenaissanceData) obj;
        return this.frescoPanel == renaissanceData.frescoPanel && defpackage.e80.Ruerzbsm(this.renaissanceSymbol, renaissanceData.renaissanceSymbol) && this.comboMultiplier == renaissanceData.comboMultiplier && this.candleLight == renaissanceData.candleLight && this.florinBalance == renaissanceData.florinBalance && this.restorationTime == renaissanceData.restorationTime && this.isOfflineMode == renaissanceData.isOfflineMode && defpackage.e80.Ruerzbsm(this.workshopDeck, renaissanceData.workshopDeck);
    }

    public final int getCandleLight() {
        return this.candleLight;
    }

    public final int getComboMultiplier() {
        return this.comboMultiplier;
    }

    public final int getFlorinBalance() {
        return this.florinBalance;
    }

    public final int getFrescoPanel() {
        return this.frescoPanel;
    }

    public final java.lang.String getRenaissanceSymbol() {
        return this.renaissanceSymbol;
    }

    public final int getRestorationTime() {
        return this.restorationTime;
    }

    public final java.lang.String getWorkshopDeck() {
        return this.workshopDeck;
    }

    public int hashCode() {
        return this.workshopDeck.hashCode() + defpackage.ny0.KTBjVUpeKM(defpackage.ny0.fBZAPWqEVL(this.restorationTime, defpackage.ny0.fBZAPWqEVL(this.florinBalance, defpackage.ny0.fBZAPWqEVL(this.candleLight, defpackage.ny0.fBZAPWqEVL(this.comboMultiplier, (this.renaissanceSymbol.hashCode() + (java.lang.Integer.hashCode(this.frescoPanel) * 31)) * 31, 31), 31), 31), 31), 31, this.isOfflineMode);
    }

    public final boolean isOfflineMode() {
        return this.isOfflineMode;
    }

    public java.lang.String toString() {
        int i = this.frescoPanel;
        java.lang.String str = this.renaissanceSymbol;
        int i2 = this.comboMultiplier;
        int i3 = this.candleLight;
        int i4 = this.florinBalance;
        int i5 = this.restorationTime;
        boolean z = this.isOfflineMode;
        java.lang.String str2 = this.workshopDeck;
        java.lang.StringBuilder sb = new java.lang.StringBuilder("RenaissanceData(frescoPanel=");
        sb.append(i);
        sb.append(", renaissanceSymbol=");
        sb.append(str);
        sb.append(", comboMultiplier=");
        defpackage.ny0.oOwEcOxvB(sb, i2, ", candleLight=", i3, ", florinBalance=");
        defpackage.ny0.oOwEcOxvB(sb, i4, ", restorationTime=", i5, ", isOfflineMode=");
        sb.append(z);
        sb.append(", workshopDeck=");
        sb.append(str2);
        sb.append(")");
        return sb.toString();
    }

    public RenaissanceData(int i, java.lang.String str, int i2, int i3, int i4, int i5, boolean z, java.lang.String str2) {
        str.getClass();
        str2.getClass();
        this.frescoPanel = i;
        this.renaissanceSymbol = str;
        this.comboMultiplier = i2;
        this.candleLight = i3;
        this.florinBalance = i4;
        this.restorationTime = i5;
        this.isOfflineMode = z;
        this.workshopDeck = str2;
    }

    public RenaissanceData() {
        this(0, null, 0, 0, 0, 0, false, null, org.chromium.net.PrivateKeyType.INVALID, null);
    }
}
