package com.corlis.lobaner.mordranik.data.local;

import defpackage.ex0;
import defpackage.h51;

/* compiled from: r8-map-id-beaee6f12e14160fbd386e8b2b8dd13e034353aa8870ef0ddc1d1cd594a2c8da */
/* loaded from: classes.dex */
public abstract class AppDatabase extends h51 {
    public abstract ex0 orH3dyfLz4hm();
}
