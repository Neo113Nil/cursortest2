package com.corlis.lobaner.mordranik;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.ah;
import defpackage.at;
import defpackage.bh;
import defpackage.bt;
import defpackage.ct;
import defpackage.dt;
import defpackage.et;
import defpackage.ft;
import defpackage.g00;
import defpackage.gi;
import defpackage.gt;
import defpackage.hf;
import defpackage.hh;
import defpackage.hh1;
import defpackage.ht;
import defpackage.i20;
import defpackage.mm1;
import defpackage.rg1;
import defpackage.vi0;
import defpackage.wu1;
import defpackage.xu1;
import defpackage.xy;
import defpackage.ys;
import defpackage.yu1;
import defpackage.zs;
import defpackage.zu1;

/* compiled from: r8-map-id-beaee6f12e14160fbd386e8b2b8dd13e034353aa8870ef0ddc1d1cd594a2c8da */
/* loaded from: classes.dex */
public final class MainActivity extends ah {
    @Override // defpackage.ah, defpackage.zg, android.app.Activity
    public final void onCreate(Bundle bundle) {
        int i = mm1.tppsemEhgjhx;
        hh1 hh1Var = new hh1(i, i, new rg1(1));
        hh1 hh1Var2 = new hh1(i, i, new rg1(1));
        ht htVar = at.tppsemEhgjhx;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ht gtVar = at.tppsemEhgjhx;
        if (gtVar == null) {
            int i2 = Build.VERSION.SDK_INT;
            gtVar = i2 >= 35 ? new gt() : i2 >= 30 ? new ft() : i2 >= 29 ? new et() : i2 >= 28 ? new dt() : i2 >= 26 ? new ct() : new bt();
            at.tppsemEhgjhx = gtVar;
        }
        ht htVar2 = gtVar;
        ys ysVar = new ys(htVar2, hh1Var, hh1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                zs zsVar = new zs(ysVar, viewGroup.getContext());
                zsVar.setTag(htVar2);
                zsVar.setVisibility(8);
                zsVar.setWillNotDraw(true);
                viewGroup.addView(zsVar);
                break;
            }
            int i4 = i3 + 1;
            View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof ht) {
                break;
            } else {
                i3 = i4;
            }
        }
        ysVar.run();
        Window window = getWindow();
        window.getClass();
        htVar2.tppsemEhgjhx(window);
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        Window window2 = getWindow();
        getWindow().getDecorView();
        int i5 = Build.VERSION.SDK_INT;
        xy zu1Var = i5 >= 35 ? new zu1(window2) : i5 >= 30 ? new yu1(window2) : i5 >= 26 ? new xu1(window2) : new wu1(window2);
        zu1Var.srjP5DwkHhfC(true);
        zu1Var.bw9UfztSfOxZ(true);
        hh hhVar = hf.wPoqzewqqTBM;
        ViewGroup.LayoutParams layoutParams = bh.tppsemEhgjhx;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        gi giVar = childAt2 instanceof gi ? (gi) childAt2 : null;
        if (giVar != null) {
            giVar.setParentCompositionContext(null);
            giVar.setContent(hhVar);
            return;
        }
        gi giVar2 = new gi(this);
        giVar2.setParentCompositionContext(null);
        giVar2.setContent(hhVar);
        View decorView2 = getWindow().getDecorView();
        if (g00.QlX2bogMyI1s(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (i20.lh2WSO5xh7P2(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (vi0.RDNdA5658ub8(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(giVar2, bh.tppsemEhgjhx);
    }
}
