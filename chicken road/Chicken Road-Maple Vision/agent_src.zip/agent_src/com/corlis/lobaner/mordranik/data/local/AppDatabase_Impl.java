package com.corlis.lobaner.mordranik.data.local;

import defpackage.a31;
import defpackage.ch1;
import defpackage.ex0;
import defpackage.gu;
import defpackage.m2;
import defpackage.ot;
import defpackage.s90;
import defpackage.v6;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-beaee6f12e14160fbd386e8b2b8dd13e034353aa8870ef0ddc1d1cd594a2c8da */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final ch1 orH3dyfLz4hm = new ch1(new m2(4, this));

    @Override // defpackage.h51
    public final s90 LkqmG5hzgLmZ() {
        return new s90(this, new LinkedHashMap(), new LinkedHashMap(), "plates");
    }

    @Override // defpackage.h51
    public final ot S8B1mXVNFkSk() {
        return new v6(this);
    }

    @Override // defpackage.h51
    public final Set ZWwlnCPyLikb() {
        return new LinkedHashSet();
    }

    @Override // defpackage.h51
    public final LinkedHashMap mRvVExLhO3gm() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(a31.tppsemEhgjhx(ex0.class), gu.ZWwlnCPyLikb);
        return linkedHashMap;
    }

    @Override // com.corlis.lobaner.mordranik.data.local.AppDatabase
    public final ex0 orH3dyfLz4hm() {
        return (ex0) this.orH3dyfLz4hm.getValue();
    }

    @Override // defpackage.h51
    public final List tppsemEhgjhx(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }
}
