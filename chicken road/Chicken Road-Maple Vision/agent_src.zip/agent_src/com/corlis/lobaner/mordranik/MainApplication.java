package com.corlis.lobaner.mordranik;

import android.app.Application;
import defpackage.a31;
import defpackage.bCEzlpzT5xKl;
import defpackage.ex0;
import defpackage.g7;
import defpackage.h70;
import defpackage.in;
import defpackage.ld0;
import defpackage.n71;
import defpackage.on;
import defpackage.sk;
import defpackage.tm;
import defpackage.vp;
import defpackage.wm;
import defpackage.xn;
import defpackage.ya0;
import defpackage.za0;
import defpackage.zi0;

/* compiled from: r8-map-id-beaee6f12e14160fbd386e8b2b8dd13e034353aa8870ef0ddc1d1cd594a2c8da */
/* loaded from: classes.dex */
public final class MainApplication extends Application {
    public static final /* synthetic */ int ZWwlnCPyLikb = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        ld0 ld0Var = new ld0(3, this);
        synchronized (bCEzlpzT5xKl.RKkMUBK8KhCh) {
            za0 za0Var = new za0();
            if (bCEzlpzT5xKl.yKaxTIZK0ar8 != null) {
                throw new xn("A Koin Application has already been started");
            }
            bCEzlpzT5xKl.yKaxTIZK0ar8 = za0Var.tppsemEhgjhx;
            ld0Var.orH3dyfLz4hm(za0Var);
            za0Var.tppsemEhgjhx.NX2iyR2eoijD();
        }
        ya0 ya0Var = bCEzlpzT5xKl.yKaxTIZK0ar8;
        if (ya0Var == null) {
            g7.GLsxIBCNEngq("KoinApplication has not been started");
            return;
        }
        ex0 ex0Var = (ex0) ((n71) ((h70) ya0Var.NX2iyR2eoijD).NX2iyR2eoijD).LkqmG5hzgLmZ(a31.tppsemEhgjhx(ex0.class));
        on onVar = vp.tppsemEhgjhx;
        tm.srjP5DwkHhfC(zi0.ZWwlnCPyLikb(in.NX2iyR2eoijD), null, new wm(ex0Var, (sk) null, 7), 3);
    }
}
