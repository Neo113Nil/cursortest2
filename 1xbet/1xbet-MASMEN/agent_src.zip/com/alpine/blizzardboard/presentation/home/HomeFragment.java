package com.alpine.blizzardboard.presentation.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Connectivity;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentHomeBinding;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import com.alpine.blizzardboard.domain.catalog.RouteInfo;
import com.alpine.blizzardboard.presentation.common.NoInternetDialog;
import java.time.LocalDate;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: HomeFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\b\u0010\u0016\u001a\u00020\u0014H\u0016J\b\u0010\u0017\u001a\u00020\u0014H\u0002J\b\u0010\u0018\u001a\u00020\u0014H\u0002J\b\u0010\u0019\u001a\u00020\u001aH\u0002J\b\u0010\u001b\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001c"}, d2 = {"Lcom/alpine/blizzardboard/presentation/home/HomeFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentHomeBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentHomeBinding;", "connectivityChecked", "", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "onResume", "refresh", "onDailyTapped", "today", "", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class HomeFragment extends Fragment {
    private FragmentHomeBinding _binding;
    private boolean connectivityChecked;

    private final FragmentHomeBinding getBinding() {
        FragmentHomeBinding fragmentHomeBinding = this._binding;
        Intrinsics.checkNotNull(fragmentHomeBinding);
        return fragmentHomeBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentHomeBinding.inflate(inflater, container, false);
        FrameLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        ImageButton settingsButton = getBinding().settingsButton;
        Intrinsics.checkNotNullExpressionValue(settingsButton, "settingsButton");
        settingsButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_settings);
            }
        });
        TextView playButton = getBinding().playButton;
        Intrinsics.checkNotNullExpressionValue(playButton, "playButton");
        playButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_levelSelect);
            }
        });
        TextView routesButton = getBinding().routesButton;
        Intrinsics.checkNotNullExpressionValue(routesButton, "routesButton");
        routesButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_routes);
            }
        });
        TextView collectionButton = getBinding().collectionButton;
        Intrinsics.checkNotNullExpressionValue(collectionButton, "collectionButton");
        collectionButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_collection);
            }
        });
        TextView achievementsButton = getBinding().achievementsButton;
        Intrinsics.checkNotNullExpressionValue(achievementsButton, "achievementsButton");
        achievementsButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_achievements);
            }
        });
        TextView statisticsButton = getBinding().statisticsButton;
        Intrinsics.checkNotNullExpressionValue(statisticsButton, "statisticsButton");
        statisticsButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).navigate(R.id.action_home_to_statistics);
            }
        });
        LinearLayout dailyCard = getBinding().dailyCard;
        Intrinsics.checkNotNullExpressionValue(dailyCard, "dailyCard");
        dailyCard.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.home.HomeFragment$onViewCreated$$inlined$onClick$7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                this.this$0.onDailyTapped();
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        Progress.INSTANCE.syncPassiveUnlocks();
        refresh();
        if (this.connectivityChecked) {
            return;
        }
        this.connectivityChecked = true;
        Connectivity connectivity = Connectivity.INSTANCE;
        Context contextRequireContext = requireContext();
        Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
        if (connectivity.isOnline(contextRequireContext)) {
            return;
        }
        new NoInternetDialog().show(getChildFragmentManager(), "no_internet");
    }

    private final void refresh() {
        int iCompletedCount = Progress.INSTANCE.completedCount();
        RouteInfo routeInfo = Catalog.INSTANCE.getRoutes().get(RangesKt.coerceIn(Progress.INSTANCE.getCurrentRouteId(), 0, Catalog.INSTANCE.getRoutes().size() - 1));
        getBinding().routeName.setText(routeInfo.getName());
        getBinding().routeTint.setBackgroundColor((int) routeInfo.getTint());
        getBinding().progressText.setText(getString(R.string.home_progress_format, Integer.valueOf(iCompletedCount), Integer.valueOf(Progress.INSTANCE.getLevelCount())));
        getBinding().progressBar.setMax(Progress.INSTANCE.getLevelCount());
        getBinding().progressBar.setProgress(iCompletedCount);
        getBinding().dailyStatus.setText(Progress.INSTANCE.isDailyAvailable(today()) ? R.string.home_daily_ready : R.string.home_daily_done);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onDailyTapped() {
        if (!Progress.INSTANCE.isDailyAvailable(today())) {
            Toast.makeText(requireContext(), R.string.home_daily_done, 0).show();
            return;
        }
        int dayOfYear = (LocalDate.now().getDayOfYear() % RangesKt.coerceIn(Progress.INSTANCE.highestUnlocked(), 1, Progress.INSTANCE.getLevelCount())) + 1;
        Bundle bundle = new Bundle();
        bundle.putInt("levelId", RangesKt.coerceIn(dayOfYear, 1, Progress.INSTANCE.getLevelCount()));
        bundle.putBoolean("daily", true);
        FragmentKt.findNavController(this).navigate(R.id.action_home_to_game, bundle);
    }

    private final String today() {
        String string = LocalDate.now().toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
