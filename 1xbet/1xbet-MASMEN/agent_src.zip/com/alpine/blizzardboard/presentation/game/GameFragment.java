package com.alpine.blizzardboard.presentation.game;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavOptionsBuilder;
import androidx.navigation.NavOptionsBuilderKt;
import androidx.navigation.PopUpToBuilder;
import androidx.navigation.fragment.FragmentKt;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.LevelOutcome;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentGameBinding;
import com.alpine.blizzardboard.databinding.ItemGoalBinding;
import com.alpine.blizzardboard.domain.level.Levels;
import com.alpine.blizzardboard.domain.model.BoosterType;
import com.alpine.blizzardboard.domain.model.GoalType;
import com.alpine.blizzardboard.domain.model.LevelConfig;
import com.alpine.blizzardboard.engine.ClearPhase;
import com.alpine.blizzardboard.engine.GameEngine;
import com.alpine.blizzardboard.engine.GoalProgress;
import com.alpine.blizzardboard.engine.GoalRuntime;
import com.alpine.blizzardboard.engine.HudState;
import com.alpine.blizzardboard.engine.Phase;
import com.alpine.blizzardboard.engine.Pos;
import com.alpine.blizzardboard.engine.ResultPhase;
import com.alpine.blizzardboard.engine.VCell;
import com.alpine.blizzardboard.presentation.common.GemUi;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: GameFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000¢\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u0000 T2\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004:\u0001TB\u0007¢\u0006\u0004\b\u0005\u0010\u0006J$\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010&2\b\u0010'\u001a\u0004\u0018\u00010(H\u0016J\u001a\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020\"2\b\u0010'\u001a\u0004\u0018\u00010(H\u0016J\b\u0010,\u001a\u00020*H\u0002J\u0010\u0010-\u001a\u00020*2\u0006\u0010.\u001a\u00020/H\u0002J\b\u00100\u001a\u00020*H\u0002J\u0018\u00101\u001a\u00020*2\u0006\u00102\u001a\u0002032\u0006\u00104\u001a\u000203H\u0016J\u0010\u00105\u001a\u00020*2\u0006\u00106\u001a\u000203H\u0016J\b\u00107\u001a\u00020*H\u0002J\b\u00108\u001a\u00020*H\u0002J\b\u00109\u001a\u00020*H\u0002J\b\u0010:\u001a\u00020*H\u0002J\u0010\u0010;\u001a\u00020*2\u0006\u0010<\u001a\u00020=H\u0002J\u0016\u0010>\u001a\u00020*2\f\u0010?\u001a\b\u0012\u0004\u0012\u00020A0@H\u0002J\u0010\u0010B\u001a\u00020*2\u0006\u0010C\u001a\u00020AH\u0002J\b\u0010D\u001a\u00020*H\u0002J\u0010\u0010E\u001a\u00020*2\u0006\u0010F\u001a\u00020\u001dH\u0002J\b\u0010G\u001a\u00020*H\u0016J\b\u0010H\u001a\u00020*H\u0016J\b\u0010I\u001a\u00020*H\u0016J\b\u0010J\u001a\u00020*H\u0002J\b\u0010K\u001a\u00020*H\u0016J\b\u0010L\u001a\u00020*H\u0002J\b\u0010M\u001a\u00020*H\u0002J\b\u0010N\u001a\u00020*H\u0002J\b\u0010O\u001a\u00020*H\u0002J\b\u0010P\u001a\u00020QH\u0002J\b\u0010R\u001a\u00020*H\u0016J\b\u0010S\u001a\u00020*H\u0016R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u001b\u0010\f\u001a\u00020\r8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u000e\u0010\u000fR\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0018\u001a\u0012\u0012\u0004\u0012\u00020\u001a0\u0019j\b\u0012\u0004\u0012\u00020\u001a`\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006U"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/GameFragment;", "Landroidx/fragment/app/Fragment;", "Lcom/alpine/blizzardboard/presentation/game/BoardView$Listener;", "Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog$Host;", "Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog$Host;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentGameBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentGameBinding;", "viewModel", "Lcom/alpine/blizzardboard/presentation/game/GameViewModel;", "getViewModel", "()Lcom/alpine/blizzardboard/presentation/game/GameViewModel;", "viewModel$delegate", "Lkotlin/Lazy;", "engine", "Lcom/alpine/blizzardboard/engine/GameEngine;", "config", "Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "daily", "", "goalBindings", "Ljava/util/ArrayList;", "Lcom/alpine/blizzardboard/databinding/ItemGoalBinding;", "Lkotlin/collections/ArrayList;", "pendingResult", "Lcom/alpine/blizzardboard/engine/ResultPhase;", "levelOver", "hintRunnable", "Ljava/lang/Runnable;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "buildGoals", "updateHud", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "refreshBoosters", "onSwap", "a", "Lcom/alpine/blizzardboard/engine/Pos;", "b", "onRemoveTap", "p", "useMoves", "useRemove", "useShuffle", "useMagnet", "emptyBoosterToast", "labelRes", "", "playPhases", "phases", "", "Lcom/alpine/blizzardboard/engine/Phase;", "handlePhase", TypedValues.CycleType.S_WAVE_PHASE, "afterPlay", "showResult", GameFragment.TAG_RESULT, "onNextLevel", "onReplay", "onRetry", "restartLevel", "onHome", "dismissResult", "scheduleHint", "cancelHint", "maybeShowHint", "today", "", "onPause", "onDestroyView", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class GameFragment extends Fragment implements BoardView.Listener, LevelCompleteDialog.Host, LevelFailedDialog.Host {
    private static final long HINT_DELAY = 5000;
    private static final String TAG_RESULT = "result";
    private FragmentGameBinding _binding;
    private LevelConfig config;
    private boolean daily;
    private GameEngine engine;
    private final ArrayList<ItemGoalBinding> goalBindings;
    private final Runnable hintRunnable;
    private boolean levelOver;
    private ResultPhase pendingResult;

    /* JADX INFO: renamed from: viewModel$delegate, reason: from kotlin metadata */
    private final Lazy viewModel;

    public GameFragment() {
        final GameFragment gameFragment = this;
        final Function0<Fragment> function0 = new Function0<Fragment>() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final Fragment invoke() {
                return gameFragment;
            }
        };
        final Lazy lazy = LazyKt.lazy(LazyThreadSafetyMode.NONE, (Function0) new Function0<ViewModelStoreOwner>() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStoreOwner invoke() {
                return (ViewModelStoreOwner) function0.invoke();
            }
        });
        final Function0 function1 = null;
        this.viewModel = FragmentViewModelLazyKt.createViewModelLazy(gameFragment, Reflection.getOrCreateKotlinClass(GameViewModel.class), new Function0<ViewModelStore>() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$special$$inlined$viewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return FragmentViewModelLazyKt.m87viewModels$lambda1(lazy).getViewModelStore();
            }
        }, new Function0<CreationExtras>() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$special$$inlined$viewModels$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function2 = function1;
                if (function2 != null && (creationExtras = (CreationExtras) function2.invoke()) != null) {
                    return creationExtras;
                }
                ViewModelStoreOwner viewModelStoreOwnerM87viewModels$lambda1 = FragmentViewModelLazyKt.m87viewModels$lambda1(lazy);
                HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = viewModelStoreOwnerM87viewModels$lambda1 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) viewModelStoreOwnerM87viewModels$lambda1 : null;
                return hasDefaultViewModelProviderFactory != null ? hasDefaultViewModelProviderFactory.getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$special$$inlined$viewModels$default$5
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory;
                ViewModelStoreOwner viewModelStoreOwnerM87viewModels$lambda1 = FragmentViewModelLazyKt.m87viewModels$lambda1(lazy);
                HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = viewModelStoreOwnerM87viewModels$lambda1 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) viewModelStoreOwnerM87viewModels$lambda1 : null;
                return (hasDefaultViewModelProviderFactory == null || (defaultViewModelProviderFactory = hasDefaultViewModelProviderFactory.getDefaultViewModelProviderFactory()) == null) ? gameFragment.getDefaultViewModelProviderFactory() : defaultViewModelProviderFactory;
            }
        });
        this.goalBindings = new ArrayList<>();
        this.hintRunnable = new Runnable() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.maybeShowHint();
            }
        };
    }

    private final FragmentGameBinding getBinding() {
        FragmentGameBinding fragmentGameBinding = this._binding;
        Intrinsics.checkNotNull(fragmentGameBinding);
        return fragmentGameBinding;
    }

    private final GameViewModel getViewModel() {
        return (GameViewModel) this.viewModel.getValue();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentGameBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        Bundle arguments = getArguments();
        int iCoerceIn = RangesKt.coerceIn(arguments != null ? arguments.getInt("levelId", 1) : 1, 1, Levels.INSTANCE.getCount());
        Bundle arguments2 = getArguments();
        this.daily = arguments2 != null ? arguments2.getBoolean("daily", false) : false;
        LevelConfig levelConfigById = Levels.INSTANCE.byId(iCoerceIn);
        if (levelConfigById == null) {
            levelConfigById = (LevelConfig) CollectionsKt.first((List) Levels.INSTANCE.getAll());
        }
        this.config = levelConfigById;
        GameViewModel viewModel = getViewModel();
        LevelConfig levelConfig = this.config;
        GameEngine gameEngine = null;
        if (levelConfig == null) {
            Intrinsics.throwUninitializedPropertyAccessException("config");
            levelConfig = null;
        }
        this.engine = viewModel.ensure(levelConfig);
        TextView textView = getBinding().levelTitle;
        int i = R.string.game_level_format;
        LevelConfig levelConfig2 = this.config;
        if (levelConfig2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("config");
            levelConfig2 = null;
        }
        textView.setText(getString(i, Integer.valueOf(levelConfig2.getId())));
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        getBinding().boardView.setListener(this);
        getBinding().boardView.setSnapshotProvider(new Function0() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return GameFragment.onViewCreated$lambda$2(this.f$0);
            }
        });
        BoardView boardView = getBinding().boardView;
        GameEngine gameEngine2 = this.engine;
        if (gameEngine2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine2 = null;
        }
        boardView.bind(gameEngine2.snapshot());
        getBinding().boosterMoves.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.useMoves();
            }
        });
        getBinding().boosterRemove.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.useRemove();
            }
        });
        getBinding().boosterShuffle.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.useShuffle();
            }
        });
        getBinding().boosterMagnet.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.useMagnet();
            }
        });
        buildGoals();
        GameEngine gameEngine3 = this.engine;
        if (gameEngine3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
        } else {
            gameEngine = gameEngine3;
        }
        updateHud(gameEngine.hud());
        refreshBoosters();
        scheduleHint();
    }

    static final VCell[][] onViewCreated$lambda$2(GameFragment gameFragment) {
        GameEngine gameEngine = gameFragment.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        return gameEngine.snapshot();
    }

    private final void buildGoals() {
        this.goalBindings.clear();
        getBinding().goalContainer.removeAllViews();
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        for (GoalRuntime goalRuntime : gameEngine.getGoals()) {
            ItemGoalBinding itemGoalBindingInflate = ItemGoalBinding.inflate(getLayoutInflater(), getBinding().goalContainer, false);
            Intrinsics.checkNotNullExpressionValue(itemGoalBindingInflate, "inflate(...)");
            itemGoalBindingInflate.goalIcon.setImageResource(GemUi.INSTANCE.goalIcon(goalRuntime.getGoal()));
            TextView textView = itemGoalBindingInflate.goalLabel;
            GemUi gemUi = GemUi.INSTANCE;
            Context contextRequireContext = requireContext();
            Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
            textView.setText(gemUi.goalLabel(contextRequireContext, goalRuntime.getGoal()));
            getBinding().goalContainer.addView(itemGoalBindingInflate.getRoot());
            this.goalBindings.add(itemGoalBindingInflate);
        }
    }

    private final void updateHud(HudState hud) {
        getBinding().scoreValue.setText(String.valueOf(hud.getScore()));
        getBinding().movesValue.setText(String.valueOf(hud.getMovesLeft()));
        int size = this.goalBindings.size();
        for (int i = 0; i < size; i++) {
            GoalProgress goalProgress = (GoalProgress) CollectionsKt.getOrNull(hud.getGoals(), i);
            if (goalProgress != null) {
                goalProgress.getGoal().getType();
                GoalType goalType = GoalType.REACH_SCORE;
                this.goalBindings.get(i).goalCount.setText(getString(R.string.progress_fraction, Integer.valueOf(goalProgress.getCurrent()), Integer.valueOf(goalProgress.getGoal().getTarget())));
                this.goalBindings.get(i).goalCount.setTextColor(requireContext().getColor(goalProgress.getDone() ? R.color.level_done_stroke : R.color.snow_white));
            }
        }
    }

    private final void refreshBoosters() {
        getBinding().boosterMovesCount.setText(getString(R.string.count_format, Integer.valueOf(Progress.INSTANCE.boosterCount(BoosterType.EXTRA_MOVES))));
        getBinding().boosterRemoveCount.setText(getString(R.string.count_format, Integer.valueOf(Progress.INSTANCE.boosterCount(BoosterType.REMOVE_ITEM))));
        getBinding().boosterShuffleCount.setText(getString(R.string.count_format, Integer.valueOf(Progress.INSTANCE.boosterCount(BoosterType.SHUFFLE))));
        getBinding().boosterMagnetCount.setText(getString(R.string.count_format, Integer.valueOf(Progress.INSTANCE.boosterCount(BoosterType.GOAL_MAGNET))));
    }

    @Override // com.alpine.blizzardboard.presentation.game.BoardView.Listener
    public void onSwap(Pos a, Pos b) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        if (getBinding().boardView.getAnimating() || this.levelOver) {
            return;
        }
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        List<Phase> listTrySwap = gameEngine.trySwap(a, b);
        if (listTrySwap.isEmpty()) {
            return;
        }
        List<Phase> list = listTrySwap;
        if (!(list instanceof Collection) || !list.isEmpty()) {
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                if (((Phase) it.next()) instanceof ClearPhase) {
                    Progress.INSTANCE.addMatches(1);
                    break;
                }
            }
        }
        cancelHint();
        SoundManager.INSTANCE.click();
        playPhases(listTrySwap);
    }

    @Override // com.alpine.blizzardboard.presentation.game.BoardView.Listener
    public void onRemoveTap(Pos p) {
        Intrinsics.checkNotNullParameter(p, "p");
        if (getBinding().boardView.getAnimating() || this.levelOver || Progress.INSTANCE.boosterCount(BoosterType.REMOVE_ITEM) <= 0) {
            return;
        }
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        List<Phase> listRemoveAt = gameEngine.removeAt(p);
        if (listRemoveAt.isEmpty()) {
            return;
        }
        Progress.INSTANCE.consumeBooster(BoosterType.REMOVE_ITEM);
        refreshBoosters();
        cancelHint();
        playPhases(listRemoveAt);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void useMoves() {
        if (getBinding().boardView.getAnimating() || this.levelOver) {
            return;
        }
        SoundManager.INSTANCE.click();
        if (Progress.INSTANCE.boosterCount(BoosterType.EXTRA_MOVES) <= 0) {
            emptyBoosterToast(R.string.booster_moves);
            return;
        }
        Progress.INSTANCE.consumeBooster(BoosterType.EXTRA_MOVES);
        refreshBoosters();
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        playPhases(gameEngine.addExtraMoves(5));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void useRemove() {
        if (getBinding().boardView.getAnimating() || this.levelOver) {
            return;
        }
        SoundManager.INSTANCE.click();
        if (Progress.INSTANCE.boosterCount(BoosterType.REMOVE_ITEM) <= 0) {
            emptyBoosterToast(R.string.booster_remove);
        } else {
            getBinding().boardView.setRemoveMode(true);
            Toast.makeText(requireContext(), R.string.booster_remove_hint, 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void useShuffle() {
        if (getBinding().boardView.getAnimating() || this.levelOver) {
            return;
        }
        SoundManager.INSTANCE.click();
        if (Progress.INSTANCE.boosterCount(BoosterType.SHUFFLE) <= 0) {
            emptyBoosterToast(R.string.booster_shuffle);
            return;
        }
        Progress.INSTANCE.consumeBooster(BoosterType.SHUFFLE);
        refreshBoosters();
        cancelHint();
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        playPhases(gameEngine.doShuffle());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void useMagnet() {
        if (getBinding().boardView.getAnimating() || this.levelOver) {
            return;
        }
        SoundManager.INSTANCE.click();
        if (Progress.INSTANCE.boosterCount(BoosterType.GOAL_MAGNET) <= 0) {
            emptyBoosterToast(R.string.booster_magnet);
            return;
        }
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        List<Phase> listUseMagnet = gameEngine.useMagnet();
        if (listUseMagnet.isEmpty()) {
            return;
        }
        Progress.INSTANCE.consumeBooster(BoosterType.GOAL_MAGNET);
        refreshBoosters();
        cancelHint();
        playPhases(listUseMagnet);
    }

    private final void emptyBoosterToast(int labelRes) {
        Toast.makeText(requireContext(), getString(R.string.booster_empty, getString(labelRes)), 0).show();
    }

    private final void playPhases(List<? extends Phase> phases) {
        getBinding().boardView.play(phases, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return GameFragment.playPhases$lambda$8(this.f$0, (Phase) obj);
            }
        }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return GameFragment.playPhases$lambda$9(this.f$0);
            }
        });
    }

    static final Unit playPhases$lambda$8(GameFragment gameFragment, Phase it) {
        Intrinsics.checkNotNullParameter(it, "it");
        gameFragment.handlePhase(it);
        return Unit.INSTANCE;
    }

    static final Unit playPhases$lambda$9(GameFragment gameFragment) {
        gameFragment.afterPlay();
        return Unit.INSTANCE;
    }

    private final void handlePhase(Phase phase) {
        updateHud(phase.getHud());
        if (phase instanceof ClearPhase) {
            SoundManager.INSTANCE.coin();
            ClearPhase clearPhase = (ClearPhase) phase;
            if (!clearPhase.getCreated().isEmpty()) {
                getViewModel().setMadeSpecial(true);
            }
            if (clearPhase.getCombo() >= 2) {
                getBinding().comboText.setVisibility(0);
                getBinding().comboText.setText(getString(R.string.combo_format, Integer.valueOf(clearPhase.getCombo())));
                return;
            } else {
                getBinding().comboText.setVisibility(4);
                return;
            }
        }
        if (phase instanceof ResultPhase) {
            ResultPhase resultPhase = (ResultPhase) phase;
            this.pendingResult = resultPhase;
            if (resultPhase.getSuccess()) {
                SoundManager.INSTANCE.success();
            } else {
                SoundManager.INSTANCE.lose();
            }
        }
    }

    private final void afterPlay() {
        getBinding().comboText.setVisibility(4);
        refreshBoosters();
        ResultPhase resultPhase = this.pendingResult;
        if (resultPhase != null) {
            this.pendingResult = null;
            showResult(resultPhase);
        } else {
            scheduleHint();
        }
    }

    private final void showResult(ResultPhase result) {
        boolean z;
        this.levelOver = true;
        cancelHint();
        if (result.getSuccess()) {
            if (this.daily && Progress.INSTANCE.isDailyAvailable(today())) {
                Progress.INSTANCE.claimDaily(today());
            }
            GameEngine gameEngine = this.engine;
            LevelConfig levelConfig = null;
            if (gameEngine == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                gameEngine = null;
            }
            List<GoalRuntime> goals = gameEngine.getGoals();
            if (!(goals instanceof Collection) || !goals.isEmpty()) {
                Iterator<T> it = goals.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        z = false;
                        break;
                    }
                    GoalRuntime goalRuntime = (GoalRuntime) it.next();
                    if (goalRuntime.getGoal().getType() == GoalType.CLEAR_SNOW && goalRuntime.getDone()) {
                        z = true;
                        break;
                    }
                }
            } else {
                z = false;
                break;
            }
            Progress progress = Progress.INSTANCE;
            LevelConfig levelConfig2 = this.config;
            if (levelConfig2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("config");
                levelConfig2 = null;
            }
            int id = levelConfig2.getId();
            int stars = result.getStars();
            int score = result.getScore();
            GameEngine gameEngine2 = this.engine;
            if (gameEngine2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                gameEngine2 = null;
            }
            LevelOutcome levelOutcomeOnLevelComplete = progress.onLevelComplete(id, stars, score, gameEngine2.getBestCombo(), getViewModel().getMadeSpecial(), z);
            int size = levelOutcomeOnLevelComplete.getNewAchievements().size() + levelOutcomeOnLevelComplete.getNewCollectibles().size();
            if (size > 0) {
                Toast.makeText(requireContext(), "New unlocks: " + size, 0).show();
            }
            LevelCompleteDialog.Companion companion = LevelCompleteDialog.INSTANCE;
            int stars2 = result.getStars();
            int score2 = result.getScore();
            LevelConfig levelConfig3 = this.config;
            if (levelConfig3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("config");
            } else {
                levelConfig = levelConfig3;
            }
            companion.newInstance(stars2, score2, levelConfig.getId() < Levels.INSTANCE.getCount()).show(getChildFragmentManager(), TAG_RESULT);
            return;
        }
        Progress.INSTANCE.onLevelFailed();
        LevelFailedDialog.INSTANCE.newInstance(result.getScore()).show(getChildFragmentManager(), TAG_RESULT);
    }

    @Override // com.alpine.blizzardboard.presentation.game.LevelCompleteDialog.Host
    public void onNextLevel() {
        dismissResult();
        LevelConfig levelConfig = this.config;
        if (levelConfig == null) {
            Intrinsics.throwUninitializedPropertyAccessException("config");
            levelConfig = null;
        }
        int iCoerceAtMost = RangesKt.coerceAtMost(levelConfig.getId() + 1, Levels.INSTANCE.getCount());
        Bundle bundle = new Bundle();
        bundle.putInt("levelId", iCoerceAtMost);
        bundle.putBoolean("daily", false);
        FragmentKt.findNavController(this).navigate(R.id.gameFragment, bundle, NavOptionsBuilderKt.navOptions(new Function1() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return GameFragment.onNextLevel$lambda$13((NavOptionsBuilder) obj);
            }
        }));
    }

    static final Unit onNextLevel$lambda$13(NavOptionsBuilder navOptions) {
        Intrinsics.checkNotNullParameter(navOptions, "$this$navOptions");
        navOptions.popUpTo(R.id.gameFragment, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.GameFragment$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return GameFragment.onNextLevel$lambda$13$lambda$12((PopUpToBuilder) obj);
            }
        });
        return Unit.INSTANCE;
    }

    static final Unit onNextLevel$lambda$13$lambda$12(PopUpToBuilder popUpTo) {
        Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(true);
        return Unit.INSTANCE;
    }

    @Override // com.alpine.blizzardboard.presentation.game.LevelCompleteDialog.Host
    public void onReplay() {
        restartLevel();
    }

    @Override // com.alpine.blizzardboard.presentation.game.LevelFailedDialog.Host
    public void onRetry() {
        restartLevel();
    }

    private final void restartLevel() {
        dismissResult();
        GameViewModel viewModel = getViewModel();
        LevelConfig levelConfig = this.config;
        GameEngine gameEngine = null;
        if (levelConfig == null) {
            Intrinsics.throwUninitializedPropertyAccessException("config");
            levelConfig = null;
        }
        this.engine = viewModel.reset(levelConfig);
        this.levelOver = false;
        BoardView boardView = getBinding().boardView;
        GameEngine gameEngine2 = this.engine;
        if (gameEngine2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine2 = null;
        }
        boardView.bind(gameEngine2.snapshot());
        GameEngine gameEngine3 = this.engine;
        if (gameEngine3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
        } else {
            gameEngine = gameEngine3;
        }
        updateHud(gameEngine.hud());
        refreshBoosters();
        scheduleHint();
    }

    @Override // com.alpine.blizzardboard.presentation.game.LevelCompleteDialog.Host, com.alpine.blizzardboard.presentation.game.LevelFailedDialog.Host
    public void onHome() {
        dismissResult();
        FragmentKt.findNavController(this).popBackStack(R.id.homeFragment, false);
    }

    private final void dismissResult() {
        Fragment fragmentFindFragmentByTag = getChildFragmentManager().findFragmentByTag(TAG_RESULT);
        DialogFragment dialogFragment = fragmentFindFragmentByTag instanceof DialogFragment ? (DialogFragment) fragmentFindFragmentByTag : null;
        if (dialogFragment != null) {
            dialogFragment.dismissAllowingStateLoss();
        }
    }

    private final void scheduleHint() {
        FragmentGameBinding fragmentGameBinding;
        LinearLayout root;
        cancelHint();
        if (this.levelOver || (fragmentGameBinding = this._binding) == null || (root = fragmentGameBinding.getRoot()) == null) {
            return;
        }
        root.postDelayed(this.hintRunnable, 5000L);
    }

    private final void cancelHint() {
        BoardView boardView;
        LinearLayout root;
        FragmentGameBinding fragmentGameBinding = this._binding;
        if (fragmentGameBinding != null && (root = fragmentGameBinding.getRoot()) != null) {
            root.removeCallbacks(this.hintRunnable);
        }
        FragmentGameBinding fragmentGameBinding2 = this._binding;
        if (fragmentGameBinding2 == null || (boardView = fragmentGameBinding2.boardView) == null) {
            return;
        }
        boardView.clearHint();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeShowHint() {
        if (this.levelOver || this._binding == null || getBinding().boardView.getAnimating()) {
            return;
        }
        GameEngine gameEngine = this.engine;
        if (gameEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            gameEngine = null;
        }
        Pair<Pos, Pos> pairHint = gameEngine.hint();
        if (pairHint != null) {
            getBinding().boardView.showHint(pairHint.getFirst(), pairHint.getSecond());
        }
    }

    private final String today() {
        String string = LocalDate.now().toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        cancelHint();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        cancelHint();
        this._binding = null;
    }
}
