package com.alpine.blizzardboard.presentation.game;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultCaller;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.KeyEventDispatcher;
import androidx.fragment.app.DialogFragment;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.DialogLevelCompleteBinding;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: LevelCompleteDialog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \u001a2\u00020\u0001:\u0002\u0019\u001aB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u0012\u0010\u0011\u001a\u00020\u00122\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\n\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0002J\b\u0010\u0018\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u001b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/DialogLevelCompleteBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/DialogLevelCompleteBinding;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "onViewCreated", "", "view", "host", "Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog$Host;", "onDestroyView", "Host", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class LevelCompleteDialog extends DialogFragment {
    private static final String ARG_HAS_NEXT = "hasNext";
    private static final String ARG_SCORE = "score";
    private static final String ARG_STARS = "stars";

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private DialogLevelCompleteBinding _binding;

    /* JADX INFO: compiled from: LevelCompleteDialog.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\b\u0010\u0004\u001a\u00020\u0003H&J\b\u0010\u0005\u001a\u00020\u0003H&¨\u0006\u0006À\u0006\u0003"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog$Host;", "", "onNextLevel", "", "onReplay", "onHome", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public interface Host {
        void onHome();

        void onNextLevel();

        void onReplay();
    }

    private final DialogLevelCompleteBinding getBinding() {
        DialogLevelCompleteBinding dialogLevelCompleteBinding = this._binding;
        Intrinsics.checkNotNull(dialogLevelCompleteBinding);
        return dialogLevelCompleteBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = DialogLevelCompleteBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialogOnCreateDialog = super.onCreateDialog(savedInstanceState);
        Intrinsics.checkNotNullExpressionValue(dialogOnCreateDialog, "onCreateDialog(...)");
        Window window = dialogOnCreateDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        setCancelable(false);
        return dialogOnCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        Bundle arguments = getArguments();
        int i = arguments != null ? arguments.getInt(ARG_STARS) : 1;
        Bundle arguments2 = getArguments();
        int i2 = arguments2 != null ? arguments2.getInt(ARG_SCORE) : 0;
        Bundle arguments3 = getArguments();
        boolean z = arguments3 != null ? arguments3.getBoolean(ARG_HAS_NEXT) : false;
        List listListOf = CollectionsKt.listOf((Object[]) new ImageView[]{getBinding().star1, getBinding().star2, getBinding().star3});
        int size = listListOf.size();
        int i3 = 0;
        while (i3 < size) {
            ((ImageView) listListOf.get(i3)).setImageResource(i3 < i ? R.drawable.ic_star : R.drawable.ic_star_off);
            i3++;
        }
        getBinding().completeScore.setText(getString(R.string.dialog_score, Integer.valueOf(i2)));
        getBinding().nextButton.setVisibility(z ? 0 : 8);
        TextView nextButton = getBinding().nextButton;
        Intrinsics.checkNotNullExpressionValue(nextButton, "nextButton");
        nextButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.LevelCompleteDialog$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                LevelCompleteDialog.Host host = this.this$0.host();
                if (host != null) {
                    host.onNextLevel();
                }
            }
        });
        TextView retryButton = getBinding().retryButton;
        Intrinsics.checkNotNullExpressionValue(retryButton, "retryButton");
        retryButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.LevelCompleteDialog$onViewCreated$$inlined$onClick$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                LevelCompleteDialog.Host host = this.this$0.host();
                if (host != null) {
                    host.onReplay();
                }
            }
        });
        TextView homeButton = getBinding().homeButton;
        Intrinsics.checkNotNullExpressionValue(homeButton, "homeButton");
        homeButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.LevelCompleteDialog$onViewCreated$$inlined$onClick$3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                LevelCompleteDialog.Host host = this.this$0.host();
                if (host != null) {
                    host.onHome();
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Host host() {
        ActivityResultCaller parentFragment = getParentFragment();
        Host host = parentFragment instanceof Host ? (Host) parentFragment : null;
        if (host != null) {
            return host;
        }
        KeyEventDispatcher.Component activity = getActivity();
        if (activity instanceof Host) {
            return (Host) activity;
        }
        return null;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }

    /* JADX INFO: compiled from: LevelCompleteDialog.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog$Companion;", "", "<init>", "()V", "ARG_STARS", "", "ARG_SCORE", "ARG_HAS_NEXT", "newInstance", "Lcom/alpine/blizzardboard/presentation/game/LevelCompleteDialog;", LevelCompleteDialog.ARG_STARS, "", LevelCompleteDialog.ARG_SCORE, LevelCompleteDialog.ARG_HAS_NEXT, "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final LevelCompleteDialog newInstance(int stars, int score, boolean hasNext) {
            LevelCompleteDialog levelCompleteDialog = new LevelCompleteDialog();
            Bundle bundle = new Bundle();
            bundle.putInt(LevelCompleteDialog.ARG_STARS, stars);
            bundle.putInt(LevelCompleteDialog.ARG_SCORE, score);
            bundle.putBoolean(LevelCompleteDialog.ARG_HAS_NEXT, hasNext);
            levelCompleteDialog.setArguments(bundle);
            return levelCompleteDialog;
        }
    }
}
