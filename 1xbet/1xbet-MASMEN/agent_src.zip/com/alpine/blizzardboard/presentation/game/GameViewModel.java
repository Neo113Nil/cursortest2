package com.alpine.blizzardboard.presentation.game;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModel;
import com.alpine.blizzardboard.domain.model.LevelConfig;
import com.alpine.blizzardboard.engine.GameEngine;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: GameViewModel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011R\"\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006\u0013"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/GameViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "value", "Lcom/alpine/blizzardboard/engine/GameEngine;", "engine", "getEngine", "()Lcom/alpine/blizzardboard/engine/GameEngine;", "madeSpecial", "", "getMadeSpecial", "()Z", "setMadeSpecial", "(Z)V", "ensure", "config", "Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "reset", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class GameViewModel extends ViewModel {
    private GameEngine engine;
    private boolean madeSpecial;

    public final GameEngine getEngine() {
        return this.engine;
    }

    public final boolean getMadeSpecial() {
        return this.madeSpecial;
    }

    public final void setMadeSpecial(boolean z) {
        this.madeSpecial = z;
    }

    public final GameEngine ensure(LevelConfig config) {
        Intrinsics.checkNotNullParameter(config, "config");
        GameEngine gameEngine = this.engine;
        if (gameEngine != null) {
            return gameEngine;
        }
        GameEngine gameEngine2 = new GameEngine(config, 0L, 2, null);
        this.engine = gameEngine2;
        return gameEngine2;
    }

    public final GameEngine reset(LevelConfig config) {
        Intrinsics.checkNotNullParameter(config, "config");
        this.madeSpecial = false;
        GameEngine gameEngine = new GameEngine(config, 0L, 2, null);
        this.engine = gameEngine;
        return gameEngine;
    }
}
