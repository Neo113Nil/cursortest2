package com.alpine.blizzardboard.presentation.game;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.domain.model.Blocker;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Special;
import com.alpine.blizzardboard.engine.ClearPhase;
import com.alpine.blizzardboard.engine.FallPhase;
import com.alpine.blizzardboard.engine.GemMove;
import com.alpine.blizzardboard.engine.GemSpawn;
import com.alpine.blizzardboard.engine.Phase;
import com.alpine.blizzardboard.engine.Pos;
import com.alpine.blizzardboard.engine.ResultPhase;
import com.alpine.blizzardboard.engine.ShufflePhase;
import com.alpine.blizzardboard.engine.StatePhase;
import com.alpine.blizzardboard.engine.SwapPhase;
import com.alpine.blizzardboard.engine.VCell;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.scheduling.WorkQueueKt;

/* JADX INFO: compiled from: BoardView.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000ì\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0004®\u0001¯\u0001B'\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010S\u001a\u00020\u00072\u0006\u0010T\u001a\u000201H\u0002J)\u0010U\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020!0\u00120\u00122\u0006\u0010V\u001a\u00020\u00072\u0006\u0010W\u001a\u00020\u0007H\u0002¢\u0006\u0002\u0010XJ\b\u0010Y\u001a\u00020ZH\u0002J\b\u0010[\u001a\u00020ZH\u0002J\u001f\u0010\\\u001a\u00020Z2\u0012\u0010]\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\u0012¢\u0006\u0002\u0010^J-\u0010_\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020!0\u00120\u00122\u0012\u0010`\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\u0012H\u0002¢\u0006\u0002\u0010aJ\u0018\u0010c\u001a\u00020Z2\u0006\u0010d\u001a\u00020\u00072\u0006\u0010e\u001a\u00020\u0007H\u0014J(\u0010f\u001a\u00020Z2\u0006\u0010g\u001a\u00020\u00072\u0006\u0010h\u001a\u00020\u00072\u0006\u0010i\u001a\u00020\u00072\u0006\u0010j\u001a\u00020\u0007H\u0014J\u0010\u0010k\u001a\u00020Z2\u0006\u0010l\u001a\u00020mH\u0014J(\u0010n\u001a\u00020.2\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$2\u0006\u0010q\u001a\u00020$2\u0006\u0010r\u001a\u00020$H\u0002J@\u0010s\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010V\u001a\u00020\u00072\u0006\u0010W\u001a\u00020\u00072\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$2\u0006\u0010t\u001a\u0002012\u0006\u0010u\u001a\u00020vH\u0002J(\u0010w\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010x\u001a\u00020.2\u0006\u0010u\u001a\u00020v2\u0006\u0010y\u001a\u00020\u0007H\u0002J(\u0010z\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$2\u0006\u0010{\u001a\u00020\u0007H\u0002J(\u0010|\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$2\u0006\u0010{\u001a\u00020\u0007H\u0002J(\u0010}\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$2\u0006\u0010~\u001a\u00020\u007fH\u0002J!\u0010\u0080\u0001\u001a\u00020Z2\u0006\u0010l\u001a\u00020m2\u0006\u0010o\u001a\u00020$2\u0006\u0010p\u001a\u00020$H\u0002J\u0011\u0010\u0081\u0001\u001a\u00020Z2\u0006\u0010l\u001a\u00020mH\u0002J\u0011\u0010\u0082\u0001\u001a\u00020Z2\u0006\u0010l\u001a\u00020mH\u0002J,\u0010\u0083\u0001\u001a\u00020\u00072\u0007\u0010\u0084\u0001\u001a\u00020\u00072\u0006\u0010V\u001a\u00020\u00072\u0007\u0010\u0085\u0001\u001a\u00020\u00072\u0007\u0010\u0086\u0001\u001a\u00020\u0007H\u0002J\u0013\u0010\u0087\u0001\u001a\u00020\u00192\b\u0010\u0088\u0001\u001a\u00030\u0089\u0001H\u0016J\u0019\u0010\u008a\u0001\u001a\u00020\u00192\u0006\u0010V\u001a\u00020\u00072\u0006\u0010W\u001a\u00020\u0007H\u0002J\u001b\u0010\u008b\u0001\u001a\u00020\u00192\u0007\u0010\u0084\u0001\u001a\u00020D2\u0007\u0010\u0086\u0001\u001a\u00020DH\u0002J\u0019\u0010\u008c\u0001\u001a\u00020Z2\u0007\u0010\u0084\u0001\u001a\u00020D2\u0007\u0010\u0086\u0001\u001a\u00020DJ\u0007\u0010\u008d\u0001\u001a\u00020ZJ>\u0010\u0095\u0001\u001a\u00020Z2\u000f\u0010\u008e\u0001\u001a\n\u0012\u0005\u0012\u00030\u0090\u00010\u008f\u00012\u0015\u0010\u0092\u0001\u001a\u0010\u0012\u0005\u0012\u00030\u0090\u0001\u0012\u0004\u0012\u00020Z0\u0093\u00012\r\u0010\u0094\u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011J\t\u0010\u0096\u0001\u001a\u00020ZH\u0002J\t\u0010\u0097\u0001\u001a\u00020ZH\u0002J8\u0010\u0098\u0001\u001a\u00020Z2\b\u0010\u0099\u0001\u001a\u00030\u009a\u00012\u0014\u0010\u009b\u0001\u001a\u000f\u0012\u0004\u0012\u00020$\u0012\u0004\u0012\u00020Z0\u0093\u00012\r\u0010\u009c\u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011H\u0002J\"\u0010\u009d\u0001\u001a\u00020Z2\b\u0010\u009e\u0001\u001a\u00030\u009f\u00012\r\u0010 \u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011H\u0002J$\u0010¡\u0001\u001a\u00020Z2\u0007\u0010¢\u0001\u001a\u00020D2\u0007\u0010£\u0001\u001a\u00020$2\u0007\u0010¤\u0001\u001a\u00020$H\u0002J\u0012\u0010¥\u0001\u001a\u00020\u00192\u0007\u0010¢\u0001\u001a\u00020DH\u0002J\u001b\u0010¦\u0001\u001a\u00020Z2\u0007\u0010\u0084\u0001\u001a\u00020D2\u0007\u0010\u0086\u0001\u001a\u00020DH\u0002J\"\u0010§\u0001\u001a\u00020Z2\b\u0010\u009e\u0001\u001a\u00030¨\u00012\r\u0010 \u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011H\u0002J\u0013\u0010©\u0001\u001a\u00020Z2\b\u0010\u009e\u0001\u001a\u00030¨\u0001H\u0002J\"\u0010ª\u0001\u001a\u00020Z2\b\u0010\u009e\u0001\u001a\u00030«\u00012\r\u0010 \u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011H\u0002J\u0013\u0010¬\u0001\u001a\u00020Z2\b\u0010\u009e\u0001\u001a\u00030«\u0001H\u0002J\u0018\u0010\u00ad\u0001\u001a\u00020Z2\r\u0010 \u0001\u001a\b\u0012\u0004\u0012\u00020Z0\u0011H\u0002R\u001c\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR.\u0010\u0010\u001a\u0016\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\u0012\u0018\u00010\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0018\u001a\u00020\u0019X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u000e\u0010\u001e\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010 \u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020!0\u00120\u0012X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\"R\u000e\u0010#\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u0004¢\u0006\u0002\n\u0000R.\u0010/\u001a\"\u0012\u0004\u0012\u000201\u0012\u0006\u0012\u0004\u0018\u00010200j\u0010\u0012\u0004\u0012\u000201\u0012\u0006\u0012\u0004\u0018\u000102`3X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u00104\u001a\u0004\u0018\u0001028BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b7\u00108\u001a\u0004\b5\u00106R\u0016\u00109\u001a\b\u0012\u0004\u0012\u00020:0\u0012X\u0082.¢\u0006\u0004\n\u0002\u0010;R\u0016\u0010<\u001a\b\u0012\u0004\u0012\u00020=0\u0012X\u0082.¢\u0006\u0004\n\u0002\u0010>R\u0016\u0010?\u001a\b\u0012\u0004\u0012\u00020:0\u0012X\u0082.¢\u0006\u0004\n\u0002\u0010;R\u0016\u0010@\u001a\b\u0012\u0004\u0012\u00020:0\u0012X\u0082.¢\u0006\u0004\n\u0002\u0010;R\u0016\u0010A\u001a\b\u0012\u0004\u0012\u00020:0\u0012X\u0082.¢\u0006\u0004\n\u0002\u0010;R\u000e\u0010B\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010C\u001a\u0004\u0018\u00010DX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010E\u001a\u0004\u0018\u00010DX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010F\u001a\u0004\u0018\u00010DX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010H\u001a\u0004\u0018\u00010IX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010O\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010P\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010Q\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010R\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010b\u001a\u00020\u00198F¢\u0006\u0006\u001a\u0004\bb\u0010\u001bR\u0017\u0010\u008e\u0001\u001a\n\u0012\u0005\u0012\u00030\u0090\u00010\u008f\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0091\u0001\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u001f\u0010\u0092\u0001\u001a\u0012\u0012\u0005\u0012\u00030\u0090\u0001\u0012\u0004\u0012\u00020Z\u0018\u00010\u0093\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010\u0094\u0001\u001a\n\u0012\u0004\u0012\u00020Z\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006°\u0001"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/BoardView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyle", "", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "listener", "Lcom/alpine/blizzardboard/presentation/game/BoardView$Listener;", "getListener", "()Lcom/alpine/blizzardboard/presentation/game/BoardView$Listener;", "setListener", "(Lcom/alpine/blizzardboard/presentation/game/BoardView$Listener;)V", "snapshotProvider", "Lkotlin/Function0;", "", "Lcom/alpine/blizzardboard/engine/VCell;", "getSnapshotProvider", "()Lkotlin/jvm/functions/Function0;", "setSnapshotProvider", "(Lkotlin/jvm/functions/Function0;)V", "removeMode", "", "getRemoveMode", "()Z", "setRemoveMode", "(Z)V", "rows", "cols", "grid", "Lcom/alpine/blizzardboard/presentation/game/BoardView$VisCell;", "[[Lcom/alpine/blizzardboard/presentation/game/BoardView$VisCell;", "cell", "", "inset", "radius", "bgPaint", "Landroid/graphics/Paint;", "strokePaint", "coatPaint", "linePaint", "glowPaint", "rect", "Landroid/graphics/RectF;", "drawables", "Ljava/util/HashMap;", "Lcom/alpine/blizzardboard/domain/model/GemType;", "Landroid/graphics/drawable/Drawable;", "Lkotlin/collections/HashMap;", "lockDrawable", "getLockDrawable", "()Landroid/graphics/drawable/Drawable;", "lockDrawable$delegate", "Lkotlin/Lazy;", "animScale", "", "[[F", "animAlpha", "", "[[I", "animOffX", "animOffY", "startOffY", "animating", "selected", "Lcom/alpine/blizzardboard/engine/Pos;", "hintA", "hintB", "hintPulse", "hintAnimator", "Landroid/animation/ValueAnimator;", "downCol", "downRow", "downX", "downY", "swipeHandled", "cellBg", "cellStroke", "selColor", "goldColor", "gemRes", "t", "emptyGrid", "r", "c", "(II)[[Lcom/alpine/blizzardboard/presentation/game/BoardView$VisCell;", "allocAnims", "", "resetAnims", "bind", "snapshot", "([[Lcom/alpine/blizzardboard/engine/VCell;)V", "visFrom", "s", "([[Lcom/alpine/blizzardboard/engine/VCell;)[[Lcom/alpine/blizzardboard/presentation/game/BoardView$VisCell;", "isBusy", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onSizeChanged", "w", "h", "oldw", "oldh", "onDraw", "canvas", "Landroid/graphics/Canvas;", "cellRect", "left", "top", "scale", "pad", "drawGem", "type", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "drawSpecialMark", "gr", "alpha", "drawSnow", "layers", "drawIce", "drawBlocker", "blocker", "Lcom/alpine/blizzardboard/domain/model/Blocker;", "drawLocked", "drawSelection", "drawHint", "argb", "a", "g", "b", "onTouchEvent", NotificationCompat.CATEGORY_EVENT, "Landroid/view/MotionEvent;", "inGrid", "isAdjacent", "showHint", "clearHint", "phases", "", "Lcom/alpine/blizzardboard/engine/Phase;", "phaseIndex", "onPhase", "Lkotlin/Function1;", "onComplete", "play", "playNext", "advance", "runAnimator", TypedValues.TransitionType.S_DURATION, "", "update", "end", "animateSwap", TypedValues.CycleType.S_WAVE_PHASE, "Lcom/alpine/blizzardboard/engine/SwapPhase;", "done", "setOff", "p", "x", "y", "inRange", "swapVis", "animateClear", "Lcom/alpine/blizzardboard/engine/ClearPhase;", "applyClear", "animateFall", "Lcom/alpine/blizzardboard/engine/FallPhase;", "applyFall", "animateShuffle", "Listener", "VisCell", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class BoardView extends View {
    private int[][] animAlpha;
    private float[][] animOffX;
    private float[][] animOffY;
    private float[][] animScale;
    private boolean animating;
    private final Paint bgPaint;
    private float cell;
    private final int cellBg;
    private final int cellStroke;
    private final Paint coatPaint;
    private int cols;
    private int downCol;
    private int downRow;
    private float downX;
    private float downY;
    private final HashMap<GemType, Drawable> drawables;
    private final Paint glowPaint;
    private final int goldColor;
    private VisCell[][] grid;
    private Pos hintA;
    private ValueAnimator hintAnimator;
    private Pos hintB;
    private float hintPulse;
    private float inset;
    private final Paint linePaint;
    private Listener listener;

    /* JADX INFO: renamed from: lockDrawable$delegate, reason: from kotlin metadata */
    private final Lazy lockDrawable;
    private Function0<Unit> onComplete;
    private Function1<? super Phase, Unit> onPhase;
    private int phaseIndex;
    private List<? extends Phase> phases;
    private float radius;
    private final RectF rect;
    private boolean removeMode;
    private int rows;
    private final int selColor;
    private Pos selected;
    private Function0<VCell[][]> snapshotProvider;
    private float[][] startOffY;
    private final Paint strokePaint;
    private boolean swipeHandled;

    /* JADX INFO: compiled from: BoardView.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H&J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\u0005H&¨\u0006\tÀ\u0006\u0003"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/BoardView$Listener;", "", "onSwap", "", "a", "Lcom/alpine/blizzardboard/engine/Pos;", "b", "onRemoveTap", "p", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public interface Listener {
        void onRemoveTap(Pos p);

        void onSwap(Pos a, Pos b);
    }

    /* JADX INFO: compiled from: BoardView.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[GemType.values().length];
            try {
                iArr[GemType.SNOWBOARD.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[GemType.HELMET.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[GemType.GOGGLES.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[GemType.GLOVE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[GemType.SNOWFLAKE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[GemType.FLAG.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[GemType.MEDAL.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Special.values().length];
            try {
                iArr2[Special.LINE_H.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr2[Special.LINE_V.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr2[Special.BOMB.ordinal()] = 3;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr2[Special.POWER.ordinal()] = 4;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr2[Special.NONE.ordinal()] = 5;
            } catch (NoSuchFieldError unused12) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public BoardView(Context context) {
        this(context, null, 0, 6, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public BoardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    private final int argb(int a, int r, int g, int b) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public /* synthetic */ BoardView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public BoardView(final Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Intrinsics.checkNotNullParameter(context, "context");
        this.rows = 8;
        this.cols = 8;
        this.grid = emptyGrid(8, 8);
        this.bgPaint = new Paint(1);
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.strokePaint = paint;
        this.coatPaint = new Paint(1);
        Paint paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.STROKE);
        this.linePaint = paint2;
        Paint paint3 = new Paint(1);
        paint3.setStyle(Paint.Style.STROKE);
        this.glowPaint = paint3;
        this.rect = new RectF();
        this.drawables = new HashMap<>();
        this.lockDrawable = LazyKt.lazy(new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ContextCompat.getDrawable(context, R.drawable.ic_lock);
            }
        });
        this.downCol = -1;
        this.downRow = -1;
        this.cellBg = ContextCompat.getColor(context, R.color.cell_bg);
        this.cellStroke = ContextCompat.getColor(context, R.color.cell_stroke);
        this.selColor = ContextCompat.getColor(context, R.color.ice_blue_bright);
        this.goldColor = ContextCompat.getColor(context, R.color.gold_bright);
        for (GemType gemType : GemType.INSTANCE.getALL()) {
            this.drawables.put(gemType, ContextCompat.getDrawable(context, gemRes(gemType)));
        }
        allocAnims();
        this.phases = CollectionsKt.emptyList();
    }

    /* JADX INFO: compiled from: BoardView.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001c\b\u0002\u0018\u00002\u00020\u0001BA\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\n¢\u0006\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\b\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u0019\"\u0004\b\u001d\u0010\u001bR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\u000b\u001a\u00020\fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010#\"\u0004\b$\u0010%R\u001a\u0010\r\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\u001f\"\u0004\b'\u0010!¨\u0006("}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/BoardView$VisCell;", "", "type", "Lcom/alpine/blizzardboard/domain/model/GemType;", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "snow", "", "ice", "locked", "", "blocker", "Lcom/alpine/blizzardboard/domain/model/Blocker;", "open", "<init>", "(Lcom/alpine/blizzardboard/domain/model/GemType;Lcom/alpine/blizzardboard/domain/model/Special;IIZLcom/alpine/blizzardboard/domain/model/Blocker;Z)V", "getType", "()Lcom/alpine/blizzardboard/domain/model/GemType;", "setType", "(Lcom/alpine/blizzardboard/domain/model/GemType;)V", "getSpecial", "()Lcom/alpine/blizzardboard/domain/model/Special;", "setSpecial", "(Lcom/alpine/blizzardboard/domain/model/Special;)V", "getSnow", "()I", "setSnow", "(I)V", "getIce", "setIce", "getLocked", "()Z", "setLocked", "(Z)V", "getBlocker", "()Lcom/alpine/blizzardboard/domain/model/Blocker;", "setBlocker", "(Lcom/alpine/blizzardboard/domain/model/Blocker;)V", "getOpen", "setOpen", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class VisCell {
        private Blocker blocker;
        private int ice;
        private boolean locked;
        private boolean open;
        private int snow;
        private Special special;
        private GemType type;

        public VisCell(GemType gemType, Special special, int i, int i2, boolean z, Blocker blocker, boolean z2) {
            Intrinsics.checkNotNullParameter(special, "special");
            Intrinsics.checkNotNullParameter(blocker, "blocker");
            this.type = gemType;
            this.special = special;
            this.snow = i;
            this.ice = i2;
            this.locked = z;
            this.blocker = blocker;
            this.open = z2;
        }

        public final GemType getType() {
            return this.type;
        }

        public final void setType(GemType gemType) {
            this.type = gemType;
        }

        public final Special getSpecial() {
            return this.special;
        }

        public final void setSpecial(Special special) {
            Intrinsics.checkNotNullParameter(special, "<set-?>");
            this.special = special;
        }

        public final int getSnow() {
            return this.snow;
        }

        public final void setSnow(int i) {
            this.snow = i;
        }

        public final int getIce() {
            return this.ice;
        }

        public final void setIce(int i) {
            this.ice = i;
        }

        public final boolean getLocked() {
            return this.locked;
        }

        public final void setLocked(boolean z) {
            this.locked = z;
        }

        public final Blocker getBlocker() {
            return this.blocker;
        }

        public final void setBlocker(Blocker blocker) {
            Intrinsics.checkNotNullParameter(blocker, "<set-?>");
            this.blocker = blocker;
        }

        public final boolean getOpen() {
            return this.open;
        }

        public final void setOpen(boolean z) {
            this.open = z;
        }
    }

    public final Listener getListener() {
        return this.listener;
    }

    public final void setListener(Listener listener) {
        this.listener = listener;
    }

    public final Function0<VCell[][]> getSnapshotProvider() {
        return this.snapshotProvider;
    }

    public final void setSnapshotProvider(Function0<VCell[][]> function0) {
        this.snapshotProvider = function0;
    }

    public final boolean getRemoveMode() {
        return this.removeMode;
    }

    public final void setRemoveMode(boolean z) {
        this.removeMode = z;
    }

    private final Drawable getLockDrawable() {
        return (Drawable) this.lockDrawable.getValue();
    }

    private final int gemRes(GemType t) {
        switch (WhenMappings.$EnumSwitchMapping$0[t.ordinal()]) {
            case 1:
                return R.drawable.ic_gem_snowboard;
            case 2:
                return R.drawable.ic_gem_helmet;
            case 3:
                return R.drawable.ic_gem_goggles;
            case 4:
                return R.drawable.ic_gem_glove;
            case 5:
                return R.drawable.ic_gem_snowflake;
            case 6:
                return R.drawable.ic_gem_flag;
            case 7:
                return R.drawable.ic_gem_medal;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    private final VisCell[][] emptyGrid(int r, int c) {
        VisCell[][] visCellArr = new VisCell[r][];
        for (int i = 0; i < r; i++) {
            VisCell[] visCellArr2 = new VisCell[c];
            for (int i2 = 0; i2 < c; i2++) {
                visCellArr2[i2] = new VisCell(null, Special.NONE, 0, 0, false, Blocker.NONE, true);
            }
            visCellArr[i] = visCellArr2;
        }
        return visCellArr;
    }

    private final void allocAnims() {
        int i = this.rows;
        float[][] fArr = new float[i][];
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            float[] fArr2 = new float[i3];
            for (int i4 = 0; i4 < i3; i4++) {
                fArr2[i4] = 1.0f;
            }
            fArr[i2] = fArr2;
        }
        this.animScale = fArr;
        int i5 = this.rows;
        int[][] iArr = new int[i5][];
        for (int i6 = 0; i6 < i5; i6++) {
            int i7 = this.cols;
            int[] iArr2 = new int[i7];
            for (int i8 = 0; i8 < i7; i8++) {
                iArr2[i8] = 255;
            }
            iArr[i6] = iArr2;
        }
        this.animAlpha = iArr;
        int i9 = this.rows;
        float[][] fArr3 = new float[i9][];
        for (int i10 = 0; i10 < i9; i10++) {
            int i11 = this.cols;
            float[] fArr4 = new float[i11];
            for (int i12 = 0; i12 < i11; i12++) {
                fArr4[i12] = 0.0f;
            }
            fArr3[i10] = fArr4;
        }
        this.animOffX = fArr3;
        int i13 = this.rows;
        float[][] fArr5 = new float[i13][];
        for (int i14 = 0; i14 < i13; i14++) {
            int i15 = this.cols;
            float[] fArr6 = new float[i15];
            for (int i16 = 0; i16 < i15; i16++) {
                fArr6[i16] = 0.0f;
            }
            fArr5[i14] = fArr6;
        }
        this.animOffY = fArr5;
        int i17 = this.rows;
        float[][] fArr7 = new float[i17][];
        for (int i18 = 0; i18 < i17; i18++) {
            int i19 = this.cols;
            float[] fArr8 = new float[i19];
            for (int i20 = 0; i20 < i19; i20++) {
                fArr8[i20] = 0.0f;
            }
            fArr7[i18] = fArr8;
        }
        this.startOffY = fArr7;
    }

    private final void resetAnims() {
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                float[][] fArr = this.animScale;
                float[][] fArr2 = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animScale");
                    fArr = null;
                }
                fArr[i2][i4] = 1.0f;
                int[][] iArr = this.animAlpha;
                if (iArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animAlpha");
                    iArr = null;
                }
                iArr[i2][i4] = 255;
                float[][] fArr3 = this.animOffX;
                if (fArr3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animOffX");
                    fArr3 = null;
                }
                fArr3[i2][i4] = 0.0f;
                float[][] fArr4 = this.animOffY;
                if (fArr4 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animOffY");
                    fArr4 = null;
                }
                fArr4[i2][i4] = 0.0f;
                float[][] fArr5 = this.startOffY;
                if (fArr5 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                } else {
                    fArr2 = fArr5;
                }
                fArr2[i2][i4] = 0.0f;
            }
        }
    }

    public final void bind(VCell[][] snapshot) {
        Intrinsics.checkNotNullParameter(snapshot, "snapshot");
        int length = snapshot.length;
        this.rows = length;
        this.cols = length > 0 ? snapshot[0].length : 8;
        this.grid = visFrom(snapshot);
        allocAnims();
        requestLayout();
        invalidate();
    }

    private final VisCell[][] visFrom(VCell[][] s) {
        int length = s.length;
        VisCell[][] visCellArr = new VisCell[length][];
        for (int i = 0; i < length; i++) {
            int length2 = s[i].length;
            VisCell[] visCellArr2 = new VisCell[length2];
            for (int i2 = 0; i2 < length2; i2++) {
                VCell vCell = s[i][i2];
                visCellArr2[i2] = new VisCell(vCell.getType(), vCell.getSpecial(), vCell.getSnow(), vCell.getIce(), vCell.getLocked(), vCell.getBlocker(), vCell.getOpen());
            }
            visCellArr[i] = visCellArr2;
        }
        return visCellArr;
    }

    /* JADX INFO: renamed from: isBusy, reason: from getter */
    public final boolean getAnimating() {
        return this.animating;
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = View.MeasureSpec.getSize(widthMeasureSpec);
        int size2 = View.MeasureSpec.getSize(heightMeasureSpec);
        if (size2 > 0) {
            size = Math.min(size, size2);
        }
        setMeasuredDimension(size, size);
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float f = w / this.cols;
        this.cell = f;
        this.inset = 0.09f * f;
        this.radius = f * 0.22f;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        BoardView boardView;
        Canvas canvas2;
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            int i4 = 0;
            while (i4 < i3) {
                VisCell visCell = this.grid[i2][i4];
                if (visCell.getOpen()) {
                    float f = this.cell;
                    float f2 = i4 * f;
                    float f3 = i2 * f;
                    RectF rectF = this.rect;
                    float f4 = this.inset;
                    rectF.set(f2 + f4, f3 + f4, (f2 + f) - f4, (f + f3) - f4);
                    this.bgPaint.setColor(this.cellBg);
                    RectF rectF2 = this.rect;
                    float f5 = this.radius;
                    canvas.drawRoundRect(rectF2, f5, f5, this.bgPaint);
                    this.strokePaint.setColor(this.cellStroke);
                    this.strokePaint.setStrokeWidth(this.cell * 0.02f);
                    RectF rectF3 = this.rect;
                    float f6 = this.radius;
                    canvas.drawRoundRect(rectF3, f6, f6, this.strokePaint);
                    if (visCell.getSnow() > 0) {
                        this.drawSnow(canvas, f2, f3, visCell.getSnow());
                    }
                    if (visCell.getIce() > 0) {
                        this.drawIce(canvas, f2, f3, visCell.getIce());
                    }
                    if (visCell.getBlocker() != Blocker.NONE) {
                        this.drawBlocker(canvas, f2, f3, visCell.getBlocker());
                    } else {
                        GemType type = visCell.getType();
                        if (type != null) {
                            boardView = this;
                            canvas2 = canvas;
                            boardView.drawGem(canvas2, i2, i4, f2, f3, type, visCell.getSpecial());
                            if (visCell.getLocked()) {
                                boardView.drawLocked(canvas2, f2, f3);
                            }
                        }
                    }
                    boardView = this;
                    canvas2 = canvas;
                } else {
                    boardView = this;
                    canvas2 = canvas;
                }
                i4++;
                this = boardView;
                canvas = canvas2;
            }
        }
        BoardView boardView2 = this;
        Canvas canvas3 = canvas;
        boardView2.drawSelection(canvas3);
        boardView2.drawHint(canvas3);
    }

    private final RectF cellRect(float left, float top, float scale, float pad) {
        float f = this.cell;
        float f2 = left + (f / 2.0f);
        float f3 = top + (f / 2.0f);
        float f4 = ((f / 2.0f) - pad) * scale;
        this.rect.set(f2 - f4, f3 - f4, f2 + f4, f3 + f4);
        return this.rect;
    }

    private final void drawGem(Canvas canvas, int r, int c, float left, float top, GemType type, Special special) {
        Drawable drawable = this.drawables.get(type);
        if (drawable == null) {
            return;
        }
        float[][] fArr = this.animOffX;
        int[][] iArr = null;
        if (fArr == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animOffX");
            fArr = null;
        }
        float f = fArr[r][c];
        float[][] fArr2 = this.animOffY;
        if (fArr2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animOffY");
            fArr2 = null;
        }
        float f2 = fArr2[r][c];
        float[][] fArr3 = this.animScale;
        if (fArr3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animScale");
            fArr3 = null;
        }
        float f3 = fArr3[r][c];
        int[][] iArr2 = this.animAlpha;
        if (iArr2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animAlpha");
        } else {
            iArr = iArr2;
        }
        int i = iArr[r][c];
        RectF rectFCellRect = cellRect(left + f, top + f2, f3, this.inset);
        if (special != Special.NONE) {
            this.glowPaint.setColor(this.goldColor);
            this.glowPaint.setStrokeWidth(this.cell * 0.05f);
            float f4 = this.radius;
            canvas.drawRoundRect(rectFCellRect, f4, f4, this.glowPaint);
        }
        drawable.setBounds((int) rectFCellRect.left, (int) rectFCellRect.top, (int) rectFCellRect.right, (int) rectFCellRect.bottom);
        drawable.setAlpha(i);
        drawable.draw(canvas);
        if (special != Special.NONE) {
            drawSpecialMark(canvas, rectFCellRect, special, i);
        }
    }

    private final void drawSpecialMark(Canvas canvas, RectF gr, Special special, int alpha) {
        this.linePaint.setColor(argb(alpha, 234, 249, 255));
        this.linePaint.setStrokeWidth(gr.width() * 0.1f);
        float fCenterX = gr.centerX();
        float fCenterY = gr.centerY();
        int i = WhenMappings.$EnumSwitchMapping$1[special.ordinal()];
        if (i == 1) {
            canvas.drawLine(gr.left, fCenterY, gr.right, fCenterY, this.linePaint);
            return;
        }
        if (i == 2) {
            canvas.drawLine(fCenterX, gr.top, fCenterX, gr.bottom, this.linePaint);
            return;
        }
        if (i == 3) {
            this.linePaint.setStyle(Paint.Style.STROKE);
            canvas.drawCircle(fCenterX, fCenterY, gr.width() * 0.3f, this.linePaint);
            this.linePaint.setStyle(Paint.Style.STROKE);
        } else if (i != 4) {
            if (i != 5) {
                throw new NoWhenBranchMatchedException();
            }
        } else {
            this.glowPaint.setColor(argb(alpha, 255, 224, 122));
            this.glowPaint.setStrokeWidth(gr.width() * 0.08f);
            canvas.drawCircle(fCenterX, fCenterY, gr.width() * 0.42f, this.glowPaint);
        }
    }

    private final void drawSnow(Canvas canvas, float left, float top, int layers) {
        RectF rectFCellRect = cellRect(left, top, 1.0f, this.inset * 0.5f);
        this.coatPaint.setColor(argb(layers >= 2 ? 205 : 135, 246, 251, 255));
        float f = this.radius;
        canvas.drawRoundRect(rectFCellRect, f, f, this.coatPaint);
        this.coatPaint.setColor(argb(120, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION, 230, 255));
        canvas.drawCircle(rectFCellRect.left + (rectFCellRect.width() * 0.32f), rectFCellRect.top + (rectFCellRect.height() * 0.34f), this.cell * 0.07f, this.coatPaint);
        canvas.drawCircle(rectFCellRect.right - (rectFCellRect.width() * 0.3f), rectFCellRect.bottom - (rectFCellRect.height() * 0.3f), this.cell * 0.06f, this.coatPaint);
    }

    private final void drawIce(Canvas canvas, float left, float top, int layers) {
        RectF rectFCellRect = cellRect(left, top, 1.0f, this.inset * 0.5f);
        this.coatPaint.setColor(argb(layers >= 2 ? 190 : 120, WorkQueueKt.MASK, 208, 245));
        float f = this.radius;
        canvas.drawRoundRect(rectFCellRect, f, f, this.coatPaint);
        this.linePaint.setColor(argb(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION, 234, 249, 255));
        this.linePaint.setStrokeWidth(this.cell * 0.03f);
        canvas.drawLine(rectFCellRect.left + (rectFCellRect.width() * 0.25f), rectFCellRect.top + (rectFCellRect.height() * 0.2f), rectFCellRect.right - (rectFCellRect.width() * 0.2f), rectFCellRect.bottom - (rectFCellRect.height() * 0.25f), this.linePaint);
    }

    private final void drawBlocker(Canvas canvas, float left, float top, Blocker blocker) {
        int i;
        int i2;
        int i3;
        RectF rectFCellRect = cellRect(left, top, 1.0f, this.inset);
        Paint paint = this.bgPaint;
        if (blocker == Blocker.ROCK) {
            i = 124;
            i2 = 144;
            i3 = 107;
        } else {
            i = 166;
            i2 = 190;
            i3 = 143;
        }
        paint.setColor(argb(255, i3, i, i2));
        float f = this.radius;
        canvas.drawRoundRect(rectFCellRect, f, f, this.bgPaint);
        this.linePaint.setColor(argb(255, 63, 78, 96));
        this.linePaint.setStrokeWidth(this.cell * 0.03f);
        canvas.drawLine(rectFCellRect.left + (rectFCellRect.width() * 0.3f), rectFCellRect.top + (rectFCellRect.height() * 0.25f), rectFCellRect.centerX(), rectFCellRect.centerY(), this.linePaint);
        canvas.drawLine(rectFCellRect.centerX(), rectFCellRect.centerY(), rectFCellRect.right - (rectFCellRect.width() * 0.25f), rectFCellRect.top + (rectFCellRect.height() * 0.35f), this.linePaint);
        canvas.drawLine(rectFCellRect.centerX(), rectFCellRect.centerY(), rectFCellRect.centerX() - (rectFCellRect.width() * 0.08f), rectFCellRect.bottom - (rectFCellRect.height() * 0.25f), this.linePaint);
    }

    private final void drawLocked(Canvas canvas, float left, float top) {
        RectF rectFCellRect = cellRect(left, top, 1.0f, this.inset);
        this.coatPaint.setColor(argb(120, 8, 20, 40));
        float f = this.radius;
        canvas.drawRoundRect(rectFCellRect, f, f, this.coatPaint);
        Drawable lockDrawable = getLockDrawable();
        if (lockDrawable == null) {
            return;
        }
        int i = (int) (this.cell * 0.32f);
        int iCenterX = (int) rectFCellRect.centerX();
        int iCenterY = (int) rectFCellRect.centerY();
        int i2 = i / 2;
        lockDrawable.setBounds(iCenterX - i2, iCenterY - i2, iCenterX + i2, iCenterY + i2);
        lockDrawable.draw(canvas);
    }

    private final void drawSelection(Canvas canvas) {
        Pos pos = this.selected;
        if (pos == null) {
            return;
        }
        RectF rectFCellRect = cellRect(pos.getC() * this.cell, pos.getR() * this.cell, 1.0f, this.inset * 0.4f);
        this.glowPaint.setColor(this.selColor);
        this.glowPaint.setStrokeWidth(this.cell * 0.06f);
        float f = this.radius;
        canvas.drawRoundRect(rectFCellRect, f, f, this.glowPaint);
    }

    private final void drawHint(Canvas canvas) {
        Pos pos;
        Pos pos2 = this.hintA;
        if (pos2 == null || (pos = this.hintB) == null) {
            return;
        }
        float fSin = (((float) Math.sin(((double) this.hintPulse) * 3.141592653589793d)) * 0.12f) + 1.0f;
        for (Pos pos3 : CollectionsKt.listOf((Object[]) new Pos[]{pos2, pos})) {
            RectF rectFCellRect = cellRect(pos3.getC() * this.cell, pos3.getR() * this.cell, fSin, this.inset * 0.4f);
            this.glowPaint.setColor(argb(220, 255, 224, 122));
            this.glowPaint.setStrokeWidth(this.cell * 0.05f);
            float f = this.radius;
            canvas.drawRoundRect(rectFCellRect, f, f, this.glowPaint);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        Pos pos;
        Intrinsics.checkNotNullParameter(event, "event");
        if (this.animating) {
            return false;
        }
        int actionMasked = event.getActionMasked();
        if (actionMasked == 0) {
            this.downCol = (int) (event.getX() / this.cell);
            this.downRow = (int) (event.getY() / this.cell);
            this.downX = event.getX();
            this.downY = event.getY();
            this.swipeHandled = false;
            return inGrid(this.downRow, this.downCol);
        }
        if (actionMasked != 1) {
            if (actionMasked == 2 && !this.swipeHandled && inGrid(this.downRow, this.downCol)) {
                float x = event.getX() - this.downX;
                float y = event.getY() - this.downY;
                if (Math.abs(x) > this.cell * 0.35f || Math.abs(y) > this.cell * 0.35f) {
                    Pos pos2 = new Pos(this.downRow, this.downCol);
                    if (Math.abs(x) > Math.abs(y)) {
                        pos = new Pos(this.downRow, this.downCol + (x > 0.0f ? 1 : -1));
                    } else {
                        pos = new Pos(this.downRow + (y > 0.0f ? 1 : -1), this.downCol);
                    }
                    this.swipeHandled = true;
                    clearHint();
                    if (inGrid(pos.getR(), pos.getC())) {
                        this.selected = null;
                        Listener listener = this.listener;
                        if (listener != null) {
                            listener.onSwap(pos2, pos);
                        }
                    }
                }
            }
            return true;
        }
        if (this.swipeHandled || !inGrid(this.downRow, this.downCol)) {
            return true;
        }
        Pos pos3 = new Pos(this.downRow, this.downCol);
        clearHint();
        if (this.removeMode) {
            this.removeMode = false;
            Listener listener2 = this.listener;
            if (listener2 != null) {
                listener2.onRemoveTap(pos3);
            }
            return true;
        }
        Pos pos4 = this.selected;
        if (pos4 == null) {
            this.selected = pos3;
            invalidate();
        } else if (Intrinsics.areEqual(pos4, pos3)) {
            this.selected = null;
            invalidate();
        } else if (isAdjacent(pos4, pos3)) {
            this.selected = null;
            Listener listener3 = this.listener;
            if (listener3 != null) {
                listener3.onSwap(pos4, pos3);
            }
        } else {
            this.selected = pos3;
            invalidate();
        }
        return true;
    }

    private final boolean inGrid(int r, int c) {
        return r >= 0 && r < this.rows && c >= 0 && c < this.cols && this.grid[r][c].getOpen() && this.grid[r][c].getBlocker() == Blocker.NONE;
    }

    private final boolean isAdjacent(Pos a, Pos b) {
        return Math.abs(a.getR() - b.getR()) + Math.abs(a.getC() - b.getC()) == 1;
    }

    public final void showHint(Pos a, Pos b) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        this.hintA = a;
        this.hintB = b;
        ValueAnimator valueAnimator = this.hintAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.setDuration(900L);
        valueAnimatorOfFloat.setRepeatCount(-1);
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda7
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                BoardView.showHint$lambda$5$lambda$4(this.f$0, valueAnimator2);
            }
        });
        valueAnimatorOfFloat.start();
        this.hintAnimator = valueAnimatorOfFloat;
    }

    static final void showHint$lambda$5$lambda$4(BoardView boardView, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        Object animatedValue = it.getAnimatedValue();
        Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        boardView.hintPulse = ((Float) animatedValue).floatValue();
        boardView.invalidate();
    }

    public final void clearHint() {
        this.hintA = null;
        this.hintB = null;
        ValueAnimator valueAnimator = this.hintAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.hintAnimator = null;
        invalidate();
    }

    public final void play(List<? extends Phase> phases, Function1<? super Phase, Unit> onPhase, Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(phases, "phases");
        Intrinsics.checkNotNullParameter(onPhase, "onPhase");
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        if (phases.isEmpty()) {
            onComplete.invoke();
            return;
        }
        clearHint();
        this.selected = null;
        this.phases = phases;
        this.onPhase = onPhase;
        this.onComplete = onComplete;
        this.phaseIndex = 0;
        this.animating = true;
        playNext();
    }

    private final void playNext() {
        if (this.phaseIndex >= this.phases.size()) {
            this.animating = false;
            Function0<VCell[][]> function0 = this.snapshotProvider;
            if (function0 != null) {
                this.grid = visFrom(function0.invoke());
            }
            resetAnims();
            invalidate();
            Function0<Unit> function1 = this.onComplete;
            if (function1 != null) {
                function1.invoke();
                return;
            }
            return;
        }
        Phase phase = this.phases.get(this.phaseIndex);
        Function1<? super Phase, Unit> function2 = this.onPhase;
        if (function2 != null) {
            function2.invoke(phase);
        }
        if (phase instanceof SwapPhase) {
            animateSwap((SwapPhase) phase, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.playNext$lambda$7(this.f$0);
                }
            });
            return;
        }
        if (phase instanceof ClearPhase) {
            animateClear((ClearPhase) phase, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.playNext$lambda$8(this.f$0);
                }
            });
            return;
        }
        if (phase instanceof FallPhase) {
            animateFall((FallPhase) phase, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.playNext$lambda$9(this.f$0);
                }
            });
            return;
        }
        if (phase instanceof ShufflePhase) {
            animateShuffle(new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.playNext$lambda$10(this.f$0);
                }
            });
        } else if (phase instanceof StatePhase) {
            advance();
        } else {
            if (!(phase instanceof ResultPhase)) {
                throw new NoWhenBranchMatchedException();
            }
            advance();
        }
    }

    static final Unit playNext$lambda$7(BoardView boardView) {
        boardView.advance();
        return Unit.INSTANCE;
    }

    static final Unit playNext$lambda$8(BoardView boardView) {
        boardView.advance();
        return Unit.INSTANCE;
    }

    static final Unit playNext$lambda$9(BoardView boardView) {
        boardView.advance();
        return Unit.INSTANCE;
    }

    static final Unit playNext$lambda$10(BoardView boardView) {
        boardView.advance();
        return Unit.INSTANCE;
    }

    private final void advance() {
        this.phaseIndex++;
        playNext();
    }

    private final void runAnimator(long duration, final Function1<? super Float, Unit> update, final Function0<Unit> end) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.setDuration(duration);
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda15
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                BoardView.runAnimator$lambda$11(update, this, valueAnimator);
            }
        });
        valueAnimatorOfFloat.addListener(new AnimatorListenerAdapter() { // from class: com.alpine.blizzardboard.presentation.game.BoardView.runAnimator.2
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animation) {
                Intrinsics.checkNotNullParameter(animation, "animation");
                end.invoke();
            }
        });
        valueAnimatorOfFloat.start();
    }

    static final void runAnimator$lambda$11(Function1 function1, BoardView boardView, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        Object animatedValue = it.getAnimatedValue();
        Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        function1.invoke((Float) animatedValue);
        boardView.invalidate();
    }

    private final void animateSwap(SwapPhase phase, final Function0<Unit> done) {
        resetAnims();
        final Pos a = phase.getA();
        final Pos b = phase.getB();
        final float c = (b.getC() - a.getC()) * this.cell;
        final float r = (b.getR() - a.getR()) * this.cell;
        if (phase.getRevert()) {
            runAnimator(280L, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda16
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return BoardView.animateSwap$lambda$12(this.f$0, a, c, r, b, ((Float) obj).floatValue());
                }
            }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.animateSwap$lambda$13(this.f$0, done);
                }
            });
        } else {
            swapVis(a, b);
            runAnimator(170L, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return BoardView.animateSwap$lambda$14(this.f$0, a, c, r, b, ((Float) obj).floatValue());
                }
            }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return BoardView.animateSwap$lambda$15(this.f$0, done);
                }
            });
        }
    }

    static final Unit animateSwap$lambda$12(BoardView boardView, Pos pos, float f, float f2, Pos pos2, float f3) {
        float fSin = ((float) Math.sin(((double) f3) * 3.141592653589793d)) * 0.42f;
        boardView.setOff(pos, f * fSin, f2 * fSin);
        boardView.setOff(pos2, (-f) * fSin, (-f2) * fSin);
        return Unit.INSTANCE;
    }

    static final Unit animateSwap$lambda$13(BoardView boardView, Function0 function0) {
        boardView.resetAnims();
        boardView.invalidate();
        function0.invoke();
        return Unit.INSTANCE;
    }

    static final Unit animateSwap$lambda$14(BoardView boardView, Pos pos, float f, float f2, Pos pos2, float f3) {
        float f4 = 1.0f - f3;
        boardView.setOff(pos, f * f4, f2 * f4);
        boardView.setOff(pos2, (-f) * f4, (-f2) * f4);
        return Unit.INSTANCE;
    }

    static final Unit animateSwap$lambda$15(BoardView boardView, Function0 function0) {
        boardView.resetAnims();
        boardView.invalidate();
        function0.invoke();
        return Unit.INSTANCE;
    }

    private final void setOff(Pos p, float x, float y) {
        if (inRange(p)) {
            float[][] fArr = this.animOffX;
            float[][] fArr2 = null;
            if (fArr == null) {
                Intrinsics.throwUninitializedPropertyAccessException("animOffX");
                fArr = null;
            }
            fArr[p.getR()][p.getC()] = x;
            float[][] fArr3 = this.animOffY;
            if (fArr3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("animOffY");
            } else {
                fArr2 = fArr3;
            }
            fArr2[p.getR()][p.getC()] = y;
        }
    }

    private final boolean inRange(Pos p) {
        int i = this.rows;
        int r = p.getR();
        if (r < 0 || r >= i) {
            return false;
        }
        int i2 = this.cols;
        int c = p.getC();
        return c >= 0 && c < i2;
    }

    private final void swapVis(Pos a, Pos b) {
        VisCell visCell = this.grid[a.getR()][a.getC()];
        VisCell visCell2 = this.grid[b.getR()][b.getC()];
        GemType type = visCell.getType();
        visCell.setType(visCell2.getType());
        visCell2.setType(type);
        Special special = visCell.getSpecial();
        visCell.setSpecial(visCell2.getSpecial());
        visCell2.setSpecial(special);
    }

    private final void animateClear(final ClearPhase phase, final Function0<Unit> done) {
        resetAnims();
        runAnimator(180L, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BoardView.animateClear$lambda$16(phase, this, ((Float) obj).floatValue());
            }
        }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return BoardView.animateClear$lambda$17(this.f$0, phase, done);
            }
        });
    }

    static final Unit animateClear$lambda$16(ClearPhase clearPhase, BoardView boardView, float f) {
        float f2 = 1.0f - f;
        for (Pos pos : clearPhase.getCleared()) {
            if (boardView.inRange(pos)) {
                float[][] fArr = boardView.animScale;
                int[][] iArr = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animScale");
                    fArr = null;
                }
                fArr[pos.getR()][pos.getC()] = f2;
                int[][] iArr2 = boardView.animAlpha;
                if (iArr2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animAlpha");
                } else {
                    iArr = iArr2;
                }
                iArr[pos.getR()][pos.getC()] = (int) (255.0f * f2);
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit animateClear$lambda$17(BoardView boardView, ClearPhase clearPhase, Function0 function0) {
        boardView.applyClear(clearPhase);
        boardView.resetAnims();
        boardView.invalidate();
        function0.invoke();
        return Unit.INSTANCE;
    }

    private final void applyClear(ClearPhase phase) {
        for (Pos pos : phase.getCleared()) {
            if (inRange(pos)) {
                this.grid[pos.getR()][pos.getC()].setType(null);
                this.grid[pos.getR()][pos.getC()].setSpecial(Special.NONE);
            }
        }
        for (Map.Entry<Pos, Special> entry : phase.getCreated().entrySet()) {
            Pos key = entry.getKey();
            Special value = entry.getValue();
            if (inRange(key)) {
                this.grid[key.getR()][key.getC()].setSpecial(value);
            }
        }
        for (Pos pos2 : phase.getSnowHits()) {
            if (inRange(pos2)) {
                this.grid[pos2.getR()][pos2.getC()].setSnow(RangesKt.coerceAtLeast(this.grid[pos2.getR()][pos2.getC()].getSnow() - 1, 0));
            }
        }
        for (Pos pos3 : phase.getIceHits()) {
            if (inRange(pos3)) {
                this.grid[pos3.getR()][pos3.getC()].setIce(RangesKt.coerceAtLeast(this.grid[pos3.getR()][pos3.getC()].getIce() - 1, 0));
            }
        }
        for (Pos pos4 : phase.getBlockerCleared()) {
            if (inRange(pos4)) {
                this.grid[pos4.getR()][pos4.getC()].setBlocker(Blocker.NONE);
            }
        }
        for (Pos pos5 : phase.getUnlocked()) {
            if (inRange(pos5)) {
                this.grid[pos5.getR()][pos5.getC()].setLocked(false);
            }
        }
    }

    private final void animateFall(FallPhase phase, final Function0<Unit> done) {
        resetAnims();
        applyFall(phase);
        int i = this.rows;
        float fAbs = 1.0f;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                float[][] fArr = this.startOffY;
                float[][] fArr2 = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    fArr = null;
                }
                if (Math.abs(fArr[i2][i4]) > fAbs) {
                    float[][] fArr3 = this.startOffY;
                    if (fArr3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    } else {
                        fArr2 = fArr3;
                    }
                    fAbs = Math.abs(fArr2[i2][i4]);
                }
            }
        }
        runAnimator(RangesKt.coerceAtMost((long) (150.0f + ((fAbs / this.cell) * 40.0f)), 520L), new Function1() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BoardView.animateFall$lambda$18(this.f$0, ((Float) obj).floatValue());
            }
        }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return BoardView.animateFall$lambda$19(this.f$0, done);
            }
        });
    }

    static final Unit animateFall$lambda$18(BoardView boardView, float f) {
        float f2 = 1.0f - f;
        int i = boardView.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = boardView.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                float[][] fArr = boardView.startOffY;
                float[][] fArr2 = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    fArr = null;
                }
                if (fArr[i2][i4] != 0.0f) {
                    float[][] fArr3 = boardView.animOffY;
                    if (fArr3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("animOffY");
                        fArr3 = null;
                    }
                    float[] fArr4 = fArr3[i2];
                    float[][] fArr5 = boardView.startOffY;
                    if (fArr5 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    } else {
                        fArr2 = fArr5;
                    }
                    fArr4[i4] = fArr2[i2][i4] * f2;
                }
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit animateFall$lambda$19(BoardView boardView, Function0 function0) {
        boardView.resetAnims();
        boardView.invalidate();
        function0.invoke();
        return Unit.INSTANCE;
    }

    private final void applyFall(FallPhase phase) {
        int i = this.rows;
        GemType[][] gemTypeArr = new GemType[i][];
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            GemType[] gemTypeArr2 = new GemType[i3];
            for (int i4 = 0; i4 < i3; i4++) {
                gemTypeArr2[i4] = this.grid[i2][i4].getType();
            }
            gemTypeArr[i2] = gemTypeArr2;
        }
        int i5 = this.rows;
        Special[][] specialArr = new Special[i5][];
        for (int i6 = 0; i6 < i5; i6++) {
            int i7 = this.cols;
            Special[] specialArr2 = new Special[i7];
            for (int i8 = 0; i8 < i7; i8++) {
                specialArr2[i8] = this.grid[i6][i8].getSpecial();
            }
            specialArr[i6] = specialArr2;
        }
        for (GemMove gemMove : phase.getMoves()) {
            if (inRange(gemMove.getFrom())) {
                this.grid[gemMove.getFrom().getR()][gemMove.getFrom().getC()].setType(null);
                this.grid[gemMove.getFrom().getR()][gemMove.getFrom().getC()].setSpecial(Special.NONE);
            }
        }
        for (GemMove gemMove2 : phase.getMoves()) {
            if (inRange(gemMove2.getTo()) && inRange(gemMove2.getFrom())) {
                this.grid[gemMove2.getTo().getR()][gemMove2.getTo().getC()].setType(gemTypeArr[gemMove2.getFrom().getR()][gemMove2.getFrom().getC()]);
                this.grid[gemMove2.getTo().getR()][gemMove2.getTo().getC()].setSpecial(specialArr[gemMove2.getFrom().getR()][gemMove2.getFrom().getC()]);
                float[][] fArr = this.startOffY;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    fArr = null;
                }
                fArr[gemMove2.getTo().getR()][gemMove2.getTo().getC()] = (gemMove2.getFrom().getR() - gemMove2.getTo().getR()) * this.cell;
            }
        }
        for (GemSpawn gemSpawn : phase.getSpawns()) {
            if (inRange(gemSpawn.getTo())) {
                this.grid[gemSpawn.getTo().getR()][gemSpawn.getTo().getC()].setType(gemSpawn.getGem().getType());
                this.grid[gemSpawn.getTo().getR()][gemSpawn.getTo().getC()].setSpecial(gemSpawn.getGem().getSpecial());
                float[][] fArr2 = this.startOffY;
                if (fArr2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("startOffY");
                    fArr2 = null;
                }
                fArr2[gemSpawn.getTo().getR()][gemSpawn.getTo().getC()] = (-gemSpawn.getFromRowsAbove()) * this.cell;
            }
        }
    }

    private final void animateShuffle(final Function0<Unit> done) {
        Function0<VCell[][]> function0 = this.snapshotProvider;
        if (function0 != null) {
            this.grid = visFrom(function0.invoke());
        }
        resetAnims();
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                float[][] fArr = this.animScale;
                int[][] iArr = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animScale");
                    fArr = null;
                }
                fArr[i2][i4] = 0.5f;
                int[][] iArr2 = this.animAlpha;
                if (iArr2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animAlpha");
                } else {
                    iArr = iArr2;
                }
                iArr[i2][i4] = 60;
            }
        }
        runAnimator(260L, new Function1() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return BoardView.animateShuffle$lambda$21(this.f$0, ((Float) obj).floatValue());
            }
        }, new Function0() { // from class: com.alpine.blizzardboard.presentation.game.BoardView$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return BoardView.animateShuffle$lambda$22(this.f$0, done);
            }
        });
    }

    static final Unit animateShuffle$lambda$21(BoardView boardView, float f) {
        int i = boardView.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = boardView.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                float[][] fArr = boardView.animScale;
                int[][] iArr = null;
                if (fArr == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animScale");
                    fArr = null;
                }
                fArr[i2][i4] = (f * 0.5f) + 0.5f;
                int[][] iArr2 = boardView.animAlpha;
                if (iArr2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("animAlpha");
                } else {
                    iArr = iArr2;
                }
                iArr[i2][i4] = (int) (60.0f + (195.0f * f));
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit animateShuffle$lambda$22(BoardView boardView, Function0 function0) {
        boardView.resetAnims();
        boardView.invalidate();
        function0.invoke();
        return Unit.INSTANCE;
    }
}
