package com.alpine.blizzardboard.presentation.game;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultCaller;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.KeyEventDispatcher;
import androidx.fragment.app.DialogFragment;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.DialogLevelFailedBinding;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: LevelFailedDialog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \u001a2\u00020\u0001:\u0002\u0019\u001aB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u0012\u0010\u0011\u001a\u00020\u00122\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\n\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0002J\b\u0010\u0018\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u001b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/DialogLevelFailedBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/DialogLevelFailedBinding;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "onViewCreated", "", "view", "host", "Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog$Host;", "onDestroyView", "Host", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class LevelFailedDialog extends DialogFragment {
    private static final String ARG_SCORE = "score";

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private DialogLevelFailedBinding _binding;

    /* JADX INFO: compiled from: LevelFailedDialog.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\b\u0010\u0004\u001a\u00020\u0003H&¨\u0006\u0005À\u0006\u0003"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog$Host;", "", "onRetry", "", "onHome", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public interface Host {
        void onHome();

        void onRetry();
    }

    private final DialogLevelFailedBinding getBinding() {
        DialogLevelFailedBinding dialogLevelFailedBinding = this._binding;
        Intrinsics.checkNotNull(dialogLevelFailedBinding);
        return dialogLevelFailedBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = DialogLevelFailedBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialogOnCreateDialog = super.onCreateDialog(savedInstanceState);
        Intrinsics.checkNotNullExpressionValue(dialogOnCreateDialog, "onCreateDialog(...)");
        Window window = dialogOnCreateDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        setCancelable(false);
        return dialogOnCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        Bundle arguments = getArguments();
        getBinding().failedScore.setText(getString(R.string.dialog_score, Integer.valueOf(arguments != null ? arguments.getInt(ARG_SCORE) : 0)));
        TextView retryButton = getBinding().retryButton;
        Intrinsics.checkNotNullExpressionValue(retryButton, "retryButton");
        retryButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.LevelFailedDialog$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                LevelFailedDialog.Host host = this.this$0.host();
                if (host != null) {
                    host.onRetry();
                }
            }
        });
        TextView homeButton = getBinding().homeButton;
        Intrinsics.checkNotNullExpressionValue(homeButton, "homeButton");
        homeButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.game.LevelFailedDialog$onViewCreated$$inlined$onClick$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                LevelFailedDialog.Host host = this.this$0.host();
                if (host != null) {
                    host.onHome();
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Host host() {
        ActivityResultCaller parentFragment = getParentFragment();
        Host host = parentFragment instanceof Host ? (Host) parentFragment : null;
        if (host != null) {
            return host;
        }
        KeyEventDispatcher.Component activity = getActivity();
        if (activity instanceof Host) {
            return (Host) activity;
        }
        return null;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }

    /* JADX INFO: compiled from: LevelFailedDialog.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog$Companion;", "", "<init>", "()V", "ARG_SCORE", "", "newInstance", "Lcom/alpine/blizzardboard/presentation/game/LevelFailedDialog;", LevelFailedDialog.ARG_SCORE, "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final LevelFailedDialog newInstance(int score) {
            LevelFailedDialog levelFailedDialog = new LevelFailedDialog();
            Bundle bundle = new Bundle();
            bundle.putInt(LevelFailedDialog.ARG_SCORE, score);
            levelFailedDialog.setArguments(bundle);
            return levelFailedDialog;
        }
    }
}
