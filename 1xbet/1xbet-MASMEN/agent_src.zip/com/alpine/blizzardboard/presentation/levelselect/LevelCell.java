package com.alpine.blizzardboard.presentation.levelselect;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;

/* JADX INFO: compiled from: LevelAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0013\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00052\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001a"}, d2 = {"Lcom/alpine/blizzardboard/presentation/levelselect/LevelCell;", "", "id", "", "unlocked", "", "done", "stars", "<init>", "(IZZI)V", "getId", "()I", "getUnlocked", "()Z", "getDone", "getStars", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class LevelCell {
    private final boolean done;
    private final int id;
    private final int stars;
    private final boolean unlocked;

    public static /* synthetic */ LevelCell copy$default(LevelCell levelCell, int i, boolean z, boolean z2, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = levelCell.id;
        }
        if ((i3 & 2) != 0) {
            z = levelCell.unlocked;
        }
        if ((i3 & 4) != 0) {
            z2 = levelCell.done;
        }
        if ((i3 & 8) != 0) {
            i2 = levelCell.stars;
        }
        return levelCell.copy(i, z, z2, i2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final boolean getUnlocked() {
        return this.unlocked;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getDone() {
        return this.done;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getStars() {
        return this.stars;
    }

    public final LevelCell copy(int id, boolean unlocked, boolean done, int stars) {
        return new LevelCell(id, unlocked, done, stars);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LevelCell)) {
            return false;
        }
        LevelCell levelCell = (LevelCell) other;
        return this.id == levelCell.id && this.unlocked == levelCell.unlocked && this.done == levelCell.done && this.stars == levelCell.stars;
    }

    public int hashCode() {
        return (((((Integer.hashCode(this.id) * 31) + Boolean.hashCode(this.unlocked)) * 31) + Boolean.hashCode(this.done)) * 31) + Integer.hashCode(this.stars);
    }

    public String toString() {
        return "LevelCell(id=" + this.id + ", unlocked=" + this.unlocked + ", done=" + this.done + ", stars=" + this.stars + ")";
    }

    public LevelCell(int i, boolean z, boolean z2, int i2) {
        this.id = i;
        this.unlocked = z;
        this.done = z2;
        this.stars = i2;
    }

    public final int getId() {
        return this.id;
    }

    public final boolean getUnlocked() {
        return this.unlocked;
    }

    public final boolean getDone() {
        return this.done;
    }

    public final int getStars() {
        return this.stars;
    }
}
