package com.alpine.blizzardboard.presentation.levelselect;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.databinding.ItemRouteLevelBinding;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: LevelAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u0000 \u00122\u0012\u0012\u0004\u0012\u00020\u0002\u0012\b\u0012\u00060\u0003R\u00020\u00000\u0001:\u0002\u0011\u0012B\u001b\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u001c\u0010\t\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u001c\u0010\u000e\u001a\u00020\u00062\n\u0010\u000f\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u0010\u001a\u00020\rH\u0016R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/alpine/blizzardboard/presentation/levelselect/LevelAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/alpine/blizzardboard/presentation/levelselect/LevelCell;", "Lcom/alpine/blizzardboard/presentation/levelselect/LevelAdapter$VH;", "onClick", "Lkotlin/Function1;", "", "<init>", "(Lkotlin/jvm/functions/Function1;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class LevelAdapter extends ListAdapter<LevelCell, VH> {
    private static final LevelAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<LevelCell>() { // from class: com.alpine.blizzardboard.presentation.levelselect.LevelAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(LevelCell a, LevelCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return a.getId() == b.getId();
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(LevelCell a, LevelCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a, b);
        }
    };
    private final Function1<LevelCell, Unit> onClick;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public LevelAdapter(Function1<? super LevelCell, Unit> onClick) {
        super(DIFF);
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        this.onClick = onClick;
    }

    /* JADX INFO: compiled from: LevelAdapter.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001c\u0010\b\u001a\r\u0012\t\u0012\u00070\n¢\u0006\u0002\b\u000b0\t¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Lcom/alpine/blizzardboard/presentation/levelselect/LevelAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/alpine/blizzardboard/databinding/ItemRouteLevelBinding;", "<init>", "(Lcom/alpine/blizzardboard/presentation/levelselect/LevelAdapter;Lcom/alpine/blizzardboard/databinding/ItemRouteLevelBinding;)V", "getBinding", "()Lcom/alpine/blizzardboard/databinding/ItemRouteLevelBinding;", "stars", "", "Landroid/widget/ImageView;", "Lkotlin/jvm/internal/EnhancedNullability;", "getStars", "()Ljava/util/List;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public final class VH extends RecyclerView.ViewHolder {
        private final ItemRouteLevelBinding binding;
        private final List<ImageView> stars;
        final /* synthetic */ LevelAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(LevelAdapter levelAdapter, ItemRouteLevelBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = levelAdapter;
            this.binding = binding;
            this.stars = CollectionsKt.listOf((Object[]) new ImageView[]{binding.star1, binding.star2, binding.star3});
        }

        public final ItemRouteLevelBinding getBinding() {
            return this.binding;
        }

        public final List<ImageView> getStars() {
            return this.stars;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemRouteLevelBinding itemRouteLevelBindingInflate = ItemRouteLevelBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemRouteLevelBindingInflate, "inflate(...)");
        return new VH(this, itemRouteLevelBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        int i;
        Intrinsics.checkNotNullParameter(holder, "holder");
        final LevelCell item = getItem(position);
        Context context = holder.getBinding().getRoot().getContext();
        holder.getBinding().levelNumber.setText(String.valueOf(item.getId()));
        if (item.getUnlocked()) {
            i = item.getDone() ? R.drawable.bg_level_done : R.drawable.bg_level_open;
        } else {
            i = R.drawable.bg_level_locked;
        }
        holder.getBinding().levelRoot.setBackgroundResource(i);
        holder.getBinding().levelNumber.setTextColor(ContextCompat.getColor(context, item.getUnlocked() ? R.color.midnight : R.color.text_secondary));
        int i2 = 0;
        holder.getBinding().levelLock.setVisibility(item.getUnlocked() ? 8 : 0);
        holder.getBinding().levelNumber.setVisibility(item.getUnlocked() ? 0 : 4);
        if (item.getDone()) {
            holder.getBinding().starRow.setVisibility(0);
            int size = holder.getStars().size();
            while (i2 < size) {
                holder.getStars().get(i2).setImageResource(i2 < item.getStars() ? R.drawable.ic_star : R.drawable.ic_star_off);
                i2++;
            }
        } else {
            holder.getBinding().starRow.setVisibility(8);
        }
        holder.getBinding().levelRoot.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.levelselect.LevelAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LevelAdapter.onBindViewHolder$lambda$0(this.f$0, item, view);
            }
        });
    }

    static final void onBindViewHolder$lambda$0(LevelAdapter levelAdapter, LevelCell levelCell, View view) {
        Function1<LevelCell, Unit> function1 = levelAdapter.onClick;
        Intrinsics.checkNotNull(levelCell);
        function1.invoke(levelCell);
    }
}
