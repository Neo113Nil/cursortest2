package com.alpine.blizzardboard.presentation.levelselect;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentLevelSelectBinding;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: LevelSelectFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\b\u0010\u0016\u001a\u00020\u0014H\u0016J\u000e\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018H\u0002J\u0010\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\u0019H\u0002J\b\u0010\u001c\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001d"}, d2 = {"Lcom/alpine/blizzardboard/presentation/levelselect/LevelSelectFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentLevelSelectBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentLevelSelectBinding;", "adapter", "Lcom/alpine/blizzardboard/presentation/levelselect/LevelAdapter;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "onResume", "buildCells", "", "Lcom/alpine/blizzardboard/presentation/levelselect/LevelCell;", "onLevelClicked", "cell", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class LevelSelectFragment extends Fragment {
    private FragmentLevelSelectBinding _binding;
    private LevelAdapter adapter;

    private final FragmentLevelSelectBinding getBinding() {
        FragmentLevelSelectBinding fragmentLevelSelectBinding = this._binding;
        Intrinsics.checkNotNull(fragmentLevelSelectBinding);
        return fragmentLevelSelectBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentLevelSelectBinding.inflate(inflater, container, false);
        FrameLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.adapter = new LevelAdapter(new Function1() { // from class: com.alpine.blizzardboard.presentation.levelselect.LevelSelectFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return LevelSelectFragment.onViewCreated$lambda$0(this.f$0, (LevelCell) obj);
            }
        });
        getBinding().levelGrid.setLayoutManager(new GridLayoutManager(requireContext(), 5));
        RecyclerView recyclerView = getBinding().levelGrid;
        LevelAdapter levelAdapter = this.adapter;
        if (levelAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            levelAdapter = null;
        }
        recyclerView.setAdapter(levelAdapter);
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.levelselect.LevelSelectFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
    }

    static final Unit onViewCreated$lambda$0(LevelSelectFragment levelSelectFragment, LevelCell cell) {
        Intrinsics.checkNotNullParameter(cell, "cell");
        levelSelectFragment.onLevelClicked(cell);
        return Unit.INSTANCE;
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        getBinding().routeTint.setBackgroundColor((int) Catalog.INSTANCE.getRoutes().get(RangesKt.coerceIn(Progress.INSTANCE.getCurrentRouteId(), 0, Catalog.INSTANCE.getRoutes().size() - 1)).getTint());
        LevelAdapter levelAdapter = this.adapter;
        if (levelAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            levelAdapter = null;
        }
        levelAdapter.submitList(buildCells());
    }

    private final List<LevelCell> buildCells() {
        IntRange intRange = new IntRange(1, Progress.INSTANCE.getLevelCount());
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange, 10));
        Iterator<Integer> it = intRange.iterator();
        while (it.hasNext()) {
            int iNextInt = ((IntIterator) it).nextInt();
            arrayList.add(new LevelCell(iNextInt, Progress.INSTANCE.isUnlocked(iNextInt), Progress.INSTANCE.starsFor(iNextInt) > 0, Progress.INSTANCE.starsFor(iNextInt)));
        }
        return arrayList;
    }

    private final void onLevelClicked(LevelCell cell) {
        if (!cell.getUnlocked()) {
            Toast.makeText(requireContext(), getString(R.string.level_locked, Integer.valueOf(cell.getId())), 0).show();
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putInt("levelId", cell.getId());
        bundle.putBoolean("daily", false);
        FragmentKt.findNavController(this).navigate(R.id.action_levelSelect_to_game, bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
