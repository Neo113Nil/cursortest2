package com.alpine.blizzardboard.presentation.statistics;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentStatisticsBinding;
import com.alpine.blizzardboard.databinding.ViewStatRowBinding;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: StatisticsFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u001a\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J \u0010\u0014\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aH\u0002J\b\u0010\u001b\u001a\u00020\u0012H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u001c"}, d2 = {"Lcom/alpine/blizzardboard/presentation/statistics/StatisticsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentStatisticsBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentStatisticsBinding;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "row", "rowBinding", "Lcom/alpine/blizzardboard/databinding/ViewStatRowBinding;", "labelRes", "", "value", "", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class StatisticsFragment extends Fragment {
    private FragmentStatisticsBinding _binding;

    private final FragmentStatisticsBinding getBinding() {
        FragmentStatisticsBinding fragmentStatisticsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentStatisticsBinding);
        return fragmentStatisticsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentStatisticsBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.statistics.StatisticsFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        ViewStatRowBinding rowScore = getBinding().rowScore;
        Intrinsics.checkNotNullExpressionValue(rowScore, "rowScore");
        row(rowScore, R.string.stat_total_score, Progress.INSTANCE.totalScore());
        ViewStatRowBinding rowLevels = getBinding().rowLevels;
        Intrinsics.checkNotNullExpressionValue(rowLevels, "rowLevels");
        row(rowLevels, R.string.stat_levels_completed, Progress.INSTANCE.levelsCompleted());
        ViewStatRowBinding rowMatches = getBinding().rowMatches;
        Intrinsics.checkNotNullExpressionValue(rowMatches, "rowMatches");
        row(rowMatches, R.string.stat_matches_played, Progress.INSTANCE.matchesPlayed());
        ViewStatRowBinding rowCombo = getBinding().rowCombo;
        Intrinsics.checkNotNullExpressionValue(rowCombo, "rowCombo");
        row(rowCombo, R.string.stat_best_combo, Progress.INSTANCE.bestCombo());
        ViewStatRowBinding rowBoosters = getBinding().rowBoosters;
        Intrinsics.checkNotNullExpressionValue(rowBoosters, "rowBoosters");
        row(rowBoosters, R.string.stat_boosters_used, Progress.INSTANCE.boostersUsed());
        ViewStatRowBinding rowStreak = getBinding().rowStreak;
        Intrinsics.checkNotNullExpressionValue(rowStreak, "rowStreak");
        row(rowStreak, R.string.stat_streak, Progress.INSTANCE.bestStreak());
    }

    private final void row(ViewStatRowBinding rowBinding, int labelRes, long value) {
        rowBinding.statLabel.setText(labelRes);
        rowBinding.statValue.setText(String.valueOf(value));
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
