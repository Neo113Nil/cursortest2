package com.alpine.blizzardboard.presentation.common;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Goal;
import com.alpine.blizzardboard.domain.model.GoalType;
import com.alpine.blizzardboard.domain.model.Special;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Ui.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nJ\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0011¨\u0006\u0012"}, d2 = {"Lcom/alpine/blizzardboard/presentation/common/GemUi;", "", "<init>", "()V", "gemDrawable", "", "type", "Lcom/alpine/blizzardboard/domain/model/GemType;", "goalIcon", "goal", "Lcom/alpine/blizzardboard/domain/model/Goal;", "goalLabel", "", "context", "Landroid/content/Context;", "specialLabel", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class GemUi {
    public static final GemUi INSTANCE = new GemUi();

    /* JADX INFO: compiled from: Ui.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;
        public static final /* synthetic */ int[] $EnumSwitchMapping$2;

        static {
            int[] iArr = new int[GemType.values().length];
            try {
                iArr[GemType.SNOWBOARD.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[GemType.HELMET.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[GemType.GOGGLES.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[GemType.GLOVE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[GemType.SNOWFLAKE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[GemType.FLAG.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[GemType.MEDAL.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[GoalType.values().length];
            try {
                iArr2[GoalType.COLLECT.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr2[GoalType.CLEAR_SNOW.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr2[GoalType.BREAK_ICE.ordinal()] = 3;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr2[GoalType.BREAK_ROCK.ordinal()] = 4;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr2[GoalType.DELIVER_FLAG.ordinal()] = 5;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr2[GoalType.REACH_SCORE.ordinal()] = 6;
            } catch (NoSuchFieldError unused13) {
            }
            $EnumSwitchMapping$1 = iArr2;
            int[] iArr3 = new int[Special.values().length];
            try {
                iArr3[Special.LINE_H.ordinal()] = 1;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                iArr3[Special.LINE_V.ordinal()] = 2;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                iArr3[Special.BOMB.ordinal()] = 3;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                iArr3[Special.POWER.ordinal()] = 4;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                iArr3[Special.NONE.ordinal()] = 5;
            } catch (NoSuchFieldError unused18) {
            }
            $EnumSwitchMapping$2 = iArr3;
        }
    }

    private GemUi() {
    }

    public final int gemDrawable(GemType type) {
        Intrinsics.checkNotNullParameter(type, "type");
        switch (WhenMappings.$EnumSwitchMapping$0[type.ordinal()]) {
            case 1:
                return R.drawable.ic_gem_snowboard;
            case 2:
                return R.drawable.ic_gem_helmet;
            case 3:
                return R.drawable.ic_gem_goggles;
            case 4:
                return R.drawable.ic_gem_glove;
            case 5:
                return R.drawable.ic_gem_snowflake;
            case 6:
                return R.drawable.ic_gem_flag;
            case 7:
                return R.drawable.ic_gem_medal;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    public final int goalIcon(Goal goal) {
        Intrinsics.checkNotNullParameter(goal, "goal");
        switch (WhenMappings.$EnumSwitchMapping$1[goal.getType().ordinal()]) {
            case 1:
                GemType gem = goal.getGem();
                return gem != null ? INSTANCE.gemDrawable(gem) : R.drawable.ic_goal_score;
            case 2:
                return R.drawable.ic_goal_snow;
            case 3:
                return R.drawable.ic_goal_ice;
            case 4:
                return R.drawable.ic_goal_rock;
            case 5:
                return R.drawable.ic_gem_flag;
            case 6:
                return R.drawable.ic_goal_score;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    public final String goalLabel(Context context, Goal goal) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(goal, "goal");
        switch (WhenMappings.$EnumSwitchMapping$1[goal.getType().ordinal()]) {
            case 1:
                if (goal.getGem() == GemType.SNOWFLAKE) {
                    String string = context.getString(R.string.goal_snowflakes);
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    return string;
                }
                String string2 = context.getString(R.string.goal_collect);
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                return string2;
            case 2:
                String string3 = context.getString(R.string.goal_snow);
                Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                return string3;
            case 3:
                String string4 = context.getString(R.string.goal_ice);
                Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
                return string4;
            case 4:
                String string5 = context.getString(R.string.goal_rock);
                Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
                return string5;
            case 5:
                String string6 = context.getString(R.string.goal_flag);
                Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
                return string6;
            case 6:
                String string7 = context.getString(R.string.goal_score);
                Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
                return string7;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    public final String specialLabel(Special special) {
        Intrinsics.checkNotNullParameter(special, "special");
        int i = WhenMappings.$EnumSwitchMapping$2[special.ordinal()];
        if (i == 1 || i == 2) {
            return "Line";
        }
        if (i == 3) {
            return "Burst";
        }
        if (i == 4) {
            return "Power Snowflake";
        }
        if (i != 5) {
            throw new NoWhenBranchMatchedException();
        }
        return "";
    }
}
