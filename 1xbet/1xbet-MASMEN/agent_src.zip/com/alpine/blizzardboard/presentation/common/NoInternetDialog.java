package com.alpine.blizzardboard.presentation.common;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.DialogFragment;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Connectivity;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.DialogNoInternetBinding;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: NoInternetDialog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u0012\u0010\u0011\u001a\u00020\u00122\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\b\u0010\u0016\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u0017"}, d2 = {"Lcom/alpine/blizzardboard/presentation/common/NoInternetDialog;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/DialogNoInternetBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/DialogNoInternetBinding;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "onViewCreated", "", "view", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class NoInternetDialog extends DialogFragment {
    private DialogNoInternetBinding _binding;

    private final DialogNoInternetBinding getBinding() {
        DialogNoInternetBinding dialogNoInternetBinding = this._binding;
        Intrinsics.checkNotNull(dialogNoInternetBinding);
        return dialogNoInternetBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = DialogNoInternetBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialogOnCreateDialog = super.onCreateDialog(savedInstanceState);
        Intrinsics.checkNotNullExpressionValue(dialogOnCreateDialog, "onCreateDialog(...)");
        Window window = dialogOnCreateDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        return dialogOnCreateDialog;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        TextView offlineButton = getBinding().offlineButton;
        Intrinsics.checkNotNullExpressionValue(offlineButton, "offlineButton");
        offlineButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.common.NoInternetDialog$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                this.this$0.dismiss();
            }
        });
        TextView retryButton = getBinding().retryButton;
        Intrinsics.checkNotNullExpressionValue(retryButton, "retryButton");
        retryButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.common.NoInternetDialog$onViewCreated$$inlined$onClick$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                Connectivity connectivity = Connectivity.INSTANCE;
                Context contextRequireContext = this.this$0.requireContext();
                Intrinsics.checkNotNullExpressionValue(contextRequireContext, "requireContext(...)");
                boolean zIsOnline = connectivity.isOnline(contextRequireContext);
                NoInternetDialog noInternetDialog = this.this$0;
                if (zIsOnline) {
                    noInternetDialog.dismiss();
                } else {
                    Toast.makeText(noInternetDialog.requireContext(), R.string.no_internet_title, 0).show();
                }
            }
        });
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
