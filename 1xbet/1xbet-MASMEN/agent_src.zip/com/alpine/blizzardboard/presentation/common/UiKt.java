package com.alpine.blizzardboard.presentation.common;

import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.core.SoundManager;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Ui.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a&\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0014\b\u0004\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00010\u0004H\u0086\bø\u0001\u0000\u001a&\u0010\u0005\u001a\u00020\u0001*\u00020\u00022\u0014\b\u0004\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00010\u0004H\u0086\bø\u0001\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u0006"}, d2 = {"onClick", "", "Landroid/view/View;", "action", "Lkotlin/Function1;", "onClickBack", "app"}, k = 2, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class UiKt {
    public static final void onClick(View view, final Function1<? super View, Unit> action) {
        Intrinsics.checkNotNullParameter(view, "<this>");
        Intrinsics.checkNotNullParameter(action, "action");
        view.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.common.UiKt.onClick.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Function1<View, Unit> function1 = action;
                Intrinsics.checkNotNull(view2);
                function1.invoke(view2);
            }
        });
    }

    public static final void onClickBack(View view, final Function1<? super View, Unit> action) {
        Intrinsics.checkNotNullParameter(view, "<this>");
        Intrinsics.checkNotNullParameter(action, "action");
        view.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.common.UiKt.onClickBack.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Function1<View, Unit> function1 = action;
                Intrinsics.checkNotNull(view2);
                function1.invoke(view2);
            }
        });
    }
}
