package com.alpine.blizzardboard.presentation.settings;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.data.prefs.AppPreferences;
import com.alpine.blizzardboard.databinding.FragmentSettingsBinding;
import com.alpine.blizzardboard.di.Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: SettingsFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\u001a\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\n2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0016J\b\u0010\u0014\u001a\u00020\u0012H\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\b\u0010\u0017\u001a\u00020\u0012H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u0018"}, d2 = {"Lcom/alpine/blizzardboard/presentation/settings/SettingsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentSettingsBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentSettingsBinding;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "confirmReset", "versionName", "", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class SettingsFragment extends Fragment {
    private FragmentSettingsBinding _binding;

    private final FragmentSettingsBinding getBinding() {
        FragmentSettingsBinding fragmentSettingsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentSettingsBinding);
        return fragmentSettingsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentSettingsBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        final AppPreferences prefs = Container.INSTANCE.getPrefs();
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        getBinding().soundSwitch.setChecked(prefs.getSoundEnabled());
        getBinding().vibrationSwitch.setChecked(prefs.getVibrationEnabled());
        getBinding().snowfallSwitch.setChecked(prefs.getSnowfallEnabled());
        getBinding().soundSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$$ExternalSyntheticLambda1
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingsFragment.onViewCreated$lambda$1(prefs, compoundButton, z);
            }
        });
        getBinding().vibrationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$$ExternalSyntheticLambda2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingsFragment.onViewCreated$lambda$2(prefs, compoundButton, z);
            }
        });
        getBinding().snowfallSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$$ExternalSyntheticLambda3
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingsFragment.onViewCreated$lambda$3(prefs, compoundButton, z);
            }
        });
        TextView resetButton = getBinding().resetButton;
        Intrinsics.checkNotNullExpressionValue(resetButton, "resetButton");
        resetButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                this.this$0.confirmReset();
            }
        });
        getBinding().versionText.setText(getString(R.string.settings_version, versionName()));
    }

    static final void onViewCreated$lambda$1(AppPreferences appPreferences, CompoundButton compoundButton, boolean z) {
        Intrinsics.checkNotNullParameter(compoundButton, "<unused var>");
        appPreferences.setSoundEnabled(z);
    }

    static final void onViewCreated$lambda$2(AppPreferences appPreferences, CompoundButton compoundButton, boolean z) {
        Intrinsics.checkNotNullParameter(compoundButton, "<unused var>");
        appPreferences.setVibrationEnabled(z);
    }

    static final void onViewCreated$lambda$3(AppPreferences appPreferences, CompoundButton compoundButton, boolean z) {
        Intrinsics.checkNotNullParameter(compoundButton, "<unused var>");
        appPreferences.setSnowfallEnabled(z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void confirmReset() {
        new AlertDialog.Builder(requireContext()).setMessage(R.string.settings_reset_confirm).setNegativeButton(R.string.btn_cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.btn_reset, new DialogInterface.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.settings.SettingsFragment$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                SettingsFragment.confirmReset$lambda$5(this.f$0, dialogInterface, i);
            }
        }).show();
    }

    static final void confirmReset$lambda$5(SettingsFragment settingsFragment, DialogInterface dialogInterface, int i) {
        Progress.INSTANCE.resetAll();
        settingsFragment.getBinding().soundSwitch.setChecked(Container.INSTANCE.getPrefs().getSoundEnabled());
        settingsFragment.getBinding().vibrationSwitch.setChecked(Container.INSTANCE.getPrefs().getVibrationEnabled());
        settingsFragment.getBinding().snowfallSwitch.setChecked(Container.INSTANCE.getPrefs().getSnowfallEnabled());
        Toast.makeText(settingsFragment.requireContext(), R.string.settings_reset_done, 0).show();
    }

    private final String versionName() {
        try {
            String str = requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(), 0).versionName;
            return str == null ? "1.0" : str;
        } catch (Exception unused) {
            return "1.0";
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
