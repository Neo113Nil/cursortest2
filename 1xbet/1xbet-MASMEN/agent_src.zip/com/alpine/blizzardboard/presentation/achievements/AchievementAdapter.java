package com.alpine.blizzardboard.presentation.achievements;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.databinding.ItemAchievementBinding;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AchievementAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u0000 \u00102\u0012\u0012\u0004\u0012\u00020\u0002\u0012\b\u0012\u00060\u0003R\u00020\u00000\u0001:\u0002\u000f\u0010B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\u001c\u0010\u0006\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J\u001c\u0010\u000b\u001a\u00020\f2\n\u0010\r\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u000e\u001a\u00020\nH\u0016¨\u0006\u0011"}, d2 = {"Lcom/alpine/blizzardboard/presentation/achievements/AchievementAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/alpine/blizzardboard/presentation/achievements/AchievementCell;", "Lcom/alpine/blizzardboard/presentation/achievements/AchievementAdapter$VH;", "<init>", "()V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "", "holder", "position", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class AchievementAdapter extends ListAdapter<AchievementCell, VH> {
    private static final AchievementAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<AchievementCell>() { // from class: com.alpine.blizzardboard.presentation.achievements.AchievementAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(AchievementCell a, AchievementCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a.getId(), b.getId());
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(AchievementCell a, AchievementCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a, b);
        }
    };

    public AchievementAdapter() {
        super(DIFF);
    }

    /* JADX INFO: compiled from: AchievementAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/achievements/AchievementAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/alpine/blizzardboard/databinding/ItemAchievementBinding;", "<init>", "(Lcom/alpine/blizzardboard/presentation/achievements/AchievementAdapter;Lcom/alpine/blizzardboard/databinding/ItemAchievementBinding;)V", "getBinding", "()Lcom/alpine/blizzardboard/databinding/ItemAchievementBinding;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public final class VH extends RecyclerView.ViewHolder {
        private final ItemAchievementBinding binding;
        final /* synthetic */ AchievementAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(AchievementAdapter achievementAdapter, ItemAchievementBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = achievementAdapter;
            this.binding = binding;
        }

        public final ItemAchievementBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemAchievementBinding itemAchievementBindingInflate = ItemAchievementBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemAchievementBindingInflate, "inflate(...)");
        return new VH(this, itemAchievementBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        AchievementCell item = getItem(position);
        holder.getBinding().achTitle.setText(item.getTitle());
        holder.getBinding().achDesc.setText(item.getDescription());
        holder.getBinding().achState.setImageResource(item.getUnlocked() ? R.drawable.ic_check : R.drawable.ic_lock);
        holder.getBinding().achIcon.setAlpha(item.getUnlocked() ? 1.0f : 0.4f);
        holder.getBinding().achCard.setAlpha(item.getUnlocked() ? 1.0f : 0.7f);
    }
}
