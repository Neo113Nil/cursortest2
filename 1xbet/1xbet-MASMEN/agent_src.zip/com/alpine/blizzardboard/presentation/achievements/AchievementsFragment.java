package com.alpine.blizzardboard.presentation.achievements;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentAchievementsBinding;
import com.alpine.blizzardboard.domain.catalog.AchievementDef;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AchievementsFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u000e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017H\u0002J\b\u0010\u0019\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/alpine/blizzardboard/presentation/achievements/AchievementsFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentAchievementsBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentAchievementsBinding;", "adapter", "Lcom/alpine/blizzardboard/presentation/achievements/AchievementAdapter;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "buildCells", "", "Lcom/alpine/blizzardboard/presentation/achievements/AchievementCell;", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class AchievementsFragment extends Fragment {
    private FragmentAchievementsBinding _binding;
    private AchievementAdapter adapter;

    private final FragmentAchievementsBinding getBinding() {
        FragmentAchievementsBinding fragmentAchievementsBinding = this._binding;
        Intrinsics.checkNotNull(fragmentAchievementsBinding);
        return fragmentAchievementsBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentAchievementsBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.adapter = new AchievementAdapter();
        getBinding().achievementList.setLayoutManager(new LinearLayoutManager(requireContext()));
        RecyclerView recyclerView = getBinding().achievementList;
        AchievementAdapter achievementAdapter = this.adapter;
        AchievementAdapter achievementAdapter2 = null;
        if (achievementAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            achievementAdapter = null;
        }
        recyclerView.setAdapter(achievementAdapter);
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.achievements.AchievementsFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        AchievementAdapter achievementAdapter3 = this.adapter;
        if (achievementAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        } else {
            achievementAdapter2 = achievementAdapter3;
        }
        achievementAdapter2.submitList(buildCells());
        getBinding().achievementsProgress.setText(getString(R.string.achievements_progress, Integer.valueOf(Progress.INSTANCE.achievedCount()), Integer.valueOf(Catalog.INSTANCE.getAchievements().size())));
    }

    private final List<AchievementCell> buildCells() {
        List<AchievementDef> achievements = Catalog.INSTANCE.getAchievements();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(achievements, 10));
        for (AchievementDef achievementDef : achievements) {
            arrayList.add(new AchievementCell(achievementDef.getId(), achievementDef.getTitle(), achievementDef.getDescription(), Progress.INSTANCE.isAchieved(achievementDef.getId())));
        }
        return arrayList;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
