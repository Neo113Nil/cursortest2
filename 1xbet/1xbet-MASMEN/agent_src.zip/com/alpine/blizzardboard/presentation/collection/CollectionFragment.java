package com.alpine.blizzardboard.presentation.collection;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentCollectionBinding;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import com.alpine.blizzardboard.domain.catalog.CollectionItem;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CollectionFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u000e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017H\u0002J\b\u0010\u0019\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/alpine/blizzardboard/presentation/collection/CollectionFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentCollectionBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentCollectionBinding;", "adapter", "Lcom/alpine/blizzardboard/presentation/collection/CollectionAdapter;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "buildCells", "", "Lcom/alpine/blizzardboard/presentation/collection/CollectionCell;", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class CollectionFragment extends Fragment {
    private FragmentCollectionBinding _binding;
    private CollectionAdapter adapter;

    private final FragmentCollectionBinding getBinding() {
        FragmentCollectionBinding fragmentCollectionBinding = this._binding;
        Intrinsics.checkNotNull(fragmentCollectionBinding);
        return fragmentCollectionBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentCollectionBinding.inflate(inflater, container, false);
        LinearLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.adapter = new CollectionAdapter();
        getBinding().collectionGrid.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        RecyclerView recyclerView = getBinding().collectionGrid;
        CollectionAdapter collectionAdapter = this.adapter;
        CollectionAdapter collectionAdapter2 = null;
        if (collectionAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            collectionAdapter = null;
        }
        recyclerView.setAdapter(collectionAdapter);
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.collection.CollectionFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        Progress.INSTANCE.syncPassiveUnlocks();
        CollectionAdapter collectionAdapter3 = this.adapter;
        if (collectionAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        } else {
            collectionAdapter2 = collectionAdapter3;
        }
        collectionAdapter2.submitList(buildCells());
        getBinding().collectionProgress.setText(getString(R.string.collection_progress, Integer.valueOf(Progress.INSTANCE.collectedCount()), Integer.valueOf(Catalog.INSTANCE.getCollectionCount())));
    }

    private final List<CollectionCell> buildCells() {
        List<CollectionItem> collection = Catalog.INSTANCE.getCollection();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(collection, 10));
        for (CollectionItem collectionItem : collection) {
            arrayList.add(new CollectionCell(collectionItem.getId(), collectionItem.getCategory(), collectionItem.getName(), Progress.INSTANCE.isCollected(collectionItem.getId())));
        }
        return arrayList;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
