package com.alpine.blizzardboard.presentation.collection;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.databinding.ItemCollectionBinding;
import com.alpine.blizzardboard.domain.catalog.CollectionCategory;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CollectionAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00132\u0012\u0012\u0004\u0012\u00020\u0002\u0012\b\u0012\u00060\u0003R\u00020\u00000\u0001:\u0002\u0012\u0013B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\u001c\u0010\u0006\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J\u001c\u0010\u000b\u001a\u00020\f2\n\u0010\r\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u000e\u001a\u00020\nH\u0016J\u0010\u0010\u000f\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002¨\u0006\u0014"}, d2 = {"Lcom/alpine/blizzardboard/presentation/collection/CollectionAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/alpine/blizzardboard/presentation/collection/CollectionCell;", "Lcom/alpine/blizzardboard/presentation/collection/CollectionAdapter$VH;", "<init>", "()V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "", "holder", "position", "iconFor", "category", "Lcom/alpine/blizzardboard/domain/catalog/CollectionCategory;", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class CollectionAdapter extends ListAdapter<CollectionCell, VH> {
    private static final CollectionAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<CollectionCell>() { // from class: com.alpine.blizzardboard.presentation.collection.CollectionAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(CollectionCell a, CollectionCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a.getId(), b.getId());
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(CollectionCell a, CollectionCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a, b);
        }
    };

    /* JADX INFO: compiled from: CollectionAdapter.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[CollectionCategory.values().length];
            try {
                iArr[CollectionCategory.SNOWBOARDS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[CollectionCategory.HELMETS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[CollectionCategory.GOGGLES.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[CollectionCategory.JACKETS.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[CollectionCategory.FLAGS.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public CollectionAdapter() {
        super(DIFF);
    }

    /* JADX INFO: compiled from: CollectionAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/collection/CollectionAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/alpine/blizzardboard/databinding/ItemCollectionBinding;", "<init>", "(Lcom/alpine/blizzardboard/presentation/collection/CollectionAdapter;Lcom/alpine/blizzardboard/databinding/ItemCollectionBinding;)V", "getBinding", "()Lcom/alpine/blizzardboard/databinding/ItemCollectionBinding;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public final class VH extends RecyclerView.ViewHolder {
        private final ItemCollectionBinding binding;
        final /* synthetic */ CollectionAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(CollectionAdapter collectionAdapter, ItemCollectionBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = collectionAdapter;
            this.binding = binding;
        }

        public final ItemCollectionBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemCollectionBinding itemCollectionBindingInflate = ItemCollectionBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemCollectionBindingInflate, "inflate(...)");
        return new VH(this, itemCollectionBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        String string;
        Intrinsics.checkNotNullParameter(holder, "holder");
        CollectionCell item = getItem(position);
        Context context = holder.getBinding().getRoot().getContext();
        holder.getBinding().collIcon.setImageResource(iconFor(item.getCategory()));
        TextView textView = holder.getBinding().collName;
        if (item.getUnlocked()) {
            string = item.getName();
        } else {
            string = context.getString(R.string.collection_locked);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        }
        textView.setText(string);
        holder.getBinding().collCategory.setText(item.getCategory().getTitle());
        holder.getBinding().collLock.setVisibility(item.getUnlocked() ? 8 : 0);
        holder.getBinding().collIcon.setAlpha(item.getUnlocked() ? 1.0f : 0.35f);
        holder.getBinding().collCard.setAlpha(item.getUnlocked() ? 1.0f : 0.7f);
    }

    private final int iconFor(CollectionCategory category) {
        int i = WhenMappings.$EnumSwitchMapping$0[category.ordinal()];
        if (i == 1) {
            return R.drawable.ic_gem_snowboard;
        }
        if (i == 2) {
            return R.drawable.ic_gem_helmet;
        }
        if (i == 3) {
            return R.drawable.ic_gem_goggles;
        }
        if (i == 4) {
            return R.drawable.ic_gem_glove;
        }
        if (i != 5) {
            throw new NoWhenBranchMatchedException();
        }
        return R.drawable.ic_gem_flag;
    }
}
