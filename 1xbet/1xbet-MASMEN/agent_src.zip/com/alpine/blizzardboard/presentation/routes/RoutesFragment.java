package com.alpine.blizzardboard.presentation.routes;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.Progress;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentRoutesBinding;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import com.alpine.blizzardboard.domain.catalog.RouteInfo;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: RoutesFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u000e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017H\u0002J\u0010\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u001a\u001a\u00020\u0018H\u0002J\b\u0010\u001b\u001a\u00020\u0014H\u0002J\b\u0010\u001c\u001a\u00020\u0014H\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u001d"}, d2 = {"Lcom/alpine/blizzardboard/presentation/routes/RoutesFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentRoutesBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentRoutesBinding;", "adapter", "Lcom/alpine/blizzardboard/presentation/routes/RouteAdapter;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "buildCells", "", "Lcom/alpine/blizzardboard/presentation/routes/RouteCell;", "onRouteClicked", "cell", "applyTint", "onDestroyView", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class RoutesFragment extends Fragment {
    private FragmentRoutesBinding _binding;
    private RouteAdapter adapter;

    private final FragmentRoutesBinding getBinding() {
        FragmentRoutesBinding fragmentRoutesBinding = this._binding;
        Intrinsics.checkNotNull(fragmentRoutesBinding);
        return fragmentRoutesBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentRoutesBinding.inflate(inflater, container, false);
        FrameLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        this.adapter = new RouteAdapter(new Function1() { // from class: com.alpine.blizzardboard.presentation.routes.RoutesFragment$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return RoutesFragment.onViewCreated$lambda$0(this.f$0, (RouteCell) obj);
            }
        });
        getBinding().routeList.setLayoutManager(new LinearLayoutManager(requireContext()));
        RecyclerView recyclerView = getBinding().routeList;
        RouteAdapter routeAdapter = this.adapter;
        RouteAdapter routeAdapter2 = null;
        if (routeAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            routeAdapter = null;
        }
        recyclerView.setAdapter(routeAdapter);
        ImageButton backButton = getBinding().backButton;
        Intrinsics.checkNotNullExpressionValue(backButton, "backButton");
        backButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.routes.RoutesFragment$onViewCreated$$inlined$onClickBack$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.back();
                Intrinsics.checkNotNull(view2);
                FragmentKt.findNavController(this.this$0).popBackStack();
            }
        });
        applyTint();
        RouteAdapter routeAdapter3 = this.adapter;
        if (routeAdapter3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        } else {
            routeAdapter2 = routeAdapter3;
        }
        routeAdapter2.submitList(buildCells());
    }

    static final Unit onViewCreated$lambda$0(RoutesFragment routesFragment, RouteCell cell) {
        Intrinsics.checkNotNullParameter(cell, "cell");
        routesFragment.onRouteClicked(cell);
        return Unit.INSTANCE;
    }

    private final List<RouteCell> buildCells() {
        int iCompletedCount = Progress.INSTANCE.completedCount();
        int currentRouteId = Progress.INSTANCE.getCurrentRouteId();
        List<RouteInfo> routes = Catalog.INSTANCE.getRoutes();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(routes, 10));
        for (RouteInfo routeInfo : routes) {
            int id = routeInfo.getId();
            String name = routeInfo.getName();
            String subtitle = routeInfo.getSubtitle();
            int firstLevel = routeInfo.getFirstLevel();
            int lastLevel = routeInfo.getLastLevel();
            boolean z = true;
            boolean z2 = iCompletedCount >= routeInfo.getUnlockAtCompleted();
            if (routeInfo.getId() != currentRouteId) {
                z = false;
            }
            arrayList.add(new RouteCell(id, name, subtitle, firstLevel, lastLevel, z2, z, routeInfo.getUnlockAtCompleted()));
        }
        return arrayList;
    }

    private final void onRouteClicked(RouteCell cell) {
        if (!cell.getUnlocked()) {
            Toast.makeText(requireContext(), getString(R.string.route_locked, Integer.valueOf(cell.getUnlockAtCompleted())), 0).show();
            return;
        }
        SoundManager.INSTANCE.notifySound();
        Progress.INSTANCE.setCurrentRouteId(cell.getId());
        applyTint();
        RouteAdapter routeAdapter = this.adapter;
        if (routeAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            routeAdapter = null;
        }
        routeAdapter.submitList(buildCells());
    }

    private final void applyTint() {
        getBinding().routeTint.setBackgroundColor((int) Catalog.INSTANCE.getRoutes().get(RangesKt.coerceIn(Progress.INSTANCE.getCurrentRouteId(), 0, Catalog.INSTANCE.getRoutes().size() - 1)).getTint());
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }
}
