package com.alpine.blizzardboard.presentation.routes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.databinding.ItemRouteBinding;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: RouteAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u0000 \u00122\u0012\u0012\u0004\u0012\u00020\u0002\u0012\b\u0012\u00060\u0003R\u00020\u00000\u0001:\u0002\u0011\u0012B\u001b\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u001c\u0010\t\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u001c\u0010\u000e\u001a\u00020\u00062\n\u0010\u000f\u001a\u00060\u0003R\u00020\u00002\u0006\u0010\u0010\u001a\u00020\rH\u0016R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/alpine/blizzardboard/presentation/routes/RouteAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/alpine/blizzardboard/presentation/routes/RouteCell;", "Lcom/alpine/blizzardboard/presentation/routes/RouteAdapter$VH;", "onClick", "Lkotlin/Function1;", "", "<init>", "(Lkotlin/jvm/functions/Function1;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class RouteAdapter extends ListAdapter<RouteCell, VH> {
    private static final RouteAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<RouteCell>() { // from class: com.alpine.blizzardboard.presentation.routes.RouteAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(RouteCell a, RouteCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return a.getId() == b.getId();
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(RouteCell a, RouteCell b) {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a, b);
        }
    };
    private final Function1<RouteCell, Unit> onClick;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public RouteAdapter(Function1<? super RouteCell, Unit> onClick) {
        super(DIFF);
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        this.onClick = onClick;
    }

    /* JADX INFO: compiled from: RouteAdapter.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/routes/RouteAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/alpine/blizzardboard/databinding/ItemRouteBinding;", "<init>", "(Lcom/alpine/blizzardboard/presentation/routes/RouteAdapter;Lcom/alpine/blizzardboard/databinding/ItemRouteBinding;)V", "getBinding", "()Lcom/alpine/blizzardboard/databinding/ItemRouteBinding;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public final class VH extends RecyclerView.ViewHolder {
        private final ItemRouteBinding binding;
        final /* synthetic */ RouteAdapter this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(RouteAdapter routeAdapter, ItemRouteBinding binding) {
            super(binding.getRoot());
            Intrinsics.checkNotNullParameter(binding, "binding");
            this.this$0 = routeAdapter;
            this.binding = binding;
        }

        public final ItemRouteBinding getBinding() {
            return this.binding;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemRouteBinding itemRouteBindingInflate = ItemRouteBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemRouteBindingInflate, "inflate(...)");
        return new VH(this, itemRouteBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        String string;
        int i;
        Intrinsics.checkNotNullParameter(holder, "holder");
        final RouteCell item = getItem(position);
        Context context = holder.getBinding().getRoot().getContext();
        holder.getBinding().routeName.setText(item.getName());
        holder.getBinding().routeSubtitle.setText(item.getSubtitle());
        holder.getBinding().routeLevels.setText(context.getString(R.string.route_levels_format, Integer.valueOf(item.getFirstLevel()), Integer.valueOf(item.getLastLevel())));
        if (item.getUnlocked()) {
            string = item.getCurrent() ? context.getString(R.string.route_current) : context.getString(R.string.route_select);
        } else {
            string = context.getString(R.string.route_locked, Integer.valueOf(item.getUnlockAtCompleted()));
        }
        Intrinsics.checkNotNull(string);
        holder.getBinding().routeStatus.setText(string);
        if (item.getUnlocked()) {
            i = item.getCurrent() ? R.color.gold_bright : R.color.ice_blue;
        } else {
            i = R.color.text_muted;
        }
        holder.getBinding().routeStatus.setTextColor(context.getColor(i));
        holder.getBinding().routeCard.setAlpha(item.getUnlocked() ? 1.0f : 0.6f);
        holder.getBinding().routeCard.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.routes.RouteAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RouteAdapter.onBindViewHolder$lambda$0(this.f$0, item, view);
            }
        });
    }

    static final void onBindViewHolder$lambda$0(RouteAdapter routeAdapter, RouteCell routeCell, View view) {
        Function1<RouteCell, Unit> function1 = routeAdapter.onClick;
        Intrinsics.checkNotNull(routeCell);
        function1.invoke(routeCell);
    }
}
