package com.alpine.blizzardboard.presentation.routes;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: RouteAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u001d\b\u0086\b\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\f\u001a\u00020\u0003¢\u0006\u0004\b\r\u0010\u000eJ\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\nHÆ\u0003J\t\u0010 \u001a\u00020\nHÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003JY\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\u0003HÆ\u0001J\u0013\u0010#\u001a\u00020\n2\b\u0010$\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010%\u001a\u00020\u0003HÖ\u0001J\t\u0010&\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0010R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0017R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0010¨\u0006'"}, d2 = {"Lcom/alpine/blizzardboard/presentation/routes/RouteCell;", "", "id", "", "name", "", "subtitle", "firstLevel", "lastLevel", "unlocked", "", "current", "unlockAtCompleted", "<init>", "(ILjava/lang/String;Ljava/lang/String;IIZZI)V", "getId", "()I", "getName", "()Ljava/lang/String;", "getSubtitle", "getFirstLevel", "getLastLevel", "getUnlocked", "()Z", "getCurrent", "getUnlockAtCompleted", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class RouteCell {
    private final boolean current;
    private final int firstLevel;
    private final int id;
    private final int lastLevel;
    private final String name;
    private final String subtitle;
    private final int unlockAtCompleted;
    private final boolean unlocked;

    public static /* synthetic */ RouteCell copy$default(RouteCell routeCell, int i, String str, String str2, int i2, int i3, boolean z, boolean z2, int i4, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            i = routeCell.id;
        }
        if ((i5 & 2) != 0) {
            str = routeCell.name;
        }
        if ((i5 & 4) != 0) {
            str2 = routeCell.subtitle;
        }
        if ((i5 & 8) != 0) {
            i2 = routeCell.firstLevel;
        }
        if ((i5 & 16) != 0) {
            i3 = routeCell.lastLevel;
        }
        if ((i5 & 32) != 0) {
            z = routeCell.unlocked;
        }
        if ((i5 & 64) != 0) {
            z2 = routeCell.current;
        }
        if ((i5 & 128) != 0) {
            i4 = routeCell.unlockAtCompleted;
        }
        boolean z3 = z2;
        int i6 = i4;
        int i7 = i3;
        boolean z4 = z;
        return routeCell.copy(i, str, str2, i2, i7, z4, z3, i6);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getSubtitle() {
        return this.subtitle;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getFirstLevel() {
        return this.firstLevel;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getLastLevel() {
        return this.lastLevel;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final boolean getUnlocked() {
        return this.unlocked;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final boolean getCurrent() {
        return this.current;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }

    public final RouteCell copy(int id, String name, String subtitle, int firstLevel, int lastLevel, boolean unlocked, boolean current, int unlockAtCompleted) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        return new RouteCell(id, name, subtitle, firstLevel, lastLevel, unlocked, current, unlockAtCompleted);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RouteCell)) {
            return false;
        }
        RouteCell routeCell = (RouteCell) other;
        return this.id == routeCell.id && Intrinsics.areEqual(this.name, routeCell.name) && Intrinsics.areEqual(this.subtitle, routeCell.subtitle) && this.firstLevel == routeCell.firstLevel && this.lastLevel == routeCell.lastLevel && this.unlocked == routeCell.unlocked && this.current == routeCell.current && this.unlockAtCompleted == routeCell.unlockAtCompleted;
    }

    public int hashCode() {
        return (((((((((((((Integer.hashCode(this.id) * 31) + this.name.hashCode()) * 31) + this.subtitle.hashCode()) * 31) + Integer.hashCode(this.firstLevel)) * 31) + Integer.hashCode(this.lastLevel)) * 31) + Boolean.hashCode(this.unlocked)) * 31) + Boolean.hashCode(this.current)) * 31) + Integer.hashCode(this.unlockAtCompleted);
    }

    public String toString() {
        return "RouteCell(id=" + this.id + ", name=" + this.name + ", subtitle=" + this.subtitle + ", firstLevel=" + this.firstLevel + ", lastLevel=" + this.lastLevel + ", unlocked=" + this.unlocked + ", current=" + this.current + ", unlockAtCompleted=" + this.unlockAtCompleted + ")";
    }

    public RouteCell(int i, String name, String subtitle, int i2, int i3, boolean z, boolean z2, int i4) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        this.id = i;
        this.name = name;
        this.subtitle = subtitle;
        this.firstLevel = i2;
        this.lastLevel = i3;
        this.unlocked = z;
        this.current = z2;
        this.unlockAtCompleted = i4;
    }

    public final int getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getSubtitle() {
        return this.subtitle;
    }

    public final int getFirstLevel() {
        return this.firstLevel;
    }

    public final int getLastLevel() {
        return this.lastLevel;
    }

    public final boolean getUnlocked() {
        return this.unlocked;
    }

    public final boolean getCurrent() {
        return this.current;
    }

    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }
}
