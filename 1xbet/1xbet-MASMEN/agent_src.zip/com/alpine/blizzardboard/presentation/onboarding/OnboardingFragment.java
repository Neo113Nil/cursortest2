package com.alpine.blizzardboard.presentation.onboarding;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.core.SoundManager;
import com.alpine.blizzardboard.databinding.FragmentOnboardingBinding;
import com.alpine.blizzardboard.databinding.ItemOnboardingBinding;
import com.alpine.blizzardboard.di.Container;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: OnboardingFragment.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001:\u0001#B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u0012\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0016J\u001a\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u00102\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0016J\u0010\u0010\u001c\u001a\u00020\r2\u0006\u0010\u001d\u001a\u00020\rH\u0002J\b\u0010\u001e\u001a\u00020\u001aH\u0002J\b\u0010\u001f\u001a\u00020\u001aH\u0002J\b\u0010 \u001a\u00020\u001aH\u0002J\b\u0010!\u001a\u00020\u001aH\u0002J\b\u0010\"\u001a\u00020\u001aH\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u000e\u001a\u0012\u0012\u0004\u0012\u00020\u00100\u000fj\b\u0012\u0004\u0012\u00020\u0010`\u0011X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"}, d2 = {"Lcom/alpine/blizzardboard/presentation/onboarding/OnboardingFragment;", "Landroidx/fragment/app/Fragment;", "<init>", "()V", "_binding", "Lcom/alpine/blizzardboard/databinding/FragmentOnboardingBinding;", "binding", "getBinding", "()Lcom/alpine/blizzardboard/databinding/FragmentOnboardingBinding;", "slides", "", "Lcom/alpine/blizzardboard/presentation/onboarding/Slide;", "current", "", "dotViews", "Ljava/util/ArrayList;", "Landroid/view/View;", "Lkotlin/collections/ArrayList;", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "", "view", "dp", "value", "buildDots", "updateDots", "updateButton", "finish", "onDestroyView", "OnboardingAdapter", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class OnboardingFragment extends Fragment {
    private FragmentOnboardingBinding _binding;
    private int current;
    private final List<Slide> slides = CollectionsKt.listOf((Object[]) new Slide[]{new Slide(R.drawable.ic_snowboard, R.string.onb_title_1, R.string.onb_body_1), new Slide(R.drawable.ic_snow_goggles, R.string.onb_title_2, R.string.onb_body_2), new Slide(R.drawable.ic_gem_snowflake, R.string.onb_title_3, R.string.onb_body_3)});
    private final ArrayList<View> dotViews = new ArrayList<>();

    /* JADX INFO: Access modifiers changed from: private */
    public final FragmentOnboardingBinding getBinding() {
        FragmentOnboardingBinding fragmentOnboardingBinding = this._binding;
        Intrinsics.checkNotNull(fragmentOnboardingBinding);
        return fragmentOnboardingBinding;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentOnboardingBinding.inflate(inflater, container, false);
        ConstraintLayout root = getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(), 0, false);
        getBinding().pager.setLayoutManager(linearLayoutManager);
        getBinding().pager.setAdapter(new OnboardingAdapter(this.slides));
        new PagerSnapHelper().attachToRecyclerView(getBinding().pager);
        buildDots();
        updateButton();
        getBinding().pager.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.alpine.blizzardboard.presentation.onboarding.OnboardingFragment.onViewCreated.1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView rv, int dx, int dy) {
                Intrinsics.checkNotNullParameter(rv, "rv");
                int iFindFirstCompletelyVisibleItemPosition = linearLayoutManager.findFirstCompletelyVisibleItemPosition();
                if (iFindFirstCompletelyVisibleItemPosition == -1 || iFindFirstCompletelyVisibleItemPosition == this.current) {
                    return;
                }
                this.current = iFindFirstCompletelyVisibleItemPosition;
                this.updateDots();
                this.updateButton();
            }
        });
        TextView skipButton = getBinding().skipButton;
        Intrinsics.checkNotNullExpressionValue(skipButton, "skipButton");
        skipButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.onboarding.OnboardingFragment$onViewCreated$$inlined$onClick$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                this.this$0.finish();
            }
        });
        TextView nextButton = getBinding().nextButton;
        Intrinsics.checkNotNullExpressionValue(nextButton, "nextButton");
        nextButton.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.presentation.onboarding.OnboardingFragment$onViewCreated$$inlined$onClick$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                SoundManager.INSTANCE.click();
                Intrinsics.checkNotNull(view2);
                int i = this.this$0.current;
                int lastIndex = CollectionsKt.getLastIndex(this.this$0.slides);
                OnboardingFragment onboardingFragment = this.this$0;
                if (i == lastIndex) {
                    onboardingFragment.finish();
                } else {
                    onboardingFragment.getBinding().pager.smoothScrollToPosition(this.this$0.current + 1);
                }
            }
        });
    }

    private final int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private final void buildDots() {
        getBinding().dots.removeAllViews();
        this.dotViews.clear();
        int size = this.slides.size();
        for (int i = 0; i < size; i++) {
            View view = new View(requireContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(8), dp(8));
            layoutParams.setMarginStart(dp(5));
            layoutParams.setMarginEnd(dp(5));
            view.setLayoutParams(layoutParams);
            getBinding().dots.addView(view);
            this.dotViews.add(view);
        }
        updateDots();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateDots() {
        int size = this.dotViews.size();
        int i = 0;
        while (i < size) {
            View view = this.dotViews.get(i);
            Intrinsics.checkNotNullExpressionValue(view, "get(...)");
            View view2 = view;
            boolean z = i == this.current;
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            layoutParams.width = dp(z ? 22 : 8);
            view2.setLayoutParams(layoutParams);
            view2.setBackgroundResource(z ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
            i++;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateButton() {
        getBinding().nextButton.setText(getString(this.current == CollectionsKt.getLastIndex(this.slides) ? R.string.onb_start : R.string.onb_next));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void finish() {
        Container.INSTANCE.getPrefs().setOnboardingDone(true);
        FragmentKt.findNavController(this).navigate(R.id.action_onboarding_to_home);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
    }

    /* JADX INFO: compiled from: OnboardingFragment.kt */
    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0002\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0014B\u0015\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001c\u0010\n\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u001c\u0010\u000f\u001a\u00020\u00102\n\u0010\u0011\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u000eH\u0016J\b\u0010\u0013\u001a\u00020\u000eH\u0016R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0015"}, d2 = {"Lcom/alpine/blizzardboard/presentation/onboarding/OnboardingFragment$OnboardingAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/alpine/blizzardboard/presentation/onboarding/OnboardingFragment$OnboardingAdapter$VH;", "items", "", "Lcom/alpine/blizzardboard/presentation/onboarding/Slide;", "<init>", "(Ljava/util/List;)V", "getItems", "()Ljava/util/List;", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "", "holder", "position", "getItemCount", "VH", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class OnboardingAdapter extends RecyclerView.Adapter<VH> {
        private final List<Slide> items;

        /* JADX INFO: compiled from: OnboardingFragment.kt */
        @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/alpine/blizzardboard/presentation/onboarding/OnboardingFragment$OnboardingAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/alpine/blizzardboard/databinding/ItemOnboardingBinding;", "<init>", "(Lcom/alpine/blizzardboard/presentation/onboarding/OnboardingFragment$OnboardingAdapter;Lcom/alpine/blizzardboard/databinding/ItemOnboardingBinding;)V", "getBinding", "()Lcom/alpine/blizzardboard/databinding/ItemOnboardingBinding;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public final class VH extends RecyclerView.ViewHolder {
            private final ItemOnboardingBinding binding;
            final /* synthetic */ OnboardingAdapter this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public VH(OnboardingAdapter onboardingAdapter, ItemOnboardingBinding binding) {
                super(binding.getRoot());
                Intrinsics.checkNotNullParameter(binding, "binding");
                this.this$0 = onboardingAdapter;
                this.binding = binding;
            }

            public final ItemOnboardingBinding getBinding() {
                return this.binding;
            }
        }

        public OnboardingAdapter(List<Slide> items) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.items = items;
        }

        public final List<Slide> getItems() {
            return this.items;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            ItemOnboardingBinding itemOnboardingBindingInflate = ItemOnboardingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            Intrinsics.checkNotNullExpressionValue(itemOnboardingBindingInflate, "inflate(...)");
            return new VH(this, itemOnboardingBindingInflate);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            Slide slide = this.items.get(position);
            holder.getBinding().slideIcon.setImageResource(slide.getIcon());
            holder.getBinding().slideTitle.setText(slide.getTitle());
            holder.getBinding().slideBody.setText(slide.getBody());
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.items.size();
        }
    }
}
