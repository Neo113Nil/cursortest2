package com.alpine.blizzardboard.data.prefs;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.HashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: AppPreferences.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010#\n\u0002\b\b\u0018\u0000 C2\u00020\u0001:\u0001CB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u0018J\u0016\u0010#\u001a\u00020$2\u0006\u0010\"\u001a\u00020\u00182\u0006\u0010%\u001a\u00020\u0018J\u000e\u0010&\u001a\u00020\u00182\u0006\u0010'\u001a\u00020\u0018J\u000e\u0010(\u001a\u00020\u00182\u0006\u0010'\u001a\u00020\u0018J\u000e\u0010)\u001a\u00020\u00182\u0006\u0010*\u001a\u00020+J\u0016\u0010,\u001a\u00020$2\u0006\u0010*\u001a\u00020+2\u0006\u0010-\u001a\u00020\u0018J\u0016\u0010.\u001a\u00020$2\u0006\u0010*\u001a\u00020+2\u0006\u0010/\u001a\u00020\u0018J\u000e\u00100\u001a\u00020\t2\u0006\u0010*\u001a\u00020+J\u000e\u00101\u001a\u0002022\u0006\u00103\u001a\u00020+J\u0016\u00104\u001a\u00020$2\u0006\u00103\u001a\u00020+2\u0006\u0010/\u001a\u000202J\u0016\u00105\u001a\u00020$2\u0006\u00103\u001a\u00020+2\u0006\u0010-\u001a\u000202J\u0016\u00106\u001a\u00020$2\u0006\u00103\u001a\u00020+2\u0006\u0010-\u001a\u000202J\u0016\u00107\u001a\u00020\t2\u0006\u00108\u001a\u00020+2\u0006\u0010*\u001a\u00020+J\u0016\u00109\u001a\u00020\t2\u0006\u00108\u001a\u00020+2\u0006\u0010*\u001a\u00020+J\u000e\u0010:\u001a\u00020\u00182\u0006\u00108\u001a\u00020+J\u0016\u0010;\u001a\b\u0012\u0004\u0012\u00020+0<2\u0006\u00108\u001a\u00020+H\u0002J\u0006\u0010B\u001a\u00020$R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R$\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR$\u0010\u000f\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0010\u0010\f\"\u0004\b\u0011\u0010\u000eR$\u0010\u0012\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0013\u0010\f\"\u0004\b\u0014\u0010\u000eR$\u0010\u0015\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0016\u0010\f\"\u0004\b\u0017\u0010\u000eR$\u0010\u0019\u001a\u00020\u00182\u0006\u0010\b\u001a\u00020\u00188F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR$\u0010\u001e\u001a\u00020\u00182\u0006\u0010\b\u001a\u00020\u00188F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001f\u0010\u001b\"\u0004\b \u0010\u001dR$\u0010=\u001a\u00020+2\u0006\u0010\b\u001a\u00020+8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b>\u0010?\"\u0004\b@\u0010A¨\u0006D"}, d2 = {"Lcom/alpine/blizzardboard/data/prefs/AppPreferences;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "sp", "Landroid/content/SharedPreferences;", "v", "", "onboardingDone", "getOnboardingDone", "()Z", "setOnboardingDone", "(Z)V", "soundEnabled", "getSoundEnabled", "setSoundEnabled", "vibrationEnabled", "getVibrationEnabled", "setVibrationEnabled", "snowfallEnabled", "getSnowfallEnabled", "setSnowfallEnabled", "", "currentRouteId", "getCurrentRouteId", "()I", "setCurrentRouteId", "(I)V", "highestUnlockedLevel", "getHighestUnlockedLevel", "setHighestUnlockedLevel", "starsFor", "levelId", "recordStars", "", "stars", "totalStars", "levelCount", "completedLevels", "boosterCount", "id", "", "setBoosterCount", "value", "addBooster", "delta", "consumeBooster", "counter", "", "key", "addCounter", "recordMax", "setCounter", "isUnlocked", "setKey", "unlock", "unlockedCount", "readSet", "", "lastDailyDate", "getLastDailyDate", "()Ljava/lang/String;", "setLastDailyDate", "(Ljava/lang/String;)V", "clearAll", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class AppPreferences {
    private static final int DEFAULT_BOOSTER = 3;
    private static final String FILE = "alpine_blizzard_prefs";
    private static final String KEY_BOOSTER = "booster_";
    private static final String KEY_DAILY = "daily_date";
    private static final String KEY_ONBOARDING = "onboarding_done";
    private static final String KEY_ROUTE = "current_route";
    private static final String KEY_SNOWFALL = "snowfall_enabled";
    private static final String KEY_SOUND = "sound_enabled";
    private static final String KEY_STARS = "stars_";
    private static final String KEY_STAT = "stat_";
    private static final String KEY_UNLOCKED = "highest_unlocked";
    private static final String KEY_VIBRATION = "vibration_enabled";
    public static final String SET_ACHIEVEMENTS = "set_achievements";
    public static final String SET_COLLECTION = "set_collection";
    public static final String STAT_BEST_COMBO = "best_combo";
    public static final String STAT_BEST_STREAK = "best_streak";
    public static final String STAT_BOOSTERS_USED = "boosters_used";
    public static final String STAT_LEVELS_DONE = "levels_done";
    public static final String STAT_MATCHES = "matches_played";
    public static final String STAT_STREAK = "success_streak";
    public static final String STAT_TOTAL_SCORE = "total_score";
    private final SharedPreferences sp;

    public AppPreferences(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences sharedPreferences = context.getApplicationContext().getSharedPreferences(FILE, 0);
        Intrinsics.checkNotNullExpressionValue(sharedPreferences, "getSharedPreferences(...)");
        this.sp = sharedPreferences;
    }

    public final boolean getOnboardingDone() {
        return this.sp.getBoolean(KEY_ONBOARDING, false);
    }

    public final void setOnboardingDone(boolean z) {
        this.sp.edit().putBoolean(KEY_ONBOARDING, z).apply();
    }

    public final boolean getSoundEnabled() {
        return this.sp.getBoolean(KEY_SOUND, true);
    }

    public final void setSoundEnabled(boolean z) {
        this.sp.edit().putBoolean(KEY_SOUND, z).apply();
    }

    public final boolean getVibrationEnabled() {
        return this.sp.getBoolean(KEY_VIBRATION, true);
    }

    public final void setVibrationEnabled(boolean z) {
        this.sp.edit().putBoolean(KEY_VIBRATION, z).apply();
    }

    public final boolean getSnowfallEnabled() {
        return this.sp.getBoolean(KEY_SNOWFALL, true);
    }

    public final void setSnowfallEnabled(boolean z) {
        this.sp.edit().putBoolean(KEY_SNOWFALL, z).apply();
    }

    public final int getCurrentRouteId() {
        return this.sp.getInt(KEY_ROUTE, 0);
    }

    public final void setCurrentRouteId(int i) {
        this.sp.edit().putInt(KEY_ROUTE, i).apply();
    }

    public final int getHighestUnlockedLevel() {
        return this.sp.getInt(KEY_UNLOCKED, 1);
    }

    public final void setHighestUnlockedLevel(int i) {
        if (i > getHighestUnlockedLevel()) {
            this.sp.edit().putInt(KEY_UNLOCKED, i).apply();
        }
    }

    public final int starsFor(int levelId) {
        return this.sp.getInt(KEY_STARS + levelId, 0);
    }

    public final void recordStars(int levelId, int stars) {
        if (stars > starsFor(levelId)) {
            this.sp.edit().putInt(KEY_STARS + levelId, stars).apply();
        }
    }

    public final int totalStars(int levelCount) {
        int iStarsFor = 0;
        int i = 1;
        if (1 <= levelCount) {
            while (true) {
                iStarsFor += starsFor(i);
                if (i == levelCount) {
                    break;
                }
                i++;
            }
        }
        return iStarsFor;
    }

    public final int completedLevels(int levelCount) {
        int i = 0;
        int i2 = 1;
        if (1 <= levelCount) {
            while (true) {
                if (starsFor(i2) > 0) {
                    i++;
                }
                if (i2 == levelCount) {
                    break;
                }
                i2++;
            }
        }
        return i;
    }

    public final int boosterCount(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return this.sp.getInt(KEY_BOOSTER + id, 3);
    }

    public final void setBoosterCount(String id, int value) {
        Intrinsics.checkNotNullParameter(id, "id");
        this.sp.edit().putInt(KEY_BOOSTER + id, RangesKt.coerceAtLeast(value, 0)).apply();
    }

    public final void addBooster(String id, int delta) {
        Intrinsics.checkNotNullParameter(id, "id");
        setBoosterCount(id, boosterCount(id) + delta);
    }

    public final boolean consumeBooster(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        int iBoosterCount = boosterCount(id);
        if (iBoosterCount <= 0) {
            return false;
        }
        setBoosterCount(id, iBoosterCount - 1);
        return true;
    }

    public final long counter(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return this.sp.getLong(KEY_STAT + key, 0L);
    }

    public final void addCounter(String key, long delta) {
        Intrinsics.checkNotNullParameter(key, "key");
        this.sp.edit().putLong(KEY_STAT + key, counter(key) + delta).apply();
    }

    public final void recordMax(String key, long value) {
        Intrinsics.checkNotNullParameter(key, "key");
        if (value > counter(key)) {
            this.sp.edit().putLong(KEY_STAT + key, value).apply();
        }
    }

    public final void setCounter(String key, long value) {
        Intrinsics.checkNotNullParameter(key, "key");
        this.sp.edit().putLong(KEY_STAT + key, value).apply();
    }

    public final boolean isUnlocked(String setKey, String id) {
        Intrinsics.checkNotNullParameter(setKey, "setKey");
        Intrinsics.checkNotNullParameter(id, "id");
        return readSet(setKey).contains(id);
    }

    public final boolean unlock(String setKey, String id) {
        Intrinsics.checkNotNullParameter(setKey, "setKey");
        Intrinsics.checkNotNullParameter(id, "id");
        Set<String> set = readSet(setKey);
        if (set.contains(id)) {
            return false;
        }
        set.add(id);
        this.sp.edit().putStringSet(setKey, set).apply();
        return true;
    }

    public final int unlockedCount(String setKey) {
        Intrinsics.checkNotNullParameter(setKey, "setKey");
        return readSet(setKey).size();
    }

    private final Set<String> readSet(String setKey) {
        Set<String> stringSet = this.sp.getStringSet(setKey, SetsKt.emptySet());
        if (stringSet == null) {
            stringSet = SetsKt.emptySet();
        }
        return new HashSet(stringSet);
    }

    public final String getLastDailyDate() {
        String string = this.sp.getString(KEY_DAILY, "");
        return string == null ? "" : string;
    }

    public final void setLastDailyDate(String v) {
        Intrinsics.checkNotNullParameter(v, "v");
        this.sp.edit().putString(KEY_DAILY, v).apply();
    }

    public final void clearAll() {
        this.sp.edit().clear().apply();
    }
}
