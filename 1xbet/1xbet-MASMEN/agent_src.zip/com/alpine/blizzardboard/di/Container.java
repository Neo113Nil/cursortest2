package com.alpine.blizzardboard.di;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.data.prefs.AppPreferences;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Container.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\r"}, d2 = {"Lcom/alpine/blizzardboard/di/Container;", "", "<init>", "()V", "_prefs", "Lcom/alpine/blizzardboard/data/prefs/AppPreferences;", "prefs", "getPrefs", "()Lcom/alpine/blizzardboard/data/prefs/AppPreferences;", "init", "", "context", "Landroid/content/Context;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Container {
    public static final Container INSTANCE = new Container();
    private static AppPreferences _prefs;

    private Container() {
    }

    public final AppPreferences getPrefs() {
        AppPreferences appPreferences = _prefs;
        if (appPreferences != null) {
            return appPreferences;
        }
        throw new IllegalStateException("Container not initialised".toString());
    }

    public final void init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (_prefs == null) {
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            _prefs = new AppPreferences(applicationContext);
        }
    }
}
