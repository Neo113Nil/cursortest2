package com.alpine.blizzardboard.core;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.data.prefs.AppPreferences;
import com.alpine.blizzardboard.di.Container;
import com.alpine.blizzardboard.domain.catalog.AchievementDef;
import com.alpine.blizzardboard.domain.catalog.Catalog;
import com.alpine.blizzardboard.domain.catalog.CollectionItem;
import com.alpine.blizzardboard.domain.catalog.RouteInfo;
import com.alpine.blizzardboard.domain.level.Levels;
import com.alpine.blizzardboard.domain.model.BoosterType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Progress.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\tJ\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\tJ\u0006\u0010\u0010\u001a\u00020\tJ\u0006\u0010\u0011\u001a\u00020\tJ\u0006\u0010\u0012\u001a\u00020\tJ\u000e\u0010\u0018\u001a\u00020\u000f2\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0016\u0010\u001e\u001a\u00020\u001f2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010 \u001a\u00020\tJ\u000e\u0010!\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0006\u0010\"\u001a\u00020#J\u0006\u0010$\u001a\u00020#J\u0006\u0010%\u001a\u00020#J\u0006\u0010&\u001a\u00020#J\u0006\u0010'\u001a\u00020#J\u0006\u0010(\u001a\u00020#J\u000e\u0010)\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\tJ\u000e\u0010*\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020+J\u0006\u0010,\u001a\u00020\tJ\u000e\u0010-\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020+J\u0006\u0010.\u001a\u00020\tJ\u0006\u0010/\u001a\u00020\u001fJ\u000e\u00100\u001a\u00020\u000f2\u0006\u00101\u001a\u00020+J\u000e\u00102\u001a\u00020\u001f2\u0006\u00101\u001a\u00020+J6\u00103\u001a\u0002042\u0006\u00105\u001a\u00020\t2\u0006\u00106\u001a\u00020\t2\u0006\u00107\u001a\u00020\t2\u0006\u0010&\u001a\u00020\t2\u0006\u00108\u001a\u00020\u000f2\u0006\u00109\u001a\u00020\u000fJ\u0006\u0010:\u001a\u00020\u001fJ\u0006\u0010;\u001a\u00020\u001fJ\u000e\u0010<\u001a\b\u0012\u0004\u0012\u00020>0=H\u0002R\u0014\u0010\u0004\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\t8F¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR$\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\t8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0015\u0010\u000b\"\u0004\b\u0016\u0010\u0017¨\u0006?"}, d2 = {"Lcom/alpine/blizzardboard/core/Progress;", "", "<init>", "()V", "p", "Lcom/alpine/blizzardboard/data/prefs/AppPreferences;", "getP", "()Lcom/alpine/blizzardboard/data/prefs/AppPreferences;", "levelCount", "", "getLevelCount", "()I", "starsFor", "id", "isUnlocked", "", "highestUnlocked", "completedCount", "totalStars", "value", "currentRouteId", "getCurrentRouteId", "setCurrentRouteId", "(I)V", "isRouteUnlocked", "route", "Lcom/alpine/blizzardboard/domain/catalog/RouteInfo;", "boosterCount", "t", "Lcom/alpine/blizzardboard/domain/model/BoosterType;", "addBooster", "", "n", "consumeBooster", "totalScore", "", "levelsCompleted", "matchesPlayed", "bestCombo", "boostersUsed", "bestStreak", "addMatches", "isCollected", "", "collectedCount", "isAchieved", "achievedCount", "syncPassiveUnlocks", "isDailyAvailable", "today", "claimDaily", "onLevelComplete", "Lcom/alpine/blizzardboard/core/LevelOutcome;", "levelId", "stars", "scoreGained", "madeSpecial", "snowGoalCompleted", "onLevelFailed", "resetAll", "syncCollection", "", "Lcom/alpine/blizzardboard/domain/catalog/CollectionItem;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Progress {
    public static final Progress INSTANCE = new Progress();

    private Progress() {
    }

    private final AppPreferences getP() {
        return Container.INSTANCE.getPrefs();
    }

    public final int getLevelCount() {
        return Levels.INSTANCE.getCount();
    }

    public final int starsFor(int id) {
        return getP().starsFor(id);
    }

    public final boolean isUnlocked(int id) {
        return id <= getP().getHighestUnlockedLevel();
    }

    public final int highestUnlocked() {
        return getP().getHighestUnlockedLevel();
    }

    public final int completedCount() {
        return getP().completedLevels(Levels.INSTANCE.getCount());
    }

    public final int totalStars() {
        return getP().totalStars(Levels.INSTANCE.getCount());
    }

    public final int getCurrentRouteId() {
        return getP().getCurrentRouteId();
    }

    public final void setCurrentRouteId(int i) {
        getP().setCurrentRouteId(i);
    }

    public final boolean isRouteUnlocked(RouteInfo route) {
        Intrinsics.checkNotNullParameter(route, "route");
        return completedCount() >= route.getUnlockAtCompleted();
    }

    public final int boosterCount(BoosterType t) {
        Intrinsics.checkNotNullParameter(t, "t");
        return getP().boosterCount(t.getKey());
    }

    public final void addBooster(BoosterType t, int n) {
        Intrinsics.checkNotNullParameter(t, "t");
        getP().addBooster(t.getKey(), n);
    }

    public final boolean consumeBooster(BoosterType t) {
        Intrinsics.checkNotNullParameter(t, "t");
        boolean zConsumeBooster = getP().consumeBooster(t.getKey());
        if (zConsumeBooster) {
            getP().addCounter(AppPreferences.STAT_BOOSTERS_USED, 1L);
        }
        return zConsumeBooster;
    }

    public final long totalScore() {
        return getP().counter(AppPreferences.STAT_TOTAL_SCORE);
    }

    public final long levelsCompleted() {
        return completedCount();
    }

    public final long matchesPlayed() {
        return getP().counter(AppPreferences.STAT_MATCHES);
    }

    public final long bestCombo() {
        return getP().counter(AppPreferences.STAT_BEST_COMBO);
    }

    public final long boostersUsed() {
        return getP().counter(AppPreferences.STAT_BOOSTERS_USED);
    }

    public final long bestStreak() {
        return getP().counter(AppPreferences.STAT_BEST_STREAK);
    }

    public final void addMatches(int n) {
        getP().addCounter(AppPreferences.STAT_MATCHES, n);
    }

    public final boolean isCollected(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return getP().isUnlocked(AppPreferences.SET_COLLECTION, id);
    }

    public final int collectedCount() {
        return getP().unlockedCount(AppPreferences.SET_COLLECTION);
    }

    public final boolean isAchieved(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return getP().isUnlocked(AppPreferences.SET_ACHIEVEMENTS, id);
    }

    public final int achievedCount() {
        return getP().unlockedCount(AppPreferences.SET_ACHIEVEMENTS);
    }

    public final void syncPassiveUnlocks() {
        syncCollection();
    }

    public final boolean isDailyAvailable(String today) {
        Intrinsics.checkNotNullParameter(today, "today");
        return !Intrinsics.areEqual(getP().getLastDailyDate(), today);
    }

    public final void claimDaily(String today) {
        Intrinsics.checkNotNullParameter(today, "today");
        getP().setLastDailyDate(today);
        Iterator<BoosterType> it = BoosterType.getEntries().iterator();
        while (it.hasNext()) {
            getP().addBooster(it.next().getKey(), 1);
        }
    }

    public final LevelOutcome onLevelComplete(int levelId, int stars, int scoreGained, int bestCombo, boolean madeSpecial, boolean snowGoalCompleted) {
        getP().recordStars(levelId, stars);
        getP().setHighestUnlockedLevel(levelId + 1);
        getP().addCounter(AppPreferences.STAT_TOTAL_SCORE, scoreGained);
        getP().recordMax(AppPreferences.STAT_BEST_COMBO, bestCombo);
        long jCounter = getP().counter(AppPreferences.STAT_STREAK) + 1;
        getP().setCounter(AppPreferences.STAT_STREAK, jCounter);
        getP().recordMax(AppPreferences.STAT_BEST_STREAK, jCounter);
        ArrayList arrayList = new ArrayList();
        onLevelComplete$tryAch(arrayList, "first_ride");
        if (stars >= 3) {
            onLevelComplete$tryAch(arrayList, "perfect_ride");
        }
        if (bestCombo >= 3) {
            onLevelComplete$tryAch(arrayList, "snow_combo");
        }
        if (madeSpecial) {
            onLevelComplete$tryAch(arrayList, "triple_match");
        }
        if (snowGoalCompleted) {
            onLevelComplete$tryAch(arrayList, "clean_route");
        }
        if (levelId >= Levels.INSTANCE.getCount()) {
            onLevelComplete$tryAch(arrayList, "blizzard_champion");
        }
        if (completedCount() >= 18) {
            onLevelComplete$tryAch(arrayList, "peak_explorer");
        }
        List<CollectionItem> listSyncCollection = syncCollection();
        if (collectedCount() >= 8) {
            onLevelComplete$tryAch(arrayList, "gear_collector");
        }
        return new LevelOutcome(arrayList, listSyncCollection);
    }

    private static final void onLevelComplete$tryAch(ArrayList<AchievementDef> arrayList, String str) {
        AchievementDef achievementDefAchievement;
        if (!INSTANCE.getP().unlock(AppPreferences.SET_ACHIEVEMENTS, str) || (achievementDefAchievement = Catalog.INSTANCE.achievement(str)) == null) {
            return;
        }
        arrayList.add(achievementDefAchievement);
    }

    public final void onLevelFailed() {
        getP().setCounter(AppPreferences.STAT_STREAK, 0L);
    }

    public final void resetAll() {
        getP().clearAll();
    }

    private final List<CollectionItem> syncCollection() {
        int iCompletedCount = completedCount();
        ArrayList arrayList = new ArrayList();
        for (CollectionItem collectionItem : Catalog.INSTANCE.getCollection()) {
            if (collectionItem.getUnlockAtCompleted() <= iCompletedCount && getP().unlock(AppPreferences.SET_COLLECTION, collectionItem.getId())) {
                arrayList.add(collectionItem);
            }
        }
        return arrayList;
    }
}
