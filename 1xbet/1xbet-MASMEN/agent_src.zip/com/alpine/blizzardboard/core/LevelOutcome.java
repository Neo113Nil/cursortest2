package com.alpine.blizzardboard.core;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.catalog.AchievementDef;
import com.alpine.blizzardboard.domain.catalog.CollectionItem;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Progress.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B#\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003HÆ\u0003J)\u0010\u000e\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\n¨\u0006\u0016"}, d2 = {"Lcom/alpine/blizzardboard/core/LevelOutcome;", "", "newAchievements", "", "Lcom/alpine/blizzardboard/domain/catalog/AchievementDef;", "newCollectibles", "Lcom/alpine/blizzardboard/domain/catalog/CollectionItem;", "<init>", "(Ljava/util/List;Ljava/util/List;)V", "getNewAchievements", "()Ljava/util/List;", "getNewCollectibles", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class LevelOutcome {
    private final List<AchievementDef> newAchievements;
    private final List<CollectionItem> newCollectibles;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ LevelOutcome copy$default(LevelOutcome levelOutcome, List list, List list2, int i, Object obj) {
        if ((i & 1) != 0) {
            list = levelOutcome.newAchievements;
        }
        if ((i & 2) != 0) {
            list2 = levelOutcome.newCollectibles;
        }
        return levelOutcome.copy(list, list2);
    }

    public final List<AchievementDef> component1() {
        return this.newAchievements;
    }

    public final List<CollectionItem> component2() {
        return this.newCollectibles;
    }

    public final LevelOutcome copy(List<AchievementDef> newAchievements, List<CollectionItem> newCollectibles) {
        Intrinsics.checkNotNullParameter(newAchievements, "newAchievements");
        Intrinsics.checkNotNullParameter(newCollectibles, "newCollectibles");
        return new LevelOutcome(newAchievements, newCollectibles);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LevelOutcome)) {
            return false;
        }
        LevelOutcome levelOutcome = (LevelOutcome) other;
        return Intrinsics.areEqual(this.newAchievements, levelOutcome.newAchievements) && Intrinsics.areEqual(this.newCollectibles, levelOutcome.newCollectibles);
    }

    public int hashCode() {
        return (this.newAchievements.hashCode() * 31) + this.newCollectibles.hashCode();
    }

    public String toString() {
        return "LevelOutcome(newAchievements=" + this.newAchievements + ", newCollectibles=" + this.newCollectibles + ")";
    }

    public LevelOutcome(List<AchievementDef> newAchievements, List<CollectionItem> newCollectibles) {
        Intrinsics.checkNotNullParameter(newAchievements, "newAchievements");
        Intrinsics.checkNotNullParameter(newCollectibles, "newCollectibles");
        this.newAchievements = newAchievements;
        this.newCollectibles = newCollectibles;
    }

    public final List<AchievementDef> getNewAchievements() {
        return this.newAchievements;
    }

    public final List<CollectionItem> getNewCollectibles() {
        return this.newCollectibles;
    }
}
