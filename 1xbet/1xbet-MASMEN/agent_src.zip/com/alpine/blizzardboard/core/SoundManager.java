package com.alpine.blizzardboard.core;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.di.Container;
import java.util.HashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: SoundManager.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018J\u0018\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u00052\b\b\u0002\u0010\u001b\u001a\u00020\u001cJ\u0006\u0010\u001d\u001a\u00020\u0016J\u0006\u0010\u001e\u001a\u00020\u0016J\u0006\u0010\u001f\u001a\u00020\u0016J\u0006\u0010 \u001a\u00020\u0016J\u0006\u0010!\u001a\u00020\u0016J\u0006\u0010\"\u001a\u00020\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010\u000f\u001a\u001e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00110\u0010j\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0011`\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006#"}, d2 = {"Lcom/alpine/blizzardboard/core/SoundManager;", "", "<init>", "()V", "CLICK", "", "NOTIFY", "BACK", "SUCCESS", "LOSE", "COIN", "names", "", "pool", "Landroid/media/SoundPool;", "ids", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "ready", "", "init", "", "context", "Landroid/content/Context;", "play", "name", "volume", "", SoundManager.CLICK, "notifySound", "back", SoundManager.SUCCESS, SoundManager.LOSE, SoundManager.COIN, "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class SoundManager {
    private static SoundPool pool;
    private static boolean ready;
    public static final SoundManager INSTANCE = new SoundManager();
    public static final String CLICK = "click";
    public static final String NOTIFY = "notify";
    public static final String BACK = "button_back";
    public static final String SUCCESS = "success";
    public static final String LOSE = "lose";
    public static final String COIN = "coin";
    private static final List<String> names = CollectionsKt.listOf((Object[]) new String[]{CLICK, NOTIFY, BACK, SUCCESS, LOSE, COIN});
    private static final HashMap<String, Integer> ids = new HashMap<>();

    private SoundManager() {
    }

    public final void init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (ready) {
            return;
        }
        SoundPool soundPoolBuild = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).build();
        Context applicationContext = context.getApplicationContext();
        for (String str : names) {
            int identifier = applicationContext.getResources().getIdentifier(str, "raw", applicationContext.getPackageName());
            if (identifier != 0) {
                ids.put(str, Integer.valueOf(soundPoolBuild.load(applicationContext, identifier, 1)));
            }
        }
        pool = soundPoolBuild;
        ready = true;
    }

    public static /* synthetic */ void play$default(SoundManager soundManager, String str, float f, int i, Object obj) {
        if ((i & 2) != 0) {
            f = 1.0f;
        }
        soundManager.play(str, f);
    }

    public final void play(String name, float volume) {
        SoundPool soundPool;
        Integer num;
        Intrinsics.checkNotNullParameter(name, "name");
        if (!Container.INSTANCE.getPrefs().getSoundEnabled() || (soundPool = pool) == null || (num = ids.get(name)) == null) {
            return;
        }
        soundPool.play(num.intValue(), volume, volume, 1, 0, 1.0f);
    }

    public final void click() {
        play(CLICK, 0.85f);
    }

    public final void notifySound() {
        play$default(this, NOTIFY, 0.0f, 2, null);
    }

    public final void back() {
        play(BACK, 0.85f);
    }

    public final void success() {
        play$default(this, SUCCESS, 0.0f, 2, null);
    }

    public final void lose() {
        play$default(this, LOSE, 0.0f, 2, null);
    }

    public final void coin() {
        play(COIN, 0.9f);
    }
}
