package com.alpine.blizzardboard.domain.level;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Goal;
import com.alpine.blizzardboard.domain.model.GoalType;
import com.alpine.blizzardboard.domain.model.LevelConfig;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;

/* JADX INFO: compiled from: Levels.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\f\n\u0002\b\u0003\n\u0002\u0010\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b \n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J&\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH\u0002J\"\u0010\f\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\n\u0010\r\u001a\u00020\u000e\"\u00020\nH\u0002J\u0018\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0005H\u0002J\u0010\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0005H\u0002J\u0016\u0010\u0015\u001a\u00020\u00102\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u0016\u0010\u0016\u001a\u00020\u00102\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u0016\u0010\u0017\u001a\u00020\u00102\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u0010\u0010\u0018\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0005H\u0002J\u0010\u00109\u001a\u0004\u0018\u0001032\u0006\u0010:\u001a\u00020\u0005R\u0014\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010 \u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010!\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\"\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010$\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010%\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010&\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010'\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010(\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010)\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010*\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010+\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010,\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010-\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010.\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010/\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u00100\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u00101\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u00102\u001a\b\u0012\u0004\u0012\u0002030\u0007¢\u0006\b\n\u0000\u001a\u0004\b4\u00105R\u0011\u00106\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b7\u00108¨\u0006;"}, d2 = {"Lcom/alpine/blizzardboard/domain/level/Levels;", "", "<init>", "()V", "countLayers", "", "layout", "", "", "one", "", "two", "countChars", "chars", "", "collect", "Lcom/alpine/blizzardboard/domain/model/Goal;", "gem", "Lcom/alpine/blizzardboard/domain/model/GemType;", TypedValues.AttributesType.S_TARGET, "score", "snow", "ice", "rock", "flags", "L6", "L7", "L8", "L9", "L10", "L11", "L12", "L13", "L14", "L15", "L16", "L17", "L18", "L19", "L20", "L21", "L22", "L23", "L24", "L25", "L26", "L27", "L28", "L29", "L30", "all", "Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "getAll", "()Ljava/util/List;", "count", "getCount", "()I", "byId", "id", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Levels {
    public static final Levels INSTANCE;
    private static final List<String> L10;
    private static final List<String> L11;
    private static final List<String> L12;
    private static final List<String> L13;
    private static final List<String> L14;
    private static final List<String> L15;
    private static final List<String> L16;
    private static final List<String> L17;
    private static final List<String> L18;
    private static final List<String> L19;
    private static final List<String> L20;
    private static final List<String> L21;
    private static final List<String> L22;
    private static final List<String> L23;
    private static final List<String> L24;
    private static final List<String> L25;
    private static final List<String> L26;
    private static final List<String> L27;
    private static final List<String> L28;
    private static final List<String> L29;
    private static final List<String> L30;
    private static final List<String> L6;
    private static final List<String> L7;
    private static final List<String> L8;
    private static final List<String> L9;
    private static final List<LevelConfig> all;

    private Levels() {
    }

    private final int countLayers(List<String> layout, char one, char two) {
        int i = 0;
        for (String str : layout) {
            int length = str.length();
            for (int i2 = 0; i2 < length; i2++) {
                char cCharAt = str.charAt(i2);
                if (cCharAt == one) {
                    i++;
                }
                if (cCharAt == two) {
                    i += 2;
                }
            }
        }
        return i;
    }

    private final int countChars(List<String> layout, char... chars) {
        int i = 0;
        for (String str : layout) {
            int length = str.length();
            for (int i2 = 0; i2 < length; i2++) {
                if (ArraysKt.contains(chars, str.charAt(i2))) {
                    i++;
                }
            }
        }
        return i;
    }

    private final Goal collect(GemType gem, int target) {
        return new Goal(GoalType.COLLECT, target, gem);
    }

    private final Goal score(int target) {
        return new Goal(GoalType.REACH_SCORE, target, null, 4, null);
    }

    private final Goal snow(List<String> layout) {
        return new Goal(GoalType.CLEAR_SNOW, countLayers(layout, 'S', 'P'), null, 4, null);
    }

    private final Goal ice(List<String> layout) {
        return new Goal(GoalType.BREAK_ICE, countLayers(layout, 'I', 'J'), null, 4, null);
    }

    private final Goal rock(List<String> layout) {
        return new Goal(GoalType.BREAK_ROCK, countChars(layout, 'R', 'B'), null, 4, null);
    }

    private final Goal flags(int target) {
        return new Goal(GoalType.DELIVER_FLAG, target, GemType.FLAG);
    }

    static {
        Levels levels = new Levels();
        INSTANCE = levels;
        List<String> listListOf = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "........", "........", "..SSSS..", ".SSSSSS.", ".SSSSSS.", "..SSSS.."});
        L6 = listListOf;
        List<String> listListOf2 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "S......S", "SS....SS", "SS....SS", "SSS..SSS", "SSSSSSSS", "SSSSSSSS"});
        L7 = listListOf2;
        List<String> listListOf3 = CollectionsKt.listOf((Object[]) new String[]{"........", "...PP...", "..PSSP..", "..PSSP..", "..PSSP..", "..PSSP..", "...PP...", "........"});
        L8 = listListOf3;
        List<String> listListOf4 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "........", "SSSSSSSS", "SSSSSSSS", "SSSSSSSS", "SSSSSSSS", "SSSSSSSS"});
        L9 = listListOf4;
        List<String> listListOf5 = CollectionsKt.listOf((Object[]) new String[]{"S......S", "SS....SS", "........", "...SS...", "...SS...", "........", "SS....SS", "S......S"});
        L10 = listListOf5;
        List<String> listListOf6 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "..I..I..", "........", "........", "..I..I..", "........", "........"});
        L11 = listListOf6;
        List<String> listListOf7 = CollectionsKt.listOf((Object[]) new String[]{"........", ".I.II.I.", "........", "..J..J..", "..J..J..", "........", ".I.II.I.", "........"});
        L12 = listListOf7;
        List<String> listListOf8 = CollectionsKt.listOf((Object[]) new String[]{"I......I", "........", "..IIII..", "........", "........", "..IIII..", "........", "I......I"});
        L13 = listListOf8;
        List<String> listListOf9 = CollectionsKt.listOf((Object[]) new String[]{"........", "..SSSS..", ".SIIIIS.", ".SIIIIS.", ".SIIIIS.", ".SIIIIS.", "..SSSS..", "........"});
        L14 = listListOf9;
        List<String> listListOf10 = CollectionsKt.listOf((Object[]) new String[]{"J......J", ".J....J.", "..J..J..", "...JJ...", "...JJ...", "..J..J..", ".J....J.", "J......J"});
        L15 = listListOf10;
        List<String> listListOf11 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "........", "........", "........", "........", "R.R..R.R", "RRR..RRR"});
        L16 = listListOf11;
        List<String> listListOf12 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "........", "...BB...", "...BB...", "........", "R......R", "RR....RR"});
        L17 = listListOf12;
        List<String> listListOf13 = CollectionsKt.listOf((Object[]) new String[]{"........", "..SSSS..", "..SSSS..", "........", "........", "B......B", "R......R", "RRR..RRR"});
        L18 = listListOf13;
        List<String> listListOf14 = CollectionsKt.listOf((Object[]) new String[]{"........", "...II...", "...II...", "........", "........", "R.B..B.R", "R.R..R.R", "RRR..RRR"});
        L19 = listListOf14;
        List<String> listListOf15 = CollectionsKt.listOf((Object[]) new String[]{"##....##", "#......#", "........", "........", "........", "........", "#.R..R.#", "##RRRR##"});
        L20 = listListOf15;
        List<String> listListOf16 = CollectionsKt.listOf((Object[]) new String[]{"........", "........", "........", "........", "........", "........", "........", "........"});
        L21 = listListOf16;
        List<String> listListOf17 = CollectionsKt.listOf((Object[]) new String[]{"........", "..L..L..", "........", "........", "........", "........", "..L..L..", "........"});
        L22 = listListOf17;
        List<String> listListOf18 = CollectionsKt.listOf((Object[]) new String[]{"I......I", "........", "...LL...", "........", "........", "...LL...", "........", "I......I"});
        L23 = listListOf18;
        List<String> listListOf19 = CollectionsKt.listOf((Object[]) new String[]{"........", "..SSSS..", "..S..S..", "........", "........", "L......L", "R......R", "RRR..RRR"});
        L24 = listListOf19;
        List<String> listListOf20 = CollectionsKt.listOf((Object[]) new String[]{"L......L", ".L....L.", "..L..L..", "........", "........", "..L..L..", ".L....L.", "L......L"});
        L25 = listListOf20;
        List<String> listListOf21 = CollectionsKt.listOf((Object[]) new String[]{"##....##", "#.SSSS.#", "..SIIS..", "..SIIS..", "..SIIS..", "..SIIS..", "#.SSSS.#", "##....##"});
        L26 = listListOf21;
        List<String> listListOf22 = CollectionsKt.listOf((Object[]) new String[]{"........", "..L..L..", "........", "...BB...", "...BB...", "........", "R......R", "RRR..RRR"});
        L27 = listListOf22;
        List<String> listListOf23 = CollectionsKt.listOf((Object[]) new String[]{"###..###", "##....##", "#.SPPS.#", "..PSSP..", "..PSSP..", "#.SPPS.#", "##....##", "###..###"});
        L28 = listListOf23;
        List<String> listListOf24 = CollectionsKt.listOf((Object[]) new String[]{"J......J", ".L....L.", "..SIIS..", "..SIIS..", "..SIIS..", "..SIIS..", ".R....R.", "RRR..RRR"});
        L29 = listListOf24;
        List<String> listListOf25 = CollectionsKt.listOf((Object[]) new String[]{"###..###", "##.II.##", "#.IJJI.#", "..LJJL..", "..LJJL..", "#.IJJI.#", "##RRRR##", "###..###"});
        L30 = listListOf25;
        all = CollectionsKt.listOf((Object[]) new LevelConfig[]{new LevelConfig(1, 22, CollectionsKt.listOf(levels.collect(GemType.SNOWFLAKE, 10)), 5, 0, 0, null, "Swipe a gem onto a neighbor to line up three of a kind.", 112, null), new LevelConfig(2, 22, CollectionsKt.listOf(levels.collect(GemType.SNOWBOARD, 12)), 5, 0, 0, null, "Longer lines clear more gear at once — keep matching.", 112, null), new LevelConfig(3, 20, CollectionsKt.listOf(levels.score(2000)), 5, 0, 0, null, "Falling gems can chain. Chains score far more points.", 112, null), new LevelConfig(4, 24, CollectionsKt.listOf((Object[]) new Goal[]{levels.collect(GemType.HELMET, 12), levels.collect(GemType.GOGGLES, 12)}), 6, 0, 0, null, "Some runs ask for two kinds of gear at once.", 112, null), new LevelConfig(5, 18, CollectionsKt.listOf(levels.collect(GemType.SNOWFLAKE, 16)), 6, 0, 0, null, "Match four in a line to forge a Line power that sweeps a whole row.", 112, null), new LevelConfig(6, 22, CollectionsKt.listOf(levels.snow(listListOf)), 6, 0, 0, listListOf, "Clear the snow beneath the gems by matching right on top of it.", 48, null), new LevelConfig(7, 22, CollectionsKt.listOf((Object[]) new Goal[]{levels.snow(listListOf2), levels.collect(GemType.GLOVE, 10)}), 6, 0, 0, listListOf2, null, 176, null), new LevelConfig(8, 24, CollectionsKt.listOf(levels.snow(listListOf3)), 6, 0, 0, listListOf3, "Deep snow piles need two clears to melt away.", 48, null), new LevelConfig(9, 24, CollectionsKt.listOf(levels.snow(listListOf4)), 6, 0, 0, listListOf4, null, 176, null), new LevelConfig(10, 24, CollectionsKt.listOf((Object[]) new Goal[]{levels.snow(listListOf5), levels.score(4000)}), 6, 0, 0, listListOf5, null, 176, null), new LevelConfig(11, 22, CollectionsKt.listOf(levels.ice(listListOf6)), 6, 0, 0, listListOf6, "Ice cracks when you match on it or right next to it.", 48, null), new LevelConfig(12, 24, CollectionsKt.listOf(levels.ice(listListOf7)), 6, 0, 0, listListOf7, null, 176, null), new LevelConfig(13, 26, CollectionsKt.listOf((Object[]) new Goal[]{levels.ice(listListOf8), levels.collect(GemType.MEDAL, 10)}), 6, 0, 0, listListOf8, null, 176, null), new LevelConfig(14, 26, CollectionsKt.listOf((Object[]) new Goal[]{levels.ice(listListOf9), levels.snow(listListOf9)}), 6, 0, 0, listListOf9, null, 176, null), new LevelConfig(15, 24, CollectionsKt.listOf(levels.ice(listListOf10)), 7, 0, 0, listListOf10, null, 176, null), new LevelConfig(16, 22, CollectionsKt.listOf(levels.rock(listListOf11)), 6, 0, 0, listListOf11, "Rocks sit on the slope. Match beside them to break them apart.", 48, null), new LevelConfig(17, 24, CollectionsKt.listOf(levels.rock(listListOf12)), 6, 0, 0, listListOf12, "Thin barriers break in a single hit.", 48, null), new LevelConfig(18, 26, CollectionsKt.listOf((Object[]) new Goal[]{levels.rock(listListOf13), levels.snow(listListOf13)}), 6, 0, 0, listListOf13, null, 176, null), new LevelConfig(19, 28, CollectionsKt.listOf((Object[]) new Goal[]{levels.rock(listListOf14), levels.ice(listListOf14)}), 6, 0, 0, listListOf14, null, 176, null), new LevelConfig(20, 24, CollectionsKt.listOf(levels.rock(listListOf15)), 6, 0, 0, listListOf15, "The board is not always a full square — mind the gaps.", 48, null), new LevelConfig(21, 22, CollectionsKt.listOf(levels.flags(6)), 6, 0, 0, listListOf16, "Match the route flags to send them down the slope.", 48, null), new LevelConfig(22, 24, CollectionsKt.listOf(levels.flags(7)), 6, 0, 0, listListOf17, "Locked gear frees up when you match right beside it.", 48, null), new LevelConfig(23, 26, CollectionsKt.listOf((Object[]) new Goal[]{levels.flags(8), levels.ice(listListOf18)}), 6, 0, 0, listListOf18, null, 176, null), new LevelConfig(24, 28, CollectionsKt.listOf((Object[]) new Goal[]{levels.flags(8), levels.snow(listListOf19), levels.rock(listListOf19)}), 6, 0, 0, listListOf19, null, 176, null), new LevelConfig(25, 26, CollectionsKt.listOf(levels.collect(GemType.HELMET, 14)), 7, 0, 0, listListOf20, null, 176, null), new LevelConfig(26, 28, CollectionsKt.listOf((Object[]) new Goal[]{levels.snow(listListOf21), levels.ice(listListOf21)}), 7, 0, 0, listListOf21, null, 176, null), new LevelConfig(27, 28, CollectionsKt.listOf((Object[]) new Goal[]{levels.rock(listListOf22), levels.flags(8)}), 7, 0, 0, listListOf22, null, 176, null), new LevelConfig(28, 26, CollectionsKt.listOf((Object[]) new Goal[]{levels.snow(listListOf23), levels.score(9000)}), 7, 0, 0, listListOf23, null, 176, null), new LevelConfig(29, 30, CollectionsKt.listOf((Object[]) new Goal[]{levels.ice(listListOf24), levels.rock(listListOf24), levels.flags(6)}), 7, 0, 0, listListOf24, null, 176, null), new LevelConfig(30, 30, CollectionsKt.listOf((Object[]) new Goal[]{levels.ice(listListOf25), levels.rock(listListOf25), levels.collect(GemType.MEDAL, 12)}), 7, 0, 0, listListOf25, null, 176, null)});
    }

    public final List<LevelConfig> getAll() {
        return all;
    }

    public final int getCount() {
        return all.size();
    }

    public final LevelConfig byId(int id) {
        return (LevelConfig) CollectionsKt.getOrNull(all, id - 1);
    }
}
