package com.alpine.blizzardboard.domain.model;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Goal.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0007HÆ\u0003J)\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/alpine/blizzardboard/domain/model/Goal;", "", "type", "Lcom/alpine/blizzardboard/domain/model/GoalType;", TypedValues.AttributesType.S_TARGET, "", "gem", "Lcom/alpine/blizzardboard/domain/model/GemType;", "<init>", "(Lcom/alpine/blizzardboard/domain/model/GoalType;ILcom/alpine/blizzardboard/domain/model/GemType;)V", "getType", "()Lcom/alpine/blizzardboard/domain/model/GoalType;", "getTarget", "()I", "getGem", "()Lcom/alpine/blizzardboard/domain/model/GemType;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class Goal {
    private final GemType gem;
    private final int target;
    private final GoalType type;

    public static /* synthetic */ Goal copy$default(Goal goal, GoalType goalType, int i, GemType gemType, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            goalType = goal.type;
        }
        if ((i2 & 2) != 0) {
            i = goal.target;
        }
        if ((i2 & 4) != 0) {
            gemType = goal.gem;
        }
        return goal.copy(goalType, i, gemType);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final GoalType getType() {
        return this.type;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getTarget() {
        return this.target;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final GemType getGem() {
        return this.gem;
    }

    public final Goal copy(GoalType type, int target, GemType gem) {
        Intrinsics.checkNotNullParameter(type, "type");
        return new Goal(type, target, gem);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Goal)) {
            return false;
        }
        Goal goal = (Goal) other;
        return this.type == goal.type && this.target == goal.target && this.gem == goal.gem;
    }

    public int hashCode() {
        int iHashCode = ((this.type.hashCode() * 31) + Integer.hashCode(this.target)) * 31;
        GemType gemType = this.gem;
        return iHashCode + (gemType == null ? 0 : gemType.hashCode());
    }

    public String toString() {
        return "Goal(type=" + this.type + ", target=" + this.target + ", gem=" + this.gem + ")";
    }

    public Goal(GoalType type, int i, GemType gemType) {
        Intrinsics.checkNotNullParameter(type, "type");
        this.type = type;
        this.target = i;
        this.gem = gemType;
    }

    public /* synthetic */ Goal(GoalType goalType, int i, GemType gemType, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(goalType, i, (i2 & 4) != 0 ? null : gemType);
    }

    public final GoalType getType() {
        return this.type;
    }

    public final int getTarget() {
        return this.target;
    }

    public final GemType getGem() {
        return this.gem;
    }
}
