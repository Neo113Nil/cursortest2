package com.alpine.blizzardboard.domain.model;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: LevelConfig.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001Ba\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\u0010\b\u0002\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0006\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\u0011\u0010!\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0006HÆ\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\fHÆ\u0003Ji\u0010#\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u00062\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\u0010\b\u0002\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u00062\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\fHÆ\u0001J\u0013\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010'\u001a\u00020\u0003HÖ\u0001J\t\u0010(\u001a\u00020\fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0011R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0011R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0011R\u0019\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0013\u0010\r\u001a\u0004\u0018\u00010\f¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001a¨\u0006)"}, d2 = {"Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "", "id", "", "moves", "goals", "", "Lcom/alpine/blizzardboard/domain/model/Goal;", "gemVariety", "rows", "cols", "layout", "", "tutorial", "<init>", "(IILjava/util/List;IIILjava/util/List;Ljava/lang/String;)V", "getId", "()I", "getMoves", "getGoals", "()Ljava/util/List;", "getGemVariety", "getRows", "getCols", "getLayout", "getTutorial", "()Ljava/lang/String;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class LevelConfig {
    private final int cols;
    private final int gemVariety;
    private final List<Goal> goals;
    private final int id;
    private final List<String> layout;
    private final int moves;
    private final int rows;
    private final String tutorial;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ LevelConfig copy$default(LevelConfig levelConfig, int i, int i2, List list, int i3, int i4, int i5, List list2, String str, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i = levelConfig.id;
        }
        if ((i6 & 2) != 0) {
            i2 = levelConfig.moves;
        }
        if ((i6 & 4) != 0) {
            list = levelConfig.goals;
        }
        if ((i6 & 8) != 0) {
            i3 = levelConfig.gemVariety;
        }
        if ((i6 & 16) != 0) {
            i4 = levelConfig.rows;
        }
        if ((i6 & 32) != 0) {
            i5 = levelConfig.cols;
        }
        if ((i6 & 64) != 0) {
            list2 = levelConfig.layout;
        }
        if ((i6 & 128) != 0) {
            str = levelConfig.tutorial;
        }
        List list3 = list2;
        String str2 = str;
        int i7 = i4;
        int i8 = i5;
        return levelConfig.copy(i, i2, list, i3, i7, i8, list3, str2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getMoves() {
        return this.moves;
    }

    public final List<Goal> component3() {
        return this.goals;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getGemVariety() {
        return this.gemVariety;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getRows() {
        return this.rows;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getCols() {
        return this.cols;
    }

    public final List<String> component7() {
        return this.layout;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final String getTutorial() {
        return this.tutorial;
    }

    public final LevelConfig copy(int id, int moves, List<Goal> goals, int gemVariety, int rows, int cols, List<String> layout, String tutorial) {
        Intrinsics.checkNotNullParameter(goals, "goals");
        return new LevelConfig(id, moves, goals, gemVariety, rows, cols, layout, tutorial);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LevelConfig)) {
            return false;
        }
        LevelConfig levelConfig = (LevelConfig) other;
        return this.id == levelConfig.id && this.moves == levelConfig.moves && Intrinsics.areEqual(this.goals, levelConfig.goals) && this.gemVariety == levelConfig.gemVariety && this.rows == levelConfig.rows && this.cols == levelConfig.cols && Intrinsics.areEqual(this.layout, levelConfig.layout) && Intrinsics.areEqual(this.tutorial, levelConfig.tutorial);
    }

    public int hashCode() {
        int iHashCode = ((((((((((Integer.hashCode(this.id) * 31) + Integer.hashCode(this.moves)) * 31) + this.goals.hashCode()) * 31) + Integer.hashCode(this.gemVariety)) * 31) + Integer.hashCode(this.rows)) * 31) + Integer.hashCode(this.cols)) * 31;
        List<String> list = this.layout;
        int iHashCode2 = (iHashCode + (list == null ? 0 : list.hashCode())) * 31;
        String str = this.tutorial;
        return iHashCode2 + (str != null ? str.hashCode() : 0);
    }

    public String toString() {
        return "LevelConfig(id=" + this.id + ", moves=" + this.moves + ", goals=" + this.goals + ", gemVariety=" + this.gemVariety + ", rows=" + this.rows + ", cols=" + this.cols + ", layout=" + this.layout + ", tutorial=" + this.tutorial + ")";
    }

    public LevelConfig(int i, int i2, List<Goal> goals, int i3, int i4, int i5, List<String> list, String str) {
        Intrinsics.checkNotNullParameter(goals, "goals");
        this.id = i;
        this.moves = i2;
        this.goals = goals;
        this.gemVariety = i3;
        this.rows = i4;
        this.cols = i5;
        this.layout = list;
        this.tutorial = str;
        if (4 > i3 || i3 >= 8) {
            throw new IllegalArgumentException(("gemVariety out of range in level " + i).toString());
        }
        if (list != null) {
            if (list.size() != i4) {
                throw new IllegalArgumentException(("layout row count in level " + i).toString());
            }
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                if (((String) it.next()).length() != this.cols) {
                    throw new IllegalArgumentException(("layout col count in level " + this.id).toString());
                }
            }
        }
    }

    public /* synthetic */ LevelConfig(int i, int i2, List list, int i3, int i4, int i5, List list2, String str, int i6, DefaultConstructorMarker defaultConstructorMarker) {
        this(i, i2, list, (i6 & 8) != 0 ? 6 : i3, (i6 & 16) != 0 ? 8 : i4, (i6 & 32) != 0 ? 8 : i5, (i6 & 64) != 0 ? null : list2, (i6 & 128) != 0 ? null : str);
    }

    public final int getId() {
        return this.id;
    }

    public final int getMoves() {
        return this.moves;
    }

    public final List<Goal> getGoals() {
        return this.goals;
    }

    public final int getGemVariety() {
        return this.gemVariety;
    }

    public final int getRows() {
        return this.rows;
    }

    public final int getCols() {
        return this.cols;
    }

    public final List<String> getLayout() {
        return this.layout;
    }

    public final String getTutorial() {
        return this.tutorial;
    }
}
