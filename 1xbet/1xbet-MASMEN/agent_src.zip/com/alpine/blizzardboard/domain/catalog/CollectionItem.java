package com.alpine.blizzardboard.domain.catalog;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Catalog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\bHÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001a\u001a\u00020\bHÖ\u0001J\t\u0010\u001b\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001c"}, d2 = {"Lcom/alpine/blizzardboard/domain/catalog/CollectionItem;", "", "id", "", "category", "Lcom/alpine/blizzardboard/domain/catalog/CollectionCategory;", "name", "unlockAtCompleted", "", "<init>", "(Ljava/lang/String;Lcom/alpine/blizzardboard/domain/catalog/CollectionCategory;Ljava/lang/String;I)V", "getId", "()Ljava/lang/String;", "getCategory", "()Lcom/alpine/blizzardboard/domain/catalog/CollectionCategory;", "getName", "getUnlockAtCompleted", "()I", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class CollectionItem {
    private final CollectionCategory category;
    private final String id;
    private final String name;
    private final int unlockAtCompleted;

    public static /* synthetic */ CollectionItem copy$default(CollectionItem collectionItem, String str, CollectionCategory collectionCategory, String str2, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = collectionItem.id;
        }
        if ((i2 & 2) != 0) {
            collectionCategory = collectionItem.category;
        }
        if ((i2 & 4) != 0) {
            str2 = collectionItem.name;
        }
        if ((i2 & 8) != 0) {
            i = collectionItem.unlockAtCompleted;
        }
        return collectionItem.copy(str, collectionCategory, str2, i);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final CollectionCategory getCategory() {
        return this.category;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }

    public final CollectionItem copy(String id, CollectionCategory category, String name, int unlockAtCompleted) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(category, "category");
        Intrinsics.checkNotNullParameter(name, "name");
        return new CollectionItem(id, category, name, unlockAtCompleted);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CollectionItem)) {
            return false;
        }
        CollectionItem collectionItem = (CollectionItem) other;
        return Intrinsics.areEqual(this.id, collectionItem.id) && this.category == collectionItem.category && Intrinsics.areEqual(this.name, collectionItem.name) && this.unlockAtCompleted == collectionItem.unlockAtCompleted;
    }

    public int hashCode() {
        return (((((this.id.hashCode() * 31) + this.category.hashCode()) * 31) + this.name.hashCode()) * 31) + Integer.hashCode(this.unlockAtCompleted);
    }

    public String toString() {
        return "CollectionItem(id=" + this.id + ", category=" + this.category + ", name=" + this.name + ", unlockAtCompleted=" + this.unlockAtCompleted + ")";
    }

    public CollectionItem(String id, CollectionCategory category, String name, int i) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(category, "category");
        Intrinsics.checkNotNullParameter(name, "name");
        this.id = id;
        this.category = category;
        this.name = name;
        this.unlockAtCompleted = i;
    }

    public final String getId() {
        return this.id;
    }

    public final CollectionCategory getCategory() {
        return this.category;
    }

    public final String getName() {
        return this.name;
    }

    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }
}
