package com.alpine.blizzardboard.domain.catalog;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Catalog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u000bHÆ\u0003JO\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u000bHÆ\u0001J\u0013\u0010 \u001a\u00020!2\b\u0010\"\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010#\u001a\u00020\u0003HÖ\u0001J\t\u0010$\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000fR\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000fR\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017¨\u0006%"}, d2 = {"Lcom/alpine/blizzardboard/domain/catalog/RouteInfo;", "", "id", "", "name", "", "subtitle", "firstLevel", "lastLevel", "unlockAtCompleted", "tint", "", "<init>", "(ILjava/lang/String;Ljava/lang/String;IIIJ)V", "getId", "()I", "getName", "()Ljava/lang/String;", "getSubtitle", "getFirstLevel", "getLastLevel", "getUnlockAtCompleted", "getTint", "()J", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class RouteInfo {
    private final int firstLevel;
    private final int id;
    private final int lastLevel;
    private final String name;
    private final String subtitle;
    private final long tint;
    private final int unlockAtCompleted;

    public static /* synthetic */ RouteInfo copy$default(RouteInfo routeInfo, int i, String str, String str2, int i2, int i3, int i4, long j, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            i = routeInfo.id;
        }
        if ((i5 & 2) != 0) {
            str = routeInfo.name;
        }
        if ((i5 & 4) != 0) {
            str2 = routeInfo.subtitle;
        }
        if ((i5 & 8) != 0) {
            i2 = routeInfo.firstLevel;
        }
        if ((i5 & 16) != 0) {
            i3 = routeInfo.lastLevel;
        }
        if ((i5 & 32) != 0) {
            i4 = routeInfo.unlockAtCompleted;
        }
        if ((i5 & 64) != 0) {
            j = routeInfo.tint;
        }
        long j2 = j;
        int i6 = i3;
        int i7 = i4;
        return routeInfo.copy(i, str, str2, i2, i6, i7, j2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getSubtitle() {
        return this.subtitle;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getFirstLevel() {
        return this.firstLevel;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getLastLevel() {
        return this.lastLevel;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final long getTint() {
        return this.tint;
    }

    public final RouteInfo copy(int id, String name, String subtitle, int firstLevel, int lastLevel, int unlockAtCompleted, long tint) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        return new RouteInfo(id, name, subtitle, firstLevel, lastLevel, unlockAtCompleted, tint);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RouteInfo)) {
            return false;
        }
        RouteInfo routeInfo = (RouteInfo) other;
        return this.id == routeInfo.id && Intrinsics.areEqual(this.name, routeInfo.name) && Intrinsics.areEqual(this.subtitle, routeInfo.subtitle) && this.firstLevel == routeInfo.firstLevel && this.lastLevel == routeInfo.lastLevel && this.unlockAtCompleted == routeInfo.unlockAtCompleted && this.tint == routeInfo.tint;
    }

    public int hashCode() {
        return (((((((((((Integer.hashCode(this.id) * 31) + this.name.hashCode()) * 31) + this.subtitle.hashCode()) * 31) + Integer.hashCode(this.firstLevel)) * 31) + Integer.hashCode(this.lastLevel)) * 31) + Integer.hashCode(this.unlockAtCompleted)) * 31) + Long.hashCode(this.tint);
    }

    public String toString() {
        return "RouteInfo(id=" + this.id + ", name=" + this.name + ", subtitle=" + this.subtitle + ", firstLevel=" + this.firstLevel + ", lastLevel=" + this.lastLevel + ", unlockAtCompleted=" + this.unlockAtCompleted + ", tint=" + this.tint + ")";
    }

    public RouteInfo(int i, String name, String subtitle, int i2, int i3, int i4, long j) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        this.id = i;
        this.name = name;
        this.subtitle = subtitle;
        this.firstLevel = i2;
        this.lastLevel = i3;
        this.unlockAtCompleted = i4;
        this.tint = j;
    }

    public final int getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getSubtitle() {
        return this.subtitle;
    }

    public final int getFirstLevel() {
        return this.firstLevel;
    }

    public final int getLastLevel() {
        return this.lastLevel;
    }

    public final int getUnlockAtCompleted() {
        return this.unlockAtCompleted;
    }

    public final long getTint() {
        return this.tint;
    }
}
