package com.alpine.blizzardboard.domain.catalog;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Catalog.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u000bJ\u0010\u0010\u000f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u0010\u001a\u00020\u0011R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\bR\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\bR\u0011\u0010\u0015\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017¨\u0006\u0018"}, d2 = {"Lcom/alpine/blizzardboard/domain/catalog/Catalog;", "", "<init>", "()V", "routes", "", "Lcom/alpine/blizzardboard/domain/catalog/RouteInfo;", "getRoutes", "()Ljava/util/List;", "routeForLevel", "levelId", "", "achievements", "Lcom/alpine/blizzardboard/domain/catalog/AchievementDef;", "getAchievements", "achievement", "id", "", "collection", "Lcom/alpine/blizzardboard/domain/catalog/CollectionItem;", "getCollection", "collectionCount", "getCollectionCount", "()I", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Catalog {
    public static final Catalog INSTANCE = new Catalog();
    private static final List<RouteInfo> routes = CollectionsKt.listOf((Object[]) new RouteInfo[]{new RouteInfo(0, "Snow Start", "Gentle beginner slopes", 1, 6, 0, 1429451627), new RouteInfo(1, "Frost Valley", "Fresh powder and long runs", 7, 12, 6, 1431814655), new RouteInfo(2, "Ice Ridge", "Frozen tracks and hard ice", 13, 18, 12, 1429110712), new RouteInfo(3, "Aurora Peak", "Night lights over the peak", 19, 24, 18, 1436838911), new RouteInfo(4, "Blizzard Summit", "The storm at the very top", 25, 30, 24, 1442810428)});
    private static final List<AchievementDef> achievements = CollectionsKt.listOf((Object[]) new AchievementDef[]{new AchievementDef("first_ride", "First Ride", "Finish your first level."), new AchievementDef("snow_combo", "Snow Combo", "Trigger a chain of three cascades."), new AchievementDef("triple_match", "Triple Match", "Forge your first power gem from a big match."), new AchievementDef("peak_explorer", "Peak Explorer", "Reach the Aurora Peak route."), new AchievementDef("gear_collector", "Gear Collector", "Unlock eight pieces of gear."), new AchievementDef("clean_route", "Clean Route", "Sweep every snow tile on a level."), new AchievementDef("perfect_ride", "Perfect Ride", "Finish a level with three stars."), new AchievementDef("blizzard_champion", "Blizzard Champion", "Complete the final summit level.")});
    private static final List<CollectionItem> collection = CollectionsKt.listOf((Object[]) new CollectionItem[]{new CollectionItem("board_powder", CollectionCategory.SNOWBOARDS, "Powder Cruiser", 0), new CollectionItem("board_frost", CollectionCategory.SNOWBOARDS, "Frost Carver", 6), new CollectionItem("board_aurora", CollectionCategory.SNOWBOARDS, "Aurora Edge", 18), new CollectionItem("helmet_ridge", CollectionCategory.HELMETS, "Ridge Guard", 2), new CollectionItem("helmet_summit", CollectionCategory.HELMETS, "Summit Shell", 12), new CollectionItem("helmet_glacier", CollectionCategory.HELMETS, "Glacier Dome", 24), new CollectionItem("goggles_clear", CollectionCategory.GOGGLES, "Clear Sky", 4), new CollectionItem("goggles_storm", CollectionCategory.GOGGLES, "Storm Lens", 14), new CollectionItem("goggles_night", CollectionCategory.GOGGLES, "Nightfall Optic", 22), new CollectionItem("jacket_slope", CollectionCategory.JACKETS, "Slope Shell", 3), new CollectionItem("jacket_parka", CollectionCategory.JACKETS, "Blizzard Parka", 10), new CollectionItem("jacket_aurora", CollectionCategory.JACKETS, "Aurora Coat", 20), new CollectionItem("flag_snow", CollectionCategory.FLAGS, "Snow Start Pennant", 1), new CollectionItem("flag_frost", CollectionCategory.FLAGS, "Frost Valley Banner", 8), new CollectionItem("flag_ice", CollectionCategory.FLAGS, "Ice Ridge Marker", 16), new CollectionItem("flag_peak", CollectionCategory.FLAGS, "Aurora Peak Flag", 26), new CollectionItem("flag_summit", CollectionCategory.FLAGS, "Summit Crown Flag", 29)});

    private Catalog() {
    }

    public final List<RouteInfo> getRoutes() {
        return routes;
    }

    public final RouteInfo routeForLevel(int levelId) {
        Object next;
        Iterator<T> it = routes.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            RouteInfo routeInfo = (RouteInfo) next;
            int firstLevel = routeInfo.getFirstLevel();
            if (levelId <= routeInfo.getLastLevel() && firstLevel <= levelId) {
                break;
            }
        }
        RouteInfo routeInfo2 = (RouteInfo) next;
        return routeInfo2 == null ? (RouteInfo) CollectionsKt.first((List) routes) : routeInfo2;
    }

    public final List<AchievementDef> getAchievements() {
        return achievements;
    }

    public final AchievementDef achievement(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = achievements.iterator();
        while (it.hasNext()) {
            next = it.next();
            if (Intrinsics.areEqual(((AchievementDef) next).getId(), id)) {
                return (AchievementDef) next;
            }
        }
        next = null;
        return (AchievementDef) next;
    }

    public final List<CollectionItem> getCollection() {
        return collection;
    }

    public final int getCollectionCount() {
        return collection.size();
    }
}
