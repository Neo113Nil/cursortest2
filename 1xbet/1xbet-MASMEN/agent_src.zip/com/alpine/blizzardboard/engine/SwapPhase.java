package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0015\u001a\u00020\bHÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00062\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019HÖ\u0003J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001J\t\u0010\u001c\u001a\u00020\u001dHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0007\u001a\u00020\bX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001e"}, d2 = {"Lcom/alpine/blizzardboard/engine/SwapPhase;", "Lcom/alpine/blizzardboard/engine/Phase;", "a", "Lcom/alpine/blizzardboard/engine/Pos;", "b", "revert", "", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "<init>", "(Lcom/alpine/blizzardboard/engine/Pos;Lcom/alpine/blizzardboard/engine/Pos;ZLcom/alpine/blizzardboard/engine/HudState;)V", "getA", "()Lcom/alpine/blizzardboard/engine/Pos;", "getB", "getRevert", "()Z", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "component1", "component2", "component3", "component4", "copy", "equals", "other", "", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class SwapPhase implements Phase {
    private final Pos a;
    private final Pos b;
    private final HudState hud;
    private final boolean revert;

    public static /* synthetic */ SwapPhase copy$default(SwapPhase swapPhase, Pos pos, Pos pos2, boolean z, HudState hudState, int i, Object obj) {
        if ((i & 1) != 0) {
            pos = swapPhase.a;
        }
        if ((i & 2) != 0) {
            pos2 = swapPhase.b;
        }
        if ((i & 4) != 0) {
            z = swapPhase.revert;
        }
        if ((i & 8) != 0) {
            hudState = swapPhase.hud;
        }
        return swapPhase.copy(pos, pos2, z, hudState);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Pos getA() {
        return this.a;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Pos getB() {
        return this.b;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getRevert() {
        return this.revert;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final HudState getHud() {
        return this.hud;
    }

    public final SwapPhase copy(Pos a, Pos b, boolean revert, HudState hud) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        Intrinsics.checkNotNullParameter(hud, "hud");
        return new SwapPhase(a, b, revert, hud);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SwapPhase)) {
            return false;
        }
        SwapPhase swapPhase = (SwapPhase) other;
        return Intrinsics.areEqual(this.a, swapPhase.a) && Intrinsics.areEqual(this.b, swapPhase.b) && this.revert == swapPhase.revert && Intrinsics.areEqual(this.hud, swapPhase.hud);
    }

    public int hashCode() {
        return (((((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + Boolean.hashCode(this.revert)) * 31) + this.hud.hashCode();
    }

    public String toString() {
        return "SwapPhase(a=" + this.a + ", b=" + this.b + ", revert=" + this.revert + ", hud=" + this.hud + ")";
    }

    public SwapPhase(Pos a, Pos b, boolean z, HudState hud) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        Intrinsics.checkNotNullParameter(hud, "hud");
        this.a = a;
        this.b = b;
        this.revert = z;
        this.hud = hud;
    }

    public final Pos getA() {
        return this.a;
    }

    public final Pos getB() {
        return this.b;
    }

    public final boolean getRevert() {
        return this.revert;
    }

    @Override // com.alpine.blizzardboard.engine.Phase
    public HudState getHud() {
        return this.hud;
    }
}
