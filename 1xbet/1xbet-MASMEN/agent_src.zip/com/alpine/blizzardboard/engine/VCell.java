package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Blocker;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Special;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001BI\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\n¢\u0006\u0004\b\u000f\u0010\u0010J\u000b\u0010\u001e\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0007HÆ\u0003J\t\u0010!\u001a\u00020\u0007HÆ\u0003J\t\u0010\"\u001a\u00020\nHÆ\u0003J\t\u0010#\u001a\u00020\fHÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\t\u0010%\u001a\u00020\nHÆ\u0003J[\u0010&\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\nHÆ\u0001J\u0013\u0010'\u001a\u00020\n2\b\u0010(\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010)\u001a\u00020\u0007HÖ\u0001J\t\u0010*\u001a\u00020+HÖ\u0001R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0016R\u0011\u0010\u000e\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019¨\u0006,"}, d2 = {"Lcom/alpine/blizzardboard/engine/VCell;", "", "type", "Lcom/alpine/blizzardboard/domain/model/GemType;", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "snow", "", "ice", "locked", "", "blocker", "Lcom/alpine/blizzardboard/domain/model/Blocker;", "blockerHp", "open", "<init>", "(Lcom/alpine/blizzardboard/domain/model/GemType;Lcom/alpine/blizzardboard/domain/model/Special;IIZLcom/alpine/blizzardboard/domain/model/Blocker;IZ)V", "getType", "()Lcom/alpine/blizzardboard/domain/model/GemType;", "getSpecial", "()Lcom/alpine/blizzardboard/domain/model/Special;", "getSnow", "()I", "getIce", "getLocked", "()Z", "getBlocker", "()Lcom/alpine/blizzardboard/domain/model/Blocker;", "getBlockerHp", "getOpen", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class VCell {
    private final Blocker blocker;
    private final int blockerHp;
    private final int ice;
    private final boolean locked;
    private final boolean open;
    private final int snow;
    private final Special special;
    private final GemType type;

    public static /* synthetic */ VCell copy$default(VCell vCell, GemType gemType, Special special, int i, int i2, boolean z, Blocker blocker, int i3, boolean z2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            gemType = vCell.type;
        }
        if ((i4 & 2) != 0) {
            special = vCell.special;
        }
        if ((i4 & 4) != 0) {
            i = vCell.snow;
        }
        if ((i4 & 8) != 0) {
            i2 = vCell.ice;
        }
        if ((i4 & 16) != 0) {
            z = vCell.locked;
        }
        if ((i4 & 32) != 0) {
            blocker = vCell.blocker;
        }
        if ((i4 & 64) != 0) {
            i3 = vCell.blockerHp;
        }
        if ((i4 & 128) != 0) {
            z2 = vCell.open;
        }
        int i5 = i3;
        boolean z3 = z2;
        boolean z4 = z;
        Blocker blocker2 = blocker;
        return vCell.copy(gemType, special, i, i2, z4, blocker2, i5, z3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final GemType getType() {
        return this.type;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Special getSpecial() {
        return this.special;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getSnow() {
        return this.snow;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getIce() {
        return this.ice;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final boolean getLocked() {
        return this.locked;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final Blocker getBlocker() {
        return this.blocker;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final int getBlockerHp() {
        return this.blockerHp;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final boolean getOpen() {
        return this.open;
    }

    public final VCell copy(GemType type, Special special, int snow, int ice, boolean locked, Blocker blocker, int blockerHp, boolean open) {
        Intrinsics.checkNotNullParameter(special, "special");
        Intrinsics.checkNotNullParameter(blocker, "blocker");
        return new VCell(type, special, snow, ice, locked, blocker, blockerHp, open);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof VCell)) {
            return false;
        }
        VCell vCell = (VCell) other;
        return this.type == vCell.type && this.special == vCell.special && this.snow == vCell.snow && this.ice == vCell.ice && this.locked == vCell.locked && this.blocker == vCell.blocker && this.blockerHp == vCell.blockerHp && this.open == vCell.open;
    }

    public int hashCode() {
        GemType gemType = this.type;
        return ((((((((((((((gemType == null ? 0 : gemType.hashCode()) * 31) + this.special.hashCode()) * 31) + Integer.hashCode(this.snow)) * 31) + Integer.hashCode(this.ice)) * 31) + Boolean.hashCode(this.locked)) * 31) + this.blocker.hashCode()) * 31) + Integer.hashCode(this.blockerHp)) * 31) + Boolean.hashCode(this.open);
    }

    public String toString() {
        return "VCell(type=" + this.type + ", special=" + this.special + ", snow=" + this.snow + ", ice=" + this.ice + ", locked=" + this.locked + ", blocker=" + this.blocker + ", blockerHp=" + this.blockerHp + ", open=" + this.open + ")";
    }

    public VCell(GemType gemType, Special special, int i, int i2, boolean z, Blocker blocker, int i3, boolean z2) {
        Intrinsics.checkNotNullParameter(special, "special");
        Intrinsics.checkNotNullParameter(blocker, "blocker");
        this.type = gemType;
        this.special = special;
        this.snow = i;
        this.ice = i2;
        this.locked = z;
        this.blocker = blocker;
        this.blockerHp = i3;
        this.open = z2;
    }

    public final GemType getType() {
        return this.type;
    }

    public final Special getSpecial() {
        return this.special;
    }

    public final int getSnow() {
        return this.snow;
    }

    public final int getIce() {
        return this.ice;
    }

    public final boolean getLocked() {
        return this.locked;
    }

    public final Blocker getBlocker() {
        return this.blocker;
    }

    public final int getBlockerHp() {
        return this.blockerHp;
    }

    public final boolean getOpen() {
        return this.open;
    }
}
