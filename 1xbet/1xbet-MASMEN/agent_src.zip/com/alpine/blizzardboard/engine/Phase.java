package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005\u0082\u0001\u0006\u0006\u0007\b\t\n\u000b¨\u0006\fÀ\u0006\u0003"}, d2 = {"Lcom/alpine/blizzardboard/engine/Phase;", "", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "Lcom/alpine/blizzardboard/engine/ClearPhase;", "Lcom/alpine/blizzardboard/engine/FallPhase;", "Lcom/alpine/blizzardboard/engine/ResultPhase;", "Lcom/alpine/blizzardboard/engine/ShufflePhase;", "Lcom/alpine/blizzardboard/engine/StatePhase;", "Lcom/alpine/blizzardboard/engine/SwapPhase;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public interface Phase {
    HudState getHud();
}
