package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Blocker;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Special;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.ArrayDeque;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: Board.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010#\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\u0016\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003J\u000e\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u001bJ\u0016\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003J\u0016\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003J\u000e\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020\u001bJ\u0018\u0010\u001f\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003J\b\u0010 \u001a\u00020\u0007H\u0002J\u0016\u0010!\u001a\u00020\"2\u000e\u0010#\u001a\n\u0012\u0004\u0012\u00020$\u0018\u00010\u0006J\u0006\u0010%\u001a\u00020\"J\f\u0010&\u001a\b\u0012\u0004\u0012\u00020'0\u0006J\u001a\u0010(\u001a\b\u0012\u0004\u0012\u00020\u001b0)2\f\u0010*\u001a\b\u0012\u0004\u0012\u00020'0\u0006J*\u0010+\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020-0,2\f\u0010*\u001a\b\u0012\u0004\u0012\u00020'0\u00062\b\u0010.\u001a\u0004\u0018\u00010\u001bJ$\u0010/\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u00100\u001a\u00020-2\u0006\u00101\u001a\u00020\u0007JD\u00102\u001a\u00020\"2\f\u00103\u001a\b\u0012\u0004\u0012\u00020\u001b0)2\f\u00104\u001a\b\u0012\u0004\u0012\u00020\u001b0)2\f\u00105\u001a\b\u0012\u0004\u0012\u00020\u001b062\u0012\u00107\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00070,J\u0014\u00108\u001a\u0002092\f\u0010:\u001a\b\u0012\u0004\u0012\u00020\u001b0)J\u001e\u0010;\u001a\u001a\u0012\n\u0012\b\u0012\u0004\u0012\u00020=0\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020>0\u00060<J\u0016\u0010?\u001a\u00020\"2\u0006\u0010@\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020\u001bJ\u0018\u0010B\u001a\u00020\u001d2\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003H\u0002J\u0018\u0010C\u001a\u00020\u001d2\u0006\u0010@\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020\u001bH\u0002J\u0014\u0010D\u001a\u0010\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b\u0018\u00010<J\u0006\u0010E\u001a\u00020\u001dJ\u0006\u0010F\u001a\u00020\"J\u0014\u0010G\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010\u001a\u001a\u00020\u001bJ\f\u0010H\u001a\b\u0012\u0004\u0012\u00020\u001b0\u0006J\u0014\u0010I\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010J\u001a\u00020\u0007J\u0014\u0010K\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010\u0018\u001a\u00020\u0003J\u0014\u0010L\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010\u0019\u001a\u00020\u0003J\u001c\u0010M\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00062\u0006\u0010N\u001a\u00020\u001b2\u0006\u0010O\u001a\u00020\u0003J\u0006\u0010P\u001a\u00020\u0007J\u0017\u0010Q\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020R0\u00120\u0012¢\u0006\u0002\u0010SR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001f\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\u0012¢\u0006\n\n\u0002\u0010\u0016\u001a\u0004\b\u0014\u0010\u0015¨\u0006T"}, d2 = {"Lcom/alpine/blizzardboard/engine/Board;", "", "rows", "", "cols", "activeTypes", "", "Lcom/alpine/blizzardboard/domain/model/GemType;", "rng", "Lkotlin/random/Random;", "<init>", "(IILjava/util/List;Lkotlin/random/Random;)V", "getRows", "()I", "getCols", "getActiveTypes", "()Ljava/util/List;", "cells", "", "Lcom/alpine/blizzardboard/engine/Cell;", "getCells", "()[[Lcom/alpine/blizzardboard/engine/Cell;", "[[Lcom/alpine/blizzardboard/engine/Cell;", "cell", "r", "c", "p", "Lcom/alpine/blizzardboard/engine/Pos;", "inBounds", "", "movable", "typeAt", "randomType", "applyLayout", "", "layout", "", "fillInitialNoMatch", "findRuns", "Lcom/alpine/blizzardboard/engine/Run;", "matchedCells", "", "runs", "decideSpecials", "", "Lcom/alpine/blizzardboard/domain/model/Special;", "swapCell", "specialEffectCells", "kind", TypedValues.AttributesType.S_TARGET, "expandClears", "seeds", "excluded", "out", "", "powerTargets", "applyClears", "Lcom/alpine/blizzardboard/engine/ClearInfo;", "clearSet", "gravity", "Lkotlin/Pair;", "Lcom/alpine/blizzardboard/engine/GemMove;", "Lcom/alpine/blizzardboard/engine/GemSpawn;", "swapGems", "a", "b", "swappable", "swapMakesMatch", "findHint", "anyMove", "shuffle", "orthogonal", "allGemCells", "cellsOfType", "t", "rowCells", "colCells", "areaCells", "center", "radius", "mostFrequentType", "snapshot", "Lcom/alpine/blizzardboard/engine/VCell;", "()[[Lcom/alpine/blizzardboard/engine/VCell;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Board {
    private final List<GemType> activeTypes;
    private final Cell[][] cells;
    private final int cols;
    private final Random rng;
    private final int rows;

    /* JADX INFO: compiled from: Board.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Special.values().length];
            try {
                iArr[Special.LINE_H.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Special.LINE_V.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Special.BOMB.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Special.POWER.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[Special.NONE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Board(int i, int i2, List<? extends GemType> activeTypes, Random rng) {
        Intrinsics.checkNotNullParameter(activeTypes, "activeTypes");
        Intrinsics.checkNotNullParameter(rng, "rng");
        this.rows = i;
        this.cols = i2;
        this.activeTypes = activeTypes;
        this.rng = rng;
        Cell[][] cellArr = new Cell[i][];
        for (int i3 = 0; i3 < i; i3++) {
            int i4 = this.cols;
            Cell[] cellArr2 = new Cell[i4];
            for (int i5 = 0; i5 < i4; i5++) {
                cellArr2[i5] = new Cell();
            }
            cellArr[i3] = cellArr2;
        }
        this.cells = cellArr;
    }

    public final int getRows() {
        return this.rows;
    }

    public final int getCols() {
        return this.cols;
    }

    public final List<GemType> getActiveTypes() {
        return this.activeTypes;
    }

    public final Cell[][] getCells() {
        return this.cells;
    }

    public final Cell cell(int r, int c) {
        return this.cells[r][c];
    }

    public final Cell cell(Pos p) {
        Intrinsics.checkNotNullParameter(p, "p");
        return this.cells[p.getR()][p.getC()];
    }

    public final boolean inBounds(int r, int c) {
        return r >= 0 && r < this.rows && c >= 0 && c < this.cols;
    }

    public final boolean movable(int r, int c) {
        return inBounds(r, c) && this.cells[r][c].getMovable();
    }

    public final boolean movable(Pos p) {
        Intrinsics.checkNotNullParameter(p, "p");
        return movable(p.getR(), p.getC());
    }

    public final GemType typeAt(int r, int c) {
        Gem gem;
        if (inBounds(r, c) && this.cells[r][c].getMovable() && (gem = this.cells[r][c].getGem()) != null) {
            return gem.getType();
        }
        return null;
    }

    private final GemType randomType() {
        List<GemType> list = this.activeTypes;
        return list.get(this.rng.nextInt(list.size()));
    }

    public final void applyLayout(List<String> layout) {
        if (layout == null) {
            return;
        }
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                Cell cell = this.cells[i2][i4];
                char cCharAt = layout.get(i2).charAt(i4);
                if (cCharAt == '#') {
                    cell.setOpen(false);
                } else if (cCharAt == 'B') {
                    cell.setBlocker(Blocker.BARRIER);
                    cell.setBlockerHp(1);
                } else if (cCharAt == 'L') {
                    cell.setLocked(true);
                } else if (cCharAt == 'P') {
                    cell.setSnow(2);
                } else if (cCharAt == 'I') {
                    cell.setIce(1);
                } else if (cCharAt == 'J') {
                    cell.setIce(2);
                } else if (cCharAt == 'R') {
                    cell.setBlocker(Blocker.ROCK);
                    cell.setBlockerHp(2);
                } else if (cCharAt == 'S') {
                    cell.setSnow(1);
                }
            }
        }
    }

    public final void fillInitialNoMatch() {
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                Cell cell = this.cells[i2][i4];
                if (cell.getMovable()) {
                    HashSet hashSet = new HashSet();
                    int i5 = i4 - 1;
                    if (typeAt(i2, i5) != null && typeAt(i2, i5) == typeAt(i2, i4 - 2)) {
                        GemType gemTypeTypeAt = typeAt(i2, i5);
                        Intrinsics.checkNotNull(gemTypeTypeAt);
                        hashSet.add(gemTypeTypeAt);
                    }
                    int i6 = i2 - 1;
                    if (typeAt(i6, i4) != null && typeAt(i6, i4) == typeAt(i2 - 2, i4)) {
                        GemType gemTypeTypeAt2 = typeAt(i6, i4);
                        Intrinsics.checkNotNull(gemTypeTypeAt2);
                        hashSet.add(gemTypeTypeAt2);
                    }
                    List<GemType> list = this.activeTypes;
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : list) {
                        if (!hashSet.contains((GemType) obj)) {
                            arrayList.add(obj);
                        }
                    }
                    ArrayList arrayList2 = arrayList;
                    if (arrayList2.isEmpty()) {
                        arrayList2 = this.activeTypes;
                    }
                    cell.setGem(new Gem((GemType) arrayList2.get(this.rng.nextInt(arrayList2.size())), null, 2, null));
                }
            }
        }
    }

    public final List<Run> findRuns() {
        int i;
        int i2;
        ArrayList arrayList = new ArrayList();
        int i3 = this.rows;
        for (int i4 = 0; i4 < i3; i4++) {
            int i5 = 0;
            while (i5 < this.cols) {
                GemType gemTypeTypeAt = typeAt(i4, i5);
                if (gemTypeTypeAt == null) {
                    i5++;
                } else {
                    int i6 = i5;
                    while (true) {
                        i2 = i6 + 1;
                        if (i2 >= this.cols || typeAt(i4, i2) != gemTypeTypeAt) {
                            break;
                        }
                        i6 = i2;
                    }
                    if ((i6 - i5) + 1 >= 3) {
                        IntRange intRange = new IntRange(i5, i6);
                        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange, 10));
                        Iterator<Integer> it = intRange.iterator();
                        while (it.hasNext()) {
                            arrayList2.add(new Pos(i4, ((IntIterator) it).nextInt()));
                        }
                        arrayList.add(new Run(arrayList2, true));
                    }
                    i5 = i2;
                }
            }
        }
        int i7 = this.cols;
        for (int i8 = 0; i8 < i7; i8++) {
            int i9 = 0;
            while (i9 < this.rows) {
                GemType gemTypeTypeAt2 = typeAt(i9, i8);
                if (gemTypeTypeAt2 == null) {
                    i9++;
                } else {
                    int i10 = i9;
                    while (true) {
                        i = i10 + 1;
                        if (i >= this.rows || typeAt(i, i8) != gemTypeTypeAt2) {
                            break;
                        }
                        i10 = i;
                    }
                    if ((i10 - i9) + 1 >= 3) {
                        IntRange intRange2 = new IntRange(i9, i10);
                        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange2, 10));
                        Iterator<Integer> it2 = intRange2.iterator();
                        while (it2.hasNext()) {
                            arrayList3.add(new Pos(((IntIterator) it2).nextInt(), i8));
                        }
                        arrayList.add(new Run(arrayList3, false));
                    }
                    i9 = i;
                }
            }
        }
        return arrayList;
    }

    public final Set<Pos> matchedCells(List<Run> runs) {
        Intrinsics.checkNotNullParameter(runs, "runs");
        HashSet hashSet = new HashSet();
        Iterator<Run> it = runs.iterator();
        while (it.hasNext()) {
            hashSet.addAll(it.next().getCells());
        }
        return hashSet;
    }

    public final Map<Pos, Special> decideSpecials(List<Run> runs, Pos swapCell) {
        GemType gemTypeTypeAt;
        Integer numValueOf;
        Special special;
        Run run;
        Pos pos;
        Intrinsics.checkNotNullParameter(runs, "runs");
        if (runs.isEmpty()) {
            return MapsKt.emptyMap();
        }
        Set<Pos> setMatchedCells = matchedCells(runs);
        HashSet hashSet = new HashSet();
        HashMap map = new HashMap();
        for (Pos pos2 : setMatchedCells) {
            if (!hashSet.contains(pos2) && (gemTypeTypeAt = typeAt(pos2.getR(), pos2.getC())) != null) {
                HashSet hashSet2 = new HashSet();
                ArrayDeque arrayDeque = new ArrayDeque();
                arrayDeque.add(pos2);
                hashSet.add(pos2);
                hashSet2.add(pos2);
                while (!arrayDeque.isEmpty()) {
                    for (Pos pos3 : orthogonal((Pos) arrayDeque.removeFirst())) {
                        if (setMatchedCells.contains(pos3) && !hashSet.contains(pos3) && typeAt(pos3.getR(), pos3.getC()) == gemTypeTypeAt) {
                            hashSet.add(pos3);
                            hashSet2.add(pos3);
                            arrayDeque.add(pos3);
                        }
                    }
                }
                List<Run> list = runs;
                ArrayList arrayList = new ArrayList();
                for (Object obj : list) {
                    Run run2 = (Run) obj;
                    if (run2.getHorizontal() && hashSet2.containsAll(run2.getCells())) {
                        arrayList.add(obj);
                    }
                }
                ArrayList arrayList2 = arrayList;
                ArrayList arrayList3 = new ArrayList();
                for (Object obj2 : list) {
                    Run run3 = (Run) obj2;
                    if (!run3.getHorizontal() && hashSet2.containsAll(run3.getCells())) {
                        arrayList3.add(obj2);
                    }
                }
                ArrayList arrayList4 = arrayList3;
                List listPlus = CollectionsKt.plus((Collection) arrayList2, (Iterable) arrayList4);
                Iterator it = listPlus.iterator();
                Object next = null;
                if (it.hasNext()) {
                    numValueOf = Integer.valueOf(((Run) it.next()).getCells().size());
                    while (it.hasNext()) {
                        Integer numValueOf2 = Integer.valueOf(((Run) it.next()).getCells().size());
                        if (numValueOf.compareTo(numValueOf2) < 0) {
                            numValueOf = numValueOf2;
                        }
                    }
                } else {
                    numValueOf = null;
                }
                Integer num = numValueOf;
                int iIntValue = num != null ? num.intValue() : 0;
                HashSet hashSet3 = new HashSet();
                Iterator it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                    hashSet3.addAll(((Run) it2.next()).getCells());
                }
                HashSet hashSet4 = new HashSet();
                Iterator it3 = arrayList4.iterator();
                while (it3.hasNext()) {
                    hashSet4.addAll(((Run) it3.next()).getCells());
                }
                Set setIntersect = CollectionsKt.intersect(hashSet3, hashSet4);
                if (iIntValue >= 5) {
                    special = Special.POWER;
                } else if (!setIntersect.isEmpty()) {
                    special = Special.BOMB;
                } else if (iIntValue != 4) {
                    special = Special.NONE;
                } else {
                    Iterator it4 = listPlus.iterator();
                    do {
                        if (!it4.hasNext()) {
                            throw new NoSuchElementException("Collection contains no element matching the predicate.");
                        }
                        run = (Run) it4.next();
                    } while (run.getCells().size() != 4);
                    special = run.getHorizontal() ? Special.LINE_H : Special.LINE_V;
                }
                if (special != Special.NONE) {
                    if (swapCell != null && hashSet2.contains(swapCell)) {
                        pos = swapCell;
                    } else if (special != Special.BOMB || setIntersect.isEmpty()) {
                        Iterator it5 = listPlus.iterator();
                        if (it5.hasNext()) {
                            next = it5.next();
                            if (it5.hasNext()) {
                                int size = ((Run) next).getCells().size();
                                do {
                                    Object next2 = it5.next();
                                    int size2 = ((Run) next2).getCells().size();
                                    if (size < size2) {
                                        next = next2;
                                        size = size2;
                                    }
                                } while (it5.hasNext());
                            }
                        }
                        Intrinsics.checkNotNull(next);
                        Run run4 = (Run) next;
                        pos = run4.getCells().get(run4.getCells().size() / 2);
                    } else {
                        pos = (Pos) CollectionsKt.first(setIntersect);
                    }
                    map.put(pos, special);
                }
            }
        }
        return map;
    }

    public final List<Pos> specialEffectCells(Pos p, Special kind, GemType target) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(target, "target");
        ArrayList arrayList = new ArrayList();
        int i = WhenMappings.$EnumSwitchMapping$0[kind.ordinal()];
        int i2 = 0;
        if (i == 1) {
            int i3 = this.cols;
            while (i2 < i3) {
                if (movable(p.getR(), i2) && this.cells[p.getR()][i2].getGem() != null) {
                    arrayList.add(new Pos(p.getR(), i2));
                }
                i2++;
            }
        } else if (i == 2) {
            int i4 = this.rows;
            while (i2 < i4) {
                if (movable(i2, p.getC()) && this.cells[i2][p.getC()].getGem() != null) {
                    arrayList.add(new Pos(i2, p.getC()));
                }
                i2++;
            }
        } else if (i == 3) {
            for (int i5 = -1; i5 < 2; i5++) {
                for (int i6 = -1; i6 < 2; i6++) {
                    int r = p.getR() + i5;
                    int c = p.getC() + i6;
                    if (movable(r, c) && this.cells[r][c].getGem() != null) {
                        arrayList.add(new Pos(r, c));
                    }
                }
            }
        } else if (i == 4) {
            int i7 = this.rows;
            for (int i8 = 0; i8 < i7; i8++) {
                int i9 = this.cols;
                for (int i10 = 0; i10 < i9; i10++) {
                    if (movable(i8, i10)) {
                        Gem gem = this.cells[i8][i10].getGem();
                        if ((gem != null ? gem.getType() : null) == target) {
                            arrayList.add(new Pos(i8, i10));
                        }
                    }
                }
            }
        } else if (i != 5) {
            throw new NoWhenBranchMatchedException();
        }
        return arrayList;
    }

    public final void expandClears(Set<Pos> seeds, Set<Pos> excluded, Set<Pos> out, Map<Pos, ? extends GemType> powerTargets) {
        Intrinsics.checkNotNullParameter(seeds, "seeds");
        Intrinsics.checkNotNullParameter(excluded, "excluded");
        Intrinsics.checkNotNullParameter(out, "out");
        Intrinsics.checkNotNullParameter(powerTargets, "powerTargets");
        ArrayDeque arrayDeque = new ArrayDeque();
        for (Pos pos : seeds) {
            if (!excluded.contains(pos) && movable(pos) && cell(pos).getGem() != null && out.add(pos)) {
                arrayDeque.add(pos);
            }
        }
        while (!arrayDeque.isEmpty()) {
            Pos pos2 = (Pos) arrayDeque.removeFirst();
            Gem gem = cell(pos2).getGem();
            if (gem != null && gem.getSpecial() != Special.NONE) {
                GemType type = powerTargets.get(pos2);
                if (type == null) {
                    type = gem.getType();
                }
                for (Pos pos3 : specialEffectCells(pos2, gem.getSpecial(), type)) {
                    if (!excluded.contains(pos3) && !out.contains(pos3) && movable(pos3) && cell(pos3).getGem() != null) {
                        out.add(pos3);
                        arrayDeque.add(pos3);
                    }
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x0186  */
    public final ClearInfo applyClears(Set<Pos> clearSet) {
        boolean z;
        Intrinsics.checkNotNullParameter(clearSet, "clearSet");
        HashMap map = new HashMap();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList();
        ArrayList arrayList6 = new ArrayList();
        int i = 0;
        for (Pos pos : clearSet) {
            Cell cell = this.cells[pos.getR()][pos.getC()];
            Gem gem = cell.getGem();
            if (gem != null) {
                HashMap map2 = map;
                GemType type = gem.getType();
                Integer num = (Integer) map.get(gem.getType());
                map2.put(type, Integer.valueOf((num != null ? num.intValue() : 0) + 1));
                if (gem.getType() == GemType.FLAG) {
                    arrayList6.add(pos);
                }
                cell.setGem(null);
            }
            if (cell.getSnow() > 0) {
                cell.setSnow(cell.getSnow() - 1);
                arrayList.add(pos);
                i++;
            }
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (Pos pos2 : clearSet) {
            linkedHashSet.add(pos2);
            Iterator<Pos> it = orthogonal(pos2).iterator();
            while (it.hasNext()) {
                linkedHashSet.add(it.next());
            }
        }
        Iterator it2 = linkedHashSet.iterator();
        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
        int i2 = 0;
        while (it2.hasNext()) {
            Object next = it2.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Pos pos3 = (Pos) next;
            Cell cell2 = this.cells[pos3.getR()][pos3.getC()];
            if (cell2.getIce() > 0) {
                cell2.setIce(cell2.getIce() - 1);
                arrayList2.add(pos3);
                i2++;
            }
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        for (Pos pos4 : clearSet) {
            linkedHashSet2.add(pos4);
            Iterator<Pos> it3 = orthogonal(pos4).iterator();
            while (it3.hasNext()) {
                linkedHashSet2.add(it3.next());
            }
        }
        Iterator it4 = linkedHashSet2.iterator();
        Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
        int i3 = 0;
        while (it4.hasNext()) {
            Object next2 = it4.next();
            Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
            Pos pos5 = (Pos) next2;
            Cell cell3 = this.cells[pos5.getR()][pos5.getC()];
            if (cell3.getBlocker() != Blocker.NONE) {
                cell3.setBlockerHp(cell3.getBlockerHp() - 1);
                arrayList3.add(pos5);
                if (cell3.getBlockerHp() <= 0) {
                    cell3.setBlocker(Blocker.NONE);
                    z = false;
                    cell3.setBlockerHp(0);
                    arrayList4.add(pos5);
                    i3++;
                } else {
                    z = false;
                }
            } else {
                z = false;
            }
            if (cell3.getLocked()) {
                cell3.setLocked(z);
                arrayList5.add(pos5);
            }
        }
        return new ClearInfo(map, arrayList, arrayList2, arrayList3, arrayList4, arrayList5, arrayList6, i, i2, i3);
    }

    public final Pair<List<GemMove>, List<GemSpawn>> gravity() {
        int i;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int i2 = this.cols;
        for (int i3 = 0; i3 < i2; i3++) {
            int i4 = this.rows - 1;
            while (i4 >= 0) {
                if (this.cells[i4][i3].getMovable()) {
                    int i5 = i4;
                    while (true) {
                        i = i5 - 1;
                        if (i < 0 || !this.cells[i][i3].getMovable()) {
                            break;
                        }
                        i5--;
                    }
                    int i6 = i4;
                    while (i4 >= i5) {
                        Gem gem = this.cells[i4][i3].getGem();
                        if (gem != null) {
                            if (i6 != i4) {
                                this.cells[i6][i3].setGem(gem);
                                this.cells[i4][i3].setGem(null);
                                arrayList.add(new GemMove(new Pos(i4, i3), new Pos(i6, i3)));
                            }
                            i6--;
                        }
                        i4--;
                    }
                    int i7 = (i6 - i5) + 1;
                    if (i7 > 0) {
                        while (i6 >= i5) {
                            GemType gemTypeRandomType = randomType();
                            this.cells[i6][i3].setGem(new Gem(gemTypeRandomType, null, 2, null));
                            arrayList2.add(new GemSpawn(new Pos(i6, i3), new GemView(gemTypeRandomType, Special.NONE), i7));
                            i6--;
                        }
                    }
                    i4 = i;
                } else {
                    i4--;
                }
            }
        }
        return new Pair<>(arrayList, arrayList2);
    }

    public final void swapGems(Pos a, Pos b) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        Gem gem = this.cells[a.getR()][a.getC()].getGem();
        this.cells[a.getR()][a.getC()].setGem(this.cells[b.getR()][b.getC()].getGem());
        this.cells[b.getR()][b.getC()].setGem(gem);
    }

    private final boolean swappable(int r, int c) {
        return inBounds(r, c) && this.cells[r][c].getMovable() && !this.cells[r][c].getLocked() && this.cells[r][c].getGem() != null;
    }

    private final boolean swapMakesMatch(Pos a, Pos b) {
        swapGems(a, b);
        boolean z = !findRuns().isEmpty();
        swapGems(a, b);
        return z;
    }

    public final Pair<Pos, Pos> findHint() {
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                if (swappable(i2, i4)) {
                    int i5 = i4 + 1;
                    if (swappable(i2, i5) && swapMakesMatch(new Pos(i2, i4), new Pos(i2, i5))) {
                        return TuplesKt.to(new Pos(i2, i4), new Pos(i2, i5));
                    }
                    int i6 = i2 + 1;
                    if (swappable(i6, i4) && swapMakesMatch(new Pos(i2, i4), new Pos(i6, i4))) {
                        return TuplesKt.to(new Pos(i2, i4), new Pos(i6, i4));
                    }
                }
            }
        }
        int i7 = this.rows;
        for (int i8 = 0; i8 < i7; i8++) {
            int i9 = this.cols;
            for (int i10 = 0; i10 < i9; i10++) {
                if (swappable(i8, i10)) {
                    Gem gem = this.cells[i8][i10].getGem();
                    if ((gem != null ? gem.getSpecial() : null) == Special.NONE) {
                        continue;
                    } else {
                        int i11 = i10 + 1;
                        if (swappable(i8, i11)) {
                            return TuplesKt.to(new Pos(i8, i10), new Pos(i8, i11));
                        }
                        int i12 = i8 + 1;
                        if (swappable(i12, i10)) {
                            return TuplesKt.to(new Pos(i8, i10), new Pos(i12, i10));
                        }
                        int i13 = i10 - 1;
                        if (swappable(i8, i13)) {
                            return TuplesKt.to(new Pos(i8, i10), new Pos(i8, i13));
                        }
                        int i14 = i8 - 1;
                        if (swappable(i14, i10)) {
                            return TuplesKt.to(new Pos(i8, i10), new Pos(i14, i10));
                        }
                    }
                }
            }
        }
        return null;
    }

    public final boolean anyMove() {
        return findHint() != null;
    }

    public final void shuffle() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                Cell cell = this.cells[i2][i4];
                if (cell.getMovable() && cell.getGem() != null && !cell.getLocked()) {
                    arrayList.add(new Pos(i2, i4));
                    Gem gem = cell.getGem();
                    Intrinsics.checkNotNull(gem);
                    arrayList2.add(gem);
                }
            }
        }
        if (arrayList.isEmpty()) {
            return;
        }
        int i5 = 0;
        do {
            CollectionsKt.shuffle(arrayList2, this.rng);
            int size = arrayList.size();
            for (int i6 = 0; i6 < size; i6++) {
                this.cells[((Pos) arrayList.get(i6)).getR()][((Pos) arrayList.get(i6)).getC()].setGem((Gem) arrayList2.get(i6));
            }
            i5++;
            if (findRuns().isEmpty() && anyMove()) {
                return;
            }
        } while (i5 < 40);
    }

    public final List<Pos> orthogonal(Pos p) {
        Intrinsics.checkNotNullParameter(p, "p");
        ArrayList arrayList = new ArrayList(4);
        if (inBounds(p.getR() - 1, p.getC())) {
            arrayList.add(new Pos(p.getR() - 1, p.getC()));
        }
        if (inBounds(p.getR() + 1, p.getC())) {
            arrayList.add(new Pos(p.getR() + 1, p.getC()));
        }
        if (inBounds(p.getR(), p.getC() - 1)) {
            arrayList.add(new Pos(p.getR(), p.getC() - 1));
        }
        if (inBounds(p.getR(), p.getC() + 1)) {
            arrayList.add(new Pos(p.getR(), p.getC() + 1));
        }
        return arrayList;
    }

    public final List<Pos> allGemCells() {
        ArrayList arrayList = new ArrayList();
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                if (movable(i2, i4) && this.cells[i2][i4].getGem() != null) {
                    arrayList.add(new Pos(i2, i4));
                }
            }
        }
        return arrayList;
    }

    public final List<Pos> cellsOfType(GemType t) {
        Intrinsics.checkNotNullParameter(t, "t");
        ArrayList arrayList = new ArrayList();
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                if (movable(i2, i4)) {
                    Gem gem = this.cells[i2][i4].getGem();
                    if ((gem != null ? gem.getType() : null) == t) {
                        arrayList.add(new Pos(i2, i4));
                    }
                }
            }
        }
        return arrayList;
    }

    public final List<Pos> rowCells(int r) {
        IntRange intRangeUntil = RangesKt.until(0, this.cols);
        ArrayList arrayList = new ArrayList();
        Iterator<Integer> it = intRangeUntil.iterator();
        while (it.hasNext()) {
            int iNextInt = ((IntIterator) it).nextInt();
            Pos pos = (!movable(r, iNextInt) || this.cells[r][iNextInt].getGem() == null) ? null : new Pos(r, iNextInt);
            if (pos != null) {
                arrayList.add(pos);
            }
        }
        return arrayList;
    }

    public final List<Pos> colCells(int c) {
        IntRange intRangeUntil = RangesKt.until(0, this.rows);
        ArrayList arrayList = new ArrayList();
        Iterator<Integer> it = intRangeUntil.iterator();
        while (it.hasNext()) {
            int iNextInt = ((IntIterator) it).nextInt();
            Pos pos = (!movable(iNextInt, c) || this.cells[iNextInt][c].getGem() == null) ? null : new Pos(iNextInt, c);
            if (pos != null) {
                arrayList.add(pos);
            }
        }
        return arrayList;
    }

    public final List<Pos> areaCells(Pos center, int radius) {
        Intrinsics.checkNotNullParameter(center, "center");
        ArrayList arrayList = new ArrayList();
        int i = -radius;
        if (i <= radius) {
            int i2 = i;
            while (true) {
                if (i <= radius) {
                    int i3 = i;
                    while (true) {
                        int r = center.getR() + i2;
                        int c = center.getC() + i3;
                        if (movable(r, c) && this.cells[r][c].getGem() != null) {
                            arrayList.add(new Pos(r, c));
                        }
                        if (i3 == radius) {
                            break;
                        }
                        i3++;
                    }
                }
                if (i2 == radius) {
                    break;
                }
                i2++;
            }
        }
        return arrayList;
    }

    public final GemType mostFrequentType() {
        Object obj;
        GemType gemType;
        Gem gem;
        HashMap map = new HashMap();
        int i = this.rows;
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            for (int i4 = 0; i4 < i3; i4++) {
                if (movable(i2, i4) && (gem = this.cells[i2][i4].getGem()) != null) {
                    HashMap map2 = map;
                    GemType type = gem.getType();
                    Integer num = (Integer) map.get(gem.getType());
                    map2.put(type, Integer.valueOf((num != null ? num.intValue() : 0) + 1));
                }
            }
        }
        Iterator it = map.entrySet().iterator();
        if (it.hasNext()) {
            Object next = it.next();
            if (it.hasNext()) {
                int iIntValue = ((Number) ((Map.Entry) next).getValue()).intValue();
                do {
                    Object next2 = it.next();
                    int iIntValue2 = ((Number) ((Map.Entry) next2).getValue()).intValue();
                    if (iIntValue < iIntValue2) {
                        next = next2;
                        iIntValue = iIntValue2;
                    }
                } while (it.hasNext());
            }
            obj = next;
        } else {
            obj = null;
        }
        Map.Entry entry = (Map.Entry) obj;
        return (entry == null || (gemType = (GemType) entry.getKey()) == null) ? (GemType) CollectionsKt.first((List) this.activeTypes) : gemType;
    }

    public final VCell[][] snapshot() {
        Special special;
        int i = this.rows;
        VCell[][] vCellArr = new VCell[i][];
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = this.cols;
            VCell[] vCellArr2 = new VCell[i3];
            for (int i4 = 0; i4 < i3; i4++) {
                Cell cell = this.cells[i2][i4];
                Gem gem = cell.getGem();
                GemType type = gem != null ? gem.getType() : null;
                if (gem == null || (special = gem.getSpecial()) == null) {
                    special = Special.NONE;
                }
                vCellArr2[i4] = new VCell(type, special, cell.getSnow(), cell.getIce(), cell.getLocked(), cell.getBlocker(), cell.getBlockerHp(), cell.getOpen());
            }
            vCellArr[i2] = vCellArr2;
        }
        return vCellArr;
    }
}
