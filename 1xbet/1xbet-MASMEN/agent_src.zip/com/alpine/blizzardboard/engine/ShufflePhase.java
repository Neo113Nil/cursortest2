package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/alpine/blizzardboard/engine/ShufflePhase;", "Lcom/alpine/blizzardboard/engine/Phase;", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "<init>", "(Lcom/alpine/blizzardboard/engine/HudState;)V", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class ShufflePhase implements Phase {
    private final HudState hud;

    public static /* synthetic */ ShufflePhase copy$default(ShufflePhase shufflePhase, HudState hudState, int i, Object obj) {
        if ((i & 1) != 0) {
            hudState = shufflePhase.hud;
        }
        return shufflePhase.copy(hudState);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final HudState getHud() {
        return this.hud;
    }

    public final ShufflePhase copy(HudState hud) {
        Intrinsics.checkNotNullParameter(hud, "hud");
        return new ShufflePhase(hud);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof ShufflePhase) && Intrinsics.areEqual(this.hud, ((ShufflePhase) other).hud);
    }

    public int hashCode() {
        return this.hud.hashCode();
    }

    public String toString() {
        return "ShufflePhase(hud=" + this.hud + ")";
    }

    public ShufflePhase(HudState hud) {
        Intrinsics.checkNotNullParameter(hud, "hud");
        this.hud = hud;
    }

    @Override // com.alpine.blizzardboard.engine.Phase
    public HudState getHud() {
        return this.hud;
    }
}
