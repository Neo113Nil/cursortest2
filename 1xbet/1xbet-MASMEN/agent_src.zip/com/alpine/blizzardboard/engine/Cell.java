package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Blocker;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Cell.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001c\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0013\"\u0004\b\u0018\u0010\u0015R\u001a\u0010\u0019\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0007\"\u0004\b\u001b\u0010\tR\u001a\u0010\u001c\u001a\u00020\u001dX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\"\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0013\"\u0004\b$\u0010\u0015R\u0011\u0010%\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b&\u0010\u0007¨\u0006'"}, d2 = {"Lcom/alpine/blizzardboard/engine/Cell;", "", "<init>", "()V", "open", "", "getOpen", "()Z", "setOpen", "(Z)V", "gem", "Lcom/alpine/blizzardboard/engine/Gem;", "getGem", "()Lcom/alpine/blizzardboard/engine/Gem;", "setGem", "(Lcom/alpine/blizzardboard/engine/Gem;)V", "snow", "", "getSnow", "()I", "setSnow", "(I)V", "ice", "getIce", "setIce", "locked", "getLocked", "setLocked", "blocker", "Lcom/alpine/blizzardboard/domain/model/Blocker;", "getBlocker", "()Lcom/alpine/blizzardboard/domain/model/Blocker;", "setBlocker", "(Lcom/alpine/blizzardboard/domain/model/Blocker;)V", "blockerHp", "getBlockerHp", "setBlockerHp", "movable", "getMovable", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Cell {
    private int blockerHp;
    private Gem gem;
    private int ice;
    private boolean locked;
    private int snow;
    private boolean open = true;
    private Blocker blocker = Blocker.NONE;

    public final boolean getOpen() {
        return this.open;
    }

    public final void setOpen(boolean z) {
        this.open = z;
    }

    public final Gem getGem() {
        return this.gem;
    }

    public final void setGem(Gem gem) {
        this.gem = gem;
    }

    public final int getSnow() {
        return this.snow;
    }

    public final void setSnow(int i) {
        this.snow = i;
    }

    public final int getIce() {
        return this.ice;
    }

    public final void setIce(int i) {
        this.ice = i;
    }

    public final boolean getLocked() {
        return this.locked;
    }

    public final void setLocked(boolean z) {
        this.locked = z;
    }

    public final Blocker getBlocker() {
        return this.blocker;
    }

    public final void setBlocker(Blocker blocker) {
        Intrinsics.checkNotNullParameter(blocker, "<set-?>");
        this.blocker = blocker;
    }

    public final int getBlockerHp() {
        return this.blockerHp;
    }

    public final void setBlockerHp(int i) {
        this.blockerHp = i;
    }

    public final boolean getMovable() {
        return this.open && this.blocker == Blocker.NONE;
    }
}
