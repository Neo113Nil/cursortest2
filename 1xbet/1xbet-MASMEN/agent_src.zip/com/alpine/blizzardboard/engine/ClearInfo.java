package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.GemType;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Board.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b#\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0087\u0001\u0012\u0012\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0005\u0012\u0006\u0010\u000f\u001a\u00020\u0005\u0012\u0006\u0010\u0010\u001a\u00020\u0005¢\u0006\u0004\b\u0011\u0010\u0012J\u0015\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003HÆ\u0003J\u000f\u0010!\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010#\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010$\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010%\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\t\u0010'\u001a\u00020\u0005HÆ\u0003J\t\u0010(\u001a\u00020\u0005HÆ\u0003J\t\u0010)\u001a\u00020\u0005HÆ\u0003J\u009d\u0001\u0010*\u001a\u00020\u00002\u0014\b\u0002\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u00032\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u00052\b\b\u0002\u0010\u0010\u001a\u00020\u0005HÆ\u0001J\u0013\u0010+\u001a\u00020,2\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010.\u001a\u00020\u0005HÖ\u0001J\t\u0010/\u001a\u000200HÖ\u0001R\u001d\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0016R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0016R\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u000f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001dR\u0011\u0010\u0010\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001d¨\u00061"}, d2 = {"Lcom/alpine/blizzardboard/engine/ClearInfo;", "", "collected", "", "Lcom/alpine/blizzardboard/domain/model/GemType;", "", "snowHits", "", "Lcom/alpine/blizzardboard/engine/Pos;", "iceHits", "blockerHits", "blockerCleared", "unlocked", "flagsDelivered", "snowLayersRemoved", "iceLayersRemoved", "blockersRemoved", "<init>", "(Ljava/util/Map;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;III)V", "getCollected", "()Ljava/util/Map;", "getSnowHits", "()Ljava/util/List;", "getIceHits", "getBlockerHits", "getBlockerCleared", "getUnlocked", "getFlagsDelivered", "getSnowLayersRemoved", "()I", "getIceLayersRemoved", "getBlockersRemoved", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class ClearInfo {
    private final List<Pos> blockerCleared;
    private final List<Pos> blockerHits;
    private final int blockersRemoved;
    private final Map<GemType, Integer> collected;
    private final List<Pos> flagsDelivered;
    private final List<Pos> iceHits;
    private final int iceLayersRemoved;
    private final List<Pos> snowHits;
    private final int snowLayersRemoved;
    private final List<Pos> unlocked;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ ClearInfo copy$default(ClearInfo clearInfo, Map map, List list, List list2, List list3, List list4, List list5, List list6, int i, int i2, int i3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            map = clearInfo.collected;
        }
        if ((i4 & 2) != 0) {
            list = clearInfo.snowHits;
        }
        if ((i4 & 4) != 0) {
            list2 = clearInfo.iceHits;
        }
        if ((i4 & 8) != 0) {
            list3 = clearInfo.blockerHits;
        }
        if ((i4 & 16) != 0) {
            list4 = clearInfo.blockerCleared;
        }
        if ((i4 & 32) != 0) {
            list5 = clearInfo.unlocked;
        }
        if ((i4 & 64) != 0) {
            list6 = clearInfo.flagsDelivered;
        }
        if ((i4 & 128) != 0) {
            i = clearInfo.snowLayersRemoved;
        }
        if ((i4 & 256) != 0) {
            i2 = clearInfo.iceLayersRemoved;
        }
        if ((i4 & 512) != 0) {
            i3 = clearInfo.blockersRemoved;
        }
        int i5 = i2;
        int i6 = i3;
        List list7 = list6;
        int i7 = i;
        List list8 = list4;
        List list9 = list5;
        return clearInfo.copy(map, list, list2, list3, list8, list9, list7, i7, i5, i6);
    }

    public final Map<GemType, Integer> component1() {
        return this.collected;
    }

    /* JADX INFO: renamed from: component10, reason: from getter */
    public final int getBlockersRemoved() {
        return this.blockersRemoved;
    }

    public final List<Pos> component2() {
        return this.snowHits;
    }

    public final List<Pos> component3() {
        return this.iceHits;
    }

    public final List<Pos> component4() {
        return this.blockerHits;
    }

    public final List<Pos> component5() {
        return this.blockerCleared;
    }

    public final List<Pos> component6() {
        return this.unlocked;
    }

    public final List<Pos> component7() {
        return this.flagsDelivered;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final int getSnowLayersRemoved() {
        return this.snowLayersRemoved;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final int getIceLayersRemoved() {
        return this.iceLayersRemoved;
    }

    public final ClearInfo copy(Map<GemType, Integer> collected, List<Pos> snowHits, List<Pos> iceHits, List<Pos> blockerHits, List<Pos> blockerCleared, List<Pos> unlocked, List<Pos> flagsDelivered, int snowLayersRemoved, int iceLayersRemoved, int blockersRemoved) {
        Intrinsics.checkNotNullParameter(collected, "collected");
        Intrinsics.checkNotNullParameter(snowHits, "snowHits");
        Intrinsics.checkNotNullParameter(iceHits, "iceHits");
        Intrinsics.checkNotNullParameter(blockerHits, "blockerHits");
        Intrinsics.checkNotNullParameter(blockerCleared, "blockerCleared");
        Intrinsics.checkNotNullParameter(unlocked, "unlocked");
        Intrinsics.checkNotNullParameter(flagsDelivered, "flagsDelivered");
        return new ClearInfo(collected, snowHits, iceHits, blockerHits, blockerCleared, unlocked, flagsDelivered, snowLayersRemoved, iceLayersRemoved, blockersRemoved);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ClearInfo)) {
            return false;
        }
        ClearInfo clearInfo = (ClearInfo) other;
        return Intrinsics.areEqual(this.collected, clearInfo.collected) && Intrinsics.areEqual(this.snowHits, clearInfo.snowHits) && Intrinsics.areEqual(this.iceHits, clearInfo.iceHits) && Intrinsics.areEqual(this.blockerHits, clearInfo.blockerHits) && Intrinsics.areEqual(this.blockerCleared, clearInfo.blockerCleared) && Intrinsics.areEqual(this.unlocked, clearInfo.unlocked) && Intrinsics.areEqual(this.flagsDelivered, clearInfo.flagsDelivered) && this.snowLayersRemoved == clearInfo.snowLayersRemoved && this.iceLayersRemoved == clearInfo.iceLayersRemoved && this.blockersRemoved == clearInfo.blockersRemoved;
    }

    public int hashCode() {
        return (((((((((((((((((this.collected.hashCode() * 31) + this.snowHits.hashCode()) * 31) + this.iceHits.hashCode()) * 31) + this.blockerHits.hashCode()) * 31) + this.blockerCleared.hashCode()) * 31) + this.unlocked.hashCode()) * 31) + this.flagsDelivered.hashCode()) * 31) + Integer.hashCode(this.snowLayersRemoved)) * 31) + Integer.hashCode(this.iceLayersRemoved)) * 31) + Integer.hashCode(this.blockersRemoved);
    }

    public String toString() {
        return "ClearInfo(collected=" + this.collected + ", snowHits=" + this.snowHits + ", iceHits=" + this.iceHits + ", blockerHits=" + this.blockerHits + ", blockerCleared=" + this.blockerCleared + ", unlocked=" + this.unlocked + ", flagsDelivered=" + this.flagsDelivered + ", snowLayersRemoved=" + this.snowLayersRemoved + ", iceLayersRemoved=" + this.iceLayersRemoved + ", blockersRemoved=" + this.blockersRemoved + ")";
    }

    public ClearInfo(Map<GemType, Integer> collected, List<Pos> snowHits, List<Pos> iceHits, List<Pos> blockerHits, List<Pos> blockerCleared, List<Pos> unlocked, List<Pos> flagsDelivered, int i, int i2, int i3) {
        Intrinsics.checkNotNullParameter(collected, "collected");
        Intrinsics.checkNotNullParameter(snowHits, "snowHits");
        Intrinsics.checkNotNullParameter(iceHits, "iceHits");
        Intrinsics.checkNotNullParameter(blockerHits, "blockerHits");
        Intrinsics.checkNotNullParameter(blockerCleared, "blockerCleared");
        Intrinsics.checkNotNullParameter(unlocked, "unlocked");
        Intrinsics.checkNotNullParameter(flagsDelivered, "flagsDelivered");
        this.collected = collected;
        this.snowHits = snowHits;
        this.iceHits = iceHits;
        this.blockerHits = blockerHits;
        this.blockerCleared = blockerCleared;
        this.unlocked = unlocked;
        this.flagsDelivered = flagsDelivered;
        this.snowLayersRemoved = i;
        this.iceLayersRemoved = i2;
        this.blockersRemoved = i3;
    }

    public final Map<GemType, Integer> getCollected() {
        return this.collected;
    }

    public final List<Pos> getSnowHits() {
        return this.snowHits;
    }

    public final List<Pos> getIceHits() {
        return this.iceHits;
    }

    public final List<Pos> getBlockerHits() {
        return this.blockerHits;
    }

    public final List<Pos> getBlockerCleared() {
        return this.blockerCleared;
    }

    public final List<Pos> getUnlocked() {
        return this.unlocked;
    }

    public final List<Pos> getFlagsDelivered() {
        return this.flagsDelivered;
    }

    public final int getSnowLayersRemoved() {
        return this.snowLayersRemoved;
    }

    public final int getIceLayersRemoved() {
        return this.iceLayersRemoved;
    }

    public final int getBlockersRemoved() {
        return this.blockersRemoved;
    }
}
