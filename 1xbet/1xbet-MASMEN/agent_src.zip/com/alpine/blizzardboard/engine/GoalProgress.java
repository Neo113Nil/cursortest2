package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Goal;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0010\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00072\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, d2 = {"Lcom/alpine/blizzardboard/engine/GoalProgress;", "", "goal", "Lcom/alpine/blizzardboard/domain/model/Goal;", "current", "", "done", "", "<init>", "(Lcom/alpine/blizzardboard/domain/model/Goal;IZ)V", "getGoal", "()Lcom/alpine/blizzardboard/domain/model/Goal;", "getCurrent", "()I", "getDone", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class GoalProgress {
    private final int current;
    private final boolean done;
    private final Goal goal;

    public static /* synthetic */ GoalProgress copy$default(GoalProgress goalProgress, Goal goal, int i, boolean z, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            goal = goalProgress.goal;
        }
        if ((i2 & 2) != 0) {
            i = goalProgress.current;
        }
        if ((i2 & 4) != 0) {
            z = goalProgress.done;
        }
        return goalProgress.copy(goal, i, z);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Goal getGoal() {
        return this.goal;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getCurrent() {
        return this.current;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getDone() {
        return this.done;
    }

    public final GoalProgress copy(Goal goal, int current, boolean done) {
        Intrinsics.checkNotNullParameter(goal, "goal");
        return new GoalProgress(goal, current, done);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GoalProgress)) {
            return false;
        }
        GoalProgress goalProgress = (GoalProgress) other;
        return Intrinsics.areEqual(this.goal, goalProgress.goal) && this.current == goalProgress.current && this.done == goalProgress.done;
    }

    public int hashCode() {
        return (((this.goal.hashCode() * 31) + Integer.hashCode(this.current)) * 31) + Boolean.hashCode(this.done);
    }

    public String toString() {
        return "GoalProgress(goal=" + this.goal + ", current=" + this.current + ", done=" + this.done + ")";
    }

    public GoalProgress(Goal goal, int i, boolean z) {
        Intrinsics.checkNotNullParameter(goal, "goal");
        this.goal = goal;
        this.current = i;
        this.done = z;
    }

    public final int getCurrent() {
        return this.current;
    }

    public final boolean getDone() {
        return this.done;
    }

    public final Goal getGoal() {
        return this.goal;
    }
}
