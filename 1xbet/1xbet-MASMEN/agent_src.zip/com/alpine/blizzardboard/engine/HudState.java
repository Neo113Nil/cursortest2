package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0003J-\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0019"}, d2 = {"Lcom/alpine/blizzardboard/engine/HudState;", "", "score", "", "movesLeft", "goals", "", "Lcom/alpine/blizzardboard/engine/GoalProgress;", "<init>", "(IILjava/util/List;)V", "getScore", "()I", "getMovesLeft", "getGoals", "()Ljava/util/List;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class HudState {
    private final List<GoalProgress> goals;
    private final int movesLeft;
    private final int score;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ HudState copy$default(HudState hudState, int i, int i2, List list, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = hudState.score;
        }
        if ((i3 & 2) != 0) {
            i2 = hudState.movesLeft;
        }
        if ((i3 & 4) != 0) {
            list = hudState.goals;
        }
        return hudState.copy(i, i2, list);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getScore() {
        return this.score;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getMovesLeft() {
        return this.movesLeft;
    }

    public final List<GoalProgress> component3() {
        return this.goals;
    }

    public final HudState copy(int score, int movesLeft, List<GoalProgress> goals) {
        Intrinsics.checkNotNullParameter(goals, "goals");
        return new HudState(score, movesLeft, goals);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof HudState)) {
            return false;
        }
        HudState hudState = (HudState) other;
        return this.score == hudState.score && this.movesLeft == hudState.movesLeft && Intrinsics.areEqual(this.goals, hudState.goals);
    }

    public int hashCode() {
        return (((Integer.hashCode(this.score) * 31) + Integer.hashCode(this.movesLeft)) * 31) + this.goals.hashCode();
    }

    public String toString() {
        return "HudState(score=" + this.score + ", movesLeft=" + this.movesLeft + ", goals=" + this.goals + ")";
    }

    public HudState(int i, int i2, List<GoalProgress> goals) {
        Intrinsics.checkNotNullParameter(goals, "goals");
        this.score = i;
        this.movesLeft = i2;
        this.goals = goals;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getMovesLeft() {
        return this.movesLeft;
    }

    public final List<GoalProgress> getGoals() {
        return this.goals;
    }
}
