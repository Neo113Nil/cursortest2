package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Special;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0016"}, d2 = {"Lcom/alpine/blizzardboard/engine/GemView;", "", "type", "Lcom/alpine/blizzardboard/domain/model/GemType;", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "<init>", "(Lcom/alpine/blizzardboard/domain/model/GemType;Lcom/alpine/blizzardboard/domain/model/Special;)V", "getType", "()Lcom/alpine/blizzardboard/domain/model/GemType;", "getSpecial", "()Lcom/alpine/blizzardboard/domain/model/Special;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class GemView {
    private final Special special;
    private final GemType type;

    public static /* synthetic */ GemView copy$default(GemView gemView, GemType gemType, Special special, int i, Object obj) {
        if ((i & 1) != 0) {
            gemType = gemView.type;
        }
        if ((i & 2) != 0) {
            special = gemView.special;
        }
        return gemView.copy(gemType, special);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final GemType getType() {
        return this.type;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Special getSpecial() {
        return this.special;
    }

    public final GemView copy(GemType type, Special special) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(special, "special");
        return new GemView(type, special);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GemView)) {
            return false;
        }
        GemView gemView = (GemView) other;
        return this.type == gemView.type && this.special == gemView.special;
    }

    public int hashCode() {
        return (this.type.hashCode() * 31) + this.special.hashCode();
    }

    public String toString() {
        return "GemView(type=" + this.type + ", special=" + this.special + ")";
    }

    public GemView(GemType type, Special special) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(special, "special");
        this.type = type;
        this.special = special;
    }

    public final Special getSpecial() {
        return this.special;
    }

    public final GemType getType() {
        return this.type;
    }
}
