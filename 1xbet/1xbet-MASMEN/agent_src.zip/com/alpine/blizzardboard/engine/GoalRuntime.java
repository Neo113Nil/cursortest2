package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Goal;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: GameEngine.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013¨\u0006\u0014"}, d2 = {"Lcom/alpine/blizzardboard/engine/GoalRuntime;", "", "goal", "Lcom/alpine/blizzardboard/domain/model/Goal;", "<init>", "(Lcom/alpine/blizzardboard/domain/model/Goal;)V", "getGoal", "()Lcom/alpine/blizzardboard/domain/model/Goal;", "current", "", "getCurrent", "()I", "setCurrent", "(I)V", "done", "", "getDone", "()Z", "setDone", "(Z)V", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class GoalRuntime {
    private int current;
    private boolean done;
    private final Goal goal;

    public GoalRuntime(Goal goal) {
        Intrinsics.checkNotNullParameter(goal, "goal");
        this.goal = goal;
        this.done = goal.getTarget() <= 0;
    }

    public final Goal getGoal() {
        return this.goal;
    }

    public final int getCurrent() {
        return this.current;
    }

    public final void setCurrent(int i) {
        this.current = i;
    }

    public final boolean getDone() {
        return this.done;
    }

    public final void setDone(boolean z) {
        this.done = z;
    }
}
