package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Special;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Cell.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"Lcom/alpine/blizzardboard/engine/Gem;", "", "type", "Lcom/alpine/blizzardboard/domain/model/GemType;", "special", "Lcom/alpine/blizzardboard/domain/model/Special;", "<init>", "(Lcom/alpine/blizzardboard/domain/model/GemType;Lcom/alpine/blizzardboard/domain/model/Special;)V", "getType", "()Lcom/alpine/blizzardboard/domain/model/GemType;", "setType", "(Lcom/alpine/blizzardboard/domain/model/GemType;)V", "getSpecial", "()Lcom/alpine/blizzardboard/domain/model/Special;", "setSpecial", "(Lcom/alpine/blizzardboard/domain/model/Special;)V", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class Gem {
    private Special special;
    private GemType type;

    public Gem(GemType type, Special special) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(special, "special");
        this.type = type;
        this.special = special;
    }

    public /* synthetic */ Gem(GemType gemType, Special special, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(gemType, (i & 2) != 0 ? Special.NONE : special);
    }

    public final Special getSpecial() {
        return this.special;
    }

    public final GemType getType() {
        return this.type;
    }

    public final void setSpecial(Special special) {
        Intrinsics.checkNotNullParameter(special, "<set-?>");
        this.special = special;
    }

    public final void setType(GemType gemType) {
        Intrinsics.checkNotNullParameter(gemType, "<set-?>");
        this.type = gemType;
    }
}
