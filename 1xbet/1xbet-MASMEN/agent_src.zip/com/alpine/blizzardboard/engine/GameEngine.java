package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Blocker;
import com.alpine.blizzardboard.domain.model.GemType;
import com.alpine.blizzardboard.domain.model.Goal;
import com.alpine.blizzardboard.domain.model.GoalType;
import com.alpine.blizzardboard.domain.model.LevelConfig;
import com.alpine.blizzardboard.domain.model.Special;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.random.RandomKt;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: GameEngine.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000ª\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\"\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0016\u0010%\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\u0017\u0010&\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020(0'0'¢\u0006\u0002\u0010)J\u0006\u0010*\u001a\u00020+J\u0006\u0010,\u001a\u00020-J\u0006\u0010.\u001a\u00020-J\b\u0010/\u001a\u00020-H\u0002J\u0006\u00100\u001a\u00020\u0016J\u0014\u00101\u001a\u0010\u0012\u0004\u0012\u000203\u0012\u0004\u0012\u000203\u0018\u000102J\u001c\u00104\u001a\b\u0012\u0004\u0012\u0002050\r2\u0006\u00106\u001a\u0002032\u0006\u00107\u001a\u000203J\u0014\u00108\u001a\b\u0012\u0004\u0012\u0002050\r2\u0006\u00109\u001a\u00020\u0016J\f\u0010:\u001a\b\u0012\u0004\u0012\u0002050\rJ\u0014\u0010;\u001a\b\u0012\u0004\u0012\u0002050\r2\u0006\u0010<\u001a\u000203J\f\u0010=\u001a\b\u0012\u0004\u0012\u0002050\rJ\u0016\u0010>\u001a\b\u0012\u0004\u0012\u0002030?2\u0006\u0010@\u001a\u00020\u0016H\u0002J\"\u0010A\u001a\b\u0012\u0004\u0012\u0002030\r2\u0012\u0010B\u001a\u000e\u0012\u0004\u0012\u00020D\u0012\u0004\u0012\u00020-0CH\u0002J\u000e\u0010E\u001a\b\u0012\u0004\u0012\u0002030\rH\u0002JB\u0010F\u001a\u00020G2\f\u0010H\u001a\b\u0012\u0004\u0012\u0002030?2\u0012\u0010I\u001a\u000e\u0012\u0004\u0012\u000203\u0012\u0004\u0012\u00020\u000e0J2\b\u0010K\u001a\u0004\u0018\u0001032\f\u0010L\u001a\b\u0012\u0004\u0012\u0002050MH\u0002J\u0016\u0010N\u001a\u00020G2\f\u0010L\u001a\b\u0012\u0004\u0012\u0002050MH\u0002J.\u0010O\u001a\b\u0012\u0004\u0012\u0002030?2\u0006\u00106\u001a\u0002032\u0006\u00107\u001a\u0002032\u0006\u0010P\u001a\u00020Q2\u0006\u0010R\u001a\u00020QH\u0002J \u0010S\u001a\u00020\u00162\u0006\u0010T\u001a\u00020\u00162\u0006\u0010U\u001a\u00020\u00162\u0006\u0010V\u001a\u00020\u0016H\u0002J\u0010\u0010W\u001a\u00020G2\u0006\u0010X\u001a\u00020YH\u0002J\b\u0010Z\u001a\u00020GH\u0002J\u0018\u0010[\u001a\u00020-2\u0006\u00106\u001a\u0002032\u0006\u00107\u001a\u000203H\u0002R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u001e\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\u0016@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u001e\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\u0016@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u001e\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\u0016@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019R\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001f0\r¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0010R\u0011\u0010!\u001a\u00020\u00168F¢\u0006\u0006\u001a\u0004\b\"\u0010\u0019R\u0011\u0010#\u001a\u00020\u00168F¢\u0006\u0006\u001a\u0004\b$\u0010\u0019¨\u0006\\"}, d2 = {"Lcom/alpine/blizzardboard/engine/GameEngine;", "", "config", "Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "seed", "", "<init>", "(Lcom/alpine/blizzardboard/domain/model/LevelConfig;J)V", "getConfig", "()Lcom/alpine/blizzardboard/domain/model/LevelConfig;", "rng", "Lkotlin/random/Random;", "activeTypes", "", "Lcom/alpine/blizzardboard/domain/model/GemType;", "getActiveTypes", "()Ljava/util/List;", "board", "Lcom/alpine/blizzardboard/engine/Board;", "getBoard", "()Lcom/alpine/blizzardboard/engine/Board;", "value", "", "score", "getScore", "()I", "movesLeft", "getMovesLeft", "bestCombo", "getBestCombo", "goals", "Lcom/alpine/blizzardboard/engine/GoalRuntime;", "getGoals", "levelId", "getLevelId", "totalMoves", "getTotalMoves", "computeActiveTypes", "snapshot", "", "Lcom/alpine/blizzardboard/engine/VCell;", "()[[Lcom/alpine/blizzardboard/engine/VCell;", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "isComplete", "", "isFailed", "isOver", "starsEarned", "hint", "Lkotlin/Pair;", "Lcom/alpine/blizzardboard/engine/Pos;", "trySwap", "Lcom/alpine/blizzardboard/engine/Phase;", "a", "b", "addExtraMoves", "n", "doShuffle", "removeAt", "p", "useMagnet", "magnetTargets", "", "max", "cellsWith", "predicate", "Lkotlin/Function1;", "Lcom/alpine/blizzardboard/engine/Cell;", "cellsAdjacentToBlockers", "runCascade", "", "initialSeeds", "powerTargets", "", "swapCell", "phases", "", "finishMove", "combinedSpecial", "ka", "Lcom/alpine/blizzardboard/domain/model/Special;", "kb", "scoreFor", "count", "combo", "specials", "applyGoalDeltas", "info", "Lcom/alpine/blizzardboard/engine/ClearInfo;", "refreshScoreGoal", "adjacent", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class GameEngine {
    private final List<GemType> activeTypes;
    private int bestCombo;
    private final Board board;
    private final LevelConfig config;
    private final List<GoalRuntime> goals;
    private int movesLeft;
    private final Random rng;
    private int score;

    /* JADX INFO: compiled from: GameEngine.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[GoalType.values().length];
            try {
                iArr[GoalType.COLLECT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[GoalType.DELIVER_FLAG.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[GoalType.CLEAR_SNOW.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[GoalType.BREAK_ICE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[GoalType.BREAK_ROCK.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[GoalType.REACH_SCORE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Special.values().length];
            try {
                iArr2[Special.LINE_H.ordinal()] = 1;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr2[Special.LINE_V.ordinal()] = 2;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr2[Special.BOMB.ordinal()] = 3;
            } catch (NoSuchFieldError unused9) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    private final int scoreFor(int count, int combo, int specials) {
        return (count * 30) + ((combo - 1) * count * 8) + (specials * 80);
    }

    public GameEngine(LevelConfig config, long j) {
        Intrinsics.checkNotNullParameter(config, "config");
        this.config = config;
        Random Random = RandomKt.Random(j);
        this.rng = Random;
        List<GemType> listComputeActiveTypes = computeActiveTypes(config);
        this.activeTypes = listComputeActiveTypes;
        this.board = new Board(config.getRows(), config.getCols(), listComputeActiveTypes, Random);
        this.movesLeft = config.getMoves();
        List<Goal> goals = config.getGoals();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(goals, 10));
        Iterator<T> it = goals.iterator();
        while (it.hasNext()) {
            arrayList.add(new GoalRuntime((Goal) it.next()));
        }
        this.goals = arrayList;
        this.board.applyLayout(this.config.getLayout());
        this.board.fillInitialNoMatch();
        if (!this.board.anyMove()) {
            this.board.shuffle();
        }
        refreshScoreGoal();
    }

    public /* synthetic */ GameEngine(LevelConfig levelConfig, long j, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(levelConfig, (i & 2) != 0 ? System.nanoTime() : j);
    }

    public final LevelConfig getConfig() {
        return this.config;
    }

    public final List<GemType> getActiveTypes() {
        return this.activeTypes;
    }

    public final Board getBoard() {
        return this.board;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getMovesLeft() {
        return this.movesLeft;
    }

    public final int getBestCombo() {
        return this.bestCombo;
    }

    public final List<GoalRuntime> getGoals() {
        return this.goals;
    }

    public final int getLevelId() {
        return this.config.getId();
    }

    public final int getTotalMoves() {
        return this.config.getMoves();
    }

    private final List<GemType> computeActiveTypes(LevelConfig config) {
        LinkedHashSet linkedHashSet = new LinkedHashSet(CollectionsKt.take(CollectionsKt.listOf((Object[]) new GemType[]{GemType.SNOWBOARD, GemType.HELMET, GemType.GOGGLES, GemType.GLOVE, GemType.SNOWFLAKE, GemType.MEDAL, GemType.FLAG}), config.getGemVariety()));
        for (Goal goal : config.getGoals()) {
            GemType gem = goal.getGem();
            if (gem != null) {
                linkedHashSet.add(gem);
            }
            if (goal.getType() == GoalType.DELIVER_FLAG) {
                linkedHashSet.add(GemType.FLAG);
            }
        }
        return CollectionsKt.toList(linkedHashSet);
    }

    public final VCell[][] snapshot() {
        return this.board.snapshot();
    }

    public final HudState hud() {
        int i = this.score;
        int i2 = this.movesLeft;
        List<GoalRuntime> list = this.goals;
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        for (GoalRuntime goalRuntime : list) {
            arrayList.add(new GoalProgress(goalRuntime.getGoal(), goalRuntime.getCurrent(), goalRuntime.getDone()));
        }
        return new HudState(i, i2, arrayList);
    }

    public final boolean isComplete() {
        List<GoalRuntime> list = this.goals;
        if ((list instanceof Collection) && list.isEmpty()) {
            return true;
        }
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            if (!((GoalRuntime) it.next()).getDone()) {
                return false;
            }
        }
        return true;
    }

    public final boolean isFailed() {
        return !isComplete() && this.movesLeft <= 0;
    }

    private final boolean isOver() {
        return isComplete() || this.movesLeft <= 0;
    }

    public final int starsEarned() {
        float moves = this.config.getMoves() == 0 ? 0.0f : this.movesLeft / this.config.getMoves();
        if (moves >= 0.35f) {
            return 3;
        }
        return moves >= 0.12f ? 2 : 1;
    }

    public final Pair<Pos, Pos> hint() {
        return this.board.findHint();
    }

    public final List<Phase> trySwap(Pos a, Pos b) {
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(b, "b");
        if (isOver()) {
            return CollectionsKt.emptyList();
        }
        if (!this.board.movable(a) || !this.board.movable(b)) {
            return CollectionsKt.emptyList();
        }
        if (!adjacent(a, b)) {
            return CollectionsKt.emptyList();
        }
        Cell cell = this.board.cell(a);
        Cell cell2 = this.board.cell(b);
        if (cell.getLocked() || cell2.getLocked()) {
            return CollectionsKt.listOf(new SwapPhase(a, b, true, hud()));
        }
        if (cell.getGem() == null || cell2.getGem() == null) {
            return CollectionsKt.emptyList();
        }
        this.board.swapGems(a, b);
        Gem gem = this.board.cell(a).getGem();
        Intrinsics.checkNotNull(gem);
        Special special = gem.getSpecial();
        Gem gem2 = this.board.cell(b).getGem();
        Intrinsics.checkNotNull(gem2);
        Special special2 = gem2.getSpecial();
        boolean z = (special == Special.NONE && special2 == Special.NONE) ? false : true;
        if (this.board.findRuns().isEmpty() && !z) {
            this.board.swapGems(a, b);
            return CollectionsKt.listOf(new SwapPhase(a, b, true, hud()));
        }
        this.movesLeft--;
        ArrayList arrayList = new ArrayList();
        arrayList.add(new SwapPhase(a, b, false, hud()));
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        HashMap map = new HashMap();
        if (z) {
            if (special != Special.NONE && special2 != Special.NONE) {
                linkedHashSet.addAll(combinedSpecial(a, b, special, special2));
            } else if (special2 != Special.NONE) {
                linkedHashSet.add(b);
                if (special2 == Special.POWER) {
                    Gem gem3 = this.board.cell(a).getGem();
                    Intrinsics.checkNotNull(gem3);
                    map.put(b, gem3.getType());
                }
            } else {
                linkedHashSet.add(a);
                if (special == Special.POWER) {
                    Gem gem4 = this.board.cell(b).getGem();
                    Intrinsics.checkNotNull(gem4);
                    map.put(a, gem4.getType());
                }
            }
        }
        ArrayList arrayList2 = arrayList;
        runCascade(linkedHashSet, map, b, arrayList2);
        finishMove(arrayList2);
        return arrayList2;
    }

    public final List<Phase> addExtraMoves(int n) {
        if (isOver()) {
            return CollectionsKt.emptyList();
        }
        this.movesLeft += n;
        return CollectionsKt.listOf(new StatePhase(hud()));
    }

    public final List<Phase> doShuffle() {
        if (isOver()) {
            return CollectionsKt.emptyList();
        }
        this.board.shuffle();
        return CollectionsKt.listOf(new ShufflePhase(hud()));
    }

    public final List<Phase> removeAt(Pos p) {
        Intrinsics.checkNotNullParameter(p, "p");
        if (isOver() || !this.board.movable(p) || this.board.cell(p).getGem() == null) {
            return CollectionsKt.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        runCascade(SetsKt.setOf(p), MapsKt.emptyMap(), null, arrayList);
        finishMove(arrayList);
        return arrayList;
    }

    public final List<Phase> useMagnet() {
        if (isOver()) {
            return CollectionsKt.emptyList();
        }
        Set<Pos> setMagnetTargets = magnetTargets(5);
        if (setMagnetTargets.isEmpty()) {
            return CollectionsKt.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        runCascade(setMagnetTargets, MapsKt.emptyMap(), null, arrayList);
        finishMove(arrayList);
        return arrayList;
    }

    private final Set<Pos> magnetTargets(int max) {
        Object next;
        Iterator<T> it = this.goals.iterator();
        do {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
        } while (((GoalRuntime) next).getDone());
        GoalRuntime goalRuntime = (GoalRuntime) next;
        if (goalRuntime == null) {
            return SetsKt.emptySet();
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        switch (WhenMappings.$EnumSwitchMapping$0[goalRuntime.getGoal().getType().ordinal()]) {
            case 1:
                GemType gem = goalRuntime.getGoal().getGem();
                if (gem != null) {
                    linkedHashSet.addAll(CollectionsKt.take(this.board.cellsOfType(gem), max));
                }
                break;
            case 2:
                linkedHashSet.addAll(CollectionsKt.take(this.board.cellsOfType(GemType.FLAG), max));
                break;
            case 3:
                linkedHashSet.addAll(CollectionsKt.take(cellsWith(new Function1() { // from class: com.alpine.blizzardboard.engine.GameEngine$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return Boolean.valueOf(GameEngine.magnetTargets$lambda$6((Cell) obj));
                    }
                }), max));
                break;
            case 4:
                linkedHashSet.addAll(CollectionsKt.take(cellsWith(new Function1() { // from class: com.alpine.blizzardboard.engine.GameEngine$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return Boolean.valueOf(GameEngine.magnetTargets$lambda$7((Cell) obj));
                    }
                }), max));
                break;
            case 5:
                linkedHashSet.addAll(CollectionsKt.take(cellsAdjacentToBlockers(), max));
                break;
            case 6:
                linkedHashSet.addAll(CollectionsKt.take(CollectionsKt.shuffled(this.board.allGemCells(), this.rng), max));
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        return linkedHashSet;
    }

    static final boolean magnetTargets$lambda$6(Cell it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getSnow() > 0;
    }

    static final boolean magnetTargets$lambda$7(Cell it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getIce() > 0;
    }

    private final List<Pos> cellsWith(Function1<? super Cell, Boolean> predicate) {
        ArrayList arrayList = new ArrayList();
        int rows = this.board.getRows();
        for (int i = 0; i < rows; i++) {
            int cols = this.board.getCols();
            for (int i2 = 0; i2 < cols; i2++) {
                Cell cell = this.board.cell(i, i2);
                if (cell.getMovable() && cell.getGem() != null && predicate.invoke(cell).booleanValue()) {
                    arrayList.add(new Pos(i, i2));
                }
            }
        }
        return arrayList;
    }

    private final List<Pos> cellsAdjacentToBlockers() {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        int rows = this.board.getRows();
        for (int i = 0; i < rows; i++) {
            int cols = this.board.getCols();
            for (int i2 = 0; i2 < cols; i2++) {
                if (this.board.cell(i, i2).getBlocker() != Blocker.NONE) {
                    for (Pos pos : this.board.orthogonal(new Pos(i, i2))) {
                        if (this.board.movable(pos) && this.board.cell(pos).getGem() != null) {
                            linkedHashSet.add(pos);
                        }
                    }
                }
            }
        }
        return CollectionsKt.toList(linkedHashSet);
    }

    private final void runCascade(Set<Pos> initialSeeds, Map<Pos, ? extends GemType> powerTargets, Pos swapCell, List<Phase> phases) {
        int i = 0;
        boolean z = true;
        while (true) {
            List<Run> listFindRuns = this.board.findRuns();
            Set<Pos> setMatchedCells = this.board.matchedCells(listFindRuns);
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            if (z) {
                linkedHashSet.addAll(initialSeeds);
            }
            Set<Pos> set = setMatchedCells;
            linkedHashSet.addAll(set);
            if (linkedHashSet.isEmpty()) {
                return;
            }
            int i2 = i + 1;
            if (i2 > this.bestCombo) {
                this.bestCombo = i2;
            }
            Map<Pos, Special> mapEmptyMap = set.isEmpty() ? MapsKt.emptyMap() : this.board.decideSpecials(listFindRuns, z ? swapCell : null);
            LinkedHashSet linkedHashSet2 = new LinkedHashSet();
            LinkedHashSet linkedHashSet3 = linkedHashSet2;
            this.board.expandClears(linkedHashSet, mapEmptyMap.keySet(), linkedHashSet3, powerTargets);
            linkedHashSet2.removeAll(mapEmptyMap.keySet());
            if (linkedHashSet2.isEmpty()) {
                for (Map.Entry<Pos, Special> entry : mapEmptyMap.entrySet()) {
                    Pos key = entry.getKey();
                    Special value = entry.getValue();
                    Gem gem = this.board.cell(key).getGem();
                    if (gem != null) {
                        gem.setSpecial(value);
                    }
                }
                return;
            }
            ClearInfo clearInfoApplyClears = this.board.applyClears(linkedHashSet3);
            for (Map.Entry<Pos, Special> entry2 : mapEmptyMap.entrySet()) {
                Pos key2 = entry2.getKey();
                Special value2 = entry2.getValue();
                Gem gem2 = this.board.cell(key2).getGem();
                if (gem2 != null) {
                    gem2.setSpecial(value2);
                }
            }
            int iScoreFor = scoreFor(linkedHashSet2.size(), i2, mapEmptyMap.size());
            this.score += iScoreFor;
            applyGoalDeltas(clearInfoApplyClears);
            refreshScoreGoal();
            phases.add(new ClearPhase(CollectionsKt.toList(linkedHashSet2), mapEmptyMap, clearInfoApplyClears.getSnowHits(), clearInfoApplyClears.getIceHits(), clearInfoApplyClears.getBlockerHits(), clearInfoApplyClears.getBlockerCleared(), clearInfoApplyClears.getUnlocked(), clearInfoApplyClears.getFlagsDelivered(), i2, iScoreFor, hud()));
            Pair<List<GemMove>, List<GemSpawn>> pairGravity = this.board.gravity();
            phases.add(new FallPhase(pairGravity.component1(), pairGravity.component2(), hud()));
            if (isComplete()) {
                return;
            }
            z = false;
            i = i2;
        }
    }

    private final void finishMove(List<Phase> phases) {
        if (!isComplete() && this.movesLeft > 0 && !this.board.anyMove()) {
            this.board.shuffle();
            phases.add(new ShufflePhase(hud()));
        }
        if (isComplete()) {
            phases.add(new ResultPhase(true, starsEarned(), this.score, hud()));
        } else if (this.movesLeft <= 0) {
            phases.add(new ResultPhase(false, 0, this.score, hud()));
        }
    }

    private final Set<Pos> combinedSpecial(Pos a, Pos b, Special ka, Special kb) {
        HashSet hashSet = new HashSet();
        hashSet.add(a);
        hashSet.add(b);
        Set of = SetsKt.setOf((Object[]) new Special[]{Special.LINE_H, Special.LINE_V});
        if (ka == Special.POWER && kb == Special.POWER) {
            hashSet.addAll(this.board.allGemCells());
        } else if (ka == Special.POWER || kb == Special.POWER) {
            if (ka == Special.POWER) {
                ka = kb;
            }
            Board board = this.board;
            hashSet.addAll(board.cellsOfType(board.mostFrequentType()));
            int i = WhenMappings.$EnumSwitchMapping$1[ka.ordinal()];
            if (i == 1 || i == 2) {
                hashSet.addAll(this.board.rowCells(b.getR()));
                hashSet.addAll(this.board.colCells(b.getC()));
            } else if (i == 3) {
                hashSet.addAll(this.board.areaCells(b, 1));
            }
        } else if (ka == Special.BOMB && kb == Special.BOMB) {
            hashSet.addAll(this.board.areaCells(b, 2));
        } else if ((ka == Special.BOMB && of.contains(kb)) || (kb == Special.BOMB && of.contains(ka))) {
            combinedSpecial$rowsAround(this, hashSet, b.getR());
            combinedSpecial$colsAround(this, hashSet, b.getC());
        } else if (!of.contains(ka) || of.contains(kb)) {
            hashSet.addAll(this.board.rowCells(b.getR()));
            hashSet.addAll(this.board.colCells(b.getC()));
        } else {
            hashSet.addAll(this.board.rowCells(b.getR()));
            hashSet.addAll(this.board.colCells(b.getC()));
        }
        return hashSet;
    }

    private static final void combinedSpecial$rowsAround(GameEngine gameEngine, HashSet<Pos> hashSet, int i) {
        int i2 = i - 1;
        int i3 = i + 1;
        if (i2 > i3) {
            return;
        }
        while (true) {
            if (i2 >= 0 && i2 < gameEngine.board.getRows()) {
                hashSet.addAll(gameEngine.board.rowCells(i2));
            }
            if (i2 == i3) {
                return;
            } else {
                i2++;
            }
        }
    }

    private static final void combinedSpecial$colsAround(GameEngine gameEngine, HashSet<Pos> hashSet, int i) {
        int i2 = i - 1;
        int i3 = i + 1;
        if (i2 > i3) {
            return;
        }
        while (true) {
            if (i2 >= 0 && i2 < gameEngine.board.getCols()) {
                hashSet.addAll(gameEngine.board.colCells(i2));
            }
            if (i2 == i3) {
                return;
            } else {
                i2++;
            }
        }
    }

    private final void applyGoalDeltas(ClearInfo info) {
        for (GoalRuntime goalRuntime : this.goals) {
            boolean z = false;
            switch (WhenMappings.$EnumSwitchMapping$0[goalRuntime.getGoal().getType().ordinal()]) {
                case 1:
                    GemType gem = goalRuntime.getGoal().getGem();
                    if (gem != null) {
                        int current = goalRuntime.getCurrent();
                        Integer num = info.getCollected().get(gem);
                        goalRuntime.setCurrent(current + (num != null ? num.intValue() : 0));
                    }
                    break;
                case 2:
                    int current2 = goalRuntime.getCurrent();
                    Integer num2 = info.getCollected().get(GemType.FLAG);
                    goalRuntime.setCurrent(current2 + (num2 != null ? num2.intValue() : 0));
                    break;
                case 3:
                    goalRuntime.setCurrent(goalRuntime.getCurrent() + info.getSnowLayersRemoved());
                    break;
                case 4:
                    goalRuntime.setCurrent(goalRuntime.getCurrent() + info.getIceLayersRemoved());
                    break;
                case 5:
                    goalRuntime.setCurrent(goalRuntime.getCurrent() + info.getBlockersRemoved());
                    break;
                case 6:
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
            goalRuntime.setCurrent(RangesKt.coerceAtMost(goalRuntime.getCurrent(), goalRuntime.getGoal().getTarget()));
            if (goalRuntime.getCurrent() >= goalRuntime.getGoal().getTarget()) {
                z = true;
            }
            goalRuntime.setDone(z);
        }
    }

    private final void refreshScoreGoal() {
        for (GoalRuntime goalRuntime : this.goals) {
            if (goalRuntime.getGoal().getType() == GoalType.REACH_SCORE) {
                goalRuntime.setCurrent(RangesKt.coerceAtMost(this.score, goalRuntime.getGoal().getTarget()));
                goalRuntime.setDone(this.score >= goalRuntime.getGoal().getTarget());
            }
        }
    }

    private final boolean adjacent(Pos a, Pos b) {
        return Math.abs(a.getR() - b.getR()) + Math.abs(a.getC() - b.getC()) == 1;
    }
}
