package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B+\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\bHÆ\u0003J3\u0010\u0013\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u00032\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0014\u0010\u0007\u001a\u00020\bX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001c"}, d2 = {"Lcom/alpine/blizzardboard/engine/FallPhase;", "Lcom/alpine/blizzardboard/engine/Phase;", "moves", "", "Lcom/alpine/blizzardboard/engine/GemMove;", "spawns", "Lcom/alpine/blizzardboard/engine/GemSpawn;", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "<init>", "(Ljava/util/List;Ljava/util/List;Lcom/alpine/blizzardboard/engine/HudState;)V", "getMoves", "()Ljava/util/List;", "getSpawns", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class FallPhase implements Phase {
    private final HudState hud;
    private final List<GemMove> moves;
    private final List<GemSpawn> spawns;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ FallPhase copy$default(FallPhase fallPhase, List list, List list2, HudState hudState, int i, Object obj) {
        if ((i & 1) != 0) {
            list = fallPhase.moves;
        }
        if ((i & 2) != 0) {
            list2 = fallPhase.spawns;
        }
        if ((i & 4) != 0) {
            hudState = fallPhase.hud;
        }
        return fallPhase.copy(list, list2, hudState);
    }

    public final List<GemMove> component1() {
        return this.moves;
    }

    public final List<GemSpawn> component2() {
        return this.spawns;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final HudState getHud() {
        return this.hud;
    }

    public final FallPhase copy(List<GemMove> moves, List<GemSpawn> spawns, HudState hud) {
        Intrinsics.checkNotNullParameter(moves, "moves");
        Intrinsics.checkNotNullParameter(spawns, "spawns");
        Intrinsics.checkNotNullParameter(hud, "hud");
        return new FallPhase(moves, spawns, hud);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FallPhase)) {
            return false;
        }
        FallPhase fallPhase = (FallPhase) other;
        return Intrinsics.areEqual(this.moves, fallPhase.moves) && Intrinsics.areEqual(this.spawns, fallPhase.spawns) && Intrinsics.areEqual(this.hud, fallPhase.hud);
    }

    public int hashCode() {
        return (((this.moves.hashCode() * 31) + this.spawns.hashCode()) * 31) + this.hud.hashCode();
    }

    public String toString() {
        return "FallPhase(moves=" + this.moves + ", spawns=" + this.spawns + ", hud=" + this.hud + ")";
    }

    public FallPhase(List<GemMove> moves, List<GemSpawn> spawns, HudState hud) {
        Intrinsics.checkNotNullParameter(moves, "moves");
        Intrinsics.checkNotNullParameter(spawns, "spawns");
        Intrinsics.checkNotNullParameter(hud, "hud");
        this.moves = moves;
        this.spawns = spawns;
        this.hud = hud;
    }

    public final List<GemMove> getMoves() {
        return this.moves;
    }

    public final List<GemSpawn> getSpawns() {
        return this.spawns;
    }

    @Override // com.alpine.blizzardboard.engine.Phase
    public HudState getHud() {
        return this.hud;
    }
}
