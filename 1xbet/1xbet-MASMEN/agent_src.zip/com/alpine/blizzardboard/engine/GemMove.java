package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0014"}, d2 = {"Lcom/alpine/blizzardboard/engine/GemMove;", "", TypedValues.TransitionType.S_FROM, "Lcom/alpine/blizzardboard/engine/Pos;", TypedValues.TransitionType.S_TO, "<init>", "(Lcom/alpine/blizzardboard/engine/Pos;Lcom/alpine/blizzardboard/engine/Pos;)V", "getFrom", "()Lcom/alpine/blizzardboard/engine/Pos;", "getTo", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class GemMove {
    private final Pos from;
    private final Pos to;

    public static /* synthetic */ GemMove copy$default(GemMove gemMove, Pos pos, Pos pos2, int i, Object obj) {
        if ((i & 1) != 0) {
            pos = gemMove.from;
        }
        if ((i & 2) != 0) {
            pos2 = gemMove.to;
        }
        return gemMove.copy(pos, pos2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Pos getFrom() {
        return this.from;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Pos getTo() {
        return this.to;
    }

    public final GemMove copy(Pos from, Pos to) {
        Intrinsics.checkNotNullParameter(from, "from");
        Intrinsics.checkNotNullParameter(to, "to");
        return new GemMove(from, to);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GemMove)) {
            return false;
        }
        GemMove gemMove = (GemMove) other;
        return Intrinsics.areEqual(this.from, gemMove.from) && Intrinsics.areEqual(this.to, gemMove.to);
    }

    public int hashCode() {
        return (this.from.hashCode() * 31) + this.to.hashCode();
    }

    public String toString() {
        return "GemMove(from=" + this.from + ", to=" + this.to + ")";
    }

    public GemMove(Pos from, Pos to) {
        Intrinsics.checkNotNullParameter(from, "from");
        Intrinsics.checkNotNullParameter(to, "to");
        this.from = from;
        this.to = to;
    }

    public final Pos getFrom() {
        return this.from;
    }

    public final Pos getTo() {
        return this.to;
    }
}
