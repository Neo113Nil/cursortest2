package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.domain.model.Special;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0095\u0001\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u000f\u0012\u0006\u0010\u0011\u001a\u00020\u0012¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010$\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u0015\u0010%\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010)\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010*\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010+\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\t\u0010,\u001a\u00020\u000fHÆ\u0003J\t\u0010-\u001a\u00020\u000fHÆ\u0003J\t\u0010.\u001a\u00020\u0012HÆ\u0003J\u00ad\u0001\u0010/\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0014\b\u0002\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u00062\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\u0010\u001a\u00020\u000f2\b\b\u0002\u0010\u0011\u001a\u00020\u0012HÆ\u0001J\u0013\u00100\u001a\u0002012\b\u00102\u001a\u0004\u0018\u000103HÖ\u0003J\t\u00104\u001a\u00020\u000fHÖ\u0001J\t\u00105\u001a\u000206HÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u001d\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0016R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0016R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0016R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0016R\u0011\u0010\u000e\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0011\u0010\u0010\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b!\u0010 R\u0014\u0010\u0011\u001a\u00020\u0012X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#¨\u00067"}, d2 = {"Lcom/alpine/blizzardboard/engine/ClearPhase;", "Lcom/alpine/blizzardboard/engine/Phase;", "cleared", "", "Lcom/alpine/blizzardboard/engine/Pos;", "created", "", "Lcom/alpine/blizzardboard/domain/model/Special;", "snowHits", "iceHits", "blockerHits", "blockerCleared", "unlocked", "flagsDelivered", "combo", "", "gain", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "<init>", "(Ljava/util/List;Ljava/util/Map;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;IILcom/alpine/blizzardboard/engine/HudState;)V", "getCleared", "()Ljava/util/List;", "getCreated", "()Ljava/util/Map;", "getSnowHits", "getIceHits", "getBlockerHits", "getBlockerCleared", "getUnlocked", "getFlagsDelivered", "getCombo", "()I", "getGain", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class ClearPhase implements Phase {
    private final List<Pos> blockerCleared;
    private final List<Pos> blockerHits;
    private final List<Pos> cleared;
    private final int combo;
    private final Map<Pos, Special> created;
    private final List<Pos> flagsDelivered;
    private final int gain;
    private final HudState hud;
    private final List<Pos> iceHits;
    private final List<Pos> snowHits;
    private final List<Pos> unlocked;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ ClearPhase copy$default(ClearPhase clearPhase, List list, Map map, List list2, List list3, List list4, List list5, List list6, List list7, int i, int i2, HudState hudState, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            list = clearPhase.cleared;
        }
        if ((i3 & 2) != 0) {
            map = clearPhase.created;
        }
        if ((i3 & 4) != 0) {
            list2 = clearPhase.snowHits;
        }
        if ((i3 & 8) != 0) {
            list3 = clearPhase.iceHits;
        }
        if ((i3 & 16) != 0) {
            list4 = clearPhase.blockerHits;
        }
        if ((i3 & 32) != 0) {
            list5 = clearPhase.blockerCleared;
        }
        if ((i3 & 64) != 0) {
            list6 = clearPhase.unlocked;
        }
        if ((i3 & 128) != 0) {
            list7 = clearPhase.flagsDelivered;
        }
        if ((i3 & 256) != 0) {
            i = clearPhase.combo;
        }
        if ((i3 & 512) != 0) {
            i2 = clearPhase.gain;
        }
        if ((i3 & 1024) != 0) {
            hudState = clearPhase.hud;
        }
        int i4 = i2;
        HudState hudState2 = hudState;
        List list8 = list7;
        int i5 = i;
        List list9 = list5;
        List list10 = list6;
        List list11 = list4;
        List list12 = list2;
        return clearPhase.copy(list, map, list12, list3, list11, list9, list10, list8, i5, i4, hudState2);
    }

    public final List<Pos> component1() {
        return this.cleared;
    }

    /* JADX INFO: renamed from: component10, reason: from getter */
    public final int getGain() {
        return this.gain;
    }

    /* JADX INFO: renamed from: component11, reason: from getter */
    public final HudState getHud() {
        return this.hud;
    }

    public final Map<Pos, Special> component2() {
        return this.created;
    }

    public final List<Pos> component3() {
        return this.snowHits;
    }

    public final List<Pos> component4() {
        return this.iceHits;
    }

    public final List<Pos> component5() {
        return this.blockerHits;
    }

    public final List<Pos> component6() {
        return this.blockerCleared;
    }

    public final List<Pos> component7() {
        return this.unlocked;
    }

    public final List<Pos> component8() {
        return this.flagsDelivered;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final int getCombo() {
        return this.combo;
    }

    public final ClearPhase copy(List<Pos> cleared, Map<Pos, ? extends Special> created, List<Pos> snowHits, List<Pos> iceHits, List<Pos> blockerHits, List<Pos> blockerCleared, List<Pos> unlocked, List<Pos> flagsDelivered, int combo, int gain, HudState hud) {
        Intrinsics.checkNotNullParameter(cleared, "cleared");
        Intrinsics.checkNotNullParameter(created, "created");
        Intrinsics.checkNotNullParameter(snowHits, "snowHits");
        Intrinsics.checkNotNullParameter(iceHits, "iceHits");
        Intrinsics.checkNotNullParameter(blockerHits, "blockerHits");
        Intrinsics.checkNotNullParameter(blockerCleared, "blockerCleared");
        Intrinsics.checkNotNullParameter(unlocked, "unlocked");
        Intrinsics.checkNotNullParameter(flagsDelivered, "flagsDelivered");
        Intrinsics.checkNotNullParameter(hud, "hud");
        return new ClearPhase(cleared, created, snowHits, iceHits, blockerHits, blockerCleared, unlocked, flagsDelivered, combo, gain, hud);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ClearPhase)) {
            return false;
        }
        ClearPhase clearPhase = (ClearPhase) other;
        return Intrinsics.areEqual(this.cleared, clearPhase.cleared) && Intrinsics.areEqual(this.created, clearPhase.created) && Intrinsics.areEqual(this.snowHits, clearPhase.snowHits) && Intrinsics.areEqual(this.iceHits, clearPhase.iceHits) && Intrinsics.areEqual(this.blockerHits, clearPhase.blockerHits) && Intrinsics.areEqual(this.blockerCleared, clearPhase.blockerCleared) && Intrinsics.areEqual(this.unlocked, clearPhase.unlocked) && Intrinsics.areEqual(this.flagsDelivered, clearPhase.flagsDelivered) && this.combo == clearPhase.combo && this.gain == clearPhase.gain && Intrinsics.areEqual(this.hud, clearPhase.hud);
    }

    public int hashCode() {
        return (((((((((((((((((((this.cleared.hashCode() * 31) + this.created.hashCode()) * 31) + this.snowHits.hashCode()) * 31) + this.iceHits.hashCode()) * 31) + this.blockerHits.hashCode()) * 31) + this.blockerCleared.hashCode()) * 31) + this.unlocked.hashCode()) * 31) + this.flagsDelivered.hashCode()) * 31) + Integer.hashCode(this.combo)) * 31) + Integer.hashCode(this.gain)) * 31) + this.hud.hashCode();
    }

    public String toString() {
        return "ClearPhase(cleared=" + this.cleared + ", created=" + this.created + ", snowHits=" + this.snowHits + ", iceHits=" + this.iceHits + ", blockerHits=" + this.blockerHits + ", blockerCleared=" + this.blockerCleared + ", unlocked=" + this.unlocked + ", flagsDelivered=" + this.flagsDelivered + ", combo=" + this.combo + ", gain=" + this.gain + ", hud=" + this.hud + ")";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public ClearPhase(List<Pos> cleared, Map<Pos, ? extends Special> created, List<Pos> snowHits, List<Pos> iceHits, List<Pos> blockerHits, List<Pos> blockerCleared, List<Pos> unlocked, List<Pos> flagsDelivered, int i, int i2, HudState hud) {
        Intrinsics.checkNotNullParameter(cleared, "cleared");
        Intrinsics.checkNotNullParameter(created, "created");
        Intrinsics.checkNotNullParameter(snowHits, "snowHits");
        Intrinsics.checkNotNullParameter(iceHits, "iceHits");
        Intrinsics.checkNotNullParameter(blockerHits, "blockerHits");
        Intrinsics.checkNotNullParameter(blockerCleared, "blockerCleared");
        Intrinsics.checkNotNullParameter(unlocked, "unlocked");
        Intrinsics.checkNotNullParameter(flagsDelivered, "flagsDelivered");
        Intrinsics.checkNotNullParameter(hud, "hud");
        this.cleared = cleared;
        this.created = created;
        this.snowHits = snowHits;
        this.iceHits = iceHits;
        this.blockerHits = blockerHits;
        this.blockerCleared = blockerCleared;
        this.unlocked = unlocked;
        this.flagsDelivered = flagsDelivered;
        this.combo = i;
        this.gain = i2;
        this.hud = hud;
    }

    public final List<Pos> getCleared() {
        return this.cleared;
    }

    public final Map<Pos, Special> getCreated() {
        return this.created;
    }

    public final List<Pos> getSnowHits() {
        return this.snowHits;
    }

    public final List<Pos> getIceHits() {
        return this.iceHits;
    }

    public final List<Pos> getBlockerHits() {
        return this.blockerHits;
    }

    public final List<Pos> getBlockerCleared() {
        return this.blockerCleared;
    }

    public final List<Pos> getUnlocked() {
        return this.unlocked;
    }

    public final List<Pos> getFlagsDelivered() {
        return this.flagsDelivered;
    }

    public final int getCombo() {
        return this.combo;
    }

    public final int getGain() {
        return this.gain;
    }

    @Override // com.alpine.blizzardboard.engine.Phase
    public HudState getHud() {
        return this.hud;
    }
}
