package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/alpine/blizzardboard/engine/GemSpawn;", "", TypedValues.TransitionType.S_TO, "Lcom/alpine/blizzardboard/engine/Pos;", "gem", "Lcom/alpine/blizzardboard/engine/GemView;", "fromRowsAbove", "", "<init>", "(Lcom/alpine/blizzardboard/engine/Pos;Lcom/alpine/blizzardboard/engine/GemView;I)V", "getTo", "()Lcom/alpine/blizzardboard/engine/Pos;", "getGem", "()Lcom/alpine/blizzardboard/engine/GemView;", "getFromRowsAbove", "()I", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class GemSpawn {
    private final int fromRowsAbove;
    private final GemView gem;
    private final Pos to;

    public static /* synthetic */ GemSpawn copy$default(GemSpawn gemSpawn, Pos pos, GemView gemView, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            pos = gemSpawn.to;
        }
        if ((i2 & 2) != 0) {
            gemView = gemSpawn.gem;
        }
        if ((i2 & 4) != 0) {
            i = gemSpawn.fromRowsAbove;
        }
        return gemSpawn.copy(pos, gemView, i);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Pos getTo() {
        return this.to;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final GemView getGem() {
        return this.gem;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getFromRowsAbove() {
        return this.fromRowsAbove;
    }

    public final GemSpawn copy(Pos to, GemView gem, int fromRowsAbove) {
        Intrinsics.checkNotNullParameter(to, "to");
        Intrinsics.checkNotNullParameter(gem, "gem");
        return new GemSpawn(to, gem, fromRowsAbove);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GemSpawn)) {
            return false;
        }
        GemSpawn gemSpawn = (GemSpawn) other;
        return Intrinsics.areEqual(this.to, gemSpawn.to) && Intrinsics.areEqual(this.gem, gemSpawn.gem) && this.fromRowsAbove == gemSpawn.fromRowsAbove;
    }

    public int hashCode() {
        return (((this.to.hashCode() * 31) + this.gem.hashCode()) * 31) + Integer.hashCode(this.fromRowsAbove);
    }

    public String toString() {
        return "GemSpawn(to=" + this.to + ", gem=" + this.gem + ", fromRowsAbove=" + this.fromRowsAbove + ")";
    }

    public GemSpawn(Pos to, GemView gem, int i) {
        Intrinsics.checkNotNullParameter(to, "to");
        Intrinsics.checkNotNullParameter(gem, "gem");
        this.to = to;
        this.gem = gem;
        this.fromRowsAbove = i;
    }

    public final int getFromRowsAbove() {
        return this.fromRowsAbove;
    }

    public final GemView getGem() {
        return this.gem;
    }

    public final Pos getTo() {
        return this.to;
    }
}
