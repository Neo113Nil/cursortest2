package com.alpine.blizzardboard.engine;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.core.SoundManager;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Phase.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\bHÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00032\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019HÖ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÖ\u0001J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0014\u0010\u0007\u001a\u00020\bX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001d"}, d2 = {"Lcom/alpine/blizzardboard/engine/ResultPhase;", "Lcom/alpine/blizzardboard/engine/Phase;", SoundManager.SUCCESS, "", "stars", "", "score", "hud", "Lcom/alpine/blizzardboard/engine/HudState;", "<init>", "(ZIILcom/alpine/blizzardboard/engine/HudState;)V", "getSuccess", "()Z", "getStars", "()I", "getScore", "getHud", "()Lcom/alpine/blizzardboard/engine/HudState;", "component1", "component2", "component3", "component4", "copy", "equals", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final /* data */ class ResultPhase implements Phase {
    private final HudState hud;
    private final int score;
    private final int stars;
    private final boolean success;

    public static /* synthetic */ ResultPhase copy$default(ResultPhase resultPhase, boolean z, int i, int i2, HudState hudState, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            z = resultPhase.success;
        }
        if ((i3 & 2) != 0) {
            i = resultPhase.stars;
        }
        if ((i3 & 4) != 0) {
            i2 = resultPhase.score;
        }
        if ((i3 & 8) != 0) {
            hudState = resultPhase.hud;
        }
        return resultPhase.copy(z, i, i2, hudState);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final boolean getSuccess() {
        return this.success;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getStars() {
        return this.stars;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getScore() {
        return this.score;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final HudState getHud() {
        return this.hud;
    }

    public final ResultPhase copy(boolean success, int stars, int score, HudState hud) {
        Intrinsics.checkNotNullParameter(hud, "hud");
        return new ResultPhase(success, stars, score, hud);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ResultPhase)) {
            return false;
        }
        ResultPhase resultPhase = (ResultPhase) other;
        return this.success == resultPhase.success && this.stars == resultPhase.stars && this.score == resultPhase.score && Intrinsics.areEqual(this.hud, resultPhase.hud);
    }

    public int hashCode() {
        return (((((Boolean.hashCode(this.success) * 31) + Integer.hashCode(this.stars)) * 31) + Integer.hashCode(this.score)) * 31) + this.hud.hashCode();
    }

    public String toString() {
        return "ResultPhase(success=" + this.success + ", stars=" + this.stars + ", score=" + this.score + ", hud=" + this.hud + ")";
    }

    public ResultPhase(boolean z, int i, int i2, HudState hud) {
        Intrinsics.checkNotNullParameter(hud, "hud");
        this.success = z;
        this.stars = i;
        this.score = i2;
        this.hud = hud;
    }

    public final boolean getSuccess() {
        return this.success;
    }

    public final int getStars() {
        return this.stars;
    }

    public final int getScore() {
        return this.score;
    }

    @Override // com.alpine.blizzardboard.engine.Phase
    public HudState getHud() {
        return this.hud;
    }
}
