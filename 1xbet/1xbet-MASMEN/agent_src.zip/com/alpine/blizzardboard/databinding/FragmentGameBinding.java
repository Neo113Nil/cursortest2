package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.presentation.game.BoardView;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentGameBinding implements ViewBinding {
    public final ImageButton backButton;
    public final BoardView boardView;
    public final LinearLayout boosterMagnet;
    public final TextView boosterMagnetCount;
    public final LinearLayout boosterMoves;
    public final TextView boosterMovesCount;
    public final LinearLayout boosterRemove;
    public final TextView boosterRemoveCount;
    public final LinearLayout boosterShuffle;
    public final TextView boosterShuffleCount;
    public final TextView comboText;
    public final LinearLayout goalContainer;
    public final TextView levelTitle;
    public final TextView movesValue;
    private final LinearLayout rootView;
    public final TextView scoreValue;

    private FragmentGameBinding(LinearLayout linearLayout, ImageButton imageButton, BoardView boardView, LinearLayout linearLayout2, TextView textView, LinearLayout linearLayout3, TextView textView2, LinearLayout linearLayout4, TextView textView3, LinearLayout linearLayout5, TextView textView4, TextView textView5, LinearLayout linearLayout6, TextView textView6, TextView textView7, TextView textView8) {
        this.rootView = linearLayout;
        this.backButton = imageButton;
        this.boardView = boardView;
        this.boosterMagnet = linearLayout2;
        this.boosterMagnetCount = textView;
        this.boosterMoves = linearLayout3;
        this.boosterMovesCount = textView2;
        this.boosterRemove = linearLayout4;
        this.boosterRemoveCount = textView3;
        this.boosterShuffle = linearLayout5;
        this.boosterShuffleCount = textView4;
        this.comboText = textView5;
        this.goalContainer = linearLayout6;
        this.levelTitle = textView6;
        this.movesValue = textView7;
        this.scoreValue = textView8;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static FragmentGameBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentGameBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_game, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentGameBinding bind(View view) {
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.boardView;
            BoardView boardView = (BoardView) ViewBindings.findChildViewById(view, i);
            if (boardView != null) {
                i = R.id.boosterMagnet;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                if (linearLayout != null) {
                    i = R.id.boosterMagnetCount;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView != null) {
                        i = R.id.boosterMoves;
                        LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i);
                        if (linearLayout2 != null) {
                            i = R.id.boosterMovesCount;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView2 != null) {
                                i = R.id.boosterRemove;
                                LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                if (linearLayout3 != null) {
                                    i = R.id.boosterRemoveCount;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView3 != null) {
                                        i = R.id.boosterShuffle;
                                        LinearLayout linearLayout4 = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                        if (linearLayout4 != null) {
                                            i = R.id.boosterShuffleCount;
                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView4 != null) {
                                                i = R.id.comboText;
                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView5 != null) {
                                                    i = R.id.goalContainer;
                                                    LinearLayout linearLayout5 = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                                    if (linearLayout5 != null) {
                                                        i = R.id.levelTitle;
                                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                                        if (textView6 != null) {
                                                            i = R.id.movesValue;
                                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                            if (textView7 != null) {
                                                                i = R.id.scoreValue;
                                                                TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                if (textView8 != null) {
                                                                    return new FragmentGameBinding((LinearLayout) view, imageButton, boardView, linearLayout, textView, linearLayout2, textView2, linearLayout3, textView3, linearLayout4, textView4, textView5, linearLayout5, textView6, textView7, textView8);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
