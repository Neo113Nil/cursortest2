package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class LayoutPreloaderBinding implements ViewBinding {
    public final TextView claimButton;
    public final ImageView giftIcon;
    public final FrameLayout giftStack;
    public final TextView headlineText;
    public final ConstraintLayout preloaderRoot;
    private final ConstraintLayout rootView;
    public final TextView subText;
    public final TextView topLabel;

    private LayoutPreloaderBinding(ConstraintLayout constraintLayout, TextView textView, ImageView imageView, FrameLayout frameLayout, TextView textView2, ConstraintLayout constraintLayout2, TextView textView3, TextView textView4) {
        this.rootView = constraintLayout;
        this.claimButton = textView;
        this.giftIcon = imageView;
        this.giftStack = frameLayout;
        this.headlineText = textView2;
        this.preloaderRoot = constraintLayout2;
        this.subText = textView3;
        this.topLabel = textView4;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static LayoutPreloaderBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static LayoutPreloaderBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_preloader, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static LayoutPreloaderBinding bind(View view) {
        int i = R.id.claimButton;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.giftIcon;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView != null) {
                i = R.id.giftStack;
                FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i);
                if (frameLayout != null) {
                    i = R.id.headlineText;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        ConstraintLayout constraintLayout = (ConstraintLayout) view;
                        i = R.id.subText;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.topLabel;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView4 != null) {
                                return new LayoutPreloaderBinding(constraintLayout, textView, imageView, frameLayout, textView2, constraintLayout, textView3, textView4);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
