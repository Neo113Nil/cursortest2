package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class ItemAchievementBinding implements ViewBinding {
    public final LinearLayout achCard;
    public final TextView achDesc;
    public final ImageView achIcon;
    public final ImageView achState;
    public final TextView achTitle;
    private final LinearLayout rootView;

    private ItemAchievementBinding(LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView, ImageView imageView, ImageView imageView2, TextView textView2) {
        this.rootView = linearLayout;
        this.achCard = linearLayout2;
        this.achDesc = textView;
        this.achIcon = imageView;
        this.achState = imageView2;
        this.achTitle = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static ItemAchievementBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemAchievementBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_achievement, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemAchievementBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        int i = R.id.achDesc;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.achIcon;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView != null) {
                i = R.id.achState;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView2 != null) {
                    i = R.id.achTitle;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        return new ItemAchievementBinding(linearLayout, linearLayout, textView, imageView, imageView2, textView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
