package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;
import com.alpine.blizzardboard.presentation.common.SquareFrameLayout;

/* JADX INFO: loaded from: classes.dex */
public final class ItemRouteLevelBinding implements ViewBinding {
    public final ImageView levelLock;
    public final TextView levelNumber;
    public final SquareFrameLayout levelRoot;
    private final SquareFrameLayout rootView;
    public final ImageView star1;
    public final ImageView star2;
    public final ImageView star3;
    public final LinearLayout starRow;

    private ItemRouteLevelBinding(SquareFrameLayout squareFrameLayout, ImageView imageView, TextView textView, SquareFrameLayout squareFrameLayout2, ImageView imageView2, ImageView imageView3, ImageView imageView4, LinearLayout linearLayout) {
        this.rootView = squareFrameLayout;
        this.levelLock = imageView;
        this.levelNumber = textView;
        this.levelRoot = squareFrameLayout2;
        this.star1 = imageView2;
        this.star2 = imageView3;
        this.star3 = imageView4;
        this.starRow = linearLayout;
    }

    @Override // androidx.viewbinding.ViewBinding
    public SquareFrameLayout getRoot() {
        return this.rootView;
    }

    public static ItemRouteLevelBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemRouteLevelBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_route_level, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemRouteLevelBinding bind(View view) {
        int i = R.id.levelLock;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.levelNumber;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                SquareFrameLayout squareFrameLayout = (SquareFrameLayout) view;
                i = R.id.star1;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView2 != null) {
                    i = R.id.star2;
                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView3 != null) {
                        i = R.id.star3;
                        ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView4 != null) {
                            i = R.id.starRow;
                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                            if (linearLayout != null) {
                                return new ItemRouteLevelBinding(squareFrameLayout, imageView, textView, squareFrameLayout, imageView2, imageView3, imageView4, linearLayout);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
