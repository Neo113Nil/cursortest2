package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentCollectionBinding implements ViewBinding {
    public final ImageButton backButton;
    public final RecyclerView collectionGrid;
    public final TextView collectionProgress;
    private final LinearLayout rootView;

    private FragmentCollectionBinding(LinearLayout linearLayout, ImageButton imageButton, RecyclerView recyclerView, TextView textView) {
        this.rootView = linearLayout;
        this.backButton = imageButton;
        this.collectionGrid = recyclerView;
        this.collectionProgress = textView;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static FragmentCollectionBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentCollectionBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_collection, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentCollectionBinding bind(View view) {
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.collectionGrid;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
            if (recyclerView != null) {
                i = R.id.collectionProgress;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    return new FragmentCollectionBinding((LinearLayout) view, imageButton, recyclerView, textView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
