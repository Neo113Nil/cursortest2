package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentLevelSelectBinding implements ViewBinding {
    public final ImageButton backButton;
    public final RecyclerView levelGrid;
    private final FrameLayout rootView;
    public final View routeTint;

    private FragmentLevelSelectBinding(FrameLayout frameLayout, ImageButton imageButton, RecyclerView recyclerView, View view) {
        this.rootView = frameLayout;
        this.backButton = imageButton;
        this.levelGrid = recyclerView;
        this.routeTint = view;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentLevelSelectBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentLevelSelectBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_level_select, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentLevelSelectBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.levelGrid;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i);
            if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.routeTint))) != null) {
                return new FragmentLevelSelectBinding((FrameLayout) view, imageButton, recyclerView, viewFindChildViewById);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
