package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentStatisticsBinding implements ViewBinding {
    public final ImageButton backButton;
    private final LinearLayout rootView;
    public final ViewStatRowBinding rowBoosters;
    public final ViewStatRowBinding rowCombo;
    public final ViewStatRowBinding rowLevels;
    public final ViewStatRowBinding rowMatches;
    public final ViewStatRowBinding rowScore;
    public final ViewStatRowBinding rowStreak;

    private FragmentStatisticsBinding(LinearLayout linearLayout, ImageButton imageButton, ViewStatRowBinding viewStatRowBinding, ViewStatRowBinding viewStatRowBinding2, ViewStatRowBinding viewStatRowBinding3, ViewStatRowBinding viewStatRowBinding4, ViewStatRowBinding viewStatRowBinding5, ViewStatRowBinding viewStatRowBinding6) {
        this.rootView = linearLayout;
        this.backButton = imageButton;
        this.rowBoosters = viewStatRowBinding;
        this.rowCombo = viewStatRowBinding2;
        this.rowLevels = viewStatRowBinding3;
        this.rowMatches = viewStatRowBinding4;
        this.rowScore = viewStatRowBinding5;
        this.rowStreak = viewStatRowBinding6;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static FragmentStatisticsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentStatisticsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_statistics, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentStatisticsBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.rowBoosters))) != null) {
            ViewStatRowBinding viewStatRowBindingBind = ViewStatRowBinding.bind(viewFindChildViewById);
            i = R.id.rowCombo;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i);
            if (viewFindChildViewById2 != null) {
                ViewStatRowBinding viewStatRowBindingBind2 = ViewStatRowBinding.bind(viewFindChildViewById2);
                i = R.id.rowLevels;
                View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i);
                if (viewFindChildViewById3 != null) {
                    ViewStatRowBinding viewStatRowBindingBind3 = ViewStatRowBinding.bind(viewFindChildViewById3);
                    i = R.id.rowMatches;
                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i);
                    if (viewFindChildViewById4 != null) {
                        ViewStatRowBinding viewStatRowBindingBind4 = ViewStatRowBinding.bind(viewFindChildViewById4);
                        i = R.id.rowScore;
                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i);
                        if (viewFindChildViewById5 != null) {
                            ViewStatRowBinding viewStatRowBindingBind5 = ViewStatRowBinding.bind(viewFindChildViewById5);
                            i = R.id.rowStreak;
                            View viewFindChildViewById6 = ViewBindings.findChildViewById(view, i);
                            if (viewFindChildViewById6 != null) {
                                return new FragmentStatisticsBinding((LinearLayout) view, imageButton, viewStatRowBindingBind, viewStatRowBindingBind2, viewStatRowBindingBind3, viewStatRowBindingBind4, viewStatRowBindingBind5, ViewStatRowBinding.bind(viewFindChildViewById6));
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
