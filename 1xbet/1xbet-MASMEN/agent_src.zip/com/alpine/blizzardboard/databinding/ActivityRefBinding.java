package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class ActivityRefBinding implements ViewBinding {
    public final ProgressBar circleProgressBar;
    public final ProgressBar horizontalProgressBar;
    public final LayoutPreloaderBinding preloader;
    public final ConstraintLayout root;
    private final ConstraintLayout rootView;

    private ActivityRefBinding(ConstraintLayout constraintLayout, ProgressBar progressBar, ProgressBar progressBar2, LayoutPreloaderBinding layoutPreloaderBinding, ConstraintLayout constraintLayout2) {
        this.rootView = constraintLayout;
        this.circleProgressBar = progressBar;
        this.horizontalProgressBar = progressBar2;
        this.preloader = layoutPreloaderBinding;
        this.root = constraintLayout2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityRefBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivityRefBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_ref, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivityRefBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.circleProgressBar;
        ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i);
        if (progressBar != null) {
            i = R.id.horizontalProgressBar;
            ProgressBar progressBar2 = (ProgressBar) ViewBindings.findChildViewById(view, i);
            if (progressBar2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.preloader))) != null) {
                ConstraintLayout constraintLayout = (ConstraintLayout) view;
                return new ActivityRefBinding(constraintLayout, progressBar, progressBar2, LayoutPreloaderBinding.bind(viewFindChildViewById), constraintLayout);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
