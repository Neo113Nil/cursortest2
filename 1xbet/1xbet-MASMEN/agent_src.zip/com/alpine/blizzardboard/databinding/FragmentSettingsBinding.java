package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentSettingsBinding implements ViewBinding {
    public final ImageButton backButton;
    public final TextView resetButton;
    private final LinearLayout rootView;
    public final SwitchCompat snowfallSwitch;
    public final SwitchCompat soundSwitch;
    public final TextView versionText;
    public final SwitchCompat vibrationSwitch;

    private FragmentSettingsBinding(LinearLayout linearLayout, ImageButton imageButton, TextView textView, SwitchCompat switchCompat, SwitchCompat switchCompat2, TextView textView2, SwitchCompat switchCompat3) {
        this.rootView = linearLayout;
        this.backButton = imageButton;
        this.resetButton = textView;
        this.snowfallSwitch = switchCompat;
        this.soundSwitch = switchCompat2;
        this.versionText = textView2;
        this.vibrationSwitch = switchCompat3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static FragmentSettingsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentSettingsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_settings, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentSettingsBinding bind(View view) {
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.resetButton;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.snowfallSwitch;
                SwitchCompat switchCompat = (SwitchCompat) ViewBindings.findChildViewById(view, i);
                if (switchCompat != null) {
                    i = R.id.soundSwitch;
                    SwitchCompat switchCompat2 = (SwitchCompat) ViewBindings.findChildViewById(view, i);
                    if (switchCompat2 != null) {
                        i = R.id.versionText;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView2 != null) {
                            i = R.id.vibrationSwitch;
                            SwitchCompat switchCompat3 = (SwitchCompat) ViewBindings.findChildViewById(view, i);
                            if (switchCompat3 != null) {
                                return new FragmentSettingsBinding((LinearLayout) view, imageButton, textView, switchCompat, switchCompat2, textView2, switchCompat3);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
