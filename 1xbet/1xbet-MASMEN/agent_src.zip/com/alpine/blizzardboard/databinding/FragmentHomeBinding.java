package com.alpine.blizzardboard.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alpine.blizzardboard.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentHomeBinding implements ViewBinding {
    public final TextView achievementsButton;
    public final TextView collectionButton;
    public final LinearLayout dailyCard;
    public final TextView dailyStatus;
    public final TextView playButton;
    public final ProgressBar progressBar;
    public final TextView progressText;
    private final FrameLayout rootView;
    public final TextView routeName;
    public final View routeTint;
    public final TextView routesButton;
    public final ImageButton settingsButton;
    public final TextView statisticsButton;

    private FragmentHomeBinding(FrameLayout frameLayout, TextView textView, TextView textView2, LinearLayout linearLayout, TextView textView3, TextView textView4, ProgressBar progressBar, TextView textView5, TextView textView6, View view, TextView textView7, ImageButton imageButton, TextView textView8) {
        this.rootView = frameLayout;
        this.achievementsButton = textView;
        this.collectionButton = textView2;
        this.dailyCard = linearLayout;
        this.dailyStatus = textView3;
        this.playButton = textView4;
        this.progressBar = progressBar;
        this.progressText = textView5;
        this.routeName = textView6;
        this.routeTint = view;
        this.routesButton = textView7;
        this.settingsButton = imageButton;
        this.statisticsButton = textView8;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentHomeBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentHomeBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_home, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentHomeBinding bind(View view) {
        View viewFindChildViewById;
        int i = R.id.achievementsButton;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.collectionButton;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.dailyCard;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                if (linearLayout != null) {
                    i = R.id.dailyStatus;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView3 != null) {
                        i = R.id.playButton;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView4 != null) {
                            i = R.id.progressBar;
                            ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i);
                            if (progressBar != null) {
                                i = R.id.progressText;
                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView5 != null) {
                                    i = R.id.routeName;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView6 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i = R.id.routeTint))) != null) {
                                        i = R.id.routesButton;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView7 != null) {
                                            i = R.id.settingsButton;
                                            ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
                                            if (imageButton != null) {
                                                i = R.id.statisticsButton;
                                                TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i);
                                                if (textView8 != null) {
                                                    return new FragmentHomeBinding((FrameLayout) view, textView, textView2, linearLayout, textView3, textView4, progressBar, textView5, textView6, viewFindChildViewById, textView7, imageButton, textView8);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
