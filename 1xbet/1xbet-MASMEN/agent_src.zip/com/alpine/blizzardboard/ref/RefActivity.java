package com.alpine.blizzardboard.ref;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.ProgressBar;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.webkit.ProxyConfig;
import com.alpine.blizzardboard.GameActivity;
import com.alpine.blizzardboard.databinding.ActivityRefBinding;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Constructor;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: RefActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000f\u0018\u0000 22\u00020\u0001:\u00012B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0014J\b\u0010\u0014\u001a\u00020\u0011H\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0016H\u0002J\u0018\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u001cH\u0002J\u0010\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001e\u001a\u00020\u0016H\u0002J\u0012\u0010\u001f\u001a\u0004\u0018\u00010\n2\u0006\u0010 \u001a\u00020!H\u0002J\u0010\u0010\"\u001a\u00020\u00112\u0006\u0010#\u001a\u00020$H\u0002J\u0010\u0010%\u001a\u00020\u00112\u0006\u0010&\u001a\u00020\nH\u0002J\u0018\u0010'\u001a\u00020\u00112\u0006\u0010(\u001a\u00020\u000f2\u0006\u0010)\u001a\u00020\nH\u0002J\u0010\u0010*\u001a\u00020\u00112\u0006\u0010(\u001a\u00020\u000fH\u0002J\b\u0010+\u001a\u00020\u0011H\u0002J\u0010\u0010,\u001a\u00020\u00112\u0006\u0010-\u001a\u00020\u0013H\u0014J\u0010\u0010.\u001a\u00020\u00112\u0006\u0010/\u001a\u00020\u0013H\u0014J\b\u00100\u001a\u00020\u0011H\u0014J\b\u00101\u001a\u00020\u0011H\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u00063"}, d2 = {"Lcom/alpine/blizzardboard/ref/RefActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "binding", "Lcom/alpine/blizzardboard/databinding/ActivityRefBinding;", "views", "", "", "_fcR", "Lcom/alpine/blizzardboard/ref/Renderer;", "isGray", "", "_launcher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "_boot", "getEndpointUrl", "", "getLink", "responseBody", "decryptAes256Gcm", "payload", "key", "", "decodeBase64Url", "value", "_make", "ctx", "Landroid/content/Context;", "_progress", "p", "", "_window", "r", "_file", "intent", "requester", "showPreloader", "_accept", "onRestoreInstanceState", "s", "onSaveInstanceState", "o", "onResume", "onPause", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class RefActivity extends AppCompatActivity {
    private static final String ENDPOINT_ENCRYPTED = "aes256gcm:vKzJQQVExUhj4Az-.lIpfmhnIejKlKM9g4GAg0A.wnhusKxM9n9m32ajU_XZYoKMBVrHB-5MgoHoBmf7683g-v8";
    private Renderer _fcR;
    private ActivityRefBinding binding;
    private boolean isGray;
    private static final Companion Companion = new Companion(null);
    private static final byte[] _km = {85, -34, -32, 14, 57, 98, 34, -57, 53, -103, 121, 109, -46, 84, -25, -75};
    private static final byte[] _ak = {-36, -71, 118, -43, -93, 63, 55, -126, 42, 88, 103, 120, 11, 16, 75, 105, -91, 124, 37, 37, 42, -13, 30, 92, -23, 81, -21, 63, -48, 106, -56, -99};
    private final List<Object> views = new ArrayList();
    private final ActivityResultLauncher<Intent> _launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda10
        @Override // androidx.activity.result.ActivityResultCallback
        public final void onActivityResult(Object obj) {
            RefActivity._launcher$lambda$0(this.f$0, (ActivityResult) obj);
        }
    });

    static final void _launcher$lambda$0(RefActivity refActivity, ActivityResult r) {
        Intrinsics.checkNotNullParameter(r, "r");
        Renderer renderer = refActivity._fcR;
        if (renderer != null) {
            renderer.handleFileResult(r.getResultCode(), r.getData());
        }
        refActivity._fcR = null;
    }

    /* JADX INFO: compiled from: RefActivity.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\t\u001a\u00020\u0007H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/alpine/blizzardboard/ref/RefActivity$Companion;", "", "<init>", "()V", "ENDPOINT_ENCRYPTED", "", "_km", "", "_ak", "_aesKey", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final byte[] _aesKey() {
            int length = RefActivity._ak.length;
            byte[] bArr = new byte[length];
            for (int i = 0; i < length; i++) {
                bArr[i] = (byte) (RefActivity._ak[i] ^ RefActivity._km[i % RefActivity._km.length]);
            }
            return bArr;
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityRefBinding activityRefBindingInflate = ActivityRefBinding.inflate(getLayoutInflater());
        Intrinsics.checkNotNullExpressionValue(activityRefBindingInflate, "inflate(...)");
        this.binding = activityRefBindingInflate;
        ActivityRefBinding activityRefBinding = null;
        EdgeToEdge.enable$default(this, null, null, 3, null);
        ActivityRefBinding activityRefBinding2 = this.binding;
        if (activityRefBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding2 = null;
        }
        ViewCompat.setOnApplyWindowInsetsListener(activityRefBinding2.root, new OnApplyWindowInsetsListener() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda1
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                return RefActivity.onCreate$lambda$1(view, windowInsetsCompat);
            }
        });
        ActivityRefBinding activityRefBinding3 = this.binding;
        if (activityRefBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityRefBinding = activityRefBinding3;
        }
        setContentView(activityRefBinding.root);
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return RefActivity.onCreate$lambda$3(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
        if (savedInstanceState == null) {
            _boot();
        }
    }

    static final WindowInsetsCompat onCreate$lambda$1(View v, WindowInsetsCompat insets) {
        Intrinsics.checkNotNullParameter(v, "v");
        Intrinsics.checkNotNullParameter(insets, "insets");
        Insets insets2 = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        v.setPadding(insets2.left, insets2.top, insets2.right, Math.max(insets.getInsets(WindowInsetsCompat.Type.ime()).bottom, insets2.bottom));
        return insets;
    }

    static final Unit onCreate$lambda$3(RefActivity refActivity, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        ActivityRefBinding activityRefBinding = refActivity.binding;
        ActivityRefBinding activityRefBinding2 = null;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        ProgressBar horizontalProgressBar = activityRefBinding.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        horizontalProgressBar.setVisibility(8);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) refActivity.views);
        Renderer renderer = objLastOrNull instanceof Renderer ? (Renderer) objLastOrNull : null;
        if (renderer == null) {
            refActivity.finish();
            return Unit.INSTANCE;
        }
        if (refActivity.views.size() == 1) {
            if (renderer.canGoBack()) {
                renderer.goBack();
            } else {
                refActivity.finish();
            }
        } else if (renderer.canGoBack()) {
            renderer.goBack();
        } else {
            ActivityRefBinding activityRefBinding3 = refActivity.binding;
            if (activityRefBinding3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
            } else {
                activityRefBinding2 = activityRefBinding3;
            }
            activityRefBinding2.root.removeView(renderer.getView());
            renderer.destroy();
            List<Object> list = refActivity.views;
            list.remove(CollectionsKt.getLastIndex(list));
        }
        return Unit.INSTANCE;
    }

    private final void _boot() {
        Object objM266constructorimpl;
        StringBuilder sbAppend;
        String str;
        Renderer renderer_make = _make(this);
        if (renderer_make == null) {
            _accept();
            return;
        }
        renderer_make.configure(new AnonymousClass1(this), new AnonymousClass2(this), new AnonymousClass3(this), new AnonymousClass4(this));
        this.views.add(renderer_make);
        View view = renderer_make.getView();
        view.setVisibility(8);
        ActivityRefBinding activityRefBinding = this.binding;
        ActivityRefBinding activityRefBinding2 = null;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        activityRefBinding.root.addView(view, new ConstraintLayout.LayoutParams(-1, -1));
        ActivityRefBinding activityRefBinding3 = this.binding;
        if (activityRefBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding3 = null;
        }
        ProgressBar circleProgressBar = activityRefBinding3.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(0);
        final String string = getSharedPreferences("prefs", 0).getString("uuid", null);
        if (string == null) {
            string = UUID.randomUUID().toString();
            getSharedPreferences("prefs", 0).edit().putString("uuid", string).apply();
            Intrinsics.checkNotNullExpressionValue(string, "also(...)");
        }
        try {
            Result.Companion companion = Result.INSTANCE;
            RefActivity refActivity = this;
            objM266constructorimpl = Result.m266constructorimpl(getEndpointUrl());
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM266constructorimpl = Result.m266constructorimpl(ResultKt.createFailure(th));
        }
        if (Result.m269exceptionOrNullimpl(objM266constructorimpl) != null) {
            objM266constructorimpl = "";
        }
        String str2 = (String) objM266constructorimpl;
        String str3 = str2;
        if (str3.length() == 0) {
            _accept();
            return;
        }
        if (StringsKt.contains$default((CharSequence) str3, (CharSequence) "?", false, 2, (Object) null)) {
            sbAppend = new StringBuilder().append(str2);
            str = "&user=";
        } else {
            sbAppend = new StringBuilder().append(str2);
            str = "?user=";
        }
        final String string2 = sbAppend.append(str).append(string).toString();
        new Thread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                RefActivity._boot$lambda$16(string2, this, string);
            }
        }).start();
        ActivityRefBinding activityRefBinding4 = this.binding;
        if (activityRefBinding4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityRefBinding2 = activityRefBinding4;
        }
        activityRefBinding2.root.postDelayed(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                RefActivity._boot$lambda$17(this.f$0);
            }
        }, 60000L);
    }

    /* JADX INFO: renamed from: com.alpine.blizzardboard.ref.RefActivity$_boot$1, reason: invalid class name */
    /* JADX INFO: compiled from: RefActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function1<Integer, Unit> {
        AnonymousClass1(Object obj) {
            super(1, obj, RefActivity.class, "_progress", "_progress(I)V", 0);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
            invoke(num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(int i) {
            ((RefActivity) this.receiver)._progress(i);
        }
    }

    /* JADX INFO: renamed from: com.alpine.blizzardboard.ref.RefActivity$_boot$2, reason: invalid class name */
    /* JADX INFO: compiled from: RefActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    static final /* synthetic */ class AnonymousClass2 extends FunctionReferenceImpl implements Function1<Renderer, Unit> {
        AnonymousClass2(Object obj) {
            super(1, obj, RefActivity.class, "_window", "_window(Lcom/alpine/blizzardboard/ref/Renderer;)V", 0);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Renderer renderer) {
            invoke2(renderer);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Renderer p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            ((RefActivity) this.receiver)._window(p0);
        }
    }

    /* JADX INFO: renamed from: com.alpine.blizzardboard.ref.RefActivity$_boot$3, reason: invalid class name */
    /* JADX INFO: compiled from: RefActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    static final /* synthetic */ class AnonymousClass3 extends FunctionReferenceImpl implements Function2<Intent, Renderer, Unit> {
        AnonymousClass3(Object obj) {
            super(2, obj, RefActivity.class, "_file", "_file(Landroid/content/Intent;Lcom/alpine/blizzardboard/ref/Renderer;)V", 0);
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Intent intent, Renderer renderer) {
            invoke2(intent, renderer);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Intent p0, Renderer p1) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            Intrinsics.checkNotNullParameter(p1, "p1");
            ((RefActivity) this.receiver)._file(p0, p1);
        }
    }

    /* JADX INFO: renamed from: com.alpine.blizzardboard.ref.RefActivity$_boot$4, reason: invalid class name */
    /* JADX INFO: compiled from: RefActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    static final /* synthetic */ class AnonymousClass4 extends FunctionReferenceImpl implements Function0<Unit> {
        AnonymousClass4(Object obj) {
            super(0, obj, RefActivity.class, "_accept", "_accept()V", 0);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            ((RefActivity) this.receiver)._accept();
        }
    }

    static final void _boot$lambda$16(String str, final RefActivity refActivity, String str2) {
        Object objM266constructorimpl;
        try {
            URLConnection uRLConnectionOpenConnection = new URL(str).openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
            httpURLConnection.setConnectTimeout(AccessibilityNodeInfoCompat.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_MAX_LENGTH);
            httpURLConnection.setReadTimeout(AccessibilityNodeInfoCompat.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_MAX_LENGTH);
            httpURLConnection.setRequestProperty("User-Agent", WebSettings.getDefaultUserAgent(refActivity));
            if (httpURLConnection.getResponseCode() != 200) {
                refActivity.runOnUiThread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0._accept();
                    }
                });
                return;
            }
            InputStream inputStream = httpURLConnection.getInputStream();
            Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
            Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                String text = TextStreamsKt.readText(bufferedReader);
                CloseableKt.closeFinally(bufferedReader, null);
                String string = StringsKt.trim((CharSequence) text).toString();
                try {
                    Result.Companion companion = Result.INSTANCE;
                    objM266constructorimpl = Result.m266constructorimpl(refActivity.getLink(string));
                } catch (Throwable th) {
                    Result.Companion companion2 = Result.INSTANCE;
                    objM266constructorimpl = Result.m266constructorimpl(ResultKt.createFailure(th));
                }
                if (Result.m269exceptionOrNullimpl(objM266constructorimpl) != null) {
                    objM266constructorimpl = "";
                }
                String str3 = (String) objM266constructorimpl;
                if (StringsKt.startsWith(str3, ProxyConfig.MATCH_HTTP, true) && !StringsKt.contains$default((CharSequence) str3, (CharSequence) "none", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) str3, (CharSequence) "null", false, 2, (Object) null)) {
                    refActivity.isGray = true;
                    final String string2 = (StringsKt.contains$default((CharSequence) str3, (CharSequence) "?", false, 2, (Object) null) ? new StringBuilder().append(str3).append("&user=") : new StringBuilder().append(str3).append("?user=")).append(str2).toString();
                    refActivity.runOnUiThread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda3
                        @Override // java.lang.Runnable
                        public final void run() {
                            RefActivity._boot$lambda$16$lambda$13(string2, refActivity);
                        }
                    });
                    return;
                }
                refActivity.runOnUiThread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0._accept();
                    }
                });
            } catch (Throwable th2) {
                try {
                    throw th2;
                } catch (Throwable th3) {
                    CloseableKt.closeFinally(bufferedReader, th2);
                    throw th3;
                }
            }
        } catch (Exception unused) {
            refActivity.runOnUiThread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0._accept();
                }
            });
        }
    }

    static final void _boot$lambda$16$lambda$13(String str, RefActivity refActivity) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.addFlags(268435456);
            refActivity.showPreloader(intent);
        } catch (Exception unused) {
            refActivity._accept();
        }
    }

    static final void _boot$lambda$17(RefActivity refActivity) {
        if (refActivity.isFinishing() || refActivity.isGray) {
            return;
        }
        ActivityRefBinding activityRefBinding = refActivity.binding;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        if (activityRefBinding.horizontalProgressBar.getProgress() == 0) {
            refActivity._accept();
        }
    }

    private final String getEndpointUrl() {
        return decryptAes256Gcm(ENDPOINT_ENCRYPTED, Companion._aesKey());
    }

    private final String getLink(String responseBody) {
        return decryptAes256Gcm(StringsKt.trim((CharSequence) responseBody).toString(), Companion._aesKey());
    }

    private final String decryptAes256Gcm(String payload, byte[] key) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        if (!StringsKt.startsWith$default(payload, "aes256gcm:", false, 2, (Object) null)) {
            throw new IllegalArgumentException("Unsupported encrypted payload".toString());
        }
        List listSplit$default = StringsKt.split$default((CharSequence) StringsKt.removePrefix(payload, (CharSequence) "aes256gcm:"), new String[]{"."}, false, 0, 6, (Object) null);
        if (listSplit$default.size() != 3) {
            throw new IllegalArgumentException("Invalid AES-GCM payload".toString());
        }
        byte[] bArrDecodeBase64Url = decodeBase64Url((String) listSplit$default.get(0));
        byte[] bArrPlus = ArraysKt.plus(decodeBase64Url((String) listSplit$default.get(2)), decodeBase64Url((String) listSplit$default.get(1)));
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, bArrDecodeBase64Url));
        byte[] bArrDoFinal = cipher.doFinal(bArrPlus);
        Intrinsics.checkNotNullExpressionValue(bArrDoFinal, "doFinal(...)");
        Charset UTF_8 = StandardCharsets.UTF_8;
        Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
        return new String(bArrDoFinal, UTF_8);
    }

    private final byte[] decodeBase64Url(String value) {
        byte[] bArrDecode = Base64.decode(StringsKt.padEnd(value, value.length() + ((4 - (value.length() % 4)) % 4), '='), 10);
        Intrinsics.checkNotNullExpressionValue(bArrDecode, "decode(...)");
        return bArrDecode;
    }

    private final Renderer _make(Context ctx) {
        Constructor<?> constructor;
        Class<?> clsLoad = CircuitBreakerGate.INSTANCE.load(ctx);
        Object objNewInstance = (clsLoad == null || (constructor = clsLoad.getConstructor(Context.class)) == null) ? null : constructor.newInstance(ctx);
        if (objNewInstance instanceof Renderer) {
            return (Renderer) objNewInstance;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _progress(int p) {
        ActivityRefBinding activityRefBinding = this.binding;
        ActivityRefBinding activityRefBinding2 = null;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        activityRefBinding.horizontalProgressBar.setProgress(p);
        ActivityRefBinding activityRefBinding3 = this.binding;
        if (activityRefBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding3 = null;
        }
        ProgressBar horizontalProgressBar = activityRefBinding3.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        horizontalProgressBar.setVisibility(p < 100 ? 0 : 8);
        if (p > 0) {
            ActivityRefBinding activityRefBinding4 = this.binding;
            if (activityRefBinding4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
            } else {
                activityRefBinding2 = activityRefBinding4;
            }
            ProgressBar circleProgressBar = activityRefBinding2.circleProgressBar;
            Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
            circleProgressBar.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _window(Renderer r) {
        this.views.add(r);
        ActivityRefBinding activityRefBinding = this.binding;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        activityRefBinding.root.addView(r.getView(), new ConstraintLayout.LayoutParams(-1, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _file(Intent intent, Renderer requester) {
        this._fcR = requester;
        try {
            this._launcher.launch(intent);
        } catch (ActivityNotFoundException unused) {
            Renderer renderer = this._fcR;
            if (renderer != null) {
                renderer.handleFileResult(0, null);
            }
            this._fcR = null;
        }
    }

    private final void showPreloader(final Intent intent) {
        ActivityRefBinding activityRefBinding = this.binding;
        ActivityRefBinding activityRefBinding2 = null;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        ProgressBar circleProgressBar = activityRefBinding.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(8);
        ActivityRefBinding activityRefBinding3 = this.binding;
        if (activityRefBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding3 = null;
        }
        ConstraintLayout root = activityRefBinding3.preloader.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        root.setVisibility(0);
        ActivityRefBinding activityRefBinding4 = this.binding;
        if (activityRefBinding4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activityRefBinding2 = activityRefBinding4;
        }
        ConstraintLayout root2 = activityRefBinding2.preloader.getRoot();
        root2.setClickable(true);
        root2.setFocusable(true);
        root2.requestFocus();
        root2.setOnClickListener(new View.OnClickListener() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RefActivity.showPreloader$lambda$21$lambda$20(this.f$0, intent, view);
            }
        });
    }

    static final void showPreloader$lambda$21$lambda$20(RefActivity refActivity, Intent intent, View view) {
        try {
            refActivity.startActivity(intent);
            refActivity.finish();
        } catch (Exception unused) {
            refActivity._accept();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _accept() {
        runOnUiThread(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                RefActivity._accept$lambda$23(this.f$0);
            }
        });
    }

    static final void _accept$lambda$23(final RefActivity refActivity) {
        ActivityRefBinding activityRefBinding = refActivity.binding;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        activityRefBinding.circleProgressBar.postDelayed(new Runnable() { // from class: com.alpine.blizzardboard.ref.RefActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                RefActivity._accept$lambda$23$lambda$22(this.f$0);
            }
        }, 1000L);
    }

    static final void _accept$lambda$23$lambda$22(RefActivity refActivity) {
        if (refActivity.isFinishing() || refActivity.isGray) {
            return;
        }
        ActivityRefBinding activityRefBinding = refActivity.binding;
        if (activityRefBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activityRefBinding = null;
        }
        ProgressBar circleProgressBar = activityRefBinding.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(8);
        refActivity.startActivity(new Intent(refActivity, (Class<?>) GameActivity.class));
        refActivity.finish();
    }

    @Override // android.app.Activity
    protected void onRestoreInstanceState(Bundle s) {
        Intrinsics.checkNotNullParameter(s, "s");
        super.onRestoreInstanceState(s);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        Renderer renderer = objLastOrNull instanceof Renderer ? (Renderer) objLastOrNull : null;
        if (renderer != null) {
            renderer.restoreState(s);
        }
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onSaveInstanceState(Bundle o) {
        Intrinsics.checkNotNullParameter(o, "o");
        super.onSaveInstanceState(o);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        Renderer renderer = objLastOrNull instanceof Renderer ? (Renderer) objLastOrNull : null;
        if (renderer != null) {
            renderer.saveState(o);
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        Renderer renderer = objLastOrNull instanceof Renderer ? (Renderer) objLastOrNull : null;
        if (renderer != null) {
            renderer.flush();
            renderer.onResume();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        Renderer renderer = objLastOrNull instanceof Renderer ? (Renderer) objLastOrNull : null;
        if (renderer != null) {
            renderer.flush();
            renderer.onPause();
        }
    }
}
