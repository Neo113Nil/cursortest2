package com.alpine.blizzardboard.ref;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.alpine.blizzardboard.ref.dsp.LayoutCardView;
import dalvik.system.InMemoryDexClassLoader;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.ArraysKt;
import kotlin.io.ByteStreamsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* JADX INFO: compiled from: CircuitBreakerGate.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÀ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0002J\b\u0010\t\u001a\u00020\bH\u0002J\u0014\u0010\n\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u000b2\u0006\u0010\f\u001a\u00020\rJ\u0018\u0010\u000e\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\bH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/alpine/blizzardboard/ref/CircuitBreakerGate;", "", "<init>", "()V", "ASSET", "", "_t", "data", "", "_key", "load", "Ljava/lang/Class;", "ctx", "Landroid/content/Context;", "gcmDecrypt", "key", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public final class CircuitBreakerGate {
    private static final String ASSET = "ds.bin";
    public static final CircuitBreakerGate INSTANCE = new CircuitBreakerGate();

    private CircuitBreakerGate() {
    }

    private final String _t(byte[] data) {
        byte[] bArr = new byte[data.length];
        int length = data.length;
        for (int i = 0; i < length; i++) {
            bArr[i] = (byte) (data[i] ^ LayoutCardView.FirebaseWidget.INSTANCE.getKm()[i % LayoutCardView.FirebaseWidget.INSTANCE.getKm().length]);
        }
        return new String(bArr, Charsets.UTF_8);
    }

    private final byte[] _key() {
        byte[] bArr = new byte[32];
        for (int i = 0; i < 32; i++) {
            bArr[i] = (byte) (LayoutCardView.FirebaseWidget.INSTANCE.getAk()[i] ^ LayoutCardView.FirebaseWidget.INSTANCE.getKm()[i % LayoutCardView.FirebaseWidget.INSTANCE.getKm().length]);
        }
        return bArr;
    }

    public final Class<?> load(Context ctx) {
        Object objM266constructorimpl;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        try {
            Result.Companion companion = Result.INSTANCE;
            CircuitBreakerGate circuitBreakerGate = this;
            InputStream inputStreamOpen = ctx.getAssets().open(ASSET);
            try {
                InputStream inputStream = inputStreamOpen;
                Intrinsics.checkNotNull(inputStream);
                byte[] bytes = ByteStreamsKt.readBytes(inputStream);
                CloseableKt.closeFinally(inputStreamOpen, null);
                objM266constructorimpl = Result.m266constructorimpl(new InMemoryDexClassLoader(ByteBuffer.wrap(gcmDecrypt(bytes, _key())), ctx.getClassLoader()).loadClass(_t(LayoutCardView.FirebaseWidget.INSTANCE.getT())));
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    CloseableKt.closeFinally(inputStreamOpen, th);
                    throw th2;
                }
            }
        } catch (Throwable th3) {
            Result.Companion companion2 = Result.INSTANCE;
            objM266constructorimpl = Result.m266constructorimpl(ResultKt.createFailure(th3));
        }
        return (Class) (Result.m272isFailureimpl(objM266constructorimpl) ? null : objM266constructorimpl);
    }

    private final byte[] gcmDecrypt(byte[] data, byte[] key) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        byte[] bArrCopyOfRange = ArraysKt.copyOfRange(data, 0, 12);
        byte[] bArrCopyOfRange2 = ArraysKt.copyOfRange(data, 12, data.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, bArrCopyOfRange));
        byte[] bArrDoFinal = cipher.doFinal(bArrCopyOfRange2);
        Intrinsics.checkNotNullExpressionValue(bArrDoFinal, "doFinal(...)");
        return bArrDoFinal;
    }
}
