package com.alpine.blizzardboard.ref.dsp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.alpine.blizzardboard.ref.Renderer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: DataSyncProvider.kt */
/* JADX INFO: loaded from: /tmp/ds.dex */
@Metadata(d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0012\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u001b\u001a\u00020\u001cH\u0016JX\u0010\u001d\u001a\u00020\r2\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r0\u00122\u0012\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\r0\u00122\u0018\u0010 \u001a\u0014\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\r0\u000f2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\r0\fH\u0016J\u0010\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020\u0016H\u0002J\u0018\u0010%\u001a\u00020\u00162\u0006\u0010\u001e\u001a\u00020\u00162\u0006\u0010&\u001a\u00020\u0016H\u0002J\b\u0010'\u001a\u00020\rH\u0016J\b\u0010(\u001a\u00020\rH\u0016J\u0010\u0010)\u001a\u00020\u00162\u0006\u0010*\u001a\u00020\u0016H\u0016J\b\u0010+\u001a\u00020\u0016H\u0016J\b\u0010,\u001a\u00020-H\u0016J\b\u0010.\u001a\u00020\rH\u0016J\u001a\u0010/\u001a\u00020\r2\u0006\u00100\u001a\u00020\u00142\b\u00101\u001a\u0004\u0018\u00010\u0010H\u0016J\b\u00102\u001a\u00020\rH\u0016J\b\u00103\u001a\u00020\rH\u0016J\u0010\u00104\u001a\u00020\r2\u0006\u00105\u001a\u00020\u0016H\u0016J\u0010\u00106\u001a\u00020\r2\u0006\u00107\u001a\u000208H\u0016J\u0010\u00109\u001a\u00020\r2\u0006\u0010:\u001a\u000208H\u0016R\u001c\u0010\u0005\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0016\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010\u000e\u001a\u0016\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\r\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0011\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\r\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0013\u001a\u0010\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\r\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0016X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0016X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/alpine/blizzardboard/ref/dsp/DataSyncProvider;", "Lcom/alpine/blizzardboard/ref/Renderer;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "_fileCallback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "getContext", "()Landroid/content/Context;", "onAccept", "Lkotlin/Function0;", "", "onFileChooser", "Lkotlin/Function2;", "Landroid/content/Intent;", "onNewRenderer", "Lkotlin/Function1;", "onProgress", "", "p1", "", "p2", "p3", "webView", "Landroid/webkit/WebView;", "canGoBack", "", "configure", "p", "n", "f", "a", "db", "", "v", "decrypt", "k", "destroy", "flush", "getFinalUrl", "response", "getStartUrl", "getView", "Landroid/view/View;", "goBack", "handleFileResult", "resultCode", "data", "onPause", "onResume", "open", "target", "restoreState", "savedState", "Landroid/os/Bundle;", "saveState", "outState"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DataSyncProvider implements Renderer {
    private ValueCallback<Uri[]> _fileCallback;
    private final Context context;
    private Function0<Unit> onAccept;
    private Function2<? super Intent, ? super Renderer, Unit> onFileChooser;
    private Function1<? super Renderer, Unit> onNewRenderer;
    private Function1<? super Integer, Unit> onProgress;
    private final String p1;
    private final String p2;
    private final String p3;
    private final WebView webView;

    public DataSyncProvider(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.p1 = "aes256gcm:P6F8Y4stTUvA5aF8.";
        this.p2 = "jWjkrpHXRGq2iD2m63CjqA.";
        this.p3 = "7pVy0eFD8J-05CbReKrafWPQufs8O6sIFW1WbZoVp0fh9w";
        final WebView $this$webView_u24lambda_u242 = new WebView(this.context);
        $this$webView_u24lambda_u242.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        $this$webView_u24lambda_u242.setBackgroundColor(-16777216);
        WebSettings $this$webView_u24lambda_u242_u24lambda_u240 = $this$webView_u24lambda_u242.getSettings();
        $this$webView_u24lambda_u242_u24lambda_u240.setJavaScriptEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setDomStorageEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setDatabaseEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setUseWideViewPort(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setLoadWithOverviewMode(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setJavaScriptCanOpenWindowsAutomatically(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowFileAccess(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowContentAccess(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setCacheMode(-1);
        $this$webView_u24lambda_u242_u24lambda_u240.setSupportMultipleWindows(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setMixedContentMode(0);
        $this$webView_u24lambda_u242_u24lambda_u240.setUserAgentString(WebSettings.getDefaultUserAgent($this$webView_u24lambda_u242.getContext()));
        $this$webView_u24lambda_u242.setDownloadListener(new DownloadListener() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$$ExternalSyntheticLambda0
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                DataSyncProvider.webView$lambda$2$lambda$1($this$webView_u24lambda_u242, str, str2, str3, str4, j);
            }
        });
        $this$webView_u24lambda_u242.setWebViewClient(new WebViewClient() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$3
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                boolean z;
                boolean z2;
                boolean z3;
                Intrinsics.checkNotNullParameter(view, "view");
                Intrinsics.checkNotNullParameter(request, "request");
                String url = request.getUrl().toString();
                Intrinsics.checkNotNullExpressionValue(url, "toString(...)");
                if (StringsKt.startsWith$default(url, "diia://", false, 2, (Object) null) || StringsKt.contains$default(url, "diia.gov.ua", false, 2, (Object) null)) {
                    boolean z4 = true;
                    try {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                        if ($this$webView_u24lambda_u242.getContext().getPackageManager().resolveActivity(intent, 0) != null) {
                            $this$webView_u24lambda_u242.getContext().startActivity(intent);
                        } else {
                            $this$webView_u24lambda_u242.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=ua.gov.diia.app")));
                        }
                    } catch (Exception e) {
                        try {
                            $this$webView_u24lambda_u242.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=ua.gov.diia.app")));
                        } catch (Exception e2) {
                        }
                    }
                    return z4;
                }
                if (StringsKt.startsWith$default(url, "http://", false, 2, (Object) null) || StringsKt.startsWith$default(url, "https://", false, 2, (Object) null)) {
                    Iterable $this$any$iv = socialList();
                    if (!($this$any$iv instanceof Collection) || !((Collection) $this$any$iv).isEmpty()) {
                        Iterator it = $this$any$iv.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                z = true;
                                z2 = false;
                                break;
                            }
                            Object element$iv = it.next();
                            String it2 = (String) element$iv;
                            z = true;
                            Iterable $this$any$iv2 = $this$any$iv;
                            if (StringsKt.contains$default(url, it2, false, 2, (Object) null)) {
                                z2 = true;
                                break;
                            }
                            $this$any$iv = $this$any$iv2;
                        }
                    } else {
                        z2 = false;
                        z = true;
                    }
                    if (!z2) {
                        return false;
                    }
                    try {
                        $this$webView_u24lambda_u242.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                        return z;
                    } catch (Exception e3) {
                        return false;
                    }
                }
                Iterable schemes = CollectionsKt.listOf(new String[]{"whatsapp://", "viber://", "tg://", "line://", "fb-messenger://", "instagram://", "tel:", "mailto:"});
                Iterable $this$any$iv3 = schemes;
                if (!($this$any$iv3 instanceof Collection) || !((Collection) $this$any$iv3).isEmpty()) {
                    Iterator it3 = $this$any$iv3.iterator();
                    while (true) {
                        if (it3.hasNext()) {
                            Object element$iv2 = it3.next();
                            String it4 = (String) element$iv2;
                            if (StringsKt.startsWith$default(url, it4, false, 2, (Object) null)) {
                                z3 = true;
                                break;
                            }
                        } else {
                            z3 = false;
                            break;
                        }
                    }
                } else {
                    z3 = false;
                }
                if (z3) {
                    try {
                        $this$webView_u24lambda_u242.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                        return true;
                    } catch (Exception e4) {
                        return false;
                    }
                }
                try {
                    Intent intent2 = Intent.parseUri(url, 1);
                    intent2.addCategory("android.intent.category.BROWSABLE");
                    intent2.setComponent(null);
                    intent2.setSelector(null);
                    if ($this$webView_u24lambda_u242.getContext().getPackageManager().resolveActivity(intent2, 0) != null) {
                        $this$webView_u24lambda_u242.getContext().startActivity(intent2);
                        return true;
                    }
                    String fallbackUrl = intent2.getStringExtra("browser_fallback_url");
                    if (fallbackUrl != null) {
                        view.loadUrl(fallbackUrl);
                        return true;
                    }
                    return true;
                } catch (Exception e5) {
                }
            }

            private final List<String> socialList() {
                return CollectionsKt.listOf(new String[]{"t.me", "viber.com", "viber.click", "whatsapp.com", "wa.me", "line.me", "facebook.com", "messenger.com", "instagram.com"});
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                CookieManager.getInstance().flush();
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Function0 function0;
                if (!Intrinsics.areEqual(failingUrl, view != null ? view.getUrl() : null) || (function0 = this.onAccept) == null) {
                    return;
                }
                function0.invoke();
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Function0 function0;
                boolean isMainFrame = request != null ? request.isForMainFrame() : false;
                if (!isMainFrame || (function0 = this.onAccept) == null) {
                    return;
                }
                function0.invoke();
            }
        });
        $this$webView_u24lambda_u242.setWebChromeClient(new WebChromeClient() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$4
            @Override // android.webkit.WebChromeClient
            public void onProgressChanged(WebView view, int newProgress) {
                Intrinsics.checkNotNullParameter(view, "view");
                Function1 function1 = this.this$0.onProgress;
                if (function1 != null) {
                    function1.invoke(Integer.valueOf(newProgress));
                }
            }

            @Override // android.webkit.WebChromeClient
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> f, WebChromeClient.FileChooserParams p) {
                Intrinsics.checkNotNullParameter(v, "v");
                Intrinsics.checkNotNullParameter(f, "f");
                Intrinsics.checkNotNullParameter(p, "p");
                this.this$0._fileCallback = f;
                Function2 function2 = this.this$0.onFileChooser;
                if (function2 != null) {
                    Intent intentCreateIntent = p.createIntent();
                    Intrinsics.checkNotNullExpressionValue(intentCreateIntent, "createIntent(...)");
                    function2.invoke(intentCreateIntent, this.this$0);
                    return true;
                }
                return true;
            }

            @Override // android.webkit.WebChromeClient
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                Intrinsics.checkNotNullParameter(view, "view");
                Intrinsics.checkNotNullParameter(resultMsg, "resultMsg");
                Context context2 = $this$webView_u24lambda_u242.getContext();
                Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
                DataSyncProvider newRenderer = new DataSyncProvider(context2);
                DataSyncProvider$webView$1$4$onCreateWindow$1 dataSyncProvider$webView$1$4$onCreateWindow$1 = this.this$0.onProgress;
                if (dataSyncProvider$webView$1$4$onCreateWindow$1 == null) {
                    dataSyncProvider$webView$1$4$onCreateWindow$1 = new Function1<Integer, Unit>() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$4$onCreateWindow$1
                        public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                            invoke(((Number) p1).intValue());
                            return Unit.INSTANCE;
                        }

                        public final void invoke(int i) {
                        }
                    };
                }
                DataSyncProvider$webView$1$4$onCreateWindow$2 dataSyncProvider$webView$1$4$onCreateWindow$2 = this.this$0.onNewRenderer;
                if (dataSyncProvider$webView$1$4$onCreateWindow$2 == null) {
                    dataSyncProvider$webView$1$4$onCreateWindow$2 = new Function1<Renderer, Unit>() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$4$onCreateWindow$2
                        public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                            invoke((Renderer) p1);
                            return Unit.INSTANCE;
                        }

                        public final void invoke(Renderer renderer) {
                            Intrinsics.checkNotNullParameter(renderer, "<anonymous parameter 0>");
                        }
                    };
                }
                DataSyncProvider$webView$1$4$onCreateWindow$3 dataSyncProvider$webView$1$4$onCreateWindow$3 = this.this$0.onFileChooser;
                if (dataSyncProvider$webView$1$4$onCreateWindow$3 == null) {
                    dataSyncProvider$webView$1$4$onCreateWindow$3 = new Function2<Intent, Renderer, Unit>() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$4$onCreateWindow$3
                        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
                            invoke((Intent) p1, (Renderer) p2);
                            return Unit.INSTANCE;
                        }

                        public final void invoke(Intent intent, Renderer renderer) {
                            Intrinsics.checkNotNullParameter(intent, "<anonymous parameter 0>");
                            Intrinsics.checkNotNullParameter(renderer, "<anonymous parameter 1>");
                        }
                    };
                }
                DataSyncProvider$webView$1$4$onCreateWindow$4 dataSyncProvider$webView$1$4$onCreateWindow$4 = this.this$0.onAccept;
                if (dataSyncProvider$webView$1$4$onCreateWindow$4 == null) {
                    dataSyncProvider$webView$1$4$onCreateWindow$4 = new Function0<Unit>() { // from class: com.alpine.blizzardboard.ref.dsp.DataSyncProvider$webView$1$4$onCreateWindow$4
                        public /* bridge */ /* synthetic */ Object invoke() {
                            m0invoke();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                        public final void m0invoke() {
                        }
                    };
                }
                newRenderer.configure(dataSyncProvider$webView$1$4$onCreateWindow$1, dataSyncProvider$webView$1$4$onCreateWindow$2, dataSyncProvider$webView$1$4$onCreateWindow$3, dataSyncProvider$webView$1$4$onCreateWindow$4);
                Object obj = resultMsg.obj;
                Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type android.webkit.WebView.WebViewTransport");
                WebView.WebViewTransport transport = (WebView.WebViewTransport) obj;
                transport.setWebView(newRenderer.webView);
                resultMsg.sendToTarget();
                Function1 function1 = this.this$0.onNewRenderer;
                if (function1 != null) {
                    function1.invoke(newRenderer);
                    return true;
                }
                return true;
            }
        });
        this.webView = $this$webView_u24lambda_u242;
    }

    public final Context getContext() {
        return this.context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void webView$lambda$2$lambda$1(WebView $this_apply, String url, String str, String str2, String str3, long j) {
        Intrinsics.checkNotNullParameter($this_apply, "$this_apply");
        try {
            $this_apply.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        } catch (Exception e) {
        }
    }

    public String getStartUrl() {
        return decrypt(this.p1 + this.p2 + this.p3, new _WebkitDelegates().getConfigurationToken());
    }

    public String getFinalUrl(String response) {
        Intrinsics.checkNotNullParameter(response, "response");
        return decrypt(StringsKt.trim(response).toString(), new _WebkitDelegates().getConfigurationToken());
    }

    private final String decrypt(String p, String k) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        if (!StringsKt.startsWith$default(p, "aes256gcm:", false, 2, (Object) null)) {
            return "";
        }
        List parts = StringsKt.split$default(StringsKt.removePrefix(p, "aes256gcm:"), new String[]{"."}, false, 0, 6, (Object) null);
        if (parts.size() != 3) {
            return "";
        }
        byte[] iv = db((String) parts.get(0));
        byte[] tag = db((String) parts.get(1));
        byte[] enc = db((String) parts.get(2));
        byte[] key = db(k);
        byte[] combined = new byte[enc.length + tag.length];
        System.arraycopy(enc, 0, combined, 0, enc.length);
        System.arraycopy(tag, 0, combined, enc.length, tag.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
        byte[] bArrDoFinal = cipher.doFinal(combined);
        Intrinsics.checkNotNullExpressionValue(bArrDoFinal, "doFinal(...)");
        Charset charset = StandardCharsets.UTF_8;
        Intrinsics.checkNotNullExpressionValue(charset, "UTF_8");
        return new String(bArrDoFinal, charset);
    }

    private final byte[] db(String v) {
        String s = v;
        while (s.length() % 4 != 0) {
            s = s + '=';
        }
        byte[] bArrDecode = Base64.decode(s, 10);
        Intrinsics.checkNotNullExpressionValue(bArrDecode, "decode(...)");
        return bArrDecode;
    }

    public void open(String target) {
        Intrinsics.checkNotNullParameter(target, "target");
        this.webView.loadUrl(target);
    }

    public void goBack() {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        }
    }

    public boolean canGoBack() {
        return this.webView.canGoBack();
    }

    public void destroy() {
        this.webView.stopLoading();
        this.webView.destroy();
    }

    public View getView() {
        return this.webView;
    }

    public void onResume() {
        this.webView.onResume();
    }

    public void onPause() {
        this.webView.onPause();
    }

    public void flush() {
        CookieManager.getInstance().flush();
    }

    public void saveState(Bundle outState) {
        Intrinsics.checkNotNullParameter(outState, "outState");
        this.webView.saveState(outState);
    }

    public void restoreState(Bundle savedState) {
        Intrinsics.checkNotNullParameter(savedState, "savedState");
        this.webView.restoreState(savedState);
    }

    public void handleFileResult(int resultCode, Intent data) {
        ValueCallback<Uri[]> valueCallback = this._fileCallback;
        if (valueCallback != null) {
            valueCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
        }
        this._fileCallback = null;
    }

    public void configure(Function1<? super Integer, Unit> p, Function1<? super Renderer, Unit> n, Function2<? super Intent, ? super Renderer, Unit> f, Function0<Unit> a) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(n, "n");
        Intrinsics.checkNotNullParameter(f, "f");
        Intrinsics.checkNotNullParameter(a, "a");
        this.onProgress = p;
        this.onNewRenderer = n;
        this.onFileChooser = f;
        this.onAccept = a;
    }
}
