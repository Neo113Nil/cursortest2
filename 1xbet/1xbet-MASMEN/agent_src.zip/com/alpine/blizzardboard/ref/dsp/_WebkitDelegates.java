package com.alpine.blizzardboard.ref.dsp;

import kotlin.Metadata;

/* JADX INFO: compiled from: _WebkitDelegates.kt */
/* JADX INFO: loaded from: /tmp/ds.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0007\u001a\u00020\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082D¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/alpine/blizzardboard/ref/dsp/_WebkitDelegates;", "", "()V", "k1", "", "k2", "k3", "getConfigurationToken"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class _WebkitDelegates {
    private final String k1 = "gnmMcROwwLyWjWrN";
    private final String k2 = "CktZ59xTOMIp7rkK";
    private final String k3 = "Dfs8T_Yl_r8";

    public final String getConfigurationToken() {
        return this.k1 + this.k2 + this.k3;
    }
}
