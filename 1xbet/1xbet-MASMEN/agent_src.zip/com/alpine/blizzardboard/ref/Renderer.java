package com.alpine.blizzardboard.ref;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: Renderer.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0003H&J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0003H&J\b\u0010\t\u001a\u00020\u0007H&J\b\u0010\n\u001a\u00020\u000bH&J\b\u0010\f\u001a\u00020\u0007H&J\b\u0010\r\u001a\u00020\u000eH&J\b\u0010\u000f\u001a\u00020\u0007H&J\b\u0010\u0010\u001a\u00020\u0007H&J\b\u0010\u0011\u001a\u00020\u0007H&J\u0010\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0014H&J\u0010\u0010\u0015\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u0014H&J\u001a\u0010\u0017\u001a\u00020\u00072\u0006\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH&JX\u0010\u001c\u001a\u00020\u00072\u0012\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u00070\u001e2\u0012\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00070\u001e2\u0018\u0010 \u001a\u0014\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00070!2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00070#H&¨\u0006$À\u0006\u0003"}, d2 = {"Lcom/alpine/blizzardboard/ref/Renderer;", "", "getStartUrl", "", "getFinalUrl", "response", "open", "", TypedValues.AttributesType.S_TARGET, "goBack", "canGoBack", "", "destroy", "getView", "Landroid/view/View;", "onResume", "onPause", "flush", "saveState", "outState", "Landroid/os/Bundle;", "restoreState", "savedState", "handleFileResult", "resultCode", "", "data", "Landroid/content/Intent;", "configure", "onProgress", "Lkotlin/Function1;", "onNewRenderer", "onFileChooser", "Lkotlin/Function2;", "onAccept", "Lkotlin/Function0;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
public interface Renderer {
    boolean canGoBack();

    void configure(Function1<? super Integer, Unit> onProgress, Function1<? super Renderer, Unit> onNewRenderer, Function2<? super Intent, ? super Renderer, Unit> onFileChooser, Function0<Unit> onAccept);

    void destroy();

    void flush();

    String getFinalUrl(String response);

    String getStartUrl();

    View getView();

    void goBack();

    void handleFileResult(int resultCode, Intent data);

    void onPause();

    void onResume();

    void open(String target);

    void restoreState(Bundle savedState);

    void saveState(Bundle outState);
}
