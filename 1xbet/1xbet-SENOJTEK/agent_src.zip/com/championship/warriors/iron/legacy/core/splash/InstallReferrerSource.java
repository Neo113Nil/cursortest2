package com.championship.warriors.iron.legacy.core.splash;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__BuildersKt;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;

/* compiled from: Ref.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u0006\u001a\u00020\u0007H\u0096@¢\u0006\u0002\u0010\bJ\u0010\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/InstallReferrerSource;", "Lcom/championship/warriors/iron/legacy/core/splash/ReferrerSource;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "get", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getBlocking", "timeoutMs", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class InstallReferrerSource implements ReferrerSource {
    private final Context context;

    public InstallReferrerSource(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    /* compiled from: Ref.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.core.splash.InstallReferrerSource$get$2", f = "Ref.kt", i = {0}, l = {70}, m = "invokeSuspend", n = {"$i$f$suspendCancellableCoroutine"}, s = {"I$0"})
    /* renamed from: com.championship.warriors.iron.legacy.core.splash.InstallReferrerSource$get$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
        int I$0;
        Object L$0;
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return InstallReferrerSource.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i != 0) {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                return obj;
            }
            ResultKt.throwOnFailure(obj);
            InstallReferrerSource installReferrerSource = InstallReferrerSource.this;
            this.L$0 = installReferrerSource;
            this.I$0 = 0;
            this.label = 1;
            AnonymousClass2 anonymousClass2 = this;
            CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(anonymousClass2), 1);
            cancellableContinuationImpl.initCancellability();
            final CancellableContinuationImpl cancellableContinuationImpl2 = cancellableContinuationImpl;
            final InstallReferrerClient installReferrerClientBuild = InstallReferrerClient.newBuilder(installReferrerSource.context).build();
            installReferrerClientBuild.startConnection(new InstallReferrerStateListener() { // from class: com.championship.warriors.iron.legacy.core.splash.InstallReferrerSource$get$2$1$1
                @Override // com.android.installreferrer.api.InstallReferrerStateListener
                public void onInstallReferrerServiceDisconnected() {
                }

                /* JADX WARN: Removed duplicated region for block: B:6:0x0010  */
                @Override // com.android.installreferrer.api.InstallReferrerStateListener
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public void onInstallReferrerSetupFinished(int responseCode) {
                    if (responseCode == 0) {
                        try {
                            try {
                                String installReferrer = installReferrerClientBuild.getInstallReferrer().getInstallReferrer();
                                if (installReferrer == null) {
                                    installReferrer = "";
                                }
                                if (cancellableContinuationImpl2.isActive()) {
                                    CancellableContinuation<String> cancellableContinuation = cancellableContinuationImpl2;
                                    Result.Companion companion = Result.INSTANCE;
                                    cancellableContinuation.resumeWith(Result.m478constructorimpl(installReferrer));
                                }
                            } finally {
                                installReferrerClientBuild.endConnection();
                            }
                        } catch (Throwable unused) {
                            if (cancellableContinuationImpl2.isActive()) {
                                CancellableContinuation<String> cancellableContinuation2 = cancellableContinuationImpl2;
                                Result.Companion companion2 = Result.INSTANCE;
                                cancellableContinuation2.resumeWith(Result.m478constructorimpl(""));
                            }
                        }
                    }
                }
            });
            cancellableContinuationImpl2.invokeOnCancellation(new Function1<Throwable, Unit>() { // from class: com.championship.warriors.iron.legacy.core.splash.InstallReferrerSource$get$2$1$2
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Throwable th) {
                    invoke2(th);
                    return Unit.INSTANCE;
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(Throwable th) {
                    try {
                        installReferrerClientBuild.endConnection();
                    } catch (Throwable unused) {
                    }
                }
            });
            Object result = cancellableContinuationImpl.getResult();
            if (result == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                DebugProbesKt.probeCoroutineSuspended(anonymousClass2);
            }
            return result == coroutine_suspended ? coroutine_suspended : result;
        }
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ReferrerSource
    public Object get(Continuation<? super String> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(null), continuation);
    }

    public static /* synthetic */ String getBlocking$default(InstallReferrerSource installReferrerSource, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            j = 2500;
        }
        return installReferrerSource.getBlocking(j);
    }

    public final String getBlocking(long timeoutMs) {
        Object objM478constructorimpl;
        try {
            Result.Companion companion = Result.INSTANCE;
            InstallReferrerSource installReferrerSource = this;
            objM478constructorimpl = Result.m478constructorimpl((String) BuildersKt__BuildersKt.runBlocking$default(null, new InstallReferrerSource$getBlocking$1$1(timeoutMs, this, null), 1, null));
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
        }
        String str = (String) (Result.m484isFailureimpl(objM478constructorimpl) ? null : objM478constructorimpl);
        return str == null ? "" : str;
    }
}
