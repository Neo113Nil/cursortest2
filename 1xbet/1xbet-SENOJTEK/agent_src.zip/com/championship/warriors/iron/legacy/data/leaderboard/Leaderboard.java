package com.championship.warriors.iron.legacy.data.leaderboard;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Leaderboard.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001c\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\u00052\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011R \u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\t\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\n\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u000b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/leaderboard/Leaderboard;", "", "<init>", "()V", "scoreRivals", "", "Lkotlin/Pair;", "", "", "distanceRivals", "challengeRivals", "tournamentRivals", "entries", "Lcom/championship/warriors/iron/legacy/data/leaderboard/LeaderboardEntry;", "board", "Lcom/championship/warriors/iron/legacy/data/leaderboard/LeaderboardBoard;", "state", "Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Leaderboard {
    public static final Leaderboard INSTANCE = new Leaderboard();
    private static final List<Pair<String, Integer>> scoreRivals = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Blaze", 12800), TuplesKt.to("Titan", 10450), TuplesKt.to("Nova", 9100), TuplesKt.to("Apex", 7600), TuplesKt.to("Storm", 6200), TuplesKt.to("Vega", 4800), TuplesKt.to("Kova", 3500), TuplesKt.to("Milo", 2400)});
    private static final List<Pair<String, Integer>> distanceRivals = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Titan", 8600), TuplesKt.to("Blaze", 7200), TuplesKt.to("Apex", 5900), TuplesKt.to("Nova", 4800), TuplesKt.to("Storm", 3800), TuplesKt.to("Vega", 2900), TuplesKt.to("Kova", 2100), TuplesKt.to("Milo", 1500)});
    private static final List<Pair<String, Integer>> challengeRivals = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Apex", 6400), TuplesKt.to("Blaze", 5200), TuplesKt.to("Nova", 4300), TuplesKt.to("Storm", 3200), TuplesKt.to("Vega", 2100)});
    private static final List<Pair<String, Integer>> tournamentRivals = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Blaze", 12), TuplesKt.to("Titan", 9), TuplesKt.to("Apex", 7), TuplesKt.to("Nova", 5), TuplesKt.to("Storm", 3)});

    /* compiled from: Leaderboard.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[LeaderboardBoard.values().length];
            try {
                iArr[LeaderboardBoard.SCORE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[LeaderboardBoard.DISTANCE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[LeaderboardBoard.CHALLENGE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[LeaderboardBoard.TOURNAMENT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private Leaderboard() {
    }

    public final List<LeaderboardEntry> entries(LeaderboardBoard board, PlayerState state) {
        Pair pair;
        Intrinsics.checkNotNullParameter(board, "board");
        Intrinsics.checkNotNullParameter(state, "state");
        int i = WhenMappings.$EnumSwitchMapping$0[board.ordinal()];
        if (i == 1) {
            pair = TuplesKt.to(scoreRivals, Integer.valueOf(state.getHighScore()));
        } else if (i == 2) {
            pair = TuplesKt.to(distanceRivals, Integer.valueOf(state.getLongestRun()));
        } else if (i == 3) {
            pair = TuplesKt.to(challengeRivals, Integer.valueOf(state.getBestChallengeScore()));
        } else {
            if (i != 4) {
                throw new NoWhenBranchMatchedException();
            }
            pair = TuplesKt.to(tournamentRivals, Integer.valueOf((state.getTournamentTitles() * 4) + state.getBestTournamentRound()));
        }
        List list = (List) pair.component1();
        int iIntValue = ((Number) pair.component2()).intValue();
        List<Pair> list2 = list;
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
        for (Pair pair2 : list2) {
            arrayList.add(new LeaderboardEntry((String) pair2.getFirst(), ((Number) pair2.getSecond()).intValue(), false));
        }
        return CollectionsKt.sortedWith(CollectionsKt.plus((Collection<? extends LeaderboardEntry>) arrayList, new LeaderboardEntry("You", iIntValue, true)), new Comparator() { // from class: com.championship.warriors.iron.legacy.data.leaderboard.Leaderboard$entries$$inlined$sortedByDescending$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                return ComparisonsKt.compareValues(Integer.valueOf(((LeaderboardEntry) t2).getValue()), Integer.valueOf(((LeaderboardEntry) t).getValue()));
            }
        });
    }
}
