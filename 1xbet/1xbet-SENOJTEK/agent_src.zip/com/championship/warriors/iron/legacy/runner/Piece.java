package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0013\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0016\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0010¨\u0006\u0018"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/Piece;", "", "shape", "Lcom/championship/warriors/iron/legacy/runner/PieceShape;", TypedValues.Custom.S_COLOR, "", "extra", "Lcom/championship/warriors/iron/legacy/runner/CellExtra;", "extraCell", "booster", "Lcom/championship/warriors/iron/legacy/runner/Booster;", "<init>", "(Lcom/championship/warriors/iron/legacy/runner/PieceShape;ILcom/championship/warriors/iron/legacy/runner/CellExtra;ILcom/championship/warriors/iron/legacy/runner/Booster;)V", "getShape", "()Lcom/championship/warriors/iron/legacy/runner/PieceShape;", "getColor", "()I", "getExtra", "()Lcom/championship/warriors/iron/legacy/runner/CellExtra;", "getExtraCell", "getBooster", "()Lcom/championship/warriors/iron/legacy/runner/Booster;", "size", "getSize", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Piece {
    private final Booster booster;
    private final int color;
    private final CellExtra extra;
    private final int extraCell;
    private final PieceShape shape;

    public Piece(PieceShape shape, int i, CellExtra extra, int i2, Booster booster) {
        Intrinsics.checkNotNullParameter(shape, "shape");
        Intrinsics.checkNotNullParameter(extra, "extra");
        this.shape = shape;
        this.color = i;
        this.extra = extra;
        this.extraCell = i2;
        this.booster = booster;
    }

    public final PieceShape getShape() {
        return this.shape;
    }

    public final int getColor() {
        return this.color;
    }

    public /* synthetic */ Piece(PieceShape pieceShape, int i, CellExtra cellExtra, int i2, Booster booster, int i3, DefaultConstructorMarker defaultConstructorMarker) {
        this(pieceShape, i, (i3 & 4) != 0 ? CellExtra.NONE : cellExtra, (i3 & 8) != 0 ? -1 : i2, (i3 & 16) != 0 ? null : booster);
    }

    public final CellExtra getExtra() {
        return this.extra;
    }

    public final int getExtraCell() {
        return this.extraCell;
    }

    public final Booster getBooster() {
        return this.booster;
    }

    public final int getSize() {
        return this.shape.getSize();
    }
}
