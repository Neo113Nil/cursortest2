package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/ChallengeMetric;", "", "<init>", "(Ljava/lang/String;I)V", "COINS", "DISTANCE", "AVOID", "SCORE", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ChallengeMetric {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ ChallengeMetric[] $VALUES;
    public static final ChallengeMetric COINS = new ChallengeMetric("COINS", 0);
    public static final ChallengeMetric DISTANCE = new ChallengeMetric("DISTANCE", 1);
    public static final ChallengeMetric AVOID = new ChallengeMetric("AVOID", 2);
    public static final ChallengeMetric SCORE = new ChallengeMetric("SCORE", 3);

    private static final /* synthetic */ ChallengeMetric[] $values() {
        return new ChallengeMetric[]{COINS, DISTANCE, AVOID, SCORE};
    }

    public static EnumEntries<ChallengeMetric> getEntries() {
        return $ENTRIES;
    }

    public static ChallengeMetric valueOf(String str) {
        return (ChallengeMetric) Enum.valueOf(ChallengeMetric.class, str);
    }

    public static ChallengeMetric[] values() {
        return (ChallengeMetric[]) $VALUES.clone();
    }

    static {
        ChallengeMetric[] challengeMetricArr$values = $values();
        $VALUES = challengeMetricArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(challengeMetricArr$values);
    }

    private ChallengeMetric(String str, int i) {
    }
}
