package com.championship.warriors.iron.legacy.core.splash;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: SplashActivity.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final /* synthetic */ class SplashActivity$_window$1$2 extends FunctionReferenceImpl implements Function1<ViewBridge, Unit> {
    SplashActivity$_window$1$2(Object obj) {
        super(1, obj, SplashActivity.class, "_window", "_window(Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(ViewBridge viewBridge) {
        invoke2(viewBridge);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(ViewBridge p0) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        ((SplashActivity) this.receiver)._window(p0);
    }
}
