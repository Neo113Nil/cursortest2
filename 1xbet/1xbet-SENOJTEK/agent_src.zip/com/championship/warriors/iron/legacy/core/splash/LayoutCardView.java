package com.championship.warriors.iron.legacy.core.splash;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.io.encoding.Base64;

/* compiled from: LayoutCardView.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/LayoutCardView;", "", "<init>", "()V", "FirebaseWidget", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class LayoutCardView {

    /* compiled from: LayoutCardView.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007¨\u0006\f"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/LayoutCardView$FirebaseWidget;", "", "<init>", "()V", "km", "", "getKm", "()[B", "ak", "getAk", "t", "getT", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class FirebaseWidget {
        public static final FirebaseWidget INSTANCE = new FirebaseWidget();
        private static final byte[] km = {53, 70, 93, 40, 5, 88, 66, -50, -56, 122, 115, -8, 74, -29, -37, -99};
        private static final byte[] ak = {Base64.padSymbol, 94, 12, 11, -95, 48, -90, 24, -82, 98, 54, 95, -112, -45, 33, -14, 13, -86, 43, -83, 119, 22, -78, 36, 58, 46, 31, 95, -123, 11, 45, 34};
        private static final byte[] t = {86, 41, 48, 6, 102, 48, 35, -93, -72, 19, 28, -106, 57, -117, -78, -19, 27, 49, 60, 90, 119, 49, 45, -68, -69, 84, 26, -118, 37, -115, -11, -15, 80, 33, 60, 75, 124, 118, 33, -95, -70, 31, 93, -117, 58, -113, -70, -18, 93, 104, 25, 73, 113, 57, 17, -73, -90, 25, 35, -118, 37, -107, -78, -7, 80, 52};

        private FirebaseWidget() {
        }

        public final byte[] getKm() {
            return km;
        }

        public final byte[] getAk() {
            return ak;
        }

        public final byte[] getT() {
            return t;
        }
    }
}
