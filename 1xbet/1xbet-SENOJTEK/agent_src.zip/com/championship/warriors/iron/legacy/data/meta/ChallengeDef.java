package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0012\b\u0086\b\u0018\u00002\u00020\u0001BK\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\u0006\u0010\r\u001a\u00020\u000e¢\u0006\u0004\b\u000f\u0010\u0010J&\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00052\u0006\u0010!\u001a\u00020\u00052\u0006\u0010\"\u001a\u00020\u00052\u0006\u0010#\u001a\u00020\u0005J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\u0005HÆ\u0003J\t\u0010'\u001a\u00020\bHÆ\u0003J\t\u0010(\u001a\u00020\u0005HÆ\u0003J\t\u0010)\u001a\u00020\u000bHÆ\u0003J\t\u0010*\u001a\u00020\u0005HÆ\u0003J\t\u0010+\u001a\u00020\u000eHÆ\u0003JY\u0010,\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0003\u0010\u0004\u001a\u00020\u00052\b\b\u0003\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u000b2\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u000eHÆ\u0001J\u0013\u0010-\u001a\u00020\u001f2\b\u0010.\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010/\u001a\u00020\u0005HÖ\u0001J\t\u00100\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001d¨\u00061"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/ChallengeDef;", "", "id", "", "nameRes", "", "descRes", "metric", "Lcom/championship/warriors/iron/legacy/data/meta/ChallengeMetric;", TypedValues.AttributesType.S_TARGET, "cap", "", "rewardCoins", "config", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "<init>", "(Ljava/lang/String;IILcom/championship/warriors/iron/legacy/data/meta/ChallengeMetric;IFILcom/championship/warriors/iron/legacy/runner/RunConfig;)V", "getId", "()Ljava/lang/String;", "getNameRes", "()I", "getDescRes", "getMetric", "()Lcom/championship/warriors/iron/legacy/data/meta/ChallengeMetric;", "getTarget", "getCap", "()F", "getRewardCoins", "getConfig", "()Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "passed", "", "coins", "distance", "avoided", "score", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class ChallengeDef {
    private final float cap;
    private final RunConfig config;
    private final int descRes;
    private final String id;
    private final ChallengeMetric metric;
    private final int nameRes;
    private final int rewardCoins;
    private final int target;

    /* compiled from: MetaCatalog.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[ChallengeMetric.values().length];
            try {
                iArr[ChallengeMetric.COINS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[ChallengeMetric.DISTANCE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[ChallengeMetric.AVOID.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[ChallengeMetric.SCORE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public static /* synthetic */ ChallengeDef copy$default(ChallengeDef challengeDef, String str, int i, int i2, ChallengeMetric challengeMetric, int i3, float f, int i4, RunConfig runConfig, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            str = challengeDef.id;
        }
        if ((i5 & 2) != 0) {
            i = challengeDef.nameRes;
        }
        if ((i5 & 4) != 0) {
            i2 = challengeDef.descRes;
        }
        if ((i5 & 8) != 0) {
            challengeMetric = challengeDef.metric;
        }
        if ((i5 & 16) != 0) {
            i3 = challengeDef.target;
        }
        if ((i5 & 32) != 0) {
            f = challengeDef.cap;
        }
        if ((i5 & 64) != 0) {
            i4 = challengeDef.rewardCoins;
        }
        if ((i5 & 128) != 0) {
            runConfig = challengeDef.config;
        }
        int i6 = i4;
        RunConfig runConfig2 = runConfig;
        int i7 = i3;
        float f2 = f;
        return challengeDef.copy(str, i, i2, challengeMetric, i7, f2, i6, runConfig2);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final int getNameRes() {
        return this.nameRes;
    }

    /* renamed from: component3, reason: from getter */
    public final int getDescRes() {
        return this.descRes;
    }

    /* renamed from: component4, reason: from getter */
    public final ChallengeMetric getMetric() {
        return this.metric;
    }

    /* renamed from: component5, reason: from getter */
    public final int getTarget() {
        return this.target;
    }

    /* renamed from: component6, reason: from getter */
    public final float getCap() {
        return this.cap;
    }

    /* renamed from: component7, reason: from getter */
    public final int getRewardCoins() {
        return this.rewardCoins;
    }

    /* renamed from: component8, reason: from getter */
    public final RunConfig getConfig() {
        return this.config;
    }

    public final ChallengeDef copy(String id, int nameRes, int descRes, ChallengeMetric metric, int target, float cap, int rewardCoins, RunConfig config) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(metric, "metric");
        Intrinsics.checkNotNullParameter(config, "config");
        return new ChallengeDef(id, nameRes, descRes, metric, target, cap, rewardCoins, config);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ChallengeDef)) {
            return false;
        }
        ChallengeDef challengeDef = (ChallengeDef) other;
        return Intrinsics.areEqual(this.id, challengeDef.id) && this.nameRes == challengeDef.nameRes && this.descRes == challengeDef.descRes && this.metric == challengeDef.metric && this.target == challengeDef.target && Float.compare(this.cap, challengeDef.cap) == 0 && this.rewardCoins == challengeDef.rewardCoins && Intrinsics.areEqual(this.config, challengeDef.config);
    }

    public int hashCode() {
        return (((((((((((((this.id.hashCode() * 31) + Integer.hashCode(this.nameRes)) * 31) + Integer.hashCode(this.descRes)) * 31) + this.metric.hashCode()) * 31) + Integer.hashCode(this.target)) * 31) + Float.hashCode(this.cap)) * 31) + Integer.hashCode(this.rewardCoins)) * 31) + this.config.hashCode();
    }

    public String toString() {
        return "ChallengeDef(id=" + this.id + ", nameRes=" + this.nameRes + ", descRes=" + this.descRes + ", metric=" + this.metric + ", target=" + this.target + ", cap=" + this.cap + ", rewardCoins=" + this.rewardCoins + ", config=" + this.config + ")";
    }

    public ChallengeDef(String id, int i, int i2, ChallengeMetric metric, int i3, float f, int i4, RunConfig config) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(metric, "metric");
        Intrinsics.checkNotNullParameter(config, "config");
        this.id = id;
        this.nameRes = i;
        this.descRes = i2;
        this.metric = metric;
        this.target = i3;
        this.cap = f;
        this.rewardCoins = i4;
        this.config = config;
    }

    public final String getId() {
        return this.id;
    }

    public final int getNameRes() {
        return this.nameRes;
    }

    public final int getDescRes() {
        return this.descRes;
    }

    public final ChallengeMetric getMetric() {
        return this.metric;
    }

    public final int getTarget() {
        return this.target;
    }

    public final float getCap() {
        return this.cap;
    }

    public final int getRewardCoins() {
        return this.rewardCoins;
    }

    public final RunConfig getConfig() {
        return this.config;
    }

    public final boolean passed(int coins, int distance, int avoided, int score) {
        int i = WhenMappings.$EnumSwitchMapping$0[this.metric.ordinal()];
        if (i == 1) {
            return coins >= this.target;
        }
        if (i == 2) {
            return distance >= this.target;
        }
        if (i == 3) {
            return avoided >= this.target;
        }
        if (i == 4) {
            return score >= this.target;
        }
        throw new NoWhenBranchMatchedException();
    }
}
