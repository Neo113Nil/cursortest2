package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\"\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001BY\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\u0006\u0010\r\u001a\u00020\u0005¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0005HÆ\u0003J\t\u0010#\u001a\u00020\u0005HÆ\u0003J\t\u0010$\u001a\u00020\u0005HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003Jm\u0010&\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u0005HÆ\u0001J\u0013\u0010'\u001a\u00020(2\b\u0010)\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010*\u001a\u00020\u0003HÖ\u0001J\t\u0010+\u001a\u00020,HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0013R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0013R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0013R\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0013¨\u0006-"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "", "laneCount", "", "baseSpeed", "", "maxSpeed", "speedRampPer100m", "spawnGapStart", "spawnGapMin", "doubleBlockChance", "powerUpChance", "coinChance", "targetDistance", "<init>", "(IFFFFFFFFF)V", "getLaneCount", "()I", "getBaseSpeed", "()F", "getMaxSpeed", "getSpeedRampPer100m", "getSpawnGapStart", "getSpawnGapMin", "getDoubleBlockChance", "getPowerUpChance", "getCoinChance", "getTargetDistance", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunConfig {
    private final float baseSpeed;
    private final float coinChance;
    private final float doubleBlockChance;
    private final int laneCount;
    private final float maxSpeed;
    private final float powerUpChance;
    private final float spawnGapMin;
    private final float spawnGapStart;
    private final float speedRampPer100m;
    private final float targetDistance;

    public static /* synthetic */ RunConfig copy$default(RunConfig runConfig, int i, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = runConfig.laneCount;
        }
        if ((i2 & 2) != 0) {
            f = runConfig.baseSpeed;
        }
        if ((i2 & 4) != 0) {
            f2 = runConfig.maxSpeed;
        }
        if ((i2 & 8) != 0) {
            f3 = runConfig.speedRampPer100m;
        }
        if ((i2 & 16) != 0) {
            f4 = runConfig.spawnGapStart;
        }
        if ((i2 & 32) != 0) {
            f5 = runConfig.spawnGapMin;
        }
        if ((i2 & 64) != 0) {
            f6 = runConfig.doubleBlockChance;
        }
        if ((i2 & 128) != 0) {
            f7 = runConfig.powerUpChance;
        }
        if ((i2 & 256) != 0) {
            f8 = runConfig.coinChance;
        }
        if ((i2 & 512) != 0) {
            f9 = runConfig.targetDistance;
        }
        float f10 = f8;
        float f11 = f9;
        float f12 = f6;
        float f13 = f7;
        float f14 = f4;
        float f15 = f5;
        return runConfig.copy(i, f, f2, f3, f14, f15, f12, f13, f10, f11);
    }

    /* renamed from: component1, reason: from getter */
    public final int getLaneCount() {
        return this.laneCount;
    }

    /* renamed from: component10, reason: from getter */
    public final float getTargetDistance() {
        return this.targetDistance;
    }

    /* renamed from: component2, reason: from getter */
    public final float getBaseSpeed() {
        return this.baseSpeed;
    }

    /* renamed from: component3, reason: from getter */
    public final float getMaxSpeed() {
        return this.maxSpeed;
    }

    /* renamed from: component4, reason: from getter */
    public final float getSpeedRampPer100m() {
        return this.speedRampPer100m;
    }

    /* renamed from: component5, reason: from getter */
    public final float getSpawnGapStart() {
        return this.spawnGapStart;
    }

    /* renamed from: component6, reason: from getter */
    public final float getSpawnGapMin() {
        return this.spawnGapMin;
    }

    /* renamed from: component7, reason: from getter */
    public final float getDoubleBlockChance() {
        return this.doubleBlockChance;
    }

    /* renamed from: component8, reason: from getter */
    public final float getPowerUpChance() {
        return this.powerUpChance;
    }

    /* renamed from: component9, reason: from getter */
    public final float getCoinChance() {
        return this.coinChance;
    }

    public final RunConfig copy(int laneCount, float baseSpeed, float maxSpeed, float speedRampPer100m, float spawnGapStart, float spawnGapMin, float doubleBlockChance, float powerUpChance, float coinChance, float targetDistance) {
        return new RunConfig(laneCount, baseSpeed, maxSpeed, speedRampPer100m, spawnGapStart, spawnGapMin, doubleBlockChance, powerUpChance, coinChance, targetDistance);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunConfig)) {
            return false;
        }
        RunConfig runConfig = (RunConfig) other;
        return this.laneCount == runConfig.laneCount && Float.compare(this.baseSpeed, runConfig.baseSpeed) == 0 && Float.compare(this.maxSpeed, runConfig.maxSpeed) == 0 && Float.compare(this.speedRampPer100m, runConfig.speedRampPer100m) == 0 && Float.compare(this.spawnGapStart, runConfig.spawnGapStart) == 0 && Float.compare(this.spawnGapMin, runConfig.spawnGapMin) == 0 && Float.compare(this.doubleBlockChance, runConfig.doubleBlockChance) == 0 && Float.compare(this.powerUpChance, runConfig.powerUpChance) == 0 && Float.compare(this.coinChance, runConfig.coinChance) == 0 && Float.compare(this.targetDistance, runConfig.targetDistance) == 0;
    }

    public int hashCode() {
        return (((((((((((((((((Integer.hashCode(this.laneCount) * 31) + Float.hashCode(this.baseSpeed)) * 31) + Float.hashCode(this.maxSpeed)) * 31) + Float.hashCode(this.speedRampPer100m)) * 31) + Float.hashCode(this.spawnGapStart)) * 31) + Float.hashCode(this.spawnGapMin)) * 31) + Float.hashCode(this.doubleBlockChance)) * 31) + Float.hashCode(this.powerUpChance)) * 31) + Float.hashCode(this.coinChance)) * 31) + Float.hashCode(this.targetDistance);
    }

    public String toString() {
        return "RunConfig(laneCount=" + this.laneCount + ", baseSpeed=" + this.baseSpeed + ", maxSpeed=" + this.maxSpeed + ", speedRampPer100m=" + this.speedRampPer100m + ", spawnGapStart=" + this.spawnGapStart + ", spawnGapMin=" + this.spawnGapMin + ", doubleBlockChance=" + this.doubleBlockChance + ", powerUpChance=" + this.powerUpChance + ", coinChance=" + this.coinChance + ", targetDistance=" + this.targetDistance + ")";
    }

    public RunConfig(int i, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        this.laneCount = i;
        this.baseSpeed = f;
        this.maxSpeed = f2;
        this.speedRampPer100m = f3;
        this.spawnGapStart = f4;
        this.spawnGapMin = f5;
        this.doubleBlockChance = f6;
        this.powerUpChance = f7;
        this.coinChance = f8;
        this.targetDistance = f9;
    }

    public /* synthetic */ RunConfig(int i, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 3 : i, f, f2, f3, f4, f5, f6, f7, f8, f9);
    }

    public final int getLaneCount() {
        return this.laneCount;
    }

    public final float getBaseSpeed() {
        return this.baseSpeed;
    }

    public final float getMaxSpeed() {
        return this.maxSpeed;
    }

    public final float getSpeedRampPer100m() {
        return this.speedRampPer100m;
    }

    public final float getSpawnGapStart() {
        return this.spawnGapStart;
    }

    public final float getSpawnGapMin() {
        return this.spawnGapMin;
    }

    public final float getDoubleBlockChance() {
        return this.doubleBlockChance;
    }

    public final float getPowerUpChance() {
        return this.powerUpChance;
    }

    public final float getCoinChance() {
        return this.coinChance;
    }

    public final float getTargetDistance() {
        return this.targetDistance;
    }
}
