package com.championship.warriors.iron.legacy.presentation.game;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.os.BundleKt;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.AudioController;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.databinding.FragmentGameplayBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import kotlin.KotlinNothingValueException;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.StateFlow;

/* compiled from: GameplayFragment.kt */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0016J\b\u0010 \u001a\u00020\u001bH\u0016J\b\u0010!\u001a\u00020\u001bH\u0016J\b\u0010\"\u001a\u00020\u001bH\u0016J\b\u0010#\u001a\u00020\u001fH\u0002J\u0010\u0010$\u001a\u00020\u001b2\u0006\u0010%\u001a\u00020&H\u0002J\u0010\u0010'\u001a\u00020\u001b2\u0006\u0010(\u001a\u00020)H\u0002J\u0010\u0010*\u001a\u00020\u001f2\u0006\u0010+\u001a\u00020)H\u0002J\u0010\u0010,\u001a\u00020\u001b2\u0006\u0010-\u001a\u00020\fH\u0002J\b\u0010.\u001a\u00020\u001bH\u0002R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u00020\u000f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u00138BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0016\u001a\u00020\u000f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0011R\u0014\u0010\u0018\u001a\u00020\u000f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u0011¨\u0006/"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/GameplayFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentGameplayBinding;", "<init>", "()V", "viewModel", "Lcom/championship/warriors/iron/legacy/presentation/game/GameViewModel;", "getViewModel", "()Lcom/championship/warriors/iron/legacy/presentation/game/GameViewModel;", "viewModel$delegate", "Lkotlin/Lazy;", "gameStarted", "", "navigated", "mode", "", "getMode", "()Ljava/lang/String;", "stageId", "", "getStageId", "()I", "challengeId", "getChallengeId", "tournamentId", "getTournamentId", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "onResume", "onPause", "runArgs", "render", "state", "Lcom/championship/warriors/iron/legacy/presentation/game/RunUiState;", "onResult", "result", "Lcom/championship/warriors/iron/legacy/presentation/game/RunResult;", "resultArgs", "r", "showPause", "show", "flashGo", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class GameplayFragment extends BaseFragment<FragmentGameplayBinding> {
    private boolean gameStarted;
    private boolean navigated;

    /* renamed from: viewModel$delegate, reason: from kotlin metadata */
    private final Lazy viewModel;

    /* compiled from: GameplayFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentGameplayBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentGameplayBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentGameplayBinding;", 0);
        }

        public final FragmentGameplayBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentGameplayBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentGameplayBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public GameplayFragment() {
        super(AnonymousClass1.INSTANCE);
        final GameplayFragment gameplayFragment = this;
        final Function0<Fragment> function0 = new Function0<Fragment>() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$special$$inlined$viewModels$default$1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final Fragment invoke() {
                return gameplayFragment;
            }
        };
        final Lazy lazy = LazyKt.lazy(LazyThreadSafetyMode.NONE, (Function0) new Function0<ViewModelStoreOwner>() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$special$$inlined$viewModels$default$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStoreOwner invoke() {
                return (ViewModelStoreOwner) function0.invoke();
            }
        });
        final Function0 function02 = null;
        this.viewModel = FragmentViewModelLazyKt.createViewModelLazy(gameplayFragment, Reflection.getOrCreateKotlinClass(GameViewModel.class), new Function0<ViewModelStore>() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$special$$inlined$viewModels$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                return FragmentViewModelLazyKt.m139viewModels$lambda1(lazy).getViewModelStore();
            }
        }, new Function0<CreationExtras>() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$special$$inlined$viewModels$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final CreationExtras invoke() {
                CreationExtras creationExtras;
                Function0 function03 = function02;
                if (function03 != null && (creationExtras = (CreationExtras) function03.invoke()) != null) {
                    return creationExtras;
                }
                ViewModelStoreOwner viewModelStoreOwnerM139viewModels$lambda1 = FragmentViewModelLazyKt.m139viewModels$lambda1(lazy);
                HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = viewModelStoreOwnerM139viewModels$lambda1 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) viewModelStoreOwnerM139viewModels$lambda1 : null;
                return hasDefaultViewModelProviderFactory != null ? hasDefaultViewModelProviderFactory.getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$special$$inlined$viewModels$default$5
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                ViewModelProvider.Factory defaultViewModelProviderFactory;
                ViewModelStoreOwner viewModelStoreOwnerM139viewModels$lambda1 = FragmentViewModelLazyKt.m139viewModels$lambda1(lazy);
                HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = viewModelStoreOwnerM139viewModels$lambda1 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) viewModelStoreOwnerM139viewModels$lambda1 : null;
                return (hasDefaultViewModelProviderFactory == null || (defaultViewModelProviderFactory = hasDefaultViewModelProviderFactory.getDefaultViewModelProviderFactory()) == null) ? gameplayFragment.getDefaultViewModelProviderFactory() : defaultViewModelProviderFactory;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GameViewModel getViewModel() {
        return (GameViewModel) this.viewModel.getValue();
    }

    private final String getMode() {
        String string;
        Bundle arguments = getArguments();
        return (arguments == null || (string = arguments.getString("mode")) == null) ? "CAREER" : string;
    }

    private final int getStageId() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            return arguments.getInt("stageId");
        }
        return 1;
    }

    private final String getChallengeId() {
        String string;
        Bundle arguments = getArguments();
        return (arguments == null || (string = arguments.getString("challengeId")) == null) ? "" : string;
    }

    private final String getTournamentId() {
        String string;
        Bundle arguments = getArguments();
        return (arguments == null || (string = arguments.getString("tournamentId")) == null) ? "" : string;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getViewModel().load(getMode(), getStageId(), getChallengeId(), getTournamentId());
        getBinding().gameView.bind(getViewModel().engine());
        getBinding().gameView.setOnUpdate(new Function1() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return GameplayFragment.onViewCreated$lambda$0(this.f$0, ((Float) obj).floatValue());
            }
        });
        getBinding().hud.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view2, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                this.f$0.getBinding().gameView.setTopInset(i4);
            }
        });
        getBinding().pauseButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                GameplayFragment.onViewCreated$lambda$2(this.f$0, view2);
            }
        });
        getBinding().resumeButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                GameplayFragment.onViewCreated$lambda$3(this.f$0, view2);
            }
        });
        getBinding().restartButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                GameplayFragment.onViewCreated$lambda$4(this.f$0, view2);
            }
        });
        getBinding().quitButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                GameplayFragment.onViewCreated$lambda$5(this.f$0, view2);
            }
        });
        OnBackPressedDispatcherKt.addCallback$default(requireActivity().getOnBackPressedDispatcher(), getViewLifecycleOwner(), false, new Function1() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return GameplayFragment.onViewCreated$lambda$6(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner), null, null, new AnonymousClass8(null), 3, null);
    }

    static final Unit onViewCreated$lambda$0(GameplayFragment gameplayFragment, float f) {
        gameplayFragment.getViewModel().onFrame(f);
        return Unit.INSTANCE;
    }

    static final void onViewCreated$lambda$2(GameplayFragment gameplayFragment, View view) {
        gameplayFragment.getAudio().play(Sfx.BUTTON);
        gameplayFragment.showPause(true);
    }

    static final void onViewCreated$lambda$3(GameplayFragment gameplayFragment, View view) {
        gameplayFragment.getAudio().play(Sfx.BUTTON);
        gameplayFragment.showPause(false);
    }

    static final void onViewCreated$lambda$4(GameplayFragment gameplayFragment, View view) {
        gameplayFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(gameplayFragment).navigate(R.id.action_global_open_run, gameplayFragment.runArgs());
    }

    static final void onViewCreated$lambda$5(GameplayFragment gameplayFragment, View view) {
        gameplayFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(gameplayFragment).navigate(R.id.action_global_to_menu);
    }

    static final Unit onViewCreated$lambda$6(GameplayFragment gameplayFragment, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        gameplayFragment.showPause(gameplayFragment.getBinding().pauseOverlay.getVisibility() != 0);
        return Unit.INSTANCE;
    }

    /* compiled from: GameplayFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8", f = "GameplayFragment.kt", i = {}, l = {58}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8, reason: invalid class name */
    static final class AnonymousClass8 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass8(Continuation<? super AnonymousClass8> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return GameplayFragment.this.new AnonymousClass8(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass8) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: GameplayFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1", f = "GameplayFragment.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            private /* synthetic */ Object L$0;
            int label;
            final /* synthetic */ GameplayFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass1(GameplayFragment gameplayFragment, Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
                this.this$0 = gameplayFragment;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, continuation);
                anonymousClass1.L$0 = obj;
                return anonymousClass1;
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            /* compiled from: GameplayFragment.kt */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
            @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1$1", f = "GameplayFragment.kt", i = {}, l = {59}, m = "invokeSuspend", n = {}, s = {})
            /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1$1, reason: invalid class name and collision with other inner class name */
            static final class C00081 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                int label;
                final /* synthetic */ GameplayFragment this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                C00081(GameplayFragment gameplayFragment, Continuation<? super C00081> continuation) {
                    super(2, continuation);
                    this.this$0 = gameplayFragment;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new C00081(this.this$0, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((C00081) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Object invokeSuspend(Object obj) {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.label;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        StateFlow<RunUiState> state = this.this$0.getViewModel().getState();
                        final GameplayFragment gameplayFragment = this.this$0;
                        this.label = 1;
                        if (state.collect(new FlowCollector() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment.onViewCreated.8.1.1.1
                            public final Object emit(RunUiState runUiState, Continuation<? super Unit> continuation) {
                                gameplayFragment.render(runUiState);
                                return Unit.INSTANCE;
                            }

                            @Override // kotlinx.coroutines.flow.FlowCollector
                            public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                                return emit((RunUiState) obj2, (Continuation<? super Unit>) continuation);
                            }
                        }, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else {
                        if (i != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        ResultKt.throwOnFailure(obj);
                    }
                    throw new KotlinNothingValueException();
                }
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                CoroutineScope coroutineScope = (CoroutineScope) this.L$0;
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label == 0) {
                    ResultKt.throwOnFailure(obj);
                    BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new C00081(this.this$0, null), 3, null);
                    BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new AnonymousClass2(this.this$0, null), 3, null);
                    return Unit.INSTANCE;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            /* compiled from: GameplayFragment.kt */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
            @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1$2", f = "GameplayFragment.kt", i = {}, l = {60}, m = "invokeSuspend", n = {}, s = {})
            /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onViewCreated$8$1$2, reason: invalid class name */
            static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                int label;
                final /* synthetic */ GameplayFragment this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnonymousClass2(GameplayFragment gameplayFragment, Continuation<? super AnonymousClass2> continuation) {
                    super(2, continuation);
                    this.this$0 = gameplayFragment;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new AnonymousClass2(this.this$0, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Object invokeSuspend(Object obj) {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.label;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        StateFlow<RunResult> result = this.this$0.getViewModel().getResult();
                        final GameplayFragment gameplayFragment = this.this$0;
                        this.label = 1;
                        if (result.collect(new FlowCollector() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment.onViewCreated.8.1.2.1
                            public final Object emit(RunResult runResult, Continuation<? super Unit> continuation) {
                                if (runResult != null) {
                                    gameplayFragment.onResult(runResult);
                                }
                                return Unit.INSTANCE;
                            }

                            @Override // kotlinx.coroutines.flow.FlowCollector
                            public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                                return emit((RunResult) obj2, (Continuation<? super Unit>) continuation);
                            }
                        }, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else {
                        if (i != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        ResultKt.throwOnFailure(obj);
                    }
                    throw new KotlinNothingValueException();
                }
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                LifecycleOwner viewLifecycleOwner = GameplayFragment.this.getViewLifecycleOwner();
                Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
                this.label = 1;
                if (RepeatOnLifecycleKt.repeatOnLifecycle(viewLifecycleOwner, Lifecycle.State.STARTED, new AnonymousClass1(GameplayFragment.this, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        boolean zAreEqual = Intrinsics.areEqual(getMode(), "TOURNAMENT");
        AudioController audio = getAudio();
        if (zAreEqual) {
            audio.playTournamentMusic();
        } else {
            audio.playGameMusic();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.navigated || getBinding().pauseOverlay.getVisibility() == 0) {
            return;
        }
        if (!this.gameStarted) {
            this.gameStarted = true;
            getViewModel().startRun();
            flashGo();
        }
        getBinding().gameView.startLoop();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        getBinding().gameView.stopLoop();
    }

    private final Bundle runArgs() {
        return BundleKt.bundleOf(TuplesKt.to("mode", getMode()), TuplesKt.to("stageId", Integer.valueOf(getStageId())), TuplesKt.to("challengeId", getChallengeId()), TuplesKt.to("tournamentId", getTournamentId()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void render(RunUiState state) {
        if (state.getLoaded()) {
            getBinding().scoreValue.setText(String.valueOf(state.getScore()));
            getBinding().coinsValue.setText(String.valueOf(state.getCoins()));
            getBinding().distanceValue.setText(getString(R.string.value_lines, Integer.valueOf(state.getLines())));
            getBinding().comboText.setVisibility(state.getComboActive() ? 0 : 4);
            getBinding().comboText.setText(getString(R.string.hud_combo, Integer.valueOf(state.getCombo())));
            if (state.getTimeTrial()) {
                getBinding().timeText.setVisibility(0);
                getBinding().timeText.setText(getString(R.string.value_seconds, Integer.valueOf(state.getTimeRemaining())));
                getBinding().progressBar.setVisibility(4);
            } else if (state.getTarget() > 0) {
                getBinding().timeText.setVisibility(8);
                getBinding().progressBar.setVisibility(0);
                getBinding().progressBar.setMax(state.getTarget());
                getBinding().progressBar.setProgress(RangesKt.coerceIn(state.getDistance(), 0, state.getTarget()));
            } else {
                getBinding().timeText.setVisibility(8);
                getBinding().progressBar.setVisibility(4);
            }
            getBinding().powerSpeed.setVisibility(state.getSpeed() ? 0 : 8);
            getBinding().powerShield.setVisibility(state.getShield() ? 0 : 8);
            getBinding().powerMagnet.setVisibility(state.getMagnet() ? 0 : 8);
            getBinding().powerDouble.setVisibility(state.getDouble() ? 0 : 8);
            getBinding().powerSlowmo.setVisibility(state.getSlowmo() ? 0 : 8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onResult(RunResult result) {
        if (this.navigated) {
            return;
        }
        this.navigated = true;
        getBinding().gameView.stopLoop();
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner), null, null, new C00501(result, null), 3, null);
    }

    /* compiled from: GameplayFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onResult$1", f = "GameplayFragment.kt", i = {}, l = {121}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$onResult$1, reason: invalid class name and case insensitive filesystem */
    static final class C00501 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ RunResult $result;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00501(RunResult runResult, Continuation<? super C00501> continuation) {
            super(2, continuation);
            this.$result = runResult;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return GameplayFragment.this.new C00501(this.$result, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C00501) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (DelayKt.delay(550L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            NavDestination currentDestination = FragmentKt.findNavController(GameplayFragment.this).getCurrentDestination();
            if (currentDestination != null && currentDestination.getId() == R.id.gameplayFragment) {
                FragmentKt.findNavController(GameplayFragment.this).navigate(R.id.action_game_to_results, GameplayFragment.this.resultArgs(this.$result));
                return Unit.INSTANCE;
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Bundle resultArgs(RunResult r) {
        return BundleKt.bundleOf(TuplesKt.to("mode", r.getMode()), TuplesKt.to("stageId", Integer.valueOf(r.getStageId())), TuplesKt.to("challengeId", r.getChallengeId()), TuplesKt.to("tournamentId", r.getTournamentId()), TuplesKt.to("victory", Boolean.valueOf(r.getVictory())), TuplesKt.to("timedOut", Boolean.valueOf(r.getTimedOut())), TuplesKt.to("score", Integer.valueOf(r.getScore())), TuplesKt.to("distance", Integer.valueOf(r.getDistance())), TuplesKt.to("coins", Integer.valueOf(r.getCoins())), TuplesKt.to("stars", Integer.valueOf(r.getStars())), TuplesKt.to("newBest", Boolean.valueOf(r.getNewBest())), TuplesKt.to("xpGained", Integer.valueOf(r.getXpGained())), TuplesKt.to("leveledUp", Boolean.valueOf(r.getLeveledUp())), TuplesKt.to("newLevel", Integer.valueOf(r.getNewLevel())), TuplesKt.to("nextStageId", Integer.valueOf(r.getNextStageId())), TuplesKt.to("careerAdvanced", Boolean.valueOf(r.getCareerAdvanced())), TuplesKt.to("finalVictory", Boolean.valueOf(r.getFinalVictory())), TuplesKt.to("challengePassed", Boolean.valueOf(r.getChallengePassed())), TuplesKt.to("tournamentQualified", Boolean.valueOf(r.getTournamentQualified())), TuplesKt.to("tournamentFinal", Boolean.valueOf(r.getTournamentFinal())));
    }

    private final void showPause(boolean show) {
        getBinding().pauseOverlay.setVisibility(show ? 0 : 8);
        getViewModel().setPaused(show);
        if (show) {
            getBinding().gameView.stopLoop();
        } else {
            if (this.navigated) {
                return;
            }
            getBinding().gameView.startLoop();
        }
    }

    private final void flashGo() {
        final TextView textView = getBinding().goText;
        textView.setAlpha(0.0f);
        textView.setScaleX(0.4f);
        textView.setScaleY(0.4f);
        textView.setVisibility(0);
        textView.animate().alpha(1.0f).scaleX(1.2f).scaleY(1.2f).setDuration(260L).withEndAction(new Runnable() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                TextView textView2 = textView;
                textView2.animate().alpha(0.0f).setStartDelay(220L).setDuration(320L).withEndAction(new Runnable() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameplayFragment$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        textView2.setVisibility(8);
                    }
                }).start();
            }
        }).start();
        TextView textView2 = getBinding().startHint;
        textView2.setAlpha(1.0f);
        textView2.animate().alpha(0.0f).setStartDelay(2600L).setDuration(600L).start();
    }
}
