package com.championship.warriors.iron.legacy.data.equipment;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: Equipment.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u001d\b\u0002\u0012\b\b\u0001\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\bj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\r¨\u0006\u000e"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;", "", "labelRes", "", "iconRes", "<init>", "(Ljava/lang/String;III)V", "getLabelRes", "()I", "getIconRes", "JERSEY", "BOOTS", "FOOTBALL", "TRAIL", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class EquipmentCategory {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ EquipmentCategory[] $VALUES;
    private final int iconRes;
    private final int labelRes;
    public static final EquipmentCategory JERSEY = new EquipmentCategory("JERSEY", 0, R.string.cat_jerseys, R.drawable.ic_jersey);
    public static final EquipmentCategory BOOTS = new EquipmentCategory("BOOTS", 1, R.string.cat_boots, R.drawable.ic_boot);
    public static final EquipmentCategory FOOTBALL = new EquipmentCategory("FOOTBALL", 2, R.string.cat_footballs, R.drawable.ic_football);
    public static final EquipmentCategory TRAIL = new EquipmentCategory("TRAIL", 3, R.string.cat_effects, R.drawable.ic_trail);

    private static final /* synthetic */ EquipmentCategory[] $values() {
        return new EquipmentCategory[]{JERSEY, BOOTS, FOOTBALL, TRAIL};
    }

    public static EnumEntries<EquipmentCategory> getEntries() {
        return $ENTRIES;
    }

    public static EquipmentCategory valueOf(String str) {
        return (EquipmentCategory) Enum.valueOf(EquipmentCategory.class, str);
    }

    public static EquipmentCategory[] values() {
        return (EquipmentCategory[]) $VALUES.clone();
    }

    private EquipmentCategory(String str, int i, int i2, int i3) {
        this.labelRes = i2;
        this.iconRes = i3;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    static {
        EquipmentCategory[] equipmentCategoryArr$values = $values();
        $VALUES = equipmentCategoryArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(equipmentCategoryArr$values);
    }
}
