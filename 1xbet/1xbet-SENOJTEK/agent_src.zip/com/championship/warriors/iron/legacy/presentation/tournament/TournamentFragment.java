package com.championship.warriors.iron.legacy.presentation.tournament;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.os.BundleKt;
import androidx.core.view.GravityCompat;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.TournamentCatalog;
import com.championship.warriors.iron.legacy.data.meta.TournamentDef;
import com.championship.warriors.iron.legacy.data.meta.TournamentRoundDef;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentTournamentBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: TournamentFragment.kt */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0006H\u0016J\b\u0010\f\u001a\u00020\u0006H\u0016J\b\u0010\r\u001a\u00020\u0006H\u0002J\b\u0010\u000e\u001a\u00020\u0006H\u0002J\u0018\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0018\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0010\u0010\u0018\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u001aH\u0002J\u0010\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u001aH\u0002¨\u0006\u001c"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/tournament/TournamentFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentTournamentBinding;", "<init>", "()V", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "onResume", "refresh", "showChooser", "showRound", "t", "Lcom/championship/warriors/iron/legacy/data/meta/TournamentDef;", "round", "", "showEnded", "champion", "", "enter", "addLine", "text", "", "addHeader", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class TournamentFragment extends BaseFragment<FragmentTournamentBinding> {

    /* compiled from: TournamentFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentTournamentBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentTournamentBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentTournamentBinding;", 0);
        }

        public final FragmentTournamentBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentTournamentBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentTournamentBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public TournamentFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                TournamentFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        refresh();
    }

    static final void onViewCreated$lambda$0(TournamentFragment tournamentFragment, View view) {
        tournamentFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(tournamentFragment).popBackStack();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playTournamentMusic();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        refresh();
    }

    private final void refresh() {
        getBinding().contentContainer.removeAllViews();
        PlayerState playerStateCurrent = GameContainer.INSTANCE.getPlayer().current();
        TournamentDef tournamentDefById = TournamentCatalog.INSTANCE.byId(playerStateCurrent.getTournamentId());
        boolean z = tournamentDefById != null && playerStateCurrent.getTournamentAlive() && playerStateCurrent.getTournamentRound() < tournamentDefById.getRounds().size();
        if (tournamentDefById == null || playerStateCurrent.getTournamentId().length() == 0) {
            showChooser();
            return;
        }
        if (!playerStateCurrent.getTournamentAlive()) {
            showEnded(tournamentDefById, playerStateCurrent.getTournamentRound() >= tournamentDefById.getRounds().size());
        } else if (z) {
            showRound(tournamentDefById, playerStateCurrent.getTournamentRound());
        } else {
            showChooser();
        }
    }

    private final void showChooser() {
        getBinding().stateTitle.setText(R.string.tournament_title);
        String string = getString(R.string.tournament_start_new);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        addLine(string);
        final List<TournamentDef> tournaments = TournamentCatalog.INSTANCE.getTournaments();
        getBinding().primaryButton.setVisibility(0);
        getBinding().primaryButton.setText(tournaments.get(0).getNameRes());
        getBinding().primaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.enter((TournamentDef) tournaments.get(0));
            }
        });
        if (tournaments.size() > 1) {
            getBinding().secondaryButton.setVisibility(0);
            getBinding().secondaryButton.setText(tournaments.get(1).getNameRes());
            getBinding().secondaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.enter((TournamentDef) tournaments.get(1));
                }
            });
            return;
        }
        getBinding().secondaryButton.setVisibility(8);
    }

    private final void showRound(final TournamentDef t, int round) {
        int i = round + 1;
        getBinding().stateTitle.setText(getString(R.string.tournament_round, Integer.valueOf(i), Integer.valueOf(t.getRounds().size())));
        TournamentRoundDef tournamentRoundDef = t.getRounds().get(round);
        String string = getString(t.getNameRes());
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        addLine(string);
        String string2 = getString(R.string.tournament_threshold, Integer.valueOf(tournamentRoundDef.getThresholdScore()));
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        addLine(string2);
        String string3 = getString(R.string.tournament_rivals);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        addHeader(string3);
        Iterator<T> it = tournamentRoundDef.getRivals().iterator();
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            addLine(pair.getFirst() + "  —  " + pair.getSecond());
        }
        getBinding().primaryButton.setVisibility(0);
        getBinding().primaryButton.setText(getString(R.string.tournament_play, Integer.valueOf(i)));
        getBinding().primaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TournamentFragment.showRound$lambda$4(this.f$0, t, view);
            }
        });
        getBinding().secondaryButton.setVisibility(8);
    }

    static final void showRound$lambda$4(TournamentFragment tournamentFragment, TournamentDef tournamentDef, View view) {
        tournamentFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(tournamentFragment).navigate(R.id.action_global_open_run, BundleKt.bundleOf(TuplesKt.to("mode", "TOURNAMENT"), TuplesKt.to("stageId", 1), TuplesKt.to("challengeId", ""), TuplesKt.to("tournamentId", tournamentDef.getId())));
    }

    private final void showEnded(TournamentDef t, boolean champion) {
        getBinding().stateTitle.setText(champion ? R.string.tournament_champion : R.string.result_eliminated);
        String string = getString(t.getNameRes());
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        addLine(string);
        String string2 = getString(champion ? R.string.tournament_champion : R.string.tournament_eliminated_msg);
        Intrinsics.checkNotNull(string2);
        addLine(string2);
        getBinding().primaryButton.setVisibility(0);
        getBinding().primaryButton.setText(R.string.tournament_results_title);
        getBinding().primaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TournamentFragment.showEnded$lambda$5(this.f$0, view);
            }
        });
        getBinding().secondaryButton.setVisibility(0);
        getBinding().secondaryButton.setText(R.string.tournament_start_new);
        getBinding().secondaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentFragment$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TournamentFragment.showEnded$lambda$6(this.f$0, view);
            }
        });
    }

    static final void showEnded$lambda$5(TournamentFragment tournamentFragment, View view) {
        tournamentFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(tournamentFragment).navigate(R.id.action_global_to_tournament_results);
    }

    static final void showEnded$lambda$6(TournamentFragment tournamentFragment, View view) {
        GameContainer.INSTANCE.getPlayer().startTournament("");
        tournamentFragment.refresh();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void enter(TournamentDef t) {
        getAudio().play(Sfx.BUTTON);
        GameContainer.INSTANCE.getPlayer().startTournament(t.getId());
        refresh();
    }

    private final void addLine(String text) {
        LinearLayout linearLayout = getBinding().contentContainer;
        TextView textView = new TextView(requireContext());
        textView.setText(text);
        textView.setTextAppearance(R.style.TextAppearance_VR_Body);
        textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.offwhite));
        TextView textView2 = textView;
        int i = (int) (4.0f * textView.getResources().getDisplayMetrics().density);
        textView2.setPadding(i, i, i, i);
        linearLayout.addView(textView2);
    }

    private final void addHeader(String text) {
        LinearLayout linearLayout = getBinding().contentContainer;
        TextView textView = new TextView(requireContext());
        textView.setText(text);
        textView.setGravity(GravityCompat.START);
        textView.setTextAppearance(R.style.TextAppearance_VR_Label);
        textView.setPadding(0, (int) (10.0f * textView.getResources().getDisplayMetrics().density), 0, (int) (2.0f * textView.getResources().getDisplayMetrics().density));
        linearLayout.addView(textView);
    }
}
