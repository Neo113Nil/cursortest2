package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

/* loaded from: classes.dex */
public final class FragmentProfileBinding implements ViewBinding {
    public final MaterialButton achievementsButton;
    public final ImageButton backButton;
    public final TextView levelText;
    public final LinearLayout recordsContainer;
    private final FrameLayout rootView;
    public final MaterialButton statsButton;
    public final LinearProgressIndicator xpBar;
    public final TextView xpText;

    private FragmentProfileBinding(FrameLayout frameLayout, MaterialButton materialButton, ImageButton imageButton, TextView textView, LinearLayout linearLayout, MaterialButton materialButton2, LinearProgressIndicator linearProgressIndicator, TextView textView2) {
        this.rootView = frameLayout;
        this.achievementsButton = materialButton;
        this.backButton = imageButton;
        this.levelText = textView;
        this.recordsContainer = linearLayout;
        this.statsButton = materialButton2;
        this.xpBar = linearProgressIndicator;
        this.xpText = textView2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentProfileBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentProfileBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_profile, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentProfileBinding bind(View view) {
        int i = R.id.achievementsButton;
        MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
        if (materialButton != null) {
            i = R.id.backButton;
            ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
            if (imageButton != null) {
                i = R.id.levelText;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.recordsContainer;
                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                    if (linearLayout != null) {
                        i = R.id.statsButton;
                        MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                        if (materialButton2 != null) {
                            i = R.id.xpBar;
                            LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) ViewBindings.findChildViewById(view, i);
                            if (linearProgressIndicator != null) {
                                i = R.id.xpText;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView2 != null) {
                                    return new FragmentProfileBinding((FrameLayout) view, materialButton, imageButton, textView, linearLayout, materialButton2, linearProgressIndicator, textView2);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
