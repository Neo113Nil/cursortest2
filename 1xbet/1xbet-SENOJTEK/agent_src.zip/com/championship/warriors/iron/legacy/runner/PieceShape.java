package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u000f\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\f¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/PieceShape;", "", "cells", "", "Lcom/championship/warriors/iron/legacy/runner/Off;", "<init>", "(Ljava/util/List;)V", "getCells", "()Ljava/util/List;", "size", "", "getSize", "()I", "rows", "getRows", "cols", "getCols", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class PieceShape {
    private final List<Off> cells;
    private final int cols;
    private final int rows;
    private final int size;

    public PieceShape(List<Off> cells) {
        Intrinsics.checkNotNullParameter(cells, "cells");
        this.cells = cells;
        this.size = cells.size();
        Iterator<T> it = cells.iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException();
        }
        int r = ((Off) it.next()).getR();
        while (it.hasNext()) {
            int r2 = ((Off) it.next()).getR();
            if (r < r2) {
                r = r2;
            }
        }
        this.rows = r + 1;
        Iterator<T> it2 = this.cells.iterator();
        if (!it2.hasNext()) {
            throw new NoSuchElementException();
        }
        int c = ((Off) it2.next()).getC();
        while (it2.hasNext()) {
            int c2 = ((Off) it2.next()).getC();
            if (c < c2) {
                c = c2;
            }
        }
        this.cols = c + 1;
    }

    public final List<Off> getCells() {
        return this.cells;
    }

    public final int getSize() {
        return this.size;
    }

    public final int getRows() {
        return this.rows;
    }

    public final int getCols() {
        return this.cols;
    }
}
