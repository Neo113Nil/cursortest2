package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.card.MaterialCardView;

/* loaded from: classes.dex */
public final class ItemCareerStageBinding implements ViewBinding {
    public final View accentBar;
    public final TextView bestText;
    public final ImageView goIcon;
    public final ImageView lockIcon;
    private final MaterialCardView rootView;
    public final TextView stageEnv;
    public final TextView stageName;
    public final ImageView star1;
    public final ImageView star2;
    public final ImageView star3;

    private ItemCareerStageBinding(MaterialCardView materialCardView, View view, TextView textView, ImageView imageView, ImageView imageView2, TextView textView2, TextView textView3, ImageView imageView3, ImageView imageView4, ImageView imageView5) {
        this.rootView = materialCardView;
        this.accentBar = view;
        this.bestText = textView;
        this.goIcon = imageView;
        this.lockIcon = imageView2;
        this.stageEnv = textView2;
        this.stageName = textView3;
        this.star1 = imageView3;
        this.star2 = imageView4;
        this.star3 = imageView5;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ItemCareerStageBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemCareerStageBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_career_stage, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemCareerStageBinding bind(View view) {
        int i = R.id.accentBar;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            i = R.id.bestText;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.goIcon;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView != null) {
                    i = R.id.lockIcon;
                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                    if (imageView2 != null) {
                        i = R.id.stageEnv;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView2 != null) {
                            i = R.id.stageName;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView3 != null) {
                                i = R.id.star1;
                                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                if (imageView3 != null) {
                                    i = R.id.star2;
                                    ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i);
                                    if (imageView4 != null) {
                                        i = R.id.star3;
                                        ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(view, i);
                                        if (imageView5 != null) {
                                            return new ItemCareerStageBinding((MaterialCardView) view, viewFindChildViewById, textView, imageView, imageView2, textView2, textView3, imageView3, imageView4, imageView5);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
