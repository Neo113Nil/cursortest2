package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.AchievementCatalog;
import com.championship.warriors.iron.legacy.data.meta.AchievementDef;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentProfileBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: ProfileFragment.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0006H\u0016J\u0018\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002¨\u0006\u0010"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/ProfileFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentProfileBinding;", "<init>", "()V", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "addRow", "label", "", "value", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ProfileFragment extends BaseFragment<FragmentProfileBinding> {

    /* compiled from: ProfileFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ProfileFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentProfileBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentProfileBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentProfileBinding;", 0);
        }

        public final FragmentProfileBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentProfileBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentProfileBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public ProfileFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        PlayerState playerStateCurrent = GameContainer.INSTANCE.getPlayer().current();
        getBinding().levelText.setText(getString(R.string.level_label, Integer.valueOf(playerStateCurrent.getLevel())));
        getBinding().xpBar.setMax(RangesKt.coerceAtLeast(playerStateCurrent.xpForThisLevel(), 1));
        int i = 0;
        getBinding().xpBar.setProgress(RangesKt.coerceIn(playerStateCurrent.xpIntoLevel(), 0, playerStateCurrent.xpForThisLevel()));
        getBinding().xpText.setText(playerStateCurrent.xpIntoLevel() + " / " + playerStateCurrent.xpForThisLevel() + " XP");
        List<AchievementDef> achievements = AchievementCatalog.INSTANCE.getAchievements();
        if (!(achievements instanceof Collection) || !achievements.isEmpty()) {
            Iterator<T> it = achievements.iterator();
            while (it.hasNext()) {
                if (((AchievementDef) it.next()).isUnlocked(playerStateCurrent) && (i = i + 1) < 0) {
                    CollectionsKt.throwCountOverflow();
                }
            }
        }
        String string = getString(R.string.profile_high);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        addRow(string, String.valueOf(playerStateCurrent.getHighScore()));
        String string2 = getString(R.string.profile_longest);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String string3 = getString(R.string.value_meters, Integer.valueOf(playerStateCurrent.getLongestRun()));
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        addRow(string2, string3);
        String string4 = getString(R.string.profile_topspeed);
        Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
        addRow(string4, String.valueOf(playerStateCurrent.getTopSpeed()));
        String string5 = getString(R.string.profile_distance);
        Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
        String string6 = getString(R.string.value_meters, Integer.valueOf(playerStateCurrent.getTotalDistance()));
        Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
        addRow(string5, string6);
        String string7 = getString(R.string.profile_coins);
        Intrinsics.checkNotNullExpressionValue(string7, "getString(...)");
        addRow(string7, String.valueOf(playerStateCurrent.getTotalCoins()));
        String string8 = getString(R.string.profile_runs);
        Intrinsics.checkNotNullExpressionValue(string8, "getString(...)");
        addRow(string8, String.valueOf(playerStateCurrent.getTotalRuns()));
        String string9 = getString(R.string.profile_playtime);
        Intrinsics.checkNotNullExpressionValue(string9, "getString(...)");
        addRow(string9, (playerStateCurrent.getPlaySeconds() / 60) + "m");
        String string10 = getString(R.string.profile_achievements);
        Intrinsics.checkNotNullExpressionValue(string10, "getString(...)");
        String string11 = getString(R.string.value_fraction, Integer.valueOf(i), Integer.valueOf(AchievementCatalog.INSTANCE.getAchievements().size()));
        Intrinsics.checkNotNullExpressionValue(string11, "getString(...)");
        addRow(string10, string11);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ProfileFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ProfileFragment.onViewCreated$lambda$1(this.f$0, view2);
            }
        });
        getBinding().statsButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ProfileFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ProfileFragment.onViewCreated$lambda$2(this.f$0, view2);
            }
        });
        getBinding().achievementsButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ProfileFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ProfileFragment.onViewCreated$lambda$3(this.f$0, view2);
            }
        });
    }

    static final void onViewCreated$lambda$1(ProfileFragment profileFragment, View view) {
        profileFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(profileFragment).popBackStack();
    }

    static final void onViewCreated$lambda$2(ProfileFragment profileFragment, View view) {
        profileFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(profileFragment).navigate(R.id.action_global_to_stats);
    }

    static final void onViewCreated$lambda$3(ProfileFragment profileFragment, View view) {
        profileFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(profileFragment).navigate(R.id.action_global_to_achievements);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    private final void addRow(String label, String value) {
        float f = getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(requireContext());
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        int i = (int) (7.0f * f);
        linearLayout.setPadding(0, i, 0, i);
        TextView textView = new TextView(requireContext());
        textView.setText(label);
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        textView.setTextAppearance(R.style.TextAppearance_VR_Body);
        TextView textView2 = new TextView(requireContext());
        textView2.setText(value);
        textView2.setTextAppearance(R.style.TextAppearance_VR_Subtitle);
        textView2.setTextColor(ContextCompat.getColor(requireContext(), R.color.offwhite));
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        getBinding().recordsContainer.addView(linearLayout);
    }
}
