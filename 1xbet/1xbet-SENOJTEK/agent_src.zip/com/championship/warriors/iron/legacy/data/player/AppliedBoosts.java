package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: PlayerRepository.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0011\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0007HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00032\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/AppliedBoosts;", "", "headStart", "", "shieldStart", "coinRush", "revives", "", "<init>", "(ZZZI)V", "getHeadStart", "()Z", "getShieldStart", "getCoinRush", "getRevives", "()I", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class AppliedBoosts {
    private final boolean coinRush;
    private final boolean headStart;
    private final int revives;
    private final boolean shieldStart;

    public AppliedBoosts() {
        this(false, false, false, 0, 15, null);
    }

    public static /* synthetic */ AppliedBoosts copy$default(AppliedBoosts appliedBoosts, boolean z, boolean z2, boolean z3, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            z = appliedBoosts.headStart;
        }
        if ((i2 & 2) != 0) {
            z2 = appliedBoosts.shieldStart;
        }
        if ((i2 & 4) != 0) {
            z3 = appliedBoosts.coinRush;
        }
        if ((i2 & 8) != 0) {
            i = appliedBoosts.revives;
        }
        return appliedBoosts.copy(z, z2, z3, i);
    }

    /* renamed from: component1, reason: from getter */
    public final boolean getHeadStart() {
        return this.headStart;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getShieldStart() {
        return this.shieldStart;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getCoinRush() {
        return this.coinRush;
    }

    /* renamed from: component4, reason: from getter */
    public final int getRevives() {
        return this.revives;
    }

    public final AppliedBoosts copy(boolean headStart, boolean shieldStart, boolean coinRush, int revives) {
        return new AppliedBoosts(headStart, shieldStart, coinRush, revives);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AppliedBoosts)) {
            return false;
        }
        AppliedBoosts appliedBoosts = (AppliedBoosts) other;
        return this.headStart == appliedBoosts.headStart && this.shieldStart == appliedBoosts.shieldStart && this.coinRush == appliedBoosts.coinRush && this.revives == appliedBoosts.revives;
    }

    public int hashCode() {
        return (((((Boolean.hashCode(this.headStart) * 31) + Boolean.hashCode(this.shieldStart)) * 31) + Boolean.hashCode(this.coinRush)) * 31) + Integer.hashCode(this.revives);
    }

    public String toString() {
        return "AppliedBoosts(headStart=" + this.headStart + ", shieldStart=" + this.shieldStart + ", coinRush=" + this.coinRush + ", revives=" + this.revives + ")";
    }

    public AppliedBoosts(boolean z, boolean z2, boolean z3, int i) {
        this.headStart = z;
        this.shieldStart = z2;
        this.coinRush = z3;
        this.revives = i;
    }

    public /* synthetic */ AppliedBoosts(boolean z, boolean z2, boolean z3, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? false : z2, (i2 & 4) != 0 ? false : z3, (i2 & 8) != 0 ? 0 : i);
    }

    public final boolean getHeadStart() {
        return this.headStart;
    }

    public final boolean getShieldStart() {
        return this.shieldStart;
    }

    public final boolean getCoinRush() {
        return this.coinRush;
    }

    public final int getRevives() {
        return this.revives;
    }
}
