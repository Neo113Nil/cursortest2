package com.championship.warriors.iron.legacy.data.stage;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: StageModels.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0004\u000e\u000f\u0010\u0011B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003J&\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u0005R\u0012\u0010\u0004\u001a\u00020\u0005X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007\u0082\u0001\u0004\u0012\u0013\u0014\u0015¨\u0006\u0016"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", "", "<init>", "()V", TypedValues.AttributesType.S_TARGET, "", "getTarget", "()I", "met", "", "distance", "coins", "score", "avoided", "Distance", "Collect", "Score", "Avoid", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Avoid;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Collect;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Distance;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Score;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public abstract class StageGoal {
    public /* synthetic */ StageGoal(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    public abstract int getTarget();

    private StageGoal() {
    }

    /* compiled from: StageModels.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Distance;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", TypedValues.AttributesType.S_TARGET, "", "<init>", "(I)V", "getTarget", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* data */ class Distance extends StageGoal {
        private final int target;

        public static /* synthetic */ Distance copy$default(Distance distance, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                i = distance.target;
            }
            return distance.copy(i);
        }

        /* renamed from: component1, reason: from getter */
        public final int getTarget() {
            return this.target;
        }

        public final Distance copy(int target) {
            return new Distance(target);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            return (other instanceof Distance) && this.target == ((Distance) other).target;
        }

        public int hashCode() {
            return Integer.hashCode(this.target);
        }

        public String toString() {
            return "Distance(target=" + this.target + ")";
        }

        public Distance(int i) {
            super(null);
            this.target = i;
        }

        @Override // com.championship.warriors.iron.legacy.data.stage.StageGoal
        public int getTarget() {
            return this.target;
        }
    }

    /* compiled from: StageModels.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Collect;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", TypedValues.AttributesType.S_TARGET, "", "<init>", "(I)V", "getTarget", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* data */ class Collect extends StageGoal {
        private final int target;

        public static /* synthetic */ Collect copy$default(Collect collect, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                i = collect.target;
            }
            return collect.copy(i);
        }

        /* renamed from: component1, reason: from getter */
        public final int getTarget() {
            return this.target;
        }

        public final Collect copy(int target) {
            return new Collect(target);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            return (other instanceof Collect) && this.target == ((Collect) other).target;
        }

        public int hashCode() {
            return Integer.hashCode(this.target);
        }

        public String toString() {
            return "Collect(target=" + this.target + ")";
        }

        public Collect(int i) {
            super(null);
            this.target = i;
        }

        @Override // com.championship.warriors.iron.legacy.data.stage.StageGoal
        public int getTarget() {
            return this.target;
        }
    }

    /* compiled from: StageModels.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Score;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", TypedValues.AttributesType.S_TARGET, "", "<init>", "(I)V", "getTarget", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* data */ class Score extends StageGoal {
        private final int target;

        public static /* synthetic */ Score copy$default(Score score, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                i = score.target;
            }
            return score.copy(i);
        }

        /* renamed from: component1, reason: from getter */
        public final int getTarget() {
            return this.target;
        }

        public final Score copy(int target) {
            return new Score(target);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            return (other instanceof Score) && this.target == ((Score) other).target;
        }

        public int hashCode() {
            return Integer.hashCode(this.target);
        }

        public String toString() {
            return "Score(target=" + this.target + ")";
        }

        public Score(int i) {
            super(null);
            this.target = i;
        }

        @Override // com.championship.warriors.iron.legacy.data.stage.StageGoal
        public int getTarget() {
            return this.target;
        }
    }

    /* compiled from: StageModels.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageGoal$Avoid;", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", TypedValues.AttributesType.S_TARGET, "", "<init>", "(I)V", "getTarget", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* data */ class Avoid extends StageGoal {
        private final int target;

        public static /* synthetic */ Avoid copy$default(Avoid avoid, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                i = avoid.target;
            }
            return avoid.copy(i);
        }

        /* renamed from: component1, reason: from getter */
        public final int getTarget() {
            return this.target;
        }

        public final Avoid copy(int target) {
            return new Avoid(target);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            return (other instanceof Avoid) && this.target == ((Avoid) other).target;
        }

        public int hashCode() {
            return Integer.hashCode(this.target);
        }

        public String toString() {
            return "Avoid(target=" + this.target + ")";
        }

        public Avoid(int i) {
            super(null);
            this.target = i;
        }

        @Override // com.championship.warriors.iron.legacy.data.stage.StageGoal
        public int getTarget() {
            return this.target;
        }
    }

    public final boolean met(int distance, int coins, int score, int avoided) {
        if (this instanceof Distance) {
            return distance >= ((Distance) this).getTarget();
        }
        if (this instanceof Collect) {
            return coins >= ((Collect) this).getTarget();
        }
        if (this instanceof Score) {
            return score >= ((Score) this).getTarget();
        }
        if (this instanceof Avoid) {
            return avoided >= ((Avoid) this).getTarget();
        }
        throw new NoWhenBranchMatchedException();
    }
}
