package com.championship.warriors.iron.legacy.presentation.career;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: CareerMapFragment.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final /* synthetic */ class CareerMapFragment$adapter$1 extends FunctionReferenceImpl implements Function1<CareerRow, Unit> {
    CareerMapFragment$adapter$1(Object obj) {
        super(1, obj, CareerMapFragment.class, "onStage", "onStage(Lcom/championship/warriors/iron/legacy/presentation/career/CareerRow;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(CareerRow careerRow) {
        invoke2(careerRow);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(CareerRow p0) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        ((CareerMapFragment) this.receiver).onStage(p0);
    }
}
