package com.championship.warriors.iron.legacy.presentation.career;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.data.stage.StageData;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: CareerAdapter.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0007HÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00052\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u0007HÖ\u0001J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010¨\u0006\u001c"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/career/CareerRow;", "", "stage", "Lcom/championship/warriors/iron/legacy/data/stage/StageData;", "unlocked", "", "best", "", "stars", "<init>", "(Lcom/championship/warriors/iron/legacy/data/stage/StageData;ZII)V", "getStage", "()Lcom/championship/warriors/iron/legacy/data/stage/StageData;", "getUnlocked", "()Z", "getBest", "()I", "getStars", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class CareerRow {
    private final int best;
    private final StageData stage;
    private final int stars;
    private final boolean unlocked;

    public static /* synthetic */ CareerRow copy$default(CareerRow careerRow, StageData stageData, boolean z, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            stageData = careerRow.stage;
        }
        if ((i3 & 2) != 0) {
            z = careerRow.unlocked;
        }
        if ((i3 & 4) != 0) {
            i = careerRow.best;
        }
        if ((i3 & 8) != 0) {
            i2 = careerRow.stars;
        }
        return careerRow.copy(stageData, z, i, i2);
    }

    /* renamed from: component1, reason: from getter */
    public final StageData getStage() {
        return this.stage;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getUnlocked() {
        return this.unlocked;
    }

    /* renamed from: component3, reason: from getter */
    public final int getBest() {
        return this.best;
    }

    /* renamed from: component4, reason: from getter */
    public final int getStars() {
        return this.stars;
    }

    public final CareerRow copy(StageData stage, boolean unlocked, int best, int stars) {
        Intrinsics.checkNotNullParameter(stage, "stage");
        return new CareerRow(stage, unlocked, best, stars);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CareerRow)) {
            return false;
        }
        CareerRow careerRow = (CareerRow) other;
        return Intrinsics.areEqual(this.stage, careerRow.stage) && this.unlocked == careerRow.unlocked && this.best == careerRow.best && this.stars == careerRow.stars;
    }

    public int hashCode() {
        return (((((this.stage.hashCode() * 31) + Boolean.hashCode(this.unlocked)) * 31) + Integer.hashCode(this.best)) * 31) + Integer.hashCode(this.stars);
    }

    public String toString() {
        return "CareerRow(stage=" + this.stage + ", unlocked=" + this.unlocked + ", best=" + this.best + ", stars=" + this.stars + ")";
    }

    public CareerRow(StageData stage, boolean z, int i, int i2) {
        Intrinsics.checkNotNullParameter(stage, "stage");
        this.stage = stage;
        this.unlocked = z;
        this.best = i;
        this.stars = i2;
    }

    public final int getBest() {
        return this.best;
    }

    public final StageData getStage() {
        return this.stage;
    }

    public final int getStars() {
        return this.stars;
    }

    public final boolean getUnlocked() {
        return this.unlocked;
    }
}
