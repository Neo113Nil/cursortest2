package com.championship.warriors.iron.legacy.presentation.common;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.championship.warriors.iron.legacy.databinding.ItemMetaCardBinding;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: MetaAdapter.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u0000 \u00102\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001:\u0002\u000f\u0010B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\nH\u0016¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaRow;", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter$VH;", "<init>", "()V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "", "holder", "position", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MetaAdapter extends ListAdapter<MetaRow, VH> {
    private static final MetaAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<MetaRow>() { // from class: com.championship.warriors.iron.legacy.presentation.common.MetaAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(MetaRow a2, MetaRow b) {
            Intrinsics.checkNotNullParameter(a2, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a2.getId(), b.getId());
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(MetaRow a2, MetaRow b) {
            Intrinsics.checkNotNullParameter(a2, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a2.getContentKey(), b.getContentKey());
        }
    };

    public MetaAdapter() {
        super(DIFF);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemMetaCardBinding itemMetaCardBindingInflate = ItemMetaCardBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemMetaCardBindingInflate, "inflate(...)");
        return new VH(itemMetaCardBindingInflate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        MetaRow item = getItem(position);
        Intrinsics.checkNotNullExpressionValue(item, "getItem(...)");
        holder.bind(item);
    }

    /* compiled from: MetaAdapter.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "b", "Lcom/championship/warriors/iron/legacy/databinding/ItemMetaCardBinding;", "<init>", "(Lcom/championship/warriors/iron/legacy/databinding/ItemMetaCardBinding;)V", "bind", "", "row", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaRow;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class VH extends RecyclerView.ViewHolder {
        private final ItemMetaCardBinding b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(ItemMetaCardBinding b) {
            super(b.getRoot());
            Intrinsics.checkNotNullParameter(b, "b");
            this.b = b;
        }

        public final void bind(final MetaRow row) {
            Intrinsics.checkNotNullParameter(row, "row");
            Context context = this.b.getRoot().getContext();
            this.b.icon.setImageResource(row.getIconRes());
            ImageViewCompat.setImageTintList(this.b.icon, ColorStateList.valueOf(ContextCompat.getColor(context, row.getIconTint())));
            this.b.title.setText(row.getTitle());
            this.b.subtitle.setText(row.getSubtitle());
            int progressMax = row.getProgressMax();
            ItemMetaCardBinding itemMetaCardBinding = this.b;
            if (progressMax > 0) {
                itemMetaCardBinding.progressBar.setVisibility(0);
                this.b.progressBar.setMax(row.getProgressMax());
                this.b.progressBar.setProgress(RangesKt.coerceIn(row.getProgress(), 0, row.getProgressMax()));
            } else {
                itemMetaCardBinding.progressBar.setVisibility(8);
            }
            this.b.statusIcon.setVisibility(row.getShowCheck() ? 0 : 8);
            this.b.rightValue.setVisibility(row.getRightText() != null ? 0 : 8);
            TextView textView = this.b.rightValue;
            String rightText = row.getRightText();
            if (rightText == null) {
                rightText = "";
            }
            textView.setText(rightText);
            String buttonText = row.getButtonText();
            ItemMetaCardBinding itemMetaCardBinding2 = this.b;
            if (buttonText != null) {
                itemMetaCardBinding2.actionButton.setVisibility(0);
                this.b.actionButton.setText(row.getButtonText());
                this.b.actionButton.setEnabled(row.getButtonEnabled());
                this.b.actionButton.setAlpha(row.getButtonEnabled() ? 1.0f : 0.5f);
                this.b.actionButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.common.MetaAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        row.getOnAction().invoke();
                    }
                });
                return;
            }
            itemMetaCardBinding2.actionButton.setVisibility(8);
        }
    }
}
