package com.championship.warriors.iron.legacy.presentation.career;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.databinding.ItemCareerStageBinding;
import com.championship.warriors.iron.legacy.presentation.career.CareerAdapter;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: CareerAdapter.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u0000 \u00122\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001:\u0002\u0011\u0012B\u001b\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0018\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0018\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\rH\u0016R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/career/CareerAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/championship/warriors/iron/legacy/presentation/career/CareerRow;", "Lcom/championship/warriors/iron/legacy/presentation/career/CareerAdapter$VH;", "onStage", "Lkotlin/Function1;", "", "<init>", "(Lkotlin/jvm/functions/Function1;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "", "onBindViewHolder", "holder", "position", "VH", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class CareerAdapter extends ListAdapter<CareerRow, VH> {
    private static final CareerAdapter$Companion$DIFF$1 DIFF = new DiffUtil.ItemCallback<CareerRow>() { // from class: com.championship.warriors.iron.legacy.presentation.career.CareerAdapter$Companion$DIFF$1
        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areItemsTheSame(CareerRow a2, CareerRow b) {
            Intrinsics.checkNotNullParameter(a2, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return a2.getStage().getId() == b.getStage().getId();
        }

        @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
        public boolean areContentsTheSame(CareerRow a2, CareerRow b) {
            Intrinsics.checkNotNullParameter(a2, "a");
            Intrinsics.checkNotNullParameter(b, "b");
            return Intrinsics.areEqual(a2, b);
        }
    };
    private final Function1<CareerRow, Unit> onStage;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public CareerAdapter(Function1<? super CareerRow, Unit> onStage) {
        super(DIFF);
        Intrinsics.checkNotNullParameter(onStage, "onStage");
        this.onStage = onStage;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        ItemCareerStageBinding itemCareerStageBindingInflate = ItemCareerStageBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(itemCareerStageBindingInflate, "inflate(...)");
        return new VH(itemCareerStageBindingInflate, this.onStage);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(VH holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        CareerRow item = getItem(position);
        Intrinsics.checkNotNullExpressionValue(item, "getItem(...)");
        holder.bind(item);
    }

    /* compiled from: CareerAdapter.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005¢\u0006\u0004\b\b\u0010\tJ\u000e\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0006R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/career/CareerAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "b", "Lcom/championship/warriors/iron/legacy/databinding/ItemCareerStageBinding;", "onStage", "Lkotlin/Function1;", "Lcom/championship/warriors/iron/legacy/presentation/career/CareerRow;", "", "<init>", "(Lcom/championship/warriors/iron/legacy/databinding/ItemCareerStageBinding;Lkotlin/jvm/functions/Function1;)V", "bind", "row", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class VH extends RecyclerView.ViewHolder {
        private final ItemCareerStageBinding b;
        private final Function1<CareerRow, Unit> onStage;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public VH(ItemCareerStageBinding b, Function1<? super CareerRow, Unit> onStage) {
            super(b.getRoot());
            Intrinsics.checkNotNullParameter(b, "b");
            Intrinsics.checkNotNullParameter(onStage, "onStage");
            this.b = b;
            this.onStage = onStage;
        }

        public final void bind(final CareerRow row) {
            Intrinsics.checkNotNullParameter(row, "row");
            Context context = this.b.getRoot().getContext();
            this.b.stageName.setText(context.getString(row.getStage().getNameRes()));
            this.b.stageEnv.setText(context.getString(row.getStage().getEnvRes()));
            this.b.accentBar.setBackgroundColor(ContextCompat.getColor(context, row.getStage().getColorRes()));
            this.b.bestText.setText(context.getString(R.string.stage_best, Integer.valueOf(row.getBest())));
            int i = 0;
            this.b.lockIcon.setVisibility(row.getUnlocked() ? 8 : 0);
            this.b.goIcon.setVisibility(row.getUnlocked() ? 0 : 8);
            this.b.getRoot().setAlpha(row.getUnlocked() ? 1.0f : 0.7f);
            for (Object obj : CollectionsKt.listOf((Object[]) new ImageView[]{this.b.star1, this.b.star2, this.b.star3})) {
                int i2 = i + 1;
                if (i < 0) {
                    CollectionsKt.throwIndexOverflow();
                }
                ImageViewCompat.setImageTintList((ImageView) obj, ColorStateList.valueOf(ContextCompat.getColor(context, i < row.getStars() ? R.color.star_on : R.color.star_off)));
                i = i2;
            }
            this.b.getRoot().setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.career.CareerAdapter$VH$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    CareerAdapter.VH.bind$lambda$1(row, this, view);
                }
            });
        }

        static final void bind$lambda$1(CareerRow careerRow, VH vh, View view) {
            if (careerRow.getUnlocked()) {
                vh.onStage.invoke(careerRow);
            }
        }
    }
}
