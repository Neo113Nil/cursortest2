package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.presentation.game.GameView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;

/* compiled from: RunnerEngine.kt */
@Metadata(d1 = {"\u0000\u0096\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0018\n\u0002\u0010#\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u000f\u0018\u0000 \u009a\u00012\u00020\u0001:\u0002\u009a\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0006\u0010m\u001a\u00020nJ\u0018\u0010o\u001a\u00020\u00152\u0006\u0010p\u001a\u00020\u00152\u0006\u0010q\u001a\u00020\u0015H\u0002J\u0016\u0010r\u001a\u00020\u00152\u0006\u0010p\u001a\u00020\u00152\u0006\u0010q\u001a\u00020\u0015J\u0016\u0010s\u001a\u00020t2\u0006\u0010p\u001a\u00020\u00152\u0006\u0010q\u001a\u00020\u0015J\u0018\u0010u\u001a\u0004\u0018\u00010\u001f2\u0006\u0010p\u001a\u00020\u00152\u0006\u0010q\u001a\u00020\u0015J\u001e\u0010v\u001a\u00020;2\u0006\u0010w\u001a\u00020x2\u0006\u0010y\u001a\u00020\u00152\u0006\u0010z\u001a\u00020\u0015J\u001e\u0010{\u001a\u00020;2\u0006\u0010|\u001a\u00020\u00152\u0006\u0010y\u001a\u00020\u00152\u0006\u0010z\u001a\u00020\u0015J\b\u0010}\u001a\u00020nH\u0002J'\u0010~\u001a\u00020;2\u0006\u0010\u007f\u001a\u00020\u00152\u0014\u0010\u0080\u0001\u001a\u000f\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00150\u0081\u0001H\u0082\bJ\u0012\u0010\u0082\u0001\u001a\u00020n2\u0007\u0010\u0083\u0001\u001a\u00020\u001fH\u0002J\t\u0010\u0084\u0001\u001a\u00020nH\u0002J\u0012\u0010\u0085\u0001\u001a\u00020n2\u0007\u0010\u0086\u0001\u001a\u00020'H\u0002J\t\u0010\u0087\u0001\u001a\u00020nH\u0002J\t\u0010\u0088\u0001\u001a\u00020;H\u0002J\u0011\u0010\u0089\u0001\u001a\u00020;2\u0006\u0010w\u001a\u00020xH\u0002J\u0013\u0010\u008a\u0001\u001a\u00020n2\b\u0010\u008b\u0001\u001a\u00030\u008c\u0001H\u0002J\u0012\u0010\u008d\u0001\u001a\u00020n2\u0007\u0010\u008e\u0001\u001a\u00020;H\u0002J\t\u0010\u008f\u0001\u001a\u00020nH\u0002J\t\u0010\u0090\u0001\u001a\u00020nH\u0002J\t\u0010\u0091\u0001\u001a\u00020;H\u0002J\t\u0010\u0092\u0001\u001a\u00020#H\u0002J\t\u0010\u0093\u0001\u001a\u00020xH\u0002J\t\u0010\u0094\u0001\u001a\u00020\u001fH\u0002J\t\u0010\u0095\u0001\u001a\u00020\u0015H\u0002J\u0010\u0010\u0096\u0001\u001a\u00020n2\u0007\u0010\u0097\u0001\u001a\u00020'J\u0012\u0010\u0098\u0001\u001a\u00020n2\u0007\u0010\u0099\u0001\u001a\u00020'H\u0002R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0014\u001a\u00020\u0015X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\u0015X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0017R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u001d\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001f0\u001eX\u0082\u0004¢\u0006\u0004\n\u0002\u0010 R\u0019\u0010!\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010#0\"¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u001e\u0010(\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b)\u0010*R\u001e\u0010+\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b,\u0010\u0017R\u001e\u0010-\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b.\u0010\u0017R\u001e\u0010/\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b0\u0010\u0017R\u001e\u00101\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b2\u0010\u0017R\u001e\u00103\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b4\u0010\u0017R\u001e\u00105\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b6\u0010\u0017R\u001e\u00107\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b8\u0010\u0017R\u001e\u00109\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b:\u0010\u0017R\u001e\u0010<\u001a\u00020;2\u0006\u0010&\u001a\u00020;@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b=\u0010>R\u001e\u0010?\u001a\u00020;2\u0006\u0010&\u001a\u00020;@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b@\u0010>R\u001e\u0010A\u001a\u00020;2\u0006\u0010&\u001a\u00020;@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bB\u0010>R\u001e\u0010C\u001a\u00020;2\u0006\u0010&\u001a\u00020;@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bD\u0010>R\u001e\u0010E\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bF\u0010*R\u001e\u0010G\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bH\u0010*R\u001e\u0010I\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bJ\u0010*R\u001e\u0010K\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bL\u0010*R\u001e\u0010M\u001a\u00020;2\u0006\u0010&\u001a\u00020;@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bN\u0010>R\u001e\u0010O\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bP\u0010*R\u000e\u0010Q\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010R\u001a\u00020'X\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010S\u001a\b\u0012\u0004\u0012\u00020\u00150T¢\u0006\b\n\u0000\u001a\u0004\bU\u0010VR\u001e\u0010W\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bX\u0010*R\u001e\u0010Y\u001a\u00020'2\u0006\u0010&\u001a\u00020'@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bZ\u0010*R\u0017\u0010[\u001a\b\u0012\u0004\u0012\u00020\\0\"¢\u0006\b\n\u0000\u001a\u0004\b]\u0010%R\u000e\u0010^\u001a\u00020'X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010_\u001a\u00020'X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010`\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\ba\u0010>R\u0011\u0010b\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\bc\u0010>R\u0011\u0010d\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\be\u0010>R\u0011\u0010f\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\bg\u0010>R\u0011\u0010h\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\bi\u0010>R\u0011\u0010j\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\bj\u0010>R\u0011\u0010k\u001a\u00020\u00158F¢\u0006\u0006\u001a\u0004\bl\u0010\u0017¨\u0006\u009b\u0001"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunnerEngine;", "", "config", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "options", "Lcom/championship/warriors/iron/legacy/runner/RunOptions;", "random", "Lkotlin/random/Random;", "<init>", "(Lcom/championship/warriors/iron/legacy/runner/RunConfig;Lcom/championship/warriors/iron/legacy/runner/RunOptions;Lkotlin/random/Random;)V", "getConfig", "()Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "getOptions", "()Lcom/championship/warriors/iron/legacy/runner/RunOptions;", "listener", "Lcom/championship/warriors/iron/legacy/runner/RunnerListener;", "getListener", "()Lcom/championship/warriors/iron/legacy/runner/RunnerListener;", "setListener", "(Lcom/championship/warriors/iron/legacy/runner/RunnerListener;)V", "cols", "", "getCols", "()I", "rows", "getRows", TypedValues.Custom.S_COLOR, "", "extra", "boosterCell", "", "Lcom/championship/warriors/iron/legacy/runner/Booster;", "[Lcom/championship/warriors/iron/legacy/runner/Booster;", "tray", "", "Lcom/championship/warriors/iron/legacy/runner/Piece;", "getTray", "()Ljava/util/List;", "value", "", "distance", "getDistance", "()F", "score", "getScore", "coins", "getCoins", "combo", "getCombo", "maxCombo", "getMaxCombo", "obstaclesCleared", "getObstaclesCleared", "powerupsUsed", "getPowerupsUsed", "tokens", "getTokens", "topSpeed", "getTopSpeed", "", "running", "getRunning", "()Z", "finished", "getFinished", "crashed", "getCrashed", "timedOut", "getTimedOut", "speedTimer", "getSpeedTimer", "magnetTimer", "getMagnetTimer", "doubleTimer", "getDoubleTimer", "slowmoTimer", "getSlowmoTimer", "shieldActive", "getShieldActive", "timeRemaining", "getTimeRemaining", "revivesLeft", "nextCheckpoint", "clearing", "", "getClearing", "()Ljava/util/Set;", "clearTimer", "getClearTimer", "shake", "getShake", "popups", "Lcom/championship/warriors/iron/legacy/runner/Popup;", "getPopups", "coinAcc", "playTime", "comboActive", "getComboActive", "speedActive", "getSpeedActive", "magnetActive", "getMagnetActive", "doubleActive", "getDoubleActive", "slowmoActive", "getSlowmoActive", "isTimeTrial", "elapsedSeconds", "getElapsedSeconds", "start", "", "idx", "c", "r", "colorAt", "extraAt", "Lcom/championship/warriors/iron/legacy/runner/CellExtra;", "boosterAt", "fits", "shape", "Lcom/championship/warriors/iron/legacy/runner/PieceShape;", "col", "row", "tryPlace", "index", "resolveClears", "lineIsMono", "length", "cellColor", "Lkotlin/Function1;", "activateBooster", "kind", "grabLooseCoins", "addCoins", "base", "checkJam", "anyTrayFits", "canPlaceAnywhere", "relieve", "label", "", "crash", "force", "seedClutter", "refillTray", "boardEmpty", "makePiece", "pickShape", "randomBooster", "filledCount", "update", "dtSeconds", "agePopups", "dt", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class RunnerEngine {
    public static final int CLEAR_CELL = 12;
    public static final float CLEAR_FLASH = 0.32f;
    public static final int COIN_PER_CELL = 3;
    public static final int COLOR_BONUS = 60;
    public static final int COMBO_MILESTONE = 5;
    public static final float DOUBLE_DUR = 10.0f;
    public static final int LINE_BONUS = 30;
    public static final float MAGNET_DUR = 6.0f;
    public static final int PLACE_SCORE = 2;
    public static final float POPUP_LIFE = 1.1f;
    public static final float PROGRESS_PER_LINE = 30.0f;
    public static final float PROGRESS_PER_PLACE = 6.0f;
    public static final int RELIEVE_ROWS = 3;
    public static final float SHAKE_DECAY = 4.5f;
    public static final float SHAKE_MAX = 1.4f;
    public static final float SLOWMO_DUR = 8.0f;
    public static final float SPEED_DUR = 8.0f;
    private final Booster[] boosterCell;
    private float clearTimer;
    private final Set<Integer> clearing;
    private float coinAcc;
    private int coins;
    private final int[] color;
    private final int cols;
    private int combo;
    private final RunConfig config;
    private boolean crashed;
    private float distance;
    private float doubleTimer;
    private final int[] extra;
    private boolean finished;
    private RunnerListener listener;
    private float magnetTimer;
    private int maxCombo;
    private float nextCheckpoint;
    private int obstaclesCleared;
    private final RunOptions options;
    private float playTime;
    private final List<Popup> popups;
    private int powerupsUsed;
    private final Random random;
    private int revivesLeft;
    private final int rows;
    private boolean running;
    private int score;
    private float shake;
    private boolean shieldActive;
    private float slowmoTimer;
    private float speedTimer;
    private float timeRemaining;
    private boolean timedOut;
    private int tokens;
    private int topSpeed;
    private final List<Piece> tray;

    /* compiled from: RunnerEngine.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[CellExtra.values().length];
            try {
                iArr[CellExtra.COIN.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[CellExtra.GOLD.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[CellExtra.BOOSTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[CellExtra.NONE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Booster.values().length];
            try {
                iArr2[Booster.SHIELD.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr2[Booster.MAGNET.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr2[Booster.SPEED.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr2[Booster.DOUBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr2[Booster.SLOWMO.ordinal()] = 5;
            } catch (NoSuchFieldError unused9) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    public RunnerEngine(RunConfig config, RunOptions options, Random random) {
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(options, "options");
        Intrinsics.checkNotNullParameter(random, "random");
        this.config = config;
        this.options = options;
        this.random = random;
        this.cols = 8;
        this.rows = 8;
        this.color = new int[8 * 8];
        this.extra = new int[8 * 8];
        this.boosterCell = new Booster[8 * 8];
        this.tray = CollectionsKt.arrayListOf(null, null, null);
        this.clearing = new HashSet();
        this.popups = new ArrayList();
    }

    public final RunConfig getConfig() {
        return this.config;
    }

    public final RunOptions getOptions() {
        return this.options;
    }

    public /* synthetic */ RunnerEngine(RunConfig runConfig, RunOptions runOptions, Random.Companion companion, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(runConfig, runOptions, (i & 4) != 0 ? Random.INSTANCE : companion);
    }

    public final RunnerListener getListener() {
        return this.listener;
    }

    public final void setListener(RunnerListener runnerListener) {
        this.listener = runnerListener;
    }

    public final int getCols() {
        return this.cols;
    }

    public final int getRows() {
        return this.rows;
    }

    public final List<Piece> getTray() {
        return this.tray;
    }

    public final float getDistance() {
        return this.distance;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getCombo() {
        return this.combo;
    }

    public final int getMaxCombo() {
        return this.maxCombo;
    }

    public final int getObstaclesCleared() {
        return this.obstaclesCleared;
    }

    public final int getPowerupsUsed() {
        return this.powerupsUsed;
    }

    public final int getTokens() {
        return this.tokens;
    }

    public final int getTopSpeed() {
        return this.topSpeed;
    }

    public final boolean getRunning() {
        return this.running;
    }

    public final boolean getFinished() {
        return this.finished;
    }

    public final boolean getCrashed() {
        return this.crashed;
    }

    public final boolean getTimedOut() {
        return this.timedOut;
    }

    public final float getSpeedTimer() {
        return this.speedTimer;
    }

    public final float getMagnetTimer() {
        return this.magnetTimer;
    }

    public final float getDoubleTimer() {
        return this.doubleTimer;
    }

    public final float getSlowmoTimer() {
        return this.slowmoTimer;
    }

    public final boolean getShieldActive() {
        return this.shieldActive;
    }

    public final float getTimeRemaining() {
        return this.timeRemaining;
    }

    public final Set<Integer> getClearing() {
        return this.clearing;
    }

    public final float getClearTimer() {
        return this.clearTimer;
    }

    public final float getShake() {
        return this.shake;
    }

    public final List<Popup> getPopups() {
        return this.popups;
    }

    public final boolean getComboActive() {
        return this.combo > 1;
    }

    public final boolean getSpeedActive() {
        return this.speedTimer > 0.0f;
    }

    public final boolean getMagnetActive() {
        return this.magnetTimer > 0.0f;
    }

    public final boolean getDoubleActive() {
        return this.doubleTimer > 0.0f;
    }

    public final boolean getSlowmoActive() {
        return this.slowmoTimer > 0.0f;
    }

    public final boolean isTimeTrial() {
        return this.options.getTimeLimit() > 0.0f;
    }

    public final int getElapsedSeconds() {
        return (int) this.playTime;
    }

    public final void start() {
        this.running = true;
        this.revivesLeft = this.options.getRevives();
        if (this.options.getStartShield()) {
            this.shieldActive = true;
        }
        if (this.options.getHeadStart() > 0.0f) {
            this.distance = this.options.getHeadStart();
        }
        if (isTimeTrial()) {
            this.timeRemaining = this.options.getTimeLimit();
        }
        this.nextCheckpoint = this.options.getCheckpointGap() > 0.0f ? this.options.getCheckpointGap() : Float.MAX_VALUE;
        seedClutter();
        refillTray();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int idx(int c, int r) {
        return (r * this.cols) + c;
    }

    public final int colorAt(int c, int r) {
        return this.color[idx(c, r)];
    }

    public final CellExtra extraAt(int c, int r) {
        return CellExtra.getEntries().get(this.extra[idx(c, r)]);
    }

    public final Booster boosterAt(int c, int r) {
        return this.boosterCell[idx(c, r)];
    }

    public final boolean fits(PieceShape shape, int col, int row) {
        Intrinsics.checkNotNullParameter(shape, "shape");
        for (Off off : shape.getCells()) {
            int c = off.getC() + col;
            int r = off.getR() + row;
            if (c < 0 || c >= this.cols || r < 0 || r >= this.rows || this.color[idx(c, r)] != 0) {
                return false;
            }
        }
        return true;
    }

    public final boolean tryPlace(int index, int col, int row) {
        Piece piece;
        if (!this.running || this.finished || this.crashed || (piece = (Piece) CollectionsKt.getOrNull(this.tray, index)) == null || !fits(piece.getShape(), col, row)) {
            return false;
        }
        int i = 0;
        for (Object obj : piece.getShape().getCells()) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            Off off = (Off) obj;
            int iIdx = idx(off.getC() + col, off.getR() + row);
            this.color[iIdx] = piece.getColor();
            if (i == piece.getExtraCell() && piece.getExtra() != CellExtra.NONE) {
                this.extra[iIdx] = piece.getExtra().ordinal();
                if (piece.getExtra() == CellExtra.BOOSTER) {
                    this.boosterCell[iIdx] = piece.getBooster();
                }
            }
            i = i2;
        }
        this.tray.set(index, null);
        this.score += (int) (piece.getSize() * 2 * this.options.getScoreMul());
        this.distance += 6.0f;
        RunnerListener runnerListener = this.listener;
        if (runnerListener != null) {
            runnerListener.onPlace();
        }
        resolveClears();
        List<Piece> list = this.tray;
        if ((list instanceof Collection) && list.isEmpty()) {
            refillTray();
        } else {
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                if (((Piece) it.next()) != null) {
                    break;
                }
            }
            refillTray();
        }
        if (this.options.getTargetDistance() > 0.0f && this.distance >= this.options.getTargetDistance() && !this.crashed) {
            this.finished = true;
            this.running = false;
            RunnerListener runnerListener2 = this.listener;
            if (runnerListener2 != null) {
                runnerListener2.onStageComplete();
            }
            return true;
        }
        checkJam();
        return true;
    }

    private final void resolveClears() {
        RunnerListener runnerListener;
        RunnerListener runnerListener2;
        IntRange intRangeUntil = RangesKt.until(0, this.rows);
        ArrayList arrayList = new ArrayList();
        for (Integer num : intRangeUntil) {
            int iIntValue = num.intValue();
            Iterable iterableUntil = RangesKt.until(0, this.cols);
            if (!(iterableUntil instanceof Collection) || !((Collection) iterableUntil).isEmpty()) {
                Iterator it = iterableUntil.iterator();
                while (it.hasNext()) {
                    if (this.color[idx(((IntIterator) it).nextInt(), iIntValue)] != 0) {
                    }
                }
            }
            arrayList.add(num);
        }
        ArrayList arrayList2 = arrayList;
        IntRange intRangeUntil2 = RangesKt.until(0, this.cols);
        ArrayList arrayList3 = new ArrayList();
        for (Integer num2 : intRangeUntil2) {
            int iIntValue2 = num2.intValue();
            Iterable iterableUntil2 = RangesKt.until(0, this.rows);
            if (!(iterableUntil2 instanceof Collection) || !((Collection) iterableUntil2).isEmpty()) {
                Iterator it2 = iterableUntil2.iterator();
                while (it2.hasNext()) {
                    if (this.color[idx(iIntValue2, ((IntIterator) it2).nextInt())] != 0) {
                    }
                }
            }
            arrayList3.add(num2);
        }
        ArrayList arrayList4 = arrayList3;
        int size = arrayList2.size() + arrayList4.size();
        if (size == 0) {
            this.combo = 0;
            return;
        }
        HashSet hashSet = new HashSet();
        Iterator it3 = arrayList2.iterator();
        while (it3.hasNext()) {
            int iIntValue3 = ((Number) it3.next()).intValue();
            int i = this.cols;
            for (int i2 = 0; i2 < i; i2++) {
                hashSet.add(Integer.valueOf(idx(i2, iIntValue3)));
            }
        }
        Iterator it4 = arrayList4.iterator();
        while (it4.hasNext()) {
            int iIntValue4 = ((Number) it4.next()).intValue();
            int i3 = this.rows;
            for (int i4 = 0; i4 < i3; i4++) {
                hashSet.add(Integer.valueOf(idx(iIntValue4, i4)));
            }
        }
        Iterator it5 = arrayList2.iterator();
        int i5 = 0;
        while (true) {
            int i6 = 1;
            if (!it5.hasNext()) {
                break;
            }
            int iIntValue5 = ((Number) it5.next()).intValue();
            int i7 = this.cols;
            int i8 = this.color[idx(0, iIntValue5)];
            while (true) {
                if (i6 >= i7) {
                    i5++;
                    break;
                } else if (this.color[idx(i6, iIntValue5)] != i8) {
                    break;
                } else {
                    i6++;
                }
            }
        }
        Iterator it6 = arrayList4.iterator();
        while (it6.hasNext()) {
            int iIntValue6 = ((Number) it6.next()).intValue();
            int i9 = this.rows;
            int i10 = this.color[idx(iIntValue6, 0)];
            int i11 = 1;
            while (true) {
                if (i11 >= i9) {
                    i5++;
                    break;
                } else if (this.color[idx(iIntValue6, i11)] != i10) {
                    break;
                } else {
                    i11++;
                }
            }
        }
        Iterator it7 = hashSet.iterator();
        Intrinsics.checkNotNullExpressionValue(it7, "iterator(...)");
        float f = 0.0f;
        int i12 = 0;
        float f2 = 0.0f;
        while (true) {
            if (it7.hasNext()) {
                int iIntValue7 = ((Number) it7.next()).intValue();
                int i13 = WhenMappings.$EnumSwitchMapping$0[CellExtra.getEntries().get(this.extra[iIntValue7]).ordinal()];
                if (i13 == 1) {
                    i12++;
                } else if (i13 == 2) {
                    this.tokens++;
                    RunnerListener runnerListener3 = this.listener;
                    if (runnerListener3 != null) {
                        runnerListener3.onToken();
                    }
                } else if (i13 == 3) {
                    Booster booster = this.boosterCell[iIntValue7];
                    if (booster != null) {
                        activateBooster(booster);
                    }
                } else if (i13 != 4) {
                    throw new NoWhenBranchMatchedException();
                }
                int i14 = this.cols;
                f += iIntValue7 % i14;
                f2 += iIntValue7 / i14;
            } else {
                int i15 = this.combo + 1;
                this.combo = i15;
                if (i15 > this.maxCombo) {
                    this.maxCombo = i15;
                }
                this.obstaclesCleared += size;
                this.topSpeed = Math.max(this.topSpeed, hashSet.size());
                int size2 = (int) (((hashSet.size() * 12) + (size * size * 30) + (i5 * 60)) * ((Math.min(this.combo, 20) * 0.08f) + 1.0f) * this.options.getScoreMul() * (getDoubleActive() ? 2.0f : 1.0f));
                this.score += size2;
                float f3 = size;
                this.distance += 30.0f * f3 * (getSpeedActive() ? 2.0f : 1.0f);
                int i16 = (i12 * 3 * (getMagnetActive() ? 2 : 1)) + size;
                addCoins(i16);
                if (i16 > 0 && (runnerListener2 = this.listener) != null) {
                    runnerListener2.onCoin();
                }
                this.clearing.clear();
                Iterator it8 = hashSet.iterator();
                Intrinsics.checkNotNullExpressionValue(it8, "iterator(...)");
                while (it8.hasNext()) {
                    int iIntValue8 = ((Number) it8.next()).intValue();
                    this.color[iIntValue8] = 0;
                    this.extra[iIntValue8] = 0;
                    this.boosterCell[iIntValue8] = null;
                    this.clearing.add(Integer.valueOf(iIntValue8));
                }
                this.clearTimer = 0.32f;
                this.shake = Math.min(1.4f, this.shake + 0.4f + (f3 * 0.25f));
                float size3 = f / hashSet.size();
                float size4 = f2 / hashSet.size();
                this.popups.add(new Popup("+" + size2, size3, size4, GameView.COL_WHITE, 1.1f));
                if (i5 > 0) {
                    this.popups.add(new Popup("COLOR!", size3, size4 - 0.7f, -15043, 1.1f));
                }
                if (this.combo > 1) {
                    this.popups.add(new Popup("COMBO x" + this.combo, size3, size4 - 1.4f, -14032656, 1.1f));
                    RunnerListener runnerListener4 = this.listener;
                    if (runnerListener4 != null) {
                        runnerListener4.onCombo();
                    }
                    if (this.combo % 5 == 0 && (runnerListener = this.listener) != null) {
                        runnerListener.onMilestone();
                    }
                }
                RunnerListener runnerListener5 = this.listener;
                if (runnerListener5 != null) {
                    runnerListener5.onClear(size);
                    return;
                }
                return;
            }
        }
    }

    private final boolean lineIsMono(int length, Function1<? super Integer, Integer> cellColor) {
        int iIntValue = cellColor.invoke(0).intValue();
        for (int i = 1; i < length; i++) {
            if (cellColor.invoke(Integer.valueOf(i)).intValue() != iIntValue) {
                return false;
            }
        }
        return true;
    }

    private final void activateBooster(Booster kind) {
        this.powerupsUsed++;
        float staminaMul = this.options.getStaminaMul();
        int i = WhenMappings.$EnumSwitchMapping$1[kind.ordinal()];
        if (i == 1) {
            this.shieldActive = true;
            RunnerListener runnerListener = this.listener;
            if (runnerListener != null) {
                runnerListener.onPowerUp(kind);
                return;
            }
            return;
        }
        if (i == 2) {
            this.magnetTimer = staminaMul * 6.0f;
            grabLooseCoins();
            RunnerListener runnerListener2 = this.listener;
            if (runnerListener2 != null) {
                runnerListener2.onPowerUp(kind);
                return;
            }
            return;
        }
        if (i == 3) {
            this.speedTimer = staminaMul * 8.0f;
            RunnerListener runnerListener3 = this.listener;
            if (runnerListener3 != null) {
                runnerListener3.onPowerUp(kind);
                return;
            }
            return;
        }
        if (i == 4) {
            this.doubleTimer = staminaMul * 10.0f;
            RunnerListener runnerListener4 = this.listener;
            if (runnerListener4 != null) {
                runnerListener4.onDouble();
                return;
            }
            return;
        }
        if (i != 5) {
            throw new NoWhenBranchMatchedException();
        }
        this.slowmoTimer = staminaMul * 8.0f;
        RunnerListener runnerListener5 = this.listener;
        if (runnerListener5 != null) {
            runnerListener5.onPowerUp(kind);
        }
    }

    private final void grabLooseCoins() {
        int length = this.color.length;
        int i = 0;
        for (int i2 = 0; i2 < length; i2++) {
            if (this.color[i2] != 0 && CellExtra.getEntries().get(this.extra[i2]) == CellExtra.COIN) {
                this.extra[i2] = 0;
                i++;
            }
        }
        if (i > 0) {
            addCoins(i);
            RunnerListener runnerListener = this.listener;
            if (runnerListener != null) {
                runnerListener.onCoin();
            }
        }
    }

    private final void addCoins(float base) {
        this.coinAcc += base * this.options.getCoinMul() * this.options.getRewardMul();
        while (true) {
            float f = this.coinAcc;
            if (f < 1.0f) {
                return;
            }
            this.coins++;
            this.coinAcc = f - 1.0f;
        }
    }

    private final void checkJam() {
        if (anyTrayFits()) {
            return;
        }
        if (this.options.getPractice()) {
            relieve("RESCUE");
            return;
        }
        if (this.shieldActive) {
            this.shieldActive = false;
            RunnerListener runnerListener = this.listener;
            if (runnerListener != null) {
                runnerListener.onShieldBlock();
            }
            relieve("SAVED");
            return;
        }
        int i = this.revivesLeft;
        if (i <= 0) {
            crash(false);
            return;
        }
        this.revivesLeft = i - 1;
        RunnerListener runnerListener2 = this.listener;
        if (runnerListener2 != null) {
            runnerListener2.onRevive();
        }
        relieve("REVIVE");
    }

    private final boolean anyTrayFits() {
        for (Piece piece : this.tray) {
            if (piece != null && canPlaceAnywhere(piece.getShape())) {
                return true;
            }
        }
        return false;
    }

    private final boolean canPlaceAnywhere(PieceShape shape) {
        int rows = this.rows - shape.getRows();
        if (rows >= 0) {
            int i = 0;
            while (true) {
                int cols = this.cols - shape.getCols();
                if (cols >= 0) {
                    for (int i2 = 0; !fits(shape, i2, i); i2++) {
                        if (i2 != cols) {
                        }
                    }
                    return true;
                }
                if (i == rows) {
                    break;
                }
                i++;
            }
        }
        return false;
    }

    private final void relieve(String label) {
        List listSortedWith = CollectionsKt.sortedWith(RangesKt.until(0, this.rows), new Comparator() { // from class: com.championship.warriors.iron.legacy.runner.RunnerEngine$relieve$$inlined$sortedByDescending$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                int i;
                int iIntValue = ((Number) t2).intValue();
                int i2 = 0;
                Iterable iterableUntil = RangesKt.until(0, this.this$0.getCols());
                if ((iterableUntil instanceof Collection) && ((Collection) iterableUntil).isEmpty()) {
                    i = 0;
                } else {
                    Iterator<T> it = iterableUntil.iterator();
                    i = 0;
                    while (it.hasNext()) {
                        if (this.this$0.color[this.this$0.idx(((IntIterator) it).nextInt(), iIntValue)] != 0 && (i = i + 1) < 0) {
                            CollectionsKt.throwCountOverflow();
                        }
                    }
                }
                Integer numValueOf = Integer.valueOf(i);
                int iIntValue2 = ((Number) t).intValue();
                Iterable iterableUntil2 = RangesKt.until(0, this.this$0.getCols());
                if (!(iterableUntil2 instanceof Collection) || !((Collection) iterableUntil2).isEmpty()) {
                    Iterator<T> it2 = iterableUntil2.iterator();
                    while (it2.hasNext()) {
                        if (this.this$0.color[this.this$0.idx(((IntIterator) it2).nextInt(), iIntValue2)] != 0 && (i2 = i2 + 1) < 0) {
                            CollectionsKt.throwCountOverflow();
                        }
                    }
                }
                return ComparisonsKt.compareValues(numValueOf, Integer.valueOf(i2));
            }
        });
        this.clearing.clear();
        Iterator it = CollectionsKt.take(listSortedWith, 3).iterator();
        while (it.hasNext()) {
            int iIntValue = ((Number) it.next()).intValue();
            int i = this.cols;
            for (int i2 = 0; i2 < i; i2++) {
                int iIdx = idx(i2, iIntValue);
                int[] iArr = this.color;
                if (iArr[iIdx] != 0) {
                    iArr[iIdx] = 0;
                    this.extra[iIdx] = 0;
                    this.boosterCell[iIdx] = null;
                    this.clearing.add(Integer.valueOf(iIdx));
                }
            }
        }
        this.clearTimer = 0.32f;
        this.shake = Math.min(1.4f, this.shake + 0.6f);
        this.popups.add(new Popup(label, (this.cols - 1) / 2.0f, (this.rows - 1) / 2.0f, -14032656, 1.1f));
        List<Piece> list = this.tray;
        if (!(list instanceof Collection) || !list.isEmpty()) {
            Iterator<T> it2 = list.iterator();
            while (it2.hasNext()) {
                if (((Piece) it2.next()) != null) {
                    return;
                }
            }
        }
        refillTray();
    }

    private final void crash(boolean force) {
        RunnerListener runnerListener;
        this.crashed = true;
        this.running = false;
        this.shake = 1.4f;
        if (force || (runnerListener = this.listener) == null) {
            return;
        }
        runnerListener.onCrash();
    }

    private final void seedClutter() {
        int i = 0;
        int iCoerceIn = RangesKt.coerceIn((int) (this.cols * this.rows * (this.config.getDoubleBlockChance() / Math.max(1.0f, this.options.getAgilityMul())) * 0.22f), 0, 14);
        int i2 = 0;
        while (i < iCoerceIn && i2 < 200) {
            i2++;
            int iNextInt = this.random.nextInt(this.cols);
            Random random = this.random;
            int i3 = this.rows;
            int iIdx = idx(iNextInt, random.nextInt(i3 / 2, i3));
            int[] iArr = this.color;
            if (iArr[iIdx] == 0) {
                iArr[iIdx] = ArraysKt.random(PieceCatalog.INSTANCE.getPalette(), this.random);
                i++;
            }
        }
    }

    private final void refillTray() {
        int size = this.tray.size();
        for (int i = 0; i < size; i++) {
            if (this.tray.get(i) == null) {
                this.tray.set(i, makePiece());
            }
        }
        if (this.options.getPractice()) {
            for (int i2 = 0; !anyTrayFits() && i2 < 12; i2++) {
                relieve("RESCUE");
            }
            return;
        }
        for (int i3 = 0; !anyTrayFits() && !boardEmpty() && i3 < 8; i3++) {
            int size2 = this.tray.size();
            for (int i4 = 0; i4 < size2; i4++) {
                this.tray.set(i4, makePiece());
            }
        }
    }

    private final boolean boardEmpty() {
        for (int i : this.color) {
            if (i != 0) {
                return false;
            }
        }
        return true;
    }

    private final Piece makePiece() {
        CellExtra cellExtra;
        Booster boosterRandomBooster;
        PieceShape pieceShapePickShape = pickShape();
        int i = PieceCatalog.INSTANCE.getPalette()[this.random.nextInt(PieceCatalog.INSTANCE.getPalette().length)];
        CellExtra cellExtra2 = CellExtra.NONE;
        float fNextFloat = this.random.nextFloat();
        if (fNextFloat < this.config.getPowerUpChance()) {
            CellExtra cellExtra3 = CellExtra.BOOSTER;
            boosterRandomBooster = randomBooster();
            cellExtra = cellExtra3;
        } else {
            if (fNextFloat < this.config.getPowerUpChance() + this.config.getCoinChance()) {
                cellExtra2 = this.random.nextFloat() < 0.07f ? CellExtra.GOLD : CellExtra.COIN;
            }
            cellExtra = cellExtra2;
            boosterRandomBooster = null;
        }
        return new Piece(pieceShapePickShape, i, cellExtra, cellExtra == CellExtra.NONE ? -1 : this.random.nextInt(pieceShapePickShape.getSize()), boosterRandomBooster);
    }

    private final PieceShape pickShape() {
        float fFilledCount = filledCount() / (this.cols * this.rows);
        List<PieceShape> listUpTo = PieceCatalog.INSTANCE.upTo(fFilledCount > 0.62f ? 3 : fFilledCount > 0.42f ? 4 : 9);
        Iterator<PieceShape> it = listUpTo.iterator();
        int iCoerceAtLeast = 0;
        while (it.hasNext()) {
            iCoerceAtLeast += RangesKt.coerceAtLeast(11 - it.next().getSize(), 1);
        }
        int iNextInt = this.random.nextInt(iCoerceAtLeast);
        for (PieceShape pieceShape : listUpTo) {
            iNextInt -= RangesKt.coerceAtLeast(11 - pieceShape.getSize(), 1);
            if (iNextInt < 0) {
                return pieceShape;
            }
        }
        return (PieceShape) CollectionsKt.last((List) listUpTo);
    }

    private final Booster randomBooster() {
        return Booster.getEntries().get(this.random.nextInt(Booster.getEntries().size()));
    }

    private final int filledCount() {
        int i = 0;
        for (int i2 : this.color) {
            if (i2 != 0) {
                i++;
            }
        }
        return i;
    }

    public final void update(float dtSeconds) {
        if (!this.running || this.finished || this.crashed) {
            float f = this.shake;
            if (f > 0.0f) {
                this.shake = Math.max(0.0f, f - (4.5f * dtSeconds));
            }
            agePopups(dtSeconds);
            return;
        }
        float fCoerceIn = RangesKt.coerceIn(dtSeconds, 0.0f, 0.05f);
        this.playTime += fCoerceIn;
        float f2 = this.speedTimer;
        if (f2 > 0.0f) {
            this.speedTimer = Math.max(0.0f, f2 - fCoerceIn);
        }
        float f3 = this.magnetTimer;
        if (f3 > 0.0f) {
            this.magnetTimer = Math.max(0.0f, f3 - fCoerceIn);
        }
        float f4 = this.doubleTimer;
        if (f4 > 0.0f) {
            this.doubleTimer = Math.max(0.0f, f4 - fCoerceIn);
        }
        float f5 = this.slowmoTimer;
        if (f5 > 0.0f) {
            this.slowmoTimer = Math.max(0.0f, f5 - fCoerceIn);
        }
        float f6 = this.clearTimer;
        if (f6 > 0.0f) {
            float fMax = Math.max(0.0f, f6 - fCoerceIn);
            this.clearTimer = fMax;
            if (fMax == 0.0f) {
                this.clearing.clear();
            }
        }
        float f7 = this.shake;
        if (f7 > 0.0f) {
            this.shake = Math.max(0.0f, f7 - (4.5f * fCoerceIn));
        }
        agePopups(fCoerceIn);
        while (this.options.getCheckpointGap() > 0.0f && this.distance >= this.nextCheckpoint) {
            this.timeRemaining += this.options.getCheckpointBonus();
            this.nextCheckpoint += this.options.getCheckpointGap();
            RunnerListener runnerListener = this.listener;
            if (runnerListener != null) {
                runnerListener.onCheckpoint();
            }
        }
        if (isTimeTrial() && !getSlowmoActive()) {
            float f8 = this.timeRemaining - fCoerceIn;
            this.timeRemaining = f8;
            if (f8 <= 0.0f && !this.finished) {
                this.timeRemaining = 0.0f;
                this.timedOut = true;
                crash(true);
            }
        }
        if (this.options.getTargetDistance() <= 0.0f || this.distance < this.options.getTargetDistance() || this.crashed) {
            return;
        }
        this.finished = true;
        this.running = false;
        RunnerListener runnerListener2 = this.listener;
        if (runnerListener2 != null) {
            runnerListener2.onStageComplete();
        }
    }

    private final void agePopups(float dt) {
        if (this.popups.isEmpty()) {
            return;
        }
        Iterator<Popup> it = this.popups.iterator();
        while (it.hasNext()) {
            Popup next = it.next();
            next.setLife(next.getLife() - dt);
            if (next.getLife() <= 0.0f) {
                it.remove();
            }
        }
    }
}
