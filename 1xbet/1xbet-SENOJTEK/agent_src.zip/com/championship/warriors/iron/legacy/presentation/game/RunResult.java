package com.championship.warriors.iron.legacy.presentation.game;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: GameViewModel.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\bB\b\u0086\b\u0018\u00002\u00020\u0001B§\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\u0006\u0010\r\u001a\u00020\u0005\u0012\u0006\u0010\u000e\u001a\u00020\u0005\u0012\u0006\u0010\u000f\u001a\u00020\t\u0012\u0006\u0010\u0010\u001a\u00020\u0005\u0012\u0006\u0010\u0011\u001a\u00020\t\u0012\u0006\u0010\u0012\u001a\u00020\u0005\u0012\u0006\u0010\u0013\u001a\u00020\u0005\u0012\u0006\u0010\u0014\u001a\u00020\t\u0012\u0006\u0010\u0015\u001a\u00020\t\u0012\u0006\u0010\u0016\u001a\u00020\t\u0012\u0006\u0010\u0017\u001a\u00020\t\u0012\u0006\u0010\u0018\u001a\u00020\t¢\u0006\u0004\b\u0019\u0010\u001aJ\t\u00102\u001a\u00020\u0003HÆ\u0003J\t\u00103\u001a\u00020\u0005HÆ\u0003J\t\u00104\u001a\u00020\u0003HÆ\u0003J\t\u00105\u001a\u00020\u0003HÆ\u0003J\t\u00106\u001a\u00020\tHÆ\u0003J\t\u00107\u001a\u00020\tHÆ\u0003J\t\u00108\u001a\u00020\u0005HÆ\u0003J\t\u00109\u001a\u00020\u0005HÆ\u0003J\t\u0010:\u001a\u00020\u0005HÆ\u0003J\t\u0010;\u001a\u00020\u0005HÆ\u0003J\t\u0010<\u001a\u00020\tHÆ\u0003J\t\u0010=\u001a\u00020\u0005HÆ\u0003J\t\u0010>\u001a\u00020\tHÆ\u0003J\t\u0010?\u001a\u00020\u0005HÆ\u0003J\t\u0010@\u001a\u00020\u0005HÆ\u0003J\t\u0010A\u001a\u00020\tHÆ\u0003J\t\u0010B\u001a\u00020\tHÆ\u0003J\t\u0010C\u001a\u00020\tHÆ\u0003J\t\u0010D\u001a\u00020\tHÆ\u0003J\t\u0010E\u001a\u00020\tHÆ\u0003JÑ\u0001\u0010F\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\t2\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\t2\b\b\u0002\u0010\u0010\u001a\u00020\u00052\b\b\u0002\u0010\u0011\u001a\u00020\t2\b\b\u0002\u0010\u0012\u001a\u00020\u00052\b\b\u0002\u0010\u0013\u001a\u00020\u00052\b\b\u0002\u0010\u0014\u001a\u00020\t2\b\b\u0002\u0010\u0015\u001a\u00020\t2\b\b\u0002\u0010\u0016\u001a\u00020\t2\b\b\u0002\u0010\u0017\u001a\u00020\t2\b\b\u0002\u0010\u0018\u001a\u00020\tHÆ\u0001J\u0013\u0010G\u001a\u00020\t2\b\u0010H\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010I\u001a\u00020\u0005HÖ\u0001J\t\u0010J\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001cR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001cR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0011\u0010\n\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\"R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001eR\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u001eR\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u001eR\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u001eR\u0011\u0010\u000f\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\"R\u0011\u0010\u0010\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001eR\u0011\u0010\u0011\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b*\u0010\"R\u0011\u0010\u0012\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001eR\u0011\u0010\u0013\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b,\u0010\u001eR\u0011\u0010\u0014\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b-\u0010\"R\u0011\u0010\u0015\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b.\u0010\"R\u0011\u0010\u0016\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b/\u0010\"R\u0011\u0010\u0017\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b0\u0010\"R\u0011\u0010\u0018\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b1\u0010\"¨\u0006K"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/RunResult;", "", "mode", "", "stageId", "", "challengeId", "tournamentId", "victory", "", "timedOut", "score", "distance", "coins", "stars", "newBest", "xpGained", "leveledUp", "newLevel", "nextStageId", "careerAdvanced", "finalVictory", "challengePassed", "tournamentQualified", "tournamentFinal", "<init>", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ZZIIIIZIZIIZZZZZ)V", "getMode", "()Ljava/lang/String;", "getStageId", "()I", "getChallengeId", "getTournamentId", "getVictory", "()Z", "getTimedOut", "getScore", "getDistance", "getCoins", "getStars", "getNewBest", "getXpGained", "getLeveledUp", "getNewLevel", "getNextStageId", "getCareerAdvanced", "getFinalVictory", "getChallengePassed", "getTournamentQualified", "getTournamentFinal", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component20", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunResult {
    private final boolean careerAdvanced;
    private final String challengeId;
    private final boolean challengePassed;
    private final int coins;
    private final int distance;
    private final boolean finalVictory;
    private final boolean leveledUp;
    private final String mode;
    private final boolean newBest;
    private final int newLevel;
    private final int nextStageId;
    private final int score;
    private final int stageId;
    private final int stars;
    private final boolean timedOut;
    private final boolean tournamentFinal;
    private final String tournamentId;
    private final boolean tournamentQualified;
    private final boolean victory;
    private final int xpGained;

    public static /* synthetic */ RunResult copy$default(RunResult runResult, String str, int i, String str2, String str3, boolean z, boolean z2, int i2, int i3, int i4, int i5, boolean z3, int i6, boolean z4, int i7, int i8, boolean z5, boolean z6, boolean z7, boolean z8, boolean z9, int i9, Object obj) {
        boolean z10;
        boolean z11;
        String str4 = (i9 & 1) != 0 ? runResult.mode : str;
        int i10 = (i9 & 2) != 0 ? runResult.stageId : i;
        String str5 = (i9 & 4) != 0 ? runResult.challengeId : str2;
        String str6 = (i9 & 8) != 0 ? runResult.tournamentId : str3;
        boolean z12 = (i9 & 16) != 0 ? runResult.victory : z;
        boolean z13 = (i9 & 32) != 0 ? runResult.timedOut : z2;
        int i11 = (i9 & 64) != 0 ? runResult.score : i2;
        int i12 = (i9 & 128) != 0 ? runResult.distance : i3;
        int i13 = (i9 & 256) != 0 ? runResult.coins : i4;
        int i14 = (i9 & 512) != 0 ? runResult.stars : i5;
        boolean z14 = (i9 & 1024) != 0 ? runResult.newBest : z3;
        int i15 = (i9 & 2048) != 0 ? runResult.xpGained : i6;
        boolean z15 = (i9 & 4096) != 0 ? runResult.leveledUp : z4;
        int i16 = (i9 & 8192) != 0 ? runResult.newLevel : i7;
        String str7 = str4;
        int i17 = (i9 & 16384) != 0 ? runResult.nextStageId : i8;
        boolean z16 = (i9 & 32768) != 0 ? runResult.careerAdvanced : z5;
        boolean z17 = (i9 & 65536) != 0 ? runResult.finalVictory : z6;
        boolean z18 = (i9 & 131072) != 0 ? runResult.challengePassed : z7;
        boolean z19 = (i9 & 262144) != 0 ? runResult.tournamentQualified : z8;
        if ((i9 & 524288) != 0) {
            z11 = z19;
            z10 = runResult.tournamentFinal;
        } else {
            z10 = z9;
            z11 = z19;
        }
        return runResult.copy(str7, i10, str5, str6, z12, z13, i11, i12, i13, i14, z14, i15, z15, i16, i17, z16, z17, z18, z11, z10);
    }

    /* renamed from: component1, reason: from getter */
    public final String getMode() {
        return this.mode;
    }

    /* renamed from: component10, reason: from getter */
    public final int getStars() {
        return this.stars;
    }

    /* renamed from: component11, reason: from getter */
    public final boolean getNewBest() {
        return this.newBest;
    }

    /* renamed from: component12, reason: from getter */
    public final int getXpGained() {
        return this.xpGained;
    }

    /* renamed from: component13, reason: from getter */
    public final boolean getLeveledUp() {
        return this.leveledUp;
    }

    /* renamed from: component14, reason: from getter */
    public final int getNewLevel() {
        return this.newLevel;
    }

    /* renamed from: component15, reason: from getter */
    public final int getNextStageId() {
        return this.nextStageId;
    }

    /* renamed from: component16, reason: from getter */
    public final boolean getCareerAdvanced() {
        return this.careerAdvanced;
    }

    /* renamed from: component17, reason: from getter */
    public final boolean getFinalVictory() {
        return this.finalVictory;
    }

    /* renamed from: component18, reason: from getter */
    public final boolean getChallengePassed() {
        return this.challengePassed;
    }

    /* renamed from: component19, reason: from getter */
    public final boolean getTournamentQualified() {
        return this.tournamentQualified;
    }

    /* renamed from: component2, reason: from getter */
    public final int getStageId() {
        return this.stageId;
    }

    /* renamed from: component20, reason: from getter */
    public final boolean getTournamentFinal() {
        return this.tournamentFinal;
    }

    /* renamed from: component3, reason: from getter */
    public final String getChallengeId() {
        return this.challengeId;
    }

    /* renamed from: component4, reason: from getter */
    public final String getTournamentId() {
        return this.tournamentId;
    }

    /* renamed from: component5, reason: from getter */
    public final boolean getVictory() {
        return this.victory;
    }

    /* renamed from: component6, reason: from getter */
    public final boolean getTimedOut() {
        return this.timedOut;
    }

    /* renamed from: component7, reason: from getter */
    public final int getScore() {
        return this.score;
    }

    /* renamed from: component8, reason: from getter */
    public final int getDistance() {
        return this.distance;
    }

    /* renamed from: component9, reason: from getter */
    public final int getCoins() {
        return this.coins;
    }

    public final RunResult copy(String mode, int stageId, String challengeId, String tournamentId, boolean victory, boolean timedOut, int score, int distance, int coins, int stars, boolean newBest, int xpGained, boolean leveledUp, int newLevel, int nextStageId, boolean careerAdvanced, boolean finalVictory, boolean challengePassed, boolean tournamentQualified, boolean tournamentFinal) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        Intrinsics.checkNotNullParameter(challengeId, "challengeId");
        Intrinsics.checkNotNullParameter(tournamentId, "tournamentId");
        return new RunResult(mode, stageId, challengeId, tournamentId, victory, timedOut, score, distance, coins, stars, newBest, xpGained, leveledUp, newLevel, nextStageId, careerAdvanced, finalVictory, challengePassed, tournamentQualified, tournamentFinal);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunResult)) {
            return false;
        }
        RunResult runResult = (RunResult) other;
        return Intrinsics.areEqual(this.mode, runResult.mode) && this.stageId == runResult.stageId && Intrinsics.areEqual(this.challengeId, runResult.challengeId) && Intrinsics.areEqual(this.tournamentId, runResult.tournamentId) && this.victory == runResult.victory && this.timedOut == runResult.timedOut && this.score == runResult.score && this.distance == runResult.distance && this.coins == runResult.coins && this.stars == runResult.stars && this.newBest == runResult.newBest && this.xpGained == runResult.xpGained && this.leveledUp == runResult.leveledUp && this.newLevel == runResult.newLevel && this.nextStageId == runResult.nextStageId && this.careerAdvanced == runResult.careerAdvanced && this.finalVictory == runResult.finalVictory && this.challengePassed == runResult.challengePassed && this.tournamentQualified == runResult.tournamentQualified && this.tournamentFinal == runResult.tournamentFinal;
    }

    public int hashCode() {
        return (((((((((((((((((((((((((((((((((((((this.mode.hashCode() * 31) + Integer.hashCode(this.stageId)) * 31) + this.challengeId.hashCode()) * 31) + this.tournamentId.hashCode()) * 31) + Boolean.hashCode(this.victory)) * 31) + Boolean.hashCode(this.timedOut)) * 31) + Integer.hashCode(this.score)) * 31) + Integer.hashCode(this.distance)) * 31) + Integer.hashCode(this.coins)) * 31) + Integer.hashCode(this.stars)) * 31) + Boolean.hashCode(this.newBest)) * 31) + Integer.hashCode(this.xpGained)) * 31) + Boolean.hashCode(this.leveledUp)) * 31) + Integer.hashCode(this.newLevel)) * 31) + Integer.hashCode(this.nextStageId)) * 31) + Boolean.hashCode(this.careerAdvanced)) * 31) + Boolean.hashCode(this.finalVictory)) * 31) + Boolean.hashCode(this.challengePassed)) * 31) + Boolean.hashCode(this.tournamentQualified)) * 31) + Boolean.hashCode(this.tournamentFinal);
    }

    public String toString() {
        return "RunResult(mode=" + this.mode + ", stageId=" + this.stageId + ", challengeId=" + this.challengeId + ", tournamentId=" + this.tournamentId + ", victory=" + this.victory + ", timedOut=" + this.timedOut + ", score=" + this.score + ", distance=" + this.distance + ", coins=" + this.coins + ", stars=" + this.stars + ", newBest=" + this.newBest + ", xpGained=" + this.xpGained + ", leveledUp=" + this.leveledUp + ", newLevel=" + this.newLevel + ", nextStageId=" + this.nextStageId + ", careerAdvanced=" + this.careerAdvanced + ", finalVictory=" + this.finalVictory + ", challengePassed=" + this.challengePassed + ", tournamentQualified=" + this.tournamentQualified + ", tournamentFinal=" + this.tournamentFinal + ")";
    }

    public RunResult(String mode, int i, String challengeId, String tournamentId, boolean z, boolean z2, int i2, int i3, int i4, int i5, boolean z3, int i6, boolean z4, int i7, int i8, boolean z5, boolean z6, boolean z7, boolean z8, boolean z9) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        Intrinsics.checkNotNullParameter(challengeId, "challengeId");
        Intrinsics.checkNotNullParameter(tournamentId, "tournamentId");
        this.mode = mode;
        this.stageId = i;
        this.challengeId = challengeId;
        this.tournamentId = tournamentId;
        this.victory = z;
        this.timedOut = z2;
        this.score = i2;
        this.distance = i3;
        this.coins = i4;
        this.stars = i5;
        this.newBest = z3;
        this.xpGained = i6;
        this.leveledUp = z4;
        this.newLevel = i7;
        this.nextStageId = i8;
        this.careerAdvanced = z5;
        this.finalVictory = z6;
        this.challengePassed = z7;
        this.tournamentQualified = z8;
        this.tournamentFinal = z9;
    }

    public final String getMode() {
        return this.mode;
    }

    public final int getStageId() {
        return this.stageId;
    }

    public final String getChallengeId() {
        return this.challengeId;
    }

    public final String getTournamentId() {
        return this.tournamentId;
    }

    public final boolean getVictory() {
        return this.victory;
    }

    public final boolean getTimedOut() {
        return this.timedOut;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getDistance() {
        return this.distance;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getStars() {
        return this.stars;
    }

    public final boolean getNewBest() {
        return this.newBest;
    }

    public final int getXpGained() {
        return this.xpGained;
    }

    public final boolean getLeveledUp() {
        return this.leveledUp;
    }

    public final int getNewLevel() {
        return this.newLevel;
    }

    public final int getNextStageId() {
        return this.nextStageId;
    }

    public final boolean getCareerAdvanced() {
        return this.careerAdvanced;
    }

    public final boolean getFinalVictory() {
        return this.finalVictory;
    }

    public final boolean getChallengePassed() {
        return this.challengePassed;
    }

    public final boolean getTournamentQualified() {
        return this.tournamentQualified;
    }

    public final boolean getTournamentFinal() {
        return this.tournamentFinal;
    }
}
