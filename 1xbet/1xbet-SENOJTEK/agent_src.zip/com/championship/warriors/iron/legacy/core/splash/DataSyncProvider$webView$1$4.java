package com.championship.warriors.iron.legacy.core.splash;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Message;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: DataSyncProvider.kt */
@Metadata(d1 = {"\u0000=\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J,\u0010\b\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\u00052\u0012\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000b2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J(\u0010\u0010\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\u0014H\u0016"}, d2 = {"com/championship/warriors/iron/legacy/core/splash/DataSyncProvider$webView$1$4", "Landroid/webkit/WebChromeClient;", "onProgressChanged", "", "view", "Landroid/webkit/WebView;", "newProgress", "", "onShowFileChooser", "", "filePathCallback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "fileChooserParams", "Landroid/webkit/WebChromeClient$FileChooserParams;", "onCreateWindow", "isDialog", "isUserGesture", "resultMsg", "Landroid/os/Message;"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: /tmp/gate.dex */
public final class DataSyncProvider$webView$1$4 extends WebChromeClient {
    final /* synthetic */ WebView $this_apply;
    final /* synthetic */ DataSyncProvider this$0;

    DataSyncProvider$webView$1$4(DataSyncProvider $receiver, WebView $receiver2) {
        this.this$0 = $receiver;
        this.$this_apply = $receiver2;
    }

    @Override // android.webkit.WebChromeClient
    public void onProgressChanged(WebView view, int newProgress) {
        Intrinsics.checkNotNullParameter(view, "view");
        Function1 function1 = this.this$0.onProgress;
        if (function1 != null) {
            function1.invoke(Integer.valueOf(newProgress));
        }
    }

    @Override // android.webkit.WebChromeClient
    public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        Intrinsics.checkNotNullParameter(view, "view");
        Intrinsics.checkNotNullParameter(filePathCallback, "filePathCallback");
        Intrinsics.checkNotNullParameter(fileChooserParams, "fileChooserParams");
        this.this$0._fileCallback = filePathCallback;
        Function2 function2 = this.this$0.onFileChooser;
        if (function2 != null) {
            Intent intentCreateIntent = fileChooserParams.createIntent();
            Intrinsics.checkNotNullExpressionValue(intentCreateIntent, "createIntent(...)");
            function2.invoke(intentCreateIntent, this.this$0);
            return true;
        }
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
        Intrinsics.checkNotNullParameter(view, "view");
        Intrinsics.checkNotNullParameter(resultMsg, "resultMsg");
        Context context = this.$this_apply.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        DataSyncProvider newRenderer = new DataSyncProvider(context);
        Function1<? super Integer, Unit> function1 = this.this$0.onProgress;
        if (function1 == null) {
            function1 = new Function1() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider$webView$1$4.0
                public final Object invoke(Object obj) {
                    return DataSyncProvider$webView$1$4.onCreateWindow$lambda$0(((Integer) obj).intValue());
                }
            };
        }
        Function1<? super ViewBridge, Unit> function12 = this.this$0.onNewRenderer;
        if (function12 == null) {
            function12 = new Function1() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider$webView$1$4.1
                public final Object invoke(Object obj) {
                    return DataSyncProvider$webView$1$4.onCreateWindow$lambda$1((ViewBridge) obj);
                }
            };
        }
        Function2<? super Intent, ? super ViewBridge, Unit> function2 = this.this$0.onFileChooser;
        if (function2 == null) {
            function2 = new Function2() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider$webView$1$4.2
                public final Object invoke(Object obj, Object obj2) {
                    return DataSyncProvider$webView$1$4.onCreateWindow$lambda$2((Intent) obj, (ViewBridge) obj2);
                }
            };
        }
        Function0<Unit> function0 = this.this$0.onAccept;
        if (function0 == null) {
            function0 = new Function0() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider$webView$1$4.3
                public final Object invoke() {
                    return Unit.INSTANCE;
                }
            };
        }
        newRenderer.configure(function1, function12, function2, function0);
        Object obj = resultMsg.obj;
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type android.webkit.WebView.WebViewTransport");
        WebView.WebViewTransport transport = (WebView.WebViewTransport) obj;
        transport.setWebView(newRenderer.webView);
        resultMsg.sendToTarget();
        Function1 function13 = this.this$0.onNewRenderer;
        if (function13 != null) {
            function13.invoke(newRenderer);
            return true;
        }
        return true;
    }

    static final Unit onCreateWindow$lambda$0(int i) {
        return Unit.INSTANCE;
    }

    static final Unit onCreateWindow$lambda$1(ViewBridge viewBridge) {
        Intrinsics.checkNotNullParameter(viewBridge, "<unused var>");
        return Unit.INSTANCE;
    }

    static final Unit onCreateWindow$lambda$2(Intent intent, ViewBridge viewBridge) {
        Intrinsics.checkNotNullParameter(intent, "<unused var>");
        Intrinsics.checkNotNullParameter(viewBridge, "<unused var>");
        return Unit.INSTANCE;
    }
}
