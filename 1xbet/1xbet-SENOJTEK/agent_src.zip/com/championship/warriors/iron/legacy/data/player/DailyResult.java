package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;

/* compiled from: PlayerRepository.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J'\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0012\u001a\u00020\u00032\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\f¨\u0006\u0017"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/DailyResult;", "", "claimed", "", "day", "", "coins", "<init>", "(ZII)V", "getClaimed", "()Z", "getDay", "()I", "getCoins", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class DailyResult {
    private final boolean claimed;
    private final int coins;
    private final int day;

    public static /* synthetic */ DailyResult copy$default(DailyResult dailyResult, boolean z, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            z = dailyResult.claimed;
        }
        if ((i3 & 2) != 0) {
            i = dailyResult.day;
        }
        if ((i3 & 4) != 0) {
            i2 = dailyResult.coins;
        }
        return dailyResult.copy(z, i, i2);
    }

    /* renamed from: component1, reason: from getter */
    public final boolean getClaimed() {
        return this.claimed;
    }

    /* renamed from: component2, reason: from getter */
    public final int getDay() {
        return this.day;
    }

    /* renamed from: component3, reason: from getter */
    public final int getCoins() {
        return this.coins;
    }

    public final DailyResult copy(boolean claimed, int day, int coins) {
        return new DailyResult(claimed, day, coins);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof DailyResult)) {
            return false;
        }
        DailyResult dailyResult = (DailyResult) other;
        return this.claimed == dailyResult.claimed && this.day == dailyResult.day && this.coins == dailyResult.coins;
    }

    public int hashCode() {
        return (((Boolean.hashCode(this.claimed) * 31) + Integer.hashCode(this.day)) * 31) + Integer.hashCode(this.coins);
    }

    public String toString() {
        return "DailyResult(claimed=" + this.claimed + ", day=" + this.day + ", coins=" + this.coins + ")";
    }

    public DailyResult(boolean z, int i, int i2) {
        this.claimed = z;
        this.day = i;
        this.coins = i2;
    }

    public final boolean getClaimed() {
        return this.claimed;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getDay() {
        return this.day;
    }
}
