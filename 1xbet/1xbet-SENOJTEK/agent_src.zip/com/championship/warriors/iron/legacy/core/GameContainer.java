package com.championship.warriors.iron.legacy.core;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.audio.AudioController;
import com.championship.warriors.iron.legacy.data.SettingsRepository;
import com.championship.warriors.iron.legacy.data.player.PlayerRepository;
import com.championship.warriors.iron.legacy.data.stage.StageRepository;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: GameContainer.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aR\u001e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001e\u0010\n\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\t@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001e\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0004\u001a\u00020\r@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u001e\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0004\u001a\u00020\u0011@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/GameContainer;", "", "<init>", "()V", "value", "Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;", "stages", "getStages", "()Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;", "Lcom/championship/warriors/iron/legacy/data/player/PlayerRepository;", "player", "getPlayer", "()Lcom/championship/warriors/iron/legacy/data/player/PlayerRepository;", "Lcom/championship/warriors/iron/legacy/data/SettingsRepository;", "settings", "getSettings", "()Lcom/championship/warriors/iron/legacy/data/SettingsRepository;", "Lcom/championship/warriors/iron/legacy/audio/AudioController;", "audio", "getAudio", "()Lcom/championship/warriors/iron/legacy/audio/AudioController;", "initialized", "", "init", "", "context", "Landroid/content/Context;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class GameContainer {
    public static final GameContainer INSTANCE = new GameContainer();
    private static AudioController audio;
    private static volatile boolean initialized;
    private static PlayerRepository player;
    private static SettingsRepository settings;
    private static StageRepository stages;

    private GameContainer() {
    }

    public final StageRepository getStages() {
        StageRepository stageRepository = stages;
        if (stageRepository != null) {
            return stageRepository;
        }
        Intrinsics.throwUninitializedPropertyAccessException("stages");
        return null;
    }

    public final PlayerRepository getPlayer() {
        PlayerRepository playerRepository = player;
        if (playerRepository != null) {
            return playerRepository;
        }
        Intrinsics.throwUninitializedPropertyAccessException("player");
        return null;
    }

    public final SettingsRepository getSettings() {
        SettingsRepository settingsRepository = settings;
        if (settingsRepository != null) {
            return settingsRepository;
        }
        Intrinsics.throwUninitializedPropertyAccessException("settings");
        return null;
    }

    public final AudioController getAudio() {
        AudioController audioController = audio;
        if (audioController != null) {
            return audioController;
        }
        Intrinsics.throwUninitializedPropertyAccessException("audio");
        return null;
    }

    public final void init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (initialized) {
            return;
        }
        synchronized (this) {
            if (initialized) {
                return;
            }
            Context applicationContext = context.getApplicationContext();
            GameContainer gameContainer = INSTANCE;
            stages = new StageRepository();
            Intrinsics.checkNotNull(applicationContext);
            settings = new SettingsRepository(applicationContext);
            player = new PlayerRepository(applicationContext, gameContainer.getStages());
            audio = new AudioController(applicationContext, gameContainer.getSettings());
            initialized = true;
            Unit unit = Unit.INSTANCE;
        }
    }
}
