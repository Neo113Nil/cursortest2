package com.championship.warriors.iron.legacy.presentation.career;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.os.BundleKt;
import androidx.core.widget.ImageViewCompat;
import androidx.core.widget.TextViewCompat;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.data.stage.StageData;
import com.championship.warriors.iron.legacy.data.stage.StageGoal;
import com.championship.warriors.iron.legacy.databinding.FragmentStageDetailsBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: StageDetailsFragment.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002R\u0014\u0010\u0005\u001a\u00020\u00068BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u0012"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/career/StageDetailsFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentStageDetailsBinding;", "<init>", "()V", "stageId", "", "getStageId", "()I", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "addGoal", "goal", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class StageDetailsFragment extends BaseFragment<FragmentStageDetailsBinding> {

    /* compiled from: StageDetailsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.career.StageDetailsFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentStageDetailsBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentStageDetailsBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentStageDetailsBinding;", 0);
        }

        public final FragmentStageDetailsBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentStageDetailsBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentStageDetailsBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public StageDetailsFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    private final int getStageId() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            return arguments.getInt("stageId");
        }
        return 1;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        StageData stageDataStageById = GameContainer.INSTANCE.getStages().stageById(getStageId());
        if (stageDataStageById == null) {
            return;
        }
        PlayerState playerStateCurrent = GameContainer.INSTANCE.getPlayer().current();
        getBinding().stageName.setText(getString(stageDataStageById.getNameRes()));
        getBinding().stageEnv.setText(getString(stageDataStageById.getEnvRes()));
        getBinding().accentBar.setBackgroundColor(ContextCompat.getColor(requireContext(), stageDataStageById.getColorRes()));
        getBinding().bestText.setText(getString(R.string.stage_best, Integer.valueOf(playerStateCurrent.bestFor(getStageId()))));
        int iStarsFor = playerStateCurrent.starsFor(getStageId());
        int i = 0;
        for (Object obj : CollectionsKt.listOf((Object[]) new ImageView[]{getBinding().star1, getBinding().star2, getBinding().star3})) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            ImageViewCompat.setImageTintList((ImageView) obj, ColorStateList.valueOf(ContextCompat.getColor(requireContext(), i < iStarsFor ? R.color.star_on : R.color.star_off)));
            i = i2;
        }
        Iterator<StageGoal> it = stageDataStageById.getGoals().iterator();
        while (it.hasNext()) {
            addGoal(it.next());
        }
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.career.StageDetailsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                StageDetailsFragment.onViewCreated$lambda$1(this.f$0, view2);
            }
        });
        getBinding().playButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.career.StageDetailsFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                StageDetailsFragment.onViewCreated$lambda$2(this.f$0, view2);
            }
        });
    }

    static final void onViewCreated$lambda$1(StageDetailsFragment stageDetailsFragment, View view) {
        stageDetailsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(stageDetailsFragment).popBackStack();
    }

    static final void onViewCreated$lambda$2(StageDetailsFragment stageDetailsFragment, View view) {
        stageDetailsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(stageDetailsFragment).navigate(R.id.action_global_open_run, BundleKt.bundleOf(TuplesKt.to("mode", "CAREER"), TuplesKt.to("stageId", Integer.valueOf(stageDetailsFragment.getStageId())), TuplesKt.to("challengeId", ""), TuplesKt.to("tournamentId", "")));
    }

    private final void addGoal(StageGoal goal) {
        Pair pair;
        if (goal instanceof StageGoal.Distance) {
            pair = TuplesKt.to(Integer.valueOf(R.drawable.ic_flag), getString(R.string.m_distance, Integer.valueOf(((StageGoal.Distance) goal).getTarget())));
        } else if (goal instanceof StageGoal.Collect) {
            pair = TuplesKt.to(Integer.valueOf(R.drawable.ic_coin), getString(R.string.m_coins, Integer.valueOf(((StageGoal.Collect) goal).getTarget())));
        } else if (goal instanceof StageGoal.Score) {
            pair = TuplesKt.to(Integer.valueOf(R.drawable.ic_star), getString(R.string.m_score, Integer.valueOf(((StageGoal.Score) goal).getTarget())));
        } else {
            if (!(goal instanceof StageGoal.Avoid)) {
                throw new NoWhenBranchMatchedException();
            }
            pair = TuplesKt.to(Integer.valueOf(R.drawable.ic_shield), getString(R.string.m_obstacles, Integer.valueOf(((StageGoal.Avoid) goal).getTarget())));
        }
        int iIntValue = ((Number) pair.component1()).intValue();
        Object objComponent2 = pair.component2();
        Intrinsics.checkNotNullExpressionValue(objComponent2, "component2(...)");
        TextView textView = new TextView(requireContext());
        textView.setText((String) objComponent2);
        textView.setGravity(16);
        TextView textView2 = textView;
        int i = (int) (6.0f * textView.getResources().getDisplayMetrics().density);
        textView2.setPadding(i, i, i, i);
        textView.setCompoundDrawablePadding((int) (10.0f * textView.getResources().getDisplayMetrics().density));
        textView.setTextAppearance(R.style.TextAppearance_VR_Body);
        textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.offwhite));
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(iIntValue, 0, 0, 0);
        TextViewCompat.setCompoundDrawableTintList(textView, ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.accent_light)));
        getBinding().goalsContainer.addView(textView2);
    }
}
