package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J(\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u0007H\u0002J\u0010\u0010\u0010\u001a\u0004\u0018\u00010\r2\u0006\u0010\u0011\u001a\u00020\u0012R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0013"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/TournamentCatalog;", "", "<init>", "()V", "cfg", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "base", "", "mx", "gap", "dbl", "tournaments", "", "Lcom/championship/warriors/iron/legacy/data/meta/TournamentDef;", "getTournaments", "()Ljava/util/List;", "byId", "id", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class TournamentCatalog {
    public static final TournamentCatalog INSTANCE;
    private static final List<TournamentDef> tournaments;

    private TournamentCatalog() {
    }

    private final RunConfig cfg(float base, float mx, float gap, float dbl) {
        return new RunConfig(3, base, mx, 1.3f, gap, gap * 0.55f, dbl, 0.12f, 0.6f, 900.0f);
    }

    public final List<TournamentDef> getTournaments() {
        return tournaments;
    }

    static {
        TournamentCatalog tournamentCatalog = new TournamentCatalog();
        INSTANCE = tournamentCatalog;
        int i = R.string.t_rookie;
        RunConfig runConfigCfg = tournamentCatalog.cfg(10.0f, 16.0f, 18.0f, 0.2f);
        Pair[] pairArr = {TuplesKt.to("Vega", 1300), TuplesKt.to("Kova", 1450), TuplesKt.to("Rune", 1100)};
        Pair[] pairArr2 = {TuplesKt.to("Vega", 2050), TuplesKt.to("Kova", 2300), TuplesKt.to("Milo", 1900)};
        Pair[] pairArr3 = {TuplesKt.to("Kova", 3100), TuplesKt.to("Aria", 2800), TuplesKt.to("Milo", 2650)};
        Integer numValueOf = Integer.valueOf(FragmentTransaction.TRANSIT_FRAGMENT_MATCH_ACTIVITY_OPEN);
        tournaments = CollectionsKt.listOf((Object[]) new TournamentDef[]{new TournamentDef("rookie_cup", i, runConfigCfg, CollectionsKt.listOf((Object[]) new TournamentRoundDef[]{new TournamentRoundDef(1500, CollectionsKt.listOf((Object[]) pairArr)), new TournamentRoundDef(2200, CollectionsKt.listOf((Object[]) pairArr2)), new TournamentRoundDef(PathInterpolatorCompat.MAX_NUM_POINTS, CollectionsKt.listOf((Object[]) pairArr3)), new TournamentRoundDef(4000, CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Kova", 3950), TuplesKt.to("Aria", numValueOf), TuplesKt.to("Zane", 3700)}))})), new TournamentDef("pro_cup", R.string.t_pro, tournamentCatalog.cfg(13.0f, 22.0f, 14.0f, 0.45f), CollectionsKt.listOf((Object[]) new TournamentRoundDef[]{new TournamentRoundDef(PathInterpolatorCompat.MAX_NUM_POINTS, CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Storm", 2900), TuplesKt.to("Blaze", 3050), TuplesKt.to("Nova", 2700)})), new TournamentRoundDef(4200, CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Storm", numValueOf), TuplesKt.to("Blaze", 4400), TuplesKt.to("Nova", 3900)})), new TournamentRoundDef(5600, CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Blaze", 5700), TuplesKt.to("Titan", 5400), TuplesKt.to("Nova", 5200)})), new TournamentRoundDef(7000, CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Blaze", 7100), TuplesKt.to("Titan", 7300), TuplesKt.to("Apex", 6800)}))}))});
    }

    public final TournamentDef byId(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = tournaments.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((TournamentDef) next).getId(), id)) {
                break;
            }
        }
        return (TournamentDef) next;
    }
}
