package com.championship.warriors.iron.legacy.data.stage;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: StageModels.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001BK\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\u0004\b\r\u0010\u000eJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\tHÆ\u0003J\u000f\u0010!\u001a\b\u0012\u0004\u0012\u00020\f0\u000bHÆ\u0003JU\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0003\u0010\u0004\u001a\u00020\u00032\b\b\u0003\u0010\u0005\u001a\u00020\u00032\b\b\u0003\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bHÆ\u0001J\u0013\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010&\u001a\u00020\u0003HÖ\u0001J\t\u0010'\u001a\u00020(HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0010R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0019\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u0010¨\u0006)"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageData;", "", "id", "", "nameRes", "envRes", "colorRes", "themeIndex", "config", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "goals", "", "Lcom/championship/warriors/iron/legacy/data/stage/StageGoal;", "<init>", "(IIIIILcom/championship/warriors/iron/legacy/runner/RunConfig;Ljava/util/List;)V", "getId", "()I", "getNameRes", "getEnvRes", "getColorRes", "getThemeIndex", "getConfig", "()Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "getGoals", "()Ljava/util/List;", "targetDistance", "getTargetDistance", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class StageData {
    private final int colorRes;
    private final RunConfig config;
    private final int envRes;
    private final List<StageGoal> goals;
    private final int id;
    private final int nameRes;
    private final int themeIndex;

    public static /* synthetic */ StageData copy$default(StageData stageData, int i, int i2, int i3, int i4, int i5, RunConfig runConfig, List list, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i = stageData.id;
        }
        if ((i6 & 2) != 0) {
            i2 = stageData.nameRes;
        }
        if ((i6 & 4) != 0) {
            i3 = stageData.envRes;
        }
        if ((i6 & 8) != 0) {
            i4 = stageData.colorRes;
        }
        if ((i6 & 16) != 0) {
            i5 = stageData.themeIndex;
        }
        if ((i6 & 32) != 0) {
            runConfig = stageData.config;
        }
        if ((i6 & 64) != 0) {
            list = stageData.goals;
        }
        RunConfig runConfig2 = runConfig;
        List list2 = list;
        int i7 = i5;
        int i8 = i3;
        return stageData.copy(i, i2, i8, i4, i7, runConfig2, list2);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final int getNameRes() {
        return this.nameRes;
    }

    /* renamed from: component3, reason: from getter */
    public final int getEnvRes() {
        return this.envRes;
    }

    /* renamed from: component4, reason: from getter */
    public final int getColorRes() {
        return this.colorRes;
    }

    /* renamed from: component5, reason: from getter */
    public final int getThemeIndex() {
        return this.themeIndex;
    }

    /* renamed from: component6, reason: from getter */
    public final RunConfig getConfig() {
        return this.config;
    }

    public final List<StageGoal> component7() {
        return this.goals;
    }

    public final StageData copy(int id, int nameRes, int envRes, int colorRes, int themeIndex, RunConfig config, List<? extends StageGoal> goals) {
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(goals, "goals");
        return new StageData(id, nameRes, envRes, colorRes, themeIndex, config, goals);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof StageData)) {
            return false;
        }
        StageData stageData = (StageData) other;
        return this.id == stageData.id && this.nameRes == stageData.nameRes && this.envRes == stageData.envRes && this.colorRes == stageData.colorRes && this.themeIndex == stageData.themeIndex && Intrinsics.areEqual(this.config, stageData.config) && Intrinsics.areEqual(this.goals, stageData.goals);
    }

    public int hashCode() {
        return (((((((((((Integer.hashCode(this.id) * 31) + Integer.hashCode(this.nameRes)) * 31) + Integer.hashCode(this.envRes)) * 31) + Integer.hashCode(this.colorRes)) * 31) + Integer.hashCode(this.themeIndex)) * 31) + this.config.hashCode()) * 31) + this.goals.hashCode();
    }

    public String toString() {
        return "StageData(id=" + this.id + ", nameRes=" + this.nameRes + ", envRes=" + this.envRes + ", colorRes=" + this.colorRes + ", themeIndex=" + this.themeIndex + ", config=" + this.config + ", goals=" + this.goals + ")";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public StageData(int i, int i2, int i3, int i4, int i5, RunConfig config, List<? extends StageGoal> goals) {
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(goals, "goals");
        this.id = i;
        this.nameRes = i2;
        this.envRes = i3;
        this.colorRes = i4;
        this.themeIndex = i5;
        this.config = config;
        this.goals = goals;
    }

    public final int getId() {
        return this.id;
    }

    public final int getNameRes() {
        return this.nameRes;
    }

    public final int getEnvRes() {
        return this.envRes;
    }

    public final int getColorRes() {
        return this.colorRes;
    }

    public final int getThemeIndex() {
        return this.themeIndex;
    }

    public final RunConfig getConfig() {
        return this.config;
    }

    public final List<StageGoal> getGoals() {
        return this.goals;
    }

    public final int getTargetDistance() {
        return (int) this.config.getTargetDistance();
    }
}
