package com.championship.warriors.iron.legacy.data.equipment;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.championship.warriors.iron.legacy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: Equipment.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0011\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B7\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000ej\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015¨\u0006\u0016"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/equipment/BoostType;", "", "id", "", "labelRes", "", "descRes", "iconRes", "cost", "<init>", "(Ljava/lang/String;ILjava/lang/String;IIII)V", "getId", "()Ljava/lang/String;", "getLabelRes", "()I", "getDescRes", "getIconRes", "getCost", "HEAD_START", "SHIELD_START", "COIN_RUSH", "REVIVE", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class BoostType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ BoostType[] $VALUES;
    private final int cost;
    private final int descRes;
    private final int iconRes;
    private final String id;
    private final int labelRes;
    public static final BoostType HEAD_START = new BoostType("HEAD_START", 0, "head_start", R.string.boost_head_start, R.string.boost_head_start_desc, R.drawable.ic_bolt, 120);
    public static final BoostType SHIELD_START = new BoostType("SHIELD_START", 1, "shield_start", R.string.boost_shield_start, R.string.boost_shield_start_desc, R.drawable.ic_shield, 150);
    public static final BoostType COIN_RUSH = new BoostType("COIN_RUSH", 2, "coin_rush", R.string.boost_coin_rush, R.string.boost_coin_rush_desc, R.drawable.ic_coin, 180);
    public static final BoostType REVIVE = new BoostType("REVIVE", 3, "revive", R.string.boost_revive, R.string.boost_revive_desc, R.drawable.ic_heart, ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION);

    private static final /* synthetic */ BoostType[] $values() {
        return new BoostType[]{HEAD_START, SHIELD_START, COIN_RUSH, REVIVE};
    }

    public static EnumEntries<BoostType> getEntries() {
        return $ENTRIES;
    }

    public static BoostType valueOf(String str) {
        return (BoostType) Enum.valueOf(BoostType.class, str);
    }

    public static BoostType[] values() {
        return (BoostType[]) $VALUES.clone();
    }

    private BoostType(String str, int i, String str2, int i2, int i3, int i4, int i5) {
        this.id = str2;
        this.labelRes = i2;
        this.descRes = i3;
        this.iconRes = i4;
        this.cost = i5;
    }

    public final String getId() {
        return this.id;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    public final int getDescRes() {
        return this.descRes;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    public final int getCost() {
        return this.cost;
    }

    static {
        BoostType[] boostTypeArr$values = $values();
        $VALUES = boostTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(boostTypeArr$values);
    }
}
