package com.championship.warriors.iron.legacy.data.leaderboard;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Leaderboard.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0010\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00072\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u000e¨\u0006\u0017"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/leaderboard/LeaderboardEntry;", "", "name", "", "value", "", "isPlayer", "", "<init>", "(Ljava/lang/String;IZ)V", "getName", "()Ljava/lang/String;", "getValue", "()I", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class LeaderboardEntry {
    private final boolean isPlayer;
    private final String name;
    private final int value;

    public static /* synthetic */ LeaderboardEntry copy$default(LeaderboardEntry leaderboardEntry, String str, int i, boolean z, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = leaderboardEntry.name;
        }
        if ((i2 & 2) != 0) {
            i = leaderboardEntry.value;
        }
        if ((i2 & 4) != 0) {
            z = leaderboardEntry.isPlayer;
        }
        return leaderboardEntry.copy(str, i, z);
    }

    /* renamed from: component1, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* renamed from: component2, reason: from getter */
    public final int getValue() {
        return this.value;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getIsPlayer() {
        return this.isPlayer;
    }

    public final LeaderboardEntry copy(String name, int value, boolean isPlayer) {
        Intrinsics.checkNotNullParameter(name, "name");
        return new LeaderboardEntry(name, value, isPlayer);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LeaderboardEntry)) {
            return false;
        }
        LeaderboardEntry leaderboardEntry = (LeaderboardEntry) other;
        return Intrinsics.areEqual(this.name, leaderboardEntry.name) && this.value == leaderboardEntry.value && this.isPlayer == leaderboardEntry.isPlayer;
    }

    public int hashCode() {
        return (((this.name.hashCode() * 31) + Integer.hashCode(this.value)) * 31) + Boolean.hashCode(this.isPlayer);
    }

    public String toString() {
        return "LeaderboardEntry(name=" + this.name + ", value=" + this.value + ", isPlayer=" + this.isPlayer + ")";
    }

    public LeaderboardEntry(String name, int i, boolean z) {
        Intrinsics.checkNotNullParameter(name, "name");
        this.name = name;
        this.value = i;
        this.isPlayer = z;
    }

    public final String getName() {
        return this.name;
    }

    public final int getValue() {
        return this.value;
    }

    public final boolean isPlayer() {
        return this.isPlayer;
    }
}
