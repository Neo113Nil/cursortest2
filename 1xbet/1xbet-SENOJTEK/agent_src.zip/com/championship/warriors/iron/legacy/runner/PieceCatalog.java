package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\u000e\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0002J\u001c\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\t2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\tH\u0002R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0014"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/PieceCatalog;", "", "<init>", "()V", "palette", "", "getPalette", "()[I", "shapes", "", "Lcom/championship/warriors/iron/legacy/runner/PieceShape;", "getShapes", "()Ljava/util/List;", "upTo", "max", "", "buildShapes", "normalize", "Lcom/championship/warriors/iron/legacy/runner/Off;", "cells", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class PieceCatalog {
    public static final PieceCatalog INSTANCE;
    private static final int[] palette;
    private static final List<PieceShape> shapes;

    private PieceCatalog() {
    }

    public final int[] getPalette() {
        return palette;
    }

    static {
        PieceCatalog pieceCatalog = new PieceCatalog();
        INSTANCE = pieceCatalog;
        palette = new int[]{-11761921, -13252742, -30147, -1816515, -6583041, -14032656, -15043};
        shapes = pieceCatalog.buildShapes();
    }

    public final List<PieceShape> getShapes() {
        return shapes;
    }

    public final List<PieceShape> upTo(int max) {
        List<PieceShape> list = shapes;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (((PieceShape) obj).getSize() <= max) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    private final List<PieceShape> buildShapes() {
        List listListOf = CollectionsKt.listOf((Object[]) new List[]{CollectionsKt.listOf(new Off(0, 0)), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(0, 2)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(0, 2), new Off(0, 3)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(0, 2), new Off(0, 3), new Off(0, 4)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(1, 0), new Off(1, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(0, 2), new Off(1, 0), new Off(1, 1), new Off(1, 2), new Off(2, 0), new Off(2, 1), new Off(2, 2)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(1, 0), new Off(1, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(1, 0), new Off(2, 0), new Off(2, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(0, 2), new Off(1, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 1), new Off(0, 2), new Off(1, 0), new Off(1, 1)}), CollectionsKt.listOf((Object[]) new Off[]{new Off(0, 0), new Off(0, 1), new Off(1, 1), new Off(1, 2)})});
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        ArrayList arrayList = new ArrayList();
        Iterator it = listListOf.iterator();
        while (it.hasNext()) {
            List<Off> listNormalize = normalize((List) it.next());
            for (int i = 0; i < 4; i++) {
                List<Off> list = listNormalize;
                if (linkedHashSet.add(CollectionsKt.joinToString$default(list, ";", null, null, 0, null, new Function1() { // from class: com.championship.warriors.iron.legacy.runner.PieceCatalog$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return PieceCatalog.buildShapes$lambda$3$lambda$1((Off) obj);
                    }
                }, 30, null))) {
                    arrayList.add(new PieceShape(listNormalize));
                }
                PieceCatalog pieceCatalog = INSTANCE;
                ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
                for (Off off : list) {
                    arrayList2.add(new Off(off.getC(), -off.getR()));
                }
                listNormalize = pieceCatalog.normalize(arrayList2);
            }
        }
        return CollectionsKt.sortedWith(arrayList, new Comparator() { // from class: com.championship.warriors.iron.legacy.runner.PieceCatalog$buildShapes$$inlined$sortedBy$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                return ComparisonsKt.compareValues(Integer.valueOf(((PieceShape) t).getSize()), Integer.valueOf(((PieceShape) t2).getSize()));
            }
        });
    }

    static final CharSequence buildShapes$lambda$3$lambda$1(Off it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getR() + "," + it.getC();
    }

    private final List<Off> normalize(List<Off> cells) {
        List<Off> list = cells;
        Iterator<T> it = list.iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException();
        }
        int r = ((Off) it.next()).getR();
        while (it.hasNext()) {
            int r2 = ((Off) it.next()).getR();
            if (r > r2) {
                r = r2;
            }
        }
        Iterator<T> it2 = list.iterator();
        if (!it2.hasNext()) {
            throw new NoSuchElementException();
        }
        int c = ((Off) it2.next()).getC();
        while (it2.hasNext()) {
            int c2 = ((Off) it2.next()).getC();
            if (c > c2) {
                c = c2;
            }
        }
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        for (Off off : list) {
            arrayList.add(new Off(off.getR() - r, off.getC() - c));
        }
        return CollectionsKt.sortedWith(arrayList, ComparisonsKt.compareBy(new Function1() { // from class: com.championship.warriors.iron.legacy.runner.PieceCatalog$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PieceCatalog.normalize$lambda$8((Off) obj);
            }
        }, new Function1() { // from class: com.championship.warriors.iron.legacy.runner.PieceCatalog$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PieceCatalog.normalize$lambda$9((Off) obj);
            }
        }));
    }

    static final Comparable normalize$lambda$8(Off it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return Integer.valueOf(it.getR());
    }

    static final Comparable normalize$lambda$9(Off it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return Integer.valueOf(it.getC());
    }
}
