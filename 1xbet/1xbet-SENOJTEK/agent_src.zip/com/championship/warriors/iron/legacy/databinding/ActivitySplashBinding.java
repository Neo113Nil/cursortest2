package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;

/* loaded from: classes.dex */
public final class ActivitySplashBinding implements ViewBinding {
    public final ProgressBar circleProgressBar;
    public final ProgressBar horizontalProgressBar;
    private final ConstraintLayout rootView;

    private ActivitySplashBinding(ConstraintLayout constraintLayout, ProgressBar progressBar, ProgressBar progressBar2) {
        this.rootView = constraintLayout;
        this.circleProgressBar = progressBar;
        this.horizontalProgressBar = progressBar2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivitySplashBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ActivitySplashBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_splash, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ActivitySplashBinding bind(View view) {
        int i = R.id.circleProgressBar;
        ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i);
        if (progressBar != null) {
            i = R.id.horizontalProgressBar;
            ProgressBar progressBar2 = (ProgressBar) ViewBindings.findChildViewById(view, i);
            if (progressBar2 != null) {
                return new ActivitySplashBinding((ConstraintLayout) view, progressBar, progressBar2);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
