package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCatalog;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCategory;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentItem;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: PlayerState.kt */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b3\n\u0002\u0018\u0002\n\u0002\b2\b\u0086\b\u0018\u0000 \u008c\u00012\u00020\u0001:\u0002\u008c\u0001B¥\u0003\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\u0014\b\u0002\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u0006\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0015\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0003\u0012\u0014\b\u0002\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006\u0012\u0014\b\u0002\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006\u0012\u000e\b\u0002\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a\u0012\u0014\b\u0002\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b0\u0006\u0012\u0014\b\u0002\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00030\u0006\u0012\u000e\b\u0002\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a\u0012\u000e\b\u0002\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a\u0012\u000e\b\u0002\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a\u0012\b\b\u0002\u0010!\u001a\u00020\u0003\u0012\b\b\u0002\u0010\"\u001a\u00020#\u0012\b\b\u0002\u0010$\u001a\u00020\u001b\u0012\b\b\u0002\u0010%\u001a\u00020\u0003\u0012\b\b\u0002\u0010&\u001a\u00020'\u0012\b\b\u0002\u0010(\u001a\u00020\u0003\u0012\b\b\u0002\u0010)\u001a\u00020\u0003¢\u0006\u0004\b*\u0010+J\u0006\u0010U\u001a\u00020\u0003J\u0006\u0010V\u001a\u00020\u0003J\u000e\u0010W\u001a\u00020\u00032\u0006\u0010X\u001a\u00020\u0007J\u000e\u0010Y\u001a\u00020\u001b2\u0006\u0010Z\u001a\u00020[J\u000e\u0010\\\u001a\u00020'2\u0006\u0010]\u001a\u00020\u001bJ\u000e\u0010^\u001a\u00020\u00032\u0006\u0010_\u001a\u00020\u001bJ\u000e\u0010`\u001a\u00020\u00032\u0006\u0010a\u001a\u00020\u0003J\u000e\u0010b\u001a\u00020\u00032\u0006\u0010a\u001a\u00020\u0003J\u000e\u0010c\u001a\u00020'2\u0006\u0010_\u001a\u00020\u0003J\t\u0010f\u001a\u00020\u0003HÆ\u0003J\t\u0010g\u001a\u00020\u0003HÆ\u0003J\u0015\u0010h\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u0006HÆ\u0003J\t\u0010i\u001a\u00020\u0003HÆ\u0003J\t\u0010j\u001a\u00020\u0003HÆ\u0003J\t\u0010k\u001a\u00020\u0003HÆ\u0003J\t\u0010l\u001a\u00020\u0003HÆ\u0003J\t\u0010m\u001a\u00020\u0003HÆ\u0003J\t\u0010n\u001a\u00020\u0003HÆ\u0003J\t\u0010o\u001a\u00020\u0003HÆ\u0003J\t\u0010p\u001a\u00020\u0003HÆ\u0003J\t\u0010q\u001a\u00020\u0003HÆ\u0003J\t\u0010r\u001a\u00020\u0003HÆ\u0003J\t\u0010s\u001a\u00020\u0003HÆ\u0003J\t\u0010t\u001a\u00020\u0003HÆ\u0003J\t\u0010u\u001a\u00020\u0003HÆ\u0003J\t\u0010v\u001a\u00020\u0003HÆ\u0003J\t\u0010w\u001a\u00020\u0003HÆ\u0003J\u0015\u0010x\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006HÆ\u0003J\u0015\u0010y\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006HÆ\u0003J\u000f\u0010z\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aHÆ\u0003J\u0015\u0010{\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b0\u0006HÆ\u0003J\u0015\u0010|\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00030\u0006HÆ\u0003J\u000f\u0010}\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aHÆ\u0003J\u000f\u0010~\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aHÆ\u0003J\u000f\u0010\u007f\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aHÆ\u0003J\n\u0010\u0080\u0001\u001a\u00020\u0003HÆ\u0003J\n\u0010\u0081\u0001\u001a\u00020#HÆ\u0003J\n\u0010\u0082\u0001\u001a\u00020\u001bHÆ\u0003J\n\u0010\u0083\u0001\u001a\u00020\u0003HÆ\u0003J\n\u0010\u0084\u0001\u001a\u00020'HÆ\u0003J\n\u0010\u0085\u0001\u001a\u00020\u0003HÆ\u0003J\n\u0010\u0086\u0001\u001a\u00020\u0003HÆ\u0003J¨\u0003\u0010\u0087\u0001\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\u0014\b\u0002\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00062\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u00032\b\b\u0002\u0010\u0011\u001a\u00020\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u00032\b\b\u0002\u0010\u0013\u001a\u00020\u00032\b\b\u0002\u0010\u0014\u001a\u00020\u00032\b\b\u0002\u0010\u0015\u001a\u00020\u00032\b\b\u0002\u0010\u0016\u001a\u00020\u00032\u0014\b\u0002\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00062\u0014\b\u0002\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00062\u000e\b\u0002\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\u0014\b\u0002\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b0\u00062\u0014\b\u0002\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00030\u00062\u000e\b\u0002\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\u000e\b\u0002\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\u000e\b\u0002\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\b\b\u0002\u0010!\u001a\u00020\u00032\b\b\u0002\u0010\"\u001a\u00020#2\b\b\u0002\u0010$\u001a\u00020\u001b2\b\b\u0002\u0010%\u001a\u00020\u00032\b\b\u0002\u0010&\u001a\u00020'2\b\b\u0002\u0010(\u001a\u00020\u00032\b\b\u0002\u0010)\u001a\u00020\u0003HÆ\u0001J\u0015\u0010\u0088\u0001\u001a\u00020'2\t\u0010\u0089\u0001\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\n\u0010\u008a\u0001\u001a\u00020\u0003HÖ\u0001J\n\u0010\u008b\u0001\u001a\u00020\u001bHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b,\u0010-R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b.\u0010-R\u001d\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\b\n\u0000\u001a\u0004\b/\u00100R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b1\u0010-R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b2\u0010-R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b3\u0010-R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b4\u0010-R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b5\u0010-R\u0011\u0010\r\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b6\u0010-R\u0011\u0010\u000e\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b7\u0010-R\u0011\u0010\u000f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b8\u0010-R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b9\u0010-R\u0011\u0010\u0011\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b:\u0010-R\u0011\u0010\u0012\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b;\u0010-R\u0011\u0010\u0013\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b<\u0010-R\u0011\u0010\u0014\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b=\u0010-R\u0011\u0010\u0015\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b>\u0010-R\u0011\u0010\u0016\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b?\u0010-R\u001d\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\b\n\u0000\u001a\u0004\b@\u00100R\u001d\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\b\n\u0000\u001a\u0004\bA\u00100R\u0017\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a¢\u0006\b\n\u0000\u001a\u0004\bB\u0010CR\u001d\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b0\u0006¢\u0006\b\n\u0000\u001a\u0004\bD\u00100R\u001d\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\b\n\u0000\u001a\u0004\bE\u00100R\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a¢\u0006\b\n\u0000\u001a\u0004\bF\u0010CR\u0017\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a¢\u0006\b\n\u0000\u001a\u0004\bG\u0010CR\u0017\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a¢\u0006\b\n\u0000\u001a\u0004\bH\u0010CR\u0011\u0010!\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\bI\u0010-R\u0011\u0010\"\u001a\u00020#¢\u0006\b\n\u0000\u001a\u0004\bJ\u0010KR\u0011\u0010$\u001a\u00020\u001b¢\u0006\b\n\u0000\u001a\u0004\bL\u0010MR\u0011\u0010%\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\bN\u0010-R\u0011\u0010&\u001a\u00020'¢\u0006\b\n\u0000\u001a\u0004\bO\u0010PR\u0011\u0010(\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\bQ\u0010-R\u0011\u0010)\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\bR\u0010-R\u0011\u0010S\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bT\u0010-R\u0011\u0010d\u001a\u00020'8F¢\u0006\u0006\u001a\u0004\be\u0010P¨\u0006\u008d\u0001"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "", "coins", "", "xp", "statLevels", "", "Lcom/championship/warriors/iron/legacy/data/player/StatType;", "totalDistance", "totalCoins", "totalObstacles", "totalPowerups", "totalRuns", "totalTokens", "playSeconds", "highScore", "longestRun", "bestRunSeconds", "endlessBest", "topSpeed", "maxCombo", "bestChallengeScore", "careerUnlocked", "stageBest", "stageStars", "ownedEquipment", "", "", "equipped", "boosts", "missionsClaimed", "achievementsUnlocked", "challengesDone", "dailyStreak", "dailyLastDay", "", "tournamentId", "tournamentRound", "tournamentAlive", "", "tournamentTitles", "bestTournamentRound", "<init>", "(IILjava/util/Map;IIIIIIIIIIIIIIILjava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;Ljava/util/Set;IJLjava/lang/String;IZII)V", "getCoins", "()I", "getXp", "getStatLevels", "()Ljava/util/Map;", "getTotalDistance", "getTotalCoins", "getTotalObstacles", "getTotalPowerups", "getTotalRuns", "getTotalTokens", "getPlaySeconds", "getHighScore", "getLongestRun", "getBestRunSeconds", "getEndlessBest", "getTopSpeed", "getMaxCombo", "getBestChallengeScore", "getCareerUnlocked", "getStageBest", "getStageStars", "getOwnedEquipment", "()Ljava/util/Set;", "getEquipped", "getBoosts", "getMissionsClaimed", "getAchievementsUnlocked", "getChallengesDone", "getDailyStreak", "getDailyLastDay", "()J", "getTournamentId", "()Ljava/lang/String;", "getTournamentRound", "getTournamentAlive", "()Z", "getTournamentTitles", "getBestTournamentRound", "level", "getLevel", "xpIntoLevel", "xpForThisLevel", "statLevel", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "equippedIn", "category", "Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;", "owns", "itemId", "boostCount", "id", "starsFor", "stageId", "bestFor", "isStageUnlocked", "hasStarted", "getHasStarted", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component20", "component21", "component22", "component23", "component24", "component25", "component26", "component27", "component28", "component29", "component30", "component31", "component32", "component33", "copy", "equals", "other", "hashCode", "toString", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class PlayerState {

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final Set<String> achievementsUnlocked;
    private final int bestChallengeScore;
    private final int bestRunSeconds;
    private final int bestTournamentRound;
    private final Map<String, Integer> boosts;
    private final int careerUnlocked;
    private final Set<String> challengesDone;
    private final int coins;
    private final long dailyLastDay;
    private final int dailyStreak;
    private final int endlessBest;
    private final Map<String, String> equipped;
    private final int highScore;
    private final int longestRun;
    private final int maxCombo;
    private final Set<String> missionsClaimed;
    private final Set<String> ownedEquipment;
    private final int playSeconds;
    private final Map<Integer, Integer> stageBest;
    private final Map<Integer, Integer> stageStars;
    private final Map<StatType, Integer> statLevels;
    private final int topSpeed;
    private final int totalCoins;
    private final int totalDistance;
    private final int totalObstacles;
    private final int totalPowerups;
    private final int totalRuns;
    private final int totalTokens;
    private final boolean tournamentAlive;
    private final String tournamentId;
    private final int tournamentRound;
    private final int tournamentTitles;
    private final int xp;

    public PlayerState() {
        this(0, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null, null, null, null, null, 0, 0L, null, 0, false, 0, 0, -1, 1, null);
    }

    public static /* synthetic */ PlayerState copy$default(PlayerState playerState, int i, int i2, Map map, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, Map map2, Map map3, Set set, Map map4, Map map5, Set set2, Set set3, Set set4, int i18, long j, String str, int i19, boolean z, int i20, int i21, int i22, int i23, Object obj) {
        int i24;
        int i25;
        int i26;
        Map map6;
        Map map7;
        Set set5;
        Map map8;
        Map map9;
        Set set6;
        Set set7;
        Set set8;
        int i27;
        long j2;
        String str2;
        boolean z2;
        int i28;
        Map map10;
        int i29;
        int i30;
        int i31;
        int i32;
        int i33;
        int i34;
        int i35;
        int i36;
        int i37;
        int i38;
        int i39;
        int i40;
        int i41;
        int i42;
        int i43 = (i22 & 1) != 0 ? playerState.coins : i;
        int i44 = (i22 & 2) != 0 ? playerState.xp : i2;
        Map map11 = (i22 & 4) != 0 ? playerState.statLevels : map;
        int i45 = (i22 & 8) != 0 ? playerState.totalDistance : i3;
        int i46 = (i22 & 16) != 0 ? playerState.totalCoins : i4;
        int i47 = (i22 & 32) != 0 ? playerState.totalObstacles : i5;
        int i48 = (i22 & 64) != 0 ? playerState.totalPowerups : i6;
        int i49 = (i22 & 128) != 0 ? playerState.totalRuns : i7;
        int i50 = (i22 & 256) != 0 ? playerState.totalTokens : i8;
        int i51 = (i22 & 512) != 0 ? playerState.playSeconds : i9;
        int i52 = (i22 & 1024) != 0 ? playerState.highScore : i10;
        int i53 = (i22 & 2048) != 0 ? playerState.longestRun : i11;
        int i54 = (i22 & 4096) != 0 ? playerState.bestRunSeconds : i12;
        int i55 = (i22 & 8192) != 0 ? playerState.endlessBest : i13;
        int i56 = i43;
        int i57 = (i22 & 16384) != 0 ? playerState.topSpeed : i14;
        int i58 = (i22 & 32768) != 0 ? playerState.maxCombo : i15;
        int i59 = (i22 & 65536) != 0 ? playerState.bestChallengeScore : i16;
        int i60 = (i22 & 131072) != 0 ? playerState.careerUnlocked : i17;
        Map map12 = (i22 & 262144) != 0 ? playerState.stageBest : map2;
        Map map13 = (i22 & 524288) != 0 ? playerState.stageStars : map3;
        Set set9 = (i22 & 1048576) != 0 ? playerState.ownedEquipment : set;
        Map map14 = (i22 & 2097152) != 0 ? playerState.equipped : map4;
        Map map15 = (i22 & 4194304) != 0 ? playerState.boosts : map5;
        Set set10 = (i22 & 8388608) != 0 ? playerState.missionsClaimed : set2;
        Set set11 = (i22 & 16777216) != 0 ? playerState.achievementsUnlocked : set3;
        Set set12 = (i22 & 33554432) != 0 ? playerState.challengesDone : set4;
        int i61 = (i22 & AccessibilityEventCompat.TYPE_VIEW_TARGETED_BY_SCROLL) != 0 ? playerState.dailyStreak : i18;
        int i62 = i57;
        long j3 = (i22 & 134217728) != 0 ? playerState.dailyLastDay : j;
        String str3 = (i22 & 268435456) != 0 ? playerState.tournamentId : str;
        int i63 = (i22 & 536870912) != 0 ? playerState.tournamentRound : i19;
        String str4 = str3;
        boolean z3 = (i22 & BasicMeasure.EXACTLY) != 0 ? playerState.tournamentAlive : z;
        int i64 = (i22 & Integer.MIN_VALUE) != 0 ? playerState.tournamentTitles : i20;
        if ((i23 & 1) != 0) {
            i25 = i64;
            i24 = playerState.bestTournamentRound;
            map6 = map12;
            map7 = map13;
            set5 = set9;
            map8 = map14;
            map9 = map15;
            set6 = set10;
            set7 = set11;
            set8 = set12;
            i27 = i61;
            j2 = j3;
            str2 = str4;
            z2 = z3;
            i28 = i63;
            i29 = i45;
            i30 = i46;
            i31 = i47;
            i32 = i48;
            i33 = i49;
            i34 = i50;
            i35 = i51;
            i36 = i52;
            i37 = i54;
            i38 = i55;
            i39 = i58;
            i40 = i59;
            i26 = i60;
            i41 = i62;
            i42 = i44;
            map10 = map11;
        } else {
            i24 = i21;
            i25 = i64;
            i26 = i60;
            map6 = map12;
            map7 = map13;
            set5 = set9;
            map8 = map14;
            map9 = map15;
            set6 = set10;
            set7 = set11;
            set8 = set12;
            i27 = i61;
            j2 = j3;
            str2 = str4;
            z2 = z3;
            i28 = i63;
            map10 = map11;
            i29 = i45;
            i30 = i46;
            i31 = i47;
            i32 = i48;
            i33 = i49;
            i34 = i50;
            i35 = i51;
            i36 = i52;
            i37 = i54;
            i38 = i55;
            i39 = i58;
            i40 = i59;
            i41 = i62;
            i42 = i44;
        }
        return playerState.copy(i56, i42, map10, i29, i30, i31, i32, i33, i34, i35, i36, i53, i37, i38, i41, i39, i40, i26, map6, map7, set5, map8, map9, set6, set7, set8, i27, j2, str2, i28, z2, i25, i24);
    }

    /* renamed from: component1, reason: from getter */
    public final int getCoins() {
        return this.coins;
    }

    /* renamed from: component10, reason: from getter */
    public final int getPlaySeconds() {
        return this.playSeconds;
    }

    /* renamed from: component11, reason: from getter */
    public final int getHighScore() {
        return this.highScore;
    }

    /* renamed from: component12, reason: from getter */
    public final int getLongestRun() {
        return this.longestRun;
    }

    /* renamed from: component13, reason: from getter */
    public final int getBestRunSeconds() {
        return this.bestRunSeconds;
    }

    /* renamed from: component14, reason: from getter */
    public final int getEndlessBest() {
        return this.endlessBest;
    }

    /* renamed from: component15, reason: from getter */
    public final int getTopSpeed() {
        return this.topSpeed;
    }

    /* renamed from: component16, reason: from getter */
    public final int getMaxCombo() {
        return this.maxCombo;
    }

    /* renamed from: component17, reason: from getter */
    public final int getBestChallengeScore() {
        return this.bestChallengeScore;
    }

    /* renamed from: component18, reason: from getter */
    public final int getCareerUnlocked() {
        return this.careerUnlocked;
    }

    public final Map<Integer, Integer> component19() {
        return this.stageBest;
    }

    /* renamed from: component2, reason: from getter */
    public final int getXp() {
        return this.xp;
    }

    public final Map<Integer, Integer> component20() {
        return this.stageStars;
    }

    public final Set<String> component21() {
        return this.ownedEquipment;
    }

    public final Map<String, String> component22() {
        return this.equipped;
    }

    public final Map<String, Integer> component23() {
        return this.boosts;
    }

    public final Set<String> component24() {
        return this.missionsClaimed;
    }

    public final Set<String> component25() {
        return this.achievementsUnlocked;
    }

    public final Set<String> component26() {
        return this.challengesDone;
    }

    /* renamed from: component27, reason: from getter */
    public final int getDailyStreak() {
        return this.dailyStreak;
    }

    /* renamed from: component28, reason: from getter */
    public final long getDailyLastDay() {
        return this.dailyLastDay;
    }

    /* renamed from: component29, reason: from getter */
    public final String getTournamentId() {
        return this.tournamentId;
    }

    public final Map<StatType, Integer> component3() {
        return this.statLevels;
    }

    /* renamed from: component30, reason: from getter */
    public final int getTournamentRound() {
        return this.tournamentRound;
    }

    /* renamed from: component31, reason: from getter */
    public final boolean getTournamentAlive() {
        return this.tournamentAlive;
    }

    /* renamed from: component32, reason: from getter */
    public final int getTournamentTitles() {
        return this.tournamentTitles;
    }

    /* renamed from: component33, reason: from getter */
    public final int getBestTournamentRound() {
        return this.bestTournamentRound;
    }

    /* renamed from: component4, reason: from getter */
    public final int getTotalDistance() {
        return this.totalDistance;
    }

    /* renamed from: component5, reason: from getter */
    public final int getTotalCoins() {
        return this.totalCoins;
    }

    /* renamed from: component6, reason: from getter */
    public final int getTotalObstacles() {
        return this.totalObstacles;
    }

    /* renamed from: component7, reason: from getter */
    public final int getTotalPowerups() {
        return this.totalPowerups;
    }

    /* renamed from: component8, reason: from getter */
    public final int getTotalRuns() {
        return this.totalRuns;
    }

    /* renamed from: component9, reason: from getter */
    public final int getTotalTokens() {
        return this.totalTokens;
    }

    public final PlayerState copy(int coins, int xp, Map<StatType, Integer> statLevels, int totalDistance, int totalCoins, int totalObstacles, int totalPowerups, int totalRuns, int totalTokens, int playSeconds, int highScore, int longestRun, int bestRunSeconds, int endlessBest, int topSpeed, int maxCombo, int bestChallengeScore, int careerUnlocked, Map<Integer, Integer> stageBest, Map<Integer, Integer> stageStars, Set<String> ownedEquipment, Map<String, String> equipped, Map<String, Integer> boosts, Set<String> missionsClaimed, Set<String> achievementsUnlocked, Set<String> challengesDone, int dailyStreak, long dailyLastDay, String tournamentId, int tournamentRound, boolean tournamentAlive, int tournamentTitles, int bestTournamentRound) {
        Intrinsics.checkNotNullParameter(statLevels, "statLevels");
        Intrinsics.checkNotNullParameter(stageBest, "stageBest");
        Intrinsics.checkNotNullParameter(stageStars, "stageStars");
        Intrinsics.checkNotNullParameter(ownedEquipment, "ownedEquipment");
        Intrinsics.checkNotNullParameter(equipped, "equipped");
        Intrinsics.checkNotNullParameter(boosts, "boosts");
        Intrinsics.checkNotNullParameter(missionsClaimed, "missionsClaimed");
        Intrinsics.checkNotNullParameter(achievementsUnlocked, "achievementsUnlocked");
        Intrinsics.checkNotNullParameter(challengesDone, "challengesDone");
        Intrinsics.checkNotNullParameter(tournamentId, "tournamentId");
        return new PlayerState(coins, xp, statLevels, totalDistance, totalCoins, totalObstacles, totalPowerups, totalRuns, totalTokens, playSeconds, highScore, longestRun, bestRunSeconds, endlessBest, topSpeed, maxCombo, bestChallengeScore, careerUnlocked, stageBest, stageStars, ownedEquipment, equipped, boosts, missionsClaimed, achievementsUnlocked, challengesDone, dailyStreak, dailyLastDay, tournamentId, tournamentRound, tournamentAlive, tournamentTitles, bestTournamentRound);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PlayerState)) {
            return false;
        }
        PlayerState playerState = (PlayerState) other;
        return this.coins == playerState.coins && this.xp == playerState.xp && Intrinsics.areEqual(this.statLevels, playerState.statLevels) && this.totalDistance == playerState.totalDistance && this.totalCoins == playerState.totalCoins && this.totalObstacles == playerState.totalObstacles && this.totalPowerups == playerState.totalPowerups && this.totalRuns == playerState.totalRuns && this.totalTokens == playerState.totalTokens && this.playSeconds == playerState.playSeconds && this.highScore == playerState.highScore && this.longestRun == playerState.longestRun && this.bestRunSeconds == playerState.bestRunSeconds && this.endlessBest == playerState.endlessBest && this.topSpeed == playerState.topSpeed && this.maxCombo == playerState.maxCombo && this.bestChallengeScore == playerState.bestChallengeScore && this.careerUnlocked == playerState.careerUnlocked && Intrinsics.areEqual(this.stageBest, playerState.stageBest) && Intrinsics.areEqual(this.stageStars, playerState.stageStars) && Intrinsics.areEqual(this.ownedEquipment, playerState.ownedEquipment) && Intrinsics.areEqual(this.equipped, playerState.equipped) && Intrinsics.areEqual(this.boosts, playerState.boosts) && Intrinsics.areEqual(this.missionsClaimed, playerState.missionsClaimed) && Intrinsics.areEqual(this.achievementsUnlocked, playerState.achievementsUnlocked) && Intrinsics.areEqual(this.challengesDone, playerState.challengesDone) && this.dailyStreak == playerState.dailyStreak && this.dailyLastDay == playerState.dailyLastDay && Intrinsics.areEqual(this.tournamentId, playerState.tournamentId) && this.tournamentRound == playerState.tournamentRound && this.tournamentAlive == playerState.tournamentAlive && this.tournamentTitles == playerState.tournamentTitles && this.bestTournamentRound == playerState.bestTournamentRound;
    }

    public int hashCode() {
        return (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((Integer.hashCode(this.coins) * 31) + Integer.hashCode(this.xp)) * 31) + this.statLevels.hashCode()) * 31) + Integer.hashCode(this.totalDistance)) * 31) + Integer.hashCode(this.totalCoins)) * 31) + Integer.hashCode(this.totalObstacles)) * 31) + Integer.hashCode(this.totalPowerups)) * 31) + Integer.hashCode(this.totalRuns)) * 31) + Integer.hashCode(this.totalTokens)) * 31) + Integer.hashCode(this.playSeconds)) * 31) + Integer.hashCode(this.highScore)) * 31) + Integer.hashCode(this.longestRun)) * 31) + Integer.hashCode(this.bestRunSeconds)) * 31) + Integer.hashCode(this.endlessBest)) * 31) + Integer.hashCode(this.topSpeed)) * 31) + Integer.hashCode(this.maxCombo)) * 31) + Integer.hashCode(this.bestChallengeScore)) * 31) + Integer.hashCode(this.careerUnlocked)) * 31) + this.stageBest.hashCode()) * 31) + this.stageStars.hashCode()) * 31) + this.ownedEquipment.hashCode()) * 31) + this.equipped.hashCode()) * 31) + this.boosts.hashCode()) * 31) + this.missionsClaimed.hashCode()) * 31) + this.achievementsUnlocked.hashCode()) * 31) + this.challengesDone.hashCode()) * 31) + Integer.hashCode(this.dailyStreak)) * 31) + Long.hashCode(this.dailyLastDay)) * 31) + this.tournamentId.hashCode()) * 31) + Integer.hashCode(this.tournamentRound)) * 31) + Boolean.hashCode(this.tournamentAlive)) * 31) + Integer.hashCode(this.tournamentTitles)) * 31) + Integer.hashCode(this.bestTournamentRound);
    }

    public String toString() {
        return "PlayerState(coins=" + this.coins + ", xp=" + this.xp + ", statLevels=" + this.statLevels + ", totalDistance=" + this.totalDistance + ", totalCoins=" + this.totalCoins + ", totalObstacles=" + this.totalObstacles + ", totalPowerups=" + this.totalPowerups + ", totalRuns=" + this.totalRuns + ", totalTokens=" + this.totalTokens + ", playSeconds=" + this.playSeconds + ", highScore=" + this.highScore + ", longestRun=" + this.longestRun + ", bestRunSeconds=" + this.bestRunSeconds + ", endlessBest=" + this.endlessBest + ", topSpeed=" + this.topSpeed + ", maxCombo=" + this.maxCombo + ", bestChallengeScore=" + this.bestChallengeScore + ", careerUnlocked=" + this.careerUnlocked + ", stageBest=" + this.stageBest + ", stageStars=" + this.stageStars + ", ownedEquipment=" + this.ownedEquipment + ", equipped=" + this.equipped + ", boosts=" + this.boosts + ", missionsClaimed=" + this.missionsClaimed + ", achievementsUnlocked=" + this.achievementsUnlocked + ", challengesDone=" + this.challengesDone + ", dailyStreak=" + this.dailyStreak + ", dailyLastDay=" + this.dailyLastDay + ", tournamentId=" + this.tournamentId + ", tournamentRound=" + this.tournamentRound + ", tournamentAlive=" + this.tournamentAlive + ", tournamentTitles=" + this.tournamentTitles + ", bestTournamentRound=" + this.bestTournamentRound + ")";
    }

    public PlayerState(int i, int i2, Map<StatType, Integer> statLevels, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, Map<Integer, Integer> stageBest, Map<Integer, Integer> stageStars, Set<String> ownedEquipment, Map<String, String> equipped, Map<String, Integer> boosts, Set<String> missionsClaimed, Set<String> achievementsUnlocked, Set<String> challengesDone, int i18, long j, String tournamentId, int i19, boolean z, int i20, int i21) {
        Intrinsics.checkNotNullParameter(statLevels, "statLevels");
        Intrinsics.checkNotNullParameter(stageBest, "stageBest");
        Intrinsics.checkNotNullParameter(stageStars, "stageStars");
        Intrinsics.checkNotNullParameter(ownedEquipment, "ownedEquipment");
        Intrinsics.checkNotNullParameter(equipped, "equipped");
        Intrinsics.checkNotNullParameter(boosts, "boosts");
        Intrinsics.checkNotNullParameter(missionsClaimed, "missionsClaimed");
        Intrinsics.checkNotNullParameter(achievementsUnlocked, "achievementsUnlocked");
        Intrinsics.checkNotNullParameter(challengesDone, "challengesDone");
        Intrinsics.checkNotNullParameter(tournamentId, "tournamentId");
        this.coins = i;
        this.xp = i2;
        this.statLevels = statLevels;
        this.totalDistance = i3;
        this.totalCoins = i4;
        this.totalObstacles = i5;
        this.totalPowerups = i6;
        this.totalRuns = i7;
        this.totalTokens = i8;
        this.playSeconds = i9;
        this.highScore = i10;
        this.longestRun = i11;
        this.bestRunSeconds = i12;
        this.endlessBest = i13;
        this.topSpeed = i14;
        this.maxCombo = i15;
        this.bestChallengeScore = i16;
        this.careerUnlocked = i17;
        this.stageBest = stageBest;
        this.stageStars = stageStars;
        this.ownedEquipment = ownedEquipment;
        this.equipped = equipped;
        this.boosts = boosts;
        this.missionsClaimed = missionsClaimed;
        this.achievementsUnlocked = achievementsUnlocked;
        this.challengesDone = challengesDone;
        this.dailyStreak = i18;
        this.dailyLastDay = j;
        this.tournamentId = tournamentId;
        this.tournamentRound = i19;
        this.tournamentAlive = z;
        this.tournamentTitles = i20;
        this.bestTournamentRound = i21;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getXp() {
        return this.xp;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ PlayerState(int i, int i2, Map map, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, Map map2, Map map3, Set set, Map map4, Map map5, Set set2, Set set3, Set set4, int i18, long j, String str, int i19, boolean z, int i20, int i21, int i22, int i23, DefaultConstructorMarker defaultConstructorMarker) {
        int i24 = (i22 & 1) != 0 ? 0 : i;
        int i25 = (i22 & 2) != 0 ? 0 : i2;
        Map mapEmptyMap = (i22 & 4) != 0 ? MapsKt.emptyMap() : map;
        int i26 = (i22 & 8) != 0 ? 0 : i3;
        int i27 = (i22 & 16) != 0 ? 0 : i4;
        int i28 = (i22 & 32) != 0 ? 0 : i5;
        int i29 = (i22 & 64) != 0 ? 0 : i6;
        int i30 = (i22 & 128) != 0 ? 0 : i7;
        int i31 = (i22 & 256) != 0 ? 0 : i8;
        int i32 = (i22 & 512) != 0 ? 0 : i9;
        int i33 = (i22 & 1024) != 0 ? 0 : i10;
        int i34 = (i22 & 2048) != 0 ? 0 : i11;
        int i35 = (i22 & 4096) != 0 ? 0 : i12;
        int i36 = (i22 & 8192) != 0 ? 0 : i13;
        int i37 = (i22 & 16384) != 0 ? 0 : i14;
        this(i24, i25, mapEmptyMap, i26, i27, i28, i29, i30, i31, i32, i33, i34, i35, i36, i37, (i22 & 32768) != 0 ? 0 : i15, (i22 & 65536) != 0 ? 0 : i16, (i22 & 131072) != 0 ? 1 : i17, (i22 & 262144) != 0 ? MapsKt.emptyMap() : map2, (i22 & 524288) != 0 ? MapsKt.emptyMap() : map3, (i22 & 1048576) != 0 ? SetsKt.emptySet() : set, (i22 & 2097152) != 0 ? MapsKt.emptyMap() : map4, (i22 & 4194304) != 0 ? MapsKt.emptyMap() : map5, (i22 & 8388608) != 0 ? SetsKt.emptySet() : set2, (i22 & 16777216) != 0 ? SetsKt.emptySet() : set3, (i22 & 33554432) != 0 ? SetsKt.emptySet() : set4, (i22 & AccessibilityEventCompat.TYPE_VIEW_TARGETED_BY_SCROLL) != 0 ? 0 : i18, (i22 & 134217728) != 0 ? 0L : j, (i22 & 268435456) != 0 ? "" : str, (i22 & 536870912) != 0 ? 0 : i19, (i22 & BasicMeasure.EXACTLY) != 0 ? true : z, (i22 & Integer.MIN_VALUE) != 0 ? 0 : i20, (i23 & 1) != 0 ? 0 : i21);
    }

    public final Map<StatType, Integer> getStatLevels() {
        return this.statLevels;
    }

    public final int getTotalDistance() {
        return this.totalDistance;
    }

    public final int getTotalCoins() {
        return this.totalCoins;
    }

    public final int getTotalObstacles() {
        return this.totalObstacles;
    }

    public final int getTotalPowerups() {
        return this.totalPowerups;
    }

    public final int getTotalRuns() {
        return this.totalRuns;
    }

    public final int getTotalTokens() {
        return this.totalTokens;
    }

    public final int getPlaySeconds() {
        return this.playSeconds;
    }

    public final int getHighScore() {
        return this.highScore;
    }

    public final int getLongestRun() {
        return this.longestRun;
    }

    public final int getBestRunSeconds() {
        return this.bestRunSeconds;
    }

    public final int getEndlessBest() {
        return this.endlessBest;
    }

    public final int getTopSpeed() {
        return this.topSpeed;
    }

    public final int getMaxCombo() {
        return this.maxCombo;
    }

    public final int getBestChallengeScore() {
        return this.bestChallengeScore;
    }

    public final int getCareerUnlocked() {
        return this.careerUnlocked;
    }

    public final Map<Integer, Integer> getStageBest() {
        return this.stageBest;
    }

    public final Map<Integer, Integer> getStageStars() {
        return this.stageStars;
    }

    public final Set<String> getOwnedEquipment() {
        return this.ownedEquipment;
    }

    public final Map<String, String> getEquipped() {
        return this.equipped;
    }

    public final Map<String, Integer> getBoosts() {
        return this.boosts;
    }

    public final Set<String> getMissionsClaimed() {
        return this.missionsClaimed;
    }

    public final Set<String> getAchievementsUnlocked() {
        return this.achievementsUnlocked;
    }

    public final Set<String> getChallengesDone() {
        return this.challengesDone;
    }

    public final int getDailyStreak() {
        return this.dailyStreak;
    }

    public final long getDailyLastDay() {
        return this.dailyLastDay;
    }

    public final String getTournamentId() {
        return this.tournamentId;
    }

    public final int getTournamentRound() {
        return this.tournamentRound;
    }

    public final boolean getTournamentAlive() {
        return this.tournamentAlive;
    }

    public final int getTournamentTitles() {
        return this.tournamentTitles;
    }

    public final int getBestTournamentRound() {
        return this.bestTournamentRound;
    }

    public final int getLevel() {
        return INSTANCE.levelForXp(this.xp);
    }

    public final int xpIntoLevel() {
        return this.xp - INSTANCE.cumulativeXp(getLevel());
    }

    public final int xpForThisLevel() {
        return INSTANCE.xpToNext(getLevel());
    }

    public final int statLevel(StatType type) {
        Intrinsics.checkNotNullParameter(type, "type");
        Integer num = this.statLevels.get(type);
        return RangesKt.coerceIn(num != null ? num.intValue() : 1, 1, 8);
    }

    public final String equippedIn(EquipmentCategory category) {
        Intrinsics.checkNotNullParameter(category, "category");
        String str = this.equipped.get(category.name());
        return str == null ? (String) MapsKt.getValue(EquipmentCatalog.INSTANCE.getDefaultEquipped(), category) : str;
    }

    public final boolean owns(String itemId) {
        EquipmentItem equipmentItemById;
        Intrinsics.checkNotNullParameter(itemId, "itemId");
        return this.ownedEquipment.contains(itemId) || ((equipmentItemById = EquipmentCatalog.INSTANCE.byId(itemId)) != null && equipmentItemById.getDefaultOwned());
    }

    public final int boostCount(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        Integer num = this.boosts.get(id);
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    public final int starsFor(int stageId) {
        Integer num = this.stageStars.get(Integer.valueOf(stageId));
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    public final int bestFor(int stageId) {
        Integer num = this.stageBest.get(Integer.valueOf(stageId));
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    public final boolean isStageUnlocked(int id) {
        return id <= this.careerUnlocked;
    }

    public final boolean getHasStarted() {
        return this.totalRuns > 0;
    }

    /* compiled from: PlayerState.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u000e\u0010\u0007\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u0005¨\u0006\n"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/PlayerState$Companion;", "", "<init>", "()V", "xpToNext", "", "level", "cumulativeXp", "levelForXp", "xp", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final int xpToNext(int level) {
            return ((level - 1) * 120) + ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION;
        }

        private Companion() {
        }

        public final int cumulativeXp(int level) {
            int iXpToNext = 0;
            for (int i = 1; i < level; i++) {
                iXpToNext += xpToNext(i);
            }
            return iXpToNext;
        }

        public final int levelForXp(int xp) {
            int i = 1;
            while (true) {
                int i2 = i + 1;
                if (xp < cumulativeXp(i2)) {
                    return i;
                }
                i = i2;
            }
        }
    }
}
