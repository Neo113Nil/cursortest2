package com.championship.warriors.iron.legacy.presentation.game;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModel;
import com.championship.warriors.iron.legacy.audio.AudioController;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCatalog;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCategory;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentItem;
import com.championship.warriors.iron.legacy.data.meta.ChallengeCatalog;
import com.championship.warriors.iron.legacy.data.meta.ChallengeDef;
import com.championship.warriors.iron.legacy.data.meta.TournamentCatalog;
import com.championship.warriors.iron.legacy.data.meta.TournamentDef;
import com.championship.warriors.iron.legacy.data.player.AppliedBoosts;
import com.championship.warriors.iron.legacy.data.player.PlayerRepository;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.data.player.RunOutcome;
import com.championship.warriors.iron.legacy.data.player.RunReport;
import com.championship.warriors.iron.legacy.data.player.StatModifiers;
import com.championship.warriors.iron.legacy.data.player.StatType;
import com.championship.warriors.iron.legacy.data.stage.StageData;
import com.championship.warriors.iron.legacy.data.stage.StageRepository;
import com.championship.warriors.iron.legacy.runner.Booster;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import com.championship.warriors.iron.legacy.runner.RunMode;
import com.championship.warriors.iron.legacy.runner.RunOptions;
import com.championship.warriors.iron.legacy.runner.RunTheme;
import com.championship.warriors.iron.legacy.runner.RunnerEngine;
import com.championship.warriors.iron.legacy.runner.RunnerListener;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.RandomKt;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: GameViewModel.kt */
@Metadata(d1 = {"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0006\u0010\u0014\u001a\u00020\u0010J&\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020\u00122\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010)\u001a\u00020'J\u000e\u0010*\u001a\u00020'2\u0006\u0010+\u001a\u00020\u0016J\u000e\u0010,\u001a\u00020'2\u0006\u0010-\u001a\u00020\u001aJ\u0014\u0010.\u001a\u000e\u0012\u0004\u0012\u000200\u0012\u0004\u0012\u0002010/H\u0002J\b\u00102\u001a\u00020'H\u0002J\b\u00103\u001a\u00020'H\u0002J\b\u00104\u001a\u00020'H\u0016J\u0010\u00105\u001a\u00020'2\u0006\u00106\u001a\u00020\u0010H\u0016J\b\u00107\u001a\u00020'H\u0016J\b\u00108\u001a\u00020'H\u0016J\b\u00109\u001a\u00020'H\u0016J\u0010\u0010:\u001a\u00020'2\u0006\u0010;\u001a\u00020<H\u0016J\b\u0010=\u001a\u00020'H\u0016J\b\u0010>\u001a\u00020'H\u0016J\b\u0010?\u001a\u00020'H\u0016J\b\u0010@\u001a\u00020'H\u0016J\b\u0010A\u001a\u00020'H\u0016J\b\u0010B\u001a\u00020'H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001f¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0016\u0010\"\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010#0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010$\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010#0\u001f¢\u0006\b\n\u0000\u001a\u0004\b%\u0010!¨\u0006C"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/GameViewModel;", "Landroidx/lifecycle/ViewModel;", "Lcom/championship/warriors/iron/legacy/runner/RunnerListener;", "<init>", "()V", "stages", "Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;", "player", "Lcom/championship/warriors/iron/legacy/data/player/PlayerRepository;", "audio", "Lcom/championship/warriors/iron/legacy/audio/AudioController;", "engine", "Lcom/championship/warriors/iron/legacy/runner/RunnerEngine;", "mode", "Lcom/championship/warriors/iron/legacy/runner/RunMode;", "stageId", "", "challengeId", "", "tournamentId", "themeIndex", "loaded", "", "paused", "resultEmitted", "hudAcc", "", "_state", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/championship/warriors/iron/legacy/presentation/game/RunUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "_result", "Lcom/championship/warriors/iron/legacy/presentation/game/RunResult;", "result", "getResult", "load", "", "modeName", "startRun", "setPaused", "value", "onFrame", "dt", "buildSetup", "Lkotlin/Pair;", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "Lcom/championship/warriors/iron/legacy/runner/RunOptions;", "finish", "publish", "onPlace", "onClear", "lines", "onCombo", "onCoin", "onToken", "onPowerUp", "kind", "Lcom/championship/warriors/iron/legacy/runner/Booster;", "onDouble", "onShieldBlock", "onRevive", "onCheckpoint", "onMilestone", "onCrash", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class GameViewModel extends ViewModel implements RunnerListener {
    private final MutableStateFlow<RunResult> _result;
    private final MutableStateFlow<RunUiState> _state;
    private RunnerEngine engine;
    private float hudAcc;
    private boolean loaded;
    private boolean paused;
    private final StateFlow<RunResult> result;
    private boolean resultEmitted;
    private final StateFlow<RunUiState> state;
    private final StageRepository stages = GameContainer.INSTANCE.getStages();
    private final PlayerRepository player = GameContainer.INSTANCE.getPlayer();
    private final AudioController audio = GameContainer.INSTANCE.getAudio();
    private RunMode mode = RunMode.CAREER;
    private int stageId = 1;
    private String challengeId = "";
    private String tournamentId = "";
    private int themeIndex = 2;

    /* compiled from: GameViewModel.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[StatType.values().length];
            try {
                iArr[StatType.SPEED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[StatType.CONTROL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[StatType.STAMINA.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[StatType.AGILITY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[StatType.REWARD.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[RunMode.values().length];
            try {
                iArr2[RunMode.CAREER.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr2[RunMode.ENDLESS.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr2[RunMode.TIME_TRIAL.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr2[RunMode.CHALLENGE.ordinal()] = 4;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr2[RunMode.TOURNAMENT.ordinal()] = 5;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr2[RunMode.TRAINING.ordinal()] = 6;
            } catch (NoSuchFieldError unused11) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    public GameViewModel() {
        MutableStateFlow<RunUiState> MutableStateFlow = StateFlowKt.MutableStateFlow(new RunUiState(false, 0, 0, 0, 0, 0, false, 0, false, 0, false, false, false, false, false, 32767, null));
        this._state = MutableStateFlow;
        this.state = FlowKt.asStateFlow(MutableStateFlow);
        MutableStateFlow<RunResult> MutableStateFlow2 = StateFlowKt.MutableStateFlow(null);
        this._result = MutableStateFlow2;
        this.result = FlowKt.asStateFlow(MutableStateFlow2);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onStageComplete() {
        super.onStageComplete();
    }

    public final StateFlow<RunUiState> getState() {
        return this.state;
    }

    public final StateFlow<RunResult> getResult() {
        return this.result;
    }

    /* renamed from: themeIndex, reason: from getter */
    public final int getThemeIndex() {
        return this.themeIndex;
    }

    public final void load(String modeName, int stageId, String challengeId, String tournamentId) {
        Object objM478constructorimpl;
        Intrinsics.checkNotNullParameter(modeName, "modeName");
        Intrinsics.checkNotNullParameter(challengeId, "challengeId");
        Intrinsics.checkNotNullParameter(tournamentId, "tournamentId");
        if (this.loaded) {
            return;
        }
        try {
            Result.Companion companion = Result.INSTANCE;
            GameViewModel gameViewModel = this;
            objM478constructorimpl = Result.m478constructorimpl(RunMode.valueOf(modeName));
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
        }
        RunMode runMode = RunMode.CAREER;
        if (Result.m484isFailureimpl(objM478constructorimpl)) {
            objM478constructorimpl = runMode;
        }
        this.mode = (RunMode) objM478constructorimpl;
        this.stageId = stageId;
        this.challengeId = challengeId;
        this.tournamentId = tournamentId;
        Pair<RunConfig, RunOptions> pairBuildSetup = buildSetup();
        RunnerEngine runnerEngine = new RunnerEngine(pairBuildSetup.component1(), pairBuildSetup.component2(), RandomKt.Random(System.nanoTime()));
        this.engine = runnerEngine;
        runnerEngine.setListener(this);
        this.loaded = true;
        publish();
    }

    public final RunnerEngine engine() {
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine != null) {
            return runnerEngine;
        }
        Intrinsics.throwUninitializedPropertyAccessException("engine");
        return null;
    }

    public final void startRun() {
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine = null;
        }
        runnerEngine.start();
    }

    public final void setPaused(boolean value) {
        this.paused = value;
    }

    public final void onFrame(float dt) {
        if (this.paused) {
            return;
        }
        RunnerEngine runnerEngine = this.engine;
        RunnerEngine runnerEngine2 = null;
        if (runnerEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine = null;
        }
        runnerEngine.update(dt);
        float f = this.hudAcc + dt;
        this.hudAcc = f;
        if (f >= 0.08f) {
            this.hudAcc = 0.0f;
            publish();
        }
        if (this.resultEmitted) {
            return;
        }
        RunnerEngine runnerEngine3 = this.engine;
        if (runnerEngine3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine3 = null;
        }
        if (!runnerEngine3.getFinished()) {
            RunnerEngine runnerEngine4 = this.engine;
            if (runnerEngine4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
            } else {
                runnerEngine2 = runnerEngine4;
            }
            if (!runnerEngine2.getCrashed()) {
                return;
            }
        }
        this.resultEmitted = true;
        publish();
        finish();
    }

    /* JADX WARN: Removed duplicated region for block: B:66:0x020f  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x021d  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0220  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final Pair<RunConfig, RunOptions> buildSetup() {
        RunConfig config;
        float targetDistance;
        boolean z;
        float f;
        float f2;
        float f3;
        float f4;
        RunConfig runConfig;
        PlayerState playerStateCurrent = this.player.current();
        StatModifiers statModifiersCompute = StatType.INSTANCE.compute(playerStateCurrent.getStatLevels());
        float speedFactor = statModifiersCompute.getSpeedFactor();
        float controlMul = statModifiersCompute.getControlMul();
        float staminaMul = statModifiersCompute.getStaminaMul();
        float agilityMul = statModifiersCompute.getAgilityMul();
        float rewardMul = statModifiersCompute.getRewardMul();
        Iterator<EquipmentCategory> it = EquipmentCategory.getEntries().iterator();
        float bonusPercent = rewardMul;
        float bonusPercent2 = speedFactor;
        float bonusPercent3 = controlMul;
        float bonusPercent4 = staminaMul;
        float bonusPercent5 = agilityMul;
        while (it.hasNext()) {
            EquipmentItem equipmentItemById = EquipmentCatalog.INSTANCE.byId(playerStateCurrent.equippedIn(it.next()));
            if (equipmentItemById != null) {
                StatType bonusStat = equipmentItemById.getBonusStat();
                int i = bonusStat == null ? -1 : WhenMappings.$EnumSwitchMapping$0[bonusStat.ordinal()];
                if (i == -1) {
                    continue;
                } else if (i == 1) {
                    bonusPercent2 += equipmentItemById.getBonusPercent();
                } else if (i == 2) {
                    bonusPercent3 += equipmentItemById.getBonusPercent();
                } else if (i == 3) {
                    bonusPercent4 += equipmentItemById.getBonusPercent();
                } else if (i == 4) {
                    bonusPercent5 += equipmentItemById.getBonusPercent();
                } else {
                    if (i != 5) {
                        throw new NoWhenBranchMatchedException();
                    }
                    bonusPercent += equipmentItemById.getBonusPercent();
                }
            }
        }
        EquipmentItem equipmentItemById2 = EquipmentCatalog.INSTANCE.byId(playerStateCurrent.equippedIn(EquipmentCategory.JERSEY));
        int color = equipmentItemById2 != null ? equipmentItemById2.getColor() : -12747777;
        EquipmentItem equipmentItemById3 = EquipmentCatalog.INSTANCE.byId(playerStateCurrent.equippedIn(EquipmentCategory.FOOTBALL));
        int color2 = equipmentItemById3 != null ? equipmentItemById3.getColor() : GameView.COL_WHITE;
        EquipmentItem equipmentItemById4 = EquipmentCatalog.INSTANCE.byId(playerStateCurrent.equippedIn(EquipmentCategory.TRAIL));
        int color3 = equipmentItemById4 != null ? equipmentItemById4.getColor() : 0;
        AppliedBoosts appliedBoostsConsumeBoosts = this.mode != RunMode.TRAINING ? this.player.consumeBoosts() : new AppliedBoosts(false, false, false, 0, 15, null);
        switch (WhenMappings.$EnumSwitchMapping$1[this.mode.ordinal()]) {
            case 1:
                StageData stageDataStageById = this.stages.stageById(this.stageId);
                if (stageDataStageById == null) {
                    stageDataStageById = (StageData) CollectionsKt.first((List) this.stages.getStages());
                }
                this.themeIndex = stageDataStageById.getThemeIndex();
                config = stageDataStageById.getConfig();
                targetDistance = stageDataStageById.getConfig().getTargetDistance();
                z = false;
                f = targetDistance;
                f2 = 0.0f;
                f3 = f2;
                f4 = f3;
                runConfig = config;
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            case 2:
                this.themeIndex = 2;
                z = false;
                f = 0.0f;
                f2 = 0.0f;
                f3 = 0.0f;
                f4 = 0.0f;
                runConfig = new RunConfig(3, 10.0f, 22.0f, 1.4f, 20.0f, 10.0f, 0.35f, 0.13f, 0.65f, 0.0f);
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            case 3:
                this.themeIndex = 1;
                z = false;
                f = 300.0f;
                f2 = 50.0f;
                f3 = 80.0f;
                f4 = 9.0f;
                runConfig = new RunConfig(3, 11.0f, 20.0f, 1.0f, 18.0f, 12.0f, 0.12f, 0.14f, 0.6f, 300.0f);
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            case 4:
                this.themeIndex = 2;
                ChallengeDef challengeDefById = ChallengeCatalog.INSTANCE.byId(this.challengeId);
                if (challengeDefById == null) {
                    challengeDefById = (ChallengeDef) CollectionsKt.first((List) ChallengeCatalog.INSTANCE.getChallenges());
                }
                config = challengeDefById.getConfig();
                targetDistance = challengeDefById.getCap();
                z = false;
                f = targetDistance;
                f2 = 0.0f;
                f3 = f2;
                f4 = f3;
                runConfig = config;
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            case 5:
                this.themeIndex = 4;
                TournamentDef tournamentDefById = TournamentCatalog.INSTANCE.byId(this.tournamentId);
                if (tournamentDefById == null) {
                    tournamentDefById = (TournamentDef) CollectionsKt.first((List) TournamentCatalog.INSTANCE.getTournaments());
                }
                config = tournamentDefById.getConfig();
                targetDistance = tournamentDefById.getConfig().getTargetDistance();
                z = false;
                f = targetDistance;
                f2 = 0.0f;
                f3 = f2;
                f4 = f3;
                runConfig = config;
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            case 6:
                this.themeIndex = 0;
                config = new RunConfig(3, 7.0f, 11.0f, 0.3f, 24.0f, 18.0f, 0.0f, 0.15f, 0.7f, 0.0f);
                z = true;
                f = 0.0f;
                f2 = 0.0f;
                f3 = f2;
                f4 = f3;
                runConfig = config;
                return TuplesKt.to(runConfig, new RunOptions(this.mode, f, f2, f3, f4, z, bonusPercent3, bonusPercent5, bonusPercent4, bonusPercent, bonusPercent2, appliedBoostsConsumeBoosts.getShieldStart(), appliedBoostsConsumeBoosts.getHeadStart() ? 170.0f : 0.0f, appliedBoostsConsumeBoosts.getRevives(), !appliedBoostsConsumeBoosts.getCoinRush() ? 2.0f : 1.0f, RunTheme.INSTANCE.forStage(this.themeIndex), color, color2, color3));
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0052  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void finish() {
        boolean z;
        boolean z2;
        boolean z3;
        MutableStateFlow<RunResult> mutableStateFlow;
        boolean z4;
        TournamentDef tournamentDefById;
        RunnerEngine runnerEngine = this.engine;
        RunnerEngine runnerEngine2 = null;
        if (runnerEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine = null;
        }
        int distance = (int) runnerEngine.getDistance();
        ChallengeDef challengeDefById = ChallengeCatalog.INSTANCE.byId(this.challengeId);
        if (this.mode != RunMode.CHALLENGE || challengeDefById == null) {
            z = false;
        } else {
            RunnerEngine runnerEngine3 = this.engine;
            if (runnerEngine3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                runnerEngine3 = null;
            }
            int coins = runnerEngine3.getCoins();
            RunnerEngine runnerEngine4 = this.engine;
            if (runnerEngine4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                runnerEngine4 = null;
            }
            int obstaclesCleared = runnerEngine4.getObstaclesCleared();
            RunnerEngine runnerEngine5 = this.engine;
            if (runnerEngine5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                runnerEngine5 = null;
            }
            if (challengeDefById.passed(coins, distance, obstaclesCleared, runnerEngine5.getScore())) {
                z = true;
            }
        }
        RunMode runMode = this.mode;
        int i = this.stageId;
        RunnerEngine runnerEngine6 = this.engine;
        if (runnerEngine6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine6 = null;
        }
        int score = runnerEngine6.getScore();
        RunnerEngine runnerEngine7 = this.engine;
        if (runnerEngine7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine7 = null;
        }
        int coins2 = runnerEngine7.getCoins();
        RunnerEngine runnerEngine8 = this.engine;
        if (runnerEngine8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine8 = null;
        }
        int obstaclesCleared2 = runnerEngine8.getObstaclesCleared();
        RunnerEngine runnerEngine9 = this.engine;
        if (runnerEngine9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine9 = null;
        }
        int powerupsUsed = runnerEngine9.getPowerupsUsed();
        RunnerEngine runnerEngine10 = this.engine;
        if (runnerEngine10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine10 = null;
        }
        int elapsedSeconds = runnerEngine10.getElapsedSeconds();
        RunnerEngine runnerEngine11 = this.engine;
        if (runnerEngine11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine11 = null;
        }
        int topSpeed = runnerEngine11.getTopSpeed();
        RunnerEngine runnerEngine12 = this.engine;
        if (runnerEngine12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine12 = null;
        }
        int tokens = runnerEngine12.getTokens();
        RunnerEngine runnerEngine13 = this.engine;
        if (runnerEngine13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine13 = null;
        }
        int maxCombo = runnerEngine13.getMaxCombo();
        RunnerEngine runnerEngine14 = this.engine;
        if (runnerEngine14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine14 = null;
        }
        boolean finished = runnerEngine14.getFinished();
        String str = this.challengeId;
        if (str.length() == 0) {
            str = null;
        }
        RunReport runReportRecordRun = this.player.recordRun(new RunOutcome(runMode, i, score, distance, coins2, obstaclesCleared2, powerupsUsed, elapsedSeconds, topSpeed, tokens, maxCombo, finished, str, z));
        if (this.mode != RunMode.TOURNAMENT || (tournamentDefById = TournamentCatalog.INSTANCE.byId(this.tournamentId)) == null) {
            z2 = false;
            z3 = false;
        } else {
            int iCoerceIn = RangesKt.coerceIn(this.player.current().getTournamentRound(), 0, tournamentDefById.getRounds().size() - 1);
            int thresholdScore = tournamentDefById.getRounds().get(iCoerceIn).getThresholdScore();
            RunnerEngine runnerEngine15 = this.engine;
            if (runnerEngine15 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                runnerEngine15 = null;
            }
            boolean z5 = runnerEngine15.getScore() >= thresholdScore;
            boolean z6 = iCoerceIn == tournamentDefById.getRounds().size() + (-1);
            this.player.advanceTournament(z5, z6);
            z3 = z6;
            z2 = z5;
        }
        MutableStateFlow<RunResult> mutableStateFlow2 = this._result;
        String strName = this.mode.name();
        int i2 = this.stageId;
        String str2 = this.challengeId;
        String str3 = this.tournamentId;
        RunnerEngine runnerEngine16 = this.engine;
        if (runnerEngine16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine16 = null;
        }
        boolean finished2 = runnerEngine16.getFinished();
        RunnerEngine runnerEngine17 = this.engine;
        if (runnerEngine17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine17 = null;
        }
        boolean timedOut = runnerEngine17.getTimedOut();
        RunnerEngine runnerEngine18 = this.engine;
        if (runnerEngine18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine18 = null;
        }
        int score2 = runnerEngine18.getScore();
        RunnerEngine runnerEngine19 = this.engine;
        if (runnerEngine19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine19 = null;
        }
        int coins3 = runnerEngine19.getCoins();
        int stars = runReportRecordRun.getStars();
        boolean newHighScore = runReportRecordRun.getNewHighScore();
        int xpGained = runReportRecordRun.getXpGained();
        boolean leveledUp = runReportRecordRun.getLeveledUp();
        boolean z7 = z;
        int newLevel = runReportRecordRun.getNewLevel();
        int nextStageId = runReportRecordRun.getNextStageId();
        boolean careerAdvanced = runReportRecordRun.getCareerAdvanced();
        RunnerEngine runnerEngine20 = this.engine;
        if (runnerEngine20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
        } else {
            runnerEngine2 = runnerEngine20;
        }
        if (runnerEngine2.getFinished() && this.stageId == this.stages.getLastStageId() && this.mode == RunMode.CAREER) {
            mutableStateFlow = mutableStateFlow2;
            z4 = true;
        } else {
            mutableStateFlow = mutableStateFlow2;
            z4 = false;
        }
        mutableStateFlow.setValue(new RunResult(strName, i2, str2, str3, finished2, timedOut, score2, distance, coins3, stars, newHighScore, xpGained, leveledUp, newLevel, nextStageId, careerAdvanced, z4, z7, z2, z3));
    }

    private final void publish() {
        int targetDistance;
        MutableStateFlow<RunUiState> mutableStateFlow = this._state;
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine = null;
        }
        int score = runnerEngine.getScore();
        RunnerEngine runnerEngine2 = this.engine;
        if (runnerEngine2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine2 = null;
        }
        int distance = (int) runnerEngine2.getDistance();
        RunnerEngine runnerEngine3 = this.engine;
        if (runnerEngine3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine3 = null;
        }
        int obstaclesCleared = runnerEngine3.getObstaclesCleared();
        RunnerEngine runnerEngine4 = this.engine;
        if (runnerEngine4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine4 = null;
        }
        int coins = runnerEngine4.getCoins();
        RunnerEngine runnerEngine5 = this.engine;
        if (runnerEngine5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine5 = null;
        }
        int combo = runnerEngine5.getCombo();
        RunnerEngine runnerEngine6 = this.engine;
        if (runnerEngine6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine6 = null;
        }
        boolean comboActive = runnerEngine6.getComboActive();
        RunnerEngine runnerEngine7 = this.engine;
        if (runnerEngine7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine7 = null;
        }
        if (runnerEngine7.getOptions().getTargetDistance() > 0.0f) {
            RunnerEngine runnerEngine8 = this.engine;
            if (runnerEngine8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("engine");
                runnerEngine8 = null;
            }
            targetDistance = (int) runnerEngine8.getOptions().getTargetDistance();
        } else {
            targetDistance = 0;
        }
        RunnerEngine runnerEngine9 = this.engine;
        if (runnerEngine9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine9 = null;
        }
        boolean zIsTimeTrial = runnerEngine9.isTimeTrial();
        RunnerEngine runnerEngine10 = this.engine;
        if (runnerEngine10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine10 = null;
        }
        int iCeil = (int) Math.ceil(runnerEngine10.getTimeRemaining());
        RunnerEngine runnerEngine11 = this.engine;
        if (runnerEngine11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine11 = null;
        }
        boolean speedActive = runnerEngine11.getSpeedActive();
        RunnerEngine runnerEngine12 = this.engine;
        if (runnerEngine12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine12 = null;
        }
        boolean shieldActive = runnerEngine12.getShieldActive();
        RunnerEngine runnerEngine13 = this.engine;
        if (runnerEngine13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine13 = null;
        }
        boolean magnetActive = runnerEngine13.getMagnetActive();
        RunnerEngine runnerEngine14 = this.engine;
        if (runnerEngine14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine14 = null;
        }
        boolean doubleActive = runnerEngine14.getDoubleActive();
        RunnerEngine runnerEngine15 = this.engine;
        if (runnerEngine15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("engine");
            runnerEngine15 = null;
        }
        mutableStateFlow.setValue(new RunUiState(true, score, distance, obstaclesCleared, coins, combo, comboActive, targetDistance, zIsTimeTrial, iCeil, speedActive, shieldActive, magnetActive, doubleActive, runnerEngine15.getSlowmoActive()));
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onPlace() {
        this.audio.play(Sfx.SLIDE);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onClear(int lines) {
        this.audio.play(Sfx.CHECKPOINT);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onCombo() {
        this.audio.play(Sfx.DOUBLE);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onCoin() {
        this.audio.play(Sfx.COIN);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onToken() {
        this.audio.play(Sfx.POWERUP);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onPowerUp(Booster kind) {
        Intrinsics.checkNotNullParameter(kind, "kind");
        this.audio.play(Sfx.POWERUP);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onDouble() {
        this.audio.play(Sfx.DOUBLE);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onShieldBlock() {
        this.audio.play(Sfx.SHIELD);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onRevive() {
        this.audio.play(Sfx.SHIELD);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onCheckpoint() {
        this.audio.play(Sfx.CHECKPOINT);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onMilestone() {
        this.audio.play(Sfx.DOUBLE);
    }

    @Override // com.championship.warriors.iron.legacy.runner.RunnerListener
    public void onCrash() {
        this.audio.play(Sfx.COLLISION);
    }
}
