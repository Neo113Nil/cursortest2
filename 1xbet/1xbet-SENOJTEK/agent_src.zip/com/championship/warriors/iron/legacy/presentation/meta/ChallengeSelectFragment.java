package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.os.BundleKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.ChallengeCatalog;
import com.championship.warriors.iron.legacy.data.meta.ChallengeDef;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentListBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import com.championship.warriors.iron.legacy.presentation.common.MetaAdapter;
import com.championship.warriors.iron.legacy.presentation.common.MetaRow;
import com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment;
import java.util.ArrayList;
import java.util.List;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;

/* compiled from: ChallengeSelectFragment.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\b\u0010\r\u001a\u00020\bH\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/ChallengeSelectFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", "<init>", "()V", "adapter", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter;", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ChallengeSelectFragment extends BaseFragment<FragmentListBinding> {
    private final MetaAdapter adapter;

    /* compiled from: ChallengeSelectFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentListBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentListBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", 0);
        }

        public final FragmentListBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentListBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentListBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public ChallengeSelectFragment() {
        super(AnonymousClass1.INSTANCE);
        this.adapter = new MetaAdapter();
    }

    public static final /* synthetic */ FragmentListBinding access$getBinding(ChallengeSelectFragment challengeSelectFragment) {
        return challengeSelectFragment.getBinding();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().title.setText(R.string.challenge_title);
        getBinding().recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        getBinding().recycler.setAdapter(this.adapter);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ChallengeSelectFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner), null, null, new AnonymousClass2(null), 3, null);
    }

    static final void onViewCreated$lambda$0(ChallengeSelectFragment challengeSelectFragment, View view) {
        challengeSelectFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(challengeSelectFragment).popBackStack();
    }

    /* compiled from: ChallengeSelectFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2", f = "ChallengeSelectFragment.kt", i = {}, l = {34}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ChallengeSelectFragment.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: ChallengeSelectFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2$1", f = "ChallengeSelectFragment.kt", i = {}, l = {35}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ ChallengeSelectFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass1(ChallengeSelectFragment challengeSelectFragment, Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
                this.this$0 = challengeSelectFragment;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass1(this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            /* compiled from: ChallengeSelectFragment.kt */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
            /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2$1$1, reason: invalid class name and collision with other inner class name */
            static final class C00131<T> implements FlowCollector {
                final /* synthetic */ ChallengeSelectFragment this$0;

                C00131(ChallengeSelectFragment challengeSelectFragment) {
                    this.this$0 = challengeSelectFragment;
                }

                @Override // kotlinx.coroutines.flow.FlowCollector
                public /* bridge */ /* synthetic */ Object emit(Object obj, Continuation continuation) {
                    return emit((PlayerState) obj, (Continuation<? super Unit>) continuation);
                }

                public final Object emit(PlayerState playerState, Continuation<? super Unit> continuation) {
                    ChallengeSelectFragment.access$getBinding(this.this$0).coinsValue.setText(String.valueOf(playerState.getCoins()));
                    MetaAdapter metaAdapter = this.this$0.adapter;
                    List<ChallengeDef> challenges = ChallengeCatalog.INSTANCE.getChallenges();
                    final ChallengeSelectFragment challengeSelectFragment = this.this$0;
                    ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(challenges, 10));
                    for (final ChallengeDef challengeDef : challenges) {
                        boolean zContains = playerState.getChallengesDone().contains(challengeDef.getId());
                        String id = challengeDef.getId();
                        int i = R.drawable.ic_target;
                        int i2 = R.color.accent_light;
                        String string = challengeSelectFragment.getString(challengeDef.getNameRes());
                        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                        arrayList.add(new MetaRow(id, i, i2, string, challengeSelectFragment.getString(challengeDef.getDescRes()) + "  •  " + challengeSelectFragment.getString(R.string.challenge_reward, Boxing.boxInt(challengeDef.getRewardCoins())), 0, 0, challengeSelectFragment.getString(R.string.play), false, null, zContains, String.valueOf(zContains), new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ChallengeSelectFragment$onViewCreated$2$1$1$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ChallengeSelectFragment.AnonymousClass2.AnonymousClass1.C00131.emit$lambda$1$lambda$0(challengeSelectFragment, challengeDef);
                            }
                        }, 864, null));
                    }
                    metaAdapter.submitList(arrayList);
                    return Unit.INSTANCE;
                }

                static final Unit emit$lambda$1$lambda$0(ChallengeSelectFragment challengeSelectFragment, ChallengeDef challengeDef) {
                    challengeSelectFragment.getAudio().play(Sfx.BUTTON);
                    FragmentKt.findNavController(challengeSelectFragment).navigate(R.id.action_global_open_run, BundleKt.bundleOf(TuplesKt.to("mode", "CHALLENGE"), TuplesKt.to("stageId", 1), TuplesKt.to("challengeId", challengeDef.getId()), TuplesKt.to("tournamentId", "")));
                    return Unit.INSTANCE;
                }
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    this.label = 1;
                    if (GameContainer.INSTANCE.getPlayer().getState().collect(new C00131(this.this$0), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                }
                throw new KotlinNothingValueException();
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                LifecycleOwner viewLifecycleOwner = ChallengeSelectFragment.this.getViewLifecycleOwner();
                Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
                this.label = 1;
                if (RepeatOnLifecycleKt.repeatOnLifecycle(viewLifecycleOwner, Lifecycle.State.STARTED, new AnonymousClass1(ChallengeSelectFragment.this, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }
}
