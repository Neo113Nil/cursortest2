package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;

/* loaded from: classes.dex */
public final class FragmentTournamentResultsBinding implements ViewBinding {
    public final TextView bestRoundValue;
    public final MaterialButton menuButton;
    public final ImageView resultIcon;
    private final FrameLayout rootView;
    public final TextView subtitle;
    public final TextView title;
    public final TextView titlesValue;
    public final MaterialButton tournamentButton;

    private FragmentTournamentResultsBinding(FrameLayout frameLayout, TextView textView, MaterialButton materialButton, ImageView imageView, TextView textView2, TextView textView3, TextView textView4, MaterialButton materialButton2) {
        this.rootView = frameLayout;
        this.bestRoundValue = textView;
        this.menuButton = materialButton;
        this.resultIcon = imageView;
        this.subtitle = textView2;
        this.title = textView3;
        this.titlesValue = textView4;
        this.tournamentButton = materialButton2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentTournamentResultsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentTournamentResultsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_tournament_results, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentTournamentResultsBinding bind(View view) {
        int i = R.id.bestRoundValue;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.menuButton;
            MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
            if (materialButton != null) {
                i = R.id.resultIcon;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                if (imageView != null) {
                    i = R.id.subtitle;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        i = R.id.title;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.titlesValue;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView4 != null) {
                                i = R.id.tournamentButton;
                                MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                if (materialButton2 != null) {
                                    return new FragmentTournamentResultsBinding((FrameLayout) view, textView, materialButton, imageView, textView2, textView3, textView4, materialButton2);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
