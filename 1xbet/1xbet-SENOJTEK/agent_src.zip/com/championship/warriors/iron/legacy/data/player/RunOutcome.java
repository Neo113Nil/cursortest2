package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.runner.RunMode;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PlayerRepository.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b)\b\u0086\b\u0018\u00002\u00020\u0001B}\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\u0006\u0010\r\u001a\u00020\u0005\u0012\u0006\u0010\u000e\u001a\u00020\u0005\u0012\u0006\u0010\u000f\u001a\u00020\u0010\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0012\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0010¢\u0006\u0004\b\u0014\u0010\u0015J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\t\u0010)\u001a\u00020\u0005HÆ\u0003J\t\u0010*\u001a\u00020\u0005HÆ\u0003J\t\u0010+\u001a\u00020\u0005HÆ\u0003J\t\u0010,\u001a\u00020\u0005HÆ\u0003J\t\u0010-\u001a\u00020\u0005HÆ\u0003J\t\u0010.\u001a\u00020\u0005HÆ\u0003J\t\u0010/\u001a\u00020\u0005HÆ\u0003J\t\u00100\u001a\u00020\u0005HÆ\u0003J\t\u00101\u001a\u00020\u0005HÆ\u0003J\t\u00102\u001a\u00020\u0005HÆ\u0003J\t\u00103\u001a\u00020\u0010HÆ\u0003J\u000b\u00104\u001a\u0004\u0018\u00010\u0012HÆ\u0003J\t\u00105\u001a\u00020\u0010HÆ\u0003J\u0097\u0001\u00106\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u00102\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00122\b\b\u0002\u0010\u0013\u001a\u00020\u0010HÆ\u0001J\u0013\u00107\u001a\u00020\u00102\b\u00108\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00109\u001a\u00020\u0005HÖ\u0001J\t\u0010:\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0019R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0019R\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0019R\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0019R\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0013\u0010\u0011\u001a\u0004\u0018\u00010\u0012¢\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0011\u0010\u0013\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b'\u0010$¨\u0006;"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/RunOutcome;", "", "mode", "Lcom/championship/warriors/iron/legacy/runner/RunMode;", "stageId", "", "score", "distance", "coins", "avoided", "powerups", "seconds", "topSpeed", "tokens", "maxCombo", "finished", "", "challengeId", "", "challengePassed", "<init>", "(Lcom/championship/warriors/iron/legacy/runner/RunMode;IIIIIIIIIIZLjava/lang/String;Z)V", "getMode", "()Lcom/championship/warriors/iron/legacy/runner/RunMode;", "getStageId", "()I", "getScore", "getDistance", "getCoins", "getAvoided", "getPowerups", "getSeconds", "getTopSpeed", "getTokens", "getMaxCombo", "getFinished", "()Z", "getChallengeId", "()Ljava/lang/String;", "getChallengePassed", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunOutcome {
    private final int avoided;
    private final String challengeId;
    private final boolean challengePassed;
    private final int coins;
    private final int distance;
    private final boolean finished;
    private final int maxCombo;
    private final RunMode mode;
    private final int powerups;
    private final int score;
    private final int seconds;
    private final int stageId;
    private final int tokens;
    private final int topSpeed;

    /* renamed from: component1, reason: from getter */
    public final RunMode getMode() {
        return this.mode;
    }

    /* renamed from: component10, reason: from getter */
    public final int getTokens() {
        return this.tokens;
    }

    /* renamed from: component11, reason: from getter */
    public final int getMaxCombo() {
        return this.maxCombo;
    }

    /* renamed from: component12, reason: from getter */
    public final boolean getFinished() {
        return this.finished;
    }

    /* renamed from: component13, reason: from getter */
    public final String getChallengeId() {
        return this.challengeId;
    }

    /* renamed from: component14, reason: from getter */
    public final boolean getChallengePassed() {
        return this.challengePassed;
    }

    /* renamed from: component2, reason: from getter */
    public final int getStageId() {
        return this.stageId;
    }

    /* renamed from: component3, reason: from getter */
    public final int getScore() {
        return this.score;
    }

    /* renamed from: component4, reason: from getter */
    public final int getDistance() {
        return this.distance;
    }

    /* renamed from: component5, reason: from getter */
    public final int getCoins() {
        return this.coins;
    }

    /* renamed from: component6, reason: from getter */
    public final int getAvoided() {
        return this.avoided;
    }

    /* renamed from: component7, reason: from getter */
    public final int getPowerups() {
        return this.powerups;
    }

    /* renamed from: component8, reason: from getter */
    public final int getSeconds() {
        return this.seconds;
    }

    /* renamed from: component9, reason: from getter */
    public final int getTopSpeed() {
        return this.topSpeed;
    }

    public final RunOutcome copy(RunMode mode, int stageId, int score, int distance, int coins, int avoided, int powerups, int seconds, int topSpeed, int tokens, int maxCombo, boolean finished, String challengeId, boolean challengePassed) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        return new RunOutcome(mode, stageId, score, distance, coins, avoided, powerups, seconds, topSpeed, tokens, maxCombo, finished, challengeId, challengePassed);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunOutcome)) {
            return false;
        }
        RunOutcome runOutcome = (RunOutcome) other;
        return this.mode == runOutcome.mode && this.stageId == runOutcome.stageId && this.score == runOutcome.score && this.distance == runOutcome.distance && this.coins == runOutcome.coins && this.avoided == runOutcome.avoided && this.powerups == runOutcome.powerups && this.seconds == runOutcome.seconds && this.topSpeed == runOutcome.topSpeed && this.tokens == runOutcome.tokens && this.maxCombo == runOutcome.maxCombo && this.finished == runOutcome.finished && Intrinsics.areEqual(this.challengeId, runOutcome.challengeId) && this.challengePassed == runOutcome.challengePassed;
    }

    public int hashCode() {
        int iHashCode = ((((((((((((((((((((((this.mode.hashCode() * 31) + Integer.hashCode(this.stageId)) * 31) + Integer.hashCode(this.score)) * 31) + Integer.hashCode(this.distance)) * 31) + Integer.hashCode(this.coins)) * 31) + Integer.hashCode(this.avoided)) * 31) + Integer.hashCode(this.powerups)) * 31) + Integer.hashCode(this.seconds)) * 31) + Integer.hashCode(this.topSpeed)) * 31) + Integer.hashCode(this.tokens)) * 31) + Integer.hashCode(this.maxCombo)) * 31) + Boolean.hashCode(this.finished)) * 31;
        String str = this.challengeId;
        return ((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + Boolean.hashCode(this.challengePassed);
    }

    public String toString() {
        return "RunOutcome(mode=" + this.mode + ", stageId=" + this.stageId + ", score=" + this.score + ", distance=" + this.distance + ", coins=" + this.coins + ", avoided=" + this.avoided + ", powerups=" + this.powerups + ", seconds=" + this.seconds + ", topSpeed=" + this.topSpeed + ", tokens=" + this.tokens + ", maxCombo=" + this.maxCombo + ", finished=" + this.finished + ", challengeId=" + this.challengeId + ", challengePassed=" + this.challengePassed + ")";
    }

    public RunOutcome(RunMode mode, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, boolean z, String str, boolean z2) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        this.mode = mode;
        this.stageId = i;
        this.score = i2;
        this.distance = i3;
        this.coins = i4;
        this.avoided = i5;
        this.powerups = i6;
        this.seconds = i7;
        this.topSpeed = i8;
        this.tokens = i9;
        this.maxCombo = i10;
        this.finished = z;
        this.challengeId = str;
        this.challengePassed = z2;
    }

    public /* synthetic */ RunOutcome(RunMode runMode, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, boolean z, String str, boolean z2, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(runMode, i, i2, i3, i4, i5, i6, i7, i8, i9, i10, z, (i11 & 4096) != 0 ? null : str, (i11 & 8192) != 0 ? false : z2);
    }

    public final RunMode getMode() {
        return this.mode;
    }

    public final int getStageId() {
        return this.stageId;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getDistance() {
        return this.distance;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getAvoided() {
        return this.avoided;
    }

    public final int getPowerups() {
        return this.powerups;
    }

    public final int getSeconds() {
        return this.seconds;
    }

    public final int getTopSpeed() {
        return this.topSpeed;
    }

    public final int getTokens() {
        return this.tokens;
    }

    public final int getMaxCombo() {
        return this.maxCombo;
    }

    public final boolean getFinished() {
        return this.finished;
    }

    public final String getChallengeId() {
        return this.challengeId;
    }

    public final boolean getChallengePassed() {
        return this.challengePassed;
    }
}
