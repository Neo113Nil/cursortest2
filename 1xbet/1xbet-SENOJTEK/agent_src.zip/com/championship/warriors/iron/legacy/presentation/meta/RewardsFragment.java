package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.MissionCatalog;
import com.championship.warriors.iron.legacy.data.meta.MissionDef;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentRewardsBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RewardsFragment.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0006H\u0016J\b\u0010\f\u001a\u00020\u0006H\u0002¨\u0006\r"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/RewardsFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentRewardsBinding;", "<init>", "()V", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "refresh", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class RewardsFragment extends BaseFragment<FragmentRewardsBinding> {

    /* compiled from: RewardsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.RewardsFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentRewardsBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentRewardsBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentRewardsBinding;", 0);
        }

        public final FragmentRewardsBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentRewardsBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentRewardsBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public RewardsFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.RewardsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                RewardsFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        getBinding().dailyButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.RewardsFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                RewardsFragment.onViewCreated$lambda$1(this.f$0, view2);
            }
        });
        getBinding().claimAllButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.RewardsFragment$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                RewardsFragment.onViewCreated$lambda$3(this.f$0, view2);
            }
        });
        refresh();
    }

    static final void onViewCreated$lambda$0(RewardsFragment rewardsFragment, View view) {
        rewardsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(rewardsFragment).popBackStack();
    }

    static final void onViewCreated$lambda$1(RewardsFragment rewardsFragment, View view) {
        rewardsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(rewardsFragment).navigate(R.id.action_global_to_daily);
    }

    static final void onViewCreated$lambda$3(RewardsFragment rewardsFragment, View view) {
        Iterator<T> it = MissionCatalog.INSTANCE.getMissions().iterator();
        boolean z = false;
        while (it.hasNext()) {
            if (GameContainer.INSTANCE.getPlayer().claimMission(((MissionDef) it.next()).getId())) {
                z = true;
            }
        }
        if (z) {
            rewardsFragment.getAudio().play(Sfx.REWARD);
        }
        rewardsFragment.refresh();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    private final void refresh() {
        int i;
        getBinding().dailyStatus.setText(GameContainer.INSTANCE.getPlayer().canClaimDaily() ? R.string.daily_ready : R.string.daily_claimed);
        PlayerState playerStateCurrent = GameContainer.INSTANCE.getPlayer().current();
        List<MissionDef> missions = MissionCatalog.INSTANCE.getMissions();
        if ((missions instanceof Collection) && missions.isEmpty()) {
            i = 0;
        } else {
            i = 0;
            for (MissionDef missionDef : missions) {
                if (missionDef.progress(playerStateCurrent) >= missionDef.getTarget() && !playerStateCurrent.getMissionsClaimed().contains(missionDef.getId()) && (i = i + 1) < 0) {
                    CollectionsKt.throwCountOverflow();
                }
            }
        }
        getBinding().claimableText.setText(i > 0 ? getString(R.string.value_fraction, Integer.valueOf(i), Integer.valueOf(MissionCatalog.INSTANCE.getMissions().size())) : getString(R.string.rewards_none));
        getBinding().claimAllButton.setEnabled(i > 0);
        getBinding().claimAllButton.setAlpha(i > 0 ? 1.0f : 0.5f);
    }
}
