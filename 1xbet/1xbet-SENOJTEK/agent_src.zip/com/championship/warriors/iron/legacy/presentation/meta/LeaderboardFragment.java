package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.leaderboard.Leaderboard;
import com.championship.warriors.iron.legacy.data.leaderboard.LeaderboardBoard;
import com.championship.warriors.iron.legacy.data.leaderboard.LeaderboardEntry;
import com.championship.warriors.iron.legacy.databinding.FragmentListBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import com.championship.warriors.iron.legacy.presentation.common.MetaAdapter;
import com.championship.warriors.iron.legacy.presentation.common.MetaRow;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: LeaderboardFragment.kt */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\b\u0010\u0017\u001a\u00020\u0012H\u0016J\u0010\u0010\u0018\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\fH\u0002J\b\u0010\u001a\u001a\u00020\u0012H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\t\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\u000f0\u000ej\b\u0012\u0004\u0012\u00020\u000f`\u0010X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/LeaderboardFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", "<init>", "()V", "adapter", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter;", "board", "Lcom/championship/warriors/iron/legacy/data/leaderboard/LeaderboardBoard;", "tabs", "", "Lkotlin/Pair;", "", "tabViews", "Ljava/util/ArrayList;", "Landroid/widget/TextView;", "Lkotlin/collections/ArrayList;", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "select", "index", "rebuild", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class LeaderboardFragment extends BaseFragment<FragmentListBinding> {
    private final MetaAdapter adapter;
    private LeaderboardBoard board;
    private final ArrayList<TextView> tabViews;
    private final List<Pair<LeaderboardBoard, Integer>> tabs;

    /* compiled from: LeaderboardFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.LeaderboardFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentListBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentListBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", 0);
        }

        public final FragmentListBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentListBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentListBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public LeaderboardFragment() {
        super(AnonymousClass1.INSTANCE);
        this.adapter = new MetaAdapter();
        this.board = LeaderboardBoard.SCORE;
        this.tabs = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(LeaderboardBoard.SCORE, Integer.valueOf(R.string.board_score)), TuplesKt.to(LeaderboardBoard.DISTANCE, Integer.valueOf(R.string.board_distance)), TuplesKt.to(LeaderboardBoard.CHALLENGE, Integer.valueOf(R.string.board_challenge)), TuplesKt.to(LeaderboardBoard.TOURNAMENT, Integer.valueOf(R.string.board_tournament))});
        this.tabViews = new ArrayList<>();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().title.setText(R.string.leaderboard_title);
        getBinding().recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        getBinding().recycler.setAdapter(this.adapter);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.LeaderboardFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                LeaderboardFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        getBinding().coinsValue.setText(String.valueOf(GameContainer.INSTANCE.getPlayer().current().getCoins()));
        getBinding().tabScroll.setVisibility(0);
        final int i = 0;
        for (Object obj : this.tabs) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            Pair pair = (Pair) obj;
            final LeaderboardBoard leaderboardBoard = (LeaderboardBoard) pair.component1();
            int iIntValue = ((Number) pair.component2()).intValue();
            TextView textView = new TextView(requireContext());
            textView.setText(getString(iIntValue));
            textView.setTextAppearance(R.style.TextAppearance_VR_Subtitle);
            textView.setGravity(17);
            int i3 = (int) (14.0f * textView.getResources().getDisplayMetrics().density);
            int i4 = i3 / 2;
            textView.setPadding(i3, i4, i3, i4);
            textView.setClickable(true);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMarginEnd((int) (8.0f * textView.getResources().getDisplayMetrics().density));
            textView.setLayoutParams(layoutParams);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.LeaderboardFragment$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    LeaderboardFragment.onViewCreated$lambda$4$lambda$3$lambda$2(this.f$0, leaderboardBoard, i, view2);
                }
            });
            this.tabViews.add(textView);
            getBinding().tabRow.addView(textView);
            i = i2;
        }
        select(0);
        rebuild();
    }

    static final void onViewCreated$lambda$0(LeaderboardFragment leaderboardFragment, View view) {
        leaderboardFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(leaderboardFragment).popBackStack();
    }

    static final void onViewCreated$lambda$4$lambda$3$lambda$2(LeaderboardFragment leaderboardFragment, LeaderboardBoard leaderboardBoard, int i, View view) {
        leaderboardFragment.getAudio().play(Sfx.BUTTON);
        leaderboardFragment.board = leaderboardBoard;
        leaderboardFragment.select(i);
        leaderboardFragment.rebuild();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    private final void select(int index) {
        int i = 0;
        for (Object obj : this.tabViews) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            TextView textView = (TextView) obj;
            textView.setBackgroundResource(i == index ? R.drawable.bg_pill_solid : R.drawable.bg_pill);
            textView.setTextColor(ContextCompat.getColor(requireContext(), i == index ? R.color.offwhite : R.color.muted));
            i = i2;
        }
    }

    private final void rebuild() {
        List<LeaderboardEntry> listEntries = Leaderboard.INSTANCE.entries(this.board, GameContainer.INSTANCE.getPlayer().current());
        MetaAdapter metaAdapter = this.adapter;
        List<LeaderboardEntry> list = listEntries;
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        int i = 0;
        for (Object obj : list) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            LeaderboardEntry leaderboardEntry = (LeaderboardEntry) obj;
            arrayList.add(new MetaRow("lb_" + this.board.name() + "_" + leaderboardEntry.getName() + "_" + i, i == 0 ? R.drawable.ic_trophy : R.drawable.ic_podium, leaderboardEntry.isPlayer() ? R.color.accent_light : i == 0 ? R.color.coin : R.color.muted, "#" + i2 + "  " + (leaderboardEntry.isPlayer() ? getString(R.string.lb_you) : leaderboardEntry.getName()), "", 0, 0, null, false, String.valueOf(leaderboardEntry.getValue()), false, leaderboardEntry.getValue() + "-" + leaderboardEntry.isPlayer(), null, 5600, null));
            i = i2;
        }
        metaAdapter.submitList(arrayList);
    }
}
