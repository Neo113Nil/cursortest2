package com.championship.warriors.iron.legacy.presentation.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.View;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import com.championship.warriors.iron.legacy.runner.Booster;
import com.championship.warriors.iron.legacy.runner.CellExtra;
import com.championship.warriors.iron.legacy.runner.Off;
import com.championship.warriors.iron.legacy.runner.Piece;
import com.championship.warriors.iron.legacy.runner.Popup;
import com.championship.warriors.iron.legacy.runner.RunTheme;
import com.championship.warriors.iron.legacy.runner.RunnerEngine;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;

/* compiled from: GameView.kt */
@Metadata(d1 = {"\u0000\u0092\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0014\u0018\u0000 j2\u00020\u0001:\u0001jB'\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u000e\u0010/\u001a\u00020\u000f2\u0006\u0010\n\u001a\u00020\u000bJ\u0006\u00100\u001a\u00020\u000fJ\u0006\u00101\u001a\u00020\u000fJ\u0010\u00102\u001a\u00020\u000f2\u0006\u00103\u001a\u00020\u0017H\u0002J\u000e\u00105\u001a\u00020\u000f2\u0006\u00106\u001a\u00020\u000eJ(\u00107\u001a\u00020\u000f2\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010:\u001a\u00020\u00072\u0006\u0010;\u001a\u00020\u0007H\u0014J\u0018\u0010<\u001a\u00020\u000f2\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u0007H\u0002J\u0010\u0010=\u001a\u00020\u00152\u0006\u0010>\u001a\u00020?H\u0016J\b\u0010@\u001a\u00020\u0015H\u0016J\u0018\u0010A\u001a\u00020\u00072\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000eH\u0002J\u001c\u0010D\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070E2\u0006\u0010F\u001a\u00020GH\u0002J\u0010\u0010H\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020JH\u0014J\u0018\u0010K\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J\u0018\u0010M\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J \u0010N\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000eH\u0002J8\u0010O\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000e2\u0006\u0010P\u001a\u00020\u000e2\u0006\u0010Q\u001a\u00020\u00072\u0006\u0010R\u001a\u00020\u000eH\u0002J:\u0010S\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000e2\u0006\u0010P\u001a\u00020\u000e2\u0006\u0010T\u001a\u00020U2\b\u0010V\u001a\u0004\u0018\u00010WH\u0002J\u0018\u0010X\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J\u0018\u0010Y\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J\u0018\u0010Z\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J\u0018\u0010[\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010L\u001a\u00020\u000bH\u0002J8\u0010\\\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010F\u001a\u00020G2\u0006\u0010]\u001a\u00020\u000e2\u0006\u0010^\u001a\u00020\u000e2\u0006\u0010_\u001a\u00020\u000e2\u0006\u0010R\u001a\u00020\u000eH\u0002J(\u0010`\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000e2\u0006\u0010a\u001a\u00020\u000eH\u0002J2\u0010b\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000e2\u0006\u0010a\u001a\u00020\u000e2\b\u0010V\u001a\u0004\u0018\u00010WH\u0002J(\u0010c\u001a\u00020\u000f2\u0006\u0010I\u001a\u00020J2\u0006\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u000e2\u0006\u0010a\u001a\u00020\u000eH\u0002J\u0018\u0010d\u001a\u00020\u00072\u0006\u0010e\u001a\u00020\u00072\u0006\u0010f\u001a\u00020\u000eH\u0002J\u0018\u0010g\u001a\u00020\u00072\u0006\u0010e\u001a\u00020\u00072\u0006\u0010f\u001a\u00020\u000eH\u0002J\u0018\u0010h\u001a\u00020\u00072\u0006\u0010e\u001a\u00020\u00072\u0006\u0010R\u001a\u00020\u000eH\u0002J\b\u0010i\u001a\u00020\u000fH\u0014R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R(\u0010\f\u001a\u0010\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f\u0018\u00010\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0018\u001a\n \u001a*\u0004\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006k"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/GameView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyle", "", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "engine", "Lcom/championship/warriors/iron/legacy/runner/RunnerEngine;", "onUpdate", "Lkotlin/Function1;", "", "", "getOnUpdate", "()Lkotlin/jvm/functions/Function1;", "setOnUpdate", "(Lkotlin/jvm/functions/Function1;)V", "running", "", "lastFrameNanos", "", "choreographer", "Landroid/view/Choreographer;", "kotlin.jvm.PlatformType", "frameCallback", "Landroid/view/Choreographer$FrameCallback;", "boardLeft", "boardTop", "boardSize", "cell", "trayTop", "trayHeight", "trayCell", "heldIndex", "fingerX", "fingerY", "paint", "Landroid/graphics/Paint;", "stroke", "text", "tmp", "Landroid/graphics/RectF;", "path", "Landroid/graphics/Path;", "bind", "startLoop", "stopLoop", "onFrame", "nanos", "topInset", "setTopInset", "inset", "onSizeChanged", "w", "h", "oldw", "oldh", "computeMetrics", "onTouchEvent", NotificationCompat.CATEGORY_EVENT, "Landroid/view/MotionEvent;", "performClick", "trayHit", "x", "y", "snapTarget", "Lkotlin/Pair;", "piece", "Lcom/championship/warriors/iron/legacy/runner/Piece;", "onDraw", "canvas", "Landroid/graphics/Canvas;", "drawBackground", "e", "drawBoard", "drawSlot", "drawBlock", "size", "col", "alpha", "drawExtra", "extra", "Lcom/championship/warriors/iron/legacy/runner/CellExtra;", "booster", "Lcom/championship/warriors/iron/legacy/runner/Booster;", "drawGhost", "drawPopups", "drawTray", "drawHeldPiece", "drawPieceAt", "cx", "cy", "unit", "star", "r", "boosterGlyph", "bolt", "lighten", TypedValues.Custom.S_COLOR, "amount", "darken", "withAlpha", "onDetachedFromWindow", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class GameView extends View {

    @Deprecated
    public static final int COL_SLOT = 587202559;

    @Deprecated
    public static final int COL_WHITE = -1379841;
    private static final Companion Companion = new Companion(null);

    @Deprecated
    public static final float GAP_RATIO = 0.09f;

    @Deprecated
    public static final float LIFT_CELLS = 1.6f;

    @Deprecated
    public static final float TRAY_RATIO = 0.24f;
    private float boardLeft;
    private float boardSize;
    private float boardTop;
    private float cell;
    private final Choreographer choreographer;
    private RunnerEngine engine;
    private float fingerX;
    private float fingerY;
    private final Choreographer.FrameCallback frameCallback;
    private int heldIndex;
    private long lastFrameNanos;
    private Function1<? super Float, Unit> onUpdate;
    private final Paint paint;
    private final Path path;
    private boolean running;
    private final Paint stroke;
    private final Paint text;
    private final RectF tmp;
    private float topInset;
    private float trayCell;
    private float trayHeight;
    private float trayTop;

    /* compiled from: GameView.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[CellExtra.values().length];
            try {
                iArr[CellExtra.COIN.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[CellExtra.GOLD.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[CellExtra.BOOSTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[CellExtra.NONE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Booster.values().length];
            try {
                iArr2[Booster.SPEED.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr2[Booster.DOUBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr2[Booster.SLOWMO.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr2[Booster.MAGNET.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public GameView(Context context) {
        this(context, null, 0, 6, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public GameView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    public /* synthetic */ GameView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GameView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Intrinsics.checkNotNullParameter(context, "context");
        this.choreographer = Choreographer.getInstance();
        this.frameCallback = new Choreographer.FrameCallback() { // from class: com.championship.warriors.iron.legacy.presentation.game.GameView$$ExternalSyntheticLambda0
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j) {
                this.f$0.onFrame(j);
            }
        };
        this.heldIndex = -1;
        this.paint = new Paint(1);
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.stroke = paint;
        Paint paint2 = new Paint(1);
        paint2.setTextAlign(Paint.Align.CENTER);
        paint2.setFakeBoldText(true);
        this.text = paint2;
        this.tmp = new RectF();
        this.path = new Path();
    }

    public final Function1<Float, Unit> getOnUpdate() {
        return this.onUpdate;
    }

    public final void setOnUpdate(Function1<? super Float, Unit> function1) {
        this.onUpdate = function1;
    }

    /* compiled from: GameView.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/GameView$Companion;", "", "<init>", "()V", "LIFT_CELLS", "", "COL_SLOT", "", "COL_WHITE", "TRAY_RATIO", "GAP_RATIO", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public final void bind(RunnerEngine engine) {
        Intrinsics.checkNotNullParameter(engine, "engine");
        this.engine = engine;
        invalidate();
    }

    public final void startLoop() {
        if (this.running) {
            return;
        }
        this.running = true;
        this.lastFrameNanos = 0L;
        this.choreographer.postFrameCallback(this.frameCallback);
    }

    public final void stopLoop() {
        this.running = false;
        this.choreographer.removeFrameCallback(this.frameCallback);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onFrame(long nanos) {
        if (this.running) {
            long j = this.lastFrameNanos;
            if (j == 0) {
                this.lastFrameNanos = nanos;
                j = nanos;
            }
            float f = (nanos - j) / 1.0E9f;
            this.lastFrameNanos = nanos;
            Function1<? super Float, Unit> function1 = this.onUpdate;
            if (function1 != null) {
                function1.invoke(Float.valueOf(f));
            }
            invalidate();
            if (this.running) {
                this.choreographer.postFrameCallback(this.frameCallback);
            }
        }
    }

    public final void setTopInset(float inset) {
        if (this.topInset == inset) {
            return;
        }
        this.topInset = inset;
        if (getWidth() > 0 && getHeight() > 0) {
            computeMetrics(getWidth(), getHeight());
        }
        invalidate();
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        computeMetrics(w, h);
    }

    private final void computeMetrics(int w, int h) {
        float f = w;
        float f2 = h;
        float fMax = Math.max(0.17f * f2, this.topInset + (0.02f * f2));
        this.boardTop = fMax;
        float fMin = Math.min(f - ((0.05f * f) * 2.0f), Math.min(f2 * 0.55f, ((0.97f * f2) - fMax) / 1.33f));
        this.boardSize = fMin;
        this.boardLeft = (f - fMin) / 2.0f;
        float f3 = fMin / 8.0f;
        this.cell = f3;
        this.trayHeight = 0.24f * fMin;
        this.trayTop = this.boardTop + fMin + (fMin * 0.09f);
        this.trayCell = 0.6f * f3;
        this.text.setTextSize(f3 * 0.5f);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null) {
            return true;
        }
        this.fingerX = event.getX();
        this.fingerY = event.getY();
        int actionMasked = event.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked == 1 || actionMasked == 3) {
                if (this.heldIndex >= 0) {
                    Piece piece = (Piece) CollectionsKt.getOrNull(runnerEngine.getTray(), this.heldIndex);
                    if (piece != null) {
                        Pair<Integer, Integer> pairSnapTarget = snapTarget(piece);
                        runnerEngine.tryPlace(this.heldIndex, pairSnapTarget.component1().intValue(), pairSnapTarget.component2().intValue());
                    }
                    this.heldIndex = -1;
                }
                performClick();
            }
        } else if (runnerEngine.getRunning() && !runnerEngine.getFinished() && !runnerEngine.getCrashed()) {
            this.heldIndex = trayHit(event.getX(), event.getY());
        }
        invalidate();
        return true;
    }

    @Override // android.view.View
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private final int trayHit(float x, float y) {
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null || y < this.trayTop - (this.trayHeight * 0.4f)) {
            return -1;
        }
        float f = this.boardSize / 3.0f;
        for (int i = 0; i < 3; i++) {
            if (runnerEngine.getTray().get(i) != null) {
                float f2 = this.boardLeft + (i * f);
                if (x >= f2 && x <= f2 + f && y <= this.trayTop + (this.trayHeight * 1.2f)) {
                    return i;
                }
            }
        }
        return -1;
    }

    private final Pair<Integer, Integer> snapTarget(Piece piece) {
        int i;
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null) {
            return TuplesKt.to(0, 0);
        }
        float cols = piece.getShape().getCols() * this.cell;
        float rows = piece.getShape().getRows();
        float f = this.cell;
        float f2 = this.fingerX - (cols / 2.0f);
        float f3 = (this.fingerY - (1.6f * f)) - ((rows * f) / 2.0f);
        int iRoundToInt = MathKt.roundToInt((f2 - this.boardLeft) / f);
        int iRoundToInt2 = MathKt.roundToInt((f3 - this.boardTop) / this.cell);
        if (runnerEngine.fits(piece.getShape(), iRoundToInt, iRoundToInt2)) {
            return TuplesKt.to(Integer.valueOf(iRoundToInt), Integer.valueOf(iRoundToInt2));
        }
        int iCoerceIn = RangesKt.coerceIn(MathKt.roundToInt((runnerEngine.getOptions().getControlMul() - 1.0f) / 0.06f), 0, 3);
        int i2 = -iCoerceIn;
        Pair<Integer, Integer> pair = null;
        if (i2 <= iCoerceIn) {
            int i3 = Integer.MAX_VALUE;
            int i4 = i2;
            while (true) {
                if (i2 <= iCoerceIn) {
                    int i5 = i2;
                    while (true) {
                        int i6 = iRoundToInt + i5;
                        int i7 = iRoundToInt2 + i4;
                        if (runnerEngine.fits(piece.getShape(), i6, i7) && (i = (i5 * i5) + (i4 * i4)) < i3) {
                            pair = TuplesKt.to(Integer.valueOf(i6), Integer.valueOf(i7));
                            i3 = i;
                        }
                        if (i5 == iCoerceIn) {
                            break;
                        }
                        i5++;
                    }
                }
                if (i4 == iCoerceIn) {
                    break;
                }
                i4++;
            }
        }
        return pair == null ? TuplesKt.to(Integer.valueOf(iRoundToInt), Integer.valueOf(iRoundToInt2)) : pair;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        RunnerEngine runnerEngine = this.engine;
        if (runnerEngine == null || this.boardSize == 0.0f) {
            return;
        }
        drawBackground(canvas, runnerEngine);
        int iSave = canvas.save();
        if (runnerEngine.getShake() > 0.0f) {
            float shake = runnerEngine.getShake() * this.cell * 0.18f;
            canvas.translate(((float) Math.cos(runnerEngine.getShake() * 40.0f)) * shake, ((float) Math.sin(runnerEngine.getShake() * 37.0f)) * shake);
        }
        drawBoard(canvas, runnerEngine);
        drawGhost(canvas, runnerEngine);
        drawPopups(canvas, runnerEngine);
        canvas.restoreToCount(iSave);
        drawTray(canvas, runnerEngine);
        drawHeldPiece(canvas, runnerEngine);
    }

    private final void drawBackground(Canvas canvas, RunnerEngine e) {
        RunTheme theme = e.getOptions().getTheme();
        this.paint.setShader(new LinearGradient(0.0f, 0.0f, 0.0f, getHeight(), theme.getSkyTop(), theme.getSkyBottom(), Shader.TileMode.CLAMP));
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.paint);
        this.paint.setShader(null);
        this.paint.setColor((e.getOptions().getJerseyColor() & ViewCompat.MEASURED_SIZE_MASK) | 570425344);
        float f = this.boardTop;
        float f2 = this.boardSize;
        canvas.drawCircle(getWidth() / 2.0f, f + (f2 / 2.0f), f2 * 0.72f, this.paint);
    }

    private final void drawBoard(Canvas canvas, RunnerEngine e) {
        Canvas canvas2 = canvas;
        RunTheme theme = e.getOptions().getTheme();
        RectF rectF = this.tmp;
        float f = this.boardLeft;
        float f2 = this.cell;
        float f3 = this.boardTop;
        float f4 = this.boardSize;
        rectF.set(f - (f2 * 0.18f), f3 - (f2 * 0.18f), f + f4 + (f2 * 0.18f), f3 + f4 + (f2 * 0.18f));
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(theme.getTrack());
        RectF rectF2 = this.tmp;
        float f5 = this.cell;
        canvas2.drawRoundRect(rectF2, f5 * 0.32f, f5 * 0.32f, this.paint);
        this.stroke.setColor((e.getOptions().getJerseyColor() & ViewCompat.MEASURED_SIZE_MASK) | 1711276032);
        this.stroke.setStrokeWidth(this.cell * 0.08f);
        RectF rectF3 = this.tmp;
        float f6 = this.cell;
        canvas2.drawRoundRect(rectF3, f6 * 0.32f, f6 * 0.32f, this.stroke);
        int rows = e.getRows();
        for (int i = 0; i < rows; i++) {
            int cols = e.getCols();
            for (int i2 = 0; i2 < cols; i2++) {
                int iColorAt = e.colorAt(i2, i);
                float f7 = this.boardLeft;
                float f8 = this.cell;
                float f9 = (i2 * f8) + f7;
                float f10 = (i * f8) + this.boardTop;
                if (iColorAt == 0) {
                    drawSlot(canvas2, f9, f10);
                } else {
                    drawBlock(canvas2, f9, f10, f8, iColorAt, 1.0f);
                    canvas2 = canvas;
                    drawExtra(canvas2, f9, f10, this.cell, e.extraAt(i2, i), e.boosterAt(i2, i));
                }
            }
        }
        if (e.getClearTimer() <= 0.0f || e.getClearing().isEmpty()) {
            return;
        }
        this.paint.setColor((((int) ((255.0f * RangesKt.coerceIn(e.getClearTimer() / 0.32f, 0.0f, 1.0f)) * 0.7f)) << 24) | ViewCompat.MEASURED_SIZE_MASK);
        Iterator<Integer> it = e.getClearing().iterator();
        while (it.hasNext()) {
            int iIntValue = it.next().intValue();
            int cols2 = iIntValue % e.getCols();
            int cols3 = iIntValue / e.getCols();
            float f11 = this.boardLeft;
            float f12 = this.cell;
            float f13 = f11 + (cols2 * f12);
            float f14 = this.boardTop + (cols3 * f12);
            this.tmp.set((f12 * 0.06f) + f13, (0.06f * f12) + f14, f13 + (f12 * 0.94f), f14 + (f12 * 0.94f));
            RectF rectF4 = this.tmp;
            float f15 = this.cell;
            canvas2.drawRoundRect(rectF4, f15 * 0.2f, f15 * 0.2f, this.paint);
        }
    }

    private final void drawSlot(Canvas canvas, float x, float y) {
        RectF rectF = this.tmp;
        float f = this.cell;
        rectF.set((f * 0.1f) + x, (0.1f * f) + y, x + (f * 0.9f), y + (f * 0.9f));
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(COL_SLOT);
        RectF rectF2 = this.tmp;
        float f2 = this.cell;
        canvas.drawRoundRect(rectF2, f2 * 0.18f, f2 * 0.18f, this.paint);
    }

    private final void drawBlock(Canvas canvas, float x, float y, float size, int col, float alpha) {
        float f = 0.06f * size;
        float f2 = x + f;
        float f3 = y + f;
        float f4 = x + size;
        float f5 = f4 - f;
        float f6 = y + size;
        this.tmp.set(f2, f3, f5, f6 - f);
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(withAlpha(darken(col, 0.18f), alpha));
        float f7 = 0.2f * size;
        canvas.drawRoundRect(this.tmp, f7, f7, this.paint);
        float f8 = 0.34f * size;
        this.tmp.set(f2, f3, f5, f6 - f8);
        this.paint.setColor(withAlpha(col, alpha));
        canvas.drawRoundRect(this.tmp, f7, f7, this.paint);
        float f9 = 0.18f * size;
        this.tmp.set(x + f9, (0.15f * size) + y, f4 - f9, y + f8);
        this.paint.setColor(withAlpha(lighten(col, 0.4f), alpha * 0.9f));
        float f10 = size * 0.12f;
        canvas.drawRoundRect(this.tmp, f10, f10, this.paint);
    }

    private final void drawExtra(Canvas canvas, float x, float y, float size, CellExtra extra, Booster booster) {
        float f = size / 2.0f;
        float f2 = x + f;
        float f3 = y + f;
        int i = WhenMappings.$EnumSwitchMapping$0[extra.ordinal()];
        if (i == 1) {
            this.paint.setColor(-15043);
            float f4 = 0.24f * size;
            canvas.drawCircle(f2, f3, f4, this.paint);
            this.stroke.setColor(COL_WHITE);
            this.stroke.setStrokeWidth(size * 0.05f);
            canvas.drawCircle(f2, f3, f4, this.stroke);
            return;
        }
        if (i == 2) {
            this.paint.setColor(-8090);
            star(canvas, f2, f3, size * 0.3f);
        } else if (i != 3) {
            if (i != 4) {
                throw new NoWhenBranchMatchedException();
            }
        } else {
            this.paint.setColor(1711276032);
            canvas.drawCircle(f2, f3, 0.3f * size, this.paint);
            this.paint.setColor(COL_WHITE);
            boosterGlyph(canvas, f2, f3, size * 0.24f, booster);
        }
    }

    private final void drawGhost(Canvas canvas, RunnerEngine e) {
        Piece piece;
        if (this.heldIndex >= 0 && (piece = (Piece) CollectionsKt.getOrNull(e.getTray(), this.heldIndex)) != null) {
            Pair<Integer, Integer> pairSnapTarget = snapTarget(piece);
            int iIntValue = pairSnapTarget.component1().intValue();
            int iIntValue2 = pairSnapTarget.component2().intValue();
            boolean zFits = e.fits(piece.getShape(), iIntValue, iIntValue2);
            for (Off off : piece.getShape().getCells()) {
                int c = off.getC() + iIntValue;
                int r = off.getR() + iIntValue2;
                if (c >= 0 && c < e.getCols() && r >= 0) {
                    if (r < e.getRows()) {
                        float f = this.boardLeft;
                        float f2 = this.cell;
                        float f3 = (c * f2) + f;
                        float f4 = this.boardTop + (r * f2);
                        if (zFits) {
                            drawBlock(canvas, f3, f4, f2, piece.getColor(), 0.5f);
                        } else {
                            this.tmp.set((f2 * 0.1f) + f3, (0.1f * f2) + f4, f3 + (f2 * 0.9f), f4 + (f2 * 0.9f));
                            this.paint.setStyle(Paint.Style.FILL);
                            this.paint.setColor(1441024061);
                            RectF rectF = this.tmp;
                            float f5 = this.cell;
                            canvas.drawRoundRect(rectF, f5 * 0.18f, f5 * 0.18f, this.paint);
                        }
                    }
                }
            }
        }
    }

    private final void drawPopups(Canvas canvas, RunnerEngine e) {
        for (Popup popup : e.getPopups()) {
            float fCoerceIn = RangesKt.coerceIn(popup.getLife() / 1.1f, 0.0f, 1.0f);
            float f = (1.0f - fCoerceIn) * this.cell * 1.4f;
            this.text.setColor(withAlpha(popup.getColor(), fCoerceIn));
            this.text.setTextSize(this.cell * 0.46f);
            canvas.drawText(popup.getText(), this.boardLeft + ((popup.getCol() + 0.5f) * this.cell), (this.boardTop + ((popup.getRow() + 0.5f) * this.cell)) - f, this.text);
        }
    }

    private final void drawTray(Canvas canvas, RunnerEngine e) {
        GameView gameView;
        Canvas canvas2;
        Piece piece;
        float f = this.boardSize / 3.0f;
        int i = 0;
        while (i < 3) {
            if (i == this.heldIndex || (piece = e.getTray().get(i)) == null) {
                gameView = this;
                canvas2 = canvas;
            } else {
                gameView = this;
                canvas2 = canvas;
                gameView.drawPieceAt(canvas2, piece, this.boardLeft + (i * f) + (f / 2.0f), this.trayTop + (this.trayHeight / 2.0f), this.trayCell, 1.0f);
            }
            i++;
            this = gameView;
            canvas = canvas2;
        }
    }

    private final void drawHeldPiece(Canvas canvas, RunnerEngine e) {
        Piece piece;
        if (this.heldIndex >= 0 && (piece = (Piece) CollectionsKt.getOrNull(e.getTray(), this.heldIndex)) != null) {
            float f = this.fingerY;
            float f2 = this.cell;
            drawPieceAt(canvas, piece, this.fingerX, f - (1.6f * f2), f2, 0.96f);
        }
    }

    private final void drawPieceAt(Canvas canvas, Piece piece, float cx, float cy, float unit, float alpha) {
        float cols = cx - ((piece.getShape().getCols() * unit) / 2.0f);
        float rows = cy - ((piece.getShape().getRows() * unit) / 2.0f);
        int i = 0;
        for (Off off : piece.getShape().getCells()) {
            int i2 = i + 1;
            float c = cols + (off.getC() * unit);
            float r = rows + (off.getR() * unit);
            drawBlock(canvas, c, r, unit, piece.getColor(), alpha);
            if (i == piece.getExtraCell() && piece.getExtra() != CellExtra.NONE) {
                drawExtra(canvas, c, r, unit, piece.getExtra(), piece.getBooster());
            }
            i = i2;
        }
    }

    private final void star(Canvas canvas, float x, float y, float r) {
        this.path.reset();
        for (int i = 0; i < 10; i++) {
            float f = i % 2 == 0 ? r : 0.45f * r;
            double d = (((i * 36) - 90) * 3.141592653589793d) / 180.0d;
            float fCos = (((float) Math.cos(d)) * f) + x;
            float fSin = (f * ((float) Math.sin(d))) + y;
            Path path = this.path;
            if (i == 0) {
                path.moveTo(fCos, fSin);
            } else {
                path.lineTo(fCos, fSin);
            }
        }
        this.path.close();
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(this.path, this.paint);
    }

    private final void boosterGlyph(Canvas canvas, float x, float y, float r, Booster booster) {
        int i = booster == null ? -1 : WhenMappings.$EnumSwitchMapping$1[booster.ordinal()];
        if (i == 1) {
            bolt(canvas, x, y, r);
            return;
        }
        if (i == 2) {
            this.text.setColor(COL_WHITE);
            this.text.setTextSize(1.7f * r);
            canvas.drawText("x2", x, (0.6f * r) + y, this.text);
            return;
        }
        if (i == 3) {
            this.stroke.setColor(COL_WHITE);
            this.stroke.setStrokeWidth(0.22f * r);
            this.stroke.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawCircle(x, y, 0.85f * r, this.stroke);
            canvas.drawLine(x, y, x, y - (0.5f * r), this.stroke);
            canvas.drawLine(x, y, x + (r * 0.4f), y, this.stroke);
            return;
        }
        if (i == 4) {
            this.stroke.setColor(COL_WHITE);
            this.stroke.setStrokeWidth(0.42f * r);
            this.stroke.setStrokeCap(Paint.Cap.BUTT);
            float f = 0.7f * r;
            float f2 = x - f;
            float f3 = x + f;
            float f4 = y + (0.9f * r);
            this.tmp.set(f2, y - (0.8f * r), f3, f4);
            canvas.drawArc(this.tmp, 180.0f, 180.0f, false, this.stroke);
            canvas.drawLine(f2, y, f2, f4, this.stroke);
            canvas.drawLine(f3, y, f3, f4, this.stroke);
            return;
        }
        this.path.reset();
        this.path.moveTo(x, y - r);
        float f5 = 0.8f * r;
        float f6 = x + f5;
        float f7 = y - (0.4f * r);
        this.path.lineTo(f6, f7);
        float f8 = (0.3f * r) + y;
        this.path.lineTo(f6, f8);
        float f9 = x - f5;
        this.path.quadTo(x, (1.1f * r) + y, f9, f8);
        this.path.lineTo(f9, f7);
        this.path.close();
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(this.path, this.paint);
    }

    private final void bolt(Canvas canvas, float x, float y, float r) {
        this.path.reset();
        float f = 0.15f * r;
        this.path.moveTo(x + f, y - r);
        float f2 = 0.5f * r;
        float f3 = (0.1f * r) + y;
        this.path.lineTo(x - f2, f3);
        this.path.lineTo(x, f3);
        this.path.lineTo(x - f, y + r);
        float f4 = y - (r * 0.2f);
        this.path.lineTo(f2 + x, f4);
        this.path.lineTo(x, f4);
        this.path.close();
        this.paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(this.path, this.paint);
    }

    private final int lighten(int color, float amount) {
        return Color.rgb((int) (Color.red(color) + ((255 - Color.red(color)) * amount)), (int) (Color.green(color) + ((255 - Color.green(color)) * amount)), (int) (Color.blue(color) + ((255 - Color.blue(color)) * amount)));
    }

    private final int darken(int color, float amount) {
        float f = 1.0f - amount;
        return Color.rgb((int) (Color.red(color) * f), (int) (Color.green(color) * f), (int) (Color.blue(color) * f));
    }

    private final int withAlpha(int color, float alpha) {
        return (RangesKt.coerceIn((int) (255.0f * alpha), 0, 255) << 24) | (color & ViewCompat.MEASURED_SIZE_MASK);
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopLoop();
        this.onUpdate = null;
        this.engine = null;
    }
}
