package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.equipment.BoostType;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCatalog;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentItem;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.data.player.StatType;
import com.championship.warriors.iron.legacy.databinding.FragmentListBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import com.championship.warriors.iron.legacy.presentation.common.MetaAdapter;
import com.championship.warriors.iron.legacy.presentation.common.MetaRow;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.enums.EnumEntries;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.StateFlow;

/* compiled from: ShopFragment.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\b\u0010\r\u001a\u00020\bH\u0016J\u0018\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0018\u0010\u0014\u001a\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0012\u001a\u00020\u0013H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/ShopFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", "<init>", "()V", "adapter", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter;", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "equipmentRow", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaRow;", "item", "Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentItem;", "s", "Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "boostRow", "boost", "Lcom/championship/warriors/iron/legacy/data/equipment/BoostType;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ShopFragment extends BaseFragment<FragmentListBinding> {
    private final MetaAdapter adapter;

    /* compiled from: ShopFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentListBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentListBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", 0);
        }

        public final FragmentListBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentListBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentListBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public ShopFragment() {
        super(AnonymousClass1.INSTANCE);
        this.adapter = new MetaAdapter();
    }

    public static final /* synthetic */ FragmentListBinding access$getBinding(ShopFragment shopFragment) {
        return shopFragment.getBinding();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().title.setText(R.string.shop_title);
        getBinding().recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        getBinding().recycler.setAdapter(this.adapter);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ShopFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner), null, null, new AnonymousClass2(null), 3, null);
    }

    static final void onViewCreated$lambda$0(ShopFragment shopFragment, View view) {
        shopFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(shopFragment).popBackStack();
    }

    /* compiled from: ShopFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$onViewCreated$2", f = "ShopFragment.kt", i = {}, l = {35}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$onViewCreated$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ShopFragment.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: ShopFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$onViewCreated$2$1", f = "ShopFragment.kt", i = {}, l = {36}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$onViewCreated$2$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ ShopFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass1(ShopFragment shopFragment, Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
                this.this$0 = shopFragment;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass1(this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    StateFlow<PlayerState> state = GameContainer.INSTANCE.getPlayer().getState();
                    final ShopFragment shopFragment = this.this$0;
                    this.label = 1;
                    if (state.collect(new FlowCollector() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment.onViewCreated.2.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object obj2, Continuation continuation) {
                            return emit((PlayerState) obj2, (Continuation<? super Unit>) continuation);
                        }

                        public final Object emit(PlayerState playerState, Continuation<? super Unit> continuation) {
                            ShopFragment.access$getBinding(shopFragment).coinsValue.setText(String.valueOf(playerState.getCoins()));
                            ArrayList arrayList = new ArrayList();
                            List<EquipmentItem> items = EquipmentCatalog.INSTANCE.getItems();
                            ShopFragment shopFragment2 = shopFragment;
                            Iterator<T> it = items.iterator();
                            while (it.hasNext()) {
                                arrayList.add(shopFragment2.equipmentRow((EquipmentItem) it.next(), playerState));
                            }
                            EnumEntries<BoostType> entries = BoostType.getEntries();
                            ShopFragment shopFragment3 = shopFragment;
                            Iterator<BoostType> it2 = entries.iterator();
                            while (it2.hasNext()) {
                                arrayList.add(shopFragment3.boostRow(it2.next(), playerState));
                            }
                            shopFragment.adapter.submitList(arrayList);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                }
                throw new KotlinNothingValueException();
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                LifecycleOwner viewLifecycleOwner = ShopFragment.this.getViewLifecycleOwner();
                Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
                this.label = 1;
                if (RepeatOnLifecycleKt.repeatOnLifecycle(viewLifecycleOwner, Lifecycle.State.STARTED, new AnonymousClass1(ShopFragment.this, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final MetaRow equipmentRow(final EquipmentItem item, PlayerState s) {
        String string;
        String string2;
        final boolean zOwns = s.owns(item.getId());
        boolean zAreEqual = Intrinsics.areEqual(s.equippedIn(item.getCategory()), item.getId());
        StatType bonusStat = item.getBonusStat();
        if (bonusStat == null || (string = getString(R.string.eq_bonus, Integer.valueOf((int) (item.getBonusPercent() * 100.0f)), getString(bonusStat.getLabelRes()))) == null) {
            string = "";
        }
        if (zAreEqual) {
            string2 = null;
        } else if (zOwns) {
            string2 = getString(R.string.eq_equip);
        } else {
            string2 = getString(R.string.eq_buy, Integer.valueOf(item.getCost()));
        }
        String str = string2;
        String str2 = "eq_" + item.getId();
        int iconRes = item.getCategory().getIconRes();
        int i = R.color.accent_light;
        String string3 = getString(item.getNameRes());
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        return new MetaRow(str2, iconRes, i, string3, getString(item.getCategory().getLabelRes()) + (string.length() > 0 ? "  •  " + string : ""), 0, 0, str, zOwns || s.getCoins() >= item.getCost(), null, zAreEqual, zOwns + "-" + zAreEqual + "-" + (s.getCoins() >= item.getCost()), new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ShopFragment.equipmentRow$lambda$2(zOwns, item, this);
            }
        }, TypedValues.MotionType.TYPE_DRAW_PATH, null);
    }

    static final Unit equipmentRow$lambda$2(boolean z, EquipmentItem equipmentItem, ShopFragment shopFragment) {
        if (z) {
            GameContainer.INSTANCE.getPlayer().equip(equipmentItem.getId());
            shopFragment.getAudio().play(Sfx.BUTTON);
        } else if (GameContainer.INSTANCE.getPlayer().buyEquipment(equipmentItem.getId())) {
            GameContainer.INSTANCE.getPlayer().equip(equipmentItem.getId());
            shopFragment.getAudio().play(Sfx.REWARD);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final MetaRow boostRow(final BoostType boost, PlayerState s) {
        boolean z;
        int iBoostCount = s.boostCount(boost.getId());
        String str = "boost_" + boost.getId();
        int iconRes = boost.getIconRes();
        int i = R.color.coin;
        String string = getString(boost.getLabelRes());
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String str2 = getString(boost.getDescRes()) + "  •  " + getString(R.string.owned_count, Integer.valueOf(iBoostCount));
        String string2 = getString(R.string.eq_buy, Integer.valueOf(boost.getCost()));
        boolean z2 = true;
        if (s.getCoins() >= boost.getCost()) {
            z = true;
        } else {
            z = true;
            z2 = false;
        }
        if (s.getCoins() < boost.getCost()) {
            z = false;
        }
        return new MetaRow(str, iconRes, i, string, str2, 0, 0, string2, z2, null, false, iBoostCount + "-" + z, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.meta.ShopFragment$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ShopFragment.boostRow$lambda$3(boost, this);
            }
        }, 1632, null);
    }

    static final Unit boostRow$lambda$3(BoostType boostType, ShopFragment shopFragment) {
        if (GameContainer.INSTANCE.getPlayer().buyBoost(boostType)) {
            shopFragment.getAudio().play(Sfx.REWARD);
        }
        return Unit.INSTANCE;
    }
}
