package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/CellExtra;", "", "<init>", "(Ljava/lang/String;I)V", "NONE", "COIN", "GOLD", "BOOSTER", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class CellExtra {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ CellExtra[] $VALUES;
    public static final CellExtra NONE = new CellExtra("NONE", 0);
    public static final CellExtra COIN = new CellExtra("COIN", 1);
    public static final CellExtra GOLD = new CellExtra("GOLD", 2);
    public static final CellExtra BOOSTER = new CellExtra("BOOSTER", 3);

    private static final /* synthetic */ CellExtra[] $values() {
        return new CellExtra[]{NONE, COIN, GOLD, BOOSTER};
    }

    public static EnumEntries<CellExtra> getEntries() {
        return $ENTRIES;
    }

    public static CellExtra valueOf(String str) {
        return (CellExtra) Enum.valueOf(CellExtra.class, str);
    }

    public static CellExtra[] values() {
        return (CellExtra[]) $VALUES.clone();
    }

    static {
        CellExtra[] cellExtraArr$values = $values();
        $VALUES = cellExtraArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(cellExtraArr$values);
    }

    private CellExtra(String str, int i) {
    }
}
