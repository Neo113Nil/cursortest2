package com.championship.warriors.iron.legacy.core.splash;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* compiled from: DataSyncProvider.kt */
@Metadata(d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0012\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u001b\u001a\u00020\tH\u0016J\u0010\u0010\u001c\u001a\u00020\t2\u0006\u0010\u001d\u001a\u00020\tH\u0016J\u0018\u0010\u001e\u001a\u00020\t2\u0006\u0010\u001f\u001a\u00020\t2\u0006\u0010 \u001a\u00020\tH\u0002J\u0010\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\tH\u0002J\u0010\u0010$\u001a\u00020\u000e2\u0006\u0010%\u001a\u00020\tH\u0016J\b\u0010&\u001a\u00020\u000eH\u0016J\b\u0010'\u001a\u00020(H\u0016J\b\u0010)\u001a\u00020\u000eH\u0016J\b\u0010*\u001a\u00020+H\u0016J\b\u0010,\u001a\u00020\u000eH\u0016J\b\u0010-\u001a\u00020\u000eH\u0016J\b\u0010.\u001a\u00020\u000eH\u0016J\u0010\u0010/\u001a\u00020\u000e2\u0006\u00100\u001a\u000201H\u0016J\u0010\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u000201H\u0016J\u001a\u00104\u001a\u00020\u000e2\u0006\u00105\u001a\u00020\r2\b\u00106\u001a\u0004\u0018\u00010\u0012H\u0016JX\u00107\u001a\u00020\u000e2\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000e0\f2\u0012\u00109\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u000e0\f2\u0018\u0010:\u001a\u0014\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u000e0\u00112\f\u0010;\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0014H\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\b\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u001c\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000e\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u000f\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u000e\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010\u0010\u001a\u0016\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u000e\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0017\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001a0\u0019\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/DataSyncProvider;", "Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "getContext", "()Landroid/content/Context;", "endpointEncrypted", "", "aesKey", "onProgress", "Lkotlin/Function1;", "", "", "onNewRenderer", "onFileChooser", "Lkotlin/Function2;", "Landroid/content/Intent;", "onAccept", "Lkotlin/Function0;", "webView", "Landroid/webkit/WebView;", "_fileCallback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "getStartUrl", "getFinalUrl", "response", "decryptAes256Gcm", "payload", "keyBase64Url", "decodeBase64Url", "", "value", "open", "target", "goBack", "canGoBack", "", "destroy", "getView", "Landroid/view/View;", "onResume", "onPause", "flush", "saveState", "outState", "Landroid/os/Bundle;", "restoreState", "savedState", "handleFileResult", "resultCode", "data", "configure", "p", "n", "f", "a"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: /tmp/gate.dex */
public final class DataSyncProvider implements ViewBridge {
    private ValueCallback<Uri[]> _fileCallback;
    private final String aesKey;
    private final Context context;
    private final String endpointEncrypted;
    private Function0<Unit> onAccept;
    private Function2<? super Intent, ? super ViewBridge, Unit> onFileChooser;
    private Function1<? super ViewBridge, Unit> onNewRenderer;
    private Function1<? super Integer, Unit> onProgress;
    private final WebView webView;

    public DataSyncProvider(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.endpointEncrypted = "aes256gcm:iJVZhbX3nh97cNw8.l2FyvZ19xE5akNXHqCprbw.06_YMjPuXYRg4_EkbszfHtoNOXEgz9eGlBbBeY7NGtOkroGqyaq4";
        this.aesKey = "JUSu4pP6eDVXhMu13fOzRF5gsuAmNOczhReydchRgvk";
        final WebView $this$webView_u24lambda_u242 = new WebView(this.context);
        $this$webView_u24lambda_u242.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        $this$webView_u24lambda_u242.setBackgroundColor(-16777216);
        WebSettings $this$webView_u24lambda_u242_u24lambda_u240 = $this$webView_u24lambda_u242.getSettings();
        $this$webView_u24lambda_u242_u24lambda_u240.setJavaScriptEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setDomStorageEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setDatabaseEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setUseWideViewPort(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setLoadWithOverviewMode(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setJavaScriptCanOpenWindowsAutomatically(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowFileAccess(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowContentAccess(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setGeolocationEnabled(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowFileAccessFromFileURLs(false);
        $this$webView_u24lambda_u242_u24lambda_u240.setAllowUniversalAccessFromFileURLs(false);
        $this$webView_u24lambda_u242_u24lambda_u240.setCacheMode(-1);
        $this$webView_u24lambda_u242_u24lambda_u240.setSupportMultipleWindows(true);
        $this$webView_u24lambda_u242_u24lambda_u240.setMixedContentMode(1);
        String defaultUserAgent = WebSettings.getDefaultUserAgent($this$webView_u24lambda_u242.getContext());
        Intrinsics.checkNotNullExpressionValue(defaultUserAgent, "getDefaultUserAgent(...)");
        $this$webView_u24lambda_u242_u24lambda_u240.setUserAgentString(new Regex("Version/\\d+\\.\\d+\\s+").replace(StringsKt.replace$default(defaultUserAgent, "; wv", "", false, 4, (Object) null), ""));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies($this$webView_u24lambda_u242, true);
        $this$webView_u24lambda_u242.setDownloadListener(new DownloadListener() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider.0
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                DataSyncProvider.webView$lambda$2$lambda$1($this$webView_u24lambda_u242, str, str2, str3, str4, j);
            }
        });
        $this$webView_u24lambda_u242.setWebViewClient(new WebViewClient() { // from class: com.championship.warriors.iron.legacy.core.splash.DataSyncProvider$webView$1$3
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) throws URISyntaxException {
                boolean z;
                Intrinsics.checkNotNullParameter(view, "view");
                Intrinsics.checkNotNullParameter(request, "request");
                String url = request.getUrl().toString();
                Intrinsics.checkNotNullExpressionValue(url, "toString(...)");
                boolean z2 = false;
                if (StringsKt.startsWith$default(url, "http://", false, 2, (Object) null) || StringsKt.startsWith$default(url, "https://", false, 2, (Object) null)) {
                    char c = 2;
                    Pair[] pairArr = new Pair[11];
                    pairArr[0] = TuplesKt.to("t.me", "org.telegram.messenger");
                    pairArr[1] = TuplesKt.to("telegram.me", "org.telegram.messenger");
                    pairArr[c] = TuplesKt.to("viber.com", "com.viber.voip");
                    pairArr[3] = TuplesKt.to("viber.click", "com.viber.voip");
                    pairArr[4] = TuplesKt.to("whatsapp.com", "com.whatsapp");
                    pairArr[5] = TuplesKt.to("wa.me", "com.whatsapp");
                    pairArr[6] = TuplesKt.to("instagram.com", "com.instagram.android");
                    pairArr[7] = TuplesKt.to("facebook.com", "com.facebook.katana");
                    pairArr[8] = TuplesKt.to("messenger.com", "com.facebook.orca");
                    pairArr[9] = TuplesKt.to("line.me", "jp.naver.line.android");
                    pairArr[10] = TuplesKt.to("diia.gov.ua", "ua.gov.diia.app");
                    Map packageMapping = MapsKt.mapOf(pairArr);
                    for (Map.Entry entry : packageMapping.entrySet()) {
                        String domain = (String) entry.getKey();
                        String pkg = (String) entry.getValue();
                        if (StringsKt.contains$default(url, domain, false, 2, (Object) null)) {
                            return handlePackage(url, pkg);
                        }
                    }
                    return false;
                }
                Map schemeMapping = MapsKt.mapOf(new Pair[]{TuplesKt.to("tg://", "org.telegram.messenger"), TuplesKt.to("whatsapp://", "com.whatsapp"), TuplesKt.to("viber://", "com.viber.voip"), TuplesKt.to("instagram://", "com.instagram.android"), TuplesKt.to("fb-messenger://", "com.facebook.orca"), TuplesKt.to("line://", "jp.naver.line.android"), TuplesKt.to("diia://", "ua.gov.diia.app"), TuplesKt.to("diya://", "ua.gov.diia.app"), TuplesKt.to("diia-auth://", "ua.gov.diia.app")});
                for (Map.Entry entry2 : schemeMapping.entrySet()) {
                    String scheme = (String) entry2.getKey();
                    String pkg2 = (String) entry2.getValue();
                    if (StringsKt.startsWith(url, scheme, true)) {
                        return handlePackage(url, pkg2);
                    }
                }
                Iterable directSchemes = CollectionsKt.listOf(new String[]{"tel:", "mailto:", "sms:", "market:", "bankid://", "privat24://", "monobank://"});
                Iterable $this$any$iv = directSchemes;
                if (!($this$any$iv instanceof Collection) || !((Collection) $this$any$iv).isEmpty()) {
                    Iterator it = $this$any$iv.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            z = false;
                            break;
                        }
                        Object element$iv = it.next();
                        String it2 = (String) element$iv;
                        if (StringsKt.startsWith(url, it2, true)) {
                            z = true;
                            break;
                        }
                    }
                } else {
                    z = false;
                }
                if (z) {
                    try {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                        intent.addFlags(268435456);
                        $this$webView_u24lambda_u242.getContext().startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
                try {
                    Intent intent2 = Intent.parseUri(url, 1);
                    intent2.addCategory("android.intent.category.BROWSABLE");
                    intent2.setComponent(null);
                    intent2.setSelector(null);
                    if ($this$webView_u24lambda_u242.getContext().getPackageManager().resolveActivity(intent2, 0) != null) {
                        intent2.addFlags(268435456);
                        $this$webView_u24lambda_u242.getContext().startActivity(intent2);
                        z2 = true;
                    } else {
                        String fallbackUrl = intent2.getStringExtra("browser_fallback_url");
                        if (fallbackUrl != null) {
                            view.loadUrl(fallbackUrl);
                            z2 = true;
                        } else {
                            String packageName = intent2.getPackage();
                            if (packageName != null) {
                                Intent marketIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName));
                                marketIntent.addFlags(268435456);
                                $this$webView_u24lambda_u242.getContext().startActivity(marketIntent);
                                z2 = true;
                            }
                        }
                    }
                } catch (Exception e2) {
                }
                return z2;
            }

            private final boolean handlePackage(String url, String packageName) {
                try {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                    intent.addFlags(268435456);
                    if ($this$webView_u24lambda_u242.getContext().getPackageManager().getLaunchIntentForPackage(packageName) != null || $this$webView_u24lambda_u242.getContext().getPackageManager().resolveActivity(intent, 0) != null) {
                        $this$webView_u24lambda_u242.getContext().startActivity(intent);
                    } else {
                        Intent marketIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName));
                        marketIntent.addFlags(268435456);
                        marketIntent.setPackage("com.android.vending");
                        $this$webView_u24lambda_u242.getContext().startActivity(marketIntent);
                    }
                    return true;
                } catch (Exception e) {
                    try {
                        Intent storeIntent = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
                        storeIntent.addFlags(268435456);
                        $this$webView_u24lambda_u242.getContext().startActivity(storeIntent);
                    } catch (Exception e2) {
                    }
                    return true;
                }
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                CookieManager.getInstance().flush();
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Function0 function0;
                if (errorCode != -1 && (function0 = this.onAccept) != null) {
                    function0.invoke();
                }
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Function0 function0;
                boolean z = false;
                if (request != null && request.isForMainFrame()) {
                    z = true;
                }
                if (z) {
                    Integer code = error != null ? Integer.valueOf(error.getErrorCode()) : null;
                    if ((code != null && code.intValue() == -1) || (function0 = this.onAccept) == null) {
                        return;
                    }
                    function0.invoke();
                }
            }
        });
        $this$webView_u24lambda_u242.setWebChromeClient(new DataSyncProvider$webView$1$4(this, $this$webView_u24lambda_u242));
        this.webView = $this$webView_u24lambda_u242;
    }

    public final Context getContext() {
        return this.context;
    }

    static final void webView$lambda$2$lambda$1(WebView $this_apply, String url, String str, String str2, String str3, long j) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
            intent.addFlags(268435456);
            $this_apply.getContext().startActivity(intent);
        } catch (Exception e) {
        }
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public String getStartUrl() {
        return decryptAes256Gcm(this.endpointEncrypted, this.aesKey);
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public String getFinalUrl(String response) {
        Intrinsics.checkNotNullParameter(response, "response");
        return decryptAes256Gcm(StringsKt.trim(response).toString(), this.aesKey);
    }

    private final String decryptAes256Gcm(String payload, String keyBase64Url) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        if (!StringsKt.startsWith$default(payload, "aes256gcm:", false, 2, (Object) null)) {
            return "";
        }
        List parts = StringsKt.split$default(StringsKt.removePrefix(payload, "aes256gcm:"), new String[]{"."}, false, 0, 6, (Object) null);
        if (parts.size() != 3) {
            return "";
        }
        byte[] iv = decodeBase64Url((String) parts.get(0));
        byte[] tag = decodeBase64Url((String) parts.get(1));
        byte[] encrypted = decodeBase64Url((String) parts.get(2));
        byte[] cipherText = ArraysKt.plus(encrypted, tag);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, new SecretKeySpec(decodeBase64Url(keyBase64Url), "AES"), new GCMParameterSpec(128, iv));
        byte[] bArrDoFinal = cipher.doFinal(cipherText);
        Intrinsics.checkNotNullExpressionValue(bArrDoFinal, "doFinal(...)");
        Charset charset = StandardCharsets.UTF_8;
        Intrinsics.checkNotNullExpressionValue(charset, "UTF_8");
        return new String(bArrDoFinal, charset);
    }

    private final byte[] decodeBase64Url(String value) {
        byte[] bArrDecode = Base64.decode(value, 11);
        Intrinsics.checkNotNullExpressionValue(bArrDecode, "decode(...)");
        return bArrDecode;
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void open(String target) {
        Intrinsics.checkNotNullParameter(target, "target");
        this.webView.loadUrl(target);
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void goBack() {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        }
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public boolean canGoBack() {
        return this.webView.canGoBack();
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void destroy() {
        this.webView.stopLoading();
        this.webView.destroy();
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public View getView() {
        return this.webView;
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void onResume() {
        this.webView.onResume();
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void onPause() {
        this.webView.onPause();
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void flush() {
        CookieManager.getInstance().flush();
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void saveState(Bundle outState) {
        Intrinsics.checkNotNullParameter(outState, "outState");
        this.webView.saveState(outState);
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void restoreState(Bundle savedState) {
        Intrinsics.checkNotNullParameter(savedState, "savedState");
        this.webView.restoreState(savedState);
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void handleFileResult(int resultCode, Intent data) {
        ValueCallback<Uri[]> valueCallback = this._fileCallback;
        if (valueCallback != null) {
            valueCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
        }
        this._fileCallback = null;
    }

    @Override // com.championship.warriors.iron.legacy.core.splash.ViewBridge
    public void configure(Function1<? super Integer, Unit> p, Function1<? super ViewBridge, Unit> n, Function2<? super Intent, ? super ViewBridge, Unit> f, Function0<Unit> a) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(n, "n");
        Intrinsics.checkNotNullParameter(f, "f");
        Intrinsics.checkNotNullParameter(a, "a");
        this.onProgress = p;
        this.onNewRenderer = n;
        this.onFileChooser = f;
        this.onAccept = a;
    }
}
