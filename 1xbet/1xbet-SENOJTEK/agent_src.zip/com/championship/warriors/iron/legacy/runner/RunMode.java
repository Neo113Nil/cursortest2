package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunMode;", "", "<init>", "(Ljava/lang/String;I)V", "CAREER", "ENDLESS", "TIME_TRIAL", "CHALLENGE", "TOURNAMENT", "TRAINING", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class RunMode {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ RunMode[] $VALUES;
    public static final RunMode CAREER = new RunMode("CAREER", 0);
    public static final RunMode ENDLESS = new RunMode("ENDLESS", 1);
    public static final RunMode TIME_TRIAL = new RunMode("TIME_TRIAL", 2);
    public static final RunMode CHALLENGE = new RunMode("CHALLENGE", 3);
    public static final RunMode TOURNAMENT = new RunMode("TOURNAMENT", 4);
    public static final RunMode TRAINING = new RunMode("TRAINING", 5);

    private static final /* synthetic */ RunMode[] $values() {
        return new RunMode[]{CAREER, ENDLESS, TIME_TRIAL, CHALLENGE, TOURNAMENT, TRAINING};
    }

    public static EnumEntries<RunMode> getEntries() {
        return $ENTRIES;
    }

    public static RunMode valueOf(String str) {
        return (RunMode) Enum.valueOf(RunMode.class, str);
    }

    public static RunMode[] values() {
        return (RunMode[]) $VALUES.clone();
    }

    static {
        RunMode[] runModeArr$values = $values();
        $VALUES = runModeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(runModeArr$values);
    }

    private RunMode(String str, int i) {
    }
}
