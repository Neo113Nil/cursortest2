package com.championship.warriors.iron.legacy.core.splash;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* compiled from: SplashActivity.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final /* synthetic */ class SplashActivity$_window$1$1 extends FunctionReferenceImpl implements Function1<Integer, Unit> {
    SplashActivity$_window$1$1(Object obj) {
        super(1, obj, SplashActivity.class, "_progress", "_progress(I)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
        invoke(num.intValue());
        return Unit.INSTANCE;
    }

    public final void invoke(int i) {
        ((SplashActivity) this.receiver)._progress(i);
    }
}
