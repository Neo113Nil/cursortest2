package com.championship.warriors.iron.legacy.presentation.tournament;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.TournamentCatalog;
import com.championship.warriors.iron.legacy.data.meta.TournamentDef;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentTournamentResultsBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import kotlin.Metadata;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: TournamentResultsFragment.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0006H\u0016¨\u0006\f"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/tournament/TournamentResultsFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentTournamentResultsBinding;", "<init>", "()V", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class TournamentResultsFragment extends BaseFragment<FragmentTournamentResultsBinding> {

    /* compiled from: TournamentResultsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.tournament.TournamentResultsFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentTournamentResultsBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentTournamentResultsBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentTournamentResultsBinding;", 0);
        }

        public final FragmentTournamentResultsBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentTournamentResultsBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentTournamentResultsBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public TournamentResultsFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        String string;
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        PlayerState playerStateCurrent = GameContainer.INSTANCE.getPlayer().current();
        TournamentDef tournamentDefById = TournamentCatalog.INSTANCE.byId(playerStateCurrent.getTournamentId());
        boolean z = tournamentDefById != null && playerStateCurrent.getTournamentRound() >= tournamentDefById.getRounds().size();
        getBinding().title.setText(z ? R.string.result_champion : R.string.result_eliminated);
        TextView textView = getBinding().subtitle;
        if (tournamentDefById == null || (string = getString(tournamentDefById.getNameRes())) == null) {
            string = "";
        }
        textView.setText(string);
        getBinding().titlesValue.setText(String.valueOf(playerStateCurrent.getTournamentTitles()));
        getBinding().bestRoundValue.setText(String.valueOf(playerStateCurrent.getBestTournamentRound()));
        getBinding().tournamentButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentResultsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                TournamentResultsFragment.onViewCreated$lambda$1(this.f$0, view2);
            }
        });
        getBinding().menuButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.tournament.TournamentResultsFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                TournamentResultsFragment.onViewCreated$lambda$2(this.f$0, view2);
            }
        });
        getAudio().play(z ? Sfx.VICTORY : Sfx.DEFEAT);
    }

    static final void onViewCreated$lambda$1(TournamentResultsFragment tournamentResultsFragment, View view) {
        tournamentResultsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(tournamentResultsFragment).navigate(R.id.action_global_to_tournament);
    }

    static final void onViewCreated$lambda$2(TournamentResultsFragment tournamentResultsFragment, View view) {
        tournamentResultsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(tournamentResultsFragment).navigate(R.id.action_global_to_menu);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }
}
