package com.championship.warriors.iron.legacy.core.splash;

import android.content.Intent;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: SplashActivity.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final /* synthetic */ class SplashActivity$_window$1$3 extends FunctionReferenceImpl implements Function2<Intent, ViewBridge, Unit> {
    SplashActivity$_window$1$3(Object obj) {
        super(2, obj, SplashActivity.class, "_file", "_file(Landroid/content/Intent;Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ Unit invoke(Intent intent, ViewBridge viewBridge) {
        invoke2(intent, viewBridge);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(Intent p0, ViewBridge p1) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        Intrinsics.checkNotNullParameter(p1, "p1");
        ((SplashActivity) this.receiver)._file(p0, p1);
    }
}
