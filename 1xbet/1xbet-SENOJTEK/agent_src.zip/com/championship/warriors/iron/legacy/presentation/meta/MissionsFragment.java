package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.navigation.fragment.FragmentKt;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.MissionCatalog;
import com.championship.warriors.iron.legacy.data.meta.MissionDef;
import com.championship.warriors.iron.legacy.data.meta.MissionMetric;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import com.championship.warriors.iron.legacy.databinding.FragmentListBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import com.championship.warriors.iron.legacy.presentation.common.MetaAdapter;
import com.championship.warriors.iron.legacy.presentation.common.MetaRow;
import com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.FlowCollector;

/* compiled from: MissionsFragment.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\b\u0010\r\u001a\u00020\bH\u0016J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/MissionsFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", "<init>", "()V", "adapter", "Lcom/championship/warriors/iron/legacy/presentation/common/MetaAdapter;", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "iconFor", "", "m", "Lcom/championship/warriors/iron/legacy/data/meta/MissionMetric;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MissionsFragment extends BaseFragment<FragmentListBinding> {
    private final MetaAdapter adapter;

    /* compiled from: MissionsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MissionMetric.values().length];
            try {
                iArr[MissionMetric.DISTANCE_TOTAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MissionMetric.COINS_TOTAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[MissionMetric.OBSTACLES_TOTAL.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[MissionMetric.POWERUPS_TOTAL.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[MissionMetric.RUNS_TOTAL.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[MissionMetric.TOKENS_TOTAL.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[MissionMetric.SURVIVE_SECONDS.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[MissionMetric.SCORE_SINGLE.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* compiled from: MissionsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentListBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentListBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentListBinding;", 0);
        }

        public final FragmentListBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentListBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentListBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public MissionsFragment() {
        super(AnonymousClass1.INSTANCE);
        this.adapter = new MetaAdapter();
    }

    public static final /* synthetic */ FragmentListBinding access$getBinding(MissionsFragment missionsFragment) {
        return missionsFragment.getBinding();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().title.setText(R.string.missions_title);
        getBinding().recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        getBinding().recycler.setAdapter(this.adapter);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                MissionsFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
        BuildersKt__Builders_commonKt.launch$default(LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner), null, null, new AnonymousClass2(null), 3, null);
    }

    static final void onViewCreated$lambda$0(MissionsFragment missionsFragment, View view) {
        missionsFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(missionsFragment).popBackStack();
    }

    /* compiled from: MissionsFragment.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2", f = "MissionsFragment.kt", i = {}, l = {33}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MissionsFragment.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: MissionsFragment.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        @DebugMetadata(c = "com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2$1", f = "MissionsFragment.kt", i = {}, l = {34}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ MissionsFragment this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass1(MissionsFragment missionsFragment, Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
                this.this$0 = missionsFragment;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass1(this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            /* compiled from: MissionsFragment.kt */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
            /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2$1$1, reason: invalid class name and collision with other inner class name */
            static final class C00151<T> implements FlowCollector {
                final /* synthetic */ MissionsFragment this$0;

                C00151(MissionsFragment missionsFragment) {
                    this.this$0 = missionsFragment;
                }

                @Override // kotlinx.coroutines.flow.FlowCollector
                public /* bridge */ /* synthetic */ Object emit(Object obj, Continuation continuation) {
                    return emit((PlayerState) obj, (Continuation<? super Unit>) continuation);
                }

                public final Object emit(PlayerState playerState, Continuation<? super Unit> continuation) {
                    PlayerState playerState2 = playerState;
                    MissionsFragment.access$getBinding(this.this$0).coinsValue.setText(String.valueOf(playerState2.getCoins()));
                    MetaAdapter metaAdapter = this.this$0.adapter;
                    List<MissionDef> missions = MissionCatalog.INSTANCE.getMissions();
                    final MissionsFragment missionsFragment = this.this$0;
                    ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(missions, 10));
                    Iterator<T> it = missions.iterator();
                    while (it.hasNext()) {
                        final MissionDef missionDef = (MissionDef) it.next();
                        int iCoerceAtMost = RangesKt.coerceAtMost(missionDef.progress(playerState2), missionDef.getTarget());
                        boolean zContains = playerState2.getMissionsClaimed().contains(missionDef.getId());
                        boolean z = missionDef.progress(playerState2) >= missionDef.getTarget();
                        String id = missionDef.getId();
                        int iIconFor = missionsFragment.iconFor(missionDef.getMetric());
                        int i = R.color.accent_light;
                        String string = missionsFragment.getString(missionDef.getLabelRes(), Boxing.boxInt(missionDef.getTarget()));
                        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                        Iterator<T> it2 = it;
                        String string2 = missionsFragment.getString(R.string.value_fraction, Boxing.boxInt(iCoerceAtMost), Boxing.boxInt(missionDef.getTarget()));
                        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                        arrayList.add(new MetaRow(id, iIconFor, i, string, string2, iCoerceAtMost, missionDef.getTarget(), (zContains || !z) ? null : missionsFragment.getString(R.string.mission_claim, Boxing.boxInt(missionDef.getRewardCoins())), true, null, zContains, iCoerceAtMost + "-" + zContains, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.meta.MissionsFragment$onViewCreated$2$1$1$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return MissionsFragment.AnonymousClass2.AnonymousClass1.C00151.emit$lambda$1$lambda$0(missionDef, missionsFragment);
                            }
                        }, 512, null));
                        it = it2;
                        playerState2 = playerState;
                    }
                    metaAdapter.submitList(arrayList);
                    return Unit.INSTANCE;
                }

                static final Unit emit$lambda$1$lambda$0(MissionDef missionDef, MissionsFragment missionsFragment) {
                    if (GameContainer.INSTANCE.getPlayer().claimMission(missionDef.getId())) {
                        missionsFragment.getAudio().play(Sfx.REWARD);
                    }
                    return Unit.INSTANCE;
                }
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    this.label = 1;
                    if (GameContainer.INSTANCE.getPlayer().getState().collect(new C00151(this.this$0), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                }
                throw new KotlinNothingValueException();
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                LifecycleOwner viewLifecycleOwner = MissionsFragment.this.getViewLifecycleOwner();
                Intrinsics.checkNotNullExpressionValue(viewLifecycleOwner, "getViewLifecycleOwner(...)");
                this.label = 1;
                if (RepeatOnLifecycleKt.repeatOnLifecycle(viewLifecycleOwner, Lifecycle.State.STARTED, new AnonymousClass1(MissionsFragment.this, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int iconFor(MissionMetric m) {
        switch (WhenMappings.$EnumSwitchMapping$0[m.ordinal()]) {
            case 1:
                return R.drawable.ic_flag;
            case 2:
                return R.drawable.ic_coin;
            case 3:
                return R.drawable.ic_shield;
            case 4:
                return R.drawable.ic_bolt;
            case 5:
                return R.drawable.ic_person;
            case 6:
                return R.drawable.ic_star;
            case 7:
                return R.drawable.ic_timer;
            case 8:
                return R.drawable.ic_stats;
            default:
                throw new NoWhenBranchMatchedException();
        }
    }
}
