package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;

/* loaded from: classes.dex */
public final class FragmentMainMenuBinding implements ViewBinding {
    public final MaterialButton careerButton;
    public final MaterialButton challengeButton;
    public final TextView coinsValue;
    public final MaterialButton endlessButton;
    public final TextView levelText;
    public final LinearLayout metaGrid;
    public final LinearLayout profileBadge;
    private final FrameLayout rootView;
    public final ImageButton settingsButton;
    public final MaterialButton timeTrialButton;
    public final MaterialButton tournamentButton;
    public final MaterialButton trainingButton;

    private FragmentMainMenuBinding(FrameLayout frameLayout, MaterialButton materialButton, MaterialButton materialButton2, TextView textView, MaterialButton materialButton3, TextView textView2, LinearLayout linearLayout, LinearLayout linearLayout2, ImageButton imageButton, MaterialButton materialButton4, MaterialButton materialButton5, MaterialButton materialButton6) {
        this.rootView = frameLayout;
        this.careerButton = materialButton;
        this.challengeButton = materialButton2;
        this.coinsValue = textView;
        this.endlessButton = materialButton3;
        this.levelText = textView2;
        this.metaGrid = linearLayout;
        this.profileBadge = linearLayout2;
        this.settingsButton = imageButton;
        this.timeTrialButton = materialButton4;
        this.tournamentButton = materialButton5;
        this.trainingButton = materialButton6;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentMainMenuBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentMainMenuBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_main_menu, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentMainMenuBinding bind(View view) {
        int i = R.id.careerButton;
        MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
        if (materialButton != null) {
            i = R.id.challengeButton;
            MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(view, i);
            if (materialButton2 != null) {
                i = R.id.coinsValue;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.endlessButton;
                    MaterialButton materialButton3 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                    if (materialButton3 != null) {
                        i = R.id.levelText;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView2 != null) {
                            i = R.id.metaGrid;
                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                            if (linearLayout != null) {
                                i = R.id.profileBadge;
                                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                if (linearLayout2 != null) {
                                    i = R.id.settingsButton;
                                    ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
                                    if (imageButton != null) {
                                        i = R.id.timeTrialButton;
                                        MaterialButton materialButton4 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                        if (materialButton4 != null) {
                                            i = R.id.tournamentButton;
                                            MaterialButton materialButton5 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                            if (materialButton5 != null) {
                                                i = R.id.trainingButton;
                                                MaterialButton materialButton6 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                                if (materialButton6 != null) {
                                                    return new FragmentMainMenuBinding((FrameLayout) view, materialButton, materialButton2, textView, materialButton3, textView2, linearLayout, linearLayout2, imageButton, materialButton4, materialButton5, materialButton6);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
