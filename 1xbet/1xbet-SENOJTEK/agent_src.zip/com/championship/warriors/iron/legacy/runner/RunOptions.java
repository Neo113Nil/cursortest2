package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.presentation.game.GameView;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b5\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001BÃ\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\f\u001a\u00020\u0005\u0012\b\b\u0002\u0010\r\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0010\u001a\u00020\n\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0015\u001a\u00020\u0016\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0013¢\u0006\u0004\b\u001a\u0010\u001bJ\t\u00104\u001a\u00020\u0003HÆ\u0003J\t\u00105\u001a\u00020\u0005HÆ\u0003J\t\u00106\u001a\u00020\u0005HÆ\u0003J\t\u00107\u001a\u00020\u0005HÆ\u0003J\t\u00108\u001a\u00020\u0005HÆ\u0003J\t\u00109\u001a\u00020\nHÆ\u0003J\t\u0010:\u001a\u00020\u0005HÆ\u0003J\t\u0010;\u001a\u00020\u0005HÆ\u0003J\t\u0010<\u001a\u00020\u0005HÆ\u0003J\t\u0010=\u001a\u00020\u0005HÆ\u0003J\t\u0010>\u001a\u00020\u0005HÆ\u0003J\t\u0010?\u001a\u00020\nHÆ\u0003J\t\u0010@\u001a\u00020\u0005HÆ\u0003J\t\u0010A\u001a\u00020\u0013HÆ\u0003J\t\u0010B\u001a\u00020\u0005HÆ\u0003J\t\u0010C\u001a\u00020\u0016HÆ\u0003J\t\u0010D\u001a\u00020\u0013HÆ\u0003J\t\u0010E\u001a\u00020\u0013HÆ\u0003J\t\u0010F\u001a\u00020\u0013HÆ\u0003JÇ\u0001\u0010G\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u00052\b\b\u0002\u0010\u0010\u001a\u00020\n2\b\b\u0002\u0010\u0011\u001a\u00020\u00052\b\b\u0002\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u00052\b\b\u0002\u0010\u0015\u001a\u00020\u00162\b\b\u0002\u0010\u0017\u001a\u00020\u00132\b\b\u0002\u0010\u0018\u001a\u00020\u00132\b\b\u0002\u0010\u0019\u001a\u00020\u0013HÆ\u0001J\u0013\u0010H\u001a\u00020\n2\b\u0010I\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010J\u001a\u00020\u0013HÖ\u0001J\t\u0010K\u001a\u00020LHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001fR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u001fR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u001fR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u001fR\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u001fR\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u001fR\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u001fR\u0011\u0010\u000f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001fR\u0011\u0010\u0010\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b*\u0010$R\u0011\u0010\u0011\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001fR\u0011\u0010\u0012\u001a\u00020\u0013¢\u0006\b\n\u0000\u001a\u0004\b,\u0010-R\u0011\u0010\u0014\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b.\u0010\u001fR\u0011\u0010\u0015\u001a\u00020\u0016¢\u0006\b\n\u0000\u001a\u0004\b/\u00100R\u0011\u0010\u0017\u001a\u00020\u0013¢\u0006\b\n\u0000\u001a\u0004\b1\u0010-R\u0011\u0010\u0018\u001a\u00020\u0013¢\u0006\b\n\u0000\u001a\u0004\b2\u0010-R\u0011\u0010\u0019\u001a\u00020\u0013¢\u0006\b\n\u0000\u001a\u0004\b3\u0010-¨\u0006M"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunOptions;", "", "mode", "Lcom/championship/warriors/iron/legacy/runner/RunMode;", "targetDistance", "", "timeLimit", "checkpointGap", "checkpointBonus", "practice", "", "controlMul", "agilityMul", "staminaMul", "rewardMul", "scoreMul", "startShield", "headStart", "revives", "", "coinMul", "theme", "Lcom/championship/warriors/iron/legacy/runner/RunTheme;", "jerseyColor", "ballColor", "trailColor", "<init>", "(Lcom/championship/warriors/iron/legacy/runner/RunMode;FFFFZFFFFFZFIFLcom/championship/warriors/iron/legacy/runner/RunTheme;III)V", "getMode", "()Lcom/championship/warriors/iron/legacy/runner/RunMode;", "getTargetDistance", "()F", "getTimeLimit", "getCheckpointGap", "getCheckpointBonus", "getPractice", "()Z", "getControlMul", "getAgilityMul", "getStaminaMul", "getRewardMul", "getScoreMul", "getStartShield", "getHeadStart", "getRevives", "()I", "getCoinMul", "getTheme", "()Lcom/championship/warriors/iron/legacy/runner/RunTheme;", "getJerseyColor", "getBallColor", "getTrailColor", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunOptions {
    private final float agilityMul;
    private final int ballColor;
    private final float checkpointBonus;
    private final float checkpointGap;
    private final float coinMul;
    private final float controlMul;
    private final float headStart;
    private final int jerseyColor;
    private final RunMode mode;
    private final boolean practice;
    private final int revives;
    private final float rewardMul;
    private final float scoreMul;
    private final float staminaMul;
    private final boolean startShield;
    private final float targetDistance;
    private final RunTheme theme;
    private final float timeLimit;
    private final int trailColor;

    public static /* synthetic */ RunOptions copy$default(RunOptions runOptions, RunMode runMode, float f, float f2, float f3, float f4, boolean z, float f5, float f6, float f7, float f8, float f9, boolean z2, float f10, int i, float f11, RunTheme runTheme, int i2, int i3, int i4, int i5, Object obj) {
        int i6;
        int i7;
        RunMode runMode2 = (i5 & 1) != 0 ? runOptions.mode : runMode;
        float f12 = (i5 & 2) != 0 ? runOptions.targetDistance : f;
        float f13 = (i5 & 4) != 0 ? runOptions.timeLimit : f2;
        float f14 = (i5 & 8) != 0 ? runOptions.checkpointGap : f3;
        float f15 = (i5 & 16) != 0 ? runOptions.checkpointBonus : f4;
        boolean z3 = (i5 & 32) != 0 ? runOptions.practice : z;
        float f16 = (i5 & 64) != 0 ? runOptions.controlMul : f5;
        float f17 = (i5 & 128) != 0 ? runOptions.agilityMul : f6;
        float f18 = (i5 & 256) != 0 ? runOptions.staminaMul : f7;
        float f19 = (i5 & 512) != 0 ? runOptions.rewardMul : f8;
        float f20 = (i5 & 1024) != 0 ? runOptions.scoreMul : f9;
        boolean z4 = (i5 & 2048) != 0 ? runOptions.startShield : z2;
        float f21 = (i5 & 4096) != 0 ? runOptions.headStart : f10;
        int i8 = (i5 & 8192) != 0 ? runOptions.revives : i;
        RunMode runMode3 = runMode2;
        float f22 = (i5 & 16384) != 0 ? runOptions.coinMul : f11;
        RunTheme runTheme2 = (i5 & 32768) != 0 ? runOptions.theme : runTheme;
        int i9 = (i5 & 65536) != 0 ? runOptions.jerseyColor : i2;
        int i10 = (i5 & 131072) != 0 ? runOptions.ballColor : i3;
        if ((i5 & 262144) != 0) {
            i7 = i10;
            i6 = runOptions.trailColor;
        } else {
            i6 = i4;
            i7 = i10;
        }
        return runOptions.copy(runMode3, f12, f13, f14, f15, z3, f16, f17, f18, f19, f20, z4, f21, i8, f22, runTheme2, i9, i7, i6);
    }

    /* renamed from: component1, reason: from getter */
    public final RunMode getMode() {
        return this.mode;
    }

    /* renamed from: component10, reason: from getter */
    public final float getRewardMul() {
        return this.rewardMul;
    }

    /* renamed from: component11, reason: from getter */
    public final float getScoreMul() {
        return this.scoreMul;
    }

    /* renamed from: component12, reason: from getter */
    public final boolean getStartShield() {
        return this.startShield;
    }

    /* renamed from: component13, reason: from getter */
    public final float getHeadStart() {
        return this.headStart;
    }

    /* renamed from: component14, reason: from getter */
    public final int getRevives() {
        return this.revives;
    }

    /* renamed from: component15, reason: from getter */
    public final float getCoinMul() {
        return this.coinMul;
    }

    /* renamed from: component16, reason: from getter */
    public final RunTheme getTheme() {
        return this.theme;
    }

    /* renamed from: component17, reason: from getter */
    public final int getJerseyColor() {
        return this.jerseyColor;
    }

    /* renamed from: component18, reason: from getter */
    public final int getBallColor() {
        return this.ballColor;
    }

    /* renamed from: component19, reason: from getter */
    public final int getTrailColor() {
        return this.trailColor;
    }

    /* renamed from: component2, reason: from getter */
    public final float getTargetDistance() {
        return this.targetDistance;
    }

    /* renamed from: component3, reason: from getter */
    public final float getTimeLimit() {
        return this.timeLimit;
    }

    /* renamed from: component4, reason: from getter */
    public final float getCheckpointGap() {
        return this.checkpointGap;
    }

    /* renamed from: component5, reason: from getter */
    public final float getCheckpointBonus() {
        return this.checkpointBonus;
    }

    /* renamed from: component6, reason: from getter */
    public final boolean getPractice() {
        return this.practice;
    }

    /* renamed from: component7, reason: from getter */
    public final float getControlMul() {
        return this.controlMul;
    }

    /* renamed from: component8, reason: from getter */
    public final float getAgilityMul() {
        return this.agilityMul;
    }

    /* renamed from: component9, reason: from getter */
    public final float getStaminaMul() {
        return this.staminaMul;
    }

    public final RunOptions copy(RunMode mode, float targetDistance, float timeLimit, float checkpointGap, float checkpointBonus, boolean practice, float controlMul, float agilityMul, float staminaMul, float rewardMul, float scoreMul, boolean startShield, float headStart, int revives, float coinMul, RunTheme theme, int jerseyColor, int ballColor, int trailColor) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        Intrinsics.checkNotNullParameter(theme, "theme");
        return new RunOptions(mode, targetDistance, timeLimit, checkpointGap, checkpointBonus, practice, controlMul, agilityMul, staminaMul, rewardMul, scoreMul, startShield, headStart, revives, coinMul, theme, jerseyColor, ballColor, trailColor);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunOptions)) {
            return false;
        }
        RunOptions runOptions = (RunOptions) other;
        return this.mode == runOptions.mode && Float.compare(this.targetDistance, runOptions.targetDistance) == 0 && Float.compare(this.timeLimit, runOptions.timeLimit) == 0 && Float.compare(this.checkpointGap, runOptions.checkpointGap) == 0 && Float.compare(this.checkpointBonus, runOptions.checkpointBonus) == 0 && this.practice == runOptions.practice && Float.compare(this.controlMul, runOptions.controlMul) == 0 && Float.compare(this.agilityMul, runOptions.agilityMul) == 0 && Float.compare(this.staminaMul, runOptions.staminaMul) == 0 && Float.compare(this.rewardMul, runOptions.rewardMul) == 0 && Float.compare(this.scoreMul, runOptions.scoreMul) == 0 && this.startShield == runOptions.startShield && Float.compare(this.headStart, runOptions.headStart) == 0 && this.revives == runOptions.revives && Float.compare(this.coinMul, runOptions.coinMul) == 0 && Intrinsics.areEqual(this.theme, runOptions.theme) && this.jerseyColor == runOptions.jerseyColor && this.ballColor == runOptions.ballColor && this.trailColor == runOptions.trailColor;
    }

    public int hashCode() {
        return (((((((((((((((((((((((((((((((((((this.mode.hashCode() * 31) + Float.hashCode(this.targetDistance)) * 31) + Float.hashCode(this.timeLimit)) * 31) + Float.hashCode(this.checkpointGap)) * 31) + Float.hashCode(this.checkpointBonus)) * 31) + Boolean.hashCode(this.practice)) * 31) + Float.hashCode(this.controlMul)) * 31) + Float.hashCode(this.agilityMul)) * 31) + Float.hashCode(this.staminaMul)) * 31) + Float.hashCode(this.rewardMul)) * 31) + Float.hashCode(this.scoreMul)) * 31) + Boolean.hashCode(this.startShield)) * 31) + Float.hashCode(this.headStart)) * 31) + Integer.hashCode(this.revives)) * 31) + Float.hashCode(this.coinMul)) * 31) + this.theme.hashCode()) * 31) + Integer.hashCode(this.jerseyColor)) * 31) + Integer.hashCode(this.ballColor)) * 31) + Integer.hashCode(this.trailColor);
    }

    public String toString() {
        return "RunOptions(mode=" + this.mode + ", targetDistance=" + this.targetDistance + ", timeLimit=" + this.timeLimit + ", checkpointGap=" + this.checkpointGap + ", checkpointBonus=" + this.checkpointBonus + ", practice=" + this.practice + ", controlMul=" + this.controlMul + ", agilityMul=" + this.agilityMul + ", staminaMul=" + this.staminaMul + ", rewardMul=" + this.rewardMul + ", scoreMul=" + this.scoreMul + ", startShield=" + this.startShield + ", headStart=" + this.headStart + ", revives=" + this.revives + ", coinMul=" + this.coinMul + ", theme=" + this.theme + ", jerseyColor=" + this.jerseyColor + ", ballColor=" + this.ballColor + ", trailColor=" + this.trailColor + ")";
    }

    public RunOptions(RunMode mode, float f, float f2, float f3, float f4, boolean z, float f5, float f6, float f7, float f8, float f9, boolean z2, float f10, int i, float f11, RunTheme theme, int i2, int i3, int i4) {
        Intrinsics.checkNotNullParameter(mode, "mode");
        Intrinsics.checkNotNullParameter(theme, "theme");
        this.mode = mode;
        this.targetDistance = f;
        this.timeLimit = f2;
        this.checkpointGap = f3;
        this.checkpointBonus = f4;
        this.practice = z;
        this.controlMul = f5;
        this.agilityMul = f6;
        this.staminaMul = f7;
        this.rewardMul = f8;
        this.scoreMul = f9;
        this.startShield = z2;
        this.headStart = f10;
        this.revives = i;
        this.coinMul = f11;
        this.theme = theme;
        this.jerseyColor = i2;
        this.ballColor = i3;
        this.trailColor = i4;
    }

    public final RunMode getMode() {
        return this.mode;
    }

    public final float getTargetDistance() {
        return this.targetDistance;
    }

    public final float getTimeLimit() {
        return this.timeLimit;
    }

    public final float getCheckpointGap() {
        return this.checkpointGap;
    }

    public final float getCheckpointBonus() {
        return this.checkpointBonus;
    }

    public final boolean getPractice() {
        return this.practice;
    }

    public final float getControlMul() {
        return this.controlMul;
    }

    public final float getAgilityMul() {
        return this.agilityMul;
    }

    public final float getStaminaMul() {
        return this.staminaMul;
    }

    public final float getRewardMul() {
        return this.rewardMul;
    }

    public final float getScoreMul() {
        return this.scoreMul;
    }

    public final boolean getStartShield() {
        return this.startShield;
    }

    public final float getHeadStart() {
        return this.headStart;
    }

    public final int getRevives() {
        return this.revives;
    }

    public final float getCoinMul() {
        return this.coinMul;
    }

    public /* synthetic */ RunOptions(RunMode runMode, float f, float f2, float f3, float f4, boolean z, float f5, float f6, float f7, float f8, float f9, boolean z2, float f10, int i, float f11, RunTheme runTheme, int i2, int i3, int i4, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this(runMode, (i5 & 2) != 0 ? 0.0f : f, (i5 & 4) != 0 ? 0.0f : f2, (i5 & 8) != 0 ? 0.0f : f3, (i5 & 16) != 0 ? 0.0f : f4, (i5 & 32) != 0 ? false : z, (i5 & 64) != 0 ? 1.0f : f5, (i5 & 128) != 0 ? 1.0f : f6, (i5 & 256) != 0 ? 1.0f : f7, (i5 & 512) != 0 ? 1.0f : f8, (i5 & 1024) != 0 ? 1.0f : f9, (i5 & 2048) != 0 ? false : z2, (i5 & 4096) == 0 ? f10 : 0.0f, (i5 & 8192) == 0 ? i : 0, (i5 & 16384) == 0 ? f11 : 1.0f, (32768 & i5) != 0 ? RunTheme.INSTANCE.getCITY() : runTheme, (i5 & 65536) != 0 ? -12747777 : i2, (i5 & 131072) != 0 ? GameView.COL_WHITE : i3, (i5 & 262144) != 0 ? -14032656 : i4);
    }

    public final RunTheme getTheme() {
        return this.theme;
    }

    public final int getJerseyColor() {
        return this.jerseyColor;
    }

    public final int getBallColor() {
        return this.ballColor;
    }

    public final int getTrailColor() {
        return this.trailColor;
    }
}
