package com.championship.warriors.iron.legacy.data;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: SettingsRepository.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013J\u000e\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013J\b\u0010\u0015\u001a\u00020\u000bH\u0002R\u0016\u0010\u0006\u001a\n \b*\u0004\u0018\u00010\u00070\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\r¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0017"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/SettingsRepository;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "_settings", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/championship/warriors/iron/legacy/data/GameSettings;", "settings", "Lkotlinx/coroutines/flow/StateFlow;", "getSettings", "()Lkotlinx/coroutines/flow/StateFlow;", "setMusic", "", "enabled", "", "setSfx", "load", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class SettingsRepository {
    private static final String KEY_MUSIC = "music";
    private static final String KEY_SFX = "sfx";
    private static final String PREFS = "vr_settings";
    private final MutableStateFlow<GameSettings> _settings;
    private final SharedPreferences prefs;
    private final StateFlow<GameSettings> settings;

    public SettingsRepository(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.prefs = context.getApplicationContext().getSharedPreferences(PREFS, 0);
        MutableStateFlow<GameSettings> MutableStateFlow = StateFlowKt.MutableStateFlow(load());
        this._settings = MutableStateFlow;
        this.settings = FlowKt.asStateFlow(MutableStateFlow);
    }

    public final StateFlow<GameSettings> getSettings() {
        return this.settings;
    }

    public final void setMusic(boolean enabled) {
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putBoolean(KEY_MUSIC, enabled);
        editorEdit.apply();
        this._settings.setValue(load());
    }

    public final void setSfx(boolean enabled) {
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putBoolean(KEY_SFX, enabled);
        editorEdit.apply();
        this._settings.setValue(load());
    }

    private final GameSettings load() {
        return new GameSettings(this.prefs.getBoolean(KEY_MUSIC, true), this.prefs.getBoolean(KEY_SFX, true));
    }
}
