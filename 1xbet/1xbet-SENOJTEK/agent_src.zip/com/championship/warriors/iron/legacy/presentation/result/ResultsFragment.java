package com.championship.warriors.iron.legacy.presentation.result;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.os.BundleKt;
import androidx.core.widget.ImageViewCompat;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.databinding.FragmentResultsBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ResultsFragment.kt */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0006H\u0016J\b\u0010\u0018\u001a\u00020\u0014H\u0016J\b\u0010\u0019\u001a\u00020\u0014H\u0002J\u0010\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\u001cH\u0002J\b\u0010\u001d\u001a\u00020\u0014H\u0002J\u001e\u0010\u001e\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020\u001c2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00140!H\u0002J\u001e\u0010\"\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020\u001c2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00140!H\u0002J\u001e\u0010#\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020\u001c2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00140!H\u0002J\b\u0010$\u001a\u00020\u0014H\u0002J\b\u0010%\u001a\u00020\u0014H\u0002J&\u0010&\u001a\u00020\u00142\u0006\u0010'\u001a\u00020(2\u0006\u0010\u001f\u001a\u00020\u001c2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00140!H\u0002J\u0010\u0010)\u001a\u00020\u00142\u0006\u0010 \u001a\u00020\u001cH\u0002J\u0010\u0010*\u001a\u00020\u00142\u0006\u0010+\u001a\u00020\u0006H\u0002J\u0010\u0010,\u001a\u00020\u00142\u0006\u0010-\u001a\u00020\u001cH\u0002J\u0010\u0010.\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\nH\u0002J\u0010\u0010/\u001a\u00020\u00142\u0006\u00100\u001a\u00020\nH\u0002R\u0014\u0010\u0005\u001a\u00020\u00068BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\n8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u0014\u0010\r\u001a\u00020\u000e8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0011\u001a\u00020\u000e8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0010¨\u00061"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/result/ResultsFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentResultsBinding;", "<init>", "()V", "a", "Landroid/os/Bundle;", "getA", "()Landroid/os/Bundle;", "mode", "", "getMode", "()Ljava/lang/String;", "victory", "", "getVictory", "()Z", "timedOut", "getTimedOut", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "onStart", "configureForMode", "showStars", "stars", "", "animateIn", "primary", "text", "action", "Lkotlin/Function0;", "secondary", "ghost", "hideSecondary", "hideGhost", "wire", "button", "Landroid/widget/Button;", "nav", "launchRun", "bundle", "launchCareer", "stageId", "launchSimple", "launchChallenge", "id", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ResultsFragment extends BaseFragment<FragmentResultsBinding> {
    private final void animateIn() {
    }

    /* compiled from: ResultsFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentResultsBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentResultsBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentResultsBinding;", 0);
        }

        public final FragmentResultsBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentResultsBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentResultsBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public ResultsFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    private final Bundle getA() {
        Bundle bundleRequireArguments = requireArguments();
        Intrinsics.checkNotNullExpressionValue(bundleRequireArguments, "requireArguments(...)");
        return bundleRequireArguments;
    }

    private final String getMode() {
        String string = getA().getString("mode");
        return string == null ? "CAREER" : string;
    }

    private final boolean getVictory() {
        return getA().getBoolean("victory");
    }

    private final boolean getTimedOut() {
        return getA().getBoolean("timedOut");
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().scoreValue.setText(String.valueOf(getA().getInt("score")));
        getBinding().distanceValue.setText(getString(R.string.value_meters, Integer.valueOf(getA().getInt("distance"))));
        getBinding().coinsValue.setText(String.valueOf(getA().getInt("coins")));
        getBinding().xpText.setText(getString(R.string.xp_gained, Integer.valueOf(getA().getInt("xpGained"))));
        getBinding().newBestBadge.setVisibility(getA().getBoolean("newBest") ? 0 : 8);
        if (getA().getBoolean("leveledUp")) {
            getBinding().levelUpBadge.setVisibility(0);
            getBinding().levelUpBadge.setText(getString(R.string.level_up, Integer.valueOf(getA().getInt("newLevel"))));
        }
        configureForMode();
        animateIn();
        MaterialCardView materialCardView = getBinding().card;
        materialCardView.setAlpha(0.0f);
        materialCardView.setScaleX(0.9f);
        materialCardView.setScaleY(0.9f);
        materialCardView.animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setDuration(380L).start();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x01c3, code lost:
    
        if (r0.equals("ENDLESS") == false) goto L109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x01ca, code lost:
    
        if (r0.equals("TIME_TRIAL") == false) goto L109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x01cd, code lost:
    
        primary(com.championship.warriors.iron.legacy.R.string.retry, new com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda12(r9));
        secondary(com.championship.warriors.iron.legacy.R.string.to_menu, new com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda1(r9));
        hideGhost();
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue
    java.lang.NullPointerException: Cannot invoke "java.util.List.iterator()" because the return value of "jadx.core.dex.visitors.regions.SwitchOverStringVisitor$SwitchData.getNewCases()" is null
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(SwitchOverStringVisitor.java:109)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(SwitchOverStringVisitor.java:66)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:77)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:82)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterative(DepthRegionTraversal.java:31)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visit(SwitchOverStringVisitor.java:60)
     */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00f2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void configureForMode() {
        boolean victory;
        int i;
        String mode = getMode();
        switch (mode.hashCode()) {
            case -1756907772:
                if (!mode.equals("TIME_TRIAL")) {
                    victory = true;
                    break;
                } else {
                    victory = getVictory();
                    break;
                }
            case -510900759:
                if (mode.equals("TOURNAMENT")) {
                    victory = getA().getBoolean("tournamentQualified");
                    break;
                }
                break;
            case -105739197:
                if (mode.equals("CHALLENGE")) {
                    victory = getA().getBoolean("challengePassed");
                    break;
                }
                break;
            case 1980693374:
                if (!mode.equals("CAREER")) {
                }
                break;
        }
        getAudio().play(victory ? Sfx.VICTORY : Sfx.DEFEAT);
        String mode2 = getMode();
        switch (mode2.hashCode()) {
            case -1756907772:
                if (!mode2.equals("TIME_TRIAL")) {
                    i = R.string.result_complete;
                    break;
                } else if (!getVictory()) {
                    if (!getTimedOut()) {
                        i = R.string.result_crash;
                        break;
                    } else {
                        i = R.string.result_timeup;
                        break;
                    }
                } else {
                    i = R.string.result_victory;
                    break;
                }
            case -888549164:
                if (mode2.equals("ENDLESS")) {
                    i = R.string.result_complete;
                    break;
                }
                break;
            case -510900759:
                if (mode2.equals("TOURNAMENT")) {
                    if (!getA().getBoolean("tournamentQualified")) {
                        i = R.string.result_eliminated;
                        break;
                    } else if (!getA().getBoolean("tournamentFinal")) {
                        i = R.string.result_qualified;
                        break;
                    } else {
                        i = R.string.result_champion;
                        break;
                    }
                }
                break;
            case -105739197:
                if (mode2.equals("CHALLENGE")) {
                    if (!getA().getBoolean("challengePassed")) {
                        i = R.string.result_challenge_fail;
                        break;
                    } else {
                        i = R.string.result_challenge_pass;
                        break;
                    }
                }
                break;
            case 1980693374:
                if (mode2.equals("CAREER")) {
                    if (!getA().getBoolean("finalVictory")) {
                        if (!getVictory()) {
                            i = R.string.result_crash;
                            break;
                        } else {
                            i = R.string.result_victory;
                            break;
                        }
                    } else {
                        i = R.string.result_champion;
                        break;
                    }
                }
                break;
        }
        getBinding().resultTitle.setText(i);
        if (Intrinsics.areEqual(getMode(), "CAREER") && getVictory()) {
            showStars(getA().getInt("stars"));
        }
        String mode3 = getMode();
        switch (mode3.hashCode()) {
            case -1756907772:
                break;
            case -888549164:
                break;
            case -510900759:
                if (mode3.equals("TOURNAMENT")) {
                    primary(R.string.result_continue, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return ResultsFragment.configureForMode$lambda$11(this.f$0);
                        }
                    });
                    hideSecondary();
                    hideGhost();
                    break;
                }
                primary(R.string.to_menu, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ResultsFragment.configureForMode$lambda$12(this.f$0);
                    }
                });
                hideSecondary();
                hideGhost();
                break;
            case -105739197:
                if (mode3.equals("CHALLENGE")) {
                    primary(R.string.retry, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return ResultsFragment.configureForMode$lambda$9(this.f$0);
                        }
                    });
                    secondary(R.string.to_challenges, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return ResultsFragment.configureForMode$lambda$10(this.f$0);
                        }
                    });
                    hideGhost();
                    break;
                }
                primary(R.string.to_menu, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ResultsFragment.configureForMode$lambda$12(this.f$0);
                    }
                });
                hideSecondary();
                hideGhost();
                break;
            case 1980693374:
                if (mode3.equals("CAREER")) {
                    if (!getVictory()) {
                        primary(R.string.retry, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ResultsFragment.configureForMode$lambda$5(this.f$0);
                            }
                        });
                        secondary(R.string.to_career, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ResultsFragment.configureForMode$lambda$6(this.f$0);
                            }
                        });
                        hideGhost();
                        break;
                    } else {
                        if (getA().getBoolean("careerAdvanced")) {
                            primary(R.string.next_stage, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda4
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return ResultsFragment.configureForMode$lambda$1(this.f$0);
                                }
                            });
                            secondary(R.string.result_replay, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda7
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return ResultsFragment.configureForMode$lambda$2(this.f$0);
                                }
                            });
                        } else {
                            primary(R.string.result_replay, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda8
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return ResultsFragment.configureForMode$lambda$3(this.f$0);
                                }
                            });
                            hideSecondary();
                        }
                        ghost(R.string.to_career, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return ResultsFragment.configureForMode$lambda$4(this.f$0);
                            }
                        });
                        break;
                    }
                }
                primary(R.string.to_menu, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ResultsFragment.configureForMode$lambda$12(this.f$0);
                    }
                });
                hideSecondary();
                hideGhost();
                break;
            default:
                primary(R.string.to_menu, new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ResultsFragment.configureForMode$lambda$12(this.f$0);
                    }
                });
                hideSecondary();
                hideGhost();
                break;
        }
    }

    static final Unit configureForMode$lambda$1(ResultsFragment resultsFragment) {
        resultsFragment.launchCareer(resultsFragment.getA().getInt("nextStageId"));
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$2(ResultsFragment resultsFragment) {
        resultsFragment.launchCareer(resultsFragment.getA().getInt("stageId"));
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$3(ResultsFragment resultsFragment) {
        resultsFragment.launchCareer(resultsFragment.getA().getInt("stageId"));
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$4(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_career);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$5(ResultsFragment resultsFragment) {
        resultsFragment.launchCareer(resultsFragment.getA().getInt("stageId"));
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$6(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_career);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$7(ResultsFragment resultsFragment) {
        resultsFragment.launchSimple(resultsFragment.getMode());
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$8(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_menu);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$9(ResultsFragment resultsFragment) {
        String string = resultsFragment.getA().getString("challengeId");
        if (string == null) {
            string = "";
        }
        resultsFragment.launchChallenge(string);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$10(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_challenges);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$11(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_tournament);
        return Unit.INSTANCE;
    }

    static final Unit configureForMode$lambda$12(ResultsFragment resultsFragment) {
        resultsFragment.nav(R.id.action_global_to_menu);
        return Unit.INSTANCE;
    }

    private final void showStars(int stars) {
        int i = 0;
        getBinding().starsRow.setVisibility(0);
        for (Object obj : CollectionsKt.listOf((Object[]) new ImageView[]{getBinding().star1, getBinding().star2, getBinding().star3})) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            ImageViewCompat.setImageTintList((ImageView) obj, ColorStateList.valueOf(ContextCompat.getColor(requireContext(), i < stars ? R.color.star_on : R.color.star_off)));
            i = i2;
        }
    }

    private final void primary(int text, Function0<Unit> action) {
        MaterialButton primaryButton = getBinding().primaryButton;
        Intrinsics.checkNotNullExpressionValue(primaryButton, "primaryButton");
        wire(primaryButton, text, action);
    }

    private final void secondary(int text, Function0<Unit> action) {
        MaterialButton secondaryButton = getBinding().secondaryButton;
        Intrinsics.checkNotNullExpressionValue(secondaryButton, "secondaryButton");
        wire(secondaryButton, text, action);
    }

    private final void ghost(int text, Function0<Unit> action) {
        MaterialButton ghostButton = getBinding().ghostButton;
        Intrinsics.checkNotNullExpressionValue(ghostButton, "ghostButton");
        wire(ghostButton, text, action);
    }

    private final void hideSecondary() {
        getBinding().secondaryButton.setVisibility(8);
    }

    private final void hideGhost() {
        getBinding().ghostButton.setVisibility(8);
    }

    private final void wire(Button button, int text, final Function0<Unit> action) {
        button.setVisibility(0);
        button.setText(text);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.result.ResultsFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ResultsFragment.wire$lambda$14(this.f$0, action, view);
            }
        });
    }

    static final void wire$lambda$14(ResultsFragment resultsFragment, Function0 function0, View view) {
        resultsFragment.getAudio().play(Sfx.BUTTON);
        function0.invoke();
    }

    private final void nav(int action) {
        FragmentKt.findNavController(this).navigate(action);
    }

    private final void launchRun(Bundle bundle) {
        ResultsFragment resultsFragment = this;
        FragmentKt.findNavController(resultsFragment).popBackStack();
        FragmentKt.findNavController(resultsFragment).navigate(R.id.action_global_open_run, bundle);
    }

    private final void launchCareer(int stageId) {
        launchRun(BundleKt.bundleOf(TuplesKt.to("mode", "CAREER"), TuplesKt.to("stageId", Integer.valueOf(stageId)), TuplesKt.to("challengeId", ""), TuplesKt.to("tournamentId", "")));
    }

    private final void launchSimple(String mode) {
        launchRun(BundleKt.bundleOf(TuplesKt.to("mode", mode), TuplesKt.to("stageId", 1), TuplesKt.to("challengeId", ""), TuplesKt.to("tournamentId", "")));
    }

    private final void launchChallenge(String id) {
        launchRun(BundleKt.bundleOf(TuplesKt.to("mode", "CHALLENGE"), TuplesKt.to("stageId", 1), TuplesKt.to("challengeId", id), TuplesKt.to("tournamentId", "")));
    }
}
