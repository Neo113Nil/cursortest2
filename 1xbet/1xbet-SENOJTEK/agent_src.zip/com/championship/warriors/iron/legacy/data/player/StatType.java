package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import java.util.Map;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: StatType.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0011\b\u0086\u0081\u0002\u0018\u0000 \u00132\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0013B'\b\u0002\u0012\b\b\u0001\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0012\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010¨\u0006\u0014"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/StatType;", "", "labelRes", "", "descRes", "iconRes", "<init>", "(Ljava/lang/String;IIII)V", "getLabelRes", "()I", "getDescRes", "getIconRes", "SPEED", "CONTROL", "STAMINA", "AGILITY", "REWARD", "upgradeCost", "currentLevel", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class StatType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ StatType[] $VALUES;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE;
    public static final int MAX_LEVEL = 8;
    private final int descRes;
    private final int iconRes;
    private final int labelRes;
    public static final StatType SPEED = new StatType("SPEED", 0, R.string.stat_speed, R.string.stat_speed_desc, R.drawable.ic_bolt);
    public static final StatType CONTROL = new StatType("CONTROL", 1, R.string.stat_control, R.string.stat_control_desc, R.drawable.ic_control);
    public static final StatType STAMINA = new StatType("STAMINA", 2, R.string.stat_stamina, R.string.stat_stamina_desc, R.drawable.ic_heart);
    public static final StatType AGILITY = new StatType("AGILITY", 3, R.string.stat_agility, R.string.stat_agility_desc, R.drawable.ic_agility);
    public static final StatType REWARD = new StatType("REWARD", 4, R.string.stat_reward, R.string.stat_reward_desc, R.drawable.ic_coin);

    private static final /* synthetic */ StatType[] $values() {
        return new StatType[]{SPEED, CONTROL, STAMINA, AGILITY, REWARD};
    }

    public static EnumEntries<StatType> getEntries() {
        return $ENTRIES;
    }

    public static StatType valueOf(String str) {
        return (StatType) Enum.valueOf(StatType.class, str);
    }

    public static StatType[] values() {
        return (StatType[]) $VALUES.clone();
    }

    public final int upgradeCost(int currentLevel) {
        return ((currentLevel - 1) * 90) + 120;
    }

    private StatType(String str, int i, int i2, int i3, int i4) {
        this.labelRes = i2;
        this.descRes = i3;
        this.iconRes = i4;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    public final int getDescRes() {
        return this.descRes;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    static {
        StatType[] statTypeArr$values = $values();
        $VALUES = statTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(statTypeArr$values);
        INSTANCE = new Companion(null);
    }

    /* compiled from: StatType.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001a\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00050\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/StatType$Companion;", "", "<init>", "()V", "MAX_LEVEL", "", "compute", "Lcom/championship/warriors/iron/legacy/data/player/StatModifiers;", "levels", "", "Lcom/championship/warriors/iron/legacy/data/player/StatType;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        private static final int compute$lvl(Map<StatType, Integer> map, StatType statType) {
            Integer num = map.get(statType);
            return RangesKt.coerceIn(num != null ? num.intValue() : 1, 1, 8);
        }

        public final StatModifiers compute(Map<StatType, Integer> levels) {
            Intrinsics.checkNotNullParameter(levels, "levels");
            return new StatModifiers(((compute$lvl(levels, StatType.SPEED) - 1) * 0.03f) + 1.0f, ((compute$lvl(levels, StatType.CONTROL) - 1) * 0.06f) + 1.0f, ((compute$lvl(levels, StatType.STAMINA) - 1) * 0.08f) + 1.0f, ((compute$lvl(levels, StatType.AGILITY) - 1) * 0.05f) + 1.0f, ((compute$lvl(levels, StatType.REWARD) - 1) * 0.06f) + 1.0f);
        }
    }
}
