package com.championship.warriors.iron.legacy.audio;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.data.GameSettings;
import com.championship.warriors.iron.legacy.data.SettingsRepository;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.flow.FlowKt;

/* compiled from: AudioController.kt */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u000e\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0010J\u0006\u0010\u001b\u001a\u00020\u0019J\u0006\u0010\u001c\u001a\u00020\u0019J\u0006\u0010\u001d\u001a\u00020\u0019J\u0006\u0010\u001e\u001a\u00020\u0019J\u0010\u0010\u001f\u001a\u00020\u00192\u0006\u0010 \u001a\u00020\u0011H\u0002J\u0006\u0010!\u001a\u00020\u0019J\u0006\u0010\"\u001a\u00020\u0019J\u0006\u0010#\u001a\u00020\u0019J\b\u0010$\u001a\u00020\u0019H\u0002J\u0010\u0010%\u001a\u00020\u00192\u0006\u0010 \u001a\u00020\u0011H\u0002J\b\u0010&\u001a\u00020\u0019H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n \t*\u0004\u0018\u00010\u00030\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\u000e\u001a\u001e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00110\u000fj\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011`\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006'"}, d2 = {"Lcom/championship/warriors/iron/legacy/audio/AudioController;", "", "context", "Landroid/content/Context;", "settings", "Lcom/championship/warriors/iron/legacy/data/SettingsRepository;", "<init>", "(Landroid/content/Context;Lcom/championship/warriors/iron/legacy/data/SettingsRepository;)V", "appContext", "kotlin.jvm.PlatformType", "scope", "Lkotlinx/coroutines/CoroutineScope;", "soundPool", "Landroid/media/SoundPool;", "soundIds", "Ljava/util/HashMap;", "Lcom/championship/warriors/iron/legacy/audio/Sfx;", "", "Lkotlin/collections/HashMap;", "musicPlayer", "Landroid/media/MediaPlayer;", "currentTrack", "backgrounded", "", "play", "", "sfx", "playMenuMusic", "playCareerMusic", "playGameMusic", "playTournamentMusic", "setTrack", "resId", "stopMusic", "onAppForeground", "onAppBackground", "refreshMusic", "createPlayer", "releasePlayer", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class AudioController {
    private final Context appContext;
    private boolean backgrounded;
    private int currentTrack;
    private MediaPlayer musicPlayer;
    private final CoroutineScope scope;
    private final SettingsRepository settings;
    private final HashMap<Sfx, Integer> soundIds;
    private final SoundPool soundPool;

    public AudioController(Context context, SettingsRepository settings) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(settings, "settings");
        this.settings = settings;
        this.appContext = context.getApplicationContext();
        this.scope = CoroutineScopeKt.CoroutineScope(Dispatchers.getMain().getImmediate());
        this.soundIds = new HashMap<>();
        SoundPool soundPoolBuild = new SoundPool.Builder().setMaxStreams(12).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).build();
        Intrinsics.checkNotNullExpressionValue(soundPoolBuild, "build(...)");
        this.soundPool = soundPoolBuild;
        for (Sfx sfx : Sfx.getEntries()) {
            this.soundIds.put(sfx, Integer.valueOf(this.soundPool.load(this.appContext, sfx.getResId(), 1)));
        }
        FlowKt.launchIn(FlowKt.onEach(this.settings.getSettings(), new AnonymousClass1(null)), this.scope);
    }

    /* compiled from: AudioController.kt */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "it", "Lcom/championship/warriors/iron/legacy/data/GameSettings;"}, k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    @DebugMetadata(c = "com.championship.warriors.iron.legacy.audio.AudioController$1", f = "AudioController.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.championship.warriors.iron.legacy.audio.AudioController$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<GameSettings, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return AudioController.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(GameSettings gameSettings, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(gameSettings, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws IllegalStateException {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            AudioController.this.refreshMusic();
            return Unit.INSTANCE;
        }
    }

    public final void play(Sfx sfx) {
        Integer num;
        Intrinsics.checkNotNullParameter(sfx, "sfx");
        if (this.settings.getSettings().getValue().getSfx() && (num = this.soundIds.get(sfx)) != null) {
            this.soundPool.play(num.intValue(), sfx.getVolume(), sfx.getVolume(), 1, 0, 1.0f);
        }
    }

    public final void playMenuMusic() throws IllegalStateException {
        setTrack(R.raw.music_menu);
    }

    public final void playCareerMusic() throws IllegalStateException {
        setTrack(R.raw.music_career);
    }

    public final void playGameMusic() throws IllegalStateException {
        setTrack(R.raw.music_gameplay);
    }

    public final void playTournamentMusic() throws IllegalStateException {
        setTrack(R.raw.music_tournament);
    }

    private final void setTrack(int resId) throws IllegalStateException {
        if (this.currentTrack == resId && this.musicPlayer != null) {
            refreshMusic();
            return;
        }
        this.currentTrack = resId;
        releasePlayer();
        refreshMusic();
    }

    public final void stopMusic() {
        this.currentTrack = 0;
        releasePlayer();
    }

    public final void onAppForeground() throws IllegalStateException {
        this.backgrounded = false;
        refreshMusic();
    }

    public final void onAppBackground() throws IllegalStateException {
        this.backgrounded = true;
        refreshMusic();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void refreshMusic() throws IllegalStateException {
        int i;
        if (!this.settings.getSettings().getValue().getMusic() || this.backgrounded || (i = this.currentTrack) == 0) {
            MediaPlayer mediaPlayer = this.musicPlayer;
            if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
                return;
            }
            mediaPlayer.pause();
            return;
        }
        MediaPlayer mediaPlayer2 = this.musicPlayer;
        if (mediaPlayer2 == null) {
            createPlayer(i);
            return;
        }
        if (mediaPlayer2.isPlaying()) {
            return;
        }
        try {
            Result.Companion companion = Result.INSTANCE;
            AudioController audioController = this;
            mediaPlayer2.start();
            Result.m478constructorimpl(Unit.INSTANCE);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            Result.m478constructorimpl(ResultKt.createFailure(th));
        }
    }

    private final void createPlayer(int resId) {
        Object objM478constructorimpl;
        try {
            Result.Companion companion = Result.INSTANCE;
            AudioController audioController = this;
            MediaPlayer mediaPlayerCreate = MediaPlayer.create(this.appContext, resId);
            if (mediaPlayerCreate != null) {
                mediaPlayerCreate.setLooping(true);
                mediaPlayerCreate.setVolume(0.55f, 0.55f);
                mediaPlayerCreate.start();
            } else {
                mediaPlayerCreate = null;
            }
            objM478constructorimpl = Result.m478constructorimpl(mediaPlayerCreate);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
        }
        if (Result.m485isSuccessimpl(objM478constructorimpl)) {
            this.musicPlayer = (MediaPlayer) objM478constructorimpl;
        }
    }

    private final void releasePlayer() {
        Object objM478constructorimpl;
        MediaPlayer mediaPlayer = this.musicPlayer;
        if (mediaPlayer != null) {
            try {
                Result.Companion companion = Result.INSTANCE;
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                objM478constructorimpl = Result.m478constructorimpl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
            }
            Result.m477boximpl(objM478constructorimpl);
        }
        this.musicPlayer = null;
    }
}
