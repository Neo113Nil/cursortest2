package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import com.google.android.material.card.MaterialCardViewHelper;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J(\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u0007H\u0002J\u0010\u0010\u0010\u001a\u0004\u0018\u00010\r2\u0006\u0010\u0011\u001a\u00020\u0012R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0013"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/ChallengeCatalog;", "", "<init>", "()V", "cfg", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "base", "", "mx", "gap", "dbl", "challenges", "", "Lcom/championship/warriors/iron/legacy/data/meta/ChallengeDef;", "getChallenges", "()Ljava/util/List;", "byId", "id", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ChallengeCatalog {
    public static final ChallengeCatalog INSTANCE;
    private static final List<ChallengeDef> challenges;

    private ChallengeCatalog() {
    }

    private final RunConfig cfg(float base, float mx, float gap, float dbl) {
        return new RunConfig(3, base, mx, 1.2f, gap, gap * 0.6f, dbl, 0.12f, 0.7f, 0.0f);
    }

    public final List<ChallengeDef> getChallenges() {
        return challenges;
    }

    static {
        ChallengeCatalog challengeCatalog = new ChallengeCatalog();
        INSTANCE = challengeCatalog;
        challenges = CollectionsKt.listOf((Object[]) new ChallengeDef[]{new ChallengeDef("c_coins", R.string.c_coins, R.string.c_coins_desc, ChallengeMetric.COINS, 40, 1400.0f, ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION, challengeCatalog.cfg(10.0f, 15.0f, 20.0f, 0.1f)), new ChallengeDef("c_distance", R.string.c_distance, R.string.c_distance_desc, ChallengeMetric.DISTANCE, TypedValues.Custom.TYPE_INT, 900.0f, 220, challengeCatalog.cfg(12.0f, 18.0f, 16.0f, 0.35f)), new ChallengeDef("c_dodge", R.string.c_dodge, R.string.c_dodge_desc, ChallengeMetric.AVOID, 45, 1500.0f, 240, challengeCatalog.cfg(11.0f, 17.0f, 15.0f, 0.4f)), new ChallengeDef("c_score", R.string.c_score, R.string.c_score_desc, ChallengeMetric.SCORE, 3500, 1400.0f, MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION, challengeCatalog.cfg(12.0f, 20.0f, 15.0f, 0.45f)), new ChallengeDef("c_gauntlet", R.string.c_gauntlet, R.string.c_gauntlet_desc, ChallengeMetric.DISTANCE, TypedValues.TransitionType.TYPE_DURATION, 700.0f, 320, challengeCatalog.cfg(14.0f, 22.0f, 12.0f, 0.6f)), new ChallengeDef("c_sprint", R.string.c_sprint, R.string.c_sprint_desc, ChallengeMetric.SCORE, 2200, 800.0f, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION, challengeCatalog.cfg(15.0f, 24.0f, 13.0f, 0.3f))});
    }

    public final ChallengeDef byId(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = challenges.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((ChallengeDef) next).getId(), id)) {
                break;
            }
        }
        return (ChallengeDef) next;
    }
}
