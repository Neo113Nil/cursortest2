package com.championship.warriors.iron.legacy.data.player;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
import com.championship.warriors.iron.legacy.data.equipment.BoostType;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCatalog;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentCategory;
import com.championship.warriors.iron.legacy.data.equipment.EquipmentItem;
import com.championship.warriors.iron.legacy.data.meta.AchievementCatalog;
import com.championship.warriors.iron.legacy.data.meta.AchievementDef;
import com.championship.warriors.iron.legacy.data.meta.ChallengeCatalog;
import com.championship.warriors.iron.legacy.data.meta.ChallengeDef;
import com.championship.warriors.iron.legacy.data.meta.DailyRewardTable;
import com.championship.warriors.iron.legacy.data.meta.MissionCatalog;
import com.championship.warriors.iron.legacy.data.meta.MissionDef;
import com.championship.warriors.iron.legacy.data.stage.StageData;
import com.championship.warriors.iron.legacy.data.stage.StageGoal;
import com.championship.warriors.iron.legacy.data.stage.StageRepository;
import com.championship.warriors.iron.legacy.runner.RunMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.enums.EnumEntries;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: PlayerRepository.kt */
@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\u0018\u0000 <2\u00020\u0001:\u0001<B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0006\u0010\u0012\u001a\u00020\rJ\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\u00142\u0006\u0010\u001c\u001a\u00020\u001dJ\u000e\u0010\u001e\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020 J\u000e\u0010!\u001a\u00020\"2\u0006\u0010\u001f\u001a\u00020 J\u000e\u0010#\u001a\u00020\u00142\u0006\u0010\u001c\u001a\u00020$J\u0006\u0010%\u001a\u00020&J\u000e\u0010'\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020 J\u0006\u0010(\u001a\u00020)J\u0006\u0010*\u001a\u00020\u0014J\u0006\u0010+\u001a\u00020,J\u0010\u0010-\u001a\u00020\u00162\b\b\u0002\u0010.\u001a\u00020\rJ\u000e\u0010/\u001a\u00020\"2\u0006\u0010\u001f\u001a\u00020 J\u0016\u00100\u001a\u00020\"2\u0006\u00101\u001a\u00020\u00142\u0006\u00102\u001a\u00020\u0014J\u0006\u00103\u001a\u00020\"J\b\u00104\u001a\u00020\rH\u0002J\u0010\u00105\u001a\u00020 2\u0006\u00106\u001a\u00020\u001dH\u0002J\u0010\u00107\u001a\u00020 2\u0006\u0010\u001f\u001a\u00020\u0016H\u0002J\u0010\u00108\u001a\u00020 2\u0006\u0010\u001f\u001a\u00020\u0016H\u0002J\u0010\u00109\u001a\u00020 2\u0006\u0010:\u001a\u00020 H\u0002J\u0010\u0010;\u001a\u00020 2\u0006\u0010\u001f\u001a\u00020 H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n \n*\u0004\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006="}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/PlayerRepository;", "", "context", "Landroid/content/Context;", "stages", "Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;", "<init>", "(Landroid/content/Context;Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;)V", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "_state", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "current", "spendCoins", "", "amount", "", "recordRun", "Lcom/championship/warriors/iron/legacy/data/player/RunReport;", "outcome", "Lcom/championship/warriors/iron/legacy/data/player/RunOutcome;", "upgradeStat", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "Lcom/championship/warriors/iron/legacy/data/player/StatType;", "buyEquipment", "id", "", "equip", "", "buyBoost", "Lcom/championship/warriors/iron/legacy/data/equipment/BoostType;", "consumeBoosts", "Lcom/championship/warriors/iron/legacy/data/player/AppliedBoosts;", "claimMission", "todayIndex", "", "canClaimDaily", "claimDaily", "Lcom/championship/warriors/iron/legacy/data/player/DailyResult;", "dailyDay", "s", "startTournament", "advanceTournament", "qualified", "isFinalRound", "resetAll", "load", "keyStat", "t", "keyStageBest", "keyStageStars", "keyEquip", "cat", "keyBoost", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class PlayerRepository {
    private static final String KEY_ACHIEVEMENTS = "achievements";
    private static final String KEY_BEST_CHAL = "best_chal";
    private static final String KEY_BEST_SEC = "best_sec";
    private static final String KEY_CHALLENGES = "challenges";
    private static final String KEY_COINS = "coins";
    private static final String KEY_DAILY_DAY = "daily_day";
    private static final String KEY_DAILY_STREAK = "daily_streak";
    private static final String KEY_ENDLESS = "endless";
    private static final String KEY_HIGH = "high";
    private static final String KEY_LONGEST = "longest";
    private static final String KEY_MAXCOMBO = "maxcombo";
    private static final String KEY_MISSIONS = "missions";
    private static final String KEY_OWNED = "owned";
    private static final String KEY_TOPSPEED = "topspeed";
    private static final String KEY_T_ALIVE = "t_alive";
    private static final String KEY_T_BEST = "t_best";
    private static final String KEY_T_COINS = "t_coins";
    private static final String KEY_T_DIST = "t_dist";
    private static final String KEY_T_ID = "t_id";
    private static final String KEY_T_OBS = "t_obs";
    private static final String KEY_T_POW = "t_pow";
    private static final String KEY_T_ROUND = "t_round";
    private static final String KEY_T_RUNS = "t_runs";
    private static final String KEY_T_SECONDS = "t_seconds";
    private static final String KEY_T_TITLES = "t_titles";
    private static final String KEY_T_TOKENS = "t_tokens";
    private static final String KEY_UNLOCKED = "unlocked";
    private static final String KEY_XP = "xp";
    private static final String PREFS = "vr_player";
    private final MutableStateFlow<PlayerState> _state;
    private final SharedPreferences prefs;
    private final StageRepository stages;
    private final StateFlow<PlayerState> state;

    public PlayerRepository(Context context, StageRepository stages) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(stages, "stages");
        this.stages = stages;
        this.prefs = context.getApplicationContext().getSharedPreferences(PREFS, 0);
        MutableStateFlow<PlayerState> MutableStateFlow = StateFlowKt.MutableStateFlow(load());
        this._state = MutableStateFlow;
        this.state = FlowKt.asStateFlow(MutableStateFlow);
    }

    public final StateFlow<PlayerState> getState() {
        return this.state;
    }

    public final PlayerState current() {
        return this._state.getValue();
    }

    public final boolean spendCoins(int amount) {
        if (current().getCoins() < amount) {
            return false;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(KEY_COINS, current().getCoins() - amount);
        editorEdit.apply();
        this._state.setValue(load());
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x00df  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0249  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final RunReport recordRun(RunOutcome outcome) {
        int rewardCoins;
        boolean z;
        int i;
        Intrinsics.checkNotNullParameter(outcome, "outcome");
        PlayerState playerStateCurrent = current();
        int distance = (outcome.getDistance() / 4) + (outcome.getScore() / 25) + (outcome.getCoins() * 2) + (outcome.getFinished() ? 120 : 0);
        boolean z2 = outcome.getScore() > playerStateCurrent.getHighScore();
        int iStarsFor = playerStateCurrent.starsFor(outcome.getStageId());
        int stageId = outcome.getStageId();
        StageData stageDataStageById = this.stages.stageById(outcome.getStageId());
        if (outcome.getMode() == RunMode.CAREER && stageDataStageById != null) {
            List<StageGoal> goals = stageDataStageById.getGoals();
            if ((goals instanceof Collection) && goals.isEmpty()) {
                i = 0;
            } else {
                Iterator<T> it = goals.iterator();
                i = 0;
                while (it.hasNext()) {
                    if (((StageGoal) it.next()).met(outcome.getDistance(), outcome.getCoins(), outcome.getScore(), outcome.getAvoided()) && (i = i + 1) < 0) {
                        CollectionsKt.throwCountOverflow();
                    }
                }
            }
            iStarsFor = Math.max(iStarsFor, i);
        }
        int i2 = iStarsFor;
        boolean z3 = outcome.getMode() == RunMode.CHALLENGE && outcome.getChallengePassed() && outcome.getChallengeId() != null && !playerStateCurrent.getChallengesDone().contains(outcome.getChallengeId());
        if (z3) {
            ChallengeCatalog challengeCatalog = ChallengeCatalog.INSTANCE;
            String challengeId = outcome.getChallengeId();
            Intrinsics.checkNotNull(challengeId);
            ChallengeDef challengeDefById = challengeCatalog.byId(challengeId);
            rewardCoins = challengeDefById != null ? challengeDefById.getRewardCoins() : 0;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(KEY_COINS, playerStateCurrent.getCoins() + outcome.getCoins() + rewardCoins);
        editorEdit.putInt(KEY_XP, playerStateCurrent.getXp() + distance);
        editorEdit.putInt(KEY_T_DIST, playerStateCurrent.getTotalDistance() + outcome.getDistance());
        editorEdit.putInt(KEY_T_COINS, playerStateCurrent.getTotalCoins() + outcome.getCoins());
        editorEdit.putInt(KEY_T_OBS, playerStateCurrent.getTotalObstacles() + outcome.getAvoided());
        editorEdit.putInt(KEY_T_POW, playerStateCurrent.getTotalPowerups() + outcome.getPowerups());
        editorEdit.putInt(KEY_T_RUNS, playerStateCurrent.getTotalRuns() + 1);
        editorEdit.putInt(KEY_T_TOKENS, playerStateCurrent.getTotalTokens() + outcome.getTokens());
        editorEdit.putInt(KEY_T_SECONDS, playerStateCurrent.getPlaySeconds() + outcome.getSeconds());
        editorEdit.putInt(KEY_HIGH, Math.max(playerStateCurrent.getHighScore(), outcome.getScore()));
        editorEdit.putInt(KEY_LONGEST, Math.max(playerStateCurrent.getLongestRun(), outcome.getDistance()));
        editorEdit.putInt(KEY_BEST_SEC, Math.max(playerStateCurrent.getBestRunSeconds(), outcome.getSeconds()));
        editorEdit.putInt(KEY_TOPSPEED, Math.max(playerStateCurrent.getTopSpeed(), outcome.getTopSpeed()));
        editorEdit.putInt(KEY_MAXCOMBO, Math.max(playerStateCurrent.getMaxCombo(), outcome.getMaxCombo()));
        if (outcome.getMode() == RunMode.ENDLESS) {
            editorEdit.putInt(KEY_ENDLESS, Math.max(playerStateCurrent.getEndlessBest(), outcome.getScore()));
        }
        if (outcome.getMode() == RunMode.CHALLENGE) {
            editorEdit.putInt(KEY_BEST_CHAL, Math.max(playerStateCurrent.getBestChallengeScore(), outcome.getScore()));
        }
        if (outcome.getMode() != RunMode.CAREER || stageDataStageById == null) {
            z = false;
        } else {
            editorEdit.putInt(keyStageBest(outcome.getStageId()), Math.max(playerStateCurrent.bestFor(outcome.getStageId()), outcome.getScore()));
            editorEdit.putInt(keyStageStars(outcome.getStageId()), i2);
            if (outcome.getFinished() && outcome.getStageId() == playerStateCurrent.getCareerUnlocked() && outcome.getStageId() < this.stages.getLastStageId()) {
                editorEdit.putInt(KEY_UNLOCKED, outcome.getStageId() + 1);
                stageId = outcome.getStageId() + 1;
                z = true;
            }
        }
        int i3 = stageId;
        if (z3) {
            Set<String> challengesDone = playerStateCurrent.getChallengesDone();
            String challengeId2 = outcome.getChallengeId();
            Intrinsics.checkNotNull(challengeId2);
            editorEdit.putStringSet(KEY_CHALLENGES, SetsKt.plus(challengesDone, challengeId2));
        }
        editorEdit.apply();
        PlayerState playerStateLoad = load();
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet(playerStateLoad.getAchievementsUnlocked());
        for (AchievementDef achievementDef : AchievementCatalog.INSTANCE.getAchievements()) {
            if (!hashSet.contains(achievementDef.getId()) && achievementDef.isUnlocked(playerStateLoad)) {
                hashSet.add(achievementDef.getId());
                arrayList.add(achievementDef.getId());
            }
        }
        if (!arrayList.isEmpty()) {
            SharedPreferences prefs2 = this.prefs;
            Intrinsics.checkNotNullExpressionValue(prefs2, "prefs");
            SharedPreferences.Editor editorEdit2 = prefs2.edit();
            Intrinsics.checkNotNull(editorEdit2);
            editorEdit2.putStringSet(KEY_ACHIEVEMENTS, hashSet);
            editorEdit2.apply();
        }
        this._state.setValue(load());
        PlayerState value = this._state.getValue();
        return new RunReport(outcome.getCoins() + rewardCoins, distance, value.getLevel() > playerStateCurrent.getLevel(), value.getLevel(), z2, i2, z, i3, arrayList, outcome.getChallengePassed());
    }

    public final boolean upgradeStat(StatType type) {
        int iUpgradeCost;
        Intrinsics.checkNotNullParameter(type, "type");
        int iStatLevel = current().statLevel(type);
        if (iStatLevel >= 8 || current().getCoins() < (iUpgradeCost = type.upgradeCost(iStatLevel))) {
            return false;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(KEY_COINS, current().getCoins() - iUpgradeCost);
        editorEdit.putInt(keyStat(type), iStatLevel + 1);
        editorEdit.apply();
        this._state.setValue(load());
        return true;
    }

    public final boolean buyEquipment(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        EquipmentItem equipmentItemById = EquipmentCatalog.INSTANCE.byId(id);
        if (equipmentItemById == null || current().owns(id) || !spendCoins(equipmentItemById.getCost())) {
            return false;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putStringSet(KEY_OWNED, SetsKt.plus(current().getOwnedEquipment(), id));
        editorEdit.apply();
        this._state.setValue(load());
        return true;
    }

    public final void equip(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        EquipmentItem equipmentItemById = EquipmentCatalog.INSTANCE.byId(id);
        if (equipmentItemById != null && current().owns(id)) {
            HashMap map = new HashMap(current().getEquipped());
            map.put(equipmentItemById.getCategory().name(), id);
            SharedPreferences prefs = this.prefs;
            Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
            SharedPreferences.Editor editorEdit = prefs.edit();
            Intrinsics.checkNotNull(editorEdit);
            for (Map.Entry entry : map.entrySet()) {
                String str = (String) entry.getKey();
                String str2 = (String) entry.getValue();
                Intrinsics.checkNotNull(str);
                editorEdit.putString(keyEquip(str), str2);
            }
            editorEdit.apply();
            this._state.setValue(load());
        }
    }

    public final boolean buyBoost(BoostType type) {
        Intrinsics.checkNotNullParameter(type, "type");
        if (!spendCoins(type.getCost())) {
            return false;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(keyBoost(type.getId()), current().boostCount(type.getId()) + 1);
        editorEdit.apply();
        this._state.setValue(load());
        return true;
    }

    public final AppliedBoosts consumeBoosts() {
        PlayerState playerStateCurrent = current();
        boolean z = playerStateCurrent.boostCount(BoostType.HEAD_START.getId()) > 0;
        boolean z2 = playerStateCurrent.boostCount(BoostType.SHIELD_START.getId()) > 0;
        boolean z3 = playerStateCurrent.boostCount(BoostType.COIN_RUSH.getId()) > 0;
        int i = playerStateCurrent.boostCount(BoostType.REVIVE.getId()) > 0 ? 1 : 0;
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        if (z) {
            editorEdit.putInt(keyBoost(BoostType.HEAD_START.getId()), playerStateCurrent.boostCount(BoostType.HEAD_START.getId()) - 1);
        }
        if (z2) {
            editorEdit.putInt(keyBoost(BoostType.SHIELD_START.getId()), playerStateCurrent.boostCount(BoostType.SHIELD_START.getId()) - 1);
        }
        if (z3) {
            editorEdit.putInt(keyBoost(BoostType.COIN_RUSH.getId()), playerStateCurrent.boostCount(BoostType.COIN_RUSH.getId()) - 1);
        }
        if (i == 1) {
            editorEdit.putInt(keyBoost(BoostType.REVIVE.getId()), playerStateCurrent.boostCount(BoostType.REVIVE.getId()) - 1);
        }
        editorEdit.apply();
        this._state.setValue(load());
        return new AppliedBoosts(z, z2, z3, i);
    }

    public final boolean claimMission(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = MissionCatalog.INSTANCE.getMissions().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((MissionDef) next).getId(), id)) {
                break;
            }
        }
        MissionDef missionDef = (MissionDef) next;
        if (missionDef == null) {
            return false;
        }
        PlayerState playerStateCurrent = current();
        if (playerStateCurrent.getMissionsClaimed().contains(id) || missionDef.progress(playerStateCurrent) < missionDef.getTarget()) {
            return false;
        }
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(KEY_COINS, playerStateCurrent.getCoins() + missionDef.getRewardCoins());
        editorEdit.putStringSet(KEY_MISSIONS, SetsKt.plus(playerStateCurrent.getMissionsClaimed(), id));
        editorEdit.apply();
        this._state.setValue(load());
        return true;
    }

    public final long todayIndex() {
        return System.currentTimeMillis() / 86400000;
    }

    public final boolean canClaimDaily() {
        return current().getDailyLastDay() != todayIndex();
    }

    public final DailyResult claimDaily() {
        PlayerState playerStateCurrent = current();
        long j = todayIndex();
        if (playerStateCurrent.getDailyLastDay() == j) {
            return new DailyResult(false, dailyDay(playerStateCurrent), 0);
        }
        int dailyStreak = playerStateCurrent.getDailyLastDay() == j - 1 ? (playerStateCurrent.getDailyStreak() % 7) + 1 : 1;
        int iIntValue = DailyRewardTable.INSTANCE.getCoins().get(RangesKt.coerceIn(dailyStreak - 1, 0, 6)).intValue();
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putInt(KEY_COINS, playerStateCurrent.getCoins() + iIntValue);
        editorEdit.putInt(KEY_DAILY_STREAK, dailyStreak);
        editorEdit.putLong(KEY_DAILY_DAY, j);
        editorEdit.apply();
        this._state.setValue(load());
        return new DailyResult(true, dailyStreak, iIntValue);
    }

    public static /* synthetic */ int dailyDay$default(PlayerRepository playerRepository, PlayerState playerState, int i, Object obj) {
        if ((i & 1) != 0) {
            playerState = playerRepository.current();
        }
        return playerRepository.dailyDay(playerState);
    }

    public final int dailyDay(PlayerState s) {
        Intrinsics.checkNotNullParameter(s, "s");
        if (s.getDailyStreak() == 0) {
            return 1;
        }
        return s.getDailyStreak();
    }

    public final void startTournament(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.putString(KEY_T_ID, id);
        editorEdit.putInt(KEY_T_ROUND, 0);
        editorEdit.putBoolean(KEY_T_ALIVE, true);
        editorEdit.apply();
        this._state.setValue(load());
    }

    public final void advanceTournament(boolean qualified, boolean isFinalRound) {
        PlayerState playerStateCurrent = current();
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        if (!qualified) {
            editorEdit.putBoolean(KEY_T_ALIVE, false);
            editorEdit.putInt(KEY_T_BEST, Math.max(playerStateCurrent.getBestTournamentRound(), playerStateCurrent.getTournamentRound()));
        } else if (!isFinalRound) {
            editorEdit.putInt(KEY_T_ROUND, playerStateCurrent.getTournamentRound() + 1);
            editorEdit.putInt(KEY_T_BEST, Math.max(playerStateCurrent.getBestTournamentRound(), playerStateCurrent.getTournamentRound() + 1));
        } else {
            editorEdit.putInt(KEY_T_TITLES, playerStateCurrent.getTournamentTitles() + 1);
            editorEdit.putInt(KEY_T_ROUND, playerStateCurrent.getTournamentRound() + 1);
            editorEdit.putInt(KEY_T_BEST, Math.max(playerStateCurrent.getBestTournamentRound(), playerStateCurrent.getTournamentRound() + 1));
            editorEdit.putBoolean(KEY_T_ALIVE, false);
        }
        editorEdit.apply();
        this._state.setValue(load());
    }

    public final void resetAll() {
        SharedPreferences prefs = this.prefs;
        Intrinsics.checkNotNullExpressionValue(prefs, "prefs");
        SharedPreferences.Editor editorEdit = prefs.edit();
        Intrinsics.checkNotNull(editorEdit);
        editorEdit.clear();
        editorEdit.apply();
        this._state.setValue(load());
    }

    private final PlayerState load() {
        EnumEntries<StatType> entries = StatType.getEntries();
        LinkedHashMap linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(entries, 10)), 16));
        for (StatType statType : entries) {
            linkedHashMap.put(statType, Integer.valueOf(this.prefs.getInt(keyStat(statType), 1)));
        }
        LinkedHashMap linkedHashMap2 = linkedHashMap;
        HashMap map = new HashMap();
        HashMap map2 = new HashMap();
        for (StageData stageData : this.stages.getStages()) {
            int i = this.prefs.getInt(keyStageBest(stageData.getId()), 0);
            if (i > 0) {
                map.put(Integer.valueOf(stageData.getId()), Integer.valueOf(i));
            }
            int i2 = this.prefs.getInt(keyStageStars(stageData.getId()), 0);
            if (i2 > 0) {
                map2.put(Integer.valueOf(stageData.getId()), Integer.valueOf(i2));
            }
        }
        HashMap map3 = new HashMap();
        for (EquipmentCategory equipmentCategory : EquipmentCategory.getEntries()) {
            String string = this.prefs.getString(keyEquip(equipmentCategory.name()), null);
            if (string != null) {
                map3.put(equipmentCategory.name(), string);
            }
        }
        HashMap map4 = new HashMap();
        for (BoostType boostType : BoostType.getEntries()) {
            int i3 = this.prefs.getInt(keyBoost(boostType.getId()), 0);
            if (i3 > 0) {
                map4.put(boostType.getId(), Integer.valueOf(i3));
            }
        }
        int i4 = this.prefs.getInt(KEY_COINS, 0);
        int i5 = this.prefs.getInt(KEY_XP, 0);
        int i6 = this.prefs.getInt(KEY_T_DIST, 0);
        int i7 = this.prefs.getInt(KEY_T_COINS, 0);
        int i8 = this.prefs.getInt(KEY_T_OBS, 0);
        int i9 = this.prefs.getInt(KEY_T_POW, 0);
        int i10 = this.prefs.getInt(KEY_T_RUNS, 0);
        int i11 = this.prefs.getInt(KEY_T_TOKENS, 0);
        int i12 = this.prefs.getInt(KEY_T_SECONDS, 0);
        int i13 = this.prefs.getInt(KEY_HIGH, 0);
        int i14 = this.prefs.getInt(KEY_LONGEST, 0);
        int i15 = this.prefs.getInt(KEY_BEST_SEC, 0);
        int i16 = this.prefs.getInt(KEY_ENDLESS, 0);
        int i17 = this.prefs.getInt(KEY_TOPSPEED, 0);
        int i18 = this.prefs.getInt(KEY_MAXCOMBO, 0);
        int i19 = this.prefs.getInt(KEY_BEST_CHAL, 0);
        int i20 = this.prefs.getInt(KEY_UNLOCKED, 1);
        HashMap map5 = map;
        HashMap map6 = map2;
        Set<String> stringSet = this.prefs.getStringSet(KEY_OWNED, SetsKt.emptySet());
        if (stringSet == null) {
            stringSet = SetsKt.emptySet();
        }
        HashMap map7 = map3;
        HashMap map8 = map4;
        Set<String> stringSet2 = this.prefs.getStringSet(KEY_MISSIONS, SetsKt.emptySet());
        if (stringSet2 == null) {
            stringSet2 = SetsKt.emptySet();
        }
        Set<String> set = stringSet2;
        Set<String> stringSet3 = this.prefs.getStringSet(KEY_ACHIEVEMENTS, SetsKt.emptySet());
        if (stringSet3 == null) {
            stringSet3 = SetsKt.emptySet();
        }
        Set<String> set2 = stringSet3;
        Set<String> stringSet4 = this.prefs.getStringSet(KEY_CHALLENGES, SetsKt.emptySet());
        if (stringSet4 == null) {
            stringSet4 = SetsKt.emptySet();
        }
        Set<String> set3 = stringSet4;
        int i21 = this.prefs.getInt(KEY_DAILY_STREAK, 0);
        long j = this.prefs.getLong(KEY_DAILY_DAY, 0L);
        Set<String> set4 = stringSet;
        String string2 = this.prefs.getString(KEY_T_ID, "");
        return new PlayerState(i4, i5, linkedHashMap2, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16, i17, i18, i19, i20, map5, map6, set4, map7, map8, set, set2, set3, i21, j, string2 == null ? "" : string2, this.prefs.getInt(KEY_T_ROUND, 0), this.prefs.getBoolean(KEY_T_ALIVE, true), this.prefs.getInt(KEY_T_TITLES, 0), this.prefs.getInt(KEY_T_BEST, 0));
    }

    private final String keyStat(StatType t) {
        return "stat_" + t.name();
    }

    private final String keyStageBest(int id) {
        return "sbest_" + id;
    }

    private final String keyStageStars(int id) {
        return "sstar_" + id;
    }

    private final String keyEquip(String cat) {
        return "equip_" + cat;
    }

    private final String keyBoost(String id) {
        return "boost_" + id;
    }
}
