package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

/* loaded from: classes.dex */
public final class FragmentResultsBinding implements ViewBinding {
    public final MaterialCardView card;
    public final TextView coinsValue;
    public final TextView distanceValue;
    public final MaterialButton ghostButton;
    public final TextView levelUpBadge;
    public final TextView newBestBadge;
    public final MaterialButton primaryButton;
    public final ImageView resultIcon;
    public final TextView resultTitle;
    private final FrameLayout rootView;
    public final TextView scoreValue;
    public final MaterialButton secondaryButton;
    public final ImageView star1;
    public final ImageView star2;
    public final ImageView star3;
    public final LinearLayout starsRow;
    public final TextView xpText;

    private FragmentResultsBinding(FrameLayout frameLayout, MaterialCardView materialCardView, TextView textView, TextView textView2, MaterialButton materialButton, TextView textView3, TextView textView4, MaterialButton materialButton2, ImageView imageView, TextView textView5, TextView textView6, MaterialButton materialButton3, ImageView imageView2, ImageView imageView3, ImageView imageView4, LinearLayout linearLayout, TextView textView7) {
        this.rootView = frameLayout;
        this.card = materialCardView;
        this.coinsValue = textView;
        this.distanceValue = textView2;
        this.ghostButton = materialButton;
        this.levelUpBadge = textView3;
        this.newBestBadge = textView4;
        this.primaryButton = materialButton2;
        this.resultIcon = imageView;
        this.resultTitle = textView5;
        this.scoreValue = textView6;
        this.secondaryButton = materialButton3;
        this.star1 = imageView2;
        this.star2 = imageView3;
        this.star3 = imageView4;
        this.starsRow = linearLayout;
        this.xpText = textView7;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentResultsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentResultsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_results, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentResultsBinding bind(View view) {
        int i = R.id.card;
        MaterialCardView materialCardView = (MaterialCardView) ViewBindings.findChildViewById(view, i);
        if (materialCardView != null) {
            i = R.id.coinsValue;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.distanceValue;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView2 != null) {
                    i = R.id.ghostButton;
                    MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
                    if (materialButton != null) {
                        i = R.id.levelUpBadge;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.newBestBadge;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView4 != null) {
                                i = R.id.primaryButton;
                                MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                if (materialButton2 != null) {
                                    i = R.id.resultIcon;
                                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                    if (imageView != null) {
                                        i = R.id.resultTitle;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                        if (textView5 != null) {
                                            i = R.id.scoreValue;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                            if (textView6 != null) {
                                                i = R.id.secondaryButton;
                                                MaterialButton materialButton3 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                                if (materialButton3 != null) {
                                                    i = R.id.star1;
                                                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                    if (imageView2 != null) {
                                                        i = R.id.star2;
                                                        ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                        if (imageView3 != null) {
                                                            i = R.id.star3;
                                                            ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                            if (imageView4 != null) {
                                                                i = R.id.starsRow;
                                                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                                                                if (linearLayout != null) {
                                                                    i = R.id.xpText;
                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                    if (textView7 != null) {
                                                                        return new FragmentResultsBinding((FrameLayout) view, materialCardView, textView, textView2, materialButton, textView3, textView4, materialButton2, imageView, textView5, textView6, materialButton3, imageView2, imageView3, imageView4, linearLayout, textView7);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
