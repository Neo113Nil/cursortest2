package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u0007\u001a\u00020\u0003H\u0016J\b\u0010\b\u001a\u00020\u0003H\u0016J\b\u0010\t\u001a\u00020\u0003H\u0016J\u0010\u0010\n\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\fH\u0016J\b\u0010\r\u001a\u00020\u0003H\u0016J\b\u0010\u000e\u001a\u00020\u0003H\u0016J\b\u0010\u000f\u001a\u00020\u0003H\u0016J\b\u0010\u0010\u001a\u00020\u0003H\u0016J\b\u0010\u0011\u001a\u00020\u0003H\u0016J\b\u0010\u0012\u001a\u00020\u0003H\u0016J\b\u0010\u0013\u001a\u00020\u0003H\u0016¨\u0006\u0014À\u0006\u0003"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunnerListener;", "", "onPlace", "", "onClear", "lines", "", "onCombo", "onCoin", "onToken", "onPowerUp", "kind", "Lcom/championship/warriors/iron/legacy/runner/Booster;", "onDouble", "onShieldBlock", "onRevive", "onCheckpoint", "onMilestone", "onCrash", "onStageComplete", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public interface RunnerListener {
    default void onCheckpoint() {
    }

    default void onClear(int lines) {
    }

    default void onCoin() {
    }

    default void onCombo() {
    }

    default void onCrash() {
    }

    default void onDouble() {
    }

    default void onMilestone() {
    }

    default void onPlace() {
    }

    default void onPowerUp(Booster kind) {
        Intrinsics.checkNotNullParameter(kind, "kind");
    }

    default void onRevive() {
    }

    default void onShieldBlock() {
    }

    default void onStageComplete() {
    }

    default void onToken() {
    }

    /* compiled from: RunnerModels.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class DefaultImpls {
        @Deprecated
        public static void onPlace(RunnerListener runnerListener) {
            RunnerListener.super.onPlace();
        }

        @Deprecated
        public static void onClear(RunnerListener runnerListener, int i) {
            RunnerListener.super.onClear(i);
        }

        @Deprecated
        public static void onCombo(RunnerListener runnerListener) {
            RunnerListener.super.onCombo();
        }

        @Deprecated
        public static void onCoin(RunnerListener runnerListener) {
            RunnerListener.super.onCoin();
        }

        @Deprecated
        public static void onToken(RunnerListener runnerListener) {
            RunnerListener.super.onToken();
        }

        @Deprecated
        public static void onPowerUp(RunnerListener runnerListener, Booster kind) {
            Intrinsics.checkNotNullParameter(kind, "kind");
            RunnerListener.super.onPowerUp(kind);
        }

        @Deprecated
        public static void onDouble(RunnerListener runnerListener) {
            RunnerListener.super.onDouble();
        }

        @Deprecated
        public static void onShieldBlock(RunnerListener runnerListener) {
            RunnerListener.super.onShieldBlock();
        }

        @Deprecated
        public static void onRevive(RunnerListener runnerListener) {
            RunnerListener.super.onRevive();
        }

        @Deprecated
        public static void onCheckpoint(RunnerListener runnerListener) {
            RunnerListener.super.onCheckpoint();
        }

        @Deprecated
        public static void onMilestone(RunnerListener runnerListener) {
            RunnerListener.super.onMilestone();
        }

        @Deprecated
        public static void onCrash(RunnerListener runnerListener) {
            RunnerListener.super.onCrash();
        }

        @Deprecated
        public static void onStageComplete(RunnerListener runnerListener) {
            RunnerListener.super.onStageComplete();
        }
    }
}
