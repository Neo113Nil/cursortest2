package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.ranges.RangesKt;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0016\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\b\u0018\u0000 \u001f2\u00020\u0001:\u0001\u001fB7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003JE\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\fR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\f¨\u0006 "}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunTheme;", "", "skyTop", "", "skyBottom", "stand", "track", "trackLine", "glow", "<init>", "(IIIIII)V", "getSkyTop", "()I", "getSkyBottom", "getStand", "getTrack", "getTrackLine", "getGlow", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunTheme {
    private static final RunTheme ACADEMY;
    private static final List<RunTheme> ALL;
    private static final RunTheme CHAMPIONSHIP;
    private static final RunTheme CITY;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private static final RunTheme ELITE;
    private static final RunTheme PRO;
    private static final RunTheme TRAINING;
    private final int glow;
    private final int skyBottom;
    private final int skyTop;
    private final int stand;
    private final int track;
    private final int trackLine;

    public static /* synthetic */ RunTheme copy$default(RunTheme runTheme, int i, int i2, int i3, int i4, int i5, int i6, int i7, Object obj) {
        if ((i7 & 1) != 0) {
            i = runTheme.skyTop;
        }
        if ((i7 & 2) != 0) {
            i2 = runTheme.skyBottom;
        }
        if ((i7 & 4) != 0) {
            i3 = runTheme.stand;
        }
        if ((i7 & 8) != 0) {
            i4 = runTheme.track;
        }
        if ((i7 & 16) != 0) {
            i5 = runTheme.trackLine;
        }
        if ((i7 & 32) != 0) {
            i6 = runTheme.glow;
        }
        int i8 = i5;
        int i9 = i6;
        return runTheme.copy(i, i2, i3, i4, i8, i9);
    }

    /* renamed from: component1, reason: from getter */
    public final int getSkyTop() {
        return this.skyTop;
    }

    /* renamed from: component2, reason: from getter */
    public final int getSkyBottom() {
        return this.skyBottom;
    }

    /* renamed from: component3, reason: from getter */
    public final int getStand() {
        return this.stand;
    }

    /* renamed from: component4, reason: from getter */
    public final int getTrack() {
        return this.track;
    }

    /* renamed from: component5, reason: from getter */
    public final int getTrackLine() {
        return this.trackLine;
    }

    /* renamed from: component6, reason: from getter */
    public final int getGlow() {
        return this.glow;
    }

    public final RunTheme copy(int skyTop, int skyBottom, int stand, int track, int trackLine, int glow) {
        return new RunTheme(skyTop, skyBottom, stand, track, trackLine, glow);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunTheme)) {
            return false;
        }
        RunTheme runTheme = (RunTheme) other;
        return this.skyTop == runTheme.skyTop && this.skyBottom == runTheme.skyBottom && this.stand == runTheme.stand && this.track == runTheme.track && this.trackLine == runTheme.trackLine && this.glow == runTheme.glow;
    }

    public int hashCode() {
        return (((((((((Integer.hashCode(this.skyTop) * 31) + Integer.hashCode(this.skyBottom)) * 31) + Integer.hashCode(this.stand)) * 31) + Integer.hashCode(this.track)) * 31) + Integer.hashCode(this.trackLine)) * 31) + Integer.hashCode(this.glow);
    }

    public String toString() {
        return "RunTheme(skyTop=" + this.skyTop + ", skyBottom=" + this.skyBottom + ", stand=" + this.stand + ", track=" + this.track + ", trackLine=" + this.trackLine + ", glow=" + this.glow + ")";
    }

    public RunTheme(int i, int i2, int i3, int i4, int i5, int i6) {
        this.skyTop = i;
        this.skyBottom = i2;
        this.stand = i3;
        this.track = i4;
        this.trackLine = i5;
        this.glow = i6;
    }

    public final int getSkyTop() {
        return this.skyTop;
    }

    public final int getSkyBottom() {
        return this.skyBottom;
    }

    public final int getStand() {
        return this.stand;
    }

    public final int getTrack() {
        return this.track;
    }

    public final int getTrackLine() {
        return this.trackLine;
    }

    public final int getGlow() {
        return this.glow;
    }

    /* compiled from: RunnerModels.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u0018R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0007R\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0007R\u0011\u0010\u0010\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0007R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00050\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006\u0019"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/RunTheme$Companion;", "", "<init>", "()V", "TRAINING", "Lcom/championship/warriors/iron/legacy/runner/RunTheme;", "getTRAINING", "()Lcom/championship/warriors/iron/legacy/runner/RunTheme;", "ACADEMY", "getACADEMY", "CITY", "getCITY", "PRO", "getPRO", "CHAMPIONSHIP", "getCHAMPIONSHIP", "ELITE", "getELITE", "ALL", "", "getALL", "()Ljava/util/List;", "forStage", "index", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final RunTheme getTRAINING() {
            return RunTheme.TRAINING;
        }

        public final RunTheme getACADEMY() {
            return RunTheme.ACADEMY;
        }

        public final RunTheme getCITY() {
            return RunTheme.CITY;
        }

        public final RunTheme getPRO() {
            return RunTheme.PRO;
        }

        public final RunTheme getCHAMPIONSHIP() {
            return RunTheme.CHAMPIONSHIP;
        }

        public final RunTheme getELITE() {
            return RunTheme.ELITE;
        }

        public final List<RunTheme> getALL() {
            return RunTheme.ALL;
        }

        public final RunTheme forStage(int index) {
            return getALL().get(RangesKt.coerceIn(index, 0, getALL().size() - 1));
        }
    }

    static {
        RunTheme runTheme = new RunTheme(-15585186, -16114883, -15717804, -15582674, -12992374, -12747777);
        TRAINING = runTheme;
        RunTheme runTheme2 = new RunTheme(-15451528, -16114883, -15848870, -15719092, -11761921, -11761921);
        ACADEMY = runTheme2;
        RunTheme runTheme3 = new RunTheme(-15848602, -16313039, -15981744, -15785659, -12747777, -14032656);
        CITY = runTheme3;
        RunTheme runTheme4 = new RunTheme(-15061894, -16117200, -15589282, -15590843, -9667585, -8430593);
        PRO = runTheme4;
        RunTheme runTheme5 = new RunTheme(-15714706, -16313039, -15582610, -15784889, -13252624, -15043);
        CHAMPIONSHIP = runTheme5;
        RunTheme runTheme6 = new RunTheme(-14673301, -16118230, -15130529, -15459771, -7692033, -15043);
        ELITE = runTheme6;
        ALL = CollectionsKt.listOf((Object[]) new RunTheme[]{runTheme, runTheme2, runTheme3, runTheme4, runTheme5, runTheme6});
    }
}
