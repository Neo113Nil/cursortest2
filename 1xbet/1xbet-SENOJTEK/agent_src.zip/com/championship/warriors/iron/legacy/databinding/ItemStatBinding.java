package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.LinearProgressIndicator;

/* loaded from: classes.dex */
public final class ItemStatBinding implements ViewBinding {
    public final ImageView icon;
    public final TextView levelText;
    public final LinearProgressIndicator progressBar;
    private final MaterialCardView rootView;
    public final TextView statDesc;
    public final TextView statName;
    public final MaterialButton upgradeButton;

    private ItemStatBinding(MaterialCardView materialCardView, ImageView imageView, TextView textView, LinearProgressIndicator linearProgressIndicator, TextView textView2, TextView textView3, MaterialButton materialButton) {
        this.rootView = materialCardView;
        this.icon = imageView;
        this.levelText = textView;
        this.progressBar = linearProgressIndicator;
        this.statDesc = textView2;
        this.statName = textView3;
        this.upgradeButton = materialButton;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ItemStatBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemStatBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_stat, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemStatBinding bind(View view) {
        int i = R.id.icon;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = R.id.levelText;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = R.id.progressBar;
                LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) ViewBindings.findChildViewById(view, i);
                if (linearProgressIndicator != null) {
                    i = R.id.statDesc;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        i = R.id.statName;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView3 != null) {
                            i = R.id.upgradeButton;
                            MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
                            if (materialButton != null) {
                                return new ItemStatBinding((MaterialCardView) view, imageView, textView, linearProgressIndicator, textView2, textView3, materialButton);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
