package com.championship.warriors.iron.legacy.presentation.common;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaAdapter.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b&\b\u0086\b\u0018\u00002\u00020\u0001B\u008d\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0005\u0012\b\b\u0002\u0010\n\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\r\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\r\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\t\u0010'\u001a\u00020\u0003HÆ\u0003J\t\u0010(\u001a\u00020\u0005HÆ\u0003J\t\u0010)\u001a\u00020\u0005HÆ\u0003J\t\u0010*\u001a\u00020\u0003HÆ\u0003J\t\u0010+\u001a\u00020\u0003HÆ\u0003J\t\u0010,\u001a\u00020\u0005HÆ\u0003J\t\u0010-\u001a\u00020\u0005HÆ\u0003J\u000b\u0010.\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010/\u001a\u00020\rHÆ\u0003J\u000b\u00100\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u00101\u001a\u00020\rHÆ\u0003J\t\u00102\u001a\u00020\u0003HÆ\u0003J\u000f\u00103\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012HÆ\u0003J\u0095\u0001\u00104\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0003\u0010\u0004\u001a\u00020\u00052\b\b\u0003\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00052\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\f\u001a\u00020\r2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u000f\u001a\u00020\r2\b\b\u0002\u0010\u0010\u001a\u00020\u00032\u000e\b\u0002\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012HÆ\u0001J\u0013\u00105\u001a\u00020\r2\b\u00106\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00107\u001a\u00020\u0005HÖ\u0001J\t\u00108\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0017R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0017R\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0017R\u0011\u0010\u000f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b#\u0010!R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0017R\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012¢\u0006\b\n\u0000\u001a\u0004\b%\u0010&¨\u00069"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/common/MetaRow;", "", "id", "", "iconRes", "", "iconTint", "title", "subtitle", "progress", "progressMax", "buttonText", "buttonEnabled", "", "rightText", "showCheck", "contentKey", "onAction", "Lkotlin/Function0;", "", "<init>", "(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;IILjava/lang/String;ZLjava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getId", "()Ljava/lang/String;", "getIconRes", "()I", "getIconTint", "getTitle", "getSubtitle", "getProgress", "getProgressMax", "getButtonText", "getButtonEnabled", "()Z", "getRightText", "getShowCheck", "getContentKey", "getOnAction", "()Lkotlin/jvm/functions/Function0;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class MetaRow {
    private final boolean buttonEnabled;
    private final String buttonText;
    private final String contentKey;
    private final int iconRes;
    private final int iconTint;
    private final String id;
    private final Function0<Unit> onAction;
    private final int progress;
    private final int progressMax;
    private final String rightText;
    private final boolean showCheck;
    private final String subtitle;
    private final String title;

    public static /* synthetic */ MetaRow copy$default(MetaRow metaRow, String str, int i, int i2, String str2, String str3, int i3, int i4, String str4, boolean z, String str5, boolean z2, String str6, Function0 function0, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            str = metaRow.id;
        }
        return metaRow.copy(str, (i5 & 2) != 0 ? metaRow.iconRes : i, (i5 & 4) != 0 ? metaRow.iconTint : i2, (i5 & 8) != 0 ? metaRow.title : str2, (i5 & 16) != 0 ? metaRow.subtitle : str3, (i5 & 32) != 0 ? metaRow.progress : i3, (i5 & 64) != 0 ? metaRow.progressMax : i4, (i5 & 128) != 0 ? metaRow.buttonText : str4, (i5 & 256) != 0 ? metaRow.buttonEnabled : z, (i5 & 512) != 0 ? metaRow.rightText : str5, (i5 & 1024) != 0 ? metaRow.showCheck : z2, (i5 & 2048) != 0 ? metaRow.contentKey : str6, (i5 & 4096) != 0 ? metaRow.onAction : function0);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component10, reason: from getter */
    public final String getRightText() {
        return this.rightText;
    }

    /* renamed from: component11, reason: from getter */
    public final boolean getShowCheck() {
        return this.showCheck;
    }

    /* renamed from: component12, reason: from getter */
    public final String getContentKey() {
        return this.contentKey;
    }

    public final Function0<Unit> component13() {
        return this.onAction;
    }

    /* renamed from: component2, reason: from getter */
    public final int getIconRes() {
        return this.iconRes;
    }

    /* renamed from: component3, reason: from getter */
    public final int getIconTint() {
        return this.iconTint;
    }

    /* renamed from: component4, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    /* renamed from: component5, reason: from getter */
    public final String getSubtitle() {
        return this.subtitle;
    }

    /* renamed from: component6, reason: from getter */
    public final int getProgress() {
        return this.progress;
    }

    /* renamed from: component7, reason: from getter */
    public final int getProgressMax() {
        return this.progressMax;
    }

    /* renamed from: component8, reason: from getter */
    public final String getButtonText() {
        return this.buttonText;
    }

    /* renamed from: component9, reason: from getter */
    public final boolean getButtonEnabled() {
        return this.buttonEnabled;
    }

    public final MetaRow copy(String id, int iconRes, int iconTint, String title, String subtitle, int progress, int progressMax, String buttonText, boolean buttonEnabled, String rightText, boolean showCheck, String contentKey, Function0<Unit> onAction) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        Intrinsics.checkNotNullParameter(contentKey, "contentKey");
        Intrinsics.checkNotNullParameter(onAction, "onAction");
        return new MetaRow(id, iconRes, iconTint, title, subtitle, progress, progressMax, buttonText, buttonEnabled, rightText, showCheck, contentKey, onAction);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MetaRow)) {
            return false;
        }
        MetaRow metaRow = (MetaRow) other;
        return Intrinsics.areEqual(this.id, metaRow.id) && this.iconRes == metaRow.iconRes && this.iconTint == metaRow.iconTint && Intrinsics.areEqual(this.title, metaRow.title) && Intrinsics.areEqual(this.subtitle, metaRow.subtitle) && this.progress == metaRow.progress && this.progressMax == metaRow.progressMax && Intrinsics.areEqual(this.buttonText, metaRow.buttonText) && this.buttonEnabled == metaRow.buttonEnabled && Intrinsics.areEqual(this.rightText, metaRow.rightText) && this.showCheck == metaRow.showCheck && Intrinsics.areEqual(this.contentKey, metaRow.contentKey) && Intrinsics.areEqual(this.onAction, metaRow.onAction);
    }

    public int hashCode() {
        int iHashCode = ((((((((((((this.id.hashCode() * 31) + Integer.hashCode(this.iconRes)) * 31) + Integer.hashCode(this.iconTint)) * 31) + this.title.hashCode()) * 31) + this.subtitle.hashCode()) * 31) + Integer.hashCode(this.progress)) * 31) + Integer.hashCode(this.progressMax)) * 31;
        String str = this.buttonText;
        int iHashCode2 = (((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + Boolean.hashCode(this.buttonEnabled)) * 31;
        String str2 = this.rightText;
        return ((((((iHashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31) + Boolean.hashCode(this.showCheck)) * 31) + this.contentKey.hashCode()) * 31) + this.onAction.hashCode();
    }

    public String toString() {
        return "MetaRow(id=" + this.id + ", iconRes=" + this.iconRes + ", iconTint=" + this.iconTint + ", title=" + this.title + ", subtitle=" + this.subtitle + ", progress=" + this.progress + ", progressMax=" + this.progressMax + ", buttonText=" + this.buttonText + ", buttonEnabled=" + this.buttonEnabled + ", rightText=" + this.rightText + ", showCheck=" + this.showCheck + ", contentKey=" + this.contentKey + ", onAction=" + this.onAction + ")";
    }

    public MetaRow(String id, int i, int i2, String title, String subtitle, int i3, int i4, String str, boolean z, String str2, boolean z2, String contentKey, Function0<Unit> onAction) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(subtitle, "subtitle");
        Intrinsics.checkNotNullParameter(contentKey, "contentKey");
        Intrinsics.checkNotNullParameter(onAction, "onAction");
        this.id = id;
        this.iconRes = i;
        this.iconTint = i2;
        this.title = title;
        this.subtitle = subtitle;
        this.progress = i3;
        this.progressMax = i4;
        this.buttonText = str;
        this.buttonEnabled = z;
        this.rightText = str2;
        this.showCheck = z2;
        this.contentKey = contentKey;
        this.onAction = onAction;
    }

    public final String getId() {
        return this.id;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    public final int getIconTint() {
        return this.iconTint;
    }

    public final String getTitle() {
        return this.title;
    }

    public final String getSubtitle() {
        return this.subtitle;
    }

    public final int getProgress() {
        return this.progress;
    }

    public final int getProgressMax() {
        return this.progressMax;
    }

    public final String getButtonText() {
        return this.buttonText;
    }

    public final boolean getButtonEnabled() {
        return this.buttonEnabled;
    }

    public final String getRightText() {
        return this.rightText;
    }

    public final boolean getShowCheck() {
        return this.showCheck;
    }

    public /* synthetic */ MetaRow(String str, int i, int i2, String str2, String str3, int i3, int i4, String str4, boolean z, String str5, boolean z2, String str6, Function0 function0, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, i, i2, str2, str3, (i5 & 32) != 0 ? 0 : i3, (i5 & 64) != 0 ? 0 : i4, (i5 & 128) != 0 ? null : str4, (i5 & 256) != 0 ? true : z, (i5 & 512) != 0 ? null : str5, (i5 & 1024) != 0 ? false : z2, (i5 & 2048) != 0 ? "" : str6, (i5 & 4096) != 0 ? new Function0() { // from class: com.championship.warriors.iron.legacy.presentation.common.MetaRow$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        } : function0);
    }

    public final String getContentKey() {
        return this.contentKey;
    }

    public final Function0<Unit> getOnAction() {
        return this.onAction;
    }
}
