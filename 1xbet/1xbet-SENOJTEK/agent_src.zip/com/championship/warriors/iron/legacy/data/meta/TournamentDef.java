package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\n0\tHÆ\u0003J7\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0003\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tHÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÖ\u0001J\t\u0010\u001e\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u001f"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/TournamentDef;", "", "id", "", "nameRes", "", "config", "Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "rounds", "", "Lcom/championship/warriors/iron/legacy/data/meta/TournamentRoundDef;", "<init>", "(Ljava/lang/String;ILcom/championship/warriors/iron/legacy/runner/RunConfig;Ljava/util/List;)V", "getId", "()Ljava/lang/String;", "getNameRes", "()I", "getConfig", "()Lcom/championship/warriors/iron/legacy/runner/RunConfig;", "getRounds", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class TournamentDef {
    private final RunConfig config;
    private final String id;
    private final int nameRes;
    private final List<TournamentRoundDef> rounds;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ TournamentDef copy$default(TournamentDef tournamentDef, String str, int i, RunConfig runConfig, List list, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = tournamentDef.id;
        }
        if ((i2 & 2) != 0) {
            i = tournamentDef.nameRes;
        }
        if ((i2 & 4) != 0) {
            runConfig = tournamentDef.config;
        }
        if ((i2 & 8) != 0) {
            list = tournamentDef.rounds;
        }
        return tournamentDef.copy(str, i, runConfig, list);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final int getNameRes() {
        return this.nameRes;
    }

    /* renamed from: component3, reason: from getter */
    public final RunConfig getConfig() {
        return this.config;
    }

    public final List<TournamentRoundDef> component4() {
        return this.rounds;
    }

    public final TournamentDef copy(String id, int nameRes, RunConfig config, List<TournamentRoundDef> rounds) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(rounds, "rounds");
        return new TournamentDef(id, nameRes, config, rounds);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TournamentDef)) {
            return false;
        }
        TournamentDef tournamentDef = (TournamentDef) other;
        return Intrinsics.areEqual(this.id, tournamentDef.id) && this.nameRes == tournamentDef.nameRes && Intrinsics.areEqual(this.config, tournamentDef.config) && Intrinsics.areEqual(this.rounds, tournamentDef.rounds);
    }

    public int hashCode() {
        return (((((this.id.hashCode() * 31) + Integer.hashCode(this.nameRes)) * 31) + this.config.hashCode()) * 31) + this.rounds.hashCode();
    }

    public String toString() {
        return "TournamentDef(id=" + this.id + ", nameRes=" + this.nameRes + ", config=" + this.config + ", rounds=" + this.rounds + ")";
    }

    public TournamentDef(String id, int i, RunConfig config, List<TournamentRoundDef> rounds) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(config, "config");
        Intrinsics.checkNotNullParameter(rounds, "rounds");
        this.id = id;
        this.nameRes = i;
        this.config = config;
        this.rounds = rounds;
    }

    public final String getId() {
        return this.id;
    }

    public final int getNameRes() {
        return this.nameRes;
    }

    public final RunConfig getConfig() {
        return this.config;
    }

    public final List<TournamentRoundDef> getRounds() {
        return this.rounds;
    }
}
