package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import com.championship.warriors.iron.legacy.R;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/MissionCatalog;", "", "<init>", "()V", "missions", "", "Lcom/championship/warriors/iron/legacy/data/meta/MissionDef;", "getMissions", "()Ljava/util/List;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MissionCatalog {
    public static final MissionCatalog INSTANCE = new MissionCatalog();
    private static final List<MissionDef> missions = CollectionsKt.listOf((Object[]) new MissionDef[]{new MissionDef("m_dist_1000", MissionMetric.DISTANCE_TOTAL, 1000, 150, R.string.m_distance), new MissionDef("m_coins_100", MissionMetric.COINS_TOTAL, 100, 120, R.string.m_coins), new MissionDef("m_obstacles_50", MissionMetric.OBSTACLES_TOTAL, 50, 100, R.string.m_obstacles), new MissionDef("m_power_3", MissionMetric.POWERUPS_TOTAL, 3, 90, R.string.m_powerups), new MissionDef("m_survive_60", MissionMetric.SURVIVE_SECONDS, 60, 140, R.string.m_survive), new MissionDef("m_score_3000", MissionMetric.SCORE_SINGLE, PathInterpolatorCompat.MAX_NUM_POINTS, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION, R.string.m_score), new MissionDef("m_runs_10", MissionMetric.RUNS_TOTAL, 10, 130, R.string.m_runs), new MissionDef("m_tokens_10", MissionMetric.TOKENS_TOTAL, 10, 220, R.string.m_tokens)});

    private MissionCatalog() {
    }

    public final List<MissionDef> getMissions() {
        return missions;
    }
}
