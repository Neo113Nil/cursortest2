package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.LinearProgressIndicator;

/* loaded from: classes.dex */
public final class ItemMetaCardBinding implements ViewBinding {
    public final MaterialButton actionButton;
    public final ImageView icon;
    public final LinearProgressIndicator progressBar;
    public final TextView rightValue;
    private final MaterialCardView rootView;
    public final ImageView statusIcon;
    public final TextView subtitle;
    public final TextView title;

    private ItemMetaCardBinding(MaterialCardView materialCardView, MaterialButton materialButton, ImageView imageView, LinearProgressIndicator linearProgressIndicator, TextView textView, ImageView imageView2, TextView textView2, TextView textView3) {
        this.rootView = materialCardView;
        this.actionButton = materialButton;
        this.icon = imageView;
        this.progressBar = linearProgressIndicator;
        this.rightValue = textView;
        this.statusIcon = imageView2;
        this.subtitle = textView2;
        this.title = textView3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ItemMetaCardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ItemMetaCardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_meta_card, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static ItemMetaCardBinding bind(View view) {
        int i = R.id.actionButton;
        MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
        if (materialButton != null) {
            i = R.id.icon;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView != null) {
                i = R.id.progressBar;
                LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) ViewBindings.findChildViewById(view, i);
                if (linearProgressIndicator != null) {
                    i = R.id.rightValue;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView != null) {
                        i = R.id.statusIcon;
                        ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                        if (imageView2 != null) {
                            i = R.id.subtitle;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                            if (textView2 != null) {
                                i = R.id.title;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView3 != null) {
                                    return new ItemMetaCardBinding((MaterialCardView) view, materialButton, imageView, linearProgressIndicator, textView, imageView2, textView2, textView3);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
