package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/Booster;", "", "<init>", "(Ljava/lang/String;I)V", "SHIELD", "MAGNET", "SPEED", "DOUBLE", "SLOWMO", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Booster {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ Booster[] $VALUES;
    public static final Booster SHIELD = new Booster("SHIELD", 0);
    public static final Booster MAGNET = new Booster("MAGNET", 1);
    public static final Booster SPEED = new Booster("SPEED", 2);
    public static final Booster DOUBLE = new Booster("DOUBLE", 3);
    public static final Booster SLOWMO = new Booster("SLOWMO", 4);

    private static final /* synthetic */ Booster[] $values() {
        return new Booster[]{SHIELD, MAGNET, SPEED, DOUBLE, SLOWMO};
    }

    public static EnumEntries<Booster> getEntries() {
        return $ENTRIES;
    }

    public static Booster valueOf(String str) {
        return (Booster) Enum.valueOf(Booster.class, str);
    }

    public static Booster[] values() {
        return (Booster[]) $VALUES.clone();
    }

    static {
        Booster[] boosterArr$values = $values();
        $VALUES = boosterArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(boosterArr$values);
    }

    private Booster(String str, int i) {
    }
}
