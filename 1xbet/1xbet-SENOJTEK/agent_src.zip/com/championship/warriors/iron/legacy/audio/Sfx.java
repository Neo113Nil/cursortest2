package com.championship.warriors.iron.legacy.audio;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: AudioController.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0014\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u001b\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018¨\u0006\u0019"}, d2 = {"Lcom/championship/warriors/iron/legacy/audio/Sfx;", "", "resId", "", "volume", "", "<init>", "(Ljava/lang/String;IIF)V", "getResId", "()I", "getVolume", "()F", "BUTTON", "FOOTSTEP", "JUMP", "SLIDE", "COLLISION", "COIN", "POWERUP", "SHIELD", "DOUBLE", "CHECKPOINT", "REWARD", "VICTORY", "DEFEAT", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Sfx {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ Sfx[] $VALUES;
    public static final Sfx COLLISION;
    public static final Sfx DOUBLE;
    private final int resId;
    private final float volume;
    public static final Sfx BUTTON = new Sfx("BUTTON", 0, R.raw.sfx_button, 0.0f, 2, null);
    public static final Sfx FOOTSTEP = new Sfx("FOOTSTEP", 1, R.raw.sfx_footstep, 0.3f);
    public static final Sfx JUMP = new Sfx("JUMP", 2, R.raw.sfx_jump, 0.0f, 2, null);
    public static final Sfx SLIDE = new Sfx("SLIDE", 3, R.raw.sfx_slide, 0.0f, 2, null);
    public static final Sfx COIN = new Sfx("COIN", 5, R.raw.sfx_coin, 0.75f);
    public static final Sfx POWERUP = new Sfx("POWERUP", 6, R.raw.sfx_powerup, 0.0f, 2, null);
    public static final Sfx SHIELD = new Sfx("SHIELD", 7, R.raw.sfx_shield, 0.0f, 2, null);
    public static final Sfx CHECKPOINT = new Sfx("CHECKPOINT", 9, R.raw.sfx_checkpoint, 0.0f, 2, null);
    public static final Sfx REWARD = new Sfx("REWARD", 10, R.raw.sfx_reward, 0.0f, 2, null);
    public static final Sfx VICTORY = new Sfx("VICTORY", 11, R.raw.sfx_victory, 0.0f, 2, null);
    public static final Sfx DEFEAT = new Sfx("DEFEAT", 12, R.raw.sfx_defeat, 0.0f, 2, null);

    private static final /* synthetic */ Sfx[] $values() {
        return new Sfx[]{BUTTON, FOOTSTEP, JUMP, SLIDE, COLLISION, COIN, POWERUP, SHIELD, DOUBLE, CHECKPOINT, REWARD, VICTORY, DEFEAT};
    }

    public static EnumEntries<Sfx> getEntries() {
        return $ENTRIES;
    }

    public static Sfx valueOf(String str) {
        return (Sfx) Enum.valueOf(Sfx.class, str);
    }

    public static Sfx[] values() {
        return (Sfx[]) $VALUES.clone();
    }

    private Sfx(String str, int i, int i2, float f) {
        this.resId = i2;
        this.volume = f;
    }

    /* synthetic */ Sfx(String str, int i, int i2, float f, int i3, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, i, i2, (i3 & 2) != 0 ? 1.0f : f);
    }

    public final int getResId() {
        return this.resId;
    }

    public final float getVolume() {
        return this.volume;
    }

    static {
        DefaultConstructorMarker defaultConstructorMarker = null;
        COLLISION = new Sfx("COLLISION", 4, R.raw.sfx_collision, 0.0f, 2, defaultConstructorMarker);
        DOUBLE = new Sfx("DOUBLE", 8, R.raw.sfx_double, 0.0f, 2, defaultConstructorMarker);
        Sfx[] sfxArr$values = $values();
        $VALUES = sfxArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(sfxArr$values);
    }
}
