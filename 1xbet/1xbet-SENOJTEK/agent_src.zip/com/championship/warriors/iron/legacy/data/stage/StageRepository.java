package com.championship.warriors.iron.legacy.data.stage;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.data.stage.StageGoal;
import com.championship.warriors.iron.legacy.runner.RunConfig;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* compiled from: StageRepository.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\t\u001a\u0004\u0018\u00010\u00062\u0006\u0010\n\u001a\u00020\u000bR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\f\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u000e¨\u0006\u0011"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/stage/StageRepository;", "", "<init>", "()V", "stages", "", "Lcom/championship/warriors/iron/legacy/data/stage/StageData;", "getStages", "()Ljava/util/List;", "stageById", "id", "", "firstStageId", "getFirstStageId", "()I", "lastStageId", "getLastStageId", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class StageRepository {
    private final List<StageData> stages = CollectionsKt.listOf((Object[]) new StageData[]{new StageData(1, R.string.stage_1, R.string.env_1, R.color.stage_training, 0, new RunConfig(3, 8.0f, 13.0f, 0.9f, 22.0f, 14.0f, 0.0f, 0.12f, 0.7f, 700.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(TypedValues.TransitionType.TYPE_DURATION), new StageGoal.Collect(15), new StageGoal.Score(1000)})), new StageData(2, R.string.stage_2, R.string.env_2, R.color.stage_academy, 1, new RunConfig(3, 9.5f, 16.0f, 1.1f, 20.0f, 12.0f, 0.12f, 0.12f, 0.65f, 1000.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(1000), new StageGoal.Collect(25), new StageGoal.Avoid(45)})), new StageData(3, R.string.stage_3, R.string.env_3, R.color.stage_city, 2, new RunConfig(3, 11.0f, 19.0f, 1.3f, 18.0f, 11.0f, 0.28f, 0.12f, 0.6f, 1300.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(1300), new StageGoal.Score(2800), new StageGoal.Collect(35)})), new StageData(4, R.string.stage_4, R.string.env_4, R.color.stage_pro, 3, new RunConfig(3, 12.5f, 22.0f, 1.5f, 16.0f, 10.0f, 0.42f, 0.11f, 0.55f, 1600.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(1600), new StageGoal.Avoid(90), new StageGoal.Score(3600)})), new StageData(5, R.string.stage_5, R.string.env_5, R.color.stage_champ, 4, new RunConfig(3, 14.0f, 25.0f, 1.7f, 15.0f, 9.0f, 0.52f, 0.1f, 0.5f, 2000.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(2000), new StageGoal.Collect(55), new StageGoal.Score(5000)})), new StageData(6, R.string.stage_6, R.string.env_6, R.color.stage_elite, 5, new RunConfig(3, 15.5f, 28.0f, 1.9f, 14.0f, 8.5f, 0.6f, 0.1f, 0.48f, 2500.0f), CollectionsKt.listOf((Object[]) new StageGoal[]{new StageGoal.Distance(2500), new StageGoal.Avoid(140), new StageGoal.Score(7000)}))});

    public final List<StageData> getStages() {
        return this.stages;
    }

    public final StageData stageById(int id) {
        Object next;
        Iterator<T> it = this.stages.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((StageData) next).getId() == id) {
                break;
            }
        }
        return (StageData) next;
    }

    public final int getFirstStageId() {
        return ((StageData) CollectionsKt.first((List) this.stages)).getId();
    }

    public final int getLastStageId() {
        return ((StageData) CollectionsKt.last((List) this.stages)).getId();
    }
}
