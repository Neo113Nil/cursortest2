package com.championship.warriors.iron.legacy.runner;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RunnerModels.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000e\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u001a\u0010\t\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u000f\"\u0004\b\u0014\u0010\u0015¨\u0006\u0016"}, d2 = {"Lcom/championship/warriors/iron/legacy/runner/Popup;", "", "text", "", "col", "", "row", TypedValues.Custom.S_COLOR, "", "life", "<init>", "(Ljava/lang/String;FFIF)V", "getText", "()Ljava/lang/String;", "getCol", "()F", "getRow", "getColor", "()I", "getLife", "setLife", "(F)V", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Popup {
    private final float col;
    private final int color;
    private float life;
    private final float row;
    private final String text;

    public Popup(String text, float f, float f2, int i, float f3) {
        Intrinsics.checkNotNullParameter(text, "text");
        this.text = text;
        this.col = f;
        this.row = f2;
        this.color = i;
        this.life = f3;
    }

    public final float getCol() {
        return this.col;
    }

    public final int getColor() {
        return this.color;
    }

    public final float getLife() {
        return this.life;
    }

    public final float getRow() {
        return this.row;
    }

    public final String getText() {
        return this.text;
    }

    public final void setLife(float f) {
        this.life = f;
    }
}
