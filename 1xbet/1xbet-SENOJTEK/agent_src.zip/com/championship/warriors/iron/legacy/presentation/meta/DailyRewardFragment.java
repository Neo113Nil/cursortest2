package com.championship.warriors.iron.legacy.presentation.meta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.navigation.fragment.FragmentKt;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.audio.Sfx;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.meta.DailyRewardTable;
import com.championship.warriors.iron.legacy.data.player.PlayerRepository;
import com.championship.warriors.iron.legacy.databinding.FragmentDailyBinding;
import com.championship.warriors.iron.legacy.databinding.ItemDailyTileBinding;
import com.championship.warriors.iron.legacy.presentation.common.BaseFragment;
import kotlin.Metadata;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: DailyRewardFragment.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u00020\u0006H\u0016J\b\u0010\f\u001a\u00020\u0006H\u0002¨\u0006\r"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/meta/DailyRewardFragment;", "Lcom/championship/warriors/iron/legacy/presentation/common/BaseFragment;", "Lcom/championship/warriors/iron/legacy/databinding/FragmentDailyBinding;", "<init>", "()V", "onViewCreated", "", "view", "Landroid/view/View;", "savedInstanceState", "Landroid/os/Bundle;", "onStart", "refresh", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class DailyRewardFragment extends BaseFragment<FragmentDailyBinding> {

    /* compiled from: DailyRewardFragment.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.presentation.meta.DailyRewardFragment$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function3<LayoutInflater, ViewGroup, Boolean, FragmentDailyBinding> {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        AnonymousClass1() {
            super(3, FragmentDailyBinding.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/championship/warriors/iron/legacy/databinding/FragmentDailyBinding;", 0);
        }

        public final FragmentDailyBinding invoke(LayoutInflater p0, ViewGroup viewGroup, boolean z) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return FragmentDailyBinding.inflate(p0, viewGroup, z);
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ FragmentDailyBinding invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
            return invoke(layoutInflater, viewGroup, bool.booleanValue());
        }
    }

    public DailyRewardFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(view, "view");
        super.onViewCreated(view, savedInstanceState);
        getBinding().backButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.DailyRewardFragment$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                DailyRewardFragment.onViewCreated$lambda$0(this.f$0, view2);
            }
        });
        getBinding().claimButton.setOnClickListener(new View.OnClickListener() { // from class: com.championship.warriors.iron.legacy.presentation.meta.DailyRewardFragment$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                DailyRewardFragment.onViewCreated$lambda$1(this.f$0, view2);
            }
        });
        refresh();
    }

    static final void onViewCreated$lambda$0(DailyRewardFragment dailyRewardFragment, View view) {
        dailyRewardFragment.getAudio().play(Sfx.BUTTON);
        FragmentKt.findNavController(dailyRewardFragment).popBackStack();
    }

    static final void onViewCreated$lambda$1(DailyRewardFragment dailyRewardFragment, View view) {
        if (GameContainer.INSTANCE.getPlayer().claimDaily().getClaimed()) {
            dailyRewardFragment.getAudio().play(Sfx.REWARD);
        }
        dailyRewardFragment.refresh();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() throws IllegalStateException {
        super.onStart();
        getAudio().playMenuMusic();
    }

    private final void refresh() {
        boolean zCanClaimDaily = GameContainer.INSTANCE.getPlayer().canClaimDaily();
        LinearLayout linearLayout = null;
        int iDailyDay$default = PlayerRepository.dailyDay$default(GameContainer.INSTANCE.getPlayer(), null, 1, null);
        getBinding().streakText.setText(getString(R.string.daily_streak, Integer.valueOf(GameContainer.INSTANCE.getPlayer().current().getDailyStreak())));
        getBinding().claimButton.setEnabled(zCanClaimDaily);
        getBinding().claimButton.setAlpha(zCanClaimDaily ? 1.0f : 0.5f);
        getBinding().claimButton.setText(zCanClaimDaily ? R.string.daily_claim : R.string.daily_claimed);
        getBinding().comeBackText.setVisibility(zCanClaimDaily ? 8 : 0);
        getBinding().dayGrid.removeAllViews();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(requireContext());
        int i = 1;
        while (i < 8) {
            if (i % 4 == 1) {
                linearLayout = new LinearLayout(requireContext());
                linearLayout.setOrientation(0);
                linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                getBinding().dayGrid.addView(linearLayout);
            }
            ItemDailyTileBinding itemDailyTileBindingInflate = ItemDailyTileBinding.inflate(layoutInflaterFrom, linearLayout, true);
            Intrinsics.checkNotNullExpressionValue(itemDailyTileBindingInflate, "inflate(...)");
            itemDailyTileBindingInflate.dayLabel.setText(getString(R.string.daily_day, Integer.valueOf(i)));
            itemDailyTileBindingInflate.coinValue.setText(String.valueOf(DailyRewardTable.INSTANCE.getCoins().get(i - 1).intValue()));
            boolean z = i < iDailyDay$default || (i == iDailyDay$default && !zCanClaimDaily);
            itemDailyTileBindingInflate.check.setVisibility(z ? 0 : 8);
            itemDailyTileBindingInflate.getRoot().setAlpha(i == iDailyDay$default ? 1.0f : z ? 0.85f : 0.6f);
            itemDailyTileBindingInflate.getRoot().setBackgroundResource((i == iDailyDay$default && zCanClaimDaily) ? R.drawable.bg_card_accent : R.drawable.bg_card);
            i++;
        }
        for (int i2 = 0; i2 < 1; i2++) {
            if (linearLayout != null) {
                View view = new View(requireContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, 1, 1.0f);
                layoutParams.setMargins(10, 0, 10, 0);
                view.setLayoutParams(layoutParams);
                linearLayout.addView(view);
            }
        }
    }
}
