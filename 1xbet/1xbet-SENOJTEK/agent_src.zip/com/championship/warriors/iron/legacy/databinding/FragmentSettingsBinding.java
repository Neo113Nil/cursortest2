package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;

/* loaded from: classes.dex */
public final class FragmentSettingsBinding implements ViewBinding {
    public final ImageButton backButton;
    public final MaterialSwitch musicSwitch;
    public final MaterialButton resetButton;
    private final FrameLayout rootView;
    public final MaterialSwitch sfxSwitch;

    private FragmentSettingsBinding(FrameLayout frameLayout, ImageButton imageButton, MaterialSwitch materialSwitch, MaterialButton materialButton, MaterialSwitch materialSwitch2) {
        this.rootView = frameLayout;
        this.backButton = imageButton;
        this.musicSwitch = materialSwitch;
        this.resetButton = materialButton;
        this.sfxSwitch = materialSwitch2;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentSettingsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentSettingsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_settings, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentSettingsBinding bind(View view) {
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.musicSwitch;
            MaterialSwitch materialSwitch = (MaterialSwitch) ViewBindings.findChildViewById(view, i);
            if (materialSwitch != null) {
                i = R.id.resetButton;
                MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
                if (materialButton != null) {
                    i = R.id.sfxSwitch;
                    MaterialSwitch materialSwitch2 = (MaterialSwitch) ViewBindings.findChildViewById(view, i);
                    if (materialSwitch2 != null) {
                        return new FragmentSettingsBinding((FrameLayout) view, imageButton, materialSwitch, materialButton, materialSwitch2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
