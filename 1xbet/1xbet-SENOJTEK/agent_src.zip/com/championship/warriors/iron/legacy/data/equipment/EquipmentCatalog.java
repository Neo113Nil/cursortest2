package com.championship.warriors.iron.legacy.data.equipment;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.data.player.StatType;
import com.championship.warriors.iron.legacy.presentation.game.GameView;
import com.google.android.material.card.MaterialCardViewHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: Equipment.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\t\u001a\u0004\u0018\u00010\u00062\u0006\u0010\n\u001a\u00020\u000bJ\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\r\u001a\u00020\u000eR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001d\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000b0\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u0013"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCatalog;", "", "<init>", "()V", "items", "", "Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentItem;", "getItems", "()Ljava/util/List;", "byId", "id", "", "byCategory", "category", "Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;", "defaultEquipped", "", "getDefaultEquipped", "()Ljava/util/Map;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class EquipmentCatalog {
    private static final Map<EquipmentCategory, String> defaultEquipped;
    public static final EquipmentCatalog INSTANCE = new EquipmentCatalog();
    private static final List<EquipmentItem> items = CollectionsKt.listOf((Object[]) new EquipmentItem[]{new EquipmentItem("jersey_classic", EquipmentCategory.JERSEY, R.string.eq_jersey_classic, 0, -12747777, StatType.CONTROL, 0.0f, true), new EquipmentItem("jersey_sky", EquipmentCategory.JERSEY, R.string.eq_jersey_sky, 350, -14032656, StatType.CONTROL, 0.04f, false, 128, null), new EquipmentItem("jersey_royal", EquipmentCategory.JERSEY, R.string.eq_jersey_royal, TypedValues.TransitionType.TYPE_DURATION, -10724128, StatType.CONTROL, 0.07f, false, 128, null), new EquipmentItem("jersey_gold", EquipmentCategory.JERSEY, R.string.eq_jersey_gold, 1400, -15043, StatType.CONTROL, 0.1f, false, 128, null), new EquipmentItem("boots_trainer", EquipmentCategory.BOOTS, R.string.eq_boots_trainer, 0, -4667418, StatType.SPEED, 0.0f, true), new EquipmentItem("boots_sprint", EquipmentCategory.BOOTS, R.string.eq_boots_sprint, 400, -12747777, StatType.SPEED, 0.04f, false, 128, null), new EquipmentItem("boots_turbo", EquipmentCategory.BOOTS, R.string.eq_boots_turbo, 850, -14032656, StatType.SPEED, 0.07f, false, 128, null), new EquipmentItem("boots_elite", EquipmentCategory.BOOTS, R.string.eq_boots_elite, 1600, -15043, StatType.SPEED, 0.11f, false, 128, null), new EquipmentItem("ball_classic", EquipmentCategory.FOOTBALL, R.string.eq_ball_classic, 0, GameView.COL_WHITE, StatType.REWARD, 0.0f, true), new EquipmentItem("ball_neon", EquipmentCategory.FOOTBALL, R.string.eq_ball_neon, MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION, -14032656, StatType.REWARD, 0.05f, false, 128, null), new EquipmentItem("ball_pro", EquipmentCategory.FOOTBALL, R.string.eq_ball_pro, 750, -8408833, StatType.REWARD, 0.08f, false, 128, null), new EquipmentItem("ball_golden", EquipmentCategory.FOOTBALL, R.string.eq_ball_golden, 1500, -15043, StatType.REWARD, 0.12f, false, 128, null), new EquipmentItem("trail_none", EquipmentCategory.TRAIL, R.string.eq_trail_none, 0, 2744560, null, 0.0f, true), new EquipmentItem("trail_cyan", EquipmentCategory.TRAIL, R.string.eq_trail_cyan, MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION, -14032656, null, 0.0f, false, 128, null), new EquipmentItem("trail_flame", EquipmentCategory.TRAIL, R.string.eq_trail_flame, 600, -11761921, null, 0.0f, false, 128, null), new EquipmentItem("trail_gold", EquipmentCategory.TRAIL, R.string.eq_trail_gold, 1200, -15043, null, 0.0f, false, 128, null)});

    private EquipmentCatalog() {
    }

    public final List<EquipmentItem> getItems() {
        return items;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x020d, code lost:
    
        r2.put(r1, r5.getId());
     */
    static {
        EnumEntries<EquipmentCategory> entries = EquipmentCategory.getEntries();
        LinkedHashMap linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(entries, 10)), 16));
        Iterator<EquipmentCategory> it = entries.iterator();
        while (it.hasNext()) {
            EquipmentCategory next = it.next();
            LinkedHashMap linkedHashMap2 = linkedHashMap;
            for (EquipmentItem equipmentItem : INSTANCE.byCategory(next)) {
                if (equipmentItem.getDefaultOwned()) {
                    break;
                }
            }
            throw new NoSuchElementException("Collection contains no element matching the predicate.");
        }
        defaultEquipped = linkedHashMap;
    }

    public final EquipmentItem byId(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = items.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((EquipmentItem) next).getId(), id)) {
                break;
            }
        }
        return (EquipmentItem) next;
    }

    public final List<EquipmentItem> byCategory(EquipmentCategory category) {
        Intrinsics.checkNotNullParameter(category, "category");
        List<EquipmentItem> list = items;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (((EquipmentItem) obj).getCategory() == category) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    public final Map<EquipmentCategory, String> getDefaultEquipped() {
        return defaultEquipped;
    }
}
