package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/AchievementCatalog;", "", "<init>", "()V", "achievements", "", "Lcom/championship/warriors/iron/legacy/data/meta/AchievementDef;", "getAchievements", "()Ljava/util/List;", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class AchievementCatalog {
    public static final AchievementCatalog INSTANCE = new AchievementCatalog();
    private static final List<AchievementDef> achievements = CollectionsKt.listOf((Object[]) new AchievementDef[]{new AchievementDef("first_run", R.string.a_first_run, R.string.a_first_run_desc, R.drawable.ic_flag, 1, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$0((PlayerState) obj));
        }
    }), new AchievementDef("marathon", R.string.a_marathon, R.string.a_marathon_desc, R.drawable.ic_distance, 10000, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$1((PlayerState) obj));
        }
    }), new AchievementDef("speed_demon", R.string.a_speed_demon, R.string.a_speed_demon_desc, R.drawable.ic_bolt, 24, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$2((PlayerState) obj));
        }
    }), new AchievementDef("coin_collector", R.string.a_coin_collector, R.string.a_coin_collector_desc, R.drawable.ic_coin, 1000, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$3((PlayerState) obj));
        }
    }), new AchievementDef("perfect_runner", R.string.a_perfect_runner, R.string.a_perfect_runner_desc, R.drawable.ic_star, 25, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$4((PlayerState) obj));
        }
    }), new AchievementDef("powerup_master", R.string.a_powerup_master, R.string.a_powerup_master_desc, R.drawable.ic_shield, 25, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$5((PlayerState) obj));
        }
    }), new AchievementDef("championship_runner", R.string.a_championship, R.string.a_championship_desc, R.drawable.ic_trophy, 1, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$6((PlayerState) obj));
        }
    }), new AchievementDef("elite_runner", R.string.a_elite, R.string.a_elite_desc, R.drawable.ic_medal, 1, new Function1() { // from class: com.championship.warriors.iron.legacy.data.meta.AchievementCatalog$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            return Integer.valueOf(AchievementCatalog.achievements$lambda$7((PlayerState) obj));
        }
    })});

    private AchievementCatalog() {
    }

    public final List<AchievementDef> getAchievements() {
        return achievements;
    }

    static final int achievements$lambda$0(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getTotalRuns();
    }

    static final int achievements$lambda$1(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getTotalDistance();
    }

    static final int achievements$lambda$2(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getTopSpeed();
    }

    static final int achievements$lambda$3(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getTotalCoins();
    }

    static final int achievements$lambda$4(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getMaxCombo();
    }

    static final int achievements$lambda$5(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getTotalPowerups();
    }

    static final int achievements$lambda$6(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.starsFor(5) > 0 ? 1 : 0;
    }

    static final int achievements$lambda$7(PlayerState it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.starsFor(6) > 0 ? 1 : 0;
    }
}
