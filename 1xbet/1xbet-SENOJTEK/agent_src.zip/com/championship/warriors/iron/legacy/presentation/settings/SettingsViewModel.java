package com.championship.warriors.iron.legacy.presentation.settings;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModel;
import com.championship.warriors.iron.legacy.core.GameContainer;
import com.championship.warriors.iron.legacy.data.GameSettings;
import kotlin.Metadata;
import kotlinx.coroutines.flow.StateFlow;

/* compiled from: SettingsViewModel.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\r\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\u000e\u001a\u00020\nR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000f"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/settings/SettingsViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "settings", "Lkotlinx/coroutines/flow/StateFlow;", "Lcom/championship/warriors/iron/legacy/data/GameSettings;", "getSettings", "()Lkotlinx/coroutines/flow/StateFlow;", "setMusic", "", "enabled", "", "setSfx", "resetProgress", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class SettingsViewModel extends ViewModel {
    private final StateFlow<GameSettings> settings = GameContainer.INSTANCE.getSettings().getSettings();

    public final StateFlow<GameSettings> getSettings() {
        return this.settings;
    }

    public final void setMusic(boolean enabled) {
        GameContainer.INSTANCE.getSettings().setMusic(enabled);
    }

    public final void setSfx(boolean enabled) {
        GameContainer.INSTANCE.getSettings().setSfx(enabled);
    }

    public final void resetProgress() {
        GameContainer.INSTANCE.getPlayer().resetAll();
    }
}
