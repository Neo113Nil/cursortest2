package com.championship.warriors.iron.legacy.core.splash;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* compiled from: SplashActivity.kt */
@Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final /* synthetic */ class SplashActivity$_window$1$4 extends FunctionReferenceImpl implements Function0<Unit> {
    SplashActivity$_window$1$4(Object obj) {
        super(0, obj, SplashActivity.class, "_accept", "_accept()V", 0);
    }

    @Override // kotlin.jvm.functions.Function0
    public /* bridge */ /* synthetic */ Unit invoke() {
        invoke2();
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2() {
        ((SplashActivity) this.receiver)._accept();
    }
}
