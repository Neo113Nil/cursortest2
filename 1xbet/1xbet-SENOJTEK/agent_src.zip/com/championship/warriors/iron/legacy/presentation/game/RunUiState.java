package com.championship.warriors.iron.legacy.presentation.game;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: GameViewModel.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b4\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u009d\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\u0005\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0003¢\u0006\u0004\b\u0013\u0010\u0014J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\t\u0010'\u001a\u00020\u0005HÆ\u0003J\t\u0010(\u001a\u00020\u0005HÆ\u0003J\t\u0010)\u001a\u00020\u0005HÆ\u0003J\t\u0010*\u001a\u00020\u0005HÆ\u0003J\t\u0010+\u001a\u00020\u0005HÆ\u0003J\t\u0010,\u001a\u00020\u0003HÆ\u0003J\t\u0010-\u001a\u00020\u0005HÆ\u0003J\t\u0010.\u001a\u00020\u0003HÆ\u0003J\t\u0010/\u001a\u00020\u0005HÆ\u0003J\t\u00100\u001a\u00020\u0003HÆ\u0003J\t\u00101\u001a\u00020\u0003HÆ\u0003J\t\u00102\u001a\u00020\u0003HÆ\u0003J\t\u00103\u001a\u00020\u0003HÆ\u0003J\t\u00104\u001a\u00020\u0003HÆ\u0003J\u009f\u0001\u00105\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u00032\b\b\u0002\u0010\u0011\u001a\u00020\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u0003HÆ\u0001J\u0013\u00106\u001a\u00020\u00032\b\u00107\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00108\u001a\u00020\u0005HÖ\u0001J\t\u00109\u001a\u00020:HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0018R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0018R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0018R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0018R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0018R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0016R\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0018R\u0011\u0010\u000e\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0016R\u0011\u0010\u000f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0016R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0016R\u0011\u0010\u0011\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0016R\u0011\u0010\u0012\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u0016¨\u0006;"}, d2 = {"Lcom/championship/warriors/iron/legacy/presentation/game/RunUiState;", "", "loaded", "", "score", "", "distance", "lines", "coins", "combo", "comboActive", TypedValues.AttributesType.S_TARGET, "timeTrial", "timeRemaining", "speed", "shield", "magnet", "double", "slowmo", "<init>", "(ZIIIIIZIZIZZZZZ)V", "getLoaded", "()Z", "getScore", "()I", "getDistance", "getLines", "getCoins", "getCombo", "getComboActive", "getTarget", "getTimeTrial", "getTimeRemaining", "getSpeed", "getShield", "getMagnet", "getDouble", "getSlowmo", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "component15", "copy", "equals", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunUiState {
    private final int coins;
    private final int combo;
    private final boolean comboActive;
    private final int distance;
    private final boolean double;
    private final int lines;
    private final boolean loaded;
    private final boolean magnet;
    private final int score;
    private final boolean shield;
    private final boolean slowmo;
    private final boolean speed;
    private final int target;
    private final int timeRemaining;
    private final boolean timeTrial;

    public RunUiState() {
        this(false, 0, 0, 0, 0, 0, false, 0, false, 0, false, false, false, false, false, 32767, null);
    }

    /* renamed from: component1, reason: from getter */
    public final boolean getLoaded() {
        return this.loaded;
    }

    /* renamed from: component10, reason: from getter */
    public final int getTimeRemaining() {
        return this.timeRemaining;
    }

    /* renamed from: component11, reason: from getter */
    public final boolean getSpeed() {
        return this.speed;
    }

    /* renamed from: component12, reason: from getter */
    public final boolean getShield() {
        return this.shield;
    }

    /* renamed from: component13, reason: from getter */
    public final boolean getMagnet() {
        return this.magnet;
    }

    /* renamed from: component14, reason: from getter */
    public final boolean getDouble() {
        return this.double;
    }

    /* renamed from: component15, reason: from getter */
    public final boolean getSlowmo() {
        return this.slowmo;
    }

    /* renamed from: component2, reason: from getter */
    public final int getScore() {
        return this.score;
    }

    /* renamed from: component3, reason: from getter */
    public final int getDistance() {
        return this.distance;
    }

    /* renamed from: component4, reason: from getter */
    public final int getLines() {
        return this.lines;
    }

    /* renamed from: component5, reason: from getter */
    public final int getCoins() {
        return this.coins;
    }

    /* renamed from: component6, reason: from getter */
    public final int getCombo() {
        return this.combo;
    }

    /* renamed from: component7, reason: from getter */
    public final boolean getComboActive() {
        return this.comboActive;
    }

    /* renamed from: component8, reason: from getter */
    public final int getTarget() {
        return this.target;
    }

    /* renamed from: component9, reason: from getter */
    public final boolean getTimeTrial() {
        return this.timeTrial;
    }

    public final RunUiState copy(boolean loaded, int score, int distance, int lines, int coins, int combo, boolean comboActive, int target, boolean timeTrial, int timeRemaining, boolean speed, boolean shield, boolean magnet, boolean z, boolean slowmo) {
        return new RunUiState(loaded, score, distance, lines, coins, combo, comboActive, target, timeTrial, timeRemaining, speed, shield, magnet, z, slowmo);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunUiState)) {
            return false;
        }
        RunUiState runUiState = (RunUiState) other;
        return this.loaded == runUiState.loaded && this.score == runUiState.score && this.distance == runUiState.distance && this.lines == runUiState.lines && this.coins == runUiState.coins && this.combo == runUiState.combo && this.comboActive == runUiState.comboActive && this.target == runUiState.target && this.timeTrial == runUiState.timeTrial && this.timeRemaining == runUiState.timeRemaining && this.speed == runUiState.speed && this.shield == runUiState.shield && this.magnet == runUiState.magnet && this.double == runUiState.double && this.slowmo == runUiState.slowmo;
    }

    public int hashCode() {
        return (((((((((((((((((((((((((((Boolean.hashCode(this.loaded) * 31) + Integer.hashCode(this.score)) * 31) + Integer.hashCode(this.distance)) * 31) + Integer.hashCode(this.lines)) * 31) + Integer.hashCode(this.coins)) * 31) + Integer.hashCode(this.combo)) * 31) + Boolean.hashCode(this.comboActive)) * 31) + Integer.hashCode(this.target)) * 31) + Boolean.hashCode(this.timeTrial)) * 31) + Integer.hashCode(this.timeRemaining)) * 31) + Boolean.hashCode(this.speed)) * 31) + Boolean.hashCode(this.shield)) * 31) + Boolean.hashCode(this.magnet)) * 31) + Boolean.hashCode(this.double)) * 31) + Boolean.hashCode(this.slowmo);
    }

    public String toString() {
        return "RunUiState(loaded=" + this.loaded + ", score=" + this.score + ", distance=" + this.distance + ", lines=" + this.lines + ", coins=" + this.coins + ", combo=" + this.combo + ", comboActive=" + this.comboActive + ", target=" + this.target + ", timeTrial=" + this.timeTrial + ", timeRemaining=" + this.timeRemaining + ", speed=" + this.speed + ", shield=" + this.shield + ", magnet=" + this.magnet + ", double=" + this.double + ", slowmo=" + this.slowmo + ")";
    }

    public RunUiState(boolean z, int i, int i2, int i3, int i4, int i5, boolean z2, int i6, boolean z3, int i7, boolean z4, boolean z5, boolean z6, boolean z7, boolean z8) {
        this.loaded = z;
        this.score = i;
        this.distance = i2;
        this.lines = i3;
        this.coins = i4;
        this.combo = i5;
        this.comboActive = z2;
        this.target = i6;
        this.timeTrial = z3;
        this.timeRemaining = i7;
        this.speed = z4;
        this.shield = z5;
        this.magnet = z6;
        this.double = z7;
        this.slowmo = z8;
    }

    public /* synthetic */ RunUiState(boolean z, int i, int i2, int i3, int i4, int i5, boolean z2, int i6, boolean z3, int i7, boolean z4, boolean z5, boolean z6, boolean z7, boolean z8, int i8, DefaultConstructorMarker defaultConstructorMarker) {
        this((i8 & 1) != 0 ? false : z, (i8 & 2) != 0 ? 0 : i, (i8 & 4) != 0 ? 0 : i2, (i8 & 8) != 0 ? 0 : i3, (i8 & 16) != 0 ? 0 : i4, (i8 & 32) != 0 ? 0 : i5, (i8 & 64) != 0 ? false : z2, (i8 & 128) != 0 ? 0 : i6, (i8 & 256) != 0 ? false : z3, (i8 & 512) != 0 ? 0 : i7, (i8 & 1024) != 0 ? false : z4, (i8 & 2048) != 0 ? false : z5, (i8 & 4096) != 0 ? false : z6, (i8 & 8192) != 0 ? false : z7, (i8 & 16384) != 0 ? false : z8);
    }

    public final boolean getLoaded() {
        return this.loaded;
    }

    public final int getScore() {
        return this.score;
    }

    public final int getDistance() {
        return this.distance;
    }

    public final int getLines() {
        return this.lines;
    }

    public final int getCoins() {
        return this.coins;
    }

    public final int getCombo() {
        return this.combo;
    }

    public final boolean getComboActive() {
        return this.comboActive;
    }

    public final int getTarget() {
        return this.target;
    }

    public final boolean getTimeTrial() {
        return this.timeTrial;
    }

    public final int getTimeRemaining() {
        return this.timeRemaining;
    }

    public final boolean getSpeed() {
        return this.speed;
    }

    public final boolean getShield() {
        return this.shield;
    }

    public final boolean getMagnet() {
        return this.magnet;
    }

    public final boolean getDouble() {
        return this.double;
    }

    public final boolean getSlowmo() {
        return this.slowmo;
    }
}
