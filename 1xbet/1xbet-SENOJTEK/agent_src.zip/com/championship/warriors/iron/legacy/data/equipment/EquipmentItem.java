package com.championship.warriors.iron.legacy.data.equipment;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.data.player.StatType;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Equipment.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u001e\b\u0086\b\u0018\u00002\u00020\u0001BM\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\u0007HÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u000bHÆ\u0003J\t\u0010&\u001a\u00020\rHÆ\u0003J\t\u0010'\u001a\u00020\u000fHÆ\u0003J[\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0003\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u000b2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u000fHÆ\u0001J\u0013\u0010)\u001a\u00020\u000f2\b\u0010*\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010+\u001a\u00020\u0007HÖ\u0001J\t\u0010,\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0017R\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0017R\u0013\u0010\n\u001a\u0004\u0018\u00010\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u000e\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001f¨\u0006-"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentItem;", "", "id", "", "category", "Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;", "nameRes", "", "cost", TypedValues.Custom.S_COLOR, "bonusStat", "Lcom/championship/warriors/iron/legacy/data/player/StatType;", "bonusPercent", "", "defaultOwned", "", "<init>", "(Ljava/lang/String;Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;IIILcom/championship/warriors/iron/legacy/data/player/StatType;FZ)V", "getId", "()Ljava/lang/String;", "getCategory", "()Lcom/championship/warriors/iron/legacy/data/equipment/EquipmentCategory;", "getNameRes", "()I", "getCost", "getColor", "getBonusStat", "()Lcom/championship/warriors/iron/legacy/data/player/StatType;", "getBonusPercent", "()F", "getDefaultOwned", "()Z", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class EquipmentItem {
    private final float bonusPercent;
    private final StatType bonusStat;
    private final EquipmentCategory category;
    private final int color;
    private final int cost;
    private final boolean defaultOwned;
    private final String id;
    private final int nameRes;

    public static /* synthetic */ EquipmentItem copy$default(EquipmentItem equipmentItem, String str, EquipmentCategory equipmentCategory, int i, int i2, int i3, StatType statType, float f, boolean z, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            str = equipmentItem.id;
        }
        if ((i4 & 2) != 0) {
            equipmentCategory = equipmentItem.category;
        }
        if ((i4 & 4) != 0) {
            i = equipmentItem.nameRes;
        }
        if ((i4 & 8) != 0) {
            i2 = equipmentItem.cost;
        }
        if ((i4 & 16) != 0) {
            i3 = equipmentItem.color;
        }
        if ((i4 & 32) != 0) {
            statType = equipmentItem.bonusStat;
        }
        if ((i4 & 64) != 0) {
            f = equipmentItem.bonusPercent;
        }
        if ((i4 & 128) != 0) {
            z = equipmentItem.defaultOwned;
        }
        float f2 = f;
        boolean z2 = z;
        int i5 = i3;
        StatType statType2 = statType;
        return equipmentItem.copy(str, equipmentCategory, i, i2, i5, statType2, f2, z2);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final EquipmentCategory getCategory() {
        return this.category;
    }

    /* renamed from: component3, reason: from getter */
    public final int getNameRes() {
        return this.nameRes;
    }

    /* renamed from: component4, reason: from getter */
    public final int getCost() {
        return this.cost;
    }

    /* renamed from: component5, reason: from getter */
    public final int getColor() {
        return this.color;
    }

    /* renamed from: component6, reason: from getter */
    public final StatType getBonusStat() {
        return this.bonusStat;
    }

    /* renamed from: component7, reason: from getter */
    public final float getBonusPercent() {
        return this.bonusPercent;
    }

    /* renamed from: component8, reason: from getter */
    public final boolean getDefaultOwned() {
        return this.defaultOwned;
    }

    public final EquipmentItem copy(String id, EquipmentCategory category, int nameRes, int cost, int color, StatType bonusStat, float bonusPercent, boolean defaultOwned) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(category, "category");
        return new EquipmentItem(id, category, nameRes, cost, color, bonusStat, bonusPercent, defaultOwned);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof EquipmentItem)) {
            return false;
        }
        EquipmentItem equipmentItem = (EquipmentItem) other;
        return Intrinsics.areEqual(this.id, equipmentItem.id) && this.category == equipmentItem.category && this.nameRes == equipmentItem.nameRes && this.cost == equipmentItem.cost && this.color == equipmentItem.color && this.bonusStat == equipmentItem.bonusStat && Float.compare(this.bonusPercent, equipmentItem.bonusPercent) == 0 && this.defaultOwned == equipmentItem.defaultOwned;
    }

    public int hashCode() {
        int iHashCode = ((((((((this.id.hashCode() * 31) + this.category.hashCode()) * 31) + Integer.hashCode(this.nameRes)) * 31) + Integer.hashCode(this.cost)) * 31) + Integer.hashCode(this.color)) * 31;
        StatType statType = this.bonusStat;
        return ((((iHashCode + (statType == null ? 0 : statType.hashCode())) * 31) + Float.hashCode(this.bonusPercent)) * 31) + Boolean.hashCode(this.defaultOwned);
    }

    public String toString() {
        return "EquipmentItem(id=" + this.id + ", category=" + this.category + ", nameRes=" + this.nameRes + ", cost=" + this.cost + ", color=" + this.color + ", bonusStat=" + this.bonusStat + ", bonusPercent=" + this.bonusPercent + ", defaultOwned=" + this.defaultOwned + ")";
    }

    public EquipmentItem(String id, EquipmentCategory category, int i, int i2, int i3, StatType statType, float f, boolean z) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(category, "category");
        this.id = id;
        this.category = category;
        this.nameRes = i;
        this.cost = i2;
        this.color = i3;
        this.bonusStat = statType;
        this.bonusPercent = f;
        this.defaultOwned = z;
    }

    public /* synthetic */ EquipmentItem(String str, EquipmentCategory equipmentCategory, int i, int i2, int i3, StatType statType, float f, boolean z, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, equipmentCategory, i, i2, i3, statType, f, (i4 & 128) != 0 ? false : z);
    }

    public final String getId() {
        return this.id;
    }

    public final EquipmentCategory getCategory() {
        return this.category;
    }

    public final int getNameRes() {
        return this.nameRes;
    }

    public final int getCost() {
        return this.cost;
    }

    public final int getColor() {
        return this.color;
    }

    public final StatType getBonusStat() {
        return this.bonusStat;
    }

    public final float getBonusPercent() {
        return this.bonusPercent;
    }

    public final boolean getDefaultOwned() {
        return this.defaultOwned;
    }
}
