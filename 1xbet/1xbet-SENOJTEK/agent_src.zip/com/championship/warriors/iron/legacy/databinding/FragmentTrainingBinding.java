package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;

/* loaded from: classes.dex */
public final class FragmentTrainingBinding implements ViewBinding {
    public final ImageButton backButton;
    private final FrameLayout rootView;
    public final MaterialButton startButton;

    private FragmentTrainingBinding(FrameLayout frameLayout, ImageButton imageButton, MaterialButton materialButton) {
        this.rootView = frameLayout;
        this.backButton = imageButton;
        this.startButton = materialButton;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentTrainingBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentTrainingBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_training, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentTrainingBinding bind(View view) {
        int i = R.id.backButton;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.startButton;
            MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
            if (materialButton != null) {
                return new FragmentTrainingBinding((FrameLayout) view, imageButton, materialButton);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
