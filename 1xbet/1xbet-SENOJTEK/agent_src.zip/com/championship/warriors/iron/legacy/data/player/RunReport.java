package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PlayerRepository.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b \b\u0086\b\u0018\u00002\u00020\u0001B]\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0006\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r\u0012\u0006\u0010\u000f\u001a\u00020\u0006¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0006HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0006HÆ\u0003J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0006HÆ\u0003J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\u000f\u0010'\u001a\b\u0012\u0004\u0012\u00020\u000e0\rHÆ\u0003J\t\u0010(\u001a\u00020\u0006HÆ\u0003Js\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00062\b\b\u0002\u0010\u000b\u001a\u00020\u00032\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\b\b\u0002\u0010\u000f\u001a\u00020\u0006HÆ\u0001J\u0013\u0010*\u001a\u00020\u00062\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0003HÖ\u0001J\t\u0010-\u001a\u00020\u000eHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0011\u0010\b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0016R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\n\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0013R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u000f\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0016¨\u0006."}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/RunReport;", "", "coinsEarned", "", "xpGained", "leveledUp", "", "newLevel", "newHighScore", "stars", "careerAdvanced", "nextStageId", "newAchievements", "", "", "challengePassed", "<init>", "(IIZIZIZILjava/util/List;Z)V", "getCoinsEarned", "()I", "getXpGained", "getLeveledUp", "()Z", "getNewLevel", "getNewHighScore", "getStars", "getCareerAdvanced", "getNextStageId", "getNewAchievements", "()Ljava/util/List;", "getChallengePassed", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class RunReport {
    private final boolean careerAdvanced;
    private final boolean challengePassed;
    private final int coinsEarned;
    private final boolean leveledUp;
    private final List<String> newAchievements;
    private final boolean newHighScore;
    private final int newLevel;
    private final int nextStageId;
    private final int stars;
    private final int xpGained;

    public static /* synthetic */ RunReport copy$default(RunReport runReport, int i, int i2, boolean z, int i3, boolean z2, int i4, boolean z3, int i5, List list, boolean z4, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i = runReport.coinsEarned;
        }
        if ((i6 & 2) != 0) {
            i2 = runReport.xpGained;
        }
        if ((i6 & 4) != 0) {
            z = runReport.leveledUp;
        }
        if ((i6 & 8) != 0) {
            i3 = runReport.newLevel;
        }
        if ((i6 & 16) != 0) {
            z2 = runReport.newHighScore;
        }
        if ((i6 & 32) != 0) {
            i4 = runReport.stars;
        }
        if ((i6 & 64) != 0) {
            z3 = runReport.careerAdvanced;
        }
        if ((i6 & 128) != 0) {
            i5 = runReport.nextStageId;
        }
        if ((i6 & 256) != 0) {
            list = runReport.newAchievements;
        }
        if ((i6 & 512) != 0) {
            z4 = runReport.challengePassed;
        }
        List list2 = list;
        boolean z5 = z4;
        boolean z6 = z3;
        int i7 = i5;
        boolean z7 = z2;
        int i8 = i4;
        return runReport.copy(i, i2, z, i3, z7, i8, z6, i7, list2, z5);
    }

    /* renamed from: component1, reason: from getter */
    public final int getCoinsEarned() {
        return this.coinsEarned;
    }

    /* renamed from: component10, reason: from getter */
    public final boolean getChallengePassed() {
        return this.challengePassed;
    }

    /* renamed from: component2, reason: from getter */
    public final int getXpGained() {
        return this.xpGained;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getLeveledUp() {
        return this.leveledUp;
    }

    /* renamed from: component4, reason: from getter */
    public final int getNewLevel() {
        return this.newLevel;
    }

    /* renamed from: component5, reason: from getter */
    public final boolean getNewHighScore() {
        return this.newHighScore;
    }

    /* renamed from: component6, reason: from getter */
    public final int getStars() {
        return this.stars;
    }

    /* renamed from: component7, reason: from getter */
    public final boolean getCareerAdvanced() {
        return this.careerAdvanced;
    }

    /* renamed from: component8, reason: from getter */
    public final int getNextStageId() {
        return this.nextStageId;
    }

    public final List<String> component9() {
        return this.newAchievements;
    }

    public final RunReport copy(int coinsEarned, int xpGained, boolean leveledUp, int newLevel, boolean newHighScore, int stars, boolean careerAdvanced, int nextStageId, List<String> newAchievements, boolean challengePassed) {
        Intrinsics.checkNotNullParameter(newAchievements, "newAchievements");
        return new RunReport(coinsEarned, xpGained, leveledUp, newLevel, newHighScore, stars, careerAdvanced, nextStageId, newAchievements, challengePassed);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RunReport)) {
            return false;
        }
        RunReport runReport = (RunReport) other;
        return this.coinsEarned == runReport.coinsEarned && this.xpGained == runReport.xpGained && this.leveledUp == runReport.leveledUp && this.newLevel == runReport.newLevel && this.newHighScore == runReport.newHighScore && this.stars == runReport.stars && this.careerAdvanced == runReport.careerAdvanced && this.nextStageId == runReport.nextStageId && Intrinsics.areEqual(this.newAchievements, runReport.newAchievements) && this.challengePassed == runReport.challengePassed;
    }

    public int hashCode() {
        return (((((((((((((((((Integer.hashCode(this.coinsEarned) * 31) + Integer.hashCode(this.xpGained)) * 31) + Boolean.hashCode(this.leveledUp)) * 31) + Integer.hashCode(this.newLevel)) * 31) + Boolean.hashCode(this.newHighScore)) * 31) + Integer.hashCode(this.stars)) * 31) + Boolean.hashCode(this.careerAdvanced)) * 31) + Integer.hashCode(this.nextStageId)) * 31) + this.newAchievements.hashCode()) * 31) + Boolean.hashCode(this.challengePassed);
    }

    public String toString() {
        return "RunReport(coinsEarned=" + this.coinsEarned + ", xpGained=" + this.xpGained + ", leveledUp=" + this.leveledUp + ", newLevel=" + this.newLevel + ", newHighScore=" + this.newHighScore + ", stars=" + this.stars + ", careerAdvanced=" + this.careerAdvanced + ", nextStageId=" + this.nextStageId + ", newAchievements=" + this.newAchievements + ", challengePassed=" + this.challengePassed + ")";
    }

    public RunReport(int i, int i2, boolean z, int i3, boolean z2, int i4, boolean z3, int i5, List<String> newAchievements, boolean z4) {
        Intrinsics.checkNotNullParameter(newAchievements, "newAchievements");
        this.coinsEarned = i;
        this.xpGained = i2;
        this.leveledUp = z;
        this.newLevel = i3;
        this.newHighScore = z2;
        this.stars = i4;
        this.careerAdvanced = z3;
        this.nextStageId = i5;
        this.newAchievements = newAchievements;
        this.challengePassed = z4;
    }

    public final int getCoinsEarned() {
        return this.coinsEarned;
    }

    public final int getXpGained() {
        return this.xpGained;
    }

    public final boolean getLeveledUp() {
        return this.leveledUp;
    }

    public final int getNewLevel() {
        return this.newLevel;
    }

    public final boolean getNewHighScore() {
        return this.newHighScore;
    }

    public final int getStars() {
        return this.stars;
    }

    public final boolean getCareerAdvanced() {
        return this.careerAdvanced;
    }

    public final int getNextStageId() {
        return this.nextStageId;
    }

    public final List<String> getNewAchievements() {
        return this.newAchievements;
    }

    public final boolean getChallengePassed() {
        return this.challengePassed;
    }
}
