package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\f\b\u0086\b\u0018\u00002\u00020\u0001BI\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0001\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0001\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00050\n¢\u0006\u0004\b\f\u0010\rJ\u000e\u0010\u0017\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u000bJ\u000e\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0018\u001a\u00020\u000bJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\u0015\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00050\nHÆ\u0003JQ\u0010!\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0003\u0010\u0004\u001a\u00020\u00052\b\b\u0003\u0010\u0006\u001a\u00020\u00052\b\b\u0003\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\u0014\b\u0002\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00050\nHÆ\u0001J\u0013\u0010\"\u001a\u00020\u001a2\b\u0010#\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010$\u001a\u00020\u0005HÖ\u0001J\t\u0010%\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u001d\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00050\n¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016¨\u0006&"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/AchievementDef;", "", "id", "", "nameRes", "", "descRes", "iconRes", TypedValues.AttributesType.S_TARGET, "selector", "Lkotlin/Function1;", "Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "<init>", "(Ljava/lang/String;IIIILkotlin/jvm/functions/Function1;)V", "getId", "()Ljava/lang/String;", "getNameRes", "()I", "getDescRes", "getIconRes", "getTarget", "getSelector", "()Lkotlin/jvm/functions/Function1;", "current", "state", "isUnlocked", "", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class AchievementDef {
    private final int descRes;
    private final int iconRes;
    private final String id;
    private final int nameRes;
    private final Function1<PlayerState, Integer> selector;
    private final int target;

    public static /* synthetic */ AchievementDef copy$default(AchievementDef achievementDef, String str, int i, int i2, int i3, int i4, Function1 function1, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            str = achievementDef.id;
        }
        if ((i5 & 2) != 0) {
            i = achievementDef.nameRes;
        }
        if ((i5 & 4) != 0) {
            i2 = achievementDef.descRes;
        }
        if ((i5 & 8) != 0) {
            i3 = achievementDef.iconRes;
        }
        if ((i5 & 16) != 0) {
            i4 = achievementDef.target;
        }
        if ((i5 & 32) != 0) {
            function1 = achievementDef.selector;
        }
        int i6 = i4;
        Function1 function12 = function1;
        return achievementDef.copy(str, i, i2, i3, i6, function12);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final int getNameRes() {
        return this.nameRes;
    }

    /* renamed from: component3, reason: from getter */
    public final int getDescRes() {
        return this.descRes;
    }

    /* renamed from: component4, reason: from getter */
    public final int getIconRes() {
        return this.iconRes;
    }

    /* renamed from: component5, reason: from getter */
    public final int getTarget() {
        return this.target;
    }

    public final Function1<PlayerState, Integer> component6() {
        return this.selector;
    }

    public final AchievementDef copy(String id, int nameRes, int descRes, int iconRes, int target, Function1<? super PlayerState, Integer> selector) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(selector, "selector");
        return new AchievementDef(id, nameRes, descRes, iconRes, target, selector);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AchievementDef)) {
            return false;
        }
        AchievementDef achievementDef = (AchievementDef) other;
        return Intrinsics.areEqual(this.id, achievementDef.id) && this.nameRes == achievementDef.nameRes && this.descRes == achievementDef.descRes && this.iconRes == achievementDef.iconRes && this.target == achievementDef.target && Intrinsics.areEqual(this.selector, achievementDef.selector);
    }

    public int hashCode() {
        return (((((((((this.id.hashCode() * 31) + Integer.hashCode(this.nameRes)) * 31) + Integer.hashCode(this.descRes)) * 31) + Integer.hashCode(this.iconRes)) * 31) + Integer.hashCode(this.target)) * 31) + this.selector.hashCode();
    }

    public String toString() {
        return "AchievementDef(id=" + this.id + ", nameRes=" + this.nameRes + ", descRes=" + this.descRes + ", iconRes=" + this.iconRes + ", target=" + this.target + ", selector=" + this.selector + ")";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public AchievementDef(String id, int i, int i2, int i3, int i4, Function1<? super PlayerState, Integer> selector) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(selector, "selector");
        this.id = id;
        this.nameRes = i;
        this.descRes = i2;
        this.iconRes = i3;
        this.target = i4;
        this.selector = selector;
    }

    public final String getId() {
        return this.id;
    }

    public final int getNameRes() {
        return this.nameRes;
    }

    public final int getDescRes() {
        return this.descRes;
    }

    public final int getIconRes() {
        return this.iconRes;
    }

    public final int getTarget() {
        return this.target;
    }

    public final Function1<PlayerState, Integer> getSelector() {
        return this.selector;
    }

    public final int current(PlayerState state) {
        Intrinsics.checkNotNullParameter(state, "state");
        return RangesKt.coerceAtMost(this.selector.invoke(state).intValue(), this.target);
    }

    public final boolean isUnlocked(PlayerState state) {
        Intrinsics.checkNotNullParameter(state, "state");
        return this.selector.invoke(state).intValue() >= this.target;
    }
}
