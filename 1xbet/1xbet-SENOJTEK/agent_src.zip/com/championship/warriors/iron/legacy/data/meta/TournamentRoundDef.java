package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B)\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00060\u0005¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\u001b\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00060\u0005HÆ\u0003J/\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u001a\b\u0002\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00060\u0005HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0007HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR#\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u0016"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/TournamentRoundDef;", "", "thresholdScore", "", "rivals", "", "Lkotlin/Pair;", "", "<init>", "(ILjava/util/List;)V", "getThresholdScore", "()I", "getRivals", "()Ljava/util/List;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class TournamentRoundDef {
    private final List<Pair<String, Integer>> rivals;
    private final int thresholdScore;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ TournamentRoundDef copy$default(TournamentRoundDef tournamentRoundDef, int i, List list, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = tournamentRoundDef.thresholdScore;
        }
        if ((i2 & 2) != 0) {
            list = tournamentRoundDef.rivals;
        }
        return tournamentRoundDef.copy(i, list);
    }

    /* renamed from: component1, reason: from getter */
    public final int getThresholdScore() {
        return this.thresholdScore;
    }

    public final List<Pair<String, Integer>> component2() {
        return this.rivals;
    }

    public final TournamentRoundDef copy(int thresholdScore, List<Pair<String, Integer>> rivals) {
        Intrinsics.checkNotNullParameter(rivals, "rivals");
        return new TournamentRoundDef(thresholdScore, rivals);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TournamentRoundDef)) {
            return false;
        }
        TournamentRoundDef tournamentRoundDef = (TournamentRoundDef) other;
        return this.thresholdScore == tournamentRoundDef.thresholdScore && Intrinsics.areEqual(this.rivals, tournamentRoundDef.rivals);
    }

    public int hashCode() {
        return (Integer.hashCode(this.thresholdScore) * 31) + this.rivals.hashCode();
    }

    public String toString() {
        return "TournamentRoundDef(thresholdScore=" + this.thresholdScore + ", rivals=" + this.rivals + ")";
    }

    public TournamentRoundDef(int i, List<Pair<String, Integer>> rivals) {
        Intrinsics.checkNotNullParameter(rivals, "rivals");
        this.thresholdScore = i;
        this.rivals = rivals;
    }

    public final List<Pair<String, Integer>> getRivals() {
        return this.rivals;
    }

    public final int getThresholdScore() {
        return this.thresholdScore;
    }
}
