package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u000b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b¨\u0006\f"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/MissionMetric;", "", "<init>", "(Ljava/lang/String;I)V", "DISTANCE_TOTAL", "COINS_TOTAL", "OBSTACLES_TOTAL", "POWERUPS_TOTAL", "RUNS_TOTAL", "TOKENS_TOTAL", "SURVIVE_SECONDS", "SCORE_SINGLE", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MissionMetric {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ MissionMetric[] $VALUES;
    public static final MissionMetric DISTANCE_TOTAL = new MissionMetric("DISTANCE_TOTAL", 0);
    public static final MissionMetric COINS_TOTAL = new MissionMetric("COINS_TOTAL", 1);
    public static final MissionMetric OBSTACLES_TOTAL = new MissionMetric("OBSTACLES_TOTAL", 2);
    public static final MissionMetric POWERUPS_TOTAL = new MissionMetric("POWERUPS_TOTAL", 3);
    public static final MissionMetric RUNS_TOTAL = new MissionMetric("RUNS_TOTAL", 4);
    public static final MissionMetric TOKENS_TOTAL = new MissionMetric("TOKENS_TOTAL", 5);
    public static final MissionMetric SURVIVE_SECONDS = new MissionMetric("SURVIVE_SECONDS", 6);
    public static final MissionMetric SCORE_SINGLE = new MissionMetric("SCORE_SINGLE", 7);

    private static final /* synthetic */ MissionMetric[] $values() {
        return new MissionMetric[]{DISTANCE_TOTAL, COINS_TOTAL, OBSTACLES_TOTAL, POWERUPS_TOTAL, RUNS_TOTAL, TOKENS_TOTAL, SURVIVE_SECONDS, SCORE_SINGLE};
    }

    public static EnumEntries<MissionMetric> getEntries() {
        return $ENTRIES;
    }

    public static MissionMetric valueOf(String str) {
        return (MissionMetric) Enum.valueOf(MissionMetric.class, str);
    }

    public static MissionMetric[] values() {
        return (MissionMetric[]) $VALUES.clone();
    }

    static {
        MissionMetric[] missionMetricArr$values = $values();
        $VALUES = missionMetricArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(missionMetricArr$values);
    }

    private MissionMetric(String str, int i) {
    }
}
