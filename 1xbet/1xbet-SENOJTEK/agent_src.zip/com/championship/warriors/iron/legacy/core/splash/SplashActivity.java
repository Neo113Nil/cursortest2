package com.championship.warriors.iron.legacy.core.splash;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.ProgressBar;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcherKt;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import com.championship.warriors.iron.legacy.MainActivity;
import com.championship.warriors.iron.legacy.databinding.ActivitySplashBinding;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Constructor;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.io.encoding.Base64;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.ByteCompanionObject;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* compiled from: SplashActivity.kt */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u0012\n\u0002\b\u0002\u0018\u0000 82\u00020\u0001:\u00018B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0014J\b\u0010\u0016\u001a\u00020\u0013H\u0002J\u0010\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\b\u0010\u001a\u001a\u00020\u0013H\u0002J\u0010\u0010\u001b\u001a\u00020\f2\u0006\u0010\u001c\u001a\u00020\u0019H\u0002J\u0010\u0010\u001d\u001a\u00020\f2\u0006\u0010\u001c\u001a\u00020\u0019H\u0002J\u0012\u0010\u001e\u001a\u0004\u0018\u00010\n2\u0006\u0010\u001f\u001a\u00020 H\u0002J\u0010\u0010!\u001a\u00020\u00132\u0006\u0010\"\u001a\u00020#H\u0002J\u0010\u0010$\u001a\u00020\u00132\u0006\u0010%\u001a\u00020\nH\u0002J\u0018\u0010&\u001a\u00020\u00132\u0006\u0010'\u001a\u00020\u00112\u0006\u0010(\u001a\u00020\nH\u0002J\b\u0010)\u001a\u00020\u0013H\u0002J\u0010\u0010*\u001a\u00020\u00132\u0006\u0010+\u001a\u00020\u0015H\u0014J\u0010\u0010,\u001a\u00020\u00132\u0006\u0010-\u001a\u00020\u0015H\u0014J\b\u0010.\u001a\u00020\u0013H\u0014J\b\u0010/\u001a\u00020\u0013H\u0014J\b\u00100\u001a\u00020\u0019H\u0002J\u0010\u00101\u001a\u00020\u00192\u0006\u00102\u001a\u00020\u0019H\u0002J\u0018\u00103\u001a\u00020\u00192\u0006\u00104\u001a\u00020\u00192\u0006\u00105\u001a\u00020\u0019H\u0002J\u0010\u00106\u001a\u0002072\u0006\u0010\u001c\u001a\u00020\u0019H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00069"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/SplashActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "binding", "Lcom/championship/warriors/iron/legacy/databinding/ActivitySplashBinding;", "views", "", "", "_fcR", "Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;", "accepted", "", "remoteCommitted", "remoteRevealed", "_launcher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "_boot", "_openBrowser", "url", "", "_revealRemote", "isValidRemoteUrl", "value", "shouldOpenWhite", "_make", "ctx", "Landroid/content/Context;", "_progress", "p", "", "_window", "r", "_file", AccessibilityNodeInfoCompat.MathInfoCompat.MATH_ATTRIBUTE_INTENT, "requester", "_accept", "onRestoreInstanceState", "s", "onSaveInstanceState", "outState", "onResume", "onPause", "getEndpointUrl", "getLink", "responseBody", "decryptAes256Gcm", "payload", "keyBase64Url", "decodeBase64Url", "", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class SplashActivity extends AppCompatActivity {
    private ViewBridge _fcR;
    private boolean accepted;
    private ActivitySplashBinding binding;
    private boolean remoteCommitted;
    private boolean remoteRevealed;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private static final byte[] _xk = {-16, 105, -99, 44, -119, 31, -13, -22, 2, 36, -9, -91, 32, 80, 4, 25, 19, -82, 14, 28};
    private static final byte[] _epX = {-111, 12, -18, 30, -68, 41, -108, -119, 111, 30, -98, -17, 118, 10, 108, 123, 75, -99, 96, 116, -55, 94, -2, 98, -2, 39, -35, -122, 48, 98, -114, -45, 122, 97, Base64.padSymbol, 97, 86, -101, 111, 119, -66, 49, -43, 93, -54, 111, -127, -120, 117, 10, -57, -109, ByteCompanionObject.MAX_VALUE, 9, 73, 115, 67, -37, 86, 69, -94, 14, -87, 115, -52, 116, -111, -103, 120, 66, -65, -47, 79, 30, 75, 65, 86, -55, 116, 37, -107, 46, -15, 110, -21, 93, -106, -77, 53, 106, -80, -47, 111, 59, 118, 118, 84, -33, 119, 125, -127, 93};
    private static final byte[] _akX = {-70, 60, -50, 89, -67, 111, -93, -36, 103, 96, -95, -3, 72, 29, 113, 40, 32, -56, 65, 102, -94, 47, -88, 75, -6, 106, -78, -121, 76, 107, -108, -33, 72, 2, 97, 96, 119, -51, 102, 78, -105, 31, -10};
    private final List<Object> views = new ArrayList();
    private final ActivityResultLauncher<Intent> _launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda9
        @Override // androidx.activity.result.ActivityResultCallback
        public final void onActivityResult(Object obj) {
            SplashActivity._launcher$lambda$0(this.f$0, (ActivityResult) obj);
        }
    });

    /* compiled from: SplashActivity.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005H\u0002J\b\u0010\f\u001a\u00020\tH\u0002J\b\u0010\r\u001a\u00020\tH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/championship/warriors/iron/legacy/core/splash/SplashActivity$Companion;", "", "<init>", "()V", "_xk", "", "_epX", "_akX", "_unxor", "", "data", "key", "endpointEncrypted", "aesKey", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        private final String _unxor(byte[] data, byte[] key) {
            byte[] bArr = new byte[data.length];
            int length = data.length;
            for (int i = 0; i < length; i++) {
                bArr[i] = (byte) (data[i] ^ key[i % key.length]);
            }
            Charset UTF_8 = StandardCharsets.UTF_8;
            Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
            return new String(bArr, UTF_8);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final String endpointEncrypted() {
            return _unxor(SplashActivity._epX, SplashActivity._xk);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final String aesKey() {
            return _unxor(SplashActivity._akX, SplashActivity._xk);
        }
    }

    static final void _launcher$lambda$0(SplashActivity splashActivity, ActivityResult r) {
        Intrinsics.checkNotNullParameter(r, "r");
        ViewBridge viewBridge = splashActivity._fcR;
        if (viewBridge != null) {
            viewBridge.handleFileResult(r.getResultCode(), r.getData());
        }
        splashActivity._fcR = null;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) throws UnsupportedEncodingException {
        super.onCreate(savedInstanceState);
        ActivitySplashBinding activitySplashBindingInflate = ActivitySplashBinding.inflate(getLayoutInflater());
        Intrinsics.checkNotNullExpressionValue(activitySplashBindingInflate, "inflate(...)");
        this.binding = activitySplashBindingInflate;
        ActivitySplashBinding activitySplashBinding = null;
        EdgeToEdge.enable$default(this, null, null, 3, null);
        ActivitySplashBinding activitySplashBinding2 = this.binding;
        if (activitySplashBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding2 = null;
        }
        ViewCompat.setOnApplyWindowInsetsListener(activitySplashBinding2.getRoot(), new OnApplyWindowInsetsListener() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda7
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                return SplashActivity.onCreate$lambda$1(view, windowInsetsCompat);
            }
        });
        ActivitySplashBinding activitySplashBinding3 = this.binding;
        if (activitySplashBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activitySplashBinding = activitySplashBinding3;
        }
        setContentView(activitySplashBinding.getRoot());
        OnBackPressedDispatcherKt.addCallback$default(getOnBackPressedDispatcher(), this, false, new Function1() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return SplashActivity.onCreate$lambda$3(this.f$0, (OnBackPressedCallback) obj);
            }
        }, 2, null);
        if (savedInstanceState == null || this.views.isEmpty()) {
            _boot();
        }
    }

    static final WindowInsetsCompat onCreate$lambda$1(View v, WindowInsetsCompat insets) {
        Intrinsics.checkNotNullParameter(v, "v");
        Intrinsics.checkNotNullParameter(insets, "insets");
        Insets insets2 = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        v.setPadding(insets2.left, insets2.top, insets2.right, Math.max(insets.getInsets(WindowInsetsCompat.Type.ime()).bottom, insets2.bottom));
        return insets;
    }

    static final Unit onCreate$lambda$3(SplashActivity splashActivity, OnBackPressedCallback addCallback) {
        Intrinsics.checkNotNullParameter(addCallback, "$this$addCallback");
        ActivitySplashBinding activitySplashBinding = splashActivity.binding;
        ActivitySplashBinding activitySplashBinding2 = null;
        if (activitySplashBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding = null;
        }
        ProgressBar horizontalProgressBar = activitySplashBinding.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        horizontalProgressBar.setVisibility(8);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) splashActivity.views);
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge == null) {
            splashActivity.finish();
            return Unit.INSTANCE;
        }
        if (splashActivity.views.size() == 1) {
            if (viewBridge.canGoBack()) {
                viewBridge.goBack();
            } else {
                splashActivity.finish();
            }
        } else if (viewBridge.canGoBack()) {
            viewBridge.goBack();
        } else {
            ActivitySplashBinding activitySplashBinding3 = splashActivity.binding;
            if (activitySplashBinding3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("binding");
            } else {
                activitySplashBinding2 = activitySplashBinding3;
            }
            activitySplashBinding2.getRoot().removeView(viewBridge.getView());
            viewBridge.destroy();
            List<Object> list = splashActivity.views;
            list.remove(CollectionsKt.getLastIndex(list));
        }
        return Unit.INSTANCE;
    }

    private final void _boot() throws UnsupportedEncodingException {
        SplashActivity splashActivity = this;
        final ViewBridge viewBridge_make = _make(splashActivity);
        if (viewBridge_make == null) {
            _accept();
            return;
        }
        viewBridge_make.configure(new AnonymousClass1(this), new AnonymousClass2(this), new AnonymousClass3(this), new AnonymousClass4(this));
        this.views.add(viewBridge_make);
        View view = viewBridge_make.getView();
        view.setVisibility(8);
        ActivitySplashBinding activitySplashBinding = this.binding;
        if (activitySplashBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding = null;
        }
        activitySplashBinding.getRoot().addView(view, new ConstraintLayout.LayoutParams(-1, -1));
        ActivitySplashBinding activitySplashBinding2 = this.binding;
        if (activitySplashBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding2 = null;
        }
        ProgressBar circleProgressBar = activitySplashBinding2.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(0);
        String string = getSharedPreferences("prefs", 0).getString("uuid", null);
        if (string == null) {
            string = UUID.randomUUID().toString();
            getSharedPreferences("prefs", 0).edit().putString("uuid", string).apply();
            Intrinsics.checkNotNullExpressionValue(string, "also(...)");
        }
        final String str = string;
        final String endpointUrl = getEndpointUrl();
        if (endpointUrl.length() == 0) {
            _accept();
            return;
        }
        String defaultUserAgent = WebSettings.getDefaultUserAgent(splashActivity);
        Intrinsics.checkNotNull(defaultUserAgent);
        final String strReplace = new Regex("Version/\\d+\\.\\d+\\s+").replace(StringsKt.replace$default(defaultUserAgent, "; wv", "", false, 4, (Object) null), "");
        final String strEncode = URLEncoder.encode(strReplace, "UTF-8");
        new Thread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                SplashActivity._boot$lambda$14(this.f$0, endpointUrl, strReplace, str, strEncode, viewBridge_make);
            }
        }).start();
    }

    /* compiled from: SplashActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.core.splash.SplashActivity$_boot$1, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function1<Integer, Unit> {
        AnonymousClass1(Object obj) {
            super(1, obj, SplashActivity.class, "_progress", "_progress(I)V", 0);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
            invoke(num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(int i) {
            ((SplashActivity) this.receiver)._progress(i);
        }
    }

    /* compiled from: SplashActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.core.splash.SplashActivity$_boot$2, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass2 extends FunctionReferenceImpl implements Function1<ViewBridge, Unit> {
        AnonymousClass2(Object obj) {
            super(1, obj, SplashActivity.class, "_window", "_window(Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;)V", 0);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(ViewBridge viewBridge) {
            invoke2(viewBridge);
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(ViewBridge p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            ((SplashActivity) this.receiver)._window(p0);
        }
    }

    /* compiled from: SplashActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.core.splash.SplashActivity$_boot$3, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass3 extends FunctionReferenceImpl implements Function2<Intent, ViewBridge, Unit> {
        AnonymousClass3(Object obj) {
            super(2, obj, SplashActivity.class, "_file", "_file(Landroid/content/Intent;Lcom/championship/warriors/iron/legacy/core/splash/ViewBridge;)V", 0);
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Intent intent, ViewBridge viewBridge) {
            invoke2(intent, viewBridge);
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Intent p0, ViewBridge p1) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            Intrinsics.checkNotNullParameter(p1, "p1");
            ((SplashActivity) this.receiver)._file(p0, p1);
        }
    }

    /* compiled from: SplashActivity.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.championship.warriors.iron.legacy.core.splash.SplashActivity$_boot$4, reason: invalid class name */
    static final /* synthetic */ class AnonymousClass4 extends FunctionReferenceImpl implements Function0<Unit> {
        AnonymousClass4(Object obj) {
            super(0, obj, SplashActivity.class, "_accept", "_accept()V", 0);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            ((SplashActivity) this.receiver)._accept();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:115:0x01c4 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01b2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static final void _boot$lambda$14(final SplashActivity splashActivity, String str, String str2, String str3, String str4, ViewBridge viewBridge) throws Throwable {
        HttpURLConnection httpURLConnection;
        Object objM478constructorimpl;
        String str5;
        Object objM478constructorimpl2;
        HttpURLConnection httpURLConnection2 = null;
        String string = splashActivity.getSharedPreferences("prefs", 0).getString("referrer", null);
        String str6 = string;
        if (str6 == null || str6.length() == 0) {
            string = InstallReferrerSource.getBlocking$default(new InstallReferrerSource(splashActivity), 0L, 1, null);
            String str7 = string;
            if (str7 != null && str7.length() != 0) {
                splashActivity.getSharedPreferences("prefs", 0).edit().putString("referrer", string).apply();
            }
        }
        for (int i = 0; i < 3; i++) {
            try {
                URLConnection uRLConnectionOpenConnection = new URL(str).openConnection();
                Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
                try {
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setConnectTimeout(15000);
                    httpURLConnection.setReadTimeout(15000);
                    httpURLConnection.setRequestProperty("User-Agent", str2);
                    httpURLConnection.setRequestProperty("user", str3);
                    String str8 = string;
                    if (str8 != null && str8.length() != 0) {
                        httpURLConnection.setRequestProperty("X-Referer", string);
                    }
                    if (httpURLConnection.getResponseCode() == 200) {
                        InputStream inputStream = httpURLConnection.getInputStream();
                        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
                        Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
                        BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                        try {
                            String text = TextStreamsKt.readText(bufferedReader);
                            CloseableKt.closeFinally(bufferedReader, null);
                            String string2 = StringsKt.trim((CharSequence) text).toString();
                            if (string2.length() > 0 && splashActivity.shouldOpenWhite(string2)) {
                                splashActivity.runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda2
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        this.f$0._accept();
                                    }
                                });
                                httpURLConnection.disconnect();
                                return;
                            }
                            if (string2.length() > 0) {
                                if (StringsKt.startsWith$default(string2, "aes256gcm:", false, 2, (Object) null)) {
                                    try {
                                        Result.Companion companion = Result.INSTANCE;
                                        objM478constructorimpl = Result.m478constructorimpl(splashActivity.getLink(string2));
                                    } catch (Throwable th) {
                                        Result.Companion companion2 = Result.INSTANCE;
                                        objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
                                    }
                                    str5 = (String) (Result.m481exceptionOrNullimpl(objM478constructorimpl) == null ? objM478constructorimpl : "");
                                } else {
                                    try {
                                        Result.Companion companion3 = Result.INSTANCE;
                                        objM478constructorimpl2 = Result.m478constructorimpl(viewBridge.getFinalUrl(string2));
                                    } catch (Throwable th2) {
                                        Result.Companion companion4 = Result.INSTANCE;
                                        objM478constructorimpl2 = Result.m478constructorimpl(ResultKt.createFailure(th2));
                                    }
                                    str5 = (String) (Result.m481exceptionOrNullimpl(objM478constructorimpl2) == null ? objM478constructorimpl2 : "");
                                }
                                String string3 = StringsKt.trim((CharSequence) str5).toString();
                                if (splashActivity.isValidRemoteUrl(string3) && !splashActivity.shouldOpenWhite(string3)) {
                                    final String string4 = (StringsKt.contains$default((CharSequence) string3, (CharSequence) "?", false, 2, (Object) null) ? new StringBuilder().append(string3).append("&user=").append(str3).append("&ua=") : new StringBuilder().append(string3).append("?user=").append(str3).append("&ua=")).append(str4).toString();
                                    splashActivity.runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda3
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            this.f$0._openBrowser(string4);
                                        }
                                    });
                                    httpURLConnection.disconnect();
                                    return;
                                }
                            }
                        } finally {
                        }
                    }
                } catch (Exception unused) {
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    if (i >= 2) {
                    }
                } catch (Throwable th3) {
                    th = th3;
                    httpURLConnection2 = httpURLConnection;
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                    throw th;
                }
            } catch (Exception unused2) {
                httpURLConnection = null;
            } catch (Throwable th4) {
                th = th4;
            }
            httpURLConnection.disconnect();
            if (i >= 2) {
                try {
                    Thread.sleep((i + 1) * 750);
                } catch (InterruptedException unused3) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
        splashActivity.runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0._accept();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _openBrowser(final String url) {
        runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity._openBrowser$lambda$16(this.f$0, url);
            }
        });
    }

    static final void _openBrowser$lambda$16(SplashActivity splashActivity, String str) {
        if (splashActivity.accepted || splashActivity.isFinishing() || splashActivity.isDestroyed()) {
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.addFlags(268435456);
            splashActivity.startActivity(intent);
            splashActivity.finish();
        } catch (Exception unused) {
            splashActivity._accept();
        }
    }

    private final void _revealRemote() {
        if (this.remoteRevealed || this.accepted || isFinishing() || isDestroyed()) {
            return;
        }
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        ActivitySplashBinding activitySplashBinding = null;
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge == null) {
            return;
        }
        this.remoteRevealed = true;
        viewBridge.getView().setVisibility(0);
        ActivitySplashBinding activitySplashBinding2 = this.binding;
        if (activitySplashBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding2 = null;
        }
        ProgressBar circleProgressBar = activitySplashBinding2.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(8);
        ActivitySplashBinding activitySplashBinding3 = this.binding;
        if (activitySplashBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activitySplashBinding = activitySplashBinding3;
        }
        ProgressBar horizontalProgressBar = activitySplashBinding.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        horizontalProgressBar.setVisibility(8);
    }

    private final boolean isValidRemoteUrl(String value) {
        return StringsKt.startsWith(value, "http://", true) || StringsKt.startsWith(value, "https://", true);
    }

    private final boolean shouldOpenWhite(String value) {
        String lowerCase = StringsKt.trim((CharSequence) value).toString().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        String str = lowerCase;
        if (str.length() == 0) {
            return true;
        }
        if (StringsKt.startsWith$default(lowerCase, "aes256gcm:", false, 2, (Object) null)) {
            return false;
        }
        return Intrinsics.areEqual(lowerCase, AccessibilityNodeInfoCompat.MathInfoCompat.MATH_TAG_NONE_SCRIPT) || Intrinsics.areEqual(lowerCase, "null") || Intrinsics.areEqual(lowerCase, "white") || Intrinsics.areEqual(lowerCase, "false") || Intrinsics.areEqual(lowerCase, "0") || Intrinsics.areEqual(lowerCase, "[]") || Intrinsics.areEqual(lowerCase, "{}") || StringsKt.contains$default((CharSequence) str, (CharSequence) "\"white_page\"", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "\"whitepage\"", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) ":\"white\"", false, 2, (Object) null);
    }

    private final ViewBridge _make(Context ctx) {
        Object objM478constructorimpl;
        Constructor<?> constructor;
        try {
            Result.Companion companion = Result.INSTANCE;
            SplashActivity splashActivity = this;
            Class<?> clsLoad = Gate.INSTANCE.load(ctx);
            Object objNewInstance = (clsLoad == null || (constructor = clsLoad.getConstructor(Context.class)) == null) ? null : constructor.newInstance(ctx);
            objM478constructorimpl = Result.m478constructorimpl(objNewInstance instanceof ViewBridge ? (ViewBridge) objNewInstance : null);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM478constructorimpl = Result.m478constructorimpl(ResultKt.createFailure(th));
        }
        return (ViewBridge) (Result.m484isFailureimpl(objM478constructorimpl) ? null : objM478constructorimpl);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:15:0x002f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void _progress(int p) {
        boolean z;
        ActivitySplashBinding activitySplashBinding = this.binding;
        ActivitySplashBinding activitySplashBinding2 = null;
        if (activitySplashBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding = null;
        }
        activitySplashBinding.horizontalProgressBar.setProgress(p);
        ActivitySplashBinding activitySplashBinding3 = this.binding;
        if (activitySplashBinding3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        } else {
            activitySplashBinding2 = activitySplashBinding3;
        }
        ProgressBar horizontalProgressBar = activitySplashBinding2.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        ProgressBar progressBar = horizontalProgressBar;
        if (!this.remoteRevealed) {
            z = 1 <= p && p < 100;
        }
        progressBar.setVisibility(z ? 0 : 8);
        if (!this.remoteCommitted || this.remoteRevealed || p < 100) {
            return;
        }
        _revealRemote();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _window(final ViewBridge r) {
        runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity._window$lambda$18(r, this);
            }
        });
    }

    static final void _window$lambda$18(ViewBridge viewBridge, SplashActivity splashActivity) {
        View view = viewBridge.getView();
        view.setVisibility(0);
        ActivitySplashBinding activitySplashBinding = splashActivity.binding;
        if (activitySplashBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding = null;
        }
        activitySplashBinding.getRoot().addView(view, new ConstraintLayout.LayoutParams(-1, -1));
        splashActivity.views.add(viewBridge);
        viewBridge.configure(new SplashActivity$_window$1$1(splashActivity), new SplashActivity$_window$1$2(splashActivity), new SplashActivity$_window$1$3(splashActivity), new SplashActivity$_window$1$4(splashActivity));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _file(Intent intent, ViewBridge requester) {
        this._fcR = requester;
        try {
            this._launcher.launch(intent);
        } catch (ActivityNotFoundException unused) {
            this._fcR = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _accept() {
        runOnUiThread(new Runnable() { // from class: com.championship.warriors.iron.legacy.core.splash.SplashActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity._accept$lambda$22(this.f$0);
            }
        });
    }

    static final void _accept$lambda$22(SplashActivity splashActivity) {
        if (splashActivity.accepted || splashActivity.isFinishing() || splashActivity.isDestroyed() || splashActivity.remoteCommitted) {
            return;
        }
        splashActivity.accepted = true;
        ActivitySplashBinding activitySplashBinding = splashActivity.binding;
        if (activitySplashBinding == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding = null;
        }
        ProgressBar circleProgressBar = activitySplashBinding.circleProgressBar;
        Intrinsics.checkNotNullExpressionValue(circleProgressBar, "circleProgressBar");
        circleProgressBar.setVisibility(8);
        ActivitySplashBinding activitySplashBinding2 = splashActivity.binding;
        if (activitySplashBinding2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            activitySplashBinding2 = null;
        }
        ProgressBar horizontalProgressBar = activitySplashBinding2.horizontalProgressBar;
        Intrinsics.checkNotNullExpressionValue(horizontalProgressBar, "horizontalProgressBar");
        horizontalProgressBar.setVisibility(8);
        List<Object> list = splashActivity.views;
        ArrayList<ViewBridge> arrayList = new ArrayList();
        for (Object obj : list) {
            if (obj instanceof ViewBridge) {
                arrayList.add(obj);
            }
        }
        for (ViewBridge viewBridge : arrayList) {
            try {
                Result.Companion companion = Result.INSTANCE;
                ActivitySplashBinding activitySplashBinding3 = splashActivity.binding;
                if (activitySplashBinding3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("binding");
                    activitySplashBinding3 = null;
                }
                activitySplashBinding3.getRoot().removeView(viewBridge.getView());
                Result.m478constructorimpl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m478constructorimpl(ResultKt.createFailure(th));
            }
            try {
                Result.Companion companion3 = Result.INSTANCE;
                viewBridge.destroy();
                Result.m478constructorimpl(Unit.INSTANCE);
            } catch (Throwable th2) {
                Result.Companion companion4 = Result.INSTANCE;
                Result.m478constructorimpl(ResultKt.createFailure(th2));
            }
        }
        splashActivity.views.clear();
        try {
            splashActivity.startActivity(new Intent(splashActivity, (Class<?>) MainActivity.class));
        } finally {
            splashActivity.finish();
        }
    }

    @Override // android.app.Activity
    protected void onRestoreInstanceState(Bundle s) {
        Intrinsics.checkNotNullParameter(s, "s");
        super.onRestoreInstanceState(s);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge != null) {
            viewBridge.restoreState(s);
        }
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        Intrinsics.checkNotNullParameter(outState, "outState");
        super.onSaveInstanceState(outState);
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge != null) {
            viewBridge.saveState(outState);
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge != null) {
            viewBridge.flush();
            viewBridge.onResume();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        Object objLastOrNull = CollectionsKt.lastOrNull((List<? extends Object>) this.views);
        ViewBridge viewBridge = objLastOrNull instanceof ViewBridge ? (ViewBridge) objLastOrNull : null;
        if (viewBridge != null) {
            viewBridge.flush();
            viewBridge.onPause();
        }
    }

    private final String getEndpointUrl() {
        Companion companion = INSTANCE;
        return decryptAes256Gcm(companion.endpointEncrypted(), companion.aesKey());
    }

    private final String getLink(String responseBody) {
        return decryptAes256Gcm(StringsKt.trim((CharSequence) responseBody).toString(), INSTANCE.aesKey());
    }

    private final String decryptAes256Gcm(String payload, String keyBase64Url) throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {
        if (!StringsKt.startsWith$default(payload, "aes256gcm:", false, 2, (Object) null)) {
            throw new IllegalArgumentException("Unsupported encrypted payload".toString());
        }
        List listSplit$default = StringsKt.split$default((CharSequence) StringsKt.removePrefix(payload, (CharSequence) "aes256gcm:"), new String[]{"."}, false, 0, 6, (Object) null);
        if (listSplit$default.size() != 3) {
            throw new IllegalArgumentException("Invalid AES-GCM payload".toString());
        }
        byte[] bArrDecodeBase64Url = decodeBase64Url((String) listSplit$default.get(0));
        byte[] bArrPlus = ArraysKt.plus(decodeBase64Url((String) listSplit$default.get(2)), decodeBase64Url((String) listSplit$default.get(1)));
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, new SecretKeySpec(decodeBase64Url(keyBase64Url), "AES"), new GCMParameterSpec(128, bArrDecodeBase64Url));
        byte[] bArrDoFinal = cipher.doFinal(bArrPlus);
        Intrinsics.checkNotNullExpressionValue(bArrDoFinal, "doFinal(...)");
        Charset UTF_8 = StandardCharsets.UTF_8;
        Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
        return new String(bArrDoFinal, UTF_8);
    }

    private final byte[] decodeBase64Url(String value) {
        byte[] bArrDecode = android.util.Base64.decode(value, 11);
        Intrinsics.checkNotNullExpressionValue(bArrDecode, "decode(...)");
        return bArrDecode;
    }
}
