package com.championship.warriors.iron.legacy.data.player;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.Metadata;

/* compiled from: StatType.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J;\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001d"}, d2 = {"Lcom/championship/warriors/iron/legacy/data/player/StatModifiers;", "", "speedFactor", "", "controlMul", "staminaMul", "agilityMul", "rewardMul", "<init>", "(FFFFF)V", "getSpeedFactor", "()F", "getControlMul", "getStaminaMul", "getAgilityMul", "getRewardMul", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class StatModifiers {
    private final float agilityMul;
    private final float controlMul;
    private final float rewardMul;
    private final float speedFactor;
    private final float staminaMul;

    public static /* synthetic */ StatModifiers copy$default(StatModifiers statModifiers, float f, float f2, float f3, float f4, float f5, int i, Object obj) {
        if ((i & 1) != 0) {
            f = statModifiers.speedFactor;
        }
        if ((i & 2) != 0) {
            f2 = statModifiers.controlMul;
        }
        if ((i & 4) != 0) {
            f3 = statModifiers.staminaMul;
        }
        if ((i & 8) != 0) {
            f4 = statModifiers.agilityMul;
        }
        if ((i & 16) != 0) {
            f5 = statModifiers.rewardMul;
        }
        float f6 = f5;
        float f7 = f3;
        return statModifiers.copy(f, f2, f7, f4, f6);
    }

    /* renamed from: component1, reason: from getter */
    public final float getSpeedFactor() {
        return this.speedFactor;
    }

    /* renamed from: component2, reason: from getter */
    public final float getControlMul() {
        return this.controlMul;
    }

    /* renamed from: component3, reason: from getter */
    public final float getStaminaMul() {
        return this.staminaMul;
    }

    /* renamed from: component4, reason: from getter */
    public final float getAgilityMul() {
        return this.agilityMul;
    }

    /* renamed from: component5, reason: from getter */
    public final float getRewardMul() {
        return this.rewardMul;
    }

    public final StatModifiers copy(float speedFactor, float controlMul, float staminaMul, float agilityMul, float rewardMul) {
        return new StatModifiers(speedFactor, controlMul, staminaMul, agilityMul, rewardMul);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof StatModifiers)) {
            return false;
        }
        StatModifiers statModifiers = (StatModifiers) other;
        return Float.compare(this.speedFactor, statModifiers.speedFactor) == 0 && Float.compare(this.controlMul, statModifiers.controlMul) == 0 && Float.compare(this.staminaMul, statModifiers.staminaMul) == 0 && Float.compare(this.agilityMul, statModifiers.agilityMul) == 0 && Float.compare(this.rewardMul, statModifiers.rewardMul) == 0;
    }

    public int hashCode() {
        return (((((((Float.hashCode(this.speedFactor) * 31) + Float.hashCode(this.controlMul)) * 31) + Float.hashCode(this.staminaMul)) * 31) + Float.hashCode(this.agilityMul)) * 31) + Float.hashCode(this.rewardMul);
    }

    public String toString() {
        return "StatModifiers(speedFactor=" + this.speedFactor + ", controlMul=" + this.controlMul + ", staminaMul=" + this.staminaMul + ", agilityMul=" + this.agilityMul + ", rewardMul=" + this.rewardMul + ")";
    }

    public StatModifiers(float f, float f2, float f3, float f4, float f5) {
        this.speedFactor = f;
        this.controlMul = f2;
        this.staminaMul = f3;
        this.agilityMul = f4;
        this.rewardMul = f5;
    }

    public final float getSpeedFactor() {
        return this.speedFactor;
    }

    public final float getControlMul() {
        return this.controlMul;
    }

    public final float getStaminaMul() {
        return this.staminaMul;
    }

    public final float getAgilityMul() {
        return this.agilityMul;
    }

    public final float getRewardMul() {
        return this.rewardMul;
    }
}
