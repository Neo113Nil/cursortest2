package com.championship.warriors.iron.legacy.data.meta;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.championship.warriors.iron.legacy.data.player.PlayerState;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MetaCatalog.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\b\b\u0001\u0010\t\u001a\u00020\u0007¢\u0006\u0004\b\n\u0010\u000bJ\u000e\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u0016J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0007HÆ\u0003J;\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0003\u0010\t\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020\u0007HÖ\u0001J\t\u0010!\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011¨\u0006\""}, d2 = {"Lcom/championship/warriors/iron/legacy/data/meta/MissionDef;", "", "id", "", "metric", "Lcom/championship/warriors/iron/legacy/data/meta/MissionMetric;", TypedValues.AttributesType.S_TARGET, "", "rewardCoins", "labelRes", "<init>", "(Ljava/lang/String;Lcom/championship/warriors/iron/legacy/data/meta/MissionMetric;III)V", "getId", "()Ljava/lang/String;", "getMetric", "()Lcom/championship/warriors/iron/legacy/data/meta/MissionMetric;", "getTarget", "()I", "getRewardCoins", "getLabelRes", "progress", "state", "Lcom/championship/warriors/iron/legacy/data/player/PlayerState;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final /* data */ class MissionDef {
    private final String id;
    private final int labelRes;
    private final MissionMetric metric;
    private final int rewardCoins;
    private final int target;

    /* compiled from: MetaCatalog.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[MissionMetric.values().length];
            try {
                iArr[MissionMetric.DISTANCE_TOTAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[MissionMetric.COINS_TOTAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[MissionMetric.OBSTACLES_TOTAL.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[MissionMetric.POWERUPS_TOTAL.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[MissionMetric.RUNS_TOTAL.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[MissionMetric.TOKENS_TOTAL.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[MissionMetric.SURVIVE_SECONDS.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[MissionMetric.SCORE_SINGLE.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public static /* synthetic */ MissionDef copy$default(MissionDef missionDef, String str, MissionMetric missionMetric, int i, int i2, int i3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            str = missionDef.id;
        }
        if ((i4 & 2) != 0) {
            missionMetric = missionDef.metric;
        }
        if ((i4 & 4) != 0) {
            i = missionDef.target;
        }
        if ((i4 & 8) != 0) {
            i2 = missionDef.rewardCoins;
        }
        if ((i4 & 16) != 0) {
            i3 = missionDef.labelRes;
        }
        int i5 = i3;
        int i6 = i;
        return missionDef.copy(str, missionMetric, i6, i2, i5);
    }

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final MissionMetric getMetric() {
        return this.metric;
    }

    /* renamed from: component3, reason: from getter */
    public final int getTarget() {
        return this.target;
    }

    /* renamed from: component4, reason: from getter */
    public final int getRewardCoins() {
        return this.rewardCoins;
    }

    /* renamed from: component5, reason: from getter */
    public final int getLabelRes() {
        return this.labelRes;
    }

    public final MissionDef copy(String id, MissionMetric metric, int target, int rewardCoins, int labelRes) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(metric, "metric");
        return new MissionDef(id, metric, target, rewardCoins, labelRes);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MissionDef)) {
            return false;
        }
        MissionDef missionDef = (MissionDef) other;
        return Intrinsics.areEqual(this.id, missionDef.id) && this.metric == missionDef.metric && this.target == missionDef.target && this.rewardCoins == missionDef.rewardCoins && this.labelRes == missionDef.labelRes;
    }

    public int hashCode() {
        return (((((((this.id.hashCode() * 31) + this.metric.hashCode()) * 31) + Integer.hashCode(this.target)) * 31) + Integer.hashCode(this.rewardCoins)) * 31) + Integer.hashCode(this.labelRes);
    }

    public String toString() {
        return "MissionDef(id=" + this.id + ", metric=" + this.metric + ", target=" + this.target + ", rewardCoins=" + this.rewardCoins + ", labelRes=" + this.labelRes + ")";
    }

    public MissionDef(String id, MissionMetric metric, int i, int i2, int i3) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(metric, "metric");
        this.id = id;
        this.metric = metric;
        this.target = i;
        this.rewardCoins = i2;
        this.labelRes = i3;
    }

    public final String getId() {
        return this.id;
    }

    public final MissionMetric getMetric() {
        return this.metric;
    }

    public final int getTarget() {
        return this.target;
    }

    public final int getRewardCoins() {
        return this.rewardCoins;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    public final int progress(PlayerState state) {
        Intrinsics.checkNotNullParameter(state, "state");
        switch (WhenMappings.$EnumSwitchMapping$0[this.metric.ordinal()]) {
            case 1:
                return state.getTotalDistance();
            case 2:
                return state.getTotalCoins();
            case 3:
                return state.getTotalObstacles();
            case 4:
                return state.getTotalPowerups();
            case 5:
                return state.getTotalRuns();
            case 6:
                return state.getTotalTokens();
            case 7:
                return state.getBestRunSeconds();
            case 8:
                return state.getHighScore();
            default:
                throw new NoWhenBranchMatchedException();
        }
    }
}
