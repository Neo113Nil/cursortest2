package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.championship.warriors.iron.legacy.presentation.game.GameView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

/* loaded from: classes.dex */
public final class FragmentGameplayBinding implements ViewBinding {
    public final TextView coinsValue;
    public final TextView comboText;
    public final TextView distanceValue;
    public final GameView gameView;
    public final TextView goText;
    public final LinearLayout hud;
    public final ImageButton pauseButton;
    public final FrameLayout pauseOverlay;
    public final ImageView powerDouble;
    public final ImageView powerMagnet;
    public final ImageView powerShield;
    public final ImageView powerSlowmo;
    public final ImageView powerSpeed;
    public final LinearProgressIndicator progressBar;
    public final MaterialButton quitButton;
    public final MaterialButton restartButton;
    public final MaterialButton resumeButton;
    private final FrameLayout rootView;
    public final TextView scoreValue;
    public final TextView startHint;
    public final TextView timeText;

    private FragmentGameplayBinding(FrameLayout frameLayout, TextView textView, TextView textView2, TextView textView3, GameView gameView, TextView textView4, LinearLayout linearLayout, ImageButton imageButton, FrameLayout frameLayout2, ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, ImageView imageView5, LinearProgressIndicator linearProgressIndicator, MaterialButton materialButton, MaterialButton materialButton2, MaterialButton materialButton3, TextView textView5, TextView textView6, TextView textView7) {
        this.rootView = frameLayout;
        this.coinsValue = textView;
        this.comboText = textView2;
        this.distanceValue = textView3;
        this.gameView = gameView;
        this.goText = textView4;
        this.hud = linearLayout;
        this.pauseButton = imageButton;
        this.pauseOverlay = frameLayout2;
        this.powerDouble = imageView;
        this.powerMagnet = imageView2;
        this.powerShield = imageView3;
        this.powerSlowmo = imageView4;
        this.powerSpeed = imageView5;
        this.progressBar = linearProgressIndicator;
        this.quitButton = materialButton;
        this.restartButton = materialButton2;
        this.resumeButton = materialButton3;
        this.scoreValue = textView5;
        this.startHint = textView6;
        this.timeText = textView7;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentGameplayBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentGameplayBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_gameplay, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentGameplayBinding bind(View view) {
        int i = R.id.coinsValue;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
        if (textView != null) {
            i = R.id.comboText;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
            if (textView2 != null) {
                i = R.id.distanceValue;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView3 != null) {
                    i = R.id.gameView;
                    GameView gameView = (GameView) ViewBindings.findChildViewById(view, i);
                    if (gameView != null) {
                        i = R.id.goText;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                        if (textView4 != null) {
                            i = R.id.hud;
                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                            if (linearLayout != null) {
                                i = R.id.pauseButton;
                                ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
                                if (imageButton != null) {
                                    i = R.id.pauseOverlay;
                                    FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i);
                                    if (frameLayout != null) {
                                        i = R.id.powerDouble;
                                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                        if (imageView != null) {
                                            i = R.id.powerMagnet;
                                            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                            if (imageView2 != null) {
                                                i = R.id.powerShield;
                                                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                if (imageView3 != null) {
                                                    i = R.id.powerSlowmo;
                                                    ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                    if (imageView4 != null) {
                                                        i = R.id.powerSpeed;
                                                        ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                        if (imageView5 != null) {
                                                            i = R.id.progressBar;
                                                            LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) ViewBindings.findChildViewById(view, i);
                                                            if (linearProgressIndicator != null) {
                                                                i = R.id.quitButton;
                                                                MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                                                if (materialButton != null) {
                                                                    i = R.id.restartButton;
                                                                    MaterialButton materialButton2 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                                                    if (materialButton2 != null) {
                                                                        i = R.id.resumeButton;
                                                                        MaterialButton materialButton3 = (MaterialButton) ViewBindings.findChildViewById(view, i);
                                                                        if (materialButton3 != null) {
                                                                            i = R.id.scoreValue;
                                                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                            if (textView5 != null) {
                                                                                i = R.id.startHint;
                                                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                if (textView6 != null) {
                                                                                    i = R.id.timeText;
                                                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i);
                                                                                    if (textView7 != null) {
                                                                                        return new FragmentGameplayBinding((FrameLayout) view, textView, textView2, textView3, gameView, textView4, linearLayout, imageButton, frameLayout, imageView, imageView2, imageView3, imageView4, imageView5, linearProgressIndicator, materialButton, materialButton2, materialButton3, textView5, textView6, textView7);
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
