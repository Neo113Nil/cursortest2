package com.championship.warriors.iron.legacy.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.championship.warriors.iron.legacy.R;
import com.google.android.material.button.MaterialButton;

/* loaded from: classes.dex */
public final class FragmentStageDetailsBinding implements ViewBinding {
    public final View accentBar;
    public final ImageButton backButton;
    public final TextView bestText;
    public final TextView boostsNote;
    public final LinearLayout goalsContainer;
    public final MaterialButton playButton;
    private final FrameLayout rootView;
    public final TextView stageEnv;
    public final TextView stageName;
    public final ImageView star1;
    public final ImageView star2;
    public final ImageView star3;

    private FragmentStageDetailsBinding(FrameLayout frameLayout, View view, ImageButton imageButton, TextView textView, TextView textView2, LinearLayout linearLayout, MaterialButton materialButton, TextView textView3, TextView textView4, ImageView imageView, ImageView imageView2, ImageView imageView3) {
        this.rootView = frameLayout;
        this.accentBar = view;
        this.backButton = imageButton;
        this.bestText = textView;
        this.boostsNote = textView2;
        this.goalsContainer = linearLayout;
        this.playButton = materialButton;
        this.stageEnv = textView3;
        this.stageName = textView4;
        this.star1 = imageView;
        this.star2 = imageView2;
        this.star3 = imageView3;
    }

    @Override // androidx.viewbinding.ViewBinding
    public FrameLayout getRoot() {
        return this.rootView;
    }

    public static FragmentStageDetailsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FragmentStageDetailsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_stage_details, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static FragmentStageDetailsBinding bind(View view) {
        int i = R.id.accentBar;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i);
        if (viewFindChildViewById != null) {
            i = R.id.backButton;
            ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
            if (imageButton != null) {
                i = R.id.bestText;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.boostsNote;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        i = R.id.goalsContainer;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i);
                        if (linearLayout != null) {
                            i = R.id.playButton;
                            MaterialButton materialButton = (MaterialButton) ViewBindings.findChildViewById(view, i);
                            if (materialButton != null) {
                                i = R.id.stageEnv;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i);
                                if (textView3 != null) {
                                    i = R.id.stageName;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i);
                                    if (textView4 != null) {
                                        i = R.id.star1;
                                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
                                        if (imageView != null) {
                                            i = R.id.star2;
                                            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i);
                                            if (imageView2 != null) {
                                                i = R.id.star3;
                                                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i);
                                                if (imageView3 != null) {
                                                    return new FragmentStageDetailsBinding((FrameLayout) view, viewFindChildViewById, imageButton, textView, textView2, linearLayout, materialButton, textView3, textView4, imageView, imageView2, imageView3);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
