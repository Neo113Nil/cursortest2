package com.novayatema.fsnfjkrghl.tipico;

import a.a0;
import a.j0;
import a.k0;
import a.p;
import a.q;
import a.r;
import a.s;
import a.u;
import a.w;
import a.x;
import a.y;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.novayatema.fsnfjkrghl.tipico.MainActivity;
import com.novayatema.fsnfjkrghl.tipico.R;
import e3.e;
import e3.m;
import g.i;
import g2.b0;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.WeakHashMap;
import l0.d0;
import l0.l0;
import m3.f;
import o2.b;
import q3.n;
import w2.a;
import x2.c;

/* compiled from: r8-map-id-9da95fddba5760ea906e3a87b273cad99fbfa8067767d44890d2bdba4f879307 */
/* loaded from: classes.dex */
public final class MainActivity extends i {
    public static final /* synthetic */ int M = 0;
    public final b F;
    public String G;
    public final b I;
    public final b J;
    public final b K;
    public final int[] H = {61131, 25234, 44562, 48466, 33326, 32929, 60812, 36433, 53858, 24466};
    public final b L = new b(new a0(2));

    public MainActivity() {
        final int i = 0;
        this.F = new b(new a(this) { // from class: m2.d

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f2873g;

            {
                this.f2873g = this;
            }

            @Override // w2.a
            public final Object a() {
                int i4 = i;
                MainActivity mainActivity = this.f2873g;
                switch (i4) {
                    case 0:
                        int i5 = MainActivity.M;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) q3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new n2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    case 1:
                        int i6 = MainActivity.M;
                        return mainActivity.r(new byte[]{1, -12, 5}, 1);
                    case 2:
                        int i7 = MainActivity.M;
                        return mainActivity.r(new byte[]{-36, 103, -36, 126}, 2);
                    default:
                        return mainActivity.getSharedPreferences((String) mainActivity.I.a(), 0);
                }
            }
        });
        final int i4 = 1;
        this.I = new b(new a(this) { // from class: m2.d

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f2873g;

            {
                this.f2873g = this;
            }

            @Override // w2.a
            public final Object a() {
                int i42 = i4;
                MainActivity mainActivity = this.f2873g;
                switch (i42) {
                    case 0:
                        int i5 = MainActivity.M;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) q3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new n2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    case 1:
                        int i6 = MainActivity.M;
                        return mainActivity.r(new byte[]{1, -12, 5}, 1);
                    case 2:
                        int i7 = MainActivity.M;
                        return mainActivity.r(new byte[]{-36, 103, -36, 126}, 2);
                    default:
                        return mainActivity.getSharedPreferences((String) mainActivity.I.a(), 0);
                }
            }
        });
        final int i5 = 2;
        this.J = new b(new a(this) { // from class: m2.d

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f2873g;

            {
                this.f2873g = this;
            }

            @Override // w2.a
            public final Object a() {
                int i42 = i5;
                MainActivity mainActivity = this.f2873g;
                switch (i42) {
                    case 0:
                        int i52 = MainActivity.M;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) q3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new n2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    case 1:
                        int i6 = MainActivity.M;
                        return mainActivity.r(new byte[]{1, -12, 5}, 1);
                    case 2:
                        int i7 = MainActivity.M;
                        return mainActivity.r(new byte[]{-36, 103, -36, 126}, 2);
                    default:
                        return mainActivity.getSharedPreferences((String) mainActivity.I.a(), 0);
                }
            }
        });
        final int i6 = 3;
        this.K = new b(new a(this) { // from class: m2.d

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f2873g;

            {
                this.f2873g = this;
            }

            @Override // w2.a
            public final Object a() {
                int i42 = i6;
                MainActivity mainActivity = this.f2873g;
                switch (i42) {
                    case 0:
                        int i52 = MainActivity.M;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) q3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new n2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    case 1:
                        int i62 = MainActivity.M;
                        return mainActivity.r(new byte[]{1, -12, 5}, 1);
                    case 2:
                        int i7 = MainActivity.M;
                        return mainActivity.r(new byte[]{-36, 103, -36, 126}, 2);
                    default:
                        return mainActivity.getSharedPreferences((String) mainActivity.I.a(), 0);
                }
            }
        });
    }

    @Override // g.i, a.m, a0.f, android.app.Activity
    public final void onCreate(Bundle bundle) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        super.onCreate(bundle);
        String str = Build.DEVICE;
        c.d(str, "DEVICE");
        new StringBuilder((CharSequence) str).reverse().getClass();
        int i = 0;
        k0 k0Var = new k0(0, 0, new j0(0));
        k0 k0Var2 = new k0(r.f70a, r.f71b, new j0(0));
        View decorView = getWindow().getDecorView();
        c.d(decorView, "getDecorView(...)");
        s yVar = r.f72c;
        if (yVar == null) {
            int i4 = Build.VERSION.SDK_INT;
            yVar = i4 >= 35 ? new y() : i4 >= 30 ? new x() : i4 >= 29 ? new w() : i4 >= 28 ? new u() : new s();
            r.f72c = yVar;
        }
        s sVar = yVar;
        p pVar = new p(sVar, k0Var, k0Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        while (true) {
            if (i >= viewGroup.getChildCount()) {
                q qVar = new q(pVar, viewGroup.getContext());
                qVar.setTag(sVar);
                qVar.setVisibility(8);
                qVar.setWillNotDraw(true);
                viewGroup.addView(qVar);
                break;
            }
            int i5 = i + 1;
            View childAt = viewGroup.getChildAt(i);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof s) {
                break;
            } else {
                i = i5;
            }
        }
        pVar.run();
        Window window = getWindow();
        c.d(window, "getWindow(...)");
        sVar.a(window);
        setContentView(((n2.b) this.F.a()).f2980a);
        View viewFindViewById = findViewById(R.id.main);
        j0 j0Var = new j0(11);
        WeakHashMap weakHashMap = l0.f2742a;
        d0.c(viewFindViewById, j0Var);
        getWindow().setFlags(1024, 1024);
        String string = ((SharedPreferences) this.K.a()).getString((String) this.J.a(), null);
        if (string != null && !e.w0(string)) {
            this.G = string;
            u(string);
        } else if (System.currentTimeMillis() > 0) {
            s();
        } else {
            s();
        }
    }

    @Override // g.i, android.app.Activity
    public final void onResume() {
        super.onResume();
        String str = this.G;
        if (str != null) {
            u(str);
        }
    }

    public final String r(byte[] bArr, int i) {
        int i4 = this.H[i];
        int i5 = (i4 >> 8) & 255;
        int i6 = i4 & 255;
        ArrayList arrayList = new ArrayList(bArr.length);
        int length = bArr.length;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        while (i8 < length) {
            int i10 = i9 + 1;
            arrayList.add(Byte.valueOf((byte) ((i9 % 2 == 0 ? i5 : i6) ^ (bArr[i8] & 255))));
            i8++;
            i9 = i10;
        }
        byte[] bArr2 = new byte[arrayList.size()];
        int size = arrayList.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList.get(i11);
            i11++;
            bArr2[i7] = ((Number) obj).byteValue();
            i7++;
        }
        return new String(bArr2, e3.a.f1460a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0133, code lost:
    
        r5 = r4;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void s() {
        f fVar;
        String strR = r(new byte[]{-36, 103, -36, 126}, 2);
        String strConcat = r(new byte[]{-122, -65, -102, -69, -99, -15, -63, -28, -103, -82, -113, -65, -122, -82, -100, -82, -118, -26, -99, -93, -113, -69, -117, -26, -116, -82, -115, -8, -64, -90, -117, -89, -113, -91, -121, -86, -123, -71, -121, -72, -102, -86, -126, -13, -64, -68, -127, -71, -123, -82, -100, -72, -64, -81, -117, -67}, 0) + r(new byte[]{-79, 48, -2, 33, -77}, 7) + getPackageName();
        c.d(strConcat, "toString(...)");
        String strR2 = r(new byte[]{-27, 127, -7, 55, -53, 59, -34, 55, -112, 31, -46, 54, -40, 62}, 3);
        String strR3 = r(new byte[]{-61, 77, -31, 75, -14, 90, -81, 98, -29, 64, -27, 91, -29, 73, -25}, 4);
        String strR4 = r(new byte[]{-27, -49, -83, -12, -45, -115, -27, -49, -69, -48, -67, -111, -82, -104}, 5);
        String strR5 = r(new byte[]{-72, -1, -120, -2, -64, -51, -118, -23, -125, -8}, 6);
        a1.c cVar = new a1.c(6);
        if (m.o0(strConcat, "ws:", true)) {
            String strSubstring = strConcat.substring(3);
            c.d(strSubstring, "this as java.lang.String).substring(startIndex)");
            strConcat = "http:".concat(strSubstring);
        } else if (m.o0(strConcat, "wss:", true)) {
            String strSubstring2 = strConcat.substring(4);
            c.d(strSubstring2, "this as java.lang.String).substring(startIndex)");
            strConcat = "https:".concat(strSubstring2);
        }
        c.e(strConcat, "<this>");
        b0 b0Var = new b0(1);
        f fVar2 = null;
        b0Var.f(null, strConcat);
        cVar.f97f = b0Var.c();
        String str = Build.MODEL;
        c.d(str, "MODEL");
        cVar.n(strR2, str);
        cVar.n(strR3, strR4);
        String defaultUserAgent = WebSettings.getDefaultUserAgent(this);
        c.d(defaultUserAgent, "getDefaultUserAgent(...)");
        cVar.n(strR5, defaultUserAgent);
        i3.r rVarD = cVar.d();
        i3.p pVar = (i3.p) this.L.a();
        pVar.getClass();
        m3.i iVar = new m3.i(pVar, rVarD);
        a2.r rVar = new a2.r((LayoutInflater.Factory2) this, (Object) strR, 15);
        if (!iVar.f2911j.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed");
        }
        n nVar = n.f3266a;
        iVar.f2912k = n.f3266a.g();
        a1.c cVar2 = pVar.f2040f;
        f fVar3 = new f(iVar, rVar);
        cVar2.getClass();
        synchronized (cVar2) {
            ((ArrayDeque) cVar2.f98g).add(fVar3);
            String str2 = rVarD.f2065a.d;
            Iterator it = ((ArrayDeque) cVar2.h).iterator();
            while (true) {
                if (it.hasNext()) {
                    fVar = (f) it.next();
                    if (c.a(fVar.h.f2910g.f2065a.d, str2)) {
                        break;
                    }
                } else {
                    Iterator it2 = ((ArrayDeque) cVar2.f98g).iterator();
                    while (it2.hasNext()) {
                        fVar = (f) it2.next();
                        if (c.a(fVar.h.f2910g.f2065a.d, str2)) {
                        }
                    }
                }
            }
            if (fVar2 != null) {
                fVar3.f2906g = fVar2.f2906g;
            }
        }
        cVar2.t();
    }

    public final void t() {
        String str = Build.BRAND;
        c.d(str, "BRAND");
        c.d(str.toUpperCase(Locale.ROOT), "toUpperCase(...)");
        startActivity(new Intent(this, (Class<?>) MainActivity2.class));
    }

    public final void u(String str) {
        try {
            long jCurrentTimeMillis = System.currentTimeMillis() % 1000;
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Exception unused) {
            t();
        }
    }
}
