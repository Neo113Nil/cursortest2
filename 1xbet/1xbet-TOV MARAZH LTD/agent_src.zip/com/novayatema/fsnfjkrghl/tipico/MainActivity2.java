package com.novayatema.fsnfjkrghl.tipico;

import a.e0;
import a2.e;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.s;
import com.google.android.material.button.MaterialButton;
import com.novayatema.fsnfjkrghl.tipico.MainActivity2;
import com.novayatema.fsnfjkrghl.tipico.R;
import e3.l;
import g.i;
import java.util.Random;
import m2.b;
import m2.c;
import m2.h;
import n2.a;
import q3.d;

/* compiled from: r8-map-id-9da95fddba5760ea906e3a87b273cad99fbfa8067767d44890d2bdba4f879307 */
/* loaded from: classes.dex */
public final class MainActivity2 extends i {
    public static final /* synthetic */ int P = 0;
    public a F;
    public c H;
    public boolean L;
    public CountDownTimer M;
    public CountDownTimer N;
    public final e G = new e(26);
    public m2.a I = m2.a.f2859f;
    public b J = b.f2861f;
    public final StringBuilder K = new StringBuilder();
    public final o2.b O = new o2.b(new e0(1, this));

    public final void A() {
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView = aVar.f2960e;
        x2.c.d(textView, "chipClassic");
        w(textView, this.J == b.f2861f);
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView2 = aVar2.d;
        x2.c.d(textView2, "chipBlitz");
        w(textView2, this.J == b.f2862g);
    }

    @Override // g.i, a.m, a0.f, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main2, (ViewGroup) null, false);
        int i = R.id.btnPlayAgain;
        MaterialButton materialButton = (MaterialButton) d.v(viewInflate, R.id.btnPlayAgain);
        if (materialButton != null) {
            i = R.id.btnStart;
            MaterialButton materialButton2 = (MaterialButton) d.v(viewInflate, R.id.btnStart);
            if (materialButton2 != null) {
                i = R.id.btnToMenu;
                MaterialButton materialButton3 = (MaterialButton) d.v(viewInflate, R.id.btnToMenu);
                if (materialButton3 != null) {
                    i = R.id.chipBlitz;
                    TextView textView = (TextView) d.v(viewInflate, R.id.chipBlitz);
                    if (textView != null) {
                        i = R.id.chipClassic;
                        TextView textView2 = (TextView) d.v(viewInflate, R.id.chipClassic);
                        if (textView2 != null) {
                            i = R.id.chipEasy;
                            TextView textView3 = (TextView) d.v(viewInflate, R.id.chipEasy);
                            if (textView3 != null) {
                                i = R.id.chipHard;
                                TextView textView4 = (TextView) d.v(viewInflate, R.id.chipHard);
                                if (textView4 != null) {
                                    i = R.id.chipMedium;
                                    TextView textView5 = (TextView) d.v(viewInflate, R.id.chipMedium);
                                    if (textView5 != null) {
                                        i = R.id.key0;
                                        TextView textView6 = (TextView) d.v(viewInflate, R.id.key0);
                                        if (textView6 != null) {
                                            i = R.id.key1;
                                            TextView textView7 = (TextView) d.v(viewInflate, R.id.key1);
                                            if (textView7 != null) {
                                                i = R.id.key2;
                                                TextView textView8 = (TextView) d.v(viewInflate, R.id.key2);
                                                if (textView8 != null) {
                                                    i = R.id.key3;
                                                    TextView textView9 = (TextView) d.v(viewInflate, R.id.key3);
                                                    if (textView9 != null) {
                                                        i = R.id.key4;
                                                        TextView textView10 = (TextView) d.v(viewInflate, R.id.key4);
                                                        if (textView10 != null) {
                                                            i = R.id.key5;
                                                            TextView textView11 = (TextView) d.v(viewInflate, R.id.key5);
                                                            if (textView11 != null) {
                                                                i = R.id.key6;
                                                                TextView textView12 = (TextView) d.v(viewInflate, R.id.key6);
                                                                if (textView12 != null) {
                                                                    i = R.id.key7;
                                                                    TextView textView13 = (TextView) d.v(viewInflate, R.id.key7);
                                                                    if (textView13 != null) {
                                                                        i = R.id.key8;
                                                                        TextView textView14 = (TextView) d.v(viewInflate, R.id.key8);
                                                                        if (textView14 != null) {
                                                                            i = R.id.key9;
                                                                            TextView textView15 = (TextView) d.v(viewInflate, R.id.key9);
                                                                            if (textView15 != null) {
                                                                                i = R.id.keyClear;
                                                                                TextView textView16 = (TextView) d.v(viewInflate, R.id.keyClear);
                                                                                if (textView16 != null) {
                                                                                    i = R.id.keySubmit;
                                                                                    TextView textView17 = (TextView) d.v(viewInflate, R.id.keySubmit);
                                                                                    if (textView17 != null) {
                                                                                        i = R.id.keypad;
                                                                                        if (((GridLayout) d.v(viewInflate, R.id.keypad)) != null) {
                                                                                            i = R.id.panelGame;
                                                                                            LinearLayout linearLayout = (LinearLayout) d.v(viewInflate, R.id.panelGame);
                                                                                            if (linearLayout != null) {
                                                                                                i = R.id.panelMenu;
                                                                                                NestedScrollView nestedScrollView = (NestedScrollView) d.v(viewInflate, R.id.panelMenu);
                                                                                                if (nestedScrollView != null) {
                                                                                                    i = R.id.panelResult;
                                                                                                    NestedScrollView nestedScrollView2 = (NestedScrollView) d.v(viewInflate, R.id.panelResult);
                                                                                                    if (nestedScrollView2 != null) {
                                                                                                        FrameLayout frameLayout = (FrameLayout) viewInflate;
                                                                                                        i = R.id.tvAnswer;
                                                                                                        TextView textView18 = (TextView) d.v(viewInflate, R.id.tvAnswer);
                                                                                                        if (textView18 != null) {
                                                                                                            i = R.id.tvBestScore;
                                                                                                            TextView textView19 = (TextView) d.v(viewInflate, R.id.tvBestScore);
                                                                                                            if (textView19 != null) {
                                                                                                                i = R.id.tvEquation;
                                                                                                                TextView textView20 = (TextView) d.v(viewInflate, R.id.tvEquation);
                                                                                                                if (textView20 != null) {
                                                                                                                    i = R.id.tvFeedback;
                                                                                                                    TextView textView21 = (TextView) d.v(viewInflate, R.id.tvFeedback);
                                                                                                                    if (textView21 != null) {
                                                                                                                        i = R.id.tvGameSubtitle;
                                                                                                                        if (((TextView) d.v(viewInflate, R.id.tvGameSubtitle)) != null) {
                                                                                                                            i = R.id.tvGameTitle;
                                                                                                                            if (((TextView) d.v(viewInflate, R.id.tvGameTitle)) != null) {
                                                                                                                                i = R.id.tvHowTo;
                                                                                                                                if (((TextView) d.v(viewInflate, R.id.tvHowTo)) != null) {
                                                                                                                                    i = R.id.tvLives;
                                                                                                                                    TextView textView22 = (TextView) d.v(viewInflate, R.id.tvLives);
                                                                                                                                    if (textView22 != null) {
                                                                                                                                        i = R.id.tvNewRecord;
                                                                                                                                        TextView textView23 = (TextView) d.v(viewInflate, R.id.tvNewRecord);
                                                                                                                                        if (textView23 != null) {
                                                                                                                                            i = R.id.tvResultBest;
                                                                                                                                            TextView textView24 = (TextView) d.v(viewInflate, R.id.tvResultBest);
                                                                                                                                            if (textView24 != null) {
                                                                                                                                                i = R.id.tvResultCorrect;
                                                                                                                                                TextView textView25 = (TextView) d.v(viewInflate, R.id.tvResultCorrect);
                                                                                                                                                if (textView25 != null) {
                                                                                                                                                    i = R.id.tvResultScore;
                                                                                                                                                    TextView textView26 = (TextView) d.v(viewInflate, R.id.tvResultScore);
                                                                                                                                                    if (textView26 != null) {
                                                                                                                                                        i = R.id.tvResultStreak;
                                                                                                                                                        TextView textView27 = (TextView) d.v(viewInflate, R.id.tvResultStreak);
                                                                                                                                                        if (textView27 != null) {
                                                                                                                                                            i = R.id.tvResultTitle;
                                                                                                                                                            if (((TextView) d.v(viewInflate, R.id.tvResultTitle)) != null) {
                                                                                                                                                                i = R.id.tvResultWrong;
                                                                                                                                                                TextView textView28 = (TextView) d.v(viewInflate, R.id.tvResultWrong);
                                                                                                                                                                if (textView28 != null) {
                                                                                                                                                                    i = R.id.tvRound;
                                                                                                                                                                    TextView textView29 = (TextView) d.v(viewInflate, R.id.tvRound);
                                                                                                                                                                    if (textView29 != null) {
                                                                                                                                                                        i = R.id.tvScore;
                                                                                                                                                                        TextView textView30 = (TextView) d.v(viewInflate, R.id.tvScore);
                                                                                                                                                                        if (textView30 != null) {
                                                                                                                                                                            i = R.id.tvStreak;
                                                                                                                                                                            TextView textView31 = (TextView) d.v(viewInflate, R.id.tvStreak);
                                                                                                                                                                            if (textView31 != null) {
                                                                                                                                                                                i = R.id.tvTimer;
                                                                                                                                                                                TextView textView32 = (TextView) d.v(viewInflate, R.id.tvTimer);
                                                                                                                                                                                if (textView32 != null) {
                                                                                                                                                                                    this.F = new a(materialButton, materialButton2, materialButton3, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, textView16, textView17, linearLayout, nestedScrollView, nestedScrollView2, frameLayout, textView18, textView19, textView20, textView21, textView22, textView23, textView24, textView25, textView26, textView27, textView28, textView29, textView30, textView31, textView32);
                                                                                                                                                                                    setContentView(frameLayout);
                                                                                                                                                                                    t();
                                                                                                                                                                                    y();
                                                                                                                                                                                    A();
                                                                                                                                                                                    a aVar = this.F;
                                                                                                                                                                                    if (aVar == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i4 = 4;
                                                                                                                                                                                    aVar.f2961f.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i5;
                                                                                                                                                                                            int i6 = i4;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i6) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i7 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i8 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i9 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i9 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i9 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar2 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar2 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar2.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar3 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar3 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar3.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar4 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar4, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar4.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i5 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i5 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i5 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i5;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar5 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar5 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar5.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar6 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar6 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar6.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar2 = this.F;
                                                                                                                                                                                    if (aVar2 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i5 = 5;
                                                                                                                                                                                    aVar2.h.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i6 = i5;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i6) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i7 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i8 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i9 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i9 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i9 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar3 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar3 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar3.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar4 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar4, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar4.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar5 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar5 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar5.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar6 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar6 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar6.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar3 = this.F;
                                                                                                                                                                                    if (aVar3 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i6 = 6;
                                                                                                                                                                                    aVar3.f2962g.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i6;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i7 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i8 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i9 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i9 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i9 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar4 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar4, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar4.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar5 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar5 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar5.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar6 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar6 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar6.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar4 = this.F;
                                                                                                                                                                                    if (aVar4 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i7 = 7;
                                                                                                                                                                                    aVar4.f2960e.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i7;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i8 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i9 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i9 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i9 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar5 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar5 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar5.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar6 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar6 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar6.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar5 = this.F;
                                                                                                                                                                                    if (aVar5 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i8 = 8;
                                                                                                                                                                                    aVar5.d.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i8;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i9 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i9 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i9 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar6 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar6 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar6.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar6 = this.F;
                                                                                                                                                                                    if (aVar6 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i9 = 9;
                                                                                                                                                                                    aVar6.f2958b.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i9;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i92 = iVar.f2884a;
                                                                                                                                                                                                        int i10 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i92 - i10) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i92 - i10));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar62 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar62 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar62.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar7 = this.F;
                                                                                                                                                                                    if (aVar7 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    for (o2.a aVar8 : p2.i.H(new o2.a(aVar7.i, "0"), new o2.a(aVar7.f2963j, "1"), new o2.a(aVar7.f2964k, "2"), new o2.a(aVar7.f2965l, "3"), new o2.a(aVar7.f2966m, "4"), new o2.a(aVar7.f2967n, "5"), new o2.a(aVar7.f2968o, "6"), new o2.a(aVar7.f2969p, "7"), new o2.a(aVar7.f2970q, "8"), new o2.a(aVar7.f2971r, "9"))) {
                                                                                                                                                                                        Object obj = aVar8.f3043f;
                                                                                                                                                                                        x2.c.d(obj, "component1(...)");
                                                                                                                                                                                        final String str = (String) aVar8.f3044g;
                                                                                                                                                                                        ((TextView) obj).setOnClickListener(new View.OnClickListener() { // from class: m2.g
                                                                                                                                                                                            @Override // android.view.View.OnClickListener
                                                                                                                                                                                            public final void onClick(View view) {
                                                                                                                                                                                                MainActivity2 mainActivity2 = this.f2880f;
                                                                                                                                                                                                StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                if (!mainActivity2.L && sb.length() < 4) {
                                                                                                                                                                                                    if (sb.length() == 1 && sb.charAt(0) == '0') {
                                                                                                                                                                                                        sb.setLength(0);
                                                                                                                                                                                                    }
                                                                                                                                                                                                    sb.append(str);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        });
                                                                                                                                                                                    }
                                                                                                                                                                                    a aVar9 = this.F;
                                                                                                                                                                                    if (aVar9 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i10 = 2;
                                                                                                                                                                                    aVar9.f2972s.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i10;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i92 = iVar.f2884a;
                                                                                                                                                                                                        int i102 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i92 - i102) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i92 - i102));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i11 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i11;
                                                                                                                                                                                                                if (i11 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar62 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar62 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar62.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar10 = this.F;
                                                                                                                                                                                    if (aVar10 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i11 = 3;
                                                                                                                                                                                    aVar10.f2973t.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i11;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i92 = iVar.f2884a;
                                                                                                                                                                                                        int i102 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i92 - i102) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i92 - i102));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i112 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i112;
                                                                                                                                                                                                                if (i112 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i12 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i12 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar62 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar62 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar62.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar11 = this.F;
                                                                                                                                                                                    if (aVar11 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i12 = 0;
                                                                                                                                                                                    aVar11.f2957a.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i12;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i92 = iVar.f2884a;
                                                                                                                                                                                                        int i102 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i92 - i102) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i92 - i102));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i112 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i112;
                                                                                                                                                                                                                if (i112 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i122 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i13 = ((i122 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i13;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar62 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar62 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar62.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i13)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    a aVar12 = this.F;
                                                                                                                                                                                    if (aVar12 == null) {
                                                                                                                                                                                        x2.c.h("binding");
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                    final int i13 = 1;
                                                                                                                                                                                    aVar12.f2959c.setOnClickListener(new View.OnClickListener(this) { // from class: m2.f

                                                                                                                                                                                        /* renamed from: g, reason: collision with root package name */
                                                                                                                                                                                        public final /* synthetic */ MainActivity2 f2879g;

                                                                                                                                                                                        {
                                                                                                                                                                                            this.f2879g = this;
                                                                                                                                                                                        }

                                                                                                                                                                                        @Override // android.view.View.OnClickListener
                                                                                                                                                                                        public final void onClick(View view) {
                                                                                                                                                                                            i iVar;
                                                                                                                                                                                            int i52;
                                                                                                                                                                                            int i62 = i13;
                                                                                                                                                                                            b bVar = b.f2861f;
                                                                                                                                                                                            MainActivity2 mainActivity2 = this.f2879g;
                                                                                                                                                                                            switch (i62) {
                                                                                                                                                                                                case 0:
                                                                                                                                                                                                    int i72 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 1:
                                                                                                                                                                                                    int i82 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.u();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 2:
                                                                                                                                                                                                    if (mainActivity2.L) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    StringBuilder sb = mainActivity2.K;
                                                                                                                                                                                                    x2.c.e(sb, "<this>");
                                                                                                                                                                                                    sb.setLength(0);
                                                                                                                                                                                                    mainActivity2.x();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 3:
                                                                                                                                                                                                    StringBuilder sb2 = mainActivity2.K;
                                                                                                                                                                                                    c cVar = mainActivity2.H;
                                                                                                                                                                                                    if (cVar == null || (iVar = cVar.f2870k) == null || mainActivity2.L || sb2.length() == 0) {
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    String string = sb2.toString();
                                                                                                                                                                                                    x2.c.d(string, "toString(...)");
                                                                                                                                                                                                    Integer numJ0 = l.j0(string);
                                                                                                                                                                                                    if (numJ0 != null) {
                                                                                                                                                                                                        int iIntValue = numJ0.intValue();
                                                                                                                                                                                                        mainActivity2.L = true;
                                                                                                                                                                                                        int i92 = iVar.f2884a;
                                                                                                                                                                                                        int i102 = iVar.f2885b;
                                                                                                                                                                                                        if (iIntValue != i92 - i102) {
                                                                                                                                                                                                            String string2 = mainActivity2.getString(R.string.feedback_wrong, Integer.valueOf(i92 - i102));
                                                                                                                                                                                                            x2.c.d(string2, "getString(...)");
                                                                                                                                                                                                            c cVar2 = mainActivity2.H;
                                                                                                                                                                                                            if (cVar2 == null) {
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            cVar2.f2866e = 0;
                                                                                                                                                                                                            cVar2.i++;
                                                                                                                                                                                                            cVar2.f2868g++;
                                                                                                                                                                                                            if (cVar2.f2864b == bVar) {
                                                                                                                                                                                                                int i112 = cVar2.d - 1;
                                                                                                                                                                                                                cVar2.d = i112;
                                                                                                                                                                                                                if (i112 <= 0) {
                                                                                                                                                                                                                    cVar2.f2871l = true;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            n2.a aVar22 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar22 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar22.A.setTextColor(mainActivity2.getColor(R.color.danger));
                                                                                                                                                                                                            n2.a aVar32 = mainActivity2.F;
                                                                                                                                                                                                            if (aVar32 == null) {
                                                                                                                                                                                                                x2.c.h("binding");
                                                                                                                                                                                                                throw null;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            aVar32.A.setText(string2);
                                                                                                                                                                                                            mainActivity2.z();
                                                                                                                                                                                                            if (cVar2.f2871l) {
                                                                                                                                                                                                                CountDownTimer countDownTimer = mainActivity2.N;
                                                                                                                                                                                                                if (countDownTimer != null) {
                                                                                                                                                                                                                    countDownTimer.cancel();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                mainActivity2.N = new h(mainActivity2).start();
                                                                                                                                                                                                                return;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            CountDownTimer countDownTimer2 = mainActivity2.N;
                                                                                                                                                                                                            if (countDownTimer2 != null) {
                                                                                                                                                                                                                countDownTimer2.cancel();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            mainActivity2.N = new h(1100L, mainActivity2).start();
                                                                                                                                                                                                            return;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        a2.e eVar = mainActivity2.G;
                                                                                                                                                                                                        a aVar42 = cVar.f2863a;
                                                                                                                                                                                                        int i122 = cVar.f2866e;
                                                                                                                                                                                                        eVar.getClass();
                                                                                                                                                                                                        x2.c.e(aVar42, "difficulty");
                                                                                                                                                                                                        int iOrdinal = aVar42.ordinal();
                                                                                                                                                                                                        if (iOrdinal == 0) {
                                                                                                                                                                                                            i52 = 10;
                                                                                                                                                                                                        } else if (iOrdinal == 1) {
                                                                                                                                                                                                            i52 = 20;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if (iOrdinal != 2) {
                                                                                                                                                                                                                throw new s();
                                                                                                                                                                                                            }
                                                                                                                                                                                                            i52 = 35;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        int i132 = ((i122 / 3) + 1) * i52;
                                                                                                                                                                                                        int i14 = cVar.f2866e + 1;
                                                                                                                                                                                                        cVar.f2866e = i14;
                                                                                                                                                                                                        if (i14 > cVar.f2867f) {
                                                                                                                                                                                                            cVar.f2867f = i14;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        cVar.h++;
                                                                                                                                                                                                        cVar.f2865c += i132;
                                                                                                                                                                                                        cVar.f2868g++;
                                                                                                                                                                                                        n2.a aVar52 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar52 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar52.A.setTextColor(mainActivity2.getColor(R.color.success));
                                                                                                                                                                                                        n2.a aVar62 = mainActivity2.F;
                                                                                                                                                                                                        if (aVar62 == null) {
                                                                                                                                                                                                            x2.c.h("binding");
                                                                                                                                                                                                            throw null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        aVar62.A.setText(mainActivity2.getString(R.string.feedback_correct, Integer.valueOf(i132)));
                                                                                                                                                                                                        mainActivity2.z();
                                                                                                                                                                                                        CountDownTimer countDownTimer3 = mainActivity2.N;
                                                                                                                                                                                                        if (countDownTimer3 != null) {
                                                                                                                                                                                                            countDownTimer3.cancel();
                                                                                                                                                                                                        }
                                                                                                                                                                                                        mainActivity2.N = new h(650L, mainActivity2).start();
                                                                                                                                                                                                        return;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 4:
                                                                                                                                                                                                    int i15 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2859f;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 5:
                                                                                                                                                                                                    int i16 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.f2860g;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 6:
                                                                                                                                                                                                    int i17 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.I = a.h;
                                                                                                                                                                                                    mainActivity2.y();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 7:
                                                                                                                                                                                                    int i18 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = bVar;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                case 8:
                                                                                                                                                                                                    int i19 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.J = b.f2862g;
                                                                                                                                                                                                    mainActivity2.A();
                                                                                                                                                                                                    return;
                                                                                                                                                                                                default:
                                                                                                                                                                                                    int i20 = MainActivity2.P;
                                                                                                                                                                                                    mainActivity2.v();
                                                                                                                                                                                                    return;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    });
                                                                                                                                                                                    u();
                                                                                                                                                                                    return;
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // g.i, android.app.Activity
    public final void onDestroy() throws Exception {
        CountDownTimer countDownTimer = this.M;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.N;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
        super.onDestroy();
    }

    public final void r() {
        CountDownTimer countDownTimer = this.M;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.N;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
        c cVar = this.H;
        if (cVar == null) {
            return;
        }
        cVar.f2871l = true;
        o2.b bVar = this.O;
        boolean z3 = cVar.f2865c > ((SharedPreferences) bVar.a()).getInt("best_score", 0);
        if (z3) {
            SharedPreferences sharedPreferences = (SharedPreferences) bVar.a();
            x2.c.d(sharedPreferences, "<get-prefs>(...)");
            SharedPreferences.Editor editorEdit = sharedPreferences.edit();
            editorEdit.putInt("best_score", cVar.f2865c);
            editorEdit.apply();
        }
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar.C.setVisibility(z3 ? 0 : 8);
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar2.F.setText(getString(R.string.result_score, Integer.valueOf(cVar.f2865c)));
        a aVar3 = this.F;
        if (aVar3 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar3.D.setText(getString(R.string.result_best, Integer.valueOf(((SharedPreferences) bVar.a()).getInt("best_score", cVar.f2865c))));
        a aVar4 = this.F;
        if (aVar4 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar4.E.setText(getString(R.string.result_correct, Integer.valueOf(cVar.h)));
        a aVar5 = this.F;
        if (aVar5 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar5.H.setText(getString(R.string.result_wrong, Integer.valueOf(cVar.i)));
        a aVar6 = this.F;
        if (aVar6 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar6.G.setText(getString(R.string.result_best_streak, Integer.valueOf(cVar.f2867f)));
        a aVar7 = this.F;
        if (aVar7 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar7.f2975v.setVisibility(8);
        a aVar8 = this.F;
        if (aVar8 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar8.f2974u.setVisibility(8);
        a aVar9 = this.F;
        if (aVar9 != null) {
            aVar9.f2976w.setVisibility(0);
        } else {
            x2.c.h("binding");
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00dc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void s() {
        m2.i iVar;
        m2.i iVar2;
        a aVar;
        String str;
        c cVar = this.H;
        if (cVar == null) {
            return;
        }
        if (cVar.f2871l) {
            r();
            return;
        }
        m2.a aVar2 = cVar.f2863a;
        Random random = (Random) this.G.f125g;
        x2.c.e(aVar2, "difficulty");
        int iOrdinal = aVar2.ordinal();
        if (iOrdinal != 0) {
            int iNextInt = 1;
            if (iOrdinal != 1) {
                if (iOrdinal != 2) {
                    throw new s();
                }
                int iNextInt2 = random.nextInt(850);
                int i = iNextInt2 + 150;
                if (random.nextBoolean()) {
                    int i4 = i % 10;
                    int i5 = i / 10;
                    if (i5 < 1) {
                        i5 = 1;
                    }
                    int iNextInt3 = (((random.nextInt(10 - i4) + i4) + 1) % 10) + (random.nextInt(i5) * 10);
                    int i6 = iNextInt2 + 149;
                    if (iNextInt3 > i6) {
                        iNextInt3 = i6;
                    }
                    if (iNextInt3 >= 1) {
                        iNextInt = iNextInt3;
                    }
                } else {
                    iNextInt = 1 + random.nextInt(iNextInt2 + 149);
                }
                iVar2 = new m2.i(i, iNextInt);
                cVar.f2870k = iVar2;
                StringBuilder sb = this.K;
                x2.c.e(sb, "<this>");
                sb.setLength(0);
                this.L = false;
                aVar = this.F;
                if (aVar != null) {
                    x2.c.h("binding");
                    throw null;
                }
                TextView textView = aVar.f2979z;
                m2.i iVar3 = cVar.f2870k;
                if (iVar3 != null) {
                    str = iVar3.f2884a + " − " + iVar3.f2885b;
                } else {
                    str = null;
                }
                textView.setText(str);
                x();
                z();
                a aVar3 = this.F;
                if (aVar3 != null) {
                    aVar3.A.setText("");
                    return;
                } else {
                    x2.c.h("binding");
                    throw null;
                }
            }
            int iNextInt4 = random.nextInt(80) + 20;
            iVar = new m2.i(iNextInt4, random.nextInt(iNextInt4));
        } else {
            int iNextInt5 = random.nextInt(9) + 2;
            iVar = new m2.i(iNextInt5, random.nextInt(iNextInt5));
        }
        iVar2 = iVar;
        cVar.f2870k = iVar2;
        StringBuilder sb2 = this.K;
        x2.c.e(sb2, "<this>");
        sb2.setLength(0);
        this.L = false;
        aVar = this.F;
        if (aVar != null) {
        }
    }

    public final void t() {
        int i = ((SharedPreferences) this.O.a()).getInt("best_score", 0);
        a aVar = this.F;
        if (aVar != null) {
            aVar.f2978y.setText(getString(R.string.menu_best_score, Integer.valueOf(i)));
        } else {
            x2.c.h("binding");
            throw null;
        }
    }

    public final void u() {
        CountDownTimer countDownTimer = this.M;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.N;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
        t();
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar.f2975v.setVisibility(0);
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar2.f2974u.setVisibility(8);
        a aVar3 = this.F;
        if (aVar3 != null) {
            aVar3.f2976w.setVisibility(8);
        } else {
            x2.c.h("binding");
            throw null;
        }
    }

    public final void v() {
        CountDownTimer countDownTimer = this.M;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        CountDownTimer countDownTimer2 = this.N;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
        this.H = new c(this.I, this.J);
        StringBuilder sb = this.K;
        x2.c.e(sb, "<this>");
        sb.setLength(0);
        this.L = false;
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar.A.setText("");
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView = aVar2.L;
        b bVar = this.J;
        b bVar2 = b.f2862g;
        textView.setVisibility(bVar == bVar2 ? 0 : 8);
        a aVar3 = this.F;
        if (aVar3 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar3.B.setVisibility(this.J == b.f2861f ? 0 : 8);
        a aVar4 = this.F;
        if (aVar4 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar4.f2975v.setVisibility(8);
        a aVar5 = this.F;
        if (aVar5 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar5.f2974u.setVisibility(0);
        a aVar6 = this.F;
        if (aVar6 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar6.f2976w.setVisibility(8);
        s();
        if (this.J == bVar2) {
            CountDownTimer countDownTimer3 = this.M;
            if (countDownTimer3 != null) {
                countDownTimer3.cancel();
            }
            c cVar = this.H;
            if (cVar == null) {
                return;
            }
            a aVar7 = this.F;
            if (aVar7 == null) {
                x2.c.h("binding");
                throw null;
            }
            aVar7.L.setText(getString(R.string.timer_label, Integer.valueOf(cVar.f2869j)));
            this.M = new h(this, cVar.f2869j * 1000).start();
        }
    }

    public final void w(TextView textView, boolean z3) {
        textView.setSelected(z3);
        textView.setTextColor(getColor(z3 ? R.color.bg_primary : R.color.text_primary));
    }

    public final void x() {
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView = aVar.f2977x;
        StringBuilder sb = this.K;
        textView.setText(sb.length() == 0 ? getString(R.string.answer_empty) : sb.toString());
    }

    public final void y() {
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView = aVar.f2961f;
        x2.c.d(textView, "chipEasy");
        w(textView, this.I == m2.a.f2859f);
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView2 = aVar2.h;
        x2.c.d(textView2, "chipMedium");
        w(textView2, this.I == m2.a.f2860g);
        a aVar3 = this.F;
        if (aVar3 == null) {
            x2.c.h("binding");
            throw null;
        }
        TextView textView3 = aVar3.f2962g;
        x2.c.d(textView3, "chipHard");
        w(textView3, this.I == m2.a.h);
    }

    public final void z() {
        c cVar = this.H;
        if (cVar == null) {
            return;
        }
        a aVar = this.F;
        if (aVar == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar.J.setText(getString(R.string.score_label, Integer.valueOf(cVar.f2865c)));
        a aVar2 = this.F;
        if (aVar2 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar2.K.setText(getString(R.string.streak_label, Integer.valueOf(cVar.f2866e)));
        a aVar3 = this.F;
        if (aVar3 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar3.B.setText(getString(R.string.lives_label, Integer.valueOf(cVar.d)));
        a aVar4 = this.F;
        if (aVar4 == null) {
            x2.c.h("binding");
            throw null;
        }
        aVar4.I.setText(getString(R.string.round_label, Integer.valueOf(cVar.f2868g + 1)));
        if (cVar.f2864b == b.f2862g) {
            a aVar5 = this.F;
            if (aVar5 != null) {
                aVar5.L.setText(getString(R.string.timer_label, Integer.valueOf(cVar.f2869j)));
            } else {
                x2.c.h("binding");
                throw null;
            }
        }
    }
}
