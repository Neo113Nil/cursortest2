package com.proyecto26.inappbrowser;

/* JADX INFO: loaded from: classes2.dex */
public class ChromeTabsDismissedEvent {
    public final Boolean isError;
    public final String message;
    public final String resultType;

    public ChromeTabsDismissedEvent(String str, String str2, Boolean bool) {
        this.message = str;
        this.resultType = str2;
        this.isError = bool;
    }
}
