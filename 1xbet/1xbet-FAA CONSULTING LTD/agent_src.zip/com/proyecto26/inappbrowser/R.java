package com.proyecto26.inappbrowser;

/* JADX INFO: loaded from: classes2.dex */
public final class R {

    public static final class drawable {
        public static int ic_arrow_back_black = 0x7f0700a0;
        public static int ic_arrow_back_white = 0x7f0700a2;

        private drawable() {
        }
    }

    private R() {
    }
}
