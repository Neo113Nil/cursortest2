package com.reactnativecommunity.webview;

import android.webkit.WebView;

/* JADX INFO: loaded from: classes3.dex */
public interface RNCWebViewConfig {
    void configWebView(WebView webView);
}
