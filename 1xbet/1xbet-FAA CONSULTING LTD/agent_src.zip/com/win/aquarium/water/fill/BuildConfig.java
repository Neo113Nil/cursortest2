package com.win.aquarium.water.fill;

/* JADX INFO: loaded from: classes3.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.win.aquarium.water.fill";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final boolean IS_EDGE_TO_EDGE_ENABLED = false;
    public static final boolean IS_HERMES_ENABLED = true;
    public static final boolean IS_NEW_ARCHITECTURE_ENABLED = true;
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
