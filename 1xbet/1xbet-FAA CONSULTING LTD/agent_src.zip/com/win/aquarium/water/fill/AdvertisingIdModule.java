package com.win.aquarium.water.fill;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.BaseJavaModule;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AdvertisingIdModule.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u00020\u0007H\u0016J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007¨\u0006\f"}, d2 = {"Lcom/win/aquarium/water/fill/AdvertisingIdModule;", "Lcom/facebook/react/bridge/ReactContextBaseJavaModule;", "reactContext", "Lcom/facebook/react/bridge/ReactApplicationContext;", "<init>", "(Lcom/facebook/react/bridge/ReactApplicationContext;)V", "getName", "", "getAdvertisingId", "", BaseJavaModule.METHOD_TYPE_PROMISE, "Lcom/facebook/react/bridge/Promise;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AdvertisingIdModule extends ReactContextBaseJavaModule {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AdvertisingIdModule(ReactApplicationContext reactContext) {
        super(reactContext);
        Intrinsics.checkNotNullParameter(reactContext, "reactContext");
    }

    @Override // com.facebook.react.bridge.NativeModule
    public String getName() {
        return "AdvertisingIdModule";
    }

    @ReactMethod
    public final void getAdvertisingId(final Promise promise) {
        Intrinsics.checkNotNullParameter(promise, "promise");
        try {
            new Thread(new Runnable() { // from class: com.win.aquarium.water.fill.AdvertisingIdModule$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AdvertisingIdModule.getAdvertisingId$lambda$1(this.f$0, promise);
                }
            }).start();
        } catch (Exception e) {
            promise.reject("ADID_THREAD_ERROR", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void getAdvertisingId$lambda$1(AdvertisingIdModule advertisingIdModule, Promise promise) {
        try {
            AdvertisingIdClient.Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(advertisingIdModule.getReactApplicationContext());
            Intrinsics.checkNotNullExpressionValue(advertisingIdInfo, "getAdvertisingIdInfo(...)");
            String id = advertisingIdInfo.getId();
            boolean zIsLimitAdTrackingEnabled = advertisingIdInfo.isLimitAdTrackingEnabled();
            WritableMap writableMapCreateMap = Arguments.createMap();
            writableMapCreateMap.putString("advertisingId", id);
            writableMapCreateMap.putBoolean("isLimitAdTrackingEnabled", zIsLimitAdTrackingEnabled);
            promise.resolve(writableMapCreateMap);
        } catch (Exception e) {
            promise.reject("ADID_ERROR", e);
        }
    }
}
