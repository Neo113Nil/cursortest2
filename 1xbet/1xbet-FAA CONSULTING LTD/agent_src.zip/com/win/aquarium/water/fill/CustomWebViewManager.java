package com.win.aquarium.water.fill;

import android.webkit.WebView;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;
import com.facebook.react.uimanager.ThemedReactContext;
import com.reactnativecommunity.webview.RNCWebViewManager;
import com.reactnativecommunity.webview.RNCWebViewWrapper;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CustomWebViewManager.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u000e2\u00020\u0001:\u0001\u000eB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0014J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0002¨\u0006\u000f"}, d2 = {"Lcom/win/aquarium/water/fill/CustomWebViewManager;", "Lcom/reactnativecommunity/webview/RNCWebViewManager;", "<init>", "()V", "getName", "", "createViewInstance", "Lcom/reactnativecommunity/webview/RNCWebViewWrapper;", "reactContext", "Lcom/facebook/react/uimanager/ThemedReactContext;", "enablePaymentRequest", "", "webView", "Landroid/webkit/WebView;", "Companion", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CustomWebViewManager extends RNCWebViewManager {
    public static final String REACT_CLASS = "RCTCustomWebView";

    @Override // com.reactnativecommunity.webview.RNCWebViewManager, com.facebook.react.uimanager.ViewManager, com.facebook.react.bridge.NativeModule
    public String getName() {
        return REACT_CLASS;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.reactnativecommunity.webview.RNCWebViewManager, com.facebook.react.uimanager.ViewManager
    public RNCWebViewWrapper createViewInstance(ThemedReactContext reactContext) {
        Intrinsics.checkNotNullParameter(reactContext, "reactContext");
        RNCWebViewWrapper rNCWebViewWrapperCreateViewInstance = super.createViewInstance(reactContext);
        Intrinsics.checkNotNullExpressionValue(rNCWebViewWrapperCreateViewInstance, "createViewInstance(...)");
        enablePaymentRequest(rNCWebViewWrapperCreateViewInstance.getWebView());
        return rNCWebViewWrapperCreateViewInstance;
    }

    private final void enablePaymentRequest(WebView webView) {
        if (WebViewFeature.isFeatureSupported("PAYMENT_REQUEST")) {
            WebSettingsCompat.setPaymentRequestEnabled(webView.getSettings(), true);
        }
    }
}
