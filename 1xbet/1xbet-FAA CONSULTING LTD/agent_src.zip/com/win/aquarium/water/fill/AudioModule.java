package com.win.aquarium.water.fill;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AudioModule.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u000f\u001a\u00020\fH\u0016J\u0010\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\fH\u0002J\u0018\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0015H\u0007J\b\u0010\u0016\u001a\u00020\u0013H\u0007J\b\u0010\u0017\u001a\u00020\u0013H\u0007J\b\u0010\u0018\u001a\u00020\u0013H\u0007J\b\u0010\u0019\u001a\u00020\u0013H\u0007J\b\u0010\u001a\u001a\u00020\u0013H\u0002J\u0010\u0010\u001b\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\fH\u0007J\b\u0010\u001c\u001a\u00020\u0013H\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010\n\u001a\u001e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000bj\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r`\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001d"}, d2 = {"Lcom/win/aquarium/water/fill/AudioModule;", "Lcom/facebook/react/bridge/ReactContextBaseJavaModule;", "reactContext", "Lcom/facebook/react/bridge/ReactApplicationContext;", "<init>", "(Lcom/facebook/react/bridge/ReactApplicationContext;)V", "music", "Landroid/media/MediaPlayer;", "soundPool", "Landroid/media/SoundPool;", "sfxIds", "Ljava/util/HashMap;", "", "", "Lkotlin/collections/HashMap;", "getName", "rawId", "name", "startMusic", "", "loop", "", "pauseMusic", "resumeMusic", "restartMusic", "stopMusic", "ensureSoundPool", "playSfx", "release", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AudioModule extends ReactContextBaseJavaModule {
    private MediaPlayer music;
    private final ReactApplicationContext reactContext;
    private final HashMap<String, Integer> sfxIds;
    private SoundPool soundPool;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AudioModule(ReactApplicationContext reactContext) {
        super(reactContext);
        Intrinsics.checkNotNullParameter(reactContext, "reactContext");
        this.reactContext = reactContext;
        this.sfxIds = new HashMap<>();
    }

    @Override // com.facebook.react.bridge.NativeModule
    public String getName() {
        return "AudioModule";
    }

    private final int rawId(String name) {
        return this.reactContext.getResources().getIdentifier(name, "raw", this.reactContext.getPackageName());
    }

    @ReactMethod
    public final void startMusic(String name, boolean loop) {
        Intrinsics.checkNotNullParameter(name, "name");
        try {
            if (this.music == null) {
                int iRawId = rawId(name);
                if (iRawId == 0) {
                    return;
                }
                MediaPlayer mediaPlayerCreate = MediaPlayer.create(this.reactContext, iRawId);
                this.music = mediaPlayerCreate;
                if (mediaPlayerCreate != null) {
                    mediaPlayerCreate.setLooping(loop);
                }
            }
            MediaPlayer mediaPlayer = this.music;
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        } catch (Exception unused) {
        }
    }

    @ReactMethod
    public final void pauseMusic() {
        MediaPlayer mediaPlayer;
        try {
            MediaPlayer mediaPlayer2 = this.music;
            if (mediaPlayer2 == null || !mediaPlayer2.isPlaying() || (mediaPlayer = this.music) == null) {
                return;
            }
            mediaPlayer.pause();
        } catch (Exception unused) {
        }
    }

    @ReactMethod
    public final void resumeMusic() {
        try {
            MediaPlayer mediaPlayer = this.music;
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        } catch (Exception unused) {
        }
    }

    @ReactMethod
    public final void restartMusic() {
        try {
            MediaPlayer mediaPlayer = this.music;
            if (mediaPlayer != null) {
                mediaPlayer.seekTo(0);
            }
            MediaPlayer mediaPlayer2 = this.music;
            if (mediaPlayer2 != null) {
                mediaPlayer2.start();
            }
        } catch (Exception unused) {
        }
    }

    @ReactMethod
    public final void stopMusic() {
        try {
            MediaPlayer mediaPlayer = this.music;
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            MediaPlayer mediaPlayer2 = this.music;
            if (mediaPlayer2 != null) {
                mediaPlayer2.release();
            }
        } catch (Exception unused) {
        }
        this.music = null;
    }

    private final void ensureSoundPool() {
        if (this.soundPool == null) {
            this.soundPool = new SoundPool.Builder().setMaxStreams(5).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).build();
        }
    }

    @ReactMethod
    public final void playSfx(String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        try {
            ensureSoundPool();
            SoundPool soundPool = this.soundPool;
            if (soundPool == null) {
                return;
            }
            Integer num = this.sfxIds.get(name);
            if (num != null) {
                soundPool.play(num.intValue(), 1.0f, 1.0f, 1, 0, 1.0f);
                return;
            }
            int iRawId = rawId(name);
            if (iRawId == 0) {
                return;
            }
            final int iLoad = soundPool.load(this.reactContext, iRawId, 1);
            this.sfxIds.put(name, Integer.valueOf(iLoad));
            soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() { // from class: com.win.aquarium.water.fill.AudioModule$$ExternalSyntheticLambda0
                @Override // android.media.SoundPool.OnLoadCompleteListener
                public final void onLoadComplete(SoundPool soundPool2, int i, int i2) {
                    AudioModule.playSfx$lambda$0(iLoad, soundPool2, i, i2);
                }
            });
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void playSfx$lambda$0(int i, SoundPool soundPool, int i2, int i3) {
        if (i3 == 0 && i2 == i) {
            soundPool.play(i, 1.0f, 1.0f, 1, 0, 1.0f);
        }
    }

    @ReactMethod
    public final void release() {
        try {
            MediaPlayer mediaPlayer = this.music;
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
            this.music = null;
            SoundPool soundPool = this.soundPool;
            if (soundPool != null) {
                soundPool.release();
            }
            this.soundPool = null;
            this.sfxIds.clear();
        } catch (Exception unused) {
        }
    }
}
