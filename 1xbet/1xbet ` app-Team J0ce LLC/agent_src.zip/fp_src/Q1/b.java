package Q1;

import N.f;
import a.AbstractC0129a;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import b.C0158b;
import b.d;
import g1.C0206a;
import g1.InterfaceC0207b;
import h1.InterfaceC0210a;
import h1.InterfaceC0211b;
import j1.C0241l;
import k1.C0284a;
import k1.C0297n;
import k1.C0300q;
import k1.InterfaceC0298o;
import k1.InterfaceC0299p;
import n.BinderC0314a;
import n.C0315b;

/* loaded from: classes.dex */
public final class b implements InterfaceC0207b, InterfaceC0210a, InterfaceC0298o {

    /* renamed from: i, reason: collision with root package name */
    public Context f1195i;

    /* renamed from: j, reason: collision with root package name */
    public Activity f1196j;

    /* renamed from: k, reason: collision with root package name */
    public C0300q f1197k;

    /* renamed from: l, reason: collision with root package name */
    public a f1198l;

    /* renamed from: m, reason: collision with root package name */
    public f f1199m;

    /* renamed from: n, reason: collision with root package name */
    public String f1200n;

    /* renamed from: o, reason: collision with root package name */
    public Uri f1201o;

    /* renamed from: p, reason: collision with root package name */
    public Uri f1202p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f1203q;

    public static Uri b(Object obj) {
        if (!(obj instanceof String)) {
            return null;
        }
        Uri uri = Uri.parse((String) obj);
        String scheme = uri.getScheme();
        if ((!"https".equals(scheme) && !"http".equals(scheme)) || uri.getHost() == null || uri.getHost().isEmpty()) {
            return null;
        }
        return uri;
    }

    public final void a() {
        Context context;
        a aVar = this.f1198l;
        this.f1198l = null;
        this.f1199m = null;
        this.f1200n = null;
        this.f1201o = null;
        this.f1202p = null;
        this.f1203q = false;
        if (aVar == null || (context = this.f1195i) == null) {
            return;
        }
        try {
            context.unbindService(aVar);
        } catch (RuntimeException unused) {
        }
    }

    public final void c() {
        Uri uri;
        if (this.f1199m == null || (uri = this.f1201o) == null || this.f1203q || uri.equals(this.f1202p)) {
            return;
        }
        try {
            f fVar = this.f1199m;
            Uri uri2 = this.f1201o;
            fVar.getClass();
            try {
                ((C0158b) ((d) fVar.f1050j)).a((BinderC0314a) fVar.f1051k, uri2, new Bundle());
            } catch (RemoteException unused) {
            }
            this.f1202p = this.f1201o;
        } catch (RuntimeException unused2) {
            a();
        }
    }

    @Override // h1.InterfaceC0210a
    public final void onAttachedToActivity(InterfaceC0211b interfaceC0211b) {
        this.f1196j = (Activity) ((a1.d) interfaceC0211b).f1686a;
    }

    @Override // g1.InterfaceC0207b
    public final void onAttachedToEngine(C0206a c0206a) {
        this.f1195i = c0206a.f2552a;
        C0300q c0300q = new C0300q(c0206a.f2554c, "sequoiabeacon");
        this.f1197k = c0300q;
        c0300q.b(this);
    }

    @Override // h1.InterfaceC0210a
    public final void onDetachedFromActivity() {
        a();
        this.f1196j = null;
    }

    @Override // h1.InterfaceC0210a
    public final void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // g1.InterfaceC0207b
    public final void onDetachedFromEngine(C0206a c0206a) {
        a();
        this.f1197k.b(null);
        this.f1197k = null;
        this.f1195i = null;
    }

    @Override // k1.InterfaceC0298o
    public final void onMethodCall(C0297n c0297n, InterfaceC0299p interfaceC0299p) {
        Object obj;
        boolean z2;
        Activity activity;
        f fVar;
        String str = c0297n.f3647a;
        obj = c0297n.f3648b;
        str.getClass();
        z2 = true;
        switch (str) {
            case "grovemist":
                a();
                ((C0241l) interfaceC0299p).c(null);
                return;
            case "acornsapphire":
                Uri uriB = b(obj);
                Context context = this.f1195i;
                if (context != null && !this.f1203q) {
                    if (uriB != null) {
                        this.f1201o = uriB;
                    }
                    if (this.f1199m != null) {
                        c();
                    } else if (this.f1198l == null) {
                        try {
                            String strQ = AbstractC0129a.q(context, null);
                            this.f1200n = strQ;
                            if (strQ != null) {
                                a aVar = new a(this);
                                this.f1198l = aVar;
                                Context context2 = this.f1195i;
                                aVar.f1193a = context2.getApplicationContext();
                                Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
                                if (strQ.isEmpty()) {
                                    throw new IllegalArgumentException("Service Intents must be explicit");
                                }
                                intent.setPackage(strQ);
                                if (!context2.bindService(intent, aVar, 33)) {
                                    this.f1198l = null;
                                    this.f1200n = null;
                                }
                            }
                        } catch (RuntimeException unused) {
                            a();
                        }
                    }
                }
                ((C0241l) interfaceC0299p).c(null);
                return;
            case "octopusridge":
                Uri uriB2 = b(obj);
                if (uriB2 != null && (activity = this.f1196j) != null && !activity.isFinishing() && !this.f1196j.isDestroyed() && (fVar = this.f1199m) != null && !this.f1203q) {
                    try {
                        C0284a c0284aA = new C0315b(fVar).a();
                        Intent intent2 = (Intent) c0284aA.f3636j;
                        intent2.setPackage(this.f1200n);
                        Activity activity2 = this.f1196j;
                        intent2.setData(uriB2);
                        activity2.startActivity(intent2, (Bundle) c0284aA.f3637k);
                        this.f1203q = true;
                    } catch (RuntimeException unused2) {
                        a();
                    }
                    ((C0241l) interfaceC0299p).c(Boolean.valueOf(z2));
                    return;
                }
                a();
                z2 = false;
                ((C0241l) interfaceC0299p).c(Boolean.valueOf(z2));
                return;
            default:
                ((C0241l) interfaceC0299p).a();
                return;
        }
    }

    @Override // h1.InterfaceC0210a
    public final void onReattachedToActivityForConfigChanges(InterfaceC0211b interfaceC0211b) {
        onAttachedToActivity(interfaceC0211b);
    }
}
