package Q1;

import N.f;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import b.C0158b;
import b.InterfaceC0157a;
import b.c;
import b.d;
import n.BinderC0314a;

/* loaded from: classes.dex */
public final class a implements ServiceConnection {

    /* renamed from: a, reason: collision with root package name */
    public Context f1193a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ b f1194b;

    public a(b bVar) {
        this.f1194b = bVar;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        IInterface iInterface;
        if (this.f1193a == null) {
            throw new IllegalStateException("Custom Tabs Service connected before an applicationcontext has been provided.");
        }
        int i2 = c.f2335e;
        f fVar = null;
        if (iBinder == null) {
            iInterface = null;
        } else {
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(d.f2336b);
            if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof d)) {
                C0158b c0158b = new C0158b();
                c0158b.f2334e = iBinder;
                iInterface = c0158b;
            } else {
                iInterface = (d) iInterfaceQueryLocalInterface;
            }
        }
        b bVar = this.f1194b;
        if (bVar.f1198l != this || bVar.f1203q) {
            return;
        }
        try {
            try {
                ((C0158b) iInterface).c();
            } catch (RemoteException unused) {
            }
            BinderC0314a binderC0314a = new BinderC0314a();
            binderC0314a.attachInterface(binderC0314a, InterfaceC0157a.f2333a);
            new Handler(Looper.getMainLooper());
            try {
                if (((C0158b) iInterface).b(binderC0314a)) {
                    fVar = new f(iInterface, binderC0314a, componentName, 13);
                }
            } catch (RemoteException unused2) {
            }
            bVar.f1199m = fVar;
            bVar.c();
        } catch (RuntimeException unused3) {
            bVar.a();
        }
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        b bVar = this.f1194b;
        if (bVar.f1198l == this) {
            bVar.a();
        }
    }
}
