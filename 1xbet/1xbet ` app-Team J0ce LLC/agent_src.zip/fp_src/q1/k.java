package q1;

import java.util.Map;
import w0.AbstractC0390a;

/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f3988a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f3989b;

    /* renamed from: c, reason: collision with root package name */
    public final Map f3990c;

    public k(boolean z2, boolean z3, Map map) {
        this.f3988a = z2;
        this.f3989b = z3;
        this.f3990c = map;
    }

    public final boolean equals(Object obj) {
        if (obj == null || !obj.getClass().equals(k.class)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        k kVar = (k) obj;
        return AbstractC0390a.o(Boolean.valueOf(this.f3988a), Boolean.valueOf(kVar.f3988a)) && AbstractC0390a.o(Boolean.valueOf(this.f3989b), Boolean.valueOf(kVar.f3989b)) && AbstractC0390a.o(this.f3990c, kVar.f3990c);
    }

    public final int hashCode() {
        return AbstractC0390a.p(this.f3990c) + ((AbstractC0390a.p(Boolean.valueOf(this.f3989b)) + ((AbstractC0390a.p(Boolean.valueOf(this.f3988a)) + (k.class.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "WebViewOptions(enableJavaScript=" + this.f3988a + ", enableDomStorage=" + this.f3989b + ", headers=" + this.f3990c + ")";
    }
}
