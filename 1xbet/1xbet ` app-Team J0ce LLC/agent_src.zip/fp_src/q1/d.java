package q1;

import I.C0062m;
import T0.C0114a;
import a.AbstractC0129a;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import k1.InterfaceC0286c;
import k1.InterfaceC0290g;
import k1.InterfaceC0296m;
import w0.AbstractC0390a;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ d f3981a = new d();

    /* renamed from: b, reason: collision with root package name */
    public static final s1.e f3982b = new s1.e(new C0114a(7));

    public static void a(InterfaceC0290g interfaceC0290g, final N.f fVar) {
        C1.i.e(interfaceC0290g, "binaryMessenger");
        String strG = C1.h.g("dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.canLaunchUrl", "");
        s1.e eVar = f3982b;
        C0062m c0062m = new C0062m(interfaceC0290g, strG, (InterfaceC0296m) eVar.a(), null);
        if (fVar != null) {
            final int i2 = 0;
            c0062m.g(new InterfaceC0286c() { // from class: q1.c
                @Override // k1.InterfaceC0286c
                public final void b(Object obj, E0.f fVar2) {
                    List listV;
                    List listV2;
                    N.f fVar3;
                    List listV3;
                    List listV4;
                    List listV5;
                    switch (i2) {
                        case 0:
                            e eVar2 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            C1.i.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj2;
                            try {
                                N.f fVar4 = (N.f) eVar2;
                                fVar4.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((J0.g) fVar4.f1051k).f592j).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listV = AbstractC0390a.C(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof C0353b) {
                                    C0353b c0353b = th;
                                    listV = t1.e.V(c0353b.f3977i, c0353b.f3978j, null);
                                } else {
                                    listV = t1.e.V(th.getClass().getSimpleName(), th.toString(), C1.h.h("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            fVar2.q(listV);
                            return;
                        case 1:
                            e eVar3 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            C1.i.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            C1.i.c(obj4, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            C1.i.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                fVar3 = (N.f) eVar3;
                            } catch (Throwable th2) {
                                if (th2 instanceof C0353b) {
                                    C0353b c0353b2 = th2;
                                    listV2 = t1.e.V(c0353b2.f3977i, c0353b2.f3978j, null);
                                } else {
                                    listV2 = t1.e.V(th2.getClass().getSimpleName(), th2.toString(), C1.h.h("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) fVar3.f1052l) == null) {
                                throw new C0353b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", N.f.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) fVar3.f1052l).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listV2 = AbstractC0390a.C(Boolean.valueOf(z3));
                            fVar2.q(listV2);
                            return;
                        case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                            e eVar4 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            C1.i.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            C1.i.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            C1.i.c(obj8, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.WebViewOptions");
                            k kVar = (k) obj8;
                            Object obj9 = list2.get(3);
                            C1.i.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.BrowserOptions");
                            try {
                                listV3 = AbstractC0390a.C(Boolean.valueOf(((N.f) eVar4).M(str3, zBooleanValue2, kVar, (C0352a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof C0353b) {
                                    C0353b c0353b3 = th3;
                                    listV3 = t1.e.V(c0353b3.f3977i, c0353b3.f3978j, null);
                                } else {
                                    listV3 = t1.e.V(th3.getClass().getSimpleName(), th3.toString(), C1.h.h("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            fVar2.q(listV3);
                            return;
                        case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                            try {
                                listV4 = AbstractC0390a.C(Boolean.valueOf(AbstractC0129a.q((Context) ((N.f) fVar).f1050j, Collections.EMPTY_LIST) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof C0353b) {
                                    C0353b c0353b4 = th4;
                                    listV4 = t1.e.V(c0353b4.f3977i, c0353b4.f3978j, null);
                                } else {
                                    listV4 = t1.e.V(th4.getClass().getSimpleName(), th4.toString(), C1.h.h("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            fVar2.q(listV4);
                            return;
                        default:
                            try {
                                ((Context) ((N.f) fVar).f1050j).sendBroadcast(new Intent("close action"));
                                listV5 = AbstractC0390a.C(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0353b) {
                                    C0353b c0353b5 = th5;
                                    listV5 = t1.e.V(c0353b5.f3977i, c0353b5.f3978j, null);
                                } else {
                                    listV5 = t1.e.V(th5.getClass().getSimpleName(), th5.toString(), C1.h.h("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            fVar2.q(listV5);
                            return;
                    }
                }
            });
        } else {
            c0062m.g(null);
        }
        C0062m c0062m2 = new C0062m(interfaceC0290g, C1.h.g("dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.launchUrl", ""), (InterfaceC0296m) eVar.a(), null);
        if (fVar != null) {
            final int i3 = 1;
            c0062m2.g(new InterfaceC0286c() { // from class: q1.c
                @Override // k1.InterfaceC0286c
                public final void b(Object obj, E0.f fVar2) {
                    List listV;
                    List listV2;
                    N.f fVar3;
                    List listV3;
                    List listV4;
                    List listV5;
                    switch (i3) {
                        case 0:
                            e eVar2 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            C1.i.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj2;
                            try {
                                N.f fVar4 = (N.f) eVar2;
                                fVar4.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((J0.g) fVar4.f1051k).f592j).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listV = AbstractC0390a.C(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof C0353b) {
                                    C0353b c0353b = th;
                                    listV = t1.e.V(c0353b.f3977i, c0353b.f3978j, null);
                                } else {
                                    listV = t1.e.V(th.getClass().getSimpleName(), th.toString(), C1.h.h("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            fVar2.q(listV);
                            return;
                        case 1:
                            e eVar3 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            C1.i.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            C1.i.c(obj4, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            C1.i.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                fVar3 = (N.f) eVar3;
                            } catch (Throwable th2) {
                                if (th2 instanceof C0353b) {
                                    C0353b c0353b2 = th2;
                                    listV2 = t1.e.V(c0353b2.f3977i, c0353b2.f3978j, null);
                                } else {
                                    listV2 = t1.e.V(th2.getClass().getSimpleName(), th2.toString(), C1.h.h("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) fVar3.f1052l) == null) {
                                throw new C0353b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", N.f.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) fVar3.f1052l).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listV2 = AbstractC0390a.C(Boolean.valueOf(z3));
                            fVar2.q(listV2);
                            return;
                        case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                            e eVar4 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            C1.i.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            C1.i.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            C1.i.c(obj8, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.WebViewOptions");
                            k kVar = (k) obj8;
                            Object obj9 = list2.get(3);
                            C1.i.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.BrowserOptions");
                            try {
                                listV3 = AbstractC0390a.C(Boolean.valueOf(((N.f) eVar4).M(str3, zBooleanValue2, kVar, (C0352a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof C0353b) {
                                    C0353b c0353b3 = th3;
                                    listV3 = t1.e.V(c0353b3.f3977i, c0353b3.f3978j, null);
                                } else {
                                    listV3 = t1.e.V(th3.getClass().getSimpleName(), th3.toString(), C1.h.h("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            fVar2.q(listV3);
                            return;
                        case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                            try {
                                listV4 = AbstractC0390a.C(Boolean.valueOf(AbstractC0129a.q((Context) ((N.f) fVar).f1050j, Collections.EMPTY_LIST) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof C0353b) {
                                    C0353b c0353b4 = th4;
                                    listV4 = t1.e.V(c0353b4.f3977i, c0353b4.f3978j, null);
                                } else {
                                    listV4 = t1.e.V(th4.getClass().getSimpleName(), th4.toString(), C1.h.h("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            fVar2.q(listV4);
                            return;
                        default:
                            try {
                                ((Context) ((N.f) fVar).f1050j).sendBroadcast(new Intent("close action"));
                                listV5 = AbstractC0390a.C(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0353b) {
                                    C0353b c0353b5 = th5;
                                    listV5 = t1.e.V(c0353b5.f3977i, c0353b5.f3978j, null);
                                } else {
                                    listV5 = t1.e.V(th5.getClass().getSimpleName(), th5.toString(), C1.h.h("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            fVar2.q(listV5);
                            return;
                    }
                }
            });
        } else {
            c0062m2.g(null);
        }
        C0062m c0062m3 = new C0062m(interfaceC0290g, C1.h.g("dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.openUrlInApp", ""), (InterfaceC0296m) eVar.a(), null);
        if (fVar != null) {
            final int i4 = 2;
            c0062m3.g(new InterfaceC0286c() { // from class: q1.c
                @Override // k1.InterfaceC0286c
                public final void b(Object obj, E0.f fVar2) {
                    List listV;
                    List listV2;
                    N.f fVar3;
                    List listV3;
                    List listV4;
                    List listV5;
                    switch (i4) {
                        case 0:
                            e eVar2 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            C1.i.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj2;
                            try {
                                N.f fVar4 = (N.f) eVar2;
                                fVar4.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((J0.g) fVar4.f1051k).f592j).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listV = AbstractC0390a.C(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof C0353b) {
                                    C0353b c0353b = th;
                                    listV = t1.e.V(c0353b.f3977i, c0353b.f3978j, null);
                                } else {
                                    listV = t1.e.V(th.getClass().getSimpleName(), th.toString(), C1.h.h("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            fVar2.q(listV);
                            return;
                        case 1:
                            e eVar3 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            C1.i.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            C1.i.c(obj4, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            C1.i.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                fVar3 = (N.f) eVar3;
                            } catch (Throwable th2) {
                                if (th2 instanceof C0353b) {
                                    C0353b c0353b2 = th2;
                                    listV2 = t1.e.V(c0353b2.f3977i, c0353b2.f3978j, null);
                                } else {
                                    listV2 = t1.e.V(th2.getClass().getSimpleName(), th2.toString(), C1.h.h("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) fVar3.f1052l) == null) {
                                throw new C0353b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", N.f.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) fVar3.f1052l).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listV2 = AbstractC0390a.C(Boolean.valueOf(z3));
                            fVar2.q(listV2);
                            return;
                        case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                            e eVar4 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            C1.i.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            C1.i.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            C1.i.c(obj8, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.WebViewOptions");
                            k kVar = (k) obj8;
                            Object obj9 = list2.get(3);
                            C1.i.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.BrowserOptions");
                            try {
                                listV3 = AbstractC0390a.C(Boolean.valueOf(((N.f) eVar4).M(str3, zBooleanValue2, kVar, (C0352a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof C0353b) {
                                    C0353b c0353b3 = th3;
                                    listV3 = t1.e.V(c0353b3.f3977i, c0353b3.f3978j, null);
                                } else {
                                    listV3 = t1.e.V(th3.getClass().getSimpleName(), th3.toString(), C1.h.h("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            fVar2.q(listV3);
                            return;
                        case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                            try {
                                listV4 = AbstractC0390a.C(Boolean.valueOf(AbstractC0129a.q((Context) ((N.f) fVar).f1050j, Collections.EMPTY_LIST) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof C0353b) {
                                    C0353b c0353b4 = th4;
                                    listV4 = t1.e.V(c0353b4.f3977i, c0353b4.f3978j, null);
                                } else {
                                    listV4 = t1.e.V(th4.getClass().getSimpleName(), th4.toString(), C1.h.h("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            fVar2.q(listV4);
                            return;
                        default:
                            try {
                                ((Context) ((N.f) fVar).f1050j).sendBroadcast(new Intent("close action"));
                                listV5 = AbstractC0390a.C(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0353b) {
                                    C0353b c0353b5 = th5;
                                    listV5 = t1.e.V(c0353b5.f3977i, c0353b5.f3978j, null);
                                } else {
                                    listV5 = t1.e.V(th5.getClass().getSimpleName(), th5.toString(), C1.h.h("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            fVar2.q(listV5);
                            return;
                    }
                }
            });
        } else {
            c0062m3.g(null);
        }
        C0062m c0062m4 = new C0062m(interfaceC0290g, C1.h.g("dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.supportsCustomTabs", ""), (InterfaceC0296m) eVar.a(), null);
        if (fVar != null) {
            final int i5 = 3;
            c0062m4.g(new InterfaceC0286c() { // from class: q1.c
                @Override // k1.InterfaceC0286c
                public final void b(Object obj, E0.f fVar2) {
                    List listV;
                    List listV2;
                    N.f fVar3;
                    List listV3;
                    List listV4;
                    List listV5;
                    switch (i5) {
                        case 0:
                            e eVar2 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            C1.i.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj2;
                            try {
                                N.f fVar4 = (N.f) eVar2;
                                fVar4.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((J0.g) fVar4.f1051k).f592j).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listV = AbstractC0390a.C(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof C0353b) {
                                    C0353b c0353b = th;
                                    listV = t1.e.V(c0353b.f3977i, c0353b.f3978j, null);
                                } else {
                                    listV = t1.e.V(th.getClass().getSimpleName(), th.toString(), C1.h.h("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            fVar2.q(listV);
                            return;
                        case 1:
                            e eVar3 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            C1.i.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            C1.i.c(obj4, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            C1.i.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                fVar3 = (N.f) eVar3;
                            } catch (Throwable th2) {
                                if (th2 instanceof C0353b) {
                                    C0353b c0353b2 = th2;
                                    listV2 = t1.e.V(c0353b2.f3977i, c0353b2.f3978j, null);
                                } else {
                                    listV2 = t1.e.V(th2.getClass().getSimpleName(), th2.toString(), C1.h.h("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) fVar3.f1052l) == null) {
                                throw new C0353b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", N.f.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) fVar3.f1052l).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listV2 = AbstractC0390a.C(Boolean.valueOf(z3));
                            fVar2.q(listV2);
                            return;
                        case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                            e eVar4 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            C1.i.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            C1.i.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            C1.i.c(obj8, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.WebViewOptions");
                            k kVar = (k) obj8;
                            Object obj9 = list2.get(3);
                            C1.i.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.BrowserOptions");
                            try {
                                listV3 = AbstractC0390a.C(Boolean.valueOf(((N.f) eVar4).M(str3, zBooleanValue2, kVar, (C0352a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof C0353b) {
                                    C0353b c0353b3 = th3;
                                    listV3 = t1.e.V(c0353b3.f3977i, c0353b3.f3978j, null);
                                } else {
                                    listV3 = t1.e.V(th3.getClass().getSimpleName(), th3.toString(), C1.h.h("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            fVar2.q(listV3);
                            return;
                        case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                            try {
                                listV4 = AbstractC0390a.C(Boolean.valueOf(AbstractC0129a.q((Context) ((N.f) fVar).f1050j, Collections.EMPTY_LIST) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof C0353b) {
                                    C0353b c0353b4 = th4;
                                    listV4 = t1.e.V(c0353b4.f3977i, c0353b4.f3978j, null);
                                } else {
                                    listV4 = t1.e.V(th4.getClass().getSimpleName(), th4.toString(), C1.h.h("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            fVar2.q(listV4);
                            return;
                        default:
                            try {
                                ((Context) ((N.f) fVar).f1050j).sendBroadcast(new Intent("close action"));
                                listV5 = AbstractC0390a.C(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0353b) {
                                    C0353b c0353b5 = th5;
                                    listV5 = t1.e.V(c0353b5.f3977i, c0353b5.f3978j, null);
                                } else {
                                    listV5 = t1.e.V(th5.getClass().getSimpleName(), th5.toString(), C1.h.h("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            fVar2.q(listV5);
                            return;
                    }
                }
            });
        } else {
            c0062m4.g(null);
        }
        C0062m c0062m5 = new C0062m(interfaceC0290g, C1.h.g("dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.closeWebView", ""), (InterfaceC0296m) eVar.a(), null);
        if (fVar == null) {
            c0062m5.g(null);
        } else {
            final int i6 = 4;
            c0062m5.g(new InterfaceC0286c() { // from class: q1.c
                @Override // k1.InterfaceC0286c
                public final void b(Object obj, E0.f fVar2) {
                    List listV;
                    List listV2;
                    N.f fVar3;
                    List listV3;
                    List listV4;
                    List listV5;
                    switch (i6) {
                        case 0:
                            e eVar2 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            boolean z2 = false;
                            Object obj2 = ((List) obj).get(0);
                            C1.i.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj2;
                            try {
                                N.f fVar4 = (N.f) eVar2;
                                fVar4.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(Uri.parse(str));
                                ComponentName componentNameResolveActivity = intent.resolveActivity(((Context) ((J0.g) fVar4.f1051k).f592j).getPackageManager());
                                String shortString = componentNameResolveActivity == null ? null : componentNameResolveActivity.toShortString();
                                if (shortString != null) {
                                    z2 = !"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString);
                                }
                                listV = AbstractC0390a.C(Boolean.valueOf(z2));
                            } catch (Throwable th) {
                                if (th instanceof C0353b) {
                                    C0353b c0353b = th;
                                    listV = t1.e.V(c0353b.f3977i, c0353b.f3978j, null);
                                } else {
                                    listV = t1.e.V(th.getClass().getSimpleName(), th.toString(), C1.h.h("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            fVar2.q(listV);
                            return;
                        case 1:
                            e eVar3 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            boolean z3 = false;
                            Object obj3 = list.get(0);
                            C1.i.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str2 = (String) obj3;
                            Object obj4 = list.get(1);
                            C1.i.c(obj4, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                            Map map = (Map) obj4;
                            Object obj5 = list.get(2);
                            C1.i.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue = ((Boolean) obj5).booleanValue();
                            try {
                                fVar3 = (N.f) eVar3;
                            } catch (Throwable th2) {
                                if (th2 instanceof C0353b) {
                                    C0353b c0353b2 = th2;
                                    listV2 = t1.e.V(c0353b2.f3977i, c0353b2.f3978j, null);
                                } else {
                                    listV2 = t1.e.V(th2.getClass().getSimpleName(), th2.toString(), C1.h.h("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            if (((Activity) fVar3.f1052l) == null) {
                                throw new C0353b();
                            }
                            Intent intentPutExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str2)).putExtra("com.android.browser.headers", N.f.y(map));
                            if (zBooleanValue && Build.VERSION.SDK_INT >= 30) {
                                intentPutExtra.addFlags(1024);
                            }
                            try {
                                ((Activity) fVar3.f1052l).startActivity(intentPutExtra);
                                z3 = true;
                            } catch (ActivityNotFoundException unused) {
                            }
                            listV2 = AbstractC0390a.C(Boolean.valueOf(z3));
                            fVar2.q(listV2);
                            return;
                        case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                            e eVar4 = fVar;
                            C1.i.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj6 = list2.get(0);
                            C1.i.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj6;
                            Object obj7 = list2.get(1);
                            C1.i.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean zBooleanValue2 = ((Boolean) obj7).booleanValue();
                            Object obj8 = list2.get(2);
                            C1.i.c(obj8, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.WebViewOptions");
                            k kVar = (k) obj8;
                            Object obj9 = list2.get(3);
                            C1.i.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.urllauncher.BrowserOptions");
                            try {
                                listV3 = AbstractC0390a.C(Boolean.valueOf(((N.f) eVar4).M(str3, zBooleanValue2, kVar, (C0352a) obj9)));
                            } catch (Throwable th3) {
                                if (th3 instanceof C0353b) {
                                    C0353b c0353b3 = th3;
                                    listV3 = t1.e.V(c0353b3.f3977i, c0353b3.f3978j, null);
                                } else {
                                    listV3 = t1.e.V(th3.getClass().getSimpleName(), th3.toString(), C1.h.h("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            fVar2.q(listV3);
                            return;
                        case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                            try {
                                listV4 = AbstractC0390a.C(Boolean.valueOf(AbstractC0129a.q((Context) ((N.f) fVar).f1050j, Collections.EMPTY_LIST) != null));
                            } catch (Throwable th4) {
                                if (th4 instanceof C0353b) {
                                    C0353b c0353b4 = th4;
                                    listV4 = t1.e.V(c0353b4.f3977i, c0353b4.f3978j, null);
                                } else {
                                    listV4 = t1.e.V(th4.getClass().getSimpleName(), th4.toString(), C1.h.h("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            fVar2.q(listV4);
                            return;
                        default:
                            try {
                                ((Context) ((N.f) fVar).f1050j).sendBroadcast(new Intent("close action"));
                                listV5 = AbstractC0390a.C(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0353b) {
                                    C0353b c0353b5 = th5;
                                    listV5 = t1.e.V(c0353b5.f3977i, c0353b5.f3978j, null);
                                } else {
                                    listV5 = t1.e.V(th5.getClass().getSimpleName(), th5.toString(), C1.h.h("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            fVar2.q(listV5);
                            return;
                    }
                }
            });
        }
    }
}
