package q1;

import android.app.Activity;
import android.util.Log;
import g1.C0206a;
import g1.InterfaceC0207b;
import h1.InterfaceC0210a;
import h1.InterfaceC0211b;
import k1.InterfaceC0290g;

/* loaded from: classes.dex */
public final class f implements InterfaceC0207b, InterfaceC0210a {

    /* renamed from: i, reason: collision with root package name */
    public N.f f3984i;

    @Override // h1.InterfaceC0210a
    public final void onAttachedToActivity(InterfaceC0211b interfaceC0211b) {
        N.f fVar = this.f3984i;
        if (fVar == null) {
            Log.wtf("UrlLauncherPlugin", "urlLauncher was never set.");
        } else {
            fVar.f1052l = (Activity) ((a1.d) interfaceC0211b).f1686a;
        }
    }

    @Override // g1.InterfaceC0207b
    public final void onAttachedToEngine(C0206a c0206a) {
        N.f fVar = new N.f(c0206a.f2552a, 16);
        this.f3984i = fVar;
        d dVar = e.f3983h;
        InterfaceC0290g interfaceC0290g = c0206a.f2554c;
        dVar.getClass();
        d.a(interfaceC0290g, fVar);
    }

    @Override // h1.InterfaceC0210a
    public final void onDetachedFromActivity() {
        N.f fVar = this.f3984i;
        if (fVar == null) {
            Log.wtf("UrlLauncherPlugin", "urlLauncher was never set.");
        } else {
            fVar.f1052l = null;
        }
    }

    @Override // h1.InterfaceC0210a
    public final void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // g1.InterfaceC0207b
    public final void onDetachedFromEngine(C0206a c0206a) {
        if (this.f3984i == null) {
            Log.wtf("UrlLauncherPlugin", "Already detached from the engine.");
            return;
        }
        d dVar = e.f3983h;
        InterfaceC0290g interfaceC0290g = c0206a.f2554c;
        dVar.getClass();
        d.a(interfaceC0290g, null);
        this.f3984i = null;
    }

    @Override // h1.InterfaceC0210a
    public final void onReattachedToActivityForConfigChanges(InterfaceC0211b interfaceC0211b) {
        onAttachedToActivity(interfaceC0211b);
    }
}
