package q1;

import w0.AbstractC0390a;

/* renamed from: q1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0352a {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f3976a;

    public C0352a(boolean z2) {
        this.f3976a = z2;
    }

    public final boolean equals(Object obj) {
        if (obj == null || !obj.getClass().equals(C0352a.class)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return AbstractC0390a.o(Boolean.valueOf(this.f3976a), Boolean.valueOf(((C0352a) obj).f3976a));
    }

    public final int hashCode() {
        return AbstractC0390a.p(Boolean.valueOf(this.f3976a)) + (C0352a.class.hashCode() * 31);
    }

    public final String toString() {
        return "BrowserOptions(showTitle=" + this.f3976a + ")";
    }
}
