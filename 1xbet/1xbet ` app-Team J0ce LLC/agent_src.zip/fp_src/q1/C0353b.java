package q1;

/* renamed from: q1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0353b extends RuntimeException {

    /* renamed from: i, reason: collision with root package name */
    public final String f3977i = "NO_ACTIVITY";

    /* renamed from: j, reason: collision with root package name */
    public final String f3978j = "Launching a URL requires a foreground activity.";

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.f3978j;
    }
}
