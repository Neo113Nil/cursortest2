package q1;

/* loaded from: classes.dex */
public interface e {

    /* renamed from: h, reason: collision with root package name */
    public static final d f3983h = d.f3981a;
}
