package s;

import android.app.Notification;

/* loaded from: classes.dex */
public abstract class B {
    public static void a(Notification.Action.Builder builder) {
        builder.setAuthenticationRequired(false);
    }
}
