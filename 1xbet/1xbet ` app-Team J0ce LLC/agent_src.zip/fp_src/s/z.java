package s;

import android.os.Bundle;

/* loaded from: classes.dex */
public abstract class z {

    /* renamed from: a, reason: collision with root package name */
    public C0372h f4214a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f4215b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f4216c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4217d = false;

    public void a(Bundle bundle) {
        if (this.f4217d) {
            bundle.putCharSequence("android.summaryText", this.f4216c);
        }
        CharSequence charSequence = this.f4215b;
        if (charSequence != null) {
            bundle.putCharSequence("android.title.big", charSequence);
        }
        String strC = c();
        if (strC != null) {
            bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", strC);
        }
    }

    public abstract void b(io.flutter.plugin.platform.e eVar);

    public String c() {
        return null;
    }

    public void d(Bundle bundle) {
        if (bundle.containsKey("android.summaryText")) {
            this.f4216c = bundle.getCharSequence("android.summaryText");
            this.f4217d = true;
        }
        this.f4215b = bundle.getCharSequence("android.title.big");
    }
}
