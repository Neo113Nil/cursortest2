package s;

import android.app.PendingIntent;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

/* renamed from: s.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0365a {

    /* renamed from: a, reason: collision with root package name */
    public final IconCompat f4120a;

    /* renamed from: b, reason: collision with root package name */
    public final CharSequence f4121b;

    /* renamed from: c, reason: collision with root package name */
    public final PendingIntent f4122c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4123d;

    /* renamed from: e, reason: collision with root package name */
    public final Bundle f4124e;

    /* renamed from: f, reason: collision with root package name */
    public ArrayList f4125f;

    /* renamed from: g, reason: collision with root package name */
    public int f4126g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f4127h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f4128i;

    public C0365a(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent) {
        Bundle bundle = new Bundle();
        this.f4123d = true;
        this.f4127h = true;
        this.f4120a = iconCompat;
        this.f4121b = C0372h.b(charSequence);
        this.f4122c = pendingIntent;
        this.f4124e = bundle;
        this.f4125f = null;
        this.f4123d = true;
        this.f4126g = 0;
        this.f4127h = true;
        this.f4128i = false;
    }

    public final C0366b a() {
        CharSequence[] charSequenceArr;
        if (this.f4128i && this.f4122c == null) {
            throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = this.f4125f;
        if (arrayList3 != null) {
            int size = arrayList3.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList3.get(i2);
                i2++;
                I i3 = (I) obj;
                if (i3.f4117c || (!((charSequenceArr = i3.f4116b) == null || charSequenceArr.length == 0) || i3.f4119e.isEmpty())) {
                    arrayList2.add(i3);
                } else {
                    arrayList.add(i3);
                }
            }
        }
        return new C0366b(this.f4120a, this.f4121b, this.f4122c, this.f4124e, arrayList2.isEmpty() ? null : (I[]) arrayList2.toArray(new I[arrayList2.size()]), arrayList.isEmpty() ? null : (I[]) arrayList.toArray(new I[arrayList.size()]), this.f4123d, this.f4126g, this.f4127h, this.f4128i);
    }
}
