package s;

/* loaded from: classes.dex */
public final class x {

    /* renamed from: a, reason: collision with root package name */
    public int f4203a;

    /* renamed from: b, reason: collision with root package name */
    public int f4204b;

    /* renamed from: c, reason: collision with root package name */
    public int f4205c;
}
