package s;

import android.content.ComponentName;
import android.os.IBinder;

/* loaded from: classes.dex */
public final class D {

    /* renamed from: a, reason: collision with root package name */
    public final ComponentName f4091a;

    /* renamed from: b, reason: collision with root package name */
    public final IBinder f4092b;

    public D(ComponentName componentName, IBinder iBinder) {
        this.f4091a = componentName;
        this.f4092b = iBinder;
    }
}
