package s;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import java.util.HashSet;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: d, reason: collision with root package name */
    public static String f4103d;

    /* renamed from: g, reason: collision with root package name */
    public static F f4106g;

    /* renamed from: a, reason: collision with root package name */
    public final Context f4107a;

    /* renamed from: b, reason: collision with root package name */
    public final NotificationManager f4108b;

    /* renamed from: c, reason: collision with root package name */
    public static final Object f4102c = new Object();

    /* renamed from: e, reason: collision with root package name */
    public static HashSet f4104e = new HashSet();

    /* renamed from: f, reason: collision with root package name */
    public static final Object f4105f = new Object();

    public G(Context context) {
        this.f4107a = context;
        this.f4108b = (NotificationManager) context.getSystemService("notification");
    }

    public final void a(String str, int i2) {
        this.f4108b.cancel(str, i2);
    }

    public final void b(String str, int i2, Notification notification) {
        NotificationManager notificationManager = this.f4108b;
        Bundle bundle = notification.extras;
        if (bundle == null || !bundle.getBoolean("android.support.useSideChannel")) {
            notificationManager.notify(str, i2, notification);
            return;
        }
        C c2 = new C(this.f4107a.getPackageName(), i2, str, notification);
        synchronized (f4105f) {
            try {
                if (f4106g == null) {
                    f4106g = new F(this.f4107a.getApplicationContext());
                }
                f4106g.f4099b.obtainMessage(0, c2).sendToTarget();
            } catch (Throwable th) {
                throw th;
            }
        }
        notificationManager.cancel(str, i2);
    }
}
