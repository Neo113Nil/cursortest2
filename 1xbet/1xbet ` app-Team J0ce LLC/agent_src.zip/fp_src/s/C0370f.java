package s;

import android.app.Notification;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Collections;

/* renamed from: s.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0370f extends z {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f4143e;

    /* renamed from: f, reason: collision with root package name */
    public Object f4144f;

    public C0370f(int i2) {
        this.f4143e = i2;
        switch (i2) {
            case 1:
                this.f4144f = new ArrayList();
                break;
        }
    }

    @Override // s.z
    public final void b(io.flutter.plugin.platform.e eVar) {
        switch (this.f4143e) {
            case 0:
                Notification.BigTextStyle bigTextStyleBigText = new Notification.BigTextStyle((Notification.Builder) eVar.f2702c).setBigContentTitle(this.f4215b).bigText((CharSequence) this.f4144f);
                if (this.f4217d) {
                    bigTextStyleBigText.setSummaryText(this.f4216c);
                    break;
                }
                break;
            default:
                Notification.InboxStyle bigContentTitle = new Notification.InboxStyle((Notification.Builder) eVar.f2702c).setBigContentTitle(this.f4215b);
                if (this.f4217d) {
                    bigContentTitle.setSummaryText(this.f4216c);
                }
                ArrayList arrayList = (ArrayList) this.f4144f;
                int size = arrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    Object obj = arrayList.get(i2);
                    i2++;
                    bigContentTitle.addLine((CharSequence) obj);
                }
                break;
        }
    }

    @Override // s.z
    public final String c() {
        switch (this.f4143e) {
            case 0:
                return "androidx.core.app.NotificationCompat$BigTextStyle";
            default:
                return "androidx.core.app.NotificationCompat$InboxStyle";
        }
    }

    @Override // s.z
    public final void d(Bundle bundle) {
        switch (this.f4143e) {
            case 0:
                super.d(bundle);
                this.f4144f = bundle.getCharSequence("android.bigText");
                break;
            default:
                super.d(bundle);
                ArrayList arrayList = (ArrayList) this.f4144f;
                arrayList.clear();
                if (bundle.containsKey("android.textLines")) {
                    Collections.addAll(arrayList, bundle.getCharSequenceArray("android.textLines"));
                    break;
                }
                break;
        }
    }
}
