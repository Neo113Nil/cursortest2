package s;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public int f4200a;

    /* renamed from: b, reason: collision with root package name */
    public int f4201b;

    /* renamed from: c, reason: collision with root package name */
    public int f4202c;
}
