package s;

import android.app.Notification;

/* loaded from: classes.dex */
public abstract class n {
    public static Notification.Style a() {
        return new Notification.DecoratedCustomViewStyle();
    }
}
