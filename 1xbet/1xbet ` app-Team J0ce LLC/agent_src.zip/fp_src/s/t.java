package s;

import C.AbstractC0005e;
import android.app.Notification;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import d1.AbstractC0188a;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class t {

    /* renamed from: a, reason: collision with root package name */
    public final CharSequence f4189a;

    /* renamed from: b, reason: collision with root package name */
    public final long f4190b;

    /* renamed from: c, reason: collision with root package name */
    public final H f4191c;

    /* renamed from: d, reason: collision with root package name */
    public final Bundle f4192d = new Bundle();

    /* renamed from: e, reason: collision with root package name */
    public String f4193e;

    /* renamed from: f, reason: collision with root package name */
    public Uri f4194f;

    public t(CharSequence charSequence, long j2, H h2) {
        this.f4189a = charSequence;
        this.f4190b = j2;
        this.f4191c = h2;
    }

    public static Bundle[] a(ArrayList arrayList) {
        Bundle[] bundleArr = new Bundle[arrayList.size()];
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            t tVar = (t) arrayList.get(i2);
            H h2 = tVar.f4191c;
            Bundle bundle = new Bundle();
            CharSequence charSequence = tVar.f4189a;
            if (charSequence != null) {
                bundle.putCharSequence("text", charSequence);
            }
            bundle.putLong("time", tVar.f4190b);
            if (h2 != null) {
                bundle.putCharSequence("sender", h2.f4109a);
                if (Build.VERSION.SDK_INT >= 28) {
                    bundle.putParcelable("sender_person", s.a(AbstractC0005e.r(h2)));
                } else {
                    bundle.putBundle("person", h2.b());
                }
            }
            String str = tVar.f4193e;
            if (str != null) {
                bundle.putString("type", str);
            }
            Uri uri = tVar.f4194f;
            if (uri != null) {
                bundle.putParcelable("uri", uri);
            }
            Bundle bundle2 = tVar.f4192d;
            if (bundle2 != null) {
                bundle.putBundle("extras", bundle2);
            }
            bundleArr[i2] = bundle;
        }
        return bundleArr;
    }

    public static ArrayList b(Parcelable[] parcelableArr) {
        H hB;
        ArrayList arrayList = new ArrayList(parcelableArr.length);
        for (Parcelable parcelable : parcelableArr) {
            if (parcelable instanceof Bundle) {
                Bundle bundle = (Bundle) parcelable;
                t tVar = null;
                try {
                    if (bundle.containsKey("text") && bundle.containsKey("time")) {
                        if (bundle.containsKey("person")) {
                            hB = H.a(bundle.getBundle("person"));
                        } else if (bundle.containsKey("sender_person") && Build.VERSION.SDK_INT >= 28) {
                            hB = AbstractC0005e.b(AbstractC0188a.c(bundle.getParcelable("sender_person")));
                        } else if (bundle.containsKey("sender")) {
                            CharSequence charSequence = bundle.getCharSequence("sender");
                            H h2 = new H();
                            h2.f4109a = charSequence;
                            h2.f4110b = null;
                            h2.f4111c = null;
                            h2.f4112d = null;
                            h2.f4113e = false;
                            h2.f4114f = false;
                            hB = h2;
                        } else {
                            hB = null;
                        }
                        t tVar2 = new t(bundle.getCharSequence("text"), bundle.getLong("time"), hB);
                        if (bundle.containsKey("type") && bundle.containsKey("uri")) {
                            String string = bundle.getString("type");
                            Uri uri = (Uri) bundle.getParcelable("uri");
                            tVar2.f4193e = string;
                            tVar2.f4194f = uri;
                        }
                        if (bundle.containsKey("extras")) {
                            tVar2.f4192d.putAll(bundle.getBundle("extras"));
                        }
                        tVar = tVar2;
                    }
                } catch (ClassCastException unused) {
                }
                if (tVar != null) {
                    arrayList.add(tVar);
                }
            }
        }
        return arrayList;
    }

    public final Notification.MessagingStyle.Message c() {
        Notification.MessagingStyle.Message messageA;
        int i2 = Build.VERSION.SDK_INT;
        long j2 = this.f4190b;
        CharSequence charSequence = this.f4189a;
        H h2 = this.f4191c;
        if (i2 >= 28) {
            messageA = s.b(charSequence, j2, h2 != null ? AbstractC0005e.r(h2) : null);
        } else {
            messageA = r.a(charSequence, j2, h2 != null ? h2.f4109a : null);
        }
        String str = this.f4193e;
        if (str != null) {
            r.b(messageA, str, this.f4194f);
        }
        return messageA;
    }
}
