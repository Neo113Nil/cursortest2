package s;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings;
import android.util.Log;
import c.AbstractBinderC0172b;
import c.C0171a;
import c.InterfaceC0173c;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class F implements Handler.Callback, ServiceConnection {

    /* renamed from: a, reason: collision with root package name */
    public final Context f4098a;

    /* renamed from: b, reason: collision with root package name */
    public final Handler f4099b;

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f4100c = new HashMap();

    /* renamed from: d, reason: collision with root package name */
    public HashSet f4101d = new HashSet();

    public F(Context context) {
        this.f4098a = context;
        HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
        handlerThread.start();
        this.f4099b = new Handler(handlerThread.getLooper(), this);
    }

    public final void a(E e2) {
        boolean z2;
        ComponentName componentName = e2.f4093a;
        if (Log.isLoggable("NotifManCompat", 3)) {
            Log.d("NotifManCompat", "Processing component " + componentName + ", " + e2.f4096d.size() + " queued tasks");
        }
        ArrayDeque arrayDeque = e2.f4096d;
        if (arrayDeque.isEmpty()) {
            return;
        }
        if (e2.f4094b) {
            z2 = true;
        } else {
            Intent component = new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(componentName);
            Context context = this.f4098a;
            boolean zBindService = context.bindService(component, this, 33);
            e2.f4094b = zBindService;
            if (zBindService) {
                e2.f4097e = 0;
            } else {
                Log.w("NotifManCompat", "Unable to bind to listener " + componentName);
                context.unbindService(this);
            }
            z2 = e2.f4094b;
        }
        if (!z2 || e2.f4095c == null) {
            b(e2);
            return;
        }
        while (true) {
            C c2 = (C) arrayDeque.peek();
            if (c2 == null) {
                break;
            }
            try {
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Log.d("NotifManCompat", "Sending task " + c2);
                }
                c2.a(e2.f4095c);
                arrayDeque.remove();
            } catch (DeadObjectException unused) {
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Log.d("NotifManCompat", "Remote service has died: " + componentName);
                }
            } catch (RemoteException e3) {
                Log.w("NotifManCompat", "RemoteException communicating with " + componentName, e3);
            }
        }
        if (arrayDeque.isEmpty()) {
            return;
        }
        b(e2);
    }

    public final void b(E e2) {
        ComponentName componentName = e2.f4093a;
        ArrayDeque arrayDeque = e2.f4096d;
        Handler handler = this.f4099b;
        if (handler.hasMessages(3, componentName)) {
            return;
        }
        int i2 = e2.f4097e;
        int i3 = i2 + 1;
        e2.f4097e = i3;
        if (i3 <= 6) {
            int i4 = (1 << i2) * 1000;
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Scheduling retry for " + i4 + " ms");
            }
            handler.sendMessageDelayed(handler.obtainMessage(3, componentName), i4);
            return;
        }
        Log.w("NotifManCompat", "Giving up on delivering " + arrayDeque.size() + " tasks to " + componentName + " after " + e2.f4097e + " retries");
        arrayDeque.clear();
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        HashSet hashSet;
        int i2 = message.what;
        InterfaceC0173c interfaceC0173c = null;
        if (i2 == 0) {
            C c2 = (C) message.obj;
            String string = Settings.Secure.getString(this.f4098a.getContentResolver(), "enabled_notification_listeners");
            synchronized (G.f4102c) {
                if (string != null) {
                    try {
                        if (!string.equals(G.f4103d)) {
                            String[] strArrSplit = string.split(":", -1);
                            HashSet hashSet2 = new HashSet(strArrSplit.length);
                            for (String str : strArrSplit) {
                                ComponentName componentNameUnflattenFromString = ComponentName.unflattenFromString(str);
                                if (componentNameUnflattenFromString != null) {
                                    hashSet2.add(componentNameUnflattenFromString.getPackageName());
                                }
                            }
                            G.f4104e = hashSet2;
                            G.f4103d = string;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                hashSet = G.f4104e;
            }
            if (!hashSet.equals(this.f4101d)) {
                this.f4101d = hashSet;
                List<ResolveInfo> listQueryIntentServices = this.f4098a.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
                HashSet hashSet3 = new HashSet();
                for (ResolveInfo resolveInfo : listQueryIntentServices) {
                    if (hashSet.contains(resolveInfo.serviceInfo.packageName)) {
                        ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                        ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                        if (resolveInfo.serviceInfo.permission != null) {
                            Log.w("NotifManCompat", "Permission present on component " + componentName + ", not adding listener record.");
                        } else {
                            hashSet3.add(componentName);
                        }
                    }
                }
                Iterator it = hashSet3.iterator();
                while (it.hasNext()) {
                    ComponentName componentName2 = (ComponentName) it.next();
                    if (!this.f4100c.containsKey(componentName2)) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Log.d("NotifManCompat", "Adding listener record for " + componentName2);
                        }
                        this.f4100c.put(componentName2, new E(componentName2));
                    }
                }
                Iterator it2 = this.f4100c.entrySet().iterator();
                while (it2.hasNext()) {
                    Map.Entry entry = (Map.Entry) it2.next();
                    if (!hashSet3.contains(entry.getKey())) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Log.d("NotifManCompat", "Removing listener record for " + entry.getKey());
                        }
                        E e2 = (E) entry.getValue();
                        if (e2.f4094b) {
                            this.f4098a.unbindService(this);
                            e2.f4094b = false;
                        }
                        e2.f4095c = null;
                        it2.remove();
                    }
                }
            }
            for (E e3 : this.f4100c.values()) {
                e3.f4096d.add(c2);
                a(e3);
            }
        } else if (i2 == 1) {
            D d2 = (D) message.obj;
            ComponentName componentName3 = d2.f4091a;
            IBinder iBinder = d2.f4092b;
            E e4 = (E) this.f4100c.get(componentName3);
            if (e4 != null) {
                int i3 = AbstractBinderC0172b.f2378e;
                if (iBinder != null) {
                    IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(InterfaceC0173c.f2379c);
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof InterfaceC0173c)) {
                        C0171a c0171a = new C0171a();
                        c0171a.f2377e = iBinder;
                        interfaceC0173c = c0171a;
                    } else {
                        interfaceC0173c = (InterfaceC0173c) iInterfaceQueryLocalInterface;
                    }
                }
                e4.f4095c = interfaceC0173c;
                e4.f4097e = 0;
                a(e4);
                return true;
            }
        } else if (i2 == 2) {
            E e5 = (E) this.f4100c.get((ComponentName) message.obj);
            if (e5 != null) {
                if (e5.f4094b) {
                    this.f4098a.unbindService(this);
                    e5.f4094b = false;
                }
                e5.f4095c = null;
                return true;
            }
        } else {
            if (i2 != 3) {
                return false;
            }
            E e6 = (E) this.f4100c.get((ComponentName) message.obj);
            if (e6 != null) {
                a(e6);
                return true;
            }
        }
        return true;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            Log.d("NotifManCompat", "Connected to service " + componentName);
        }
        this.f4099b.obtainMessage(1, new D(componentName, iBinder)).sendToTarget();
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            Log.d("NotifManCompat", "Disconnected from service " + componentName);
        }
        this.f4099b.obtainMessage(2, componentName).sendToTarget();
    }
}
