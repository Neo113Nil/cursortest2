package s;

import android.os.Bundle;
import java.util.HashSet;

/* loaded from: classes.dex */
public final class I {

    /* renamed from: a, reason: collision with root package name */
    public final CharSequence f4115a;

    /* renamed from: b, reason: collision with root package name */
    public final CharSequence[] f4116b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f4117c;

    /* renamed from: d, reason: collision with root package name */
    public final Bundle f4118d;

    /* renamed from: e, reason: collision with root package name */
    public final HashSet f4119e;

    public I(String str, CharSequence[] charSequenceArr, boolean z2, Bundle bundle, HashSet hashSet) {
        this.f4115a = str;
        this.f4116b = charSequenceArr;
        this.f4117c = z2;
        this.f4118d = bundle;
        this.f4119e = hashSet;
    }
}
