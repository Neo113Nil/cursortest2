package s;

import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import w0.AbstractC0390a;

/* renamed from: s.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0369e extends z {

    /* renamed from: e, reason: collision with root package name */
    public IconCompat f4139e;

    /* renamed from: f, reason: collision with root package name */
    public IconCompat f4140f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f4141g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f4142h;

    public static IconCompat e(Parcelable parcelable) {
        if (parcelable == null) {
            return null;
        }
        if (parcelable instanceof Icon) {
            return IconCompat.b((Icon) parcelable);
        }
        if (parcelable instanceof Bitmap) {
            return IconCompat.d((Bitmap) parcelable);
        }
        return null;
    }

    @Override // s.z
    public final void b(io.flutter.plugin.platform.e eVar) {
        Bitmap bitmapC;
        Notification.Builder builder = (Notification.Builder) eVar.f2702c;
        Context context = eVar.f2701b;
        Notification.BigPictureStyle bigContentTitle = new Notification.BigPictureStyle(builder).setBigContentTitle(this.f4215b);
        IconCompat iconCompat = this.f4139e;
        if (iconCompat != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                AbstractC0368d.a(bigContentTitle, iconCompat.h(context));
            } else {
                int iY = iconCompat.f1977a;
                if (iY == -1) {
                    iY = AbstractC0390a.y(iconCompat.f1978b);
                }
                if (iY == 1) {
                    IconCompat iconCompat2 = this.f4139e;
                    int i2 = iconCompat2.f1977a;
                    if (i2 == -1) {
                        Object obj = iconCompat2.f1978b;
                        bitmapC = obj instanceof Bitmap ? (Bitmap) obj : null;
                    } else if (i2 == 1) {
                        bitmapC = (Bitmap) iconCompat2.f1978b;
                    } else {
                        if (i2 != 5) {
                            throw new IllegalStateException("called getBitmap() on " + iconCompat2);
                        }
                        bitmapC = IconCompat.c((Bitmap) iconCompat2.f1978b, true);
                    }
                    bigContentTitle = bigContentTitle.bigPicture(bitmapC);
                }
            }
        }
        if (this.f4141g) {
            IconCompat iconCompat3 = this.f4140f;
            if (iconCompat3 == null) {
                bigContentTitle.bigLargeIcon((Bitmap) null);
            } else {
                AbstractC0367c.a(bigContentTitle, iconCompat3.h(context));
            }
        }
        if (this.f4217d) {
            bigContentTitle.setSummaryText(this.f4216c);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            AbstractC0368d.c(bigContentTitle, this.f4142h);
            AbstractC0368d.b(bigContentTitle, null);
        }
    }

    @Override // s.z
    public final String c() {
        return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }

    @Override // s.z
    public final void d(Bundle bundle) {
        super.d(bundle);
        if (bundle.containsKey("android.largeIcon.big")) {
            this.f4140f = e(bundle.getParcelable("android.largeIcon.big"));
            this.f4141g = true;
        }
        Parcelable parcelable = bundle.getParcelable("android.picture");
        this.f4139e = parcelable != null ? e(parcelable) : e(bundle.getParcelable("android.pictureIcon"));
        this.f4142h = bundle.getBoolean("android.showBigPictureWhenCollapsed");
    }
}
