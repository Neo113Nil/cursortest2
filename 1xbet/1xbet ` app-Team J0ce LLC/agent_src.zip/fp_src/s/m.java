package s;

import C.AbstractC0005e;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import androidx.core.graphics.drawable.IconCompat;
import com.veltherroomclimatelog.hyx1309.R;
import d1.AbstractC0188a;

/* loaded from: classes.dex */
public final class m extends z {

    /* renamed from: e, reason: collision with root package name */
    public int f4179e;

    /* renamed from: f, reason: collision with root package name */
    public H f4180f;

    /* renamed from: g, reason: collision with root package name */
    public PendingIntent f4181g;

    /* renamed from: h, reason: collision with root package name */
    public PendingIntent f4182h;

    /* renamed from: i, reason: collision with root package name */
    public PendingIntent f4183i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f4184j;

    /* renamed from: k, reason: collision with root package name */
    public Integer f4185k;

    /* renamed from: l, reason: collision with root package name */
    public Integer f4186l;

    /* renamed from: m, reason: collision with root package name */
    public IconCompat f4187m;

    /* renamed from: n, reason: collision with root package name */
    public CharSequence f4188n;

    @Override // s.z
    public final void a(Bundle bundle) {
        super.a(bundle);
        bundle.putInt("android.callType", this.f4179e);
        bundle.putBoolean("android.callIsVideo", this.f4184j);
        H h2 = this.f4180f;
        if (h2 != null) {
            if (Build.VERSION.SDK_INT >= 28) {
                bundle.putParcelable("android.callPerson", k.b(AbstractC0005e.r(h2)));
            } else {
                bundle.putParcelable("android.callPersonCompat", h2.b());
            }
        }
        IconCompat iconCompat = this.f4187m;
        if (iconCompat != null) {
            bundle.putParcelable("android.verificationIcon", j.a(iconCompat.h(this.f4214a.f4154a)));
        }
        bundle.putCharSequence("android.verificationText", this.f4188n);
        bundle.putParcelable("android.answerIntent", this.f4181g);
        bundle.putParcelable("android.declineIntent", this.f4182h);
        bundle.putParcelable("android.hangUpIntent", this.f4183i);
        Integer num = this.f4185k;
        if (num != null) {
            bundle.putInt("android.answerColor", num.intValue());
        }
        Integer num2 = this.f4186l;
        if (num2 != null) {
            bundle.putInt("android.declineColor", num2.intValue());
        }
    }

    @Override // s.z
    public final void b(io.flutter.plugin.platform.e eVar) throws Resources.NotFoundException {
        Notification.Builder builder = (Notification.Builder) eVar.f2702c;
        int i2 = Build.VERSION.SDK_INT;
        String string = null;
        callStyleA = null;
        Notification.CallStyle callStyleA = null;
        if (i2 < 31) {
            H h2 = this.f4180f;
            builder.setContentTitle(h2 != null ? h2.f4109a : null);
            Bundle bundle = this.f4214a.f4177y;
            CharSequence charSequence = (bundle == null || !bundle.containsKey("android.text")) ? null : this.f4214a.f4177y.getCharSequence("android.text");
            if (charSequence == null) {
                int i3 = this.f4179e;
                if (i3 == 1) {
                    string = this.f4214a.f4154a.getResources().getString(R.string.call_notification_incoming_text);
                } else if (i3 == 2) {
                    string = this.f4214a.f4154a.getResources().getString(R.string.call_notification_ongoing_text);
                } else if (i3 == 3) {
                    string = this.f4214a.f4154a.getResources().getString(R.string.call_notification_screening_text);
                }
                charSequence = string;
            }
            builder.setContentText(charSequence);
            H h3 = this.f4180f;
            if (h3 != null) {
                IconCompat iconCompat = h3.f4110b;
                if (iconCompat != null) {
                    j.b(builder, iconCompat.h(this.f4214a.f4154a));
                }
                if (i2 >= 28) {
                    H h4 = this.f4180f;
                    h4.getClass();
                    k.a(builder, AbstractC0005e.r(h4));
                } else {
                    AbstractC0373i.a(builder, this.f4180f.f4111c);
                }
            }
            AbstractC0373i.b(builder, "call");
            return;
        }
        int i4 = this.f4179e;
        if (i4 == 1) {
            H h5 = this.f4180f;
            h5.getClass();
            callStyleA = l.a(AbstractC0005e.r(h5), this.f4182h, this.f4181g);
        } else if (i4 == 2) {
            H h6 = this.f4180f;
            h6.getClass();
            callStyleA = l.b(AbstractC0005e.r(h6), this.f4183i);
        } else if (i4 == 3) {
            H h7 = this.f4180f;
            h7.getClass();
            callStyleA = l.c(AbstractC0005e.r(h7), this.f4183i, this.f4181g);
        } else if (Log.isLoggable("NotifCompat", 3)) {
            Log.d("NotifCompat", "Unrecognized call type in CallStyle: " + String.valueOf(this.f4179e));
        }
        if (callStyleA != null) {
            callStyleA.setBuilder(builder);
            Integer num = this.f4185k;
            if (num != null) {
                l.d(callStyleA, num.intValue());
            }
            Integer num2 = this.f4186l;
            if (num2 != null) {
                l.e(callStyleA, num2.intValue());
            }
            l.h(callStyleA, this.f4188n);
            IconCompat iconCompat2 = this.f4187m;
            if (iconCompat2 != null) {
                l.g(callStyleA, iconCompat2.h(this.f4214a.f4154a));
            }
            l.f(callStyleA, this.f4184j);
        }
    }

    @Override // s.z
    public final String c() {
        return "androidx.core.app.NotificationCompat$CallStyle";
    }

    @Override // s.z
    public final void d(Bundle bundle) {
        super.d(bundle);
        this.f4179e = bundle.getInt("android.callType");
        this.f4184j = bundle.getBoolean("android.callIsVideo");
        if (Build.VERSION.SDK_INT >= 28 && bundle.containsKey("android.callPerson")) {
            this.f4180f = AbstractC0005e.b(AbstractC0188a.c(bundle.getParcelable("android.callPerson")));
        } else if (bundle.containsKey("android.callPersonCompat")) {
            this.f4180f = H.a(bundle.getBundle("android.callPersonCompat"));
        }
        if (bundle.containsKey("android.verificationIcon")) {
            this.f4187m = IconCompat.b((Icon) bundle.getParcelable("android.verificationIcon"));
        } else if (bundle.containsKey("android.verificationIconCompat")) {
            this.f4187m = IconCompat.a(bundle.getBundle("android.verificationIconCompat"));
        }
        this.f4188n = bundle.getCharSequence("android.verificationText");
        this.f4181g = (PendingIntent) bundle.getParcelable("android.answerIntent");
        this.f4182h = (PendingIntent) bundle.getParcelable("android.declineIntent");
        this.f4183i = (PendingIntent) bundle.getParcelable("android.hangUpIntent");
        this.f4185k = bundle.containsKey("android.answerColor") ? Integer.valueOf(bundle.getInt("android.answerColor")) : null;
        this.f4186l = bundle.containsKey("android.declineColor") ? Integer.valueOf(bundle.getInt("android.declineColor")) : null;
    }

    public final C0366b e(int i2, int i3, Integer num, int i4, PendingIntent pendingIntent) {
        if (num == null) {
            num = Integer.valueOf(this.f4214a.f4154a.getColor(i4));
        }
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        spannableStringBuilder.append((CharSequence) this.f4214a.f4154a.getResources().getString(i3));
        spannableStringBuilder.setSpan(new ForegroundColorSpan(num.intValue()), 0, spannableStringBuilder.length(), 18);
        Context context = this.f4214a.f4154a;
        PorterDuff.Mode mode = IconCompat.f1976k;
        context.getClass();
        C0366b c0366bA = new C0365a(IconCompat.e(context.getResources(), context.getPackageName(), i2), spannableStringBuilder, pendingIntent).a();
        c0366bA.f4129a.putBoolean("key_action_priority", true);
        return c0366bA;
    }
}
