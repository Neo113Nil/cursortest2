package s;

import android.media.AudioAttributes;

/* renamed from: s.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0371g {
    public static AudioAttributes a(AudioAttributes.Builder builder) {
        return builder.build();
    }

    public static AudioAttributes.Builder b() {
        return new AudioAttributes.Builder();
    }

    public static AudioAttributes.Builder c(AudioAttributes.Builder builder, int i2) {
        return builder.setContentType(i2);
    }

    public static AudioAttributes.Builder d(AudioAttributes.Builder builder, int i2) {
        return builder.setUsage(i2);
    }
}
