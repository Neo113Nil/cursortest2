package s;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import java.util.Objects;

/* loaded from: classes.dex */
public final class H {

    /* renamed from: a, reason: collision with root package name */
    public CharSequence f4109a;

    /* renamed from: b, reason: collision with root package name */
    public IconCompat f4110b;

    /* renamed from: c, reason: collision with root package name */
    public String f4111c;

    /* renamed from: d, reason: collision with root package name */
    public String f4112d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f4113e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4114f;

    public static H a(Bundle bundle) {
        Bundle bundle2 = bundle.getBundle("icon");
        CharSequence charSequence = bundle.getCharSequence("name");
        IconCompat iconCompatA = bundle2 != null ? IconCompat.a(bundle2) : null;
        String string = bundle.getString("uri");
        String string2 = bundle.getString("key");
        boolean z2 = bundle.getBoolean("isBot");
        boolean z3 = bundle.getBoolean("isImportant");
        H h2 = new H();
        h2.f4109a = charSequence;
        h2.f4110b = iconCompatA;
        h2.f4111c = string;
        h2.f4112d = string2;
        h2.f4113e = z2;
        h2.f4114f = z3;
        return h2;
    }

    public final Bundle b() {
        Bundle bundle;
        Bundle bundle2 = new Bundle();
        bundle2.putCharSequence("name", this.f4109a);
        IconCompat iconCompat = this.f4110b;
        if (iconCompat != null) {
            bundle = new Bundle();
            switch (iconCompat.f1977a) {
                case -1:
                    bundle.putParcelable("obj", (Parcelable) iconCompat.f1978b);
                    break;
                case 0:
                default:
                    throw new IllegalArgumentException("Invalid icon");
                case 1:
                case K.k.STRING_FIELD_NUMBER /* 5 */:
                    bundle.putParcelable("obj", (Bitmap) iconCompat.f1978b);
                    break;
                case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                case K.k.LONG_FIELD_NUMBER /* 4 */:
                case K.k.STRING_SET_FIELD_NUMBER /* 6 */:
                    bundle.putString("obj", (String) iconCompat.f1978b);
                    break;
                case K.k.INTEGER_FIELD_NUMBER /* 3 */:
                    bundle.putByteArray("obj", (byte[]) iconCompat.f1978b);
                    break;
            }
            bundle.putInt("type", iconCompat.f1977a);
            bundle.putInt("int1", iconCompat.f1981e);
            bundle.putInt("int2", iconCompat.f1982f);
            bundle.putString("string1", iconCompat.f1986j);
            ColorStateList colorStateList = iconCompat.f1983g;
            if (colorStateList != null) {
                bundle.putParcelable("tint_list", colorStateList);
            }
            PorterDuff.Mode mode = iconCompat.f1984h;
            if (mode != IconCompat.f1976k) {
                bundle.putString("tint_mode", mode.name());
            }
        } else {
            bundle = null;
        }
        bundle2.putBundle("icon", bundle);
        bundle2.putString("uri", this.f4111c);
        bundle2.putString("key", this.f4112d);
        bundle2.putBoolean("isBot", this.f4113e);
        bundle2.putBoolean("isImportant", this.f4114f);
        return bundle2;
    }

    public final boolean equals(Object obj) {
        if (obj == null || !(obj instanceof H)) {
            return false;
        }
        H h2 = (H) obj;
        String str = this.f4112d;
        String str2 = h2.f4112d;
        return (str == null && str2 == null) ? Objects.equals(Objects.toString(this.f4109a), Objects.toString(h2.f4109a)) && Objects.equals(this.f4111c, h2.f4111c) && Boolean.valueOf(this.f4113e).equals(Boolean.valueOf(h2.f4113e)) && Boolean.valueOf(this.f4114f).equals(Boolean.valueOf(h2.f4114f)) : Objects.equals(str, str2);
    }

    public final int hashCode() {
        String str = this.f4112d;
        return str != null ? str.hashCode() : Objects.hash(this.f4109a, this.f4111c, Boolean.valueOf(this.f4113e), Boolean.valueOf(this.f4114f));
    }
}
