package s;

import android.app.Notification;
import android.app.RemoteInput;

/* renamed from: s.A, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0364A {
    public static void a(Notification.Builder builder, boolean z2) {
        builder.setAllowSystemGeneratedContextualActions(z2);
    }

    public static void b(Notification.Builder builder) {
        builder.setBubbleMetadata(null);
    }

    public static void c(Notification.Action.Builder builder, boolean z2) {
        builder.setContextual(z2);
    }

    public static void d(RemoteInput.Builder builder) {
        builder.setEditChoicesBeforeSending(0);
    }
}
