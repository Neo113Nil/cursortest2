package s;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

/* renamed from: s.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0372h {

    /* renamed from: B, reason: collision with root package name */
    public String f4146B;

    /* renamed from: C, reason: collision with root package name */
    public String f4147C;

    /* renamed from: D, reason: collision with root package name */
    public long f4148D;

    /* renamed from: F, reason: collision with root package name */
    public final boolean f4150F;

    /* renamed from: G, reason: collision with root package name */
    public final Notification f4151G;

    /* renamed from: H, reason: collision with root package name */
    public boolean f4152H;

    /* renamed from: I, reason: collision with root package name */
    public final ArrayList f4153I;

    /* renamed from: a, reason: collision with root package name */
    public final Context f4154a;

    /* renamed from: e, reason: collision with root package name */
    public CharSequence f4158e;

    /* renamed from: f, reason: collision with root package name */
    public CharSequence f4159f;

    /* renamed from: g, reason: collision with root package name */
    public PendingIntent f4160g;

    /* renamed from: h, reason: collision with root package name */
    public PendingIntent f4161h;

    /* renamed from: i, reason: collision with root package name */
    public IconCompat f4162i;

    /* renamed from: j, reason: collision with root package name */
    public int f4163j;

    /* renamed from: k, reason: collision with root package name */
    public int f4164k;

    /* renamed from: m, reason: collision with root package name */
    public boolean f4166m;

    /* renamed from: n, reason: collision with root package name */
    public z f4167n;

    /* renamed from: o, reason: collision with root package name */
    public CharSequence f4168o;

    /* renamed from: p, reason: collision with root package name */
    public int f4169p;

    /* renamed from: q, reason: collision with root package name */
    public int f4170q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f4171r;

    /* renamed from: s, reason: collision with root package name */
    public String f4172s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f4173t;

    /* renamed from: v, reason: collision with root package name */
    public boolean f4175v;

    /* renamed from: w, reason: collision with root package name */
    public boolean f4176w;
    public String x;

    /* renamed from: y, reason: collision with root package name */
    public Bundle f4177y;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f4155b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f4156c = new ArrayList();

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList f4157d = new ArrayList();

    /* renamed from: l, reason: collision with root package name */
    public boolean f4165l = true;

    /* renamed from: u, reason: collision with root package name */
    public boolean f4174u = false;

    /* renamed from: z, reason: collision with root package name */
    public int f4178z = 0;

    /* renamed from: A, reason: collision with root package name */
    public int f4145A = 0;

    /* renamed from: E, reason: collision with root package name */
    public int f4149E = 0;

    public C0372h(Context context, String str) {
        Notification notification = new Notification();
        this.f4151G = notification;
        this.f4154a = context;
        this.f4146B = str;
        notification.when = System.currentTimeMillis();
        notification.audioStreamType = -1;
        this.f4164k = 0;
        this.f4153I = new ArrayList();
        this.f4150F = true;
    }

    public static CharSequence b(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    public final Notification a() {
        Notification notificationBuild;
        Bundle bundle;
        io.flutter.plugin.platform.e eVar = new io.flutter.plugin.platform.e(this);
        C0372h c0372h = (C0372h) eVar.f2703d;
        z zVar = c0372h.f4167n;
        if (zVar != null) {
            zVar.b(eVar);
        }
        Notification.Builder builder = (Notification.Builder) eVar.f2702c;
        int i2 = eVar.f2700a;
        if (Build.VERSION.SDK_INT >= 26) {
            notificationBuild = builder.build();
        } else {
            Notification notificationBuild2 = builder.build();
            if (i2 != 0) {
                if (notificationBuild2.getGroup() != null && (notificationBuild2.flags & 512) != 0 && i2 == 2) {
                    notificationBuild2.sound = null;
                    notificationBuild2.vibrate = null;
                    notificationBuild2.defaults &= -4;
                }
                if (notificationBuild2.getGroup() != null && (notificationBuild2.flags & 512) == 0 && i2 == 1) {
                    notificationBuild2.sound = null;
                    notificationBuild2.vibrate = null;
                    notificationBuild2.defaults &= -4;
                }
            }
            notificationBuild = notificationBuild2;
        }
        if (zVar != null) {
            c0372h.f4167n.getClass();
        }
        if (zVar != null && (bundle = notificationBuild.extras) != null) {
            zVar.a(bundle);
        }
        return notificationBuild;
    }

    public final void c(int i2, boolean z2) {
        Notification notification = this.f4151G;
        if (z2) {
            notification.flags = i2 | notification.flags;
        } else {
            notification.flags = (~i2) & notification.flags;
        }
    }

    public final void d(z zVar) {
        if (this.f4167n != zVar) {
            this.f4167n = zVar;
            if (zVar == null || zVar.f4214a == this) {
                return;
            }
            zVar.f4214a = this;
            d(zVar);
        }
    }
}
