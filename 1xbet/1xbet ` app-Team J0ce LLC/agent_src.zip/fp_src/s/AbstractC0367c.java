package s;

import android.app.Notification;
import android.graphics.drawable.Icon;

/* renamed from: s.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0367c {
    public static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
        bigPictureStyle.bigLargeIcon(icon);
    }
}
