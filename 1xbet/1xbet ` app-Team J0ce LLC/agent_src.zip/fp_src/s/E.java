package s;

import android.content.ComponentName;
import c.InterfaceC0173c;
import java.util.ArrayDeque;

/* loaded from: classes.dex */
public final class E {

    /* renamed from: a, reason: collision with root package name */
    public final ComponentName f4093a;

    /* renamed from: c, reason: collision with root package name */
    public InterfaceC0173c f4095c;

    /* renamed from: b, reason: collision with root package name */
    public boolean f4094b = false;

    /* renamed from: d, reason: collision with root package name */
    public final ArrayDeque f4096d = new ArrayDeque();

    /* renamed from: e, reason: collision with root package name */
    public int f4097e = 0;

    public E(ComponentName componentName) {
        this.f4093a = componentName;
    }
}
