package s;

import C.AbstractC0005e;
import android.app.Notification;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class u extends z {

    /* renamed from: e, reason: collision with root package name */
    public final ArrayList f4195e = new ArrayList();

    /* renamed from: f, reason: collision with root package name */
    public final ArrayList f4196f = new ArrayList();

    /* renamed from: g, reason: collision with root package name */
    public H f4197g;

    /* renamed from: h, reason: collision with root package name */
    public CharSequence f4198h;

    /* renamed from: i, reason: collision with root package name */
    public Boolean f4199i;

    public u() {
    }

    /* JADX WARN: Removed duplicated region for block: B:47:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:4:0x0005  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x017c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static u e(Notification notification) {
        z uVar;
        Bundle bundle = notification.extras;
        if (bundle != null) {
            String string = bundle.getString("androidx.core.app.extra.COMPAT_TEMPLATE");
            if (string != null) {
                switch (string) {
                    case "androidx.core.app.NotificationCompat$ProgressStyle":
                        uVar = new y();
                        break;
                    case "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle":
                        uVar = new P.a(1);
                        break;
                    case "androidx.core.app.NotificationCompat$BigPictureStyle":
                        uVar = new C0369e();
                        break;
                    case "androidx.core.app.NotificationCompat$CallStyle":
                        uVar = new m();
                        break;
                    case "androidx.core.app.NotificationCompat$InboxStyle":
                        uVar = new C0370f(1);
                        break;
                    case "androidx.core.app.NotificationCompat$BigTextStyle":
                        uVar = new C0370f(0);
                        break;
                    case "androidx.core.app.NotificationCompat$MessagingStyle":
                        uVar = new u();
                        break;
                    default:
                        uVar = null;
                        break;
                }
                if (uVar == null) {
                    if (bundle.containsKey("android.selfDisplayName") || bundle.containsKey("android.messagingStyleUser")) {
                        uVar = new u();
                    } else if (bundle.containsKey("android.picture") || bundle.containsKey("android.pictureIcon")) {
                        uVar = new C0369e();
                    } else if (bundle.containsKey("android.bigText")) {
                        uVar = new C0370f(0);
                    } else if (bundle.containsKey("android.textLines")) {
                        uVar = new C0370f(1);
                    } else if (bundle.containsKey("android.callType")) {
                        uVar = new m();
                    } else if (bundle.containsKey("android.progressSegments") || bundle.containsKey("android.progressPoints")) {
                        uVar = new y();
                    } else {
                        String string2 = bundle.getString("android.template");
                        if (string2 != null) {
                            uVar = string2.equals(Notification.BigPictureStyle.class.getName()) ? new C0369e() : string2.equals(Notification.BigTextStyle.class.getName()) ? new C0370f(0) : string2.equals(Notification.InboxStyle.class.getName()) ? new C0370f(1) : (Build.VERSION.SDK_INT < 36 || !string2.equals(io.flutter.view.a.a().getName())) ? string2.equals(Notification.MessagingStyle.class.getName()) ? new u() : string2.equals(Notification.DecoratedCustomViewStyle.class.getName()) ? new P.a(1) : null : new y();
                        }
                    }
                }
                if (uVar == null) {
                    uVar = null;
                } else {
                    try {
                        uVar.d(bundle);
                    } catch (ClassCastException unused) {
                    }
                }
            }
        }
        if (uVar instanceof u) {
            return (u) uVar;
        }
        return null;
    }

    @Override // s.z
    public final void a(Bundle bundle) {
        super.a(bundle);
        bundle.putCharSequence("android.selfDisplayName", this.f4197g.f4109a);
        bundle.putBundle("android.messagingStyleUser", this.f4197g.b());
        bundle.putCharSequence("android.hiddenConversationTitle", this.f4198h);
        if (this.f4198h != null && this.f4199i.booleanValue()) {
            bundle.putCharSequence("android.conversationTitle", this.f4198h);
        }
        ArrayList arrayList = this.f4195e;
        if (!arrayList.isEmpty()) {
            bundle.putParcelableArray("android.messages", t.a(arrayList));
        }
        ArrayList arrayList2 = this.f4196f;
        if (!arrayList2.isEmpty()) {
            bundle.putParcelableArray("android.messages.historic", t.a(arrayList2));
        }
        Boolean bool = this.f4199i;
        if (bool != null) {
            bundle.putBoolean("android.isGroupConversation", bool.booleanValue());
        }
    }

    @Override // s.z
    public final void b(io.flutter.plugin.platform.e eVar) {
        Notification.MessagingStyle messagingStyleB;
        this.f4199i = Boolean.valueOf(f());
        if (Build.VERSION.SDK_INT >= 28) {
            H h2 = this.f4197g;
            h2.getClass();
            messagingStyleB = q.a(AbstractC0005e.r(h2));
        } else {
            messagingStyleB = o.b(this.f4197g.f4109a);
        }
        ArrayList arrayList = this.f4195e;
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            o.a(messagingStyleB, ((t) obj).c());
        }
        if (Build.VERSION.SDK_INT >= 26) {
            ArrayList arrayList2 = this.f4196f;
            int size2 = arrayList2.size();
            while (i2 < size2) {
                Object obj2 = arrayList2.get(i2);
                i2++;
                p.a(messagingStyleB, ((t) obj2).c());
            }
        }
        if (this.f4199i.booleanValue() || Build.VERSION.SDK_INT >= 28) {
            o.c(messagingStyleB, this.f4198h);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            q.b(messagingStyleB, this.f4199i.booleanValue());
        }
        messagingStyleB.setBuilder((Notification.Builder) eVar.f2702c);
    }

    @Override // s.z
    public final String c() {
        return "androidx.core.app.NotificationCompat$MessagingStyle";
    }

    @Override // s.z
    public final void d(Bundle bundle) {
        super.d(bundle);
        ArrayList arrayList = this.f4195e;
        arrayList.clear();
        if (bundle.containsKey("android.messagingStyleUser")) {
            this.f4197g = H.a(bundle.getBundle("android.messagingStyleUser"));
        } else {
            String string = bundle.getString("android.selfDisplayName");
            H h2 = new H();
            h2.f4109a = string;
            h2.f4110b = null;
            h2.f4111c = null;
            h2.f4112d = null;
            h2.f4113e = false;
            h2.f4114f = false;
            this.f4197g = h2;
        }
        CharSequence charSequence = bundle.getCharSequence("android.conversationTitle");
        this.f4198h = charSequence;
        if (charSequence == null) {
            this.f4198h = bundle.getCharSequence("android.hiddenConversationTitle");
        }
        Parcelable[] parcelableArray = bundle.getParcelableArray("android.messages");
        if (parcelableArray != null) {
            arrayList.addAll(t.b(parcelableArray));
        }
        Parcelable[] parcelableArray2 = bundle.getParcelableArray("android.messages.historic");
        if (parcelableArray2 != null) {
            this.f4196f.addAll(t.b(parcelableArray2));
        }
        if (bundle.containsKey("android.isGroupConversation")) {
            this.f4199i = Boolean.valueOf(bundle.getBoolean("android.isGroupConversation"));
        }
    }

    public final boolean f() {
        C0372h c0372h = this.f4214a;
        if (c0372h != null && c0372h.f4154a.getApplicationInfo().targetSdkVersion < 28 && this.f4199i == null) {
            return this.f4198h != null;
        }
        Boolean bool = this.f4199i;
        if (bool != null) {
            return bool.booleanValue();
        }
        return false;
    }

    public u(H h2) {
        if (!TextUtils.isEmpty(h2.f4109a)) {
            this.f4197g = h2;
            return;
        }
        throw new IllegalArgumentException("User's name must not be empty.");
    }
}
