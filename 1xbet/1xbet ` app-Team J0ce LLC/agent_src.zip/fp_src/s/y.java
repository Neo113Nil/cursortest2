package s;

import a.AbstractC0129a;
import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class y extends z {

    /* renamed from: h, reason: collision with root package name */
    public boolean f4209h;

    /* renamed from: j, reason: collision with root package name */
    public IconCompat f4211j;

    /* renamed from: k, reason: collision with root package name */
    public IconCompat f4212k;

    /* renamed from: l, reason: collision with root package name */
    public IconCompat f4213l;

    /* renamed from: e, reason: collision with root package name */
    public ArrayList f4206e = new ArrayList();

    /* renamed from: f, reason: collision with root package name */
    public ArrayList f4207f = new ArrayList();

    /* renamed from: g, reason: collision with root package name */
    public int f4208g = 0;

    /* renamed from: i, reason: collision with root package name */
    public boolean f4210i = true;

    public static IconCompat e(Parcelable parcelable) {
        if (parcelable == null) {
            return null;
        }
        if (parcelable instanceof Icon) {
            return IconCompat.b((Icon) parcelable);
        }
        if (parcelable instanceof Bitmap) {
            return IconCompat.d((Bitmap) parcelable);
        }
        return null;
    }

    @Override // s.z
    public final void a(Bundle bundle) {
        super.a(bundle);
        if (Build.VERSION.SDK_INT < 36) {
            ArrayList arrayList = this.f4206e;
            ArrayList<? extends Parcelable> arrayList2 = new ArrayList<>();
            if (arrayList != null && !arrayList.isEmpty()) {
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    x xVar = (x) arrayList.get(i2);
                    if (xVar.f4203a > 0) {
                        Bundle bundle2 = new Bundle();
                        bundle2.putInt("length", xVar.f4203a);
                        bundle2.putInt("id", xVar.f4204b);
                        bundle2.putInt("colorInt", xVar.f4205c);
                        arrayList2.add(bundle2);
                    }
                }
            }
            bundle.putParcelableArrayList("android.progressSegments", arrayList2);
            ArrayList arrayList3 = this.f4207f;
            ArrayList<? extends Parcelable> arrayList4 = new ArrayList<>();
            if (arrayList3 != null && !arrayList3.isEmpty()) {
                for (int i3 = 0; i3 < arrayList3.size(); i3++) {
                    w wVar = (w) arrayList3.get(i3);
                    if (wVar.f4200a >= 0) {
                        Bundle bundle3 = new Bundle();
                        bundle3.putInt("position", wVar.f4200a);
                        bundle3.putInt("id", wVar.f4201b);
                        bundle3.putInt("colorInt", wVar.f4202c);
                        arrayList4.add(bundle3);
                    }
                }
            }
            bundle.putParcelableArrayList("android.progressPoints", arrayList4);
            bundle.putInt("android.progress", this.f4208g);
            bundle.putBoolean("android.progressIndeterminate", this.f4209h);
            bundle.putInt("android.progressMax", f());
            bundle.putBoolean("android.styledByProgress", this.f4210i);
            C0372h c0372h = this.f4214a;
            Context context = c0372h != null ? c0372h.f4154a : null;
            if (context != null) {
                IconCompat iconCompat = this.f4211j;
                if (iconCompat != null) {
                    bundle.putParcelable("android.progressTrackerIcon", iconCompat.h(context));
                } else {
                    bundle.remove("android.progressTrackerIcon");
                }
                IconCompat iconCompat2 = this.f4212k;
                if (iconCompat2 != null) {
                    bundle.putParcelable("android.progressStartIcon", iconCompat2.h(context));
                } else {
                    bundle.remove("android.progressStartIcon");
                }
                IconCompat iconCompat3 = this.f4213l;
                if (iconCompat3 != null) {
                    bundle.putParcelable("android.progressEndIcon", iconCompat3.h(context));
                } else {
                    bundle.remove("android.progressEndIcon");
                }
            }
        }
    }

    @Override // s.z
    public final void b(io.flutter.plugin.platform.e eVar) {
        Notification.Builder builder = (Notification.Builder) eVar.f2702c;
        if (Build.VERSION.SDK_INT < 36) {
            int iF = f();
            builder.setProgress(iF, Math.min(this.f4208g, iF), this.f4209h);
            return;
        }
        Context context = eVar.f2701b;
        Notification.ProgressStyle progressStyle = new Notification.ProgressStyle();
        v.h(progressStyle, this.f4210i);
        v.a(progressStyle, this.f4208g);
        v.c(progressStyle, this.f4209h);
        IconCompat iconCompat = this.f4212k;
        v.f(progressStyle, iconCompat != null ? iconCompat.h(context) : null);
        IconCompat iconCompat2 = this.f4213l;
        v.b(progressStyle, iconCompat2 != null ? iconCompat2.h(context) : null);
        IconCompat iconCompat3 = this.f4211j;
        v.g(progressStyle, iconCompat3 != null ? iconCompat3.h(context) : null);
        v.d(progressStyle, this.f4207f);
        v.e(progressStyle, this.f4206e);
        builder.setStyle(progressStyle);
    }

    @Override // s.z
    public final String c() {
        return "androidx.core.app.NotificationCompat$ProgressStyle";
    }

    @Override // s.z
    public final void d(Bundle bundle) {
        super.d(bundle);
        ArrayList arrayListB = Build.VERSION.SDK_INT >= 34 ? D.f.b("android.progressSegments", bundle) : bundle.getParcelableArrayList("android.progressSegments");
        ArrayList arrayList = new ArrayList();
        if (arrayListB != null && !arrayListB.isEmpty()) {
            for (int i2 = 0; i2 < arrayListB.size(); i2++) {
                Bundle bundle2 = (Bundle) arrayListB.get(i2);
                int i3 = bundle2.getInt("length");
                if (i3 > 0) {
                    int i4 = bundle2.getInt("id");
                    int i5 = bundle2.getInt("colorInt", 0);
                    x xVar = new x();
                    xVar.f4203a = i3;
                    xVar.f4204b = i4;
                    xVar.f4205c = i5;
                    arrayList.add(xVar);
                }
            }
        }
        this.f4206e = arrayList;
        this.f4208g = bundle.getInt("android.progress", 0);
        this.f4209h = bundle.getBoolean("android.progressIndeterminate", false);
        this.f4210i = bundle.getBoolean("android.styledByProgress", true);
        ArrayList arrayListB2 = Build.VERSION.SDK_INT >= 34 ? D.f.b("android.progressPoints", bundle) : bundle.getParcelableArrayList("android.progressPoints");
        ArrayList arrayList2 = new ArrayList();
        if (arrayListB2 != null && !arrayListB2.isEmpty()) {
            for (int i6 = 0; i6 < arrayListB2.size(); i6++) {
                Bundle bundle3 = (Bundle) arrayListB2.get(i6);
                int i7 = bundle3.getInt("position");
                if (i7 >= 0) {
                    int i8 = bundle3.getInt("id");
                    int i9 = bundle3.getInt("colorInt", 0);
                    w wVar = new w();
                    wVar.f4200a = i7;
                    wVar.f4201b = i8;
                    wVar.f4202c = i9;
                    arrayList2.add(wVar);
                }
            }
        }
        this.f4207f = arrayList2;
        this.f4211j = e((Parcelable) AbstractC0129a.r("android.progressTrackerIcon", bundle));
        this.f4212k = e((Parcelable) AbstractC0129a.r("android.progressStartIcon", bundle));
        this.f4213l = e((Parcelable) AbstractC0129a.r("android.progressEndIcon", bundle));
    }

    public final int f() {
        ArrayList arrayList = this.f4206e;
        if (arrayList != null && !arrayList.isEmpty()) {
            int i2 = 0;
            int iAddExact = 0;
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                int i4 = ((x) arrayList.get(i3)).f4203a;
                if (i4 > 0) {
                    try {
                        iAddExact = Math.addExact(iAddExact, i4);
                        i2++;
                    } catch (ArithmeticException unused) {
                        return 100;
                    }
                }
            }
            if (i2 != 0) {
                return iAddExact;
            }
        }
        return 100;
    }
}
