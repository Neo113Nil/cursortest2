package s;

import android.app.PendingIntent;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import w0.AbstractC0390a;

/* renamed from: s.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0366b {

    /* renamed from: a, reason: collision with root package name */
    public final Bundle f4129a;

    /* renamed from: b, reason: collision with root package name */
    public IconCompat f4130b;

    /* renamed from: c, reason: collision with root package name */
    public final I[] f4131c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f4132d;

    /* renamed from: e, reason: collision with root package name */
    public final boolean f4133e;

    /* renamed from: f, reason: collision with root package name */
    public final int f4134f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f4135g;

    /* renamed from: h, reason: collision with root package name */
    public final int f4136h;

    /* renamed from: i, reason: collision with root package name */
    public final CharSequence f4137i;

    /* renamed from: j, reason: collision with root package name */
    public final PendingIntent f4138j;

    public C0366b(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle, I[] iArr, I[] iArr2, boolean z2, int i2, boolean z3, boolean z4) {
        this.f4133e = true;
        this.f4130b = iconCompat;
        if (iconCompat != null) {
            int i3 = iconCompat.f1977a;
            if ((i3 == -1 ? AbstractC0390a.y(iconCompat.f1978b) : i3) == 2) {
                this.f4136h = iconCompat.f();
            }
        }
        this.f4137i = C0372h.b(charSequence);
        this.f4138j = pendingIntent;
        this.f4129a = bundle == null ? new Bundle() : bundle;
        this.f4131c = iArr;
        this.f4132d = z2;
        this.f4134f = i2;
        this.f4133e = z3;
        this.f4135g = z4;
    }

    public final IconCompat a() {
        int i2;
        if (this.f4130b == null && (i2 = this.f4136h) != 0) {
            this.f4130b = IconCompat.e(null, "", i2);
        }
        return this.f4130b;
    }
}
