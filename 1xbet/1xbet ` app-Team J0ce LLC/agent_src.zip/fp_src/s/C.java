package s;

import android.app.Notification;
import android.os.Parcel;
import c.C0171a;
import c.InterfaceC0173c;

/* loaded from: classes.dex */
public final class C {

    /* renamed from: a, reason: collision with root package name */
    public final String f4087a;

    /* renamed from: b, reason: collision with root package name */
    public final int f4088b;

    /* renamed from: c, reason: collision with root package name */
    public final String f4089c;

    /* renamed from: d, reason: collision with root package name */
    public final Notification f4090d;

    public C(String str, int i2, String str2, Notification notification) {
        this.f4087a = str;
        this.f4088b = i2;
        this.f4089c = str2;
        this.f4090d = notification;
    }

    public final void a(InterfaceC0173c interfaceC0173c) {
        String str = this.f4087a;
        int i2 = this.f4088b;
        String str2 = this.f4089c;
        C0171a c0171a = (C0171a) interfaceC0173c;
        c0171a.getClass();
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(InterfaceC0173c.f2379c);
            parcelObtain.writeString(str);
            parcelObtain.writeInt(i2);
            parcelObtain.writeString(str2);
            Notification notification = this.f4090d;
            if (notification != null) {
                parcelObtain.writeInt(1);
                notification.writeToParcel(parcelObtain, 0);
            } else {
                parcelObtain.writeInt(0);
            }
            c0171a.f2377e.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }

    public final String toString() {
        return "NotifyTask[packageName:" + this.f4087a + ", id:" + this.f4088b + ", tag:" + this.f4089c + "]";
    }
}
