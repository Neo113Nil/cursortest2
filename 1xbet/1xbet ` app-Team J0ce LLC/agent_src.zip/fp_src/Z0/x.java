package Z0;

import android.util.Log;
import android.view.KeyEvent;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import k1.InterfaceC0289f;
import k1.InterfaceC0290g;

/* loaded from: classes.dex */
public final class x implements A {

    /* renamed from: i, reason: collision with root package name */
    public final InterfaceC0290g f1629i;

    /* renamed from: j, reason: collision with root package name */
    public final HashMap f1630j = new HashMap();

    /* renamed from: k, reason: collision with root package name */
    public final HashMap f1631k;

    /* renamed from: l, reason: collision with root package name */
    public final y f1632l;

    public x(InterfaceC0290g interfaceC0290g) {
        HashMap map = new HashMap();
        this.f1631k = map;
        this.f1632l = new y();
        this.f1629i = interfaceC0290g;
        C c2 = F.f1522a;
        E e2 = new E();
        e2.f1521a = false;
        E e3 = new E[]{e2}[0];
        e3.getClass();
        map.put(4294967556L, e3);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:136:0x02c6  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x02d5  */
    @Override // Z0.A
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(final KeyEvent keyEvent, z zVar) throws UnsupportedEncodingException {
        Long lValueOf;
        boolean z2;
        Long l2;
        int i2;
        String str;
        int i3;
        int i4;
        E e2;
        int i5;
        HashMap map;
        int i6;
        HashMap map2;
        Boolean[] boolArr;
        int i7;
        final long j2;
        int i8;
        int i9;
        int i10;
        x xVar = this;
        if (keyEvent.getScanCode() != 0 || keyEvent.getKeyCode() != 0) {
            long scanCode = keyEvent.getScanCode();
            if (scanCode == 0) {
                lValueOf = Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            } else {
                lValueOf = (Long) F.f1522a.get(Long.valueOf(scanCode));
                if (lValueOf == null) {
                    lValueOf = Long.valueOf((keyEvent.getScanCode() & 4294967295L) | 73014444032L);
                }
            }
            Long l3 = lValueOf;
            Long lValueOf2 = (Long) F.f1523b.get(Long.valueOf(keyEvent.getKeyCode()));
            if (lValueOf2 == null) {
                lValueOf2 = Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            }
            Long l4 = lValueOf2;
            ArrayList arrayList = new ArrayList();
            B.b[] bVarArr = F.f1524c;
            int length = bVarArr.length;
            int i11 = 0;
            while (true) {
                int i12 = 2;
                HashMap map3 = xVar.f1630j;
                if (i11 >= length) {
                    HashMap map4 = map3;
                    Long l5 = l4;
                    HashMap map5 = xVar.f1631k;
                    for (E e3 : map5.values()) {
                        int metaState = keyEvent.getMetaState();
                        e3.getClass();
                        boolean z3 = (metaState & 1048576) != 0;
                        if (4294967556L == l5.longValue() || e3.f1521a == z3) {
                            map = map4;
                        } else {
                            map = map4;
                            boolean zContainsKey = map.containsKey(458809L);
                            boolean z4 = !zContainsKey;
                            if (!zContainsKey) {
                                e3.f1521a = !e3.f1521a;
                            }
                            xVar.c(z4, 4294967556L, 458809L, keyEvent.getEventTime());
                            if (zContainsKey) {
                                e3.f1521a = !e3.f1521a;
                            }
                            c(zContainsKey, 4294967556L, 458809L, keyEvent.getEventTime());
                        }
                        xVar = this;
                        map4 = map;
                    }
                    HashMap map6 = map4;
                    int action = keyEvent.getAction();
                    if (action == 0) {
                        z2 = true;
                    } else if (action != 1) {
                        xVar = this;
                    } else {
                        z2 = false;
                    }
                    Long l6 = (Long) map6.get(l3);
                    if (z2) {
                        if (l6 == null) {
                            i5 = 1;
                        } else if (keyEvent.getRepeatCount() > 0) {
                            i5 = 3;
                        } else {
                            xVar = this;
                            l2 = l3;
                            xVar.c(false, l6, l2, keyEvent.getEventTime());
                            i5 = 1;
                            char cCharValue = xVar.f1632l.a(keyEvent.getUnicodeChar()).charValue();
                            i2 = i5;
                            str = cCharValue == 0 ? "" + cCharValue : null;
                            i4 = 3;
                            i3 = 1;
                        }
                        xVar = this;
                        l2 = l3;
                        char cCharValue2 = xVar.f1632l.a(keyEvent.getUnicodeChar()).charValue();
                        if (cCharValue2 == 0) {
                        }
                        i2 = i5;
                        str = cCharValue2 == 0 ? "" + cCharValue2 : null;
                        i4 = 3;
                        i3 = 1;
                    } else {
                        xVar = this;
                        l2 = l3;
                        if (l6 != null) {
                            i2 = 2;
                            str = null;
                            i3 = 1;
                            i4 = 3;
                        }
                    }
                    if (i2 != i4) {
                        xVar.d(l2, z2 ? l5 : null);
                    }
                    if (i2 == i3 && (e2 = (E) map5.get(l5)) != null) {
                        e2.f1521a = (e2.f1521a ? 1 : 0) ^ i3;
                    }
                    u uVar = new u();
                    int source = keyEvent.getSource();
                    if (source == 513) {
                        uVar.f1621f = 2;
                    } else if (source == 1025) {
                        uVar.f1621f = i4;
                    } else if (source == 16777232) {
                        uVar.f1621f = 4;
                    } else if (source != 33554433) {
                        uVar.f1621f = 1;
                    } else {
                        uVar.f1621f = 5;
                    }
                    uVar.f1616a = keyEvent.getEventTime();
                    uVar.f1617b = i2;
                    uVar.f1619d = l5.longValue();
                    uVar.f1618c = l2.longValue();
                    uVar.f1622g = str;
                    uVar.f1620e = false;
                    xVar.b(uVar, zVar);
                    int size = arrayList.size();
                    int i13 = 0;
                    while (i13 < size) {
                        Object obj = arrayList.get(i13);
                        i13++;
                        ((Runnable) obj).run();
                    }
                    return;
                }
                B.b bVar = bVarArr[i11];
                boolean z5 = (bVar.f4a & keyEvent.getMetaState()) != 0;
                long jLongValue = l4.longValue();
                long jLongValue2 = l3.longValue();
                D[] dArr = (D[]) bVar.f5b;
                boolean[] zArr = new boolean[2];
                Boolean[] boolArr2 = new Boolean[2];
                int i14 = 0;
                boolean z6 = false;
                while (i14 < i12) {
                    final D d2 = dArr[i14];
                    boolean[] zArr2 = zArr;
                    boolean zContainsKey2 = map3.containsKey(Long.valueOf(d2.f1519a));
                    zArr2[i14] = zContainsKey2;
                    Long l7 = l4;
                    if (d2.f1520b == jLongValue) {
                        boolean z7 = keyEvent.getRepeatCount() > 0;
                        int action2 = keyEvent.getAction();
                        if (action2 != 0) {
                            i9 = 1;
                            if (action2 != 1) {
                                throw new AssertionError("Unexpected event type");
                            }
                            i10 = 2;
                        } else {
                            i9 = 1;
                            i10 = z7 ? 3 : 1;
                        }
                        int iA = K.j.a(i10);
                        if (iA == 0) {
                            map2 = map3;
                            boolArr = boolArr2;
                            i7 = i14;
                            j2 = jLongValue2;
                            i8 = 2;
                            i6 = i11;
                            boolArr[i7] = Boolean.FALSE;
                            if (!z5) {
                                final int i15 = 0;
                                arrayList.add(new Runnable(this) { // from class: Z0.w

                                    /* renamed from: j, reason: collision with root package name */
                                    public final /* synthetic */ x f1625j;

                                    {
                                        this.f1625j = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() throws UnsupportedEncodingException {
                                        switch (i15) {
                                            case 0:
                                                x xVar2 = this.f1625j;
                                                xVar2.getClass();
                                                xVar2.c(false, Long.valueOf(d2.f1520b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                x xVar3 = this.f1625j;
                                                xVar3.getClass();
                                                xVar3.c(false, Long.valueOf(d2.f1520b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                        } else if (iA == i9) {
                            i6 = i11;
                            map2 = map3;
                            boolArr = boolArr2;
                            i7 = i14;
                            j2 = jLongValue2;
                            i8 = 2;
                            boolArr[i7] = Boolean.valueOf(zArr2[i7]);
                        } else if (iA != 2) {
                            i6 = i11;
                            i8 = 2;
                            map2 = map3;
                            boolArr = boolArr2;
                            i7 = i14;
                            j2 = jLongValue2;
                        } else {
                            if (z5) {
                                i6 = i11;
                                i8 = 2;
                                map2 = map3;
                                boolArr = boolArr2;
                                i7 = i14;
                                j2 = jLongValue2;
                            } else {
                                int i16 = i14;
                                final int i17 = 1;
                                i7 = i16;
                                i8 = 2;
                                map2 = map3;
                                boolArr = boolArr2;
                                j2 = jLongValue2;
                                i6 = i11;
                                arrayList.add(new Runnable(this) { // from class: Z0.w

                                    /* renamed from: j, reason: collision with root package name */
                                    public final /* synthetic */ x f1625j;

                                    {
                                        this.f1625j = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() throws UnsupportedEncodingException {
                                        switch (i17) {
                                            case 0:
                                                x xVar2 = this.f1625j;
                                                xVar2.getClass();
                                                xVar2.c(false, Long.valueOf(d2.f1520b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                x xVar3 = this.f1625j;
                                                xVar3.getClass();
                                                xVar3.c(false, Long.valueOf(d2.f1520b), Long.valueOf(j2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                            boolArr[i7] = Boolean.valueOf(zArr2[i7]);
                        }
                        z6 = true;
                    } else {
                        i6 = i11;
                        map2 = map3;
                        boolArr = boolArr2;
                        i7 = i14;
                        j2 = jLongValue2;
                        i8 = 2;
                        z6 = z6 || zContainsKey2;
                    }
                    i14 = i7 + 1;
                    jLongValue2 = j2;
                    i12 = i8;
                    boolArr2 = boolArr;
                    i11 = i6;
                    zArr = zArr2;
                    l4 = l7;
                    map3 = map2;
                }
                int i18 = i11;
                int i19 = i12;
                boolean[] zArr3 = zArr;
                Long l8 = l4;
                Boolean[] boolArr3 = boolArr2;
                if (z5) {
                    for (int i20 = 0; i20 < i19; i20++) {
                        if (boolArr3[i20] == null) {
                            if (z6) {
                                boolArr3[i20] = Boolean.valueOf(zArr3[i20]);
                            } else {
                                boolArr3[i20] = Boolean.TRUE;
                                z6 = true;
                            }
                        }
                    }
                    if (!z6) {
                        boolArr3[0] = Boolean.TRUE;
                    }
                } else {
                    for (int i21 = 0; i21 < i19; i21++) {
                        if (boolArr3[i21] == null) {
                            boolArr3[i21] = Boolean.FALSE;
                        }
                    }
                }
                for (int i22 = 0; i22 < i19; i22++) {
                    if (zArr3[i22] != boolArr3[i22].booleanValue()) {
                        D d3 = dArr[i22];
                        c(boolArr3[i22].booleanValue(), Long.valueOf(d3.f1520b), Long.valueOf(d3.f1519a), keyEvent.getEventTime());
                    }
                }
                xVar = this;
                i11 = i18 + 1;
                l4 = l8;
            }
        }
        xVar.c(true, 0L, 0L, 0L);
        zVar.a(true);
    }

    public final void b(u uVar, final z zVar) throws UnsupportedEncodingException {
        long j2;
        long j3;
        byte[] bytes = null;
        InterfaceC0289f interfaceC0289f = zVar == null ? null : new InterfaceC0289f() { // from class: Z0.v
            @Override // k1.InterfaceC0289f
            public final void a(ByteBuffer byteBuffer) {
                Boolean boolValueOf = Boolean.FALSE;
                if (byteBuffer != null) {
                    byteBuffer.rewind();
                    if (byteBuffer.capacity() != 0) {
                        boolValueOf = Boolean.valueOf(byteBuffer.get() != 0);
                    }
                } else {
                    Log.w("KeyEmbedderResponder", "A null reply was received when sending a key event to the framework.");
                }
                zVar.a(boolValueOf.booleanValue());
            }
        };
        try {
            String str = uVar.f1622g;
            if (str != null) {
                bytes = str.getBytes("UTF-8");
            }
            int length = bytes == null ? 0 : bytes.length;
            ByteBuffer byteBufferAllocateDirect = ByteBuffer.allocateDirect(length + 56);
            byteBufferAllocateDirect.order(ByteOrder.LITTLE_ENDIAN);
            byteBufferAllocateDirect.putLong(length);
            byteBufferAllocateDirect.putLong(uVar.f1616a);
            int i2 = uVar.f1617b;
            if (i2 == 1) {
                j2 = 0;
            } else if (i2 == 2) {
                j2 = 1;
            } else {
                if (i2 != 3) {
                    throw null;
                }
                j2 = 2;
            }
            byteBufferAllocateDirect.putLong(j2);
            byteBufferAllocateDirect.putLong(uVar.f1618c);
            byteBufferAllocateDirect.putLong(uVar.f1619d);
            byteBufferAllocateDirect.putLong(uVar.f1620e ? 1L : 0L);
            int i3 = uVar.f1621f;
            if (i3 == 1) {
                j3 = 0;
            } else if (i3 == 2) {
                j3 = 1;
            } else if (i3 == 3) {
                j3 = 2;
            } else if (i3 == 4) {
                j3 = 3;
            } else {
                if (i3 != 5) {
                    throw null;
                }
                j3 = 4;
            }
            byteBufferAllocateDirect.putLong(j3);
            if (bytes != null) {
                byteBufferAllocateDirect.put(bytes);
            }
            this.f1629i.p("flutter/keydata", byteBufferAllocateDirect, interfaceC0289f);
        } catch (UnsupportedEncodingException unused) {
            throw new AssertionError("UTF-8 not supported");
        }
    }

    public final void c(boolean z2, Long l2, Long l3, long j2) throws UnsupportedEncodingException {
        u uVar = new u();
        uVar.f1616a = j2;
        uVar.f1617b = z2 ? 1 : 2;
        uVar.f1619d = l2.longValue();
        uVar.f1618c = l3.longValue();
        uVar.f1622g = null;
        uVar.f1620e = true;
        uVar.f1621f = 1;
        if (l3.longValue() != 0 && l2.longValue() != 0) {
            if (!z2) {
                l2 = null;
            }
            d(l3, l2);
        }
        b(uVar, null);
    }

    public final void d(Long l2, Long l3) {
        HashMap map = this.f1630j;
        if (l3 != null) {
            if (((Long) map.put(l2, l3)) != null) {
                throw new AssertionError("The key was not empty");
            }
        } else if (((Long) map.remove(l2)) == null) {
            throw new AssertionError("The key was empty");
        }
    }
}
