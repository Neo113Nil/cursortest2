package Z0;

import a.AbstractC0129a;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.Window;
import android.view.accessibility.AccessibilityManager;
import android.view.textservice.TextServicesManager;
import android.window.OnBackInvokedCallback;
import b1.C0160a;
import com.veltherroomclimatelog.hyx1309.MainActivity;
import io.flutter.embedding.engine.FlutterJNI;
import j1.C0231b;
import j1.C0232c;
import j1.C0233d;
import j1.C0241l;
import j1.C0242m;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import k1.C0284a;
import k1.C0300q;
import k1.InterfaceC0302s;
import o1.C0321a;

/* renamed from: Z0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0122d extends Activity implements InterfaceC0125g, androidx.lifecycle.j {

    /* renamed from: m, reason: collision with root package name */
    public static final int f1543m = View.generateViewId();

    /* renamed from: i, reason: collision with root package name */
    public boolean f1544i = false;

    /* renamed from: j, reason: collision with root package name */
    public C0126h f1545j;

    /* renamed from: k, reason: collision with root package name */
    public final androidx.lifecycle.l f1546k;

    /* renamed from: l, reason: collision with root package name */
    public final OnBackInvokedCallback f1547l;

    public AbstractActivityC0122d() {
        int i2 = Build.VERSION.SDK_INT;
        this.f1547l = i2 < 33 ? null : i2 >= 34 ? new C0121c(this) : new OnBackInvokedCallback() { // from class: Z0.b
            public final void onBackInvoked() {
                this.f1541a.onBackPressed();
            }
        };
        this.f1546k = new androidx.lifecycle.l(this);
    }

    @Override // androidx.lifecycle.j
    public final androidx.lifecycle.l b() {
        return this.f1546k;
    }

    public final String c() {
        String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int d() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final String e() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final String f() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle bundleH = h();
            String string = bundleH != null ? bundleH.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final String g() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle bundleH = h();
            if (bundleH != null) {
                return bundleH.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final Bundle h() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void i(boolean z2) {
        if (z2 && !this.f1544i) {
            if (Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f1547l);
                this.f1544i = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1544i || Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1547l);
        this.f1544i = false;
    }

    public final boolean j() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (e() != null || this.f1545j.f1558g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean k() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : e() == null;
    }

    public final boolean l(String str) {
        C0126h c0126h = this.f1545j;
        if (c0126h == null) {
            Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0126h.f1561j) {
            return true;
        }
        Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        if (l("onActivityResult")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            if (c0126h.f1553b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Objects.toString(intent);
            a1.e eVar = c0126h.f1553b.f1666d;
            if (!eVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            r1.a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                a1.d dVar = eVar.f1697f;
                dVar.getClass();
                Iterator it = new HashSet((HashSet) dVar.f1688c).iterator();
                while (true) {
                    boolean z2 = false;
                    while (it.hasNext()) {
                        if (((InterfaceC0302s) it.next()).onActivityResult(i2, i3, intent) || z2) {
                            z2 = true;
                        }
                    }
                    Trace.endSection();
                    return;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (l("onBackPressed")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                cVar.f1671i.f3302a.a("popRoute", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:188:0x0465  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x050c  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x0517  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x056d A[LOOP:0: B:202:0x0567->B:204:0x056d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0583  */
    /* JADX WARN: Removed duplicated region for block: B:215:0x059d  */
    /* JADX WARN: Removed duplicated region for block: B:249:0x064e  */
    /* JADX WARN: Type inference failed for: r10v3, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        byte[] byteArray;
        SparseArray sparseArray;
        SparseArray sparseArray2;
        SparseArray sparseArray3;
        int i2;
        int i3;
        int i4;
        try {
            Bundle bundleH = h();
            if (bundleH != null && (i4 = bundleH.getInt("io.flutter.embedding.android.NormalTheme", -1)) != -1) {
                setTheme(i4);
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.e("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
        super.onCreate(bundle);
        if (bundle != null) {
            i(bundle.getBoolean("enableOnBackInvokedCallbackState"));
        }
        C0126h c0126h = new C0126h(this);
        this.f1545j = c0126h;
        c0126h.c();
        if (c0126h.f1553b == null) {
            String strE = c0126h.f1552a.e();
            if (strE != null) {
                if (a1.i.f1709c == null) {
                    a1.i.f1709c = new a1.i(1);
                }
                a1.c cVar = (a1.c) a1.i.f1709c.f1710a.get(strE);
                c0126h.f1553b = cVar;
                c0126h.f1558g = true;
                if (cVar == null) {
                    throw new IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + strE + "'");
                }
            } else {
                c0126h.f1552a.getClass();
                c0126h.f1553b = null;
                String stringExtra = c0126h.f1552a.getIntent().getStringExtra("cached_engine_group_id");
                if (stringExtra != null) {
                    if (a1.i.f1708b == null) {
                        synchronized (a1.i.class) {
                            try {
                                if (a1.i.f1708b == null) {
                                    a1.i.f1708b = new a1.i(0);
                                }
                            } finally {
                            }
                        }
                    }
                    a1.h hVar = (a1.h) a1.i.f1708b.f1710a.get(stringExtra);
                    if (hVar == null) {
                        throw new IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + stringExtra + "'");
                    }
                    AbstractActivityC0122d abstractActivityC0122d = c0126h.f1552a;
                    abstractActivityC0122d.getClass();
                    a1.g gVar = new a1.g(abstractActivityC0122d);
                    c0126h.a(gVar);
                    c0126h.f1553b = hVar.a(gVar);
                    c0126h.f1558g = false;
                } else {
                    AbstractActivityC0122d abstractActivityC0122d2 = c0126h.f1552a;
                    abstractActivityC0122d2.getClass();
                    Intent intent = c0126h.f1552a.getIntent();
                    ArrayList arrayList = new ArrayList();
                    if (intent.getBooleanExtra("trace-startup", false)) {
                        arrayList.add("--trace-startup");
                    }
                    if (intent.getBooleanExtra("start-paused", false)) {
                        arrayList.add("--start-paused");
                    }
                    int intExtra = intent.getIntExtra("vm-service-port", 0);
                    if (intExtra > 0) {
                        arrayList.add("--vm-service-port=" + Integer.toString(intExtra));
                    }
                    if (intent.getBooleanExtra("disable-service-auth-codes", false)) {
                        arrayList.add("--disable-service-auth-codes");
                    }
                    if (intent.getBooleanExtra("endless-trace-buffer", false)) {
                        arrayList.add("--endless-trace-buffer");
                    }
                    if (intent.getBooleanExtra("use-test-fonts", false)) {
                        arrayList.add("--use-test-fonts");
                    }
                    if (intent.getBooleanExtra("enable-dart-profiling", false)) {
                        arrayList.add("--enable-dart-profiling");
                    }
                    if (intent.getBooleanExtra("profile-startup", false)) {
                        arrayList.add("--profile-startup");
                    }
                    if (intent.getBooleanExtra("enable-software-rendering", false)) {
                        arrayList.add("--enable-software-rendering");
                    }
                    if (intent.getBooleanExtra("skia-deterministic-rendering", false)) {
                        arrayList.add("--skia-deterministic-rendering");
                    }
                    if (intent.getBooleanExtra("trace-skia", false)) {
                        arrayList.add("--trace-skia");
                    }
                    String stringExtra2 = intent.getStringExtra("trace-skia-allowlist");
                    if (stringExtra2 != null) {
                        arrayList.add("--trace-skia-allowlist=".concat(stringExtra2));
                    }
                    if (intent.getBooleanExtra("trace-systrace", false)) {
                        arrayList.add("--trace-systrace");
                    }
                    if (intent.hasExtra("trace-to-file")) {
                        arrayList.add("--trace-to-file=" + intent.getStringExtra("trace-to-file"));
                    }
                    if (intent.hasExtra("profile-microtasks")) {
                        arrayList.add("--profile-microtasks");
                    }
                    if (intent.hasExtra("enable-impeller")) {
                        if (intent.getBooleanExtra("enable-impeller", false)) {
                            arrayList.add("--enable-impeller=true");
                        } else {
                            arrayList.add("--enable-impeller=false");
                        }
                    }
                    if (intent.getBooleanExtra("enable-vulkan-validation", false)) {
                        arrayList.add("--enable-vulkan-validation");
                    }
                    if (intent.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
                        arrayList.add("--dump-skp-on-shader-compilation");
                    }
                    if (intent.getBooleanExtra("cache-sksl", false)) {
                        arrayList.add("--cache-sksl");
                    }
                    if (intent.getBooleanExtra("purge-persistent-cache", false)) {
                        arrayList.add("--purge-persistent-cache");
                    }
                    if (intent.getBooleanExtra("verbose-logging", false)) {
                        arrayList.add("--verbose-logging");
                    }
                    if (intent.hasExtra("dart-flags")) {
                        arrayList.add("--dart-flags=" + intent.getStringExtra("dart-flags"));
                    }
                    HashSet hashSet = new HashSet(arrayList);
                    a1.h hVar2 = new a1.h(abstractActivityC0122d2, (String[]) hashSet.toArray(new String[hashSet.size()]));
                    AbstractActivityC0122d abstractActivityC0122d3 = c0126h.f1552a;
                    abstractActivityC0122d3.getClass();
                    a1.g gVar2 = new a1.g(abstractActivityC0122d3);
                    gVar2.f1705e = false;
                    gVar2.f1706f = c0126h.f1552a.k();
                    c0126h.a(gVar2);
                    c0126h.f1553b = hVar2.a(gVar2);
                    c0126h.f1558g = false;
                }
            }
        }
        c0126h.f1552a.getClass();
        a1.e eVar = c0126h.f1553b.f1666d;
        androidx.lifecycle.l lVar = c0126h.f1552a.f1546k;
        eVar.getClass();
        r1.a.b("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            C0126h c0126h2 = eVar.f1696e;
            if (c0126h2 != null) {
                c0126h2.b();
            }
            eVar.e();
            eVar.f1696e = c0126h;
            AbstractActivityC0122d abstractActivityC0122d4 = c0126h.f1552a;
            abstractActivityC0122d4.getClass();
            eVar.b(abstractActivityC0122d4, lVar);
            Trace.endSection();
            AbstractActivityC0122d abstractActivityC0122d5 = c0126h.f1552a;
            abstractActivityC0122d5.getClass();
            AbstractActivityC0122d abstractActivityC0122d6 = c0126h.f1552a;
            a1.c cVar2 = c0126h.f1553b;
            abstractActivityC0122d6.getClass();
            c0126h.f1555d = new io.flutter.plugin.platform.e(abstractActivityC0122d6, cVar2.f1674l, abstractActivityC0122d6);
            AbstractActivityC0122d abstractActivityC0122d7 = c0126h.f1552a;
            a1.c cVar3 = c0126h.f1553b;
            abstractActivityC0122d7.getClass();
            int i5 = f1543m;
            c0126h.f1556e = new C0321a(i5, abstractActivityC0122d5, cVar3.f1676n);
            AbstractActivityC0122d abstractActivityC0122d8 = c0126h.f1552a;
            a1.c cVar4 = c0126h.f1553b;
            MainActivity mainActivity = (MainActivity) abstractActivityC0122d8;
            mainActivity.getClass();
            C1.i.e(cVar4, "flutterEngine");
            if (!mainActivity.f1545j.f1558g) {
                AbstractC0129a.x(cVar4);
            }
            D.i iVar = cVar4.f1665c.f2347m;
            C1.i.d(iVar, "getBinaryMessenger(...)");
            new C0300q(iVar, "velther_app_insights/device").b(new J0.g(5, mainActivity));
            c0126h.f1561j = true;
            C0126h c0126h3 = this.f1545j;
            c0126h3.c();
            if (bundle != null) {
                bundle.getBundle("plugins");
                byteArray = bundle.getByteArray("framework");
            } else {
                byteArray = null;
            }
            if (c0126h3.f1552a.k()) {
                C0242m c0242m = c0126h3.f1553b.f1673k;
                c0242m.f3350e = true;
                C0241l c0241l = c0242m.f3349d;
                if (c0241l != null) {
                    c0241l.c(C0242m.a(byteArray));
                    c0242m.f3349d = null;
                    c0242m.f3347b = byteArray;
                } else if (c0242m.f3351f) {
                    c0242m.f3348c.a("push", C0242m.a(byteArray), new C0241l(0, c0242m, byteArray));
                } else {
                    c0242m.f3347b = byteArray;
                }
            }
            c0126h3.f1552a.getClass();
            a1.e eVar2 = c0126h3.f1553b.f1666d;
            if (eVar2.f()) {
                r1.a.b("FlutterEngineConnectionRegistry#onRestoreInstanceState");
                try {
                    Iterator it = ((HashSet) eVar2.f1697f.f1691f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } finally {
                    try {
                        Trace.endSection();
                        throw th;
                    } catch (Throwable th) {
                        th.addSuppressed(th);
                    }
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
            }
            this.f1546k.d(androidx.lifecycle.d.ON_CREATE);
            if (d() == 2) {
                getWindow().setBackgroundDrawable(new ColorDrawable(0));
            }
            C0126h c0126h4 = this.f1545j;
            boolean z2 = (d() == 1 ? (char) 1 : (char) 2) == 1;
            c0126h4.c();
            if (c0126h4.f1552a.d() == 1) {
                AbstractActivityC0122d abstractActivityC0122d9 = c0126h4.f1552a;
                abstractActivityC0122d9.getClass();
                k kVar = new k(abstractActivityC0122d9, c0126h4.f1552a.d() != 1);
                c0126h4.f1552a.getClass();
                AbstractActivityC0122d abstractActivityC0122d10 = c0126h4.f1552a;
                abstractActivityC0122d10.getClass();
                c0126h4.f1554c = new r(abstractActivityC0122d10, kVar);
            } else {
                AbstractActivityC0122d abstractActivityC0122d11 = c0126h4.f1552a;
                abstractActivityC0122d11.getClass();
                m mVar = new m(abstractActivityC0122d11);
                mVar.setOpaque(c0126h4.f1552a.d() == 1);
                c0126h4.f1552a.getClass();
                AbstractActivityC0122d abstractActivityC0122d12 = c0126h4.f1552a;
                abstractActivityC0122d12.getClass();
                c0126h4.f1554c = new r(abstractActivityC0122d12, mVar);
            }
            c0126h4.f1554c.f1606p.add(c0126h4.f1563l);
            c0126h4.f1552a.getClass();
            r rVar = c0126h4.f1554c;
            a1.c cVar5 = c0126h4.f1553b;
            C0123e c0123e = rVar.f1595G;
            Objects.toString(cVar5);
            if (!rVar.c()) {
                rVar.f1608r = cVar5;
                io.flutter.embedding.engine.renderer.h hVar3 = cVar5.f1664b;
                rVar.f1607q = hVar3.f2632c;
                rVar.f1604n.c(hVar3);
                hVar3.a(c0123e);
                if (rVar.f1600j) {
                    hVar3.f2630a.addResizingFlutterUiListener(rVar.f1594F);
                }
                rVar.f1610t = new C0284a(rVar, rVar.f1608r.f1670h);
                a1.c cVar6 = rVar.f1608r;
                rVar.f1611u = new io.flutter.plugin.editing.k(rVar, cVar6.f1680r, cVar6.f1675m, cVar6.f1681s, cVar6.f1682t);
                try {
                    TextServicesManager textServicesManager = (TextServicesManager) rVar.getContext().getSystemService("textservices");
                    rVar.f1589A = textServicesManager;
                    rVar.f1612v = new io.flutter.plugin.editing.h(textServicesManager, rVar.f1608r.f1678p);
                } catch (Exception unused2) {
                    Log.e("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
                }
                new E0.f(rVar, rVar.f1611u.f2679b, rVar.f1608r.f1675m);
                rVar.f1613w = rVar.f1608r.f1667e;
                rVar.x = new N.f(rVar);
                rVar.f1614y = new C0119a(rVar.f1608r.f1664b, false);
                io.flutter.view.i iVar2 = new io.flutter.view.i(rVar, cVar5.f1668f, (AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), cVar5.f1683u);
                rVar.f1615z = iVar2;
                iVar2.f2856r = rVar.f1592D;
                boolean zIsEnabled = iVar2.f2841c.isEnabled();
                boolean zIsTouchExplorationEnabled = rVar.f1615z.f2841c.isTouchExplorationEnabled();
                if (rVar.f1608r.f1664b.f2630a.getIsSoftwareRenderingEnabled()) {
                    rVar.setWillNotDraw((zIsEnabled || zIsTouchExplorationEnabled) ? false : true);
                } else {
                    rVar.setWillNotDraw(false);
                }
                a1.c cVar7 = rVar.f1608r;
                cVar7.f1681s.f2728p.f2694a = rVar.f1615z;
                new C0119a(cVar7.f1664b, true);
                a1.c cVar8 = rVar.f1608r;
                cVar8.f1682t.f2710n.f2694a = rVar.f1615z;
                new C0119a(cVar8.f1664b, true);
                rVar.f1611u.f2679b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, rVar.f1593E);
                rVar.e();
                io.flutter.plugin.platform.k kVar2 = cVar5.f1681s;
                sparseArray = kVar2.f2731s;
                sparseArray2 = kVar2.f2732t;
                sparseArray3 = kVar2.f2734v;
                kVar2.f2723k = rVar;
                for (i2 = 0; i2 < sparseArray3.size(); i2++) {
                    kVar2.f2723k.addView((io.flutter.plugin.platform.g) sparseArray3.valueAt(i2));
                }
                for (i3 = 0; i3 < sparseArray2.size(); i3++) {
                    if (sparseArray2.valueAt(i3) != null) {
                        throw new ClassCastException();
                    }
                    kVar2.f2723k.addView(null);
                }
                if (sparseArray.size() <= 0) {
                    sparseArray.valueAt(0).getClass();
                    throw new ClassCastException();
                }
                io.flutter.plugin.platform.j jVar = cVar5.f1682t;
                SparseArray sparseArray4 = jVar.f2711o;
                SparseArray sparseArray5 = jVar.f2712p;
                jVar.f2707k = rVar;
                for (int i6 = 0; i6 < sparseArray5.size(); i6++) {
                    if (sparseArray5.valueAt(i6) != null) {
                        throw new ClassCastException();
                    }
                    jVar.f2707k.addView(null);
                }
                if (sparseArray4.size() > 0) {
                    sparseArray4.valueAt(0).getClass();
                    throw new ClassCastException();
                }
                Iterator it2 = rVar.f1609s.iterator();
                if (it2.hasNext()) {
                    it2.next().getClass();
                    throw new ClassCastException();
                }
                if (rVar.f1607q) {
                    c0123e.b();
                }
            } else if (cVar5 != rVar.f1608r) {
                rVar.a();
                rVar.f1608r = cVar5;
                io.flutter.embedding.engine.renderer.h hVar32 = cVar5.f1664b;
                rVar.f1607q = hVar32.f2632c;
                rVar.f1604n.c(hVar32);
                hVar32.a(c0123e);
                if (rVar.f1600j) {
                }
                rVar.f1610t = new C0284a(rVar, rVar.f1608r.f1670h);
                a1.c cVar62 = rVar.f1608r;
                rVar.f1611u = new io.flutter.plugin.editing.k(rVar, cVar62.f1680r, cVar62.f1675m, cVar62.f1681s, cVar62.f1682t);
                TextServicesManager textServicesManager2 = (TextServicesManager) rVar.getContext().getSystemService("textservices");
                rVar.f1589A = textServicesManager2;
                rVar.f1612v = new io.flutter.plugin.editing.h(textServicesManager2, rVar.f1608r.f1678p);
                new E0.f(rVar, rVar.f1611u.f2679b, rVar.f1608r.f1675m);
                rVar.f1613w = rVar.f1608r.f1667e;
                rVar.x = new N.f(rVar);
                rVar.f1614y = new C0119a(rVar.f1608r.f1664b, false);
                io.flutter.view.i iVar22 = new io.flutter.view.i(rVar, cVar5.f1668f, (AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), cVar5.f1683u);
                rVar.f1615z = iVar22;
                iVar22.f2856r = rVar.f1592D;
                boolean zIsEnabled2 = iVar22.f2841c.isEnabled();
                boolean zIsTouchExplorationEnabled2 = rVar.f1615z.f2841c.isTouchExplorationEnabled();
                if (rVar.f1608r.f1664b.f2630a.getIsSoftwareRenderingEnabled()) {
                }
                a1.c cVar72 = rVar.f1608r;
                cVar72.f1681s.f2728p.f2694a = rVar.f1615z;
                new C0119a(cVar72.f1664b, true);
                a1.c cVar82 = rVar.f1608r;
                cVar82.f1682t.f2710n.f2694a = rVar.f1615z;
                new C0119a(cVar82.f1664b, true);
                rVar.f1611u.f2679b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, rVar.f1593E);
                rVar.e();
                io.flutter.plugin.platform.k kVar22 = cVar5.f1681s;
                sparseArray = kVar22.f2731s;
                sparseArray2 = kVar22.f2732t;
                sparseArray3 = kVar22.f2734v;
                kVar22.f2723k = rVar;
                while (i2 < sparseArray3.size()) {
                }
                while (i3 < sparseArray2.size()) {
                }
                if (sparseArray.size() <= 0) {
                }
            }
            c0126h4.f1554c.setId(i5);
            if (z2) {
                r rVar2 = c0126h4.f1554c;
                if (c0126h4.f1552a.d() != 1) {
                    throw new IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
                }
                if (c0126h4.f1557f != null) {
                    rVar2.getViewTreeObserver().removeOnPreDrawListener(c0126h4.f1557f);
                }
                c0126h4.f1557f = new ViewTreeObserverOnPreDrawListenerC0124f(c0126h4, rVar2);
                rVar2.getViewTreeObserver().addOnPreDrawListener(c0126h4.f1557f);
            }
            setContentView(c0126h4.f1554c);
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            if (Build.VERSION.SDK_INT < 35) {
                window.setStatusBarColor(1073741824);
            }
            window.getDecorView().setSystemUiVisibility(1280);
        } catch (Throwable th2) {
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (l("onDestroy")) {
            this.f1545j.e();
            this.f1545j.f();
        }
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1547l);
            this.f1544i = false;
        }
        C0126h c0126h = this.f1545j;
        if (c0126h != null) {
            c0126h.f1552a = null;
            c0126h.f1553b = null;
            c0126h.f1554c = null;
            c0126h.f1555d = null;
            c0126h.f1556e = null;
            this.f1545j = null;
        }
        this.f1546k.d(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (l("onNewIntent")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            a1.e eVar = cVar.f1666d;
            if (eVar.f()) {
                r1.a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    Iterator it = ((HashSet) eVar.f1697f.f1689d).iterator();
                    while (it.hasNext()) {
                        ((k1.t) it.next()).onNewIntent(intent);
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            String strD = c0126h.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            C0231b c0231b = c0126h.f1553b.f1671i;
            c0231b.getClass();
            HashMap map = new HashMap();
            map.put("location", strD);
            c0231b.f3302a.a("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (l("onPause")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            c0126h.f1552a.getClass();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                C0233d c0233d = cVar.f1669g;
                c0233d.a(3, c0233d.f3306c);
            }
        }
        this.f1546k.d(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (l("onPostResume")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            if (c0126h.f1553b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0126h.f1555d;
            if (eVar != null) {
                eVar.c();
            }
            Iterator it = c0126h.f1553b.f1681s.f2729q.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (l("onRequestPermissionsResult")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            if (c0126h.f1553b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Arrays.toString(strArr);
            Arrays.toString(iArr);
            a1.e eVar = c0126h.f1553b.f1666d;
            if (!eVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            r1.a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                Iterator it = ((HashSet) eVar.f1697f.f1687b).iterator();
                while (true) {
                    boolean z2 = false;
                    while (it.hasNext()) {
                        if (((k1.u) it.next()).onRequestPermissionsResult(i2, strArr, iArr) || z2) {
                            z2 = true;
                        }
                    }
                    Trace.endSection();
                    return;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1546k.d(androidx.lifecycle.d.ON_RESUME);
        if (l("onResume")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            c0126h.f1553b.f1664b.d();
            c0126h.f1552a.getClass();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                C0233d c0233d = cVar.f1669g;
                c0233d.a(2, c0233d.f3306c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (l("onSaveInstanceState")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            if (c0126h.f1552a.k()) {
                bundle.putByteArray("framework", c0126h.f1553b.f1673k.f3347b);
            }
            c0126h.f1552a.getClass();
            Bundle bundle2 = new Bundle();
            a1.e eVar = c0126h.f1553b.f1666d;
            if (eVar.f()) {
                r1.a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    Iterator it = ((HashSet) eVar.f1697f.f1691f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0126h.f1552a.e() == null || c0126h.f1552a.j()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0126h.f1552a.f1544i);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        Bundle bundleH;
        super.onStart();
        this.f1546k.d(androidx.lifecycle.d.ON_START);
        if (l("onStart")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            if (c0126h.f1552a.e() == null && !c0126h.f1553b.f1665c.f2348n) {
                String strG = c0126h.f1552a.g();
                if (strG == null) {
                    AbstractActivityC0122d abstractActivityC0122d = c0126h.f1552a;
                    abstractActivityC0122d.getClass();
                    strG = c0126h.d(abstractActivityC0122d.getIntent());
                    if (strG == null) {
                        strG = "/";
                    }
                }
                AbstractActivityC0122d abstractActivityC0122d2 = c0126h.f1552a;
                abstractActivityC0122d2.getClass();
                try {
                    bundleH = abstractActivityC0122d2.h();
                } catch (PackageManager.NameNotFoundException unused) {
                }
                String string = bundleH != null ? bundleH.getString("io.flutter.EntrypointUri") : null;
                c0126h.f1552a.f();
                c0126h.f1553b.f1671i.f3302a.a("setInitialRoute", strG, null);
                String strC = c0126h.f1552a.c();
                if (strC == null || strC.isEmpty()) {
                    strC = (String) ((e1.d) N.f.H().f1050j).f2491d.f117c;
                }
                c0126h.f1553b.f1665c.a(string == null ? new C0160a(strC, c0126h.f1552a.f()) : new C0160a(strC, string, c0126h.f1552a.f()), (List) c0126h.f1552a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            Integer num = c0126h.f1562k;
            if (num != null) {
                c0126h.f1554c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (l("onStop")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            c0126h.f1552a.getClass();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                C0233d c0233d = cVar.f1669g;
                c0233d.a(5, c0233d.f3306c);
            }
            c0126h.f1562k = Integer.valueOf(c0126h.f1554c.getVisibility());
            c0126h.f1554c.setVisibility(8);
            a1.c cVar2 = c0126h.f1553b;
            if (cVar2 != null) {
                cVar2.f1664b.b(40);
            }
        }
        this.f1546k.d(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (l("onTrimMemory")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                if (c0126h.f1560i && i2 >= 10) {
                    FlutterJNI flutterJNI = cVar.f1665c.f2343i;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    C0232c c0232c = c0126h.f1553b.f1679q;
                    c0232c.getClass();
                    HashMap map = new HashMap(1);
                    map.put("type", "memoryPressure");
                    c0232c.f3303a.f(map, null);
                }
                c0126h.f1553b.f1664b.b(i2);
                io.flutter.plugin.platform.k kVar = c0126h.f1553b.f1681s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                Iterator it = kVar.f2729q.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (l("onUserLeaveHint")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            a1.e eVar = cVar.f1666d;
            if (!eVar.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            r1.a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                Iterator it = ((HashSet) eVar.f1697f.f1690e).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (l("onWindowFocusChanged")) {
            C0126h c0126h = this.f1545j;
            c0126h.c();
            c0126h.f1552a.getClass();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                C0233d c0233d = cVar.f1669g;
                if (z2) {
                    c0233d.a(c0233d.f3304a, true);
                } else {
                    c0233d.a(c0233d.f3304a, false);
                }
            }
        }
    }
}
