package Z0;

/* loaded from: classes.dex */
public interface B {
}
