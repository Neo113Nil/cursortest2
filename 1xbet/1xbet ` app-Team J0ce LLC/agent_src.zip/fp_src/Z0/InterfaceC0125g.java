package Z0;

/* renamed from: Z0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0125g {
}
