package Z0;

import android.view.ViewTreeObserver;

/* renamed from: Z0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ViewTreeObserverOnPreDrawListenerC0124f implements ViewTreeObserver.OnPreDrawListener {

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ r f1550i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ C0126h f1551j;

    public ViewTreeObserverOnPreDrawListenerC0124f(C0126h c0126h, r rVar) {
        this.f1551j = c0126h;
        this.f1550i = rVar;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        C0126h c0126h = this.f1551j;
        if (c0126h.f1559h && c0126h.f1557f != null) {
            this.f1550i.getViewTreeObserver().removeOnPreDrawListener(this);
            c0126h.f1557f = null;
        }
        return c0126h.f1559h;
    }
}
