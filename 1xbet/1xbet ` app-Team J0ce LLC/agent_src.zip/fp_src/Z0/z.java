package Z0;

import android.view.KeyEvent;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1634a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f1635b;

    public z(String str, boolean z2) {
        this.f1635b = str;
        this.f1634a = z2;
    }

    public void a(boolean z2) {
        if (this.f1634a) {
            throw new IllegalStateException("The onKeyEventHandledCallback should be called exactly once.");
        }
        this.f1634a = true;
        N.a aVar = (N.a) this.f1635b;
        int i2 = aVar.f1028b - 1;
        aVar.f1028b = i2;
        boolean z3 = z2 | aVar.f1029c;
        aVar.f1029c = z3;
        if (i2 != 0 || z3) {
            return;
        }
        ((N.f) aVar.f1031e).K((KeyEvent) aVar.f1030d);
    }

    public z(N.a aVar) {
        this.f1635b = aVar;
        this.f1634a = false;
    }
}
