package Z0;

import android.util.Log;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import j1.C0231b;

/* renamed from: Z0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0121c implements OnBackAnimationCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AbstractActivityC0122d f1542a;

    public C0121c(AbstractActivityC0122d abstractActivityC0122d) {
        this.f1542a = abstractActivityC0122d;
    }

    public final void onBackCancelled() {
        AbstractActivityC0122d abstractActivityC0122d = this.f1542a;
        if (abstractActivityC0122d.l("cancelBackGesture")) {
            C0126h c0126h = abstractActivityC0122d.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                cVar.f1672j.f3302a.a("cancelBackGesture", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked cancelBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackInvoked() {
        AbstractActivityC0122d abstractActivityC0122d = this.f1542a;
        if (abstractActivityC0122d.l("commitBackGesture")) {
            C0126h c0126h = abstractActivityC0122d.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                cVar.f1672j.f3302a.a("commitBackGesture", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked commitBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackProgressed(BackEvent backEvent) {
        AbstractActivityC0122d abstractActivityC0122d = this.f1542a;
        if (abstractActivityC0122d.l("updateBackGestureProgress")) {
            C0126h c0126h = abstractActivityC0122d.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                cVar.f1672j.f3302a.a("updateBackGestureProgress", C0231b.a(backEvent), null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked updateBackGestureProgress() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackStarted(BackEvent backEvent) {
        AbstractActivityC0122d abstractActivityC0122d = this.f1542a;
        if (abstractActivityC0122d.l("startBackGesture")) {
            C0126h c0126h = abstractActivityC0122d.f1545j;
            c0126h.c();
            a1.c cVar = c0126h.f1553b;
            if (cVar != null) {
                cVar.f1672j.f3302a.a("startBackGesture", C0231b.a(backEvent), null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked startBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }
}
