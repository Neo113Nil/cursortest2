package Z0;

import android.view.KeyEvent;

/* loaded from: classes.dex */
public interface A {
    void a(KeyEvent keyEvent, z zVar);
}
