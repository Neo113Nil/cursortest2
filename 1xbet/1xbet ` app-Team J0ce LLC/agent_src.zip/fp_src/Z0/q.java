package Z0;

/* loaded from: classes.dex */
public final class q implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ io.flutter.embedding.engine.renderer.h f1586a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ androidx.lifecycle.o f1587b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ r f1588c;

    public q(r rVar, io.flutter.embedding.engine.renderer.h hVar, androidx.lifecycle.o oVar) {
        this.f1588c = rVar;
        this.f1586a = hVar;
        this.f1587b = oVar;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        C0127i c0127i;
        this.f1586a.c(this);
        this.f1587b.run();
        r rVar = this.f1588c;
        if ((rVar.f1604n instanceof C0127i) || (c0127i = rVar.f1603m) == null) {
            return;
        }
        c0127i.a();
        C0127i c0127i2 = rVar.f1603m;
        if (c0127i2 != null) {
            c0127i2.f1564i.close();
            rVar.removeView(rVar.f1603m);
            rVar.f1603m = null;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
    }
}
