package Z0;

/* loaded from: classes.dex */
public final class H implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Runnable f1526a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ J f1527b;

    public H(J j2, Runnable runnable) {
        this.f1527b = j2;
        this.f1526a = runnable;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        this.f1526a.run();
        io.flutter.embedding.engine.renderer.h hVar = this.f1527b.f1531b;
        if (hVar != null) {
            hVar.c(this);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
    }
}
