package Z0;

/* loaded from: classes.dex */
public final /* synthetic */ class o implements B.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1583a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1584b;

    public /* synthetic */ o(int i2, Object obj) {
        this.f1583a = i2;
        this.f1584b = obj;
    }

    @Override // B.a
    public final void accept(Object obj) {
        switch (this.f1583a) {
            case 0:
                ((r) this.f1584b).setWindowInfoListenerDisplayFeatures((d0.j) obj);
                break;
            default:
                ((J1.p) ((J1.q) this.f1584b)).l((d0.j) obj);
                break;
        }
    }
}
