package Z0;

import android.graphics.Region;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import io.flutter.embedding.engine.FlutterJNI;
import w0.AbstractC0390a;

/* loaded from: classes.dex */
public final class k extends SurfaceView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: i, reason: collision with root package name */
    public boolean f1572i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1573j;

    /* renamed from: k, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1574k;

    /* renamed from: l, reason: collision with root package name */
    public final boolean f1575l;

    /* renamed from: m, reason: collision with root package name */
    public final J f1576m;

    public k(AbstractActivityC0122d abstractActivityC0122d, boolean z2) {
        super(abstractActivityC0122d, null);
        this.f1572i = false;
        this.f1573j = false;
        this.f1575l = false;
        J j2 = new J(new SurfaceHolderCallbackC0128j(this), this, this.f1574k);
        this.f1576m = j2;
        if (z2) {
            getHolder().setFormat(-2);
            setZOrderOnTop(true);
        }
        this.f1575l = AbstractC0390a.B(getContext());
        getHolder().addCallback(j2);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1574k == null) {
            Log.w("FlutterSurfaceView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1574k;
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
        }
        I i2 = this.f1576m.f1534e;
        switch (i2.f1528a) {
            case 0:
                i2.f1529b.f1531b = null;
                break;
            default:
                J j2 = i2.f1529b;
                j2.f1530a.setAlpha(0.0f);
                io.flutter.embedding.engine.renderer.h hVar2 = j2.f1531b;
                if (hVar2 != null) {
                    hVar2.c(j2.f1533d);
                }
                j2.f1531b = null;
                break;
        }
        this.f1574k = null;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1574k == null) {
            Log.w("FlutterSurfaceView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        I i2 = this.f1576m.f1534e;
        switch (i2.f1528a) {
            case 0:
                break;
            default:
                J j2 = i2.f1529b;
                io.flutter.embedding.engine.renderer.h hVar = j2.f1531b;
                if (hVar != null) {
                    hVar.a(j2.f1533d);
                    break;
                }
                break;
        }
        if (this.f1572i) {
            e();
        }
        this.f1573j = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1574k;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1574k = hVar;
        I i2 = this.f1576m.f1534e;
        switch (i2.f1528a) {
            case 0:
                i2.f1529b.f1531b = hVar;
                break;
            default:
                J j2 = i2.f1529b;
                io.flutter.embedding.engine.renderer.h hVar3 = j2.f1531b;
                if (hVar3 != null) {
                    hVar3.c(j2.f1533d);
                }
                j2.f1531b = hVar;
                break;
        }
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1574k == null) {
            Log.w("FlutterSurfaceView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1573j = true;
        }
    }

    public final void e() {
        if (this.f1574k == null || getHolder() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getHolder() are non-null.");
        }
        io.flutter.embedding.engine.renderer.h hVar = this.f1574k;
        Surface surface = getHolder().getSurface();
        boolean z2 = this.f1573j;
        FlutterJNI flutterJNI = hVar.f2630a;
        if (!z2) {
            hVar.e();
        }
        hVar.f2631b = surface;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface);
        } else {
            flutterJNI.onSurfaceCreated(surface);
        }
    }

    @Override // android.view.SurfaceView, android.view.View
    public final boolean gatherTransparentRegion(Region region) {
        if (getAlpha() < 1.0f) {
            return false;
        }
        int[] iArr = new int[2];
        getLocationInWindow(iArr);
        int i2 = iArr[0];
        region.op(i2, iArr[1], (getRight() + i2) - getLeft(), (getBottom() + iArr[1]) - getTop(), Region.Op.DIFFERENCE);
        return true;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1574k;
    }

    @Override // android.view.SurfaceView, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1575l) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }
}
