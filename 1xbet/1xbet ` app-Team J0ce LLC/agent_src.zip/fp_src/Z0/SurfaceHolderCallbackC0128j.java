package Z0;

import android.view.SurfaceHolder;

/* renamed from: Z0.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class SurfaceHolderCallbackC0128j implements SurfaceHolder.Callback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k f1571a;

    public SurfaceHolderCallbackC0128j(k kVar) {
        this.f1571a = kVar;
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        k kVar = this.f1571a;
        io.flutter.embedding.engine.renderer.h hVar = kVar.f1574k;
        if (hVar == null || kVar.f1573j) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2630a.onSurfaceChanged(i3, i4);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        k kVar = this.f1571a;
        kVar.f1572i = true;
        if (kVar.f1574k == null || kVar.f1573j) {
            return;
        }
        kVar.e();
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        k kVar = this.f1571a;
        kVar.f1572i = false;
        io.flutter.embedding.engine.renderer.h hVar = kVar.f1574k;
        if (hVar == null || kVar.f1573j) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
        }
        hVar.e();
    }
}
