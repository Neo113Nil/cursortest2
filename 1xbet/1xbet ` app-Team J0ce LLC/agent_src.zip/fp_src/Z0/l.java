package Z0;

import android.graphics.SurfaceTexture;
import android.view.Surface;
import android.view.TextureView;

/* loaded from: classes.dex */
public final class l implements TextureView.SurfaceTextureListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ m f1577a;

    public l(m mVar) {
        this.f1577a = mVar;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i2, int i3) {
        m mVar = this.f1577a;
        mVar.f1578i = true;
        if (mVar.f1580k == null || mVar.f1579j) {
            return;
        }
        mVar.e();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        m mVar = this.f1577a;
        mVar.f1578i = false;
        io.flutter.embedding.engine.renderer.h hVar = mVar.f1580k;
        if (hVar != null && !mVar.f1579j) {
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            Surface surface = mVar.f1581l;
            if (surface != null) {
                surface.release();
                mVar.f1581l = null;
            }
        }
        Surface surface2 = mVar.f1581l;
        if (surface2 == null) {
            return true;
        }
        surface2.release();
        mVar.f1581l = null;
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i2, int i3) {
        m mVar = this.f1577a;
        io.flutter.embedding.engine.renderer.h hVar = mVar.f1580k;
        if (hVar == null || mVar.f1579j) {
            return;
        }
        if (hVar == null) {
            throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2630a.onSurfaceChanged(i2, i3);
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
    }
}
