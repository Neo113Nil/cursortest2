package Z0;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Paint;
import android.hardware.HardwareBuffer;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import java.nio.ByteBuffer;
import java.util.Locale;
import w0.AbstractC0390a;

/* renamed from: Z0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0127i extends View implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: i, reason: collision with root package name */
    public ImageReader f1564i;

    /* renamed from: j, reason: collision with root package name */
    public Image f1565j;

    /* renamed from: k, reason: collision with root package name */
    public Bitmap f1566k;

    /* renamed from: l, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1567l;

    /* renamed from: m, reason: collision with root package name */
    public final boolean f1568m;

    /* renamed from: n, reason: collision with root package name */
    public final int f1569n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1570o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0127i(Context context, int i2, int i3, int i4) {
        super(context, null);
        ImageReader imageReaderF = f(i2, i3);
        this.f1568m = false;
        this.f1570o = false;
        this.f1564i = imageReaderF;
        this.f1569n = i4;
        setAlpha(0.0f);
        this.f1568m = AbstractC0390a.B(getContext());
    }

    public static ImageReader f(int i2, int i3) {
        if (i2 <= 0) {
            Locale locale = Locale.US;
            Log.w("FlutterImageView", "ImageReader width must be greater than 0, but given width=" + i2 + ", set width=1");
            i2 = 1;
        }
        if (i3 <= 0) {
            Locale locale2 = Locale.US;
            Log.w("FlutterImageView", "ImageReader height must be greater than 0, but given height=" + i3 + ", set height=1");
            i3 = 1;
        }
        return Build.VERSION.SDK_INT >= 29 ? ImageReader.newInstance(i2, i3, 1, 3, 768L) : ImageReader.newInstance(i2, i3, 1, 3);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1570o) {
            setAlpha(0.0f);
            e();
            this.f1566k = null;
            Image image = this.f1565j;
            if (image != null) {
                image.close();
                this.f1565j = null;
            }
            invalidate();
            this.f1570o = false;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        if (K.j.a(this.f1569n) == 0) {
            Surface surface = this.f1564i.getSurface();
            hVar.f2631b = surface;
            hVar.f2630a.onSurfaceWindowChanged(surface);
        }
        setAlpha(1.0f);
        this.f1567l = hVar;
        this.f1570o = true;
    }

    public final boolean e() {
        if (!this.f1570o) {
            return false;
        }
        Image imageAcquireLatestImage = this.f1564i.acquireLatestImage();
        if (imageAcquireLatestImage != null) {
            Image image = this.f1565j;
            if (image != null) {
                image.close();
                this.f1565j = null;
            }
            this.f1565j = imageAcquireLatestImage;
            invalidate();
        }
        return imageAcquireLatestImage != null;
    }

    public final void g(int i2, int i3) {
        if (this.f1567l == null) {
            return;
        }
        if (i2 == this.f1564i.getWidth() && i3 == this.f1564i.getHeight()) {
            return;
        }
        Image image = this.f1565j;
        if (image != null) {
            image.close();
            this.f1565j = null;
        }
        this.f1564i.close();
        this.f1564i = f(i2, i3);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1567l;
    }

    public ImageReader getImageReader() {
        return this.f1564i;
    }

    public Surface getSurface() {
        return this.f1564i.getSurface();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Image image = this.f1565j;
        if (image != null) {
            if (Build.VERSION.SDK_INT >= 29) {
                HardwareBuffer hardwareBuffer = image.getHardwareBuffer();
                ColorSpace.Named unused = ColorSpace.Named.SRGB;
                this.f1566k = Bitmap.wrapHardwareBuffer(hardwareBuffer, ColorSpace.get(ColorSpace.Named.SRGB));
                hardwareBuffer.close();
            } else {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length == 1) {
                    Image.Plane plane = planes[0];
                    int rowStride = plane.getRowStride() / plane.getPixelStride();
                    int height = this.f1565j.getHeight();
                    Bitmap bitmap = this.f1566k;
                    if (bitmap == null || bitmap.getWidth() != rowStride || this.f1566k.getHeight() != height) {
                        this.f1566k = Bitmap.createBitmap(rowStride, height, Bitmap.Config.ARGB_8888);
                    }
                    ByteBuffer buffer = plane.getBuffer();
                    buffer.rewind();
                    this.f1566k.copyPixelsFromBuffer(buffer);
                }
            }
        }
        Bitmap bitmap2 = this.f1566k;
        if (bitmap2 != null) {
            canvas.drawBitmap(bitmap2, 0.0f, 0.0f, (Paint) null);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1568m) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        if (!(i2 == this.f1564i.getWidth() && i3 == this.f1564i.getHeight()) && this.f1569n == 1 && this.f1570o) {
            g(i2, i3);
            io.flutter.embedding.engine.renderer.h hVar = this.f1567l;
            Surface surface = this.f1564i.getSurface();
            hVar.f2631b = surface;
            hVar.f2630a.onSurfaceWindowChanged(surface);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
    }
}
