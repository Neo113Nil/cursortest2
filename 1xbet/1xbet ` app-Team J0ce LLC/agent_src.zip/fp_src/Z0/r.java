package Z0;

import C.AbstractC0005e;
import C.C0011k;
import H1.AbstractC0046w;
import H1.C0043t;
import H1.L;
import H1.Q;
import I.C0062m;
import a.AbstractC0129a;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.LocaleList;
import android.os.Looper;
import android.provider.Settings;
import android.text.Selection;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.DisplayCutout;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewStructure;
import android.view.Window;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textservice.SpellCheckerInfo;
import android.view.textservice.SpellCheckerSession;
import android.view.textservice.TextServicesManager;
import android.widget.FrameLayout;
import b0.C0159a;
import d0.C0180b;
import d0.C0181c;
import d0.C0185g;
import d0.C0187i;
import d0.InterfaceC0186h;
import io.flutter.embedding.engine.FlutterJNI;
import j1.C0230a;
import j1.C0243n;
import j1.C0244o;
import j1.C0245p;
import j1.C0246q;
import j1.C0247r;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import k1.C0284a;
import k1.C0300q;
import k1.InterfaceC0290g;
import l1.C0306a;
import m1.InterfaceC0313a;
import w0.AbstractC0390a;
import y.ExecutorC0392a;

/* loaded from: classes.dex */
public final class r extends FrameLayout implements InterfaceC0313a, B {

    /* renamed from: A, reason: collision with root package name */
    public TextServicesManager f1589A;

    /* renamed from: B, reason: collision with root package name */
    public D.i f1590B;

    /* renamed from: C, reason: collision with root package name */
    public final io.flutter.embedding.engine.renderer.g f1591C;

    /* renamed from: D, reason: collision with root package name */
    public final D.i f1592D;

    /* renamed from: E, reason: collision with root package name */
    public final G.a f1593E;

    /* renamed from: F, reason: collision with root package name */
    public final p f1594F;

    /* renamed from: G, reason: collision with root package name */
    public final C0123e f1595G;

    /* renamed from: H, reason: collision with root package name */
    public o f1596H;

    /* renamed from: I, reason: collision with root package name */
    public int f1597I;
    public int J;

    /* renamed from: K, reason: collision with root package name */
    public t f1598K;

    /* renamed from: i, reason: collision with root package name */
    public final AtomicBoolean f1599i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1600j;

    /* renamed from: k, reason: collision with root package name */
    public final k f1601k;

    /* renamed from: l, reason: collision with root package name */
    public final m f1602l;

    /* renamed from: m, reason: collision with root package name */
    public C0127i f1603m;

    /* renamed from: n, reason: collision with root package name */
    public View f1604n;

    /* renamed from: o, reason: collision with root package name */
    public View f1605o;

    /* renamed from: p, reason: collision with root package name */
    public final HashSet f1606p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f1607q;

    /* renamed from: r, reason: collision with root package name */
    public a1.c f1608r;

    /* renamed from: s, reason: collision with root package name */
    public final HashSet f1609s;

    /* renamed from: t, reason: collision with root package name */
    public C0284a f1610t;

    /* renamed from: u, reason: collision with root package name */
    public io.flutter.plugin.editing.k f1611u;

    /* renamed from: v, reason: collision with root package name */
    public io.flutter.plugin.editing.h f1612v;

    /* renamed from: w, reason: collision with root package name */
    public C0306a f1613w;
    public N.f x;

    /* renamed from: y, reason: collision with root package name */
    public C0119a f1614y;

    /* renamed from: z, reason: collision with root package name */
    public io.flutter.view.i f1615z;

    public r(AbstractActivityC0122d abstractActivityC0122d, k kVar) {
        super(abstractActivityC0122d, null);
        this.f1599i = new AtomicBoolean(true);
        this.f1600j = false;
        this.f1606p = new HashSet();
        this.f1609s = new HashSet();
        this.f1591C = new io.flutter.embedding.engine.renderer.g();
        this.f1592D = new D.i(18, this);
        this.f1593E = new G.a(this, new Handler(Looper.getMainLooper()), 1);
        this.f1594F = new p(this);
        this.f1595G = new C0123e(1, this);
        this.f1598K = new t();
        this.f1601k = kVar;
        this.f1604n = kVar;
        b();
    }

    /* JADX WARN: Type inference failed for: r0v38, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final void a() {
        Objects.toString(this.f1608r);
        if (c()) {
            Iterator it = this.f1609s.iterator();
            if (it.hasNext()) {
                it.next().getClass();
                throw new ClassCastException();
            }
            getContext().getContentResolver().unregisterContentObserver(this.f1593E);
            io.flutter.plugin.platform.k kVar = this.f1608r.f1681s;
            SparseArray sparseArray = kVar.f2731s;
            SparseArray sparseArray2 = kVar.f2732t;
            SparseArray sparseArray3 = kVar.f2734v;
            for (int i2 = 0; i2 < sparseArray3.size(); i2++) {
                kVar.f2723k.removeView((io.flutter.plugin.platform.g) sparseArray3.valueAt(i2));
            }
            for (int i3 = 0; i3 < sparseArray2.size(); i3++) {
                if (sparseArray2.valueAt(i3) != null) {
                    throw new ClassCastException();
                }
                kVar.f2723k.removeView(null);
            }
            kVar.b();
            SparseArray sparseArray4 = kVar.f2733u;
            if (kVar.f2723k == null) {
                Log.e("PlatformViewsController", "removeOverlaySurfaces called while flutter view is null");
            } else {
                for (int i4 = 0; i4 < sparseArray4.size(); i4++) {
                    kVar.f2723k.removeView((View) sparseArray4.valueAt(i4));
                }
                sparseArray4.clear();
            }
            kVar.f2723k = null;
            kVar.x = false;
            if (sparseArray.size() > 0) {
                sparseArray.valueAt(0).getClass();
                throw new ClassCastException();
            }
            io.flutter.plugin.platform.j jVar = this.f1608r.f1682t;
            SparseArray sparseArray5 = jVar.f2711o;
            SparseArray sparseArray6 = jVar.f2712p;
            for (int i5 = 0; i5 < sparseArray6.size(); i5++) {
                if (sparseArray6.valueAt(i5) != null) {
                    throw new ClassCastException();
                }
                jVar.f2707k.removeView(null);
            }
            Surface surface = jVar.f2715s;
            if (surface != null) {
                surface.release();
                jVar.f2715s = null;
                jVar.f2716t = null;
            }
            jVar.f2707k = null;
            if (sparseArray5.size() > 0) {
                sparseArray5.valueAt(0).getClass();
                throw new ClassCastException();
            }
            this.f1608r.f1681s.o();
            this.f1608r.f1682t.o();
            io.flutter.view.i iVar = this.f1615z;
            iVar.f2858t = true;
            iVar.f2843e.o();
            iVar.f2856r = null;
            AccessibilityManager accessibilityManager = iVar.f2841c;
            accessibilityManager.removeAccessibilityStateChangeListener(iVar.f2859u);
            accessibilityManager.removeTouchExplorationStateChangeListener(iVar.f2860v);
            iVar.f2844f.unregisterContentObserver(iVar.f2861w);
            N.f fVar = iVar.f2840b;
            fVar.f1052l = null;
            ((FlutterJNI) fVar.f1051k).setAccessibilityDelegate(null);
            this.f1615z = null;
            this.f1611u.f2679b.restartInput(this);
            this.f1611u.b();
            int size = ((HashSet) this.x.f1051k).size();
            if (size > 0) {
                Log.w("KeyboardManager", "A KeyboardManager was destroyed with " + size + " unhandled redispatch event(s).");
            }
            io.flutter.plugin.editing.h hVar = this.f1612v;
            if (hVar != null) {
                hVar.f2665a.f3301j = null;
                SpellCheckerSession spellCheckerSession = hVar.f2667c;
                if (spellCheckerSession != null) {
                    spellCheckerSession.close();
                }
            }
            C0284a c0284a = this.f1610t;
            if (c0284a != null) {
                ((C0230a) c0284a.f3637k).f3301j = null;
            }
            io.flutter.embedding.engine.renderer.h hVar2 = this.f1608r.f1664b;
            this.f1607q = false;
            hVar2.c(this.f1595G);
            FlutterJNI flutterJNI = hVar2.f2630a;
            if (this.f1600j) {
                flutterJNI.removeResizingFlutterUiListener(this.f1594F);
            }
            hVar2.e();
            flutterJNI.setSemanticsEnabled(false);
            View view = this.f1605o;
            if (view != null && this.f1604n == this.f1603m) {
                this.f1604n = view;
            }
            this.f1604n.a();
            C0127i c0127i = this.f1603m;
            if (c0127i != null) {
                c0127i.f1564i.close();
                removeView(this.f1603m);
                this.f1603m = null;
            }
            this.f1605o = null;
            this.f1608r = null;
        }
    }

    @Override // android.view.View
    public final void autofill(SparseArray sparseArray) {
        C0062m c0062m;
        C0062m c0062m2;
        io.flutter.plugin.editing.k kVar = this.f1611u;
        if (Build.VERSION.SDK_INT < 26) {
            kVar.getClass();
            return;
        }
        C0245p c0245p = kVar.f2683f;
        if (c0245p == null || kVar.f2684g == null || (c0062m = c0245p.f3366j) == null) {
            return;
        }
        HashMap map = new HashMap();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            C0245p c0245p2 = (C0245p) kVar.f2684g.get(sparseArray.keyAt(i2));
            if (c0245p2 != null && (c0062m2 = c0245p2.f3366j) != null) {
                String str = (String) c0062m2.f529a;
                String string = com.dexterous.flutterlocalnotifications.a.g(sparseArray.valueAt(i2)).getTextValue().toString();
                C0247r c0247r = new C0247r(string, string.length(), string.length(), -1, -1);
                if (str.equals((String) c0062m.f529a)) {
                    kVar.f2685h.f(c0247r);
                } else {
                    map.put(str, c0247r);
                }
            }
        }
        E0.f fVar = kVar.f2681d;
        int i3 = kVar.f2682e.f57c;
        fVar.getClass();
        map.size();
        HashMap map2 = new HashMap();
        for (Map.Entry entry : map.entrySet()) {
            C0247r c0247r2 = (C0247r) entry.getValue();
            map2.put((String) entry.getKey(), E0.f.B(c0247r2.f3373a, c0247r2.f3374b, c0247r2.f3375c, -1, -1));
        }
        ((C0300q) fVar.f133j).a("TextInputClient.updateEditingStateWithTag", Arrays.asList(Integer.valueOf(i3), map2), null);
    }

    public final void b() {
        k kVar = this.f1601k;
        if (kVar != null) {
            addView(kVar);
        } else {
            m mVar = this.f1602l;
            if (mVar != null) {
                addView(mVar);
            } else {
                addView(this.f1603m);
            }
        }
        this.f1600j = AbstractC0390a.B(getContext());
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) {
            setImportantForAutofill(1);
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final boolean c() {
        a1.c cVar = this.f1608r;
        return cVar != null && cVar.f1664b == this.f1604n.getAttachedRenderer();
    }

    @Override // android.view.View
    public final boolean checkInputConnectionProxy(View view) {
        a1.c cVar = this.f1608r;
        if (cVar == null) {
            return super.checkInputConnectionProxy(view);
        }
        HashMap map = cVar.f1681s.f2730r;
        if (view == null || !map.containsKey(view.getContext())) {
            return false;
        }
        View view2 = (View) map.get(view.getContext());
        if (view2 == view) {
            return true;
        }
        return view2.checkInputConnectionProxy(view);
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d() {
        boolean z2;
        String str;
        boolean z3;
        char c2 = (getResources().getConfiguration().uiMode & 48) == 32 ? (char) 2 : (char) 1;
        TextServicesManager textServicesManager = this.f1589A;
        if (textServicesManager == null) {
            z2 = false;
        } else {
            if (Build.VERSION.SDK_INT >= 31) {
                Iterator it = textServicesManager.getEnabledSpellCheckerInfos().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        z3 = false;
                        break;
                    } else if (((SpellCheckerInfo) it.next()).getPackageName().equals("com.google.android.inputmethod.latin")) {
                        z3 = true;
                        break;
                    }
                }
                if (!this.f1589A.isSpellCheckerEnabled() || !z3) {
                }
            }
            z2 = true;
        }
        C0244o c0244o = this.f1608r.f1677o;
        c0244o.getClass();
        C0062m c0062m = c0244o.f3356b;
        HashMap map = new HashMap();
        map.put("textScaleFactor", Float.valueOf(getResources().getConfiguration().fontScale));
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        map.put("nativeSpellCheckServiceDefined", Boolean.valueOf(z2));
        map.put("brieflyShowPassword", Boolean.valueOf(Settings.System.getInt(getContext().getContentResolver(), "show_password", 1) == 1));
        map.put("alwaysUse24HourFormat", Boolean.valueOf(DateFormat.is24HourFormat(getContext())));
        if (c2 == 1) {
            str = "light";
        } else {
            if (c2 != 2) {
                throw null;
            }
            str = "dark";
        }
        map.put("platformBrightness", str);
        Objects.toString(map.get("textScaleFactor"));
        Objects.toString(map.get("alwaysUse24HourFormat"));
        Objects.toString(map.get("platformBrightness"));
        if (Build.VERSION.SDK_INT < 34 || displayMetrics == null) {
            c0062m.f(map, null);
            return;
        }
        C0243n c0243n = new C0243n(displayMetrics);
        N.f fVar = c0244o.f3355a;
        ((ConcurrentLinkedQueue) fVar.f1050j).add(c0243n);
        C0243n c0243n2 = (C0243n) fVar.f1052l;
        fVar.f1052l = c0243n;
        E0.f fVar2 = c0243n2 != null ? new E0.f((Object) fVar, (Object) c0243n2, 25, false) : null;
        map.put("configurationId", Integer.valueOf(c0243n.f3353a));
        c0062m.f(map, fVar2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            getKeyDispatcherState().startTracking(keyEvent, this);
        } else if (keyEvent.getAction() == 1) {
            getKeyDispatcherState().handleUpEvent(keyEvent);
        }
        return (c() && this.x.G(keyEvent)) || super.dispatchKeyEvent(keyEvent);
    }

    public final void e() {
        if (!c()) {
            Log.w("FlutterView", "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine.");
            return;
        }
        float f2 = getResources().getDisplayMetrics().density;
        io.flutter.embedding.engine.renderer.g gVar = this.f1591C;
        gVar.f2608a = f2;
        gVar.f2627t = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        io.flutter.embedding.engine.renderer.h hVar = this.f1608r.f1664b;
        hVar.getClass();
        int i2 = gVar.f2609b;
        ArrayList arrayList = gVar.f2629v;
        ArrayList arrayList2 = gVar.f2628u;
        if (i2 == 0) {
            int i3 = gVar.f2611d;
            int i4 = gVar.f2612e;
            if (i3 <= 0 && i4 <= 0) {
                return;
            }
        } else {
            int i5 = gVar.f2610c;
            if (i5 == 0) {
                int i6 = gVar.f2613f;
                int i7 = gVar.f2614g;
                if (i6 <= 0 && i7 <= 0) {
                    return;
                }
            } else if (i2 <= 0 || i5 <= 0 || gVar.f2608a <= 0.0f) {
                return;
            }
        }
        arrayList2.size();
        arrayList.size();
        int size = arrayList.size() + arrayList2.size();
        int[] iArr = new int[size * 4];
        int[] iArr2 = new int[size];
        int[] iArr3 = new int[size];
        for (int i8 = 0; i8 < arrayList2.size(); i8++) {
            io.flutter.embedding.engine.renderer.a aVar = (io.flutter.embedding.engine.renderer.a) arrayList2.get(i8);
            int i9 = i8 * 4;
            Rect rect = aVar.f2595a;
            iArr[i9] = rect.left;
            iArr[i9 + 1] = rect.top;
            iArr[i9 + 2] = rect.right;
            iArr[i9 + 3] = rect.bottom;
            iArr2[i8] = K.j.a(aVar.f2596b);
            iArr3[i8] = K.j.a(aVar.f2597c);
        }
        int size2 = arrayList2.size() * 4;
        for (int i10 = 0; i10 < arrayList.size(); i10++) {
            io.flutter.embedding.engine.renderer.a aVar2 = (io.flutter.embedding.engine.renderer.a) arrayList.get(i10);
            int i11 = (i10 * 4) + size2;
            Rect rect2 = aVar2.f2595a;
            iArr[i11] = rect2.left;
            iArr[i11 + 1] = rect2.top;
            iArr[i11 + 2] = rect2.right;
            iArr[i11 + 3] = rect2.bottom;
            iArr2[arrayList2.size() + i10] = K.j.a(aVar2.f2596b);
            iArr3[arrayList2.size() + i10] = K.j.a(aVar2.f2597c);
        }
        hVar.f2630a.setViewportMetrics(gVar.f2608a, gVar.f2609b, gVar.f2610c, gVar.f2615h, gVar.f2616i, gVar.f2617j, gVar.f2618k, gVar.f2619l, gVar.f2620m, gVar.f2621n, gVar.f2622o, gVar.f2623p, gVar.f2624q, gVar.f2625r, gVar.f2626s, gVar.f2627t, iArr, iArr2, iArr3, gVar.f2611d, gVar.f2612e, gVar.f2613f, gVar.f2614g);
    }

    @Override // android.view.View
    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        io.flutter.view.i iVar = this.f1615z;
        if (iVar == null || !iVar.f2841c.isEnabled()) {
            return null;
        }
        return this.f1615z;
    }

    public a1.c getAttachedFlutterEngine() {
        return this.f1608r;
    }

    public InterfaceC0290g getBinaryMessenger() {
        return this.f1608r.f1665c;
    }

    public C0127i getCurrentImageSurface() {
        return this.f1603m;
    }

    public io.flutter.embedding.engine.renderer.g getViewportMetrics() {
        return this.f1591C;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x013d  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0174  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x017e A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0186  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x01a1  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x01a3  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        char c2;
        double d2;
        Window window;
        DisplayCutout displayCutout;
        WindowInsets windowInsetsOnApplyWindowInsets = super.onApplyWindowInsets(windowInsets);
        int i2 = Build.VERSION.SDK_INT;
        io.flutter.embedding.engine.renderer.g gVar = this.f1591C;
        if (i2 == 29) {
            Insets systemGestureInsets = windowInsets.getSystemGestureInsets();
            gVar.f2623p = systemGestureInsets.top;
            gVar.f2624q = systemGestureInsets.right;
            gVar.f2625r = systemGestureInsets.bottom;
            gVar.f2626s = systemGestureInsets.left;
        }
        boolean z2 = (getWindowSystemUiVisibility() & 4) == 0;
        boolean z3 = (getWindowSystemUiVisibility() & 2) == 0;
        if (i2 >= 30) {
            Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars());
            gVar.f2615h = insets.top;
            gVar.f2616i = insets.right;
            gVar.f2617j = insets.bottom;
            gVar.f2618k = insets.left;
            Insets insets2 = windowInsets.getInsets(WindowInsets.Type.ime());
            gVar.f2619l = insets2.top;
            gVar.f2620m = insets2.right;
            gVar.f2621n = insets2.bottom;
            gVar.f2622o = insets2.left;
            Insets insets3 = windowInsets.getInsets(WindowInsets.Type.systemGestures());
            gVar.f2623p = insets3.top;
            gVar.f2624q = insets3.right;
            gVar.f2625r = insets3.bottom;
            gVar.f2626s = insets3.left;
            DisplayCutout displayCutout2 = windowInsets.getDisplayCutout();
            if (displayCutout2 != null) {
                Insets waterfallInsets = displayCutout2.getWaterfallInsets();
                gVar.f2615h = Math.max(Math.max(gVar.f2615h, waterfallInsets.top), displayCutout2.getSafeInsetTop());
                gVar.f2616i = Math.max(Math.max(gVar.f2616i, waterfallInsets.right), displayCutout2.getSafeInsetRight());
                gVar.f2617j = Math.max(Math.max(gVar.f2617j, waterfallInsets.bottom), displayCutout2.getSafeInsetBottom());
                gVar.f2618k = Math.max(Math.max(gVar.f2618k, waterfallInsets.left), displayCutout2.getSafeInsetLeft());
            }
        } else if (!z3) {
            Context context = getContext();
            if (context.getResources().getConfiguration().orientation != 2) {
                c2 = 1;
                gVar.f2615h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
                gVar.f2616i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
                if (z3) {
                    d2 = 0.18d;
                } else {
                    d2 = 0.18d;
                    int systemWindowInsetBottom = ((((double) windowInsets.getSystemWindowInsetBottom()) > (((double) getRootView().getHeight()) * 0.18d) ? 1 : (((double) windowInsets.getSystemWindowInsetBottom()) == (((double) getRootView().getHeight()) * 0.18d) ? 0 : -1)) < 0 ? 0 : windowInsets.getSystemWindowInsetBottom()) == 0 ? windowInsets.getSystemWindowInsetBottom() : 0;
                    gVar.f2617j = systemWindowInsetBottom;
                    gVar.f2618k = (c2 == 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
                    gVar.f2619l = 0;
                    gVar.f2620m = 0;
                    gVar.f2621n = ((double) windowInsets.getSystemWindowInsetBottom()) >= ((double) getRootView().getHeight()) * d2 ? 0 : windowInsets.getSystemWindowInsetBottom();
                    gVar.f2622o = 0;
                }
                gVar.f2617j = systemWindowInsetBottom;
                if (c2 == 2) {
                    gVar.f2618k = (c2 == 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
                    gVar.f2619l = 0;
                    gVar.f2620m = 0;
                    gVar.f2621n = ((double) windowInsets.getSystemWindowInsetBottom()) >= ((double) getRootView().getHeight()) * d2 ? 0 : windowInsets.getSystemWindowInsetBottom();
                    gVar.f2622o = 0;
                }
            } else {
                int rotation = ((DisplayManager) context.getSystemService("display")).getDisplay(0).getRotation();
                if (rotation == 1) {
                    c2 = 3;
                } else if (rotation == 3) {
                    c2 = 2;
                } else if (rotation == 0 || rotation == 2) {
                    c2 = 4;
                }
                gVar.f2615h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
                if (c2 != 3) {
                    gVar.f2616i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
                    if (z3) {
                    }
                    gVar.f2617j = systemWindowInsetBottom;
                }
            }
        }
        ArrayList arrayList = new ArrayList();
        if (i2 >= 28 && (displayCutout = windowInsets.getDisplayCutout()) != null) {
            for (Rect rect : displayCutout.getBoundingRects()) {
                rect.toString();
                arrayList.add(new io.flutter.embedding.engine.renderer.a(rect, 4, 1));
            }
        }
        ArrayList arrayList2 = gVar.f2629v;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        if (Build.VERSION.SDK_INT >= 35) {
            t tVar = this.f1598K;
            Context context2 = getContext();
            tVar.getClass();
            Activity activityL = AbstractC0129a.l(context2);
            WindowInsets rootWindowInsets = null;
            if (activityL != null && (window = activityL.getWindow()) != null) {
                rootWindowInsets = window.getDecorView().getRootWindowInsets();
            }
            List boundingRects = rootWindowInsets == null ? Collections.EMPTY_LIST : rootWindowInsets.getBoundingRects(WindowInsets.Type.captionBar());
            int iMax = gVar.f2615h;
            Iterator it = boundingRects.iterator();
            while (it.hasNext()) {
                iMax = Math.max(iMax, ((Rect) it.next()).bottom);
            }
            gVar.f2615h = iMax;
        }
        e();
        return windowInsetsOnApplyWindowInsets;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v8, types: [K1.d] */
    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        D.i iVar;
        super.onAttachedToWindow();
        try {
            C0185g c0185g = InterfaceC0186h.f2459f;
            Context context = getContext();
            c0185g.getClass();
            iVar = new D.i(19, new E0.f(C0185g.a(context)));
        } catch (NoClassDefFoundError unused) {
            iVar = null;
        }
        this.f1590B = iVar;
        Activity activityL = AbstractC0129a.l(getContext());
        D.i iVar2 = this.f1590B;
        if (iVar2 == null || activityL == null) {
            return;
        }
        this.f1596H = new o(0, this);
        Context context2 = getContext();
        Executor executorD = Build.VERSION.SDK_INT >= 28 ? AbstractC0005e.d(context2) : new ExecutorC0392a(new Handler(context2.getMainLooper()), 0);
        o oVar = this.f1596H;
        E0.f fVar = (E0.f) iVar2.f102j;
        C1.i.e(executorD, "executor");
        C1.i.e(oVar, "consumer");
        E0.f fVar2 = (E0.f) fVar.f134k;
        C0180b c0180b = (C0180b) fVar.f133j;
        c0180b.getClass();
        C0187i c0187i = new C0187i(c0180b, activityL, null);
        J1.a aVar = J1.a.f636i;
        u1.i iVar3 = u1.i.f4276i;
        K1.c cVar = new K1.c(c0187i, iVar3, -2, aVar);
        O1.e eVar = H1.D.f265a;
        I1.c cVar2 = M1.o.f1017a;
        if (cVar2.o(C0043t.f328j) != null) {
            throw new IllegalArgumentException(("Flow context cannot contain job in it. Had " + cVar2).toString());
        }
        K1.c cVarX = cVar;
        if (!cVar2.equals(iVar3)) {
            cVarX = L1.j.x(cVar, cVar2, 0, null, 6);
        }
        LinkedHashMap linkedHashMap = (LinkedHashMap) fVar2.f134k;
        ReentrantLock reentrantLock = (ReentrantLock) fVar2.f133j;
        reentrantLock.lock();
        try {
            if (linkedHashMap.get(oVar) == null) {
                linkedHashMap.put(oVar, AbstractC0046w.h(AbstractC0046w.a(new L(executorD)), new C0159a(cVarX, oVar, null)));
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) throws Exception {
        super.onConfigurationChanged(configuration);
        if (this.f1608r != null) {
            this.f1613w.b(configuration);
            d();
            AbstractC0129a.b(getContext(), this.f1608r);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0059 A[PHI: r8
      0x0059: PHI (r8v11 int) = (r8v6 int), (r8v14 int) binds: [B:73:0x00b4, B:31:0x0057] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00b3  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        int i2;
        if (!c()) {
            return super.onCreateInputConnection(editorInfo);
        }
        io.flutter.plugin.editing.k kVar = this.f1611u;
        N.f fVar = this.x;
        C0011k c0011k = kVar.f2682e;
        int i3 = c0011k.f56b;
        if (i3 == 1) {
            kVar.f2687j = null;
            return null;
        }
        int i4 = 4;
        if (i3 == 4) {
            return null;
        }
        if (i3 == 3) {
            if (kVar.f2693p) {
                return kVar.f2687j;
            }
            kVar.f2688k.h(c0011k.f57c);
            throw null;
        }
        C0245p c0245p = kVar.f2683f;
        C0246q c0246q = c0245p.f3363g;
        boolean z2 = c0245p.f3357a;
        boolean z3 = c0245p.f3358b;
        boolean z4 = c0245p.f3359c;
        boolean z5 = c0245p.f3360d;
        int i5 = c0245p.f3362f;
        int i6 = c0246q.f3370a;
        if (i6 != 2) {
            if (i6 == 5) {
                i4 = c0246q.f3371b ? 4098 : 2;
                if (c0246q.f3372c) {
                    i4 |= 8192;
                }
            } else if (i6 == 6) {
                i4 = 3;
            } else if (i6 == 11) {
                i4 = 0;
            } else {
                int i7 = i6 == 7 ? 131073 : (i6 == 8 || i6 == 13) ? 33 : (i6 == 9 || i6 == 12) ? 17 : i6 == 10 ? 145 : i6 == 3 ? 97 : i6 == 4 ? 113 : 1;
                if (!z2) {
                    if (z3) {
                        i7 |= 32768;
                    }
                    i2 = z4 ? 524416 : 524432;
                    i4 = i7;
                    if (i5 != 1) {
                        i4 |= 4096;
                    } else if (i5 != 2) {
                        if (i5 == 3) {
                            i4 |= 16384;
                        }
                    }
                }
                i7 |= i2;
                i4 = i7;
                if (i5 != 1) {
                }
            }
        }
        editorInfo.inputType = i4;
        editorInfo.imeOptions = 33554432;
        int i8 = Build.VERSION.SDK_INT;
        if (i8 >= 26 && !z5) {
            editorInfo.imeOptions = 50331648;
        }
        int iIntValue = c0245p.f3364h.intValue();
        C0245p c0245p2 = kVar.f2683f;
        String str = c0245p2.f3365i;
        if (str != null) {
            editorInfo.actionLabel = str;
            editorInfo.actionId = iIntValue;
        }
        editorInfo.imeOptions = iIntValue | editorInfo.imeOptions;
        if (c0245p2.f3369m != null) {
            editorInfo.hintLocales = new LocaleList(kVar.f2683f.f3369m);
        }
        String[] strArr = kVar.f2683f.f3367k;
        if (strArr != null) {
            if (i8 >= 25) {
                editorInfo.contentMimeTypes = strArr;
            } else {
                if (editorInfo.extras == null) {
                    editorInfo.extras = new Bundle();
                }
                editorInfo.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", strArr);
                editorInfo.extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", strArr);
            }
        }
        if (i8 >= 34) {
            if (i8 >= 35) {
                E.b.b(editorInfo);
            }
            if (editorInfo.extras == null) {
                editorInfo.extras = new Bundle();
            }
            editorInfo.extras.putBoolean("androidx.core.view.inputmethod.EditorInfoCompat.STYLUS_HANDWRITING_ENABLED", true);
        }
        io.flutter.plugin.editing.d dVar = new io.flutter.plugin.editing.d(this, kVar.f2682e.f57c, kVar.f2681d, fVar, kVar.f2685h, editorInfo);
        io.flutter.plugin.editing.g gVar = kVar.f2685h;
        gVar.getClass();
        editorInfo.initialSelStart = Selection.getSelectionStart(gVar);
        io.flutter.plugin.editing.g gVar2 = kVar.f2685h;
        gVar2.getClass();
        editorInfo.initialSelEnd = Selection.getSelectionEnd(gVar2);
        kVar.f2687j = dVar;
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        o oVar;
        D.i iVar = this.f1590B;
        if (iVar != null && (oVar = this.f1596H) != null) {
            E0.f fVar = (E0.f) ((E0.f) iVar.f102j).f134k;
            LinkedHashMap linkedHashMap = (LinkedHashMap) fVar.f134k;
            ReentrantLock reentrantLock = (ReentrantLock) fVar.f133j;
            reentrantLock.lock();
            try {
                Q q2 = (Q) linkedHashMap.get(oVar);
                if (q2 != null) {
                    q2.b(null);
                }
                reentrantLock.unlock();
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
        this.f1596H = null;
        this.f1590B = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (c()) {
            C0119a c0119a = this.f1614y;
            Context context = getContext();
            c0119a.getClass();
            boolean zIsFromSource = motionEvent.isFromSource(2);
            boolean z2 = motionEvent.getActionMasked() == 7 || motionEvent.getActionMasked() == 8;
            if (zIsFromSource && z2) {
                int iB = C0119a.b(motionEvent.getActionMasked());
                ByteBuffer byteBufferAllocateDirect = ByteBuffer.allocateDirect(motionEvent.getPointerCount() * 288);
                byteBufferAllocateDirect.order(ByteOrder.LITTLE_ENDIAN);
                c0119a.a(motionEvent, motionEvent.getActionIndex(), iB, 0, C0119a.f1535f, byteBufferAllocateDirect, context);
                if (byteBufferAllocateDirect.position() % 288 != 0) {
                    throw new AssertionError("Packet position is not on field boundary.");
                }
                c0119a.f1536a.f2630a.dispatchPointerDataPacket(byteBufferAllocateDirect, byteBufferAllocateDirect.position());
                return true;
            }
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        return !c() ? super.onHoverEvent(motionEvent) : this.f1615z.e(motionEvent, false);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        this.f1597I = View.MeasureSpec.getMode(i2);
        this.J = View.MeasureSpec.getMode(i3);
        super.onMeasure(i2, i3);
    }

    @Override // android.view.View
    public final void onProvideAutofillVirtualStructure(ViewStructure viewStructure, int i2) {
        Rect rect;
        super.onProvideAutofillVirtualStructure(viewStructure, i2);
        io.flutter.plugin.editing.k kVar = this.f1611u;
        if (Build.VERSION.SDK_INT < 26) {
            kVar.getClass();
            return;
        }
        if (kVar.f2684g != null) {
            String str = (String) kVar.f2683f.f3366j.f529a;
            AutofillId autofillId = viewStructure.getAutofillId();
            for (int i3 = 0; i3 < kVar.f2684g.size(); i3++) {
                int iKeyAt = kVar.f2684g.keyAt(i3);
                C0062m c0062m = ((C0245p) kVar.f2684g.valueAt(i3)).f3366j;
                if (c0062m != null) {
                    viewStructure.addChildCount(1);
                    ViewStructure viewStructureNewChild = viewStructure.newChild(i3);
                    viewStructureNewChild.setAutofillId(autofillId, iKeyAt);
                    String[] strArr = (String[]) c0062m.f530b;
                    if (strArr.length > 0) {
                        viewStructureNewChild.setAutofillHints(strArr);
                    }
                    viewStructureNewChild.setAutofillType(1);
                    viewStructureNewChild.setVisibility(0);
                    String str2 = (String) c0062m.f532d;
                    if (str2 != null) {
                        viewStructureNewChild.setHint(str2);
                    }
                    if (str.hashCode() != iKeyAt || (rect = kVar.f2690m) == null) {
                        viewStructureNewChild.setDimens(0, 0, 0, 0, 1, 1);
                        viewStructureNewChild.setAutofillValue(AutofillValue.forText(((C0247r) c0062m.f531c).f3373a));
                    } else {
                        viewStructureNewChild.setDimens(rect.left, rect.top, 0, 0, rect.width(), kVar.f2690m.height());
                        viewStructureNewChild.setAutofillValue(AutofillValue.forText(kVar.f2685h));
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        io.flutter.embedding.engine.renderer.g gVar = this.f1591C;
        gVar.f2609b = i2;
        gVar.f2610c = i3;
        boolean z2 = this.f1600j;
        if (z2 && this.J == 0) {
            gVar.f2613f = 0;
            gVar.f2614g = 8192;
        } else {
            gVar.f2613f = i3;
            gVar.f2614g = i3;
        }
        if (z2 && this.f1597I == 0) {
            gVar.f2611d = 0;
            gVar.f2612e = 8192;
        } else {
            gVar.f2611d = i2;
            gVar.f2612e = i2;
        }
        if (this.f1599i.compareAndSet(false, true)) {
            return;
        }
        e();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ByteBuffer byteBuffer;
        if (!c()) {
            return super.onTouchEvent(motionEvent);
        }
        requestUnbufferedDispatch(motionEvent);
        C0119a c0119a = this.f1614y;
        Matrix matrix = C0119a.f1535f;
        c0119a.getClass();
        int actionMasked = motionEvent.getActionMasked();
        int iB = C0119a.b(motionEvent.getActionMasked());
        char c2 = 5;
        boolean z2 = actionMasked == 0 || actionMasked == 5;
        boolean z3 = !z2 && (actionMasked == 1 || actionMasked == 6);
        int toolType = motionEvent.getToolType(motionEvent.getActionIndex());
        if (toolType == 1) {
            c2 = 0;
        } else if (toolType == 2) {
            c2 = 2;
        } else if (toolType == 3) {
            c2 = 1;
        } else if (toolType == 4) {
            c2 = 3;
        }
        int i2 = (z3 && c2 == 0) ? 1 : 0;
        int pointerCount = motionEvent.getPointerCount();
        ByteBuffer byteBufferAllocateDirect = ByteBuffer.allocateDirect((pointerCount + i2) * 288);
        byteBufferAllocateDirect.order(ByteOrder.LITTLE_ENDIAN);
        if (z2) {
            byteBuffer = byteBufferAllocateDirect;
            c0119a.a(motionEvent, motionEvent.getActionIndex(), iB, 0, matrix, byteBuffer, null);
        } else {
            byteBuffer = byteBufferAllocateDirect;
            if (z3) {
                for (int i3 = 0; i3 < pointerCount; i3++) {
                    if (i3 != motionEvent.getActionIndex() && motionEvent.getToolType(i3) == 1) {
                        c0119a.a(motionEvent, i3, 5, 1, matrix, byteBuffer, null);
                    }
                }
                c0119a.a(motionEvent, motionEvent.getActionIndex(), iB, 0, matrix, byteBuffer, null);
                if (i2 != 0) {
                    c0119a.a(motionEvent, motionEvent.getActionIndex(), 2, 0, matrix, byteBuffer, null);
                }
            } else {
                for (int i4 = 0; i4 < pointerCount; i4++) {
                    c0119a.a(motionEvent, i4, iB, (pointerCount << 8) | 2, matrix, byteBuffer, null);
                }
            }
        }
        if (byteBuffer.position() % 288 != 0) {
            throw new AssertionError("Packet position is not on field boundary");
        }
        c0119a.f1536a.f2630a.dispatchPointerDataPacket(byteBuffer, byteBuffer.position());
        return true;
    }

    public void setDelegate(t tVar) {
        this.f1598K = tVar;
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        View view = this.f1604n;
        if (view instanceof k) {
            ((k) view).setVisibility(i2);
        }
    }

    /* JADX WARN: Type inference failed for: r9v1, types: [java.lang.Object, java.util.List] */
    public void setWindowInfoListenerDisplayFeatures(d0.j jVar) {
        C0180b c0180b = C0180b.f2440l;
        ?? r9 = jVar.f2464a;
        ArrayList arrayList = new ArrayList();
        for (C0181c c0181c : r9) {
            c0181c.f2447a.a().toString();
            a0.b bVar = c0181c.f2447a;
            int i2 = 2;
            int i3 = ((bVar.f1640c - bVar.f1638a == 0 || bVar.f1641d - bVar.f1639b == 0) ? C0180b.f2439k : c0180b) == c0180b ? 3 : 2;
            C0180b c0180b2 = c0181c.f2449c;
            if (c0180b2 != C0180b.f2441m) {
                i2 = c0180b2 == C0180b.f2442n ? 3 : 1;
            }
            arrayList.add(new io.flutter.embedding.engine.renderer.a(bVar.a(), i3, i2));
        }
        ArrayList arrayList2 = this.f1591C.f2628u;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        e();
    }

    public r(AbstractActivityC0122d abstractActivityC0122d, m mVar) {
        super(abstractActivityC0122d, null);
        this.f1599i = new AtomicBoolean(true);
        this.f1600j = false;
        this.f1606p = new HashSet();
        this.f1609s = new HashSet();
        this.f1591C = new io.flutter.embedding.engine.renderer.g();
        this.f1592D = new D.i(18, this);
        this.f1593E = new G.a(this, new Handler(Looper.getMainLooper()), 1);
        this.f1594F = new p(this);
        this.f1595G = new C0123e(1, this);
        this.f1598K = new t();
        this.f1602l = mVar;
        this.f1604n = mVar;
        b();
    }
}
