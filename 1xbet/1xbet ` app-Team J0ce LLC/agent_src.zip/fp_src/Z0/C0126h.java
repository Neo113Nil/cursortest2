package Z0;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import android.util.Log;
import android.util.SparseArray;
import b1.C0160a;
import g1.InterfaceC0207b;
import h1.InterfaceC0210a;
import io.flutter.embedding.engine.FlutterJNI;
import j1.C0233d;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import o1.C0321a;

/* renamed from: Z0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0126h {

    /* renamed from: a, reason: collision with root package name */
    public AbstractActivityC0122d f1552a;

    /* renamed from: b, reason: collision with root package name */
    public a1.c f1553b;

    /* renamed from: c, reason: collision with root package name */
    public r f1554c;

    /* renamed from: d, reason: collision with root package name */
    public io.flutter.plugin.platform.e f1555d;

    /* renamed from: e, reason: collision with root package name */
    public C0321a f1556e;

    /* renamed from: f, reason: collision with root package name */
    public ViewTreeObserverOnPreDrawListenerC0124f f1557f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1558g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1559h;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1561j;

    /* renamed from: k, reason: collision with root package name */
    public Integer f1562k;

    /* renamed from: l, reason: collision with root package name */
    public final C0123e f1563l = new C0123e(0, this);

    /* renamed from: i, reason: collision with root package name */
    public boolean f1560i = false;

    public C0126h(AbstractActivityC0122d abstractActivityC0122d) {
        this.f1552a = abstractActivityC0122d;
    }

    public final void a(a1.g gVar) {
        String strC = this.f1552a.c();
        if (strC == null || strC.isEmpty()) {
            strC = (String) ((e1.d) N.f.H().f1050j).f2491d.f117c;
        }
        C0160a c0160a = new C0160a(strC, this.f1552a.f());
        String strG = this.f1552a.g();
        if (strG == null) {
            AbstractActivityC0122d abstractActivityC0122d = this.f1552a;
            abstractActivityC0122d.getClass();
            strG = d(abstractActivityC0122d.getIntent());
            if (strG == null) {
                strG = "/";
            }
        }
        gVar.f1702b = c0160a;
        gVar.f1703c = strG;
        gVar.f1704d = (List) this.f1552a.getIntent().getSerializableExtra("dart_entrypoint_args");
    }

    public final void b() {
        if (this.f1552a.j()) {
            throw new AssertionError("The internal FlutterEngine created by " + this.f1552a + " has been attached to by another activity. To persist a FlutterEngine beyond the ownership of this activity, explicitly create a FlutterEngine");
        }
        AbstractActivityC0122d abstractActivityC0122d = this.f1552a;
        abstractActivityC0122d.getClass();
        Log.w("FlutterActivity", "FlutterActivity " + abstractActivityC0122d + " connection to the engine " + abstractActivityC0122d.f1545j.f1553b + " evicted by another attaching activity");
        C0126h c0126h = abstractActivityC0122d.f1545j;
        if (c0126h != null) {
            c0126h.e();
            abstractActivityC0122d.f1545j.f();
        }
    }

    public final void c() {
        if (this.f1552a == null) {
            throw new IllegalStateException("Cannot execute method on a destroyed FlutterActivityAndFragmentDelegate.");
        }
    }

    public final String d(Intent intent) {
        boolean z2;
        Uri data;
        AbstractActivityC0122d abstractActivityC0122d = this.f1552a;
        abstractActivityC0122d.getClass();
        try {
            Bundle bundleH = abstractActivityC0122d.h();
            z2 = (bundleH == null || !bundleH.containsKey("flutter_deeplinking_enabled")) ? true : bundleH.getBoolean("flutter_deeplinking_enabled");
        } catch (PackageManager.NameNotFoundException unused) {
            z2 = false;
        }
        if (!z2 || (data = intent.getData()) == null) {
            return null;
        }
        return data.toString();
    }

    public final void e() {
        c();
        if (this.f1557f != null) {
            this.f1554c.getViewTreeObserver().removeOnPreDrawListener(this.f1557f);
            this.f1557f = null;
        }
        r rVar = this.f1554c;
        if (rVar != null) {
            rVar.a();
            r rVar2 = this.f1554c;
            rVar2.f1606p.remove(this.f1563l);
        }
    }

    public final void f() {
        if (this.f1561j) {
            c();
            this.f1552a.getClass();
            this.f1552a.getClass();
            AbstractActivityC0122d abstractActivityC0122d = this.f1552a;
            abstractActivityC0122d.getClass();
            if (abstractActivityC0122d.isChangingConfigurations()) {
                a1.e eVar = this.f1553b.f1666d;
                if (eVar.f()) {
                    r1.a.b("FlutterEngineConnectionRegistry#detachFromActivityForConfigChanges");
                    try {
                        eVar.f1698g = true;
                        Iterator it = eVar.f1695d.values().iterator();
                        while (it.hasNext()) {
                            ((InterfaceC0210a) it.next()).onDetachedFromActivityForConfigChanges();
                        }
                        eVar.d();
                        Trace.endSection();
                    } finally {
                    }
                } else {
                    Log.e("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
                }
            } else {
                this.f1553b.f1666d.c();
            }
            io.flutter.plugin.platform.e eVar2 = this.f1555d;
            if (eVar2 != null) {
                ((E0.f) eVar2.f2702c).f134k = null;
                this.f1555d = null;
            }
            C0321a c0321a = this.f1556e;
            if (c0321a != null) {
                c0321a.f3762c.f3301j = null;
                c0321a.f3760a = null;
                this.f1556e = null;
            }
            this.f1552a.getClass();
            a1.c cVar = this.f1553b;
            if (cVar != null) {
                C0233d c0233d = cVar.f1669g;
                c0233d.a(1, c0233d.f3306c);
            }
            if (this.f1552a.j()) {
                a1.c cVar2 = this.f1553b;
                FlutterJNI flutterJNI = cVar2.f1663a;
                Iterator it2 = cVar2.f1684v.iterator();
                while (it2.hasNext()) {
                    ((a1.b) it2.next()).a();
                }
                a1.e eVar3 = cVar2.f1666d;
                eVar3.e();
                HashMap map = eVar3.f1692a;
                Iterator it3 = new HashSet(map.keySet()).iterator();
                while (it3.hasNext()) {
                    Class cls = (Class) it3.next();
                    InterfaceC0207b interfaceC0207b = (InterfaceC0207b) map.get(cls);
                    if (interfaceC0207b != null) {
                        r1.a.b("FlutterEngineConnectionRegistry#remove ".concat(cls.getSimpleName()));
                        try {
                            if (interfaceC0207b instanceof InterfaceC0210a) {
                                if (eVar3.f()) {
                                    ((InterfaceC0210a) interfaceC0207b).onDetachedFromActivity();
                                }
                                eVar3.f1695d.remove(cls);
                            }
                            interfaceC0207b.onDetachedFromEngine(eVar3.f1694c);
                            map.remove(cls);
                            Trace.endSection();
                        } finally {
                        }
                    }
                }
                map.clear();
                io.flutter.plugin.platform.k kVar = cVar2.f1681s;
                SparseArray sparseArray = kVar.f2731s;
                while (sparseArray.size() > 0) {
                    kVar.f2720C.t(sparseArray.keyAt(0));
                }
                io.flutter.plugin.platform.j jVar = cVar2.f1682t;
                SparseArray sparseArray2 = jVar.f2711o;
                while (sparseArray2.size() > 0) {
                    jVar.f2717u.t(sparseArray2.keyAt(0));
                }
                cVar2.f1665c.f2343i.setPlatformMessageHandler(null);
                flutterJNI.removeEngineLifecycleListener(cVar2.x);
                flutterJNI.setDeferredComponentManager(null);
                flutterJNI.detachFromNativeAndReleaseResources();
                N.f.H().getClass();
                a1.c.f1662z.remove(Long.valueOf(cVar2.f1685w));
                if (this.f1552a.e() != null) {
                    if (a1.i.f1709c == null) {
                        a1.i.f1709c = new a1.i(1);
                    }
                    a1.i iVar = a1.i.f1709c;
                    iVar.f1710a.remove(this.f1552a.e());
                }
                this.f1553b = null;
            }
            this.f1561j = false;
        }
    }
}
