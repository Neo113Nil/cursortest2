package Z0;

import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import io.flutter.embedding.engine.FlutterJNI;
import w0.AbstractC0390a;

/* loaded from: classes.dex */
public final class m extends TextureView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: i, reason: collision with root package name */
    public boolean f1578i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1579j;

    /* renamed from: k, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1580k;

    /* renamed from: l, reason: collision with root package name */
    public Surface f1581l;

    /* renamed from: m, reason: collision with root package name */
    public final boolean f1582m;

    public m(AbstractActivityC0122d abstractActivityC0122d) {
        super(abstractActivityC0122d, null);
        this.f1578i = false;
        this.f1579j = false;
        this.f1582m = false;
        setSurfaceTextureListener(new l(this));
        this.f1582m = AbstractC0390a.B(getContext());
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a() {
        if (this.f1580k == null) {
            Log.w("FlutterTextureView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1580k;
            if (hVar == null) {
                throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            Surface surface = this.f1581l;
            if (surface != null) {
                surface.release();
                this.f1581l = null;
            }
        }
        this.f1580k = null;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1580k == null) {
            Log.w("FlutterTextureView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (this.f1578i) {
            e();
        }
        this.f1579j = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1580k;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1580k = hVar;
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1580k == null) {
            Log.w("FlutterTextureView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1579j = true;
        }
    }

    public final void e() {
        if (this.f1580k == null || getSurfaceTexture() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getSurfaceTexture() are non-null.");
        }
        Surface surface = this.f1581l;
        if (surface != null) {
            surface.release();
            this.f1581l = null;
        }
        Surface surface2 = new Surface(getSurfaceTexture());
        this.f1581l = surface2;
        io.flutter.embedding.engine.renderer.h hVar = this.f1580k;
        boolean z2 = this.f1579j;
        FlutterJNI flutterJNI = hVar.f2630a;
        if (!z2) {
            hVar.e();
        }
        hVar.f2631b = surface2;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface2);
        } else {
            flutterJNI.onSurfaceCreated(surface2);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1580k;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1582m) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        setMeasuredDimension(Math.max(View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), Math.max(View.MeasureSpec.getSize(i3), View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }

    public void setRenderSurface(Surface surface) {
        this.f1581l = surface;
    }
}
