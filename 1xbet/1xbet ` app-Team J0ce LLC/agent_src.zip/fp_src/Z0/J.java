package Z0;

import android.os.Build;
import android.view.SurfaceHolder;

/* loaded from: classes.dex */
public final class J implements SurfaceHolder.Callback2 {

    /* renamed from: a, reason: collision with root package name */
    public final k f1530a;

    /* renamed from: b, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1531b;

    /* renamed from: c, reason: collision with root package name */
    public final SurfaceHolderCallbackC0128j f1532c;

    /* renamed from: d, reason: collision with root package name */
    public final C0123e f1533d = new C0123e(2, this);

    /* renamed from: e, reason: collision with root package name */
    public final I f1534e;

    public J(SurfaceHolderCallbackC0128j surfaceHolderCallbackC0128j, k kVar, io.flutter.embedding.engine.renderer.h hVar) {
        boolean z2 = Build.VERSION.SDK_INT < 26;
        this.f1534e = z2 ? new I(this, 1) : new I(this, 0);
        this.f1532c = surfaceHolderCallbackC0128j;
        this.f1531b = hVar;
        this.f1530a = kVar;
        if (z2) {
            kVar.setAlpha(0.0f);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        SurfaceHolderCallbackC0128j surfaceHolderCallbackC0128j = this.f1532c;
        if (surfaceHolderCallbackC0128j != null) {
            surfaceHolderCallbackC0128j.surfaceChanged(surfaceHolder, i2, i3, i4);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        SurfaceHolderCallbackC0128j surfaceHolderCallbackC0128j = this.f1532c;
        if (surfaceHolderCallbackC0128j != null) {
            surfaceHolderCallbackC0128j.surfaceCreated(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        SurfaceHolderCallbackC0128j surfaceHolderCallbackC0128j = this.f1532c;
        if (surfaceHolderCallbackC0128j != null) {
            surfaceHolderCallbackC0128j.surfaceDestroyed(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeededAsync(SurfaceHolder surfaceHolder, Runnable runnable) {
        io.flutter.embedding.engine.renderer.h hVar = this.f1531b;
        if (hVar == null) {
            return;
        }
        hVar.a(new H(this, runnable));
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeeded(SurfaceHolder surfaceHolder) {
    }
}
