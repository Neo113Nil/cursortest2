package Z0;

import java.util.concurrent.atomic.AtomicLong;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: a, reason: collision with root package name */
    public static final AtomicLong f1525a = new AtomicLong(0);
}
