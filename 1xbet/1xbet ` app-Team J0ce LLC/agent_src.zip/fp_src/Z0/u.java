package Z0;

/* loaded from: classes.dex */
public final class u {

    /* renamed from: a, reason: collision with root package name */
    public long f1616a;

    /* renamed from: b, reason: collision with root package name */
    public int f1617b;

    /* renamed from: c, reason: collision with root package name */
    public long f1618c;

    /* renamed from: d, reason: collision with root package name */
    public long f1619d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1620e;

    /* renamed from: f, reason: collision with root package name */
    public int f1621f;

    /* renamed from: g, reason: collision with root package name */
    public String f1622g;
}
