package Z0;

/* loaded from: classes.dex */
public final class I {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1528a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ J f1529b;

    public /* synthetic */ I(J j2, int i2) {
        this.f1528a = i2;
        this.f1529b = j2;
    }

    private final void a() {
    }
}
