package Z0;

import android.os.Build;
import java.util.Iterator;

/* renamed from: Z0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0123e implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1548a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1549b;

    public /* synthetic */ C0123e(int i2, Object obj) {
        this.f1548a = i2;
        this.f1549b = obj;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
        switch (this.f1548a) {
            case 0:
                C0126h c0126h = (C0126h) this.f1549b;
                c0126h.f1552a.getClass();
                c0126h.f1559h = false;
                break;
            case 1:
                r rVar = (r) this.f1549b;
                rVar.f1607q = false;
                Iterator it = rVar.f1606p.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).a();
                }
                break;
            case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1549b).f2632c = false;
                break;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        switch (this.f1548a) {
            case 0:
                C0126h c0126h = (C0126h) this.f1549b;
                AbstractActivityC0122d abstractActivityC0122d = c0126h.f1552a;
                if (Build.VERSION.SDK_INT >= 29) {
                    abstractActivityC0122d.reportFullyDrawn();
                } else {
                    abstractActivityC0122d.getClass();
                }
                c0126h.f1559h = true;
                c0126h.f1560i = true;
                break;
            case 1:
                r rVar = (r) this.f1549b;
                rVar.f1607q = true;
                Iterator it = rVar.f1606p.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).b();
                }
                break;
            case K.k.FLOAT_FIELD_NUMBER /* 2 */:
                J j2 = (J) this.f1549b;
                j2.f1530a.setAlpha(1.0f);
                io.flutter.embedding.engine.renderer.h hVar = j2.f1531b;
                if (hVar != null) {
                    hVar.c(this);
                    break;
                }
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1549b).f2632c = true;
                break;
        }
    }

    private final void c() {
    }
}
