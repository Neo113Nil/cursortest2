package Z0;

import android.graphics.fonts.Font;

/* loaded from: classes.dex */
public abstract /* synthetic */ class n {
    public static /* synthetic */ Font.Builder d(Font font) {
        return new Font.Builder(font);
    }
}
