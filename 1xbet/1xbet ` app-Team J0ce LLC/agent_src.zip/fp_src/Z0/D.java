package Z0;

/* loaded from: classes.dex */
public final class D {

    /* renamed from: a, reason: collision with root package name */
    public final long f1519a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1520b;

    public D(long j2, long j3) {
        this.f1519a = j2;
        this.f1520b = j3;
    }
}
