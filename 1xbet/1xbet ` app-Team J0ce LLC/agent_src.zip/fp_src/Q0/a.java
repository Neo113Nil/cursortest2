package Q0;

import D.i;
import E0.f;
import R0.b;
import S0.c;
import T0.C0116c;
import T0.C0118e;
import T0.InterfaceC0117d;
import T0.h;
import T0.j;
import T0.k;
import T0.m;
import T0.n;
import T0.t;
import android.content.Context;
import android.net.ConnectivityManager;
import g1.C0206a;
import g1.InterfaceC0207b;
import java.util.Iterator;
import java.util.LinkedHashMap;
import k1.InterfaceC0290g;
import k1.x;

/* loaded from: classes.dex */
public final class a implements InterfaceC0207b {

    /* renamed from: i, reason: collision with root package name */
    public f f1189i;

    /* renamed from: j, reason: collision with root package name */
    public f f1190j;

    /* renamed from: k, reason: collision with root package name */
    public b f1191k;

    /* renamed from: l, reason: collision with root package name */
    public b f1192l;

    @Override // g1.InterfaceC0207b
    public final void onAttachedToEngine(C0206a c0206a) {
        i iVar;
        C1.i.e(c0206a, "binding");
        Context context = c0206a.f2552a;
        C1.i.d(context, "getApplicationContext(...)");
        InterfaceC0290g interfaceC0290g = c0206a.f2554c;
        C1.i.d(interfaceC0290g, "getBinaryMessenger(...)");
        C0116c.a(InterfaceC0117d.f1418a, interfaceC0290g, new R0.a(context, 0));
        C0118e.a(T0.f.f1421b, interfaceC0290g, new R0.a(context, 1));
        N.f fVar = new N.f(context, 2);
        h.a(T0.i.f1432c, interfaceC0290g, new i(10, fVar));
        f fVar2 = new f(fVar);
        new N.f(interfaceC0290g, "dev.flutter.pigeon.clarity_flutter.ClarityEvents.connectivityChanged", t.f1454a, 12).P(new i(16, fVar2));
        this.f1189i = fVar2;
        try {
            iVar = new i(12, c0206a.f2553b);
        } catch (Throwable unused) {
            iVar = null;
        }
        if (iVar != null) {
            j.a(k.f1435d, interfaceC0290g, new i(11, new i(13, iVar)));
            f fVar3 = new f(context, iVar);
            this.f1190j = fVar3;
            m.a(n.f1440e, interfaceC0290g, new b(fVar3, 0));
            b bVar = new b(fVar3, 2);
            i iVar2 = new i(16, bVar);
            x xVar = t.f1454a;
            new N.f(interfaceC0290g, "dev.flutter.pigeon.clarity_flutter.ClarityEvents.webViewMessage", xVar, 12).P(iVar2);
            this.f1191k = bVar;
            b bVar2 = new b(fVar3, 1);
            new N.f(interfaceC0290g, "dev.flutter.pigeon.clarity_flutter.ClarityEvents.webViewError", xVar, 12).P(new i(16, bVar2));
            this.f1192l = bVar2;
        }
    }

    @Override // g1.InterfaceC0207b
    public final void onDetachedFromEngine(C0206a c0206a) {
        C1.i.e(c0206a, "binding");
        C0116c c0116c = InterfaceC0117d.f1418a;
        InterfaceC0290g interfaceC0290g = c0206a.f2554c;
        C1.i.d(interfaceC0290g, "getBinaryMessenger(...)");
        C0116c.a(c0116c, interfaceC0290g, null);
        C0118e c0118e = T0.f.f1421b;
        InterfaceC0290g interfaceC0290g2 = c0206a.f2554c;
        C1.i.d(interfaceC0290g2, "getBinaryMessenger(...)");
        C0118e.a(c0118e, interfaceC0290g2, null);
        h hVar = T0.i.f1432c;
        InterfaceC0290g interfaceC0290g3 = c0206a.f2554c;
        C1.i.d(interfaceC0290g3, "getBinaryMessenger(...)");
        h.a(hVar, interfaceC0290g3, null);
        j jVar = k.f1435d;
        InterfaceC0290g interfaceC0290g4 = c0206a.f2554c;
        C1.i.d(interfaceC0290g4, "getBinaryMessenger(...)");
        j.a(jVar, interfaceC0290g4, null);
        m mVar = n.f1440e;
        InterfaceC0290g interfaceC0290g5 = c0206a.f2554c;
        C1.i.d(interfaceC0290g5, "getBinaryMessenger(...)");
        m.a(mVar, interfaceC0290g5, null);
        f fVar = this.f1189i;
        if (fVar != null) {
            N.f fVar2 = (N.f) fVar.f133j;
            c cVar = (c) fVar2.f1052l;
            if (cVar != null) {
                try {
                    ((ConnectivityManager) fVar2.f1050j).unregisterNetworkCallback(cVar);
                } catch (Throwable unused) {
                }
                fVar2.f1052l = null;
            }
        }
        this.f1189i = null;
        this.f1191k = null;
        this.f1192l = null;
        f fVar3 = this.f1190j;
        if (fVar3 != null) {
            Iterator it = ((LinkedHashMap) fVar3.f134k).values().iterator();
            if (it.hasNext()) {
                if (it.next() != null) {
                    throw new ClassCastException();
                }
                C1.i.e(null, "entry");
                throw null;
            }
            ((LinkedHashMap) fVar3.f134k).clear();
        }
        this.f1190j = null;
    }
}
