package io.flutter.plugins;

import Q0.a;
import Q1.b;
import X0.d;
import a1.c;
import android.util.Log;
import com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin;
import com.github.dart_lang.jni.JniPlugin;
import com.github.dart_lang.jni_flutter.JniFlutterPlugin;
import j0.C0228a;
import p1.C0334I;
import q1.f;

/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(c cVar) {
        try {
            cVar.f1666d.a(new b());
        } catch (Exception e2) {
            Log.e(TAG, "Error registering plugin bolide_antelope, toucan.river.StoneConifer", e2);
        }
        try {
            cVar.f1666d.a(new a());
        } catch (Exception e3) {
            Log.e(TAG, "Error registering plugin clarity_flutter, com.microsoft.clarity.ClarityFlutterPlugin", e3);
        }
        try {
            cVar.f1666d.a(new FlutterLocalNotificationsPlugin());
        } catch (Exception e4) {
            Log.e(TAG, "Error registering plugin flutter_local_notifications, com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin", e4);
        }
        try {
            cVar.f1666d.a(new V0.c());
        } catch (Exception e5) {
            Log.e(TAG, "Error registering plugin in_app_review, dev.britannio.in_app_review.InAppReviewPlugin", e5);
        }
        try {
            cVar.f1666d.a(new JniPlugin());
        } catch (Exception e6) {
            Log.e(TAG, "Error registering plugin jni, com.github.dart_lang.jni.JniPlugin", e6);
        }
        try {
            cVar.f1666d.a(new JniFlutterPlugin());
        } catch (Exception e7) {
            Log.e(TAG, "Error registering plugin jni_flutter, com.github.dart_lang.jni_flutter.JniFlutterPlugin", e7);
        }
        try {
            cVar.f1666d.a(new W0.a());
        } catch (Exception e8) {
            Log.e(TAG, "Error registering plugin package_info_plus, dev.fluttercommunity.plus.packageinfo.PackageInfoPlugin", e8);
        }
        try {
            cVar.f1666d.a(new C0228a());
        } catch (Exception e9) {
            Log.e(TAG, "Error registering plugin permission_handler_android, com.baseflow.permissionhandler.PermissionHandlerPlugin", e9);
        }
        try {
            cVar.f1666d.a(new d());
        } catch (Exception e10) {
            Log.e(TAG, "Error registering plugin share_plus, dev.fluttercommunity.plus.share.SharePlusPlugin", e10);
        }
        try {
            cVar.f1666d.a(new C0334I());
        } catch (Exception e11) {
            Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e11);
        }
        try {
            cVar.f1666d.a(new f());
        } catch (Exception e12) {
            Log.e(TAG, "Error registering plugin url_launcher_android, io.flutter.plugins.urllauncher.UrlLauncherPlugin", e12);
        }
    }
}
