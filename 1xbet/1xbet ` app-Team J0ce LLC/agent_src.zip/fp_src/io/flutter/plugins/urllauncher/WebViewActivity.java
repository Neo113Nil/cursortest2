package io.flutter.plugins.urllauncher;

import C.AbstractC0007g;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import q1.g;
import q1.h;
import q1.j;

/* loaded from: classes.dex */
public class WebViewActivity extends Activity {

    /* renamed from: m, reason: collision with root package name */
    public static final /* synthetic */ int f2748m = 0;

    /* renamed from: k, reason: collision with root package name */
    public WebView f2751k;

    /* renamed from: i, reason: collision with root package name */
    public final g f2749i = new g(this);

    /* renamed from: j, reason: collision with root package name */
    public final h f2750j = new h();

    /* renamed from: l, reason: collision with root package name */
    public final IntentFilter f2752l = new IntentFilter("close action");

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        Map<String, String> map;
        super.onCreate(bundle);
        WebView webView = new WebView(this);
        this.f2751k = webView;
        setContentView(webView);
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("url");
        boolean booleanExtra = intent.getBooleanExtra("enableJavaScript", false);
        boolean booleanExtra2 = intent.getBooleanExtra("enableDomStorage", false);
        Bundle bundleExtra = intent.getBundleExtra("com.android.browser.headers");
        if (bundleExtra == null) {
            map = Collections.EMPTY_MAP;
        } else {
            HashMap map2 = new HashMap();
            for (String str : bundleExtra.keySet()) {
                map2.put(str, bundleExtra.getString(str));
            }
            map = map2;
        }
        this.f2751k.loadUrl(stringExtra, map);
        this.f2751k.getSettings().setJavaScriptEnabled(booleanExtra);
        this.f2751k.getSettings().setDomStorageEnabled(booleanExtra2);
        this.f2751k.setWebViewClient(this.f2750j);
        this.f2751k.getSettings().setSupportMultipleWindows(true);
        this.f2751k.setWebChromeClient(new j(this));
        int i2 = Build.VERSION.SDK_INT;
        BroadcastReceiver broadcastReceiver = this.f2749i;
        IntentFilter intentFilter = this.f2752l;
        if (i2 >= 33) {
            AbstractC0007g.h(this, broadcastReceiver, intentFilter);
        } else if (i2 >= 26) {
            AbstractC0007g.g(this, broadcastReceiver, intentFilter);
        } else {
            registerReceiver(broadcastReceiver, intentFilter, null, null);
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.f2749i);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 != 4 || !this.f2751k.canGoBack()) {
            return super.onKeyDown(i2, keyEvent);
        }
        this.f2751k.goBack();
        return true;
    }
}
