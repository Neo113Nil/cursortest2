package R0;

import C1.i;
import G1.h;
import T0.InterfaceC0117d;
import T0.f;
import T0.q;
import T0.u;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import java.util.Locale;

/* loaded from: classes.dex */
public final class a implements InterfaceC0117d, f {

    /* renamed from: c, reason: collision with root package name */
    public final Context f1247c;

    public q a() {
        long j2;
        Context context = this.f1247c;
        i.e(context, "context");
        try {
            Object systemService = context.getSystemService("activity");
            ActivityManager activityManager = systemService instanceof ActivityManager ? (ActivityManager) systemService : null;
            if (activityManager != null) {
                ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
                activityManager.getMemoryInfo(memoryInfo);
                j2 = memoryInfo.totalMem / 1048576;
            } else {
                j2 = 0;
            }
            return new q(Build.BRAND, null, j2);
        } catch (Throwable unused) {
            return new q(null, null, 0L);
        }
    }

    public String b() {
        Object objInvoke;
        String string;
        Context context = this.f1247c;
        i.e(context, "context");
        try {
            if ((Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("com.google.android.gms.permission.AD_ID") == 0) && (objInvoke = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient").getDeclaredMethod("getAdvertisingIdInfo", Context.class).invoke(null, context)) != null) {
                Class<?> cls = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
                Object objInvoke2 = cls.getDeclaredMethod("isLimitAdTrackingEnabled", null).invoke(objInvoke, null);
                if (!i.a(objInvoke2 instanceof Boolean ? (Boolean) objInvoke2 : null, Boolean.TRUE)) {
                    Object objInvoke3 = cls.getDeclaredMethod("getId", null).invoke(objInvoke, null);
                    String str = objInvoke3 instanceof String ? (String) objInvoke3 : null;
                    if (str != null) {
                        int length = str.length() - 1;
                        int i2 = 0;
                        boolean z2 = false;
                        while (i2 <= length) {
                            char cCharAt = str.charAt(!z2 ? i2 : length);
                            boolean z3 = Character.isWhitespace(cCharAt) || Character.isSpaceChar(cCharAt);
                            if (z2) {
                                if (!z3) {
                                    break;
                                }
                                length--;
                            } else if (z3) {
                                i2++;
                            } else {
                                z2 = true;
                            }
                        }
                        string = str.subSequence(i2, length + 1).toString();
                    } else {
                        string = null;
                    }
                    if (string == null) {
                        string = "";
                    }
                    if (string.length() != 0) {
                        String lowerCase = h.O(string, "-", "").toLowerCase(Locale.ROOT);
                        i.d(lowerCase, "toLowerCase(...)");
                        if (lowerCase.length() > 0) {
                            for (int i3 = 0; i3 < lowerCase.length(); i3++) {
                                if (lowerCase.charAt(i3) == '0') {
                                }
                            }
                        }
                        return string;
                    }
                }
            }
        } catch (Throwable unused) {
        }
        return null;
    }

    public u c() {
        Context context = this.f1247c;
        i.e(context, "context");
        try {
            String packageName = context.getPackageName();
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            String strValueOf = Build.VERSION.SDK_INT >= 28 ? String.valueOf(packageInfo.getLongVersionCode()) : String.valueOf(packageInfo.versionCode);
            i.b(packageName);
            String str = packageInfo.versionName;
            if (str == null) {
                str = "";
            }
            return new u(packageName, str, strValueOf);
        } catch (Throwable unused) {
            return new u("", "", "");
        }
    }

    public a(Context context, int i2) {
        switch (i2) {
            case 1:
                i.e(context, "context");
                this.f1247c = context;
                break;
            default:
                i.e(context, "context");
                this.f1247c = context;
                break;
        }
    }
}
