package R0;

import B1.l;
import D.i;
import E0.f;
import android.os.Handler;
import j1.C0241l;
import java.util.List;
import s1.g;

/* loaded from: classes.dex */
public final /* synthetic */ class c implements l {

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f1250i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f1251j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ Object f1252k;

    public /* synthetic */ c(int i2, Object obj, Object obj2) {
        this.f1250i = i2;
        this.f1251j = obj;
        this.f1252k = obj2;
    }

    @Override // B1.l
    public final Object g(Object obj) {
        switch (this.f1250i) {
            case 0:
                f fVar = (f) this.f1251j;
                i iVar = (i) this.f1252k;
                List list = (List) obj;
                C1.i.e(list, "types");
                ((Handler) fVar.f134k).post(new d(0, iVar, list));
                break;
            default:
                f fVar2 = (f) this.f1251j;
                C0241l c0241l = (C0241l) this.f1252k;
                Object obj2 = ((s1.d) obj).f4221i;
                Throwable thA = s1.d.a(obj2);
                if (thA == null) {
                } else {
                    X0.e eVar = (X0.e) fVar2.f134k;
                    eVar.f1505j.set(true);
                    eVar.f1504i = null;
                    c0241l.b("Share failed", thA.getMessage(), thA);
                }
                break;
        }
        return g.f4226a;
    }
}
