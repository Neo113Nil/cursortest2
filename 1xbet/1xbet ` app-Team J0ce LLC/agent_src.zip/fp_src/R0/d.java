package R0;

import D.i;
import T0.o;
import android.graphics.Typeface;
import j1.C0237h;
import java.util.List;
import k1.C0291h;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f1253i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f1254j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ Object f1255k;

    public /* synthetic */ d(int i2, Object obj, Object obj2) {
        this.f1253i = i2;
        this.f1254j = obj;
        this.f1255k = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1253i) {
            case 0:
                i iVar = (i) this.f1254j;
                ((C0291h) iVar.f102j).a(new o((List) this.f1255k));
                break;
            default:
                ((C0237h) this.f1254j).b((Typeface) this.f1255k);
                break;
        }
    }
}
