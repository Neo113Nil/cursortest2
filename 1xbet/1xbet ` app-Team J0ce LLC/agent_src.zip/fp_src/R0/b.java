package R0;

import D.i;
import E0.f;
import T0.B;
import T0.D;
import T0.n;
import T0.s;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import k1.C0291h;
import s1.g;
import t1.l;

/* loaded from: classes.dex */
public final class b implements n, s {

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f1248i;

    /* renamed from: j, reason: collision with root package name */
    public final f f1249j;

    public /* synthetic */ b(f fVar, int i2) {
        this.f1248i = i2;
        this.f1249j = fVar;
    }

    public List a() {
        LinkedHashMap linkedHashMap = (LinkedHashMap) this.f1249j.f134k;
        if (linkedHashMap.isEmpty()) {
            return l.f4255i;
        }
        ArrayList arrayList = new ArrayList(linkedHashMap.size());
        Iterator it = linkedHashMap.entrySet().iterator();
        if (!it.hasNext()) {
            return arrayList;
        }
        Map.Entry entry = (Map.Entry) it.next();
        ((Number) entry.getKey()).intValue();
        entry.getValue().getClass();
        throw new ClassCastException();
    }

    @Override // T0.s
    public void onCancel() {
        int i2 = this.f1248i;
    }

    @Override // T0.s
    public void p(final i iVar) {
        switch (this.f1248i) {
            case 1:
                final int i2 = 0;
                new B1.l() { // from class: R0.e
                    @Override // B1.l
                    public final Object g(Object obj) {
                        switch (i2) {
                            case 0:
                                B b2 = (B) obj;
                                C1.i.e(b2, "data");
                                ((C0291h) iVar.f102j).a(b2);
                                break;
                            default:
                                D d2 = (D) obj;
                                C1.i.e(d2, "data");
                                ((C0291h) iVar.f102j).a(d2);
                                break;
                        }
                        return g.f4226a;
                    }
                };
                break;
            default:
                final int i3 = 1;
                new B1.l() { // from class: R0.e
                    @Override // B1.l
                    public final Object g(Object obj) {
                        switch (i3) {
                            case 0:
                                B b2 = (B) obj;
                                C1.i.e(b2, "data");
                                ((C0291h) iVar.f102j).a(b2);
                                break;
                            default:
                                D d2 = (D) obj;
                                C1.i.e(d2, "data");
                                ((C0291h) iVar.f102j).a(d2);
                                break;
                        }
                        return g.f4226a;
                    }
                };
                break;
        }
    }
}
