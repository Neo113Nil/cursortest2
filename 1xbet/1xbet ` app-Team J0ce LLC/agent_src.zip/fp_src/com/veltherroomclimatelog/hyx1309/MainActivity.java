package com.veltherroomclimatelog.hyx1309;

import Z0.AbstractActivityC0122d;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0122d {
}
