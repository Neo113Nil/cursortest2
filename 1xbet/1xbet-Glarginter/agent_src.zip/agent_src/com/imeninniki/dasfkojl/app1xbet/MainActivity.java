package com.imeninniki.dasfkojl.app1xbet;

import a.a0;
import a.j0;
import a.k0;
import a.p;
import a.q;
import a.r;
import a.s;
import a.u;
import a.w;
import a.x;
import a.y;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.imeninniki.dasfkojl.app1xbet.MainActivity;
import com.imeninniki.dasfkojl.app1xbet.MainActivity2;
import com.imeninniki.dasfkojl.app1xbet.R;
import f3.a;
import g.i;
import g3.d;
import j2.b0;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.WeakHashMap;
import l0.f0;
import l0.n0;
import n3.l;
import r3.o;
import s2.b;
import t2.c;
import v3.f;
import z3.n;

/* compiled from: r8-map-id-63b0f5acf443110f44e3cbfc726f3470d68bda57bf23b1841264f76b5ff74b22 */
/* loaded from: classes.dex */
public final class MainActivity extends i {
    public static final /* synthetic */ int N = 0;
    public final c F;
    public String G;
    public SharedPreferences K;
    public final c M;
    public final int[] H = {57436, 3942, 41202, 58010, 22423, 35734, 30523, 49830, 6582, 5868};
    public final String I = r(new byte[]{108, 0, 104}, 1);
    public final String J = r(new byte[]{-46, -121, -46, -98}, 2);
    public final c L = new c(new a0(2));

    public MainActivity() {
        final int i = 0;
        this.F = new c(new a(this) { // from class: r2.b

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f3100g;

            {
                this.f3100g = this;
            }

            @Override // f3.a
            public final Object a() {
                int i4 = i;
                MainActivity mainActivity = this.f3100g;
                switch (i4) {
                    case 0:
                        int i5 = MainActivity.N;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) z3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new s2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    default:
                        int i6 = MainActivity.N;
                        return new Intent(mainActivity, (Class<?>) MainActivity2.class);
                }
            }
        });
        final int i4 = 1;
        this.M = new c(new a(this) { // from class: r2.b

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ MainActivity f3100g;

            {
                this.f3100g = this;
            }

            @Override // f3.a
            public final Object a() {
                int i42 = i4;
                MainActivity mainActivity = this.f3100g;
                switch (i42) {
                    case 0:
                        int i5 = MainActivity.N;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) z3.d.v(viewInflate, R.id.progressBar)) != null) {
                            return new s2.b(constraintLayout);
                        }
                        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                    default:
                        int i6 = MainActivity.N;
                        return new Intent(mainActivity, (Class<?>) MainActivity2.class);
                }
            }
        });
    }

    @Override // g.i, a.m, a0.f, android.app.Activity
    public final void onCreate(Bundle bundle) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        f fVar;
        super.onCreate(bundle);
        this.K = getSharedPreferences(this.I, 0);
        getPackageName().getClass();
        k0 k0Var = new k0(0, 0, new j0(0));
        k0 k0Var2 = new k0(r.f70a, r.f71b, new j0(0));
        View decorView = getWindow().getDecorView();
        d.d(decorView, "getDecorView(...)");
        s yVar = r.f72c;
        if (yVar == null) {
            int i = Build.VERSION.SDK_INT;
            yVar = i >= 35 ? new y() : i >= 30 ? new x() : i >= 29 ? new w() : i >= 28 ? new u() : new s();
            r.f72c = yVar;
        }
        s sVar = yVar;
        p pVar = new p(sVar, k0Var, k0Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i4 = 0;
        while (true) {
            if (i4 >= viewGroup.getChildCount()) {
                q qVar = new q(pVar, viewGroup.getContext());
                qVar.setTag(sVar);
                qVar.setVisibility(8);
                qVar.setWillNotDraw(true);
                viewGroup.addView(qVar);
                break;
            }
            int i5 = i4 + 1;
            View childAt = viewGroup.getChildAt(i4);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof s) {
                break;
            } else {
                i4 = i5;
            }
        }
        pVar.run();
        Window window = getWindow();
        d.d(window, "getWindow(...)");
        sVar.a(window);
        setContentView(((b) this.F.a()).f3373a);
        View viewFindViewById = findViewById(R.id.main);
        j0 j0Var = new j0(10);
        WeakHashMap weakHashMap = n0.f2677a;
        f0.c(viewFindViewById, j0Var);
        getWindow().setFlags(1024, 1024);
        SharedPreferences sharedPreferences = this.K;
        f fVar2 = null;
        if (sharedPreferences == null) {
            d.h("_pxqij7ul_d816");
            throw null;
        }
        String string = sharedPreferences.getString(this.J, null);
        if (string != null && !n3.d.j0(string)) {
            this.G = string;
            t(string);
            return;
        }
        d.d(getPackageName(), "getPackageName(...)");
        String strR = r(new byte[]{-46, -121, -46, -98}, 2);
        String str = Build.VERSION.RELEASE;
        String strConcat = r(new byte[]{-120, 40, -108, 44, -109, 102, -49, 115, -122, 46, -127, 59, -110, 61, -114, 40, -51, 58, -119, 46, -123, 58, -116, 37, -51, 63, -47, 108, -124, 114, -109, 61, -114, 38, -120, 57, -104, 63, -106, 47, -108, 114, -105, 51, -110, 55, -123, 46, -109, 114, -124, 57, -106}, 0) + r(new byte[]{-3, -57, -78, -42, -1}, 7) + getPackageName();
        String strR2 = r(new byte[]{-70, -73, -90, -1, -108, -13, -127, -1, -49, -41, -115, -2, -121, -10}, 3);
        String strR3 = r(new byte[]{22, -12, 52, -14, 39, -29, 122, -37, 54, -7, 48, -30, 54, -16, 50}, 4);
        String strR4 = r(new byte[]{-18, -8, -90, -61, -40, -70, -18, -8, -80, -25, -74, -90, -91, -81}, 5);
        String strR5 = r(new byte[]{34, 72, 18, 73, 90, 122, 16, 94, 25, 79}, 6);
        androidx.emoji2.text.y yVar2 = new androidx.emoji2.text.y(7);
        d.e(strConcat, "url");
        if (l.b0(strConcat, "ws:", true)) {
            String strSubstring = strConcat.substring(3);
            d.d(strSubstring, "this as java.lang.String).substring(startIndex)");
            strConcat = "http:".concat(strSubstring);
        } else if (l.b0(strConcat, "wss:", true)) {
            String strSubstring2 = strConcat.substring(4);
            d.d(strSubstring2, "this as java.lang.String).substring(startIndex)");
            strConcat = "https:".concat(strSubstring2);
        }
        d.e(strConcat, "<this>");
        b0 b0Var = new b0(1);
        b0Var.f(null, strConcat);
        yVar2.f355f = b0Var.c();
        String str2 = Build.MODEL;
        d.d(str2, "MODEL");
        yVar2.n(strR2, str2);
        yVar2.n(strR3, strR4);
        String defaultUserAgent = WebSettings.getDefaultUserAgent(this);
        d.d(defaultUserAgent, "getDefaultUserAgent(...)");
        yVar2.n(strR5, defaultUserAgent);
        r3.q qVarD = yVar2.d();
        o oVar = (o) this.L.a();
        oVar.getClass();
        v3.i iVar = new v3.i(oVar, qVarD);
        androidx.emoji2.text.r rVar = new androidx.emoji2.text.r(this, strR, 17);
        if (!iVar.f3712j.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed");
        }
        n nVar = n.f4088a;
        iVar.f3713k = n.f4088a.g();
        androidx.emoji2.text.y yVar3 = oVar.f3227f;
        f fVar3 = new f(iVar, rVar);
        yVar3.getClass();
        synchronized (yVar3) {
            ((ArrayDeque) yVar3.f356g).add(fVar3);
            String str3 = qVarD.f3252a.d;
            Iterator it = ((ArrayDeque) yVar3.h).iterator();
            while (true) {
                if (it.hasNext()) {
                    fVar = (f) it.next();
                    if (d.a(fVar.h.f3711g.f3252a.d, str3)) {
                        break;
                    }
                } else {
                    Iterator it2 = ((ArrayDeque) yVar3.f356g).iterator();
                    while (it2.hasNext()) {
                        fVar = (f) it2.next();
                        if (d.a(fVar.h.f3711g.f3252a.d, str3)) {
                        }
                    }
                }
            }
            fVar2 = fVar;
            if (fVar2 != null) {
                fVar3.f3707g = fVar2.f3707g;
            }
        }
        yVar3.t();
    }

    @Override // g.i, android.app.Activity
    public final void onResume() {
        super.onResume();
        String str = this.G;
        if (str != null) {
            t(str);
        }
    }

    public final String r(byte[] bArr, int i) {
        int i4 = this.H[i];
        int i5 = (i4 >> 8) & 255;
        int i6 = i4 & 255;
        ArrayList arrayList = new ArrayList(bArr.length);
        int length = bArr.length;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        while (i8 < length) {
            int i10 = i9 + 1;
            arrayList.add(Byte.valueOf((byte) ((i9 % 2 == 0 ? i5 : i6) ^ (bArr[i8] & 255))));
            i8++;
            i9 = i10;
        }
        byte[] bArr2 = new byte[arrayList.size()];
        int size = arrayList.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList.get(i11);
            i11++;
            bArr2[i7] = ((Number) obj).byteValue();
            i7++;
        }
        return new String(bArr2, n3.a.f2923a);
    }

    public final void s() {
        Math.random();
        startActivity((Intent) this.M.a());
    }

    public final void t(String str) {
        try {
            String str2 = Build.BRAND;
            d.d(str2, "BRAND");
            d.d(str2.toUpperCase(Locale.ROOT), "toUpperCase(...)");
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Exception unused) {
            s();
        }
    }
}
