package com.imeninniki.dasfkojl.app1xbet;

import a.j0;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.imeninniki.dasfkojl.app1xbet.MainActivity2;
import com.imeninniki.dasfkojl.app1xbet.R;
import e1.f;
import g.b;
import g.g;
import g.i;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.Executor;
import l.s;
import l0.f0;
import l0.n0;
import org.json.JSONArray;
import org.json.JSONObject;
import p0.e;
import p1.c;
import r2.j;
import r2.k;
import r2.l;
import r2.p;
import r2.q;
import r2.r;
import s2.a;
import u2.o;
import z3.d;

/* compiled from: r8-map-id-63b0f5acf443110f44e3cbfc726f3470d68bda57bf23b1841264f76b5ff74b22 */
/* loaded from: classes.dex */
public final class MainActivity2 extends i {
    public static final /* synthetic */ int M = 0;
    public a F;
    public e G;
    public p H;
    public final ArrayList I = new ArrayList();
    public j J = j.f3117f;
    public String K = "";
    public boolean L;

    /* JADX WARN: Removed duplicated region for block: B:112:0x02fb  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0241  */
    @Override // g.i, a.m, a0.f, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) throws Throwable {
        Throwable th;
        ArrayList arrayList;
        a aVar;
        super.onCreate(bundle);
        Throwable th2 = null;
        boolean z4 = false;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main2, (ViewGroup) null, false);
        int i = R.id.addFab;
        FloatingActionButton floatingActionButton = (FloatingActionButton) d.v(viewInflate, R.id.addFab);
        if (floatingActionButton != null) {
            i = R.id.budgetText;
            TextView textView = (TextView) d.v(viewInflate, R.id.budgetText);
            if (textView != null) {
                i = R.id.chipActive;
                Chip chip = (Chip) d.v(viewInflate, R.id.chipActive);
                if (chip != null) {
                    i = R.id.chipAll;
                    if (((Chip) d.v(viewInflate, R.id.chipAll)) != null) {
                        i = R.id.chipBought;
                        Chip chip2 = (Chip) d.v(viewInflate, R.id.chipBought);
                        if (chip2 != null) {
                            i = R.id.chipPriority;
                            Chip chip3 = (Chip) d.v(viewInflate, R.id.chipPriority);
                            if (chip3 != null) {
                                i = R.id.clearBoughtButton;
                                TextView textView2 = (TextView) d.v(viewInflate, R.id.clearBoughtButton);
                                if (textView2 != null) {
                                    i = R.id.emptyState;
                                    LinearLayout linearLayout = (LinearLayout) d.v(viewInflate, R.id.emptyState);
                                    if (linearLayout != null) {
                                        i = R.id.filterChips;
                                        ChipGroup chipGroup = (ChipGroup) d.v(viewInflate, R.id.filterChips);
                                        if (chipGroup != null) {
                                            i = R.id.filterScroll;
                                            if (((HorizontalScrollView) d.v(viewInflate, R.id.filterScroll)) != null) {
                                                i = R.id.headerPanel;
                                                if (((LinearLayout) d.v(viewInflate, R.id.headerPanel)) != null) {
                                                    i = R.id.itemsRecycler;
                                                    RecyclerView recyclerView = (RecyclerView) d.v(viewInflate, R.id.itemsRecycler);
                                                    if (recyclerView != null) {
                                                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                                                        i = R.id.progressPercentText;
                                                        TextView textView3 = (TextView) d.v(viewInflate, R.id.progressPercentText);
                                                        if (textView3 != null) {
                                                            i = R.id.quickAddScroll;
                                                            if (((HorizontalScrollView) d.v(viewInflate, R.id.quickAddScroll)) != null) {
                                                                i = R.id.quickBread;
                                                                TextView textView4 = (TextView) d.v(viewInflate, R.id.quickBread);
                                                                if (textView4 != null) {
                                                                    i = R.id.quickEggs;
                                                                    TextView textView5 = (TextView) d.v(viewInflate, R.id.quickEggs);
                                                                    if (textView5 != null) {
                                                                        i = R.id.quickMilk;
                                                                        TextView textView6 = (TextView) d.v(viewInflate, R.id.quickMilk);
                                                                        if (textView6 != null) {
                                                                            i = R.id.quickWater;
                                                                            TextView textView7 = (TextView) d.v(viewInflate, R.id.quickWater);
                                                                            if (textView7 != null) {
                                                                                i = R.id.searchInput;
                                                                                EditText editText = (EditText) d.v(viewInflate, R.id.searchInput);
                                                                                if (editText != null) {
                                                                                    i = R.id.searchRow;
                                                                                    if (((LinearLayout) d.v(viewInflate, R.id.searchRow)) != null) {
                                                                                        i = R.id.statsText;
                                                                                        TextView textView8 = (TextView) d.v(viewInflate, R.id.statsText);
                                                                                        if (textView8 != null) {
                                                                                            i = R.id.subtitleText;
                                                                                            if (((TextView) d.v(viewInflate, R.id.subtitleText)) != null) {
                                                                                                i = R.id.titleText;
                                                                                                if (((TextView) d.v(viewInflate, R.id.titleText)) != null) {
                                                                                                    i = R.id.tripProgress;
                                                                                                    ProgressBar progressBar = (ProgressBar) d.v(viewInflate, R.id.tripProgress);
                                                                                                    if (progressBar != null) {
                                                                                                        i = R.id.winsBadge;
                                                                                                        TextView textView9 = (TextView) d.v(viewInflate, R.id.winsBadge);
                                                                                                        if (textView9 != null) {
                                                                                                            this.F = new a(constraintLayout, floatingActionButton, textView, chip, chip2, chip3, textView2, linearLayout, chipGroup, recyclerView, constraintLayout, textView3, textView4, textView5, textView6, textView7, editText, textView8, progressBar, textView9);
                                                                                                            setContentView(constraintLayout);
                                                                                                            a aVar2 = this.F;
                                                                                                            if (aVar2 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw null;
                                                                                                            }
                                                                                                            ConstraintLayout constraintLayout2 = aVar2.f3363j;
                                                                                                            j0 j0Var = new j0(11);
                                                                                                            WeakHashMap weakHashMap = n0.f2677a;
                                                                                                            f0.c(constraintLayout2, j0Var);
                                                                                                            this.G = new e(this);
                                                                                                            ArrayList arrayList2 = this.I;
                                                                                                            arrayList2.clear();
                                                                                                            e eVar = this.G;
                                                                                                            if (eVar == null) {
                                                                                                                g3.d.h("repository");
                                                                                                                throw null;
                                                                                                            }
                                                                                                            String string = ((SharedPreferences) eVar.f3010f).getString("items_json", null);
                                                                                                            int i4 = 1;
                                                                                                            if (string == null) {
                                                                                                                arrayList = new ArrayList();
                                                                                                                th = null;
                                                                                                            } else {
                                                                                                                try {
                                                                                                                    JSONArray jSONArray = new JSONArray(string);
                                                                                                                    arrayList = new ArrayList();
                                                                                                                    int length = jSONArray.length();
                                                                                                                    int i5 = 0;
                                                                                                                    while (i5 < length) {
                                                                                                                        JSONObject jSONObject = jSONArray.getJSONObject(i5);
                                                                                                                        long j4 = jSONObject.getLong("id");
                                                                                                                        String string2 = jSONObject.getString("name");
                                                                                                                        th = th2;
                                                                                                                        try {
                                                                                                                            g3.d.d(string2, "getString(...)");
                                                                                                                            int iOptInt = jSONObject.optInt("quantity", i4);
                                                                                                                            JSONArray jSONArray2 = jSONArray;
                                                                                                                            double dOptDouble = jSONObject.optDouble("price", 0.0d);
                                                                                                                            String strOptString = jSONObject.optString("category", "OTHER");
                                                                                                                            g3.d.d(strOptString, "optString(...)");
                                                                                                                            q qVarValueOf = q.valueOf(strOptString);
                                                                                                                            String strOptString2 = jSONObject.optString("priority", "LOW");
                                                                                                                            g3.d.d(strOptString2, "optString(...)");
                                                                                                                            r2.a aVarValueOf = r2.a.valueOf(strOptString2);
                                                                                                                            String strOptString3 = jSONObject.optString("note", "");
                                                                                                                            g3.d.d(strOptString3, "optString(...)");
                                                                                                                            ArrayList arrayList3 = arrayList;
                                                                                                                            arrayList3.add(new r(j4, string2, iOptInt, dOptDouble, qVarValueOf, aVarValueOf, strOptString3, jSONObject.optBoolean("isBought", z4), jSONObject.optLong("createdAt", System.currentTimeMillis())));
                                                                                                                            i5++;
                                                                                                                            arrayList = arrayList3;
                                                                                                                            jSONArray = jSONArray2;
                                                                                                                            z4 = false;
                                                                                                                            i4 = 1;
                                                                                                                            th2 = th;
                                                                                                                        } catch (Exception unused) {
                                                                                                                            arrayList = new ArrayList();
                                                                                                                            arrayList2.addAll(arrayList);
                                                                                                                            final int i6 = 5;
                                                                                                                            this.H = new p(new r2.d(this, i6), new r2.d(this, 0), new r2.d(this, 1));
                                                                                                                            aVar = this.F;
                                                                                                                            if (aVar != null) {
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                    th = th2;
                                                                                                                } catch (Exception unused2) {
                                                                                                                    th = th2;
                                                                                                                }
                                                                                                            }
                                                                                                            arrayList2.addAll(arrayList);
                                                                                                            final int i62 = 5;
                                                                                                            this.H = new p(new r2.d(this, i62), new r2.d(this, 0), new r2.d(this, 1));
                                                                                                            aVar = this.F;
                                                                                                            if (aVar != null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            aVar.i.setLayoutManager(new LinearLayoutManager(1));
                                                                                                            a aVar3 = this.F;
                                                                                                            if (aVar3 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            RecyclerView recyclerView2 = aVar3.i;
                                                                                                            p pVar = this.H;
                                                                                                            if (pVar == null) {
                                                                                                                g3.d.h("adapter");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            recyclerView2.setAdapter(pVar);
                                                                                                            a aVar4 = this.F;
                                                                                                            if (aVar4 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            final int i7 = 2;
                                                                                                            aVar4.h.setOnCheckedStateChangeListener(new r2.d(this, i7));
                                                                                                            a aVar5 = this.F;
                                                                                                            if (aVar5 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            aVar5.f3369p.addTextChangedListener(new l(this));
                                                                                                            a aVar6 = this.F;
                                                                                                            if (aVar6 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            final int i8 = 0;
                                                                                                            aVar6.f3367n.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i9 = i8;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i9) {
                                                                                                                        case 0:
                                                                                                                            int i10 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i11 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            a aVar7 = this.F;
                                                                                                            if (aVar7 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            final int i9 = 1;
                                                                                                            aVar7.f3365l.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i92 = i9;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i92) {
                                                                                                                        case 0:
                                                                                                                            int i10 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i11 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            a aVar8 = this.F;
                                                                                                            if (aVar8 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            aVar8.f3366m.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i92 = i7;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i92) {
                                                                                                                        case 0:
                                                                                                                            int i10 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i11 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            a aVar9 = this.F;
                                                                                                            if (aVar9 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            final int i10 = 3;
                                                                                                            aVar9.f3368o.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i92 = i10;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i92) {
                                                                                                                        case 0:
                                                                                                                            int i102 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i11 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            a aVar10 = this.F;
                                                                                                            if (aVar10 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            final int i11 = 4;
                                                                                                            aVar10.f3357a.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i92 = i11;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i92) {
                                                                                                                        case 0:
                                                                                                                            int i102 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i112 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            a aVar11 = this.F;
                                                                                                            if (aVar11 == null) {
                                                                                                                g3.d.h("binding");
                                                                                                                throw th;
                                                                                                            }
                                                                                                            aVar11.f3361f.setOnClickListener(new View.OnClickListener(this) { // from class: r2.i

                                                                                                                /* renamed from: g, reason: collision with root package name */
                                                                                                                public final /* synthetic */ MainActivity2 f3116g;

                                                                                                                {
                                                                                                                    this.f3116g = this;
                                                                                                                }

                                                                                                                @Override // android.view.View.OnClickListener
                                                                                                                public final void onClick(View view) {
                                                                                                                    int i92 = i62;
                                                                                                                    q qVar = q.f3132f;
                                                                                                                    q qVar2 = q.f3133g;
                                                                                                                    final MainActivity2 mainActivity2 = this.f3116g;
                                                                                                                    switch (i92) {
                                                                                                                        case 0:
                                                                                                                            int i102 = MainActivity2.M;
                                                                                                                            String string3 = mainActivity2.getString(R.string.quick_add_milk);
                                                                                                                            g3.d.d(string3, "getString(...)");
                                                                                                                            mainActivity2.s(string3, qVar2, 80.0d);
                                                                                                                            break;
                                                                                                                        case 1:
                                                                                                                            int i112 = MainActivity2.M;
                                                                                                                            String string4 = mainActivity2.getString(R.string.quick_add_bread);
                                                                                                                            g3.d.d(string4, "getString(...)");
                                                                                                                            mainActivity2.s(string4, qVar, 55.0d);
                                                                                                                            break;
                                                                                                                        case 2:
                                                                                                                            int i12 = MainActivity2.M;
                                                                                                                            String string5 = mainActivity2.getString(R.string.quick_add_eggs);
                                                                                                                            g3.d.d(string5, "getString(...)");
                                                                                                                            mainActivity2.s(string5, qVar, 120.0d);
                                                                                                                            break;
                                                                                                                        case 3:
                                                                                                                            int i13 = MainActivity2.M;
                                                                                                                            String string6 = mainActivity2.getString(R.string.quick_add_water);
                                                                                                                            g3.d.d(string6, "getString(...)");
                                                                                                                            mainActivity2.s(string6, qVar2, 40.0d);
                                                                                                                            break;
                                                                                                                        case 4:
                                                                                                                            int i14 = MainActivity2.M;
                                                                                                                            mainActivity2.v(null);
                                                                                                                            break;
                                                                                                                        default:
                                                                                                                            int i15 = MainActivity2.M;
                                                                                                                            g.f fVar = new g.f(mainActivity2);
                                                                                                                            g.b bVar = (g.b) fVar.f1714g;
                                                                                                                            bVar.d = bVar.f1667a.getText(R.string.confirm_clear_title);
                                                                                                                            bVar.f1671f = bVar.f1667a.getText(R.string.confirm_clear_message);
                                                                                                                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: r2.f
                                                                                                                                @Override // android.content.DialogInterface.OnClickListener
                                                                                                                                public final void onClick(DialogInterface dialogInterface, int i16) {
                                                                                                                                    MainActivity2 mainActivity22 = mainActivity2;
                                                                                                                                    u2.n.A(mainActivity22.I, new j0(12));
                                                                                                                                    mainActivity22.L = false;
                                                                                                                                    mainActivity22.r();
                                                                                                                                    Toast.makeText(mainActivity22, R.string.toast_cleared, 0).show();
                                                                                                                                }
                                                                                                                            };
                                                                                                                            bVar.f1672g = bVar.f1667a.getText(R.string.btn_clear_bought);
                                                                                                                            bVar.h = onClickListener;
                                                                                                                            bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                                                                                                            fVar.b().show();
                                                                                                                            break;
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                            u();
                                                                                                            return;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    public final void r() {
        e eVar = this.G;
        if (eVar == null) {
            g3.d.h("repository");
            throw null;
        }
        ArrayList arrayList = this.I;
        g3.d.e(arrayList, "items");
        JSONArray jSONArray = new JSONArray();
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            r rVar = (r) obj;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("id", rVar.f3134a);
            jSONObject.put("name", rVar.f3135b);
            jSONObject.put("quantity", rVar.f3136c);
            jSONObject.put("price", rVar.d);
            jSONObject.put("category", rVar.f3137e.name());
            jSONObject.put("priority", rVar.f3138f.name());
            jSONObject.put("note", rVar.f3139g);
            jSONObject.put("isBought", rVar.h);
            jSONObject.put("createdAt", rVar.i);
            jSONArray.put(jSONObject);
        }
        ((SharedPreferences) eVar.f3010f).edit().putString("items_json", jSONArray.toString()).apply();
        u();
    }

    public final void s(String str, q qVar, double d) {
        e eVar = this.G;
        if (eVar == null) {
            g3.d.h("repository");
            throw null;
        }
        SharedPreferences sharedPreferences = (SharedPreferences) eVar.f3010f;
        long j4 = sharedPreferences.getLong("item_seq", 1L);
        sharedPreferences.edit().putLong("item_seq", 1 + j4).apply();
        this.I.add(0, new r(j4, str, 1, d, qVar, r2.a.f3097f, "", false, System.currentTimeMillis()));
        r();
        Toast.makeText(this, R.string.toast_added, 0).show();
    }

    public final void t() {
        List listQ;
        ArrayList arrayList = this.I;
        g3.d.e(arrayList, "<this>");
        Iterator it = new m3.d(new m3.d(new m3.d(new o(arrayList), new r2.d(this, 3), 0), new r2.d(this, 4), 0), new k(new k(new d2.r(4), 0), 1), 2).iterator();
        if (it.hasNext()) {
            Object next = it.next();
            if (it.hasNext()) {
                ArrayList arrayList2 = new ArrayList();
                arrayList2.add(next);
                while (it.hasNext()) {
                    arrayList2.add(it.next());
                }
                listQ = arrayList2;
            } else {
                listQ = c.q(next);
            }
        } else {
            listQ = u2.q.f3610f;
        }
        p pVar = this.H;
        if (pVar == null) {
            g3.d.h("adapter");
            throw null;
        }
        f fVar = pVar.d;
        androidx.emoji2.text.o oVar = fVar.f1353a;
        int i = fVar.f1358g + 1;
        fVar.f1358g = i;
        List list = fVar.f1356e;
        int i4 = 0;
        if (listQ != list) {
            if (list == null) {
                fVar.f1356e = listQ;
                fVar.f1357f = Collections.unmodifiableList(listQ);
                oVar.r(0, listQ.size());
                fVar.a();
            } else {
                ((Executor) fVar.f1354b.f336g).execute(new e1.d(fVar, list, listQ, i));
            }
        }
        a aVar = this.F;
        if (aVar == null) {
            g3.d.h("binding");
            throw null;
        }
        aVar.f3362g.setVisibility(listQ.isEmpty() ? 0 : 8);
        a aVar2 = this.F;
        if (aVar2 == null) {
            g3.d.h("binding");
            throw null;
        }
        TextView textView = aVar2.f3361f;
        if (arrayList == null || !arrayList.isEmpty()) {
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                if (((r) obj).h) {
                    break;
                }
            }
            i4 = 8;
        } else {
            i4 = 8;
        }
        textView.setVisibility(i4);
    }

    public final void u() {
        int i;
        t();
        ArrayList arrayList = this.I;
        if (arrayList == null || !arrayList.isEmpty()) {
            int size = arrayList.size();
            i = 0;
            int i4 = 0;
            while (i4 < size) {
                Object obj = arrayList.get(i4);
                i4++;
                if (((r) obj).h && (i = i + 1) < 0) {
                    throw new ArithmeticException("Count overflow has happened.");
                }
            }
        } else {
            i = 0;
        }
        int size2 = arrayList.size() - i;
        ArrayList arrayList2 = new ArrayList();
        int size3 = arrayList.size();
        int i5 = 0;
        while (i5 < size3) {
            Object obj2 = arrayList.get(i5);
            i5++;
            if (((r) obj2).h) {
                arrayList2.add(obj2);
            }
        }
        int size4 = arrayList2.size();
        double d = 0.0d;
        int i6 = 0;
        while (i6 < size4) {
            Object obj3 = arrayList2.get(i6);
            i6++;
            d += ((r) obj3).d * r9.f3136c;
        }
        int size5 = arrayList.isEmpty() ? 0 : (i * 100) / arrayList.size();
        a aVar = this.F;
        if (aVar == null) {
            g3.d.h("binding");
            throw null;
        }
        aVar.f3370q.setText(getString(R.string.stats_format, Integer.valueOf(i), Integer.valueOf(size2)));
        a aVar2 = this.F;
        if (aVar2 == null) {
            g3.d.h("binding");
            throw null;
        }
        aVar2.f3364k.setText(getString(R.string.progress_format, Integer.valueOf(size5)));
        a aVar3 = this.F;
        if (aVar3 == null) {
            g3.d.h("binding");
            throw null;
        }
        aVar3.f3371r.setProgress(size5);
        a aVar4 = this.F;
        if (aVar4 == null) {
            g3.d.h("binding");
            throw null;
        }
        aVar4.f3358b.setText(getString(R.string.budget_format, Double.valueOf(d), Double.valueOf(2000.0d)));
        a aVar5 = this.F;
        if (aVar5 == null) {
            g3.d.h("binding");
            throw null;
        }
        TextView textView = aVar5.f3372s;
        e eVar = this.G;
        if (eVar != null) {
            textView.setText(getString(R.string.wins_format, Integer.valueOf(((SharedPreferences) eVar.f3010f).getInt("win_points", 0))));
        } else {
            g3.d.h("repository");
            throw null;
        }
    }

    public final void v(final r rVar) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.dialog_item_form, (ViewGroup) null, false);
        int i = R.id.categorySpinner;
        Spinner spinner = (Spinner) d.v(viewInflate, R.id.categorySpinner);
        if (spinner != null) {
            i = R.id.inputName;
            EditText editText = (EditText) d.v(viewInflate, R.id.inputName);
            if (editText != null) {
                i = R.id.inputNote;
                EditText editText2 = (EditText) d.v(viewInflate, R.id.inputNote);
                if (editText2 != null) {
                    i = R.id.inputPrice;
                    EditText editText3 = (EditText) d.v(viewInflate, R.id.inputPrice);
                    if (editText3 != null) {
                        i = R.id.inputQuantity;
                        EditText editText4 = (EditText) d.v(viewInflate, R.id.inputQuantity);
                        if (editText4 != null) {
                            i = R.id.prioritySpinner;
                            Spinner spinner2 = (Spinner) d.v(viewInflate, R.id.prioritySpinner);
                            if (spinner2 != null) {
                                ScrollView scrollView = (ScrollView) viewInflate;
                                final s sVar = new s(scrollView, spinner, editText, editText2, editText3, editText4, spinner2);
                                List listX = u2.i.x(getString(R.string.category_food), getString(R.string.category_drinks), getString(R.string.category_home), getString(R.string.category_hygiene), getString(R.string.category_other));
                                List listX2 = u2.i.x(getString(R.string.priority_low), getString(R.string.priority_medium), getString(R.string.priority_high));
                                spinner.setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listX));
                                spinner2.setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listX2));
                                if (rVar != null) {
                                    editText.setText(rVar.f3135b);
                                    editText4.setText(String.valueOf(rVar.f3136c));
                                    double d = rVar.d;
                                    if (d > 0.0d) {
                                        editText3.setText(String.valueOf((int) d));
                                    }
                                    editText2.setText(rVar.f3139g);
                                    spinner.setSelection(rVar.f3137e.ordinal());
                                    spinner2.setSelection(rVar.f3138f.ordinal());
                                } else {
                                    editText4.setText(getString(R.string.default_quantity));
                                }
                                g.f fVar = new g.f(this);
                                b bVar = (b) fVar.f1714g;
                                bVar.d = bVar.f1667a.getText(rVar == null ? R.string.dialog_add_title : R.string.dialog_edit_title);
                                bVar.f1676m = scrollView;
                                bVar.f1672g = bVar.f1667a.getText(R.string.btn_save);
                                bVar.h = null;
                                bVar.i = bVar.f1667a.getText(R.string.btn_cancel);
                                final g gVarB = fVar.b();
                                gVarB.setOnShowListener(new DialogInterface.OnShowListener(this) { // from class: r2.g

                                    /* renamed from: c, reason: collision with root package name */
                                    public final /* synthetic */ MainActivity2 f3112c;

                                    {
                                        this.f3112c = this;
                                    }

                                    @Override // android.content.DialogInterface.OnShowListener
                                    public final void onShow(DialogInterface dialogInterface) {
                                        int i4 = MainActivity2.M;
                                        final g.g gVar = gVarB;
                                        Button button = gVar.f1731l.i;
                                        final MainActivity2 mainActivity2 = this.f3112c;
                                        final s sVar2 = sVar;
                                        final r rVar2 = rVar;
                                        button.setOnClickListener(new View.OnClickListener() { // from class: r2.h
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view) {
                                                String string;
                                                String string2;
                                                String string3;
                                                Integer numW;
                                                int iIntValue;
                                                String string4;
                                                MainActivity2 mainActivity22 = mainActivity2;
                                                ArrayList arrayList = mainActivity22.I;
                                                int i5 = MainActivity2.M;
                                                s sVar3 = sVar2;
                                                Editable text = ((EditText) sVar3.f2547b).getText();
                                                String string5 = (text == null || (string4 = text.toString()) == null) ? null : n3.d.p0(string4).toString();
                                                String str = string5 == null ? "" : string5;
                                                if (str.length() == 0) {
                                                    Toast.makeText(mainActivity22, R.string.toast_name_required, 0).show();
                                                    return;
                                                }
                                                Editable text2 = ((EditText) sVar3.f2549e).getText();
                                                int i6 = 1;
                                                if (text2 != null && (string3 = text2.toString()) != null && (numW = n3.k.W(string3)) != null && (iIntValue = numW.intValue()) >= 1) {
                                                    i6 = iIntValue;
                                                }
                                                Editable text3 = ((EditText) sVar3.d).getText();
                                                double d5 = 0.0d;
                                                if (text3 != null && (string2 = text3.toString()) != null) {
                                                    Double dValueOf = n3.j.V(string2) ? Double.valueOf(Double.parseDouble(string2)) : null;
                                                    if (dValueOf != null) {
                                                        double dDoubleValue = dValueOf.doubleValue();
                                                        if (dDoubleValue >= 0.0d) {
                                                            d5 = dDoubleValue;
                                                        }
                                                    }
                                                }
                                                q qVar = (q) q.i.get(((Spinner) sVar3.f2546a).getSelectedItemPosition());
                                                a aVar = (a) a.i.get(((Spinner) sVar3.f2550f).getSelectedItemPosition());
                                                Editable text4 = ((EditText) sVar3.f2548c).getText();
                                                String string6 = (text4 == null || (string = text4.toString()) == null) ? null : n3.d.p0(string).toString();
                                                String str2 = string6 == null ? "" : string6;
                                                r rVar3 = rVar2;
                                                if (rVar3 == null) {
                                                    p0.e eVar = mainActivity22.G;
                                                    if (eVar == null) {
                                                        g3.d.h("repository");
                                                        throw null;
                                                    }
                                                    SharedPreferences sharedPreferences = (SharedPreferences) eVar.f3010f;
                                                    long j4 = sharedPreferences.getLong("item_seq", 1L);
                                                    sharedPreferences.edit().putLong("item_seq", 1 + j4).apply();
                                                    arrayList.add(0, new r(j4, str, i6, d5, qVar, aVar, str2, false, System.currentTimeMillis()));
                                                    Toast.makeText(mainActivity22, R.string.toast_added, 0).show();
                                                } else {
                                                    double d6 = d5;
                                                    String str3 = str;
                                                    int i7 = i6;
                                                    int size = arrayList.size();
                                                    int i8 = 0;
                                                    int i9 = 0;
                                                    while (true) {
                                                        if (i9 >= size) {
                                                            i8 = -1;
                                                            break;
                                                        }
                                                        Object obj = arrayList.get(i9);
                                                        i9++;
                                                        int i10 = size;
                                                        if (((r) obj).f3134a == rVar3.f3134a) {
                                                            break;
                                                        }
                                                        i8++;
                                                        size = i10;
                                                    }
                                                    if (i8 >= 0) {
                                                        arrayList.set(i8, r.a(rVar3, str3, i7, d6, qVar, aVar, str2, false, 385));
                                                    }
                                                    Toast.makeText(mainActivity22, R.string.toast_updated, 0).show();
                                                }
                                                mainActivity22.r();
                                                gVar.dismiss();
                                            }
                                        });
                                    }
                                });
                                gVarB.show();
                                return;
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
