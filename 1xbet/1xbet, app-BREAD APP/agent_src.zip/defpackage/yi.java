package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class yi implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ android.content.SharedPreferences d;
    public final /* synthetic */ com.novasport.rivals.play.MainActivity e;
    public final /* synthetic */ java.lang.String i;
    public final /* synthetic */ java.lang.String m;
    public final /* synthetic */ android.net.Uri n;

    public /* synthetic */ yi(android.content.SharedPreferences sharedPreferences, com.novasport.rivals.play.MainActivity mainActivity, java.lang.String str, java.lang.String str2, android.net.Uri uri) {
        this.d = sharedPreferences;
        this.e = mainActivity;
        this.i = str;
        this.m = str2;
        this.n = uri;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object invoke(java.lang.Object obj) {
        return com.novasport.rivals.play.MainActivity.resolveAndLaunch$lambda$3(this.d, this.e, this.i, this.m, this.n, (defpackage.j1) obj);
    }
}
