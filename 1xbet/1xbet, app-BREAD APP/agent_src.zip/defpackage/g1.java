package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class g1 implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ java.lang.String[] d;
    public final /* synthetic */ java.util.concurrent.CountDownLatch e;

    public /* synthetic */ g1(java.lang.String[] strArr, java.util.concurrent.CountDownLatch countDownLatch) {
        this.d = strArr;
        this.e = countDownLatch;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object invoke(java.lang.Object obj) {
        java.lang.String str = (java.lang.String) obj;
        str.getClass();
        this.d[0] = str;
        this.e.countDown();
        return kotlin.Unit.a;
    }
}
