package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class j1 {
    public final java.lang.String a;
    public final java.lang.String b;
    public final java.lang.String c;

    public j1(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        str.getClass();
        str2.getClass();
        str3.getClass();
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof defpackage.j1)) {
            return false;
        }
        defpackage.j1 j1Var = (defpackage.j1) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.a, j1Var.a) && kotlin.jvm.internal.Intrinsics.a(this.b, j1Var.b) && kotlin.jvm.internal.Intrinsics.a(this.c, j1Var.c);
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + (this.a.hashCode() * 31)) * 31);
    }

    public final java.lang.String toString() {
        java.lang.StringBuilder sb = new java.lang.StringBuilder("Data(referrer=");
        sb.append(this.a);
        sb.append(", gaid=");
        sb.append(this.b);
        sb.append(", campaign=");
        return defpackage.v5.i(sb, this.c, ")");
    }
}
