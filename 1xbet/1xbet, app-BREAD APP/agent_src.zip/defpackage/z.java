package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class z {
    public static final java.lang.Object h = new java.lang.Object();
    public static volatile defpackage.z i;
    public defpackage.o3 a;
    public defpackage.uz b;
    public boolean c;
    public final java.lang.Object d = new java.lang.Object();
    public defpackage.zw e;
    public final android.content.Context f;
    public final short g;

    public z(android.content.Context context) {
        defpackage.jy.n(context);
        this.f = context.getApplicationContext();
        this.c = false;
        this.g = (short) 30000;
    }

    public static defpackage.y a(android.content.Context context) {
        defpackage.z zVar = i;
        if (zVar == null) {
            synchronized (h) {
                try {
                    zVar = i;
                    if (zVar == null) {
                        android.util.Log.d("AdvertisingIdClient", "Creating AdvertisingIdClient");
                        zVar = new defpackage.z(context);
                        i = zVar;
                    }
                } finally {
                }
            }
        }
        android.util.Log.d("AdvertisingIdClient", "AdvertisingIdClient already created.");
        if (defpackage.q30.p == null) {
            synchronized (defpackage.q30.q) {
                try {
                    if (defpackage.q30.p == null) {
                        defpackage.q30.p = new defpackage.q30(context, (byte) 2);
                    }
                } finally {
                }
            }
        }
        defpackage.q30 q30Var = defpackage.q30.p;
        long jElapsedRealtime = android.os.SystemClock.elapsedRealtime();
        try {
            defpackage.y yVarF = zVar.f();
            long jElapsedRealtime2 = android.os.SystemClock.elapsedRealtime() - jElapsedRealtime;
            zVar.d(yVarF, jElapsedRealtime2, null);
            q30Var.u(0, (int) (android.os.SystemClock.elapsedRealtime() - jElapsedRealtime), jElapsedRealtime, android.os.SystemClock.elapsedRealtime());
            java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(jElapsedRealtime2).length() + 25);
            sb.append("GetInfoInternal elapse ");
            sb.append(jElapsedRealtime2);
            sb.append("ms");
            android.util.Log.i("AdvertisingIdClient", sb.toString());
            return yVarF;
        } catch (java.lang.Throwable th) {
            zVar.d(null, -1L, th);
            q30Var.u(!(th instanceof java.io.IOException) ? !(th instanceof defpackage.je) ? th instanceof java.lang.IllegalStateException ? 8 : -1 : 9 : 1, (int) (android.os.SystemClock.elapsedRealtime() - jElapsedRealtime), jElapsedRealtime, android.os.SystemClock.elapsedRealtime());
            throw th;
        }
    }

    public final void b() {
        defpackage.jy.m("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            try {
                if (this.c) {
                    return;
                }
                android.content.Context context = this.f;
                try {
                    context.getPackageManager().getPackageInfo("com.android.vending", 0);
                    int iB = defpackage.fe.b.b(context, 12451000);
                    if (iB != 0 && iB != 2) {
                        throw new java.io.IOException("Google Play services not available");
                    }
                    defpackage.o3 o3Var = new defpackage.o3();
                    android.content.Intent intent = new android.content.Intent("com.google.android.gms.ads.identifier.service.START");
                    intent.setPackage("com.google.android.gms");
                    try {
                        if (!defpackage.zd.j().e(context, intent, o3Var, 1)) {
                            throw new java.io.IOException("Connection failure");
                        }
                        this.a = o3Var;
                        try {
                            android.os.IBinder iBinderA = o3Var.a();
                            int i2 = defpackage.iz.e;
                            android.os.IInterface iInterfaceQueryLocalInterface = iBinderA.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                            this.b = iInterfaceQueryLocalInterface instanceof defpackage.uz ? (defpackage.uz) iInterfaceQueryLocalInterface : new defpackage.py(iBinderA);
                            this.c = true;
                        } catch (java.lang.InterruptedException unused) {
                            throw new java.io.IOException("Interrupted exception");
                        } catch (java.lang.Throwable th) {
                            throw new java.io.IOException(th);
                        }
                    } finally {
                        java.io.IOException iOException = new java.io.IOException(th);
                    }
                } catch (android.content.pm.PackageManager.NameNotFoundException unused2) {
                    throw new defpackage.je();
                }
            } catch (java.lang.Throwable th2) {
                throw th2;
            }
        }
    }

    public final void c() {
        defpackage.jy.m("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            try {
                android.content.Context context = this.f;
                if (context == null || this.a == null) {
                    return;
                }
                try {
                    if (this.c) {
                        defpackage.zd.j().v(context, this.a);
                    }
                } catch (java.lang.Throwable th) {
                    android.util.Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", th);
                }
                this.c = false;
                this.b = null;
                this.a = null;
            } catch (java.lang.Throwable th2) {
                throw th2;
            }
        }
    }

    public final void d(defpackage.y yVar, long j, java.lang.Throwable th) {
        if (java.lang.Math.random() <= 0.0d) {
            java.util.HashMap map = new java.util.HashMap();
            map.put("app_context", "1");
            if (yVar != null) {
                map.put("limit_ad_tracking", true != yVar.c ? "0" : "1");
                java.lang.String str = (java.lang.String) yVar.b;
                if (str != null) {
                    map.put("ad_id_size", java.lang.Integer.toString(str.length()));
                }
            }
            if (th != null) {
                map.put("error", th.getClass().getName());
            }
            map.put("tag", "AdvertisingIdClient");
            map.put("time_spent", java.lang.Long.toString(j));
            new defpackage.xu(this, map).start();
        }
    }

    public final synchronized void e() {
        try {
            if (!this.c) {
                try {
                    android.util.Log.d("AdvertisingIdClient", "AdvertisingIdClient is not bounded. Starting to bind it...");
                    b();
                    android.util.Log.d("AdvertisingIdClient", "AdvertisingIdClient is bounded");
                    if (!this.c) {
                        throw new java.io.IOException("AdvertisingIdClient cannot reconnect.");
                    }
                } catch (java.lang.Exception e) {
                    throw new java.io.IOException("AdvertisingIdClient cannot reconnect.", e);
                }
            }
        } finally {
        }
    }

    public final defpackage.y f() {
        defpackage.y yVar;
        defpackage.jy.m("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            e();
            defpackage.jy.n(this.a);
            defpackage.jy.n(this.b);
            try {
                defpackage.py pyVar = (defpackage.py) this.b;
                pyVar.getClass();
                android.os.Parcel parcelObtain = android.os.Parcel.obtain();
                parcelObtain.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                boolean z = true;
                android.os.Parcel parcelA = pyVar.a(parcelObtain, 1);
                java.lang.String string = parcelA.readString();
                parcelA.recycle();
                defpackage.py pyVar2 = (defpackage.py) this.b;
                pyVar2.getClass();
                android.os.Parcel parcelObtain2 = android.os.Parcel.obtain();
                parcelObtain2.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                int i2 = defpackage.yx.a;
                parcelObtain2.writeInt(1);
                android.os.Parcel parcelA2 = pyVar2.a(parcelObtain2, 2);
                if (parcelA2.readInt() == 0) {
                    z = false;
                }
                parcelA2.recycle();
                yVar = new defpackage.y(string, z, (byte) 0);
            } catch (android.os.RemoteException e) {
                android.util.Log.i("AdvertisingIdClient", "GMS remote exception ", e);
                throw new java.io.IOException("Remote exception", e);
            }
        }
        synchronized (this.d) {
            defpackage.zw zwVar = this.e;
            if (zwVar != null) {
                zwVar.i.countDown();
                try {
                    this.e.join();
                } catch (java.lang.InterruptedException unused) {
                }
            }
            long j = this.g;
            if (j > 0) {
                this.e = new defpackage.zw(this, j);
            }
        }
        return yVar;
    }

    public final void finalize() throws java.lang.Throwable {
        c();
        super.finalize();
    }
}
