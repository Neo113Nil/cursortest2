package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class i1 implements java.lang.Runnable {
    public final /* synthetic */ byte d;
    public final /* synthetic */ java.lang.Object e;
    public final /* synthetic */ java.lang.Object i;

    public /* synthetic */ i1(java.lang.Object obj, java.lang.Object obj2, byte b) {
        this.d = b;
        this.e = obj;
        this.i = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() throws java.lang.Exception {
        defpackage.q8 q8Var;
        switch (this.d) {
            case 0:
                defpackage.yi yiVar = (defpackage.yi) this.e;
                java.lang.String[] strArr = (java.lang.String[]) this.i;
                yiVar.invoke(new defpackage.j1(strArr[0], strArr[1], strArr[2]));
                return;
            case 1:
                defpackage.al alVar = (defpackage.al) this.e;
                defpackage.em emVar = (defpackage.em) this.i;
                if (alVar.b != defpackage.al.d) {
                    defpackage.q8.g("provide() can be called only once.");
                    return;
                }
                synchronized (alVar) {
                    q8Var = alVar.a;
                    alVar.a = null;
                    alVar.b = emVar;
                }
                q8Var.getClass();
                return;
            case 2:
                defpackage.ph phVar = (defpackage.ph) this.e;
                defpackage.em emVar2 = (defpackage.em) this.i;
                synchronized (phVar) {
                    try {
                        if (phVar.b == null) {
                            phVar.a.add(emVar2);
                        } else {
                            phVar.b.add(emVar2.get());
                        }
                    } catch (java.lang.Throwable th) {
                        throw th;
                    }
                }
                return;
            case 3:
                defpackage.r7 r7Var = (defpackage.r7) this.e;
                java.lang.Runnable runnable = (java.lang.Runnable) this.i;
                android.os.Process.setThreadPriority(r7Var.c);
                android.os.StrictMode.ThreadPolicy threadPolicy = r7Var.d;
                if (threadPolicy != null) {
                    android.os.StrictMode.setThreadPolicy(threadPolicy);
                }
                runnable.run();
                return;
            case 4:
                java.util.concurrent.Callable callable = (java.util.concurrent.Callable) this.e;
                defpackage.b9 b9Var = (defpackage.b9) ((defpackage.zd) this.i).e;
                try {
                    b9Var.j(callable.call());
                    return;
                } catch (java.lang.Exception e) {
                    b9Var.k(e);
                    return;
                }
            case 5:
                ((defpackage.jb) this.e).a((android.content.Intent) this.i);
                return;
            case 6:
                defpackage.nf nfVar = (defpackage.nf) this.e;
                defpackage.iq iqVar = (defpackage.iq) this.i;
                try {
                    iqVar.a(nfVar.a());
                    return;
                } catch (java.lang.Exception e2) {
                    iqVar.a.n(e2);
                    return;
                }
            case androidx.browser.trusted.ScreenOrientation.PORTRAIT /* 7 */:
                com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService jobInfoSchedulerService = (com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService) this.e;
                android.app.job.JobParameters jobParameters = (android.app.job.JobParameters) this.i;
                int i = com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService.d;
                jobInfoSchedulerService.jobFinished(jobParameters, false);
                return;
            case androidx.browser.trusted.ScreenOrientation.NATURAL /* 8 */:
                ((com.google.androidbrowserhelper.trusted.splashscreens.PwaWrapperSplashScreenStrategy) this.e).lambda$onSplashImageTransferred$1((java.lang.Runnable) this.i);
                return;
            default:
                ((androidx.browser.trusted.TrustedWebActivityServiceConnectionPool) this.e).lambda$connect$0((android.net.Uri) this.i);
                return;
        }
    }
}
