package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public abstract class k1 {
    public static final void a(defpackage.pm pmVar, defpackage.g1 g1Var, com.android.installreferrer.api.InstallReferrerClient installReferrerClient, java.lang.String str) {
        if (pmVar.d) {
            return;
        }
        pmVar.d = true;
        try {
            defpackage.ln lnVar = defpackage.nn.d;
            installReferrerClient.endConnection();
        } catch (java.lang.Throwable unused) {
            defpackage.ln lnVar2 = defpackage.nn.d;
        }
        g1Var.invoke(str);
    }
}
