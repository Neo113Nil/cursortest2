package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public abstract class or implements defpackage.sa {
    public static final defpackage.zd a;
    public static final defpackage.zd b;
    public static final defpackage.ch c = new defpackage.ch(2);

    static {
        byte b2 = 16;
        a = new defpackage.zd("UNDEFINED", b2);
        b = new defpackage.zd("REUSABLE_CLAIMED", b2);
    }

    public static int A(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.d60)) {
            int iR = 0;
            while (i < size) {
                iR += defpackage.f50.r(((java.lang.Integer) list.get(i)).intValue());
                i++;
            }
            return iR;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        int iR2 = 0;
        while (i < size) {
            iR2 += defpackage.f50.r(d60Var.b(i));
            i++;
        }
        return iR2;
    }

    public static void B(int i, int i2) {
        java.lang.String strV;
        if (i < 0 || i >= i2) {
            if (i < 0) {
                strV = defpackage.vw.v("%s (%s) must not be negative", "index", java.lang.Integer.valueOf(i));
            } else {
                if (i2 < 0) {
                    java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(i2).length() + 15);
                    sb.append("negative size: ");
                    sb.append(i2);
                    throw new java.lang.IllegalArgumentException(sb.toString());
                }
                strV = defpackage.vw.v("%s (%s) must be less than size (%s)", "index", java.lang.Integer.valueOf(i), java.lang.Integer.valueOf(i2));
            }
            throw new java.lang.IndexOutOfBoundsException(strV);
        }
    }

    public static void C(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        if (list instanceof defpackage.l50) {
            defpackage.mr.a();
            return;
        }
        int i2 = 0;
        if (!z) {
            while (i2 < list.size()) {
                f50Var.d(i, java.lang.Double.doubleToRawLongBits(((java.lang.Double) list.get(i2)).doubleValue()));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i3 = 0;
        for (int i4 = 0; i4 < list.size(); i4++) {
            ((java.lang.Double) list.get(i4)).getClass();
            i3 += 8;
        }
        f50Var.n(i3);
        while (i2 < list.size()) {
            f50Var.e(java.lang.Double.doubleToRawLongBits(((java.lang.Double) list.get(i2)).doubleValue()));
            i2++;
        }
    }

    public static void D(android.os.Parcel parcel, int i, int i2) {
        if (i == i2) {
            return;
        }
        java.lang.String hexString = java.lang.Integer.toHexString(i);
        int length = java.lang.String.valueOf(i2).length();
        java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(hexString).length() + length + 19 + java.lang.String.valueOf(i).length() + 4 + 1);
        sb.append("Expected size ");
        sb.append(i2);
        sb.append(" got ");
        sb.append(i);
        sb.append(" (0x");
        sb.append(hexString);
        sb.append(")");
        throw new defpackage.fo(sb.toString(), parcel);
    }

    public static void E(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.j(i, ((java.lang.Integer) list.get(i2)).intValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iR = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                iR += defpackage.f50.r(((java.lang.Integer) list.get(i3)).intValue());
            }
            f50Var.n(iR);
            while (i2 < list.size()) {
                f50Var.i(((java.lang.Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                f50Var.j(i, d60Var.b(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iR2 = 0;
        for (int i4 = 0; i4 < d60Var.i; i4++) {
            iR2 += defpackage.f50.r(d60Var.b(i4));
        }
        f50Var.n(iR2);
        while (i2 < d60Var.i) {
            f50Var.i(d60Var.b(i2));
            i2++;
        }
    }

    public static void F(int i, int i2, int i3) {
        if (i < 0 || i2 < i || i2 > i3) {
            throw new java.lang.IndexOutOfBoundsException((i < 0 || i > i3) ? I("start index", i, i3) : (i2 < 0 || i2 > i3) ? I("end index", i2, i3) : defpackage.vw.v("end index (%s) must not be less than start index (%s)", java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(i)));
        }
    }

    public static void G(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.c(i, ((java.lang.Integer) list.get(i2)).intValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int i3 = 0;
            for (int i4 = 0; i4 < list.size(); i4++) {
                ((java.lang.Integer) list.get(i4)).getClass();
                i3 += 4;
            }
            f50Var.n(i3);
            while (i2 < list.size()) {
                f50Var.b(((java.lang.Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                f50Var.c(i, d60Var.b(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i5 = 0;
        for (int i6 = 0; i6 < d60Var.i; i6++) {
            d60Var.b(i6);
            i5 += 4;
        }
        f50Var.n(i5);
        while (i2 < d60Var.i) {
            f50Var.b(d60Var.b(i2));
            i2++;
        }
    }

    public static int H(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.d60)) {
            int iR = 0;
            while (i < size) {
                iR += defpackage.f50.r(((java.lang.Integer) list.get(i)).intValue());
                i++;
            }
            return iR;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        int iR2 = 0;
        while (i < size) {
            iR2 += defpackage.f50.r(d60Var.b(i));
            i++;
        }
        return iR2;
    }

    public static java.lang.String I(java.lang.String str, int i, int i2) {
        if (i < 0) {
            return defpackage.vw.v("%s (%s) must not be negative", str, java.lang.Integer.valueOf(i));
        }
        if (i2 >= 0) {
            return defpackage.vw.v("%s (%s) must not be greater than size (%s)", str, java.lang.Integer.valueOf(i), java.lang.Integer.valueOf(i2));
        }
        java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(i2).length() + 15);
        sb.append("negative size: ");
        sb.append(i2);
        throw new java.lang.IllegalArgumentException(sb.toString());
    }

    public static void J(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.t60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.d(i, ((java.lang.Long) list.get(i2)).longValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int i3 = 0;
            for (int i4 = 0; i4 < list.size(); i4++) {
                ((java.lang.Long) list.get(i4)).getClass();
                i3 += 8;
            }
            f50Var.n(i3);
            while (i2 < list.size()) {
                f50Var.e(((java.lang.Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        if (!z) {
            while (i2 < t60Var.i) {
                f50Var.d(i, t60Var.c(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i5 = 0;
        for (int i6 = 0; i6 < t60Var.i; i6++) {
            t60Var.c(i6);
            i5 += 8;
        }
        f50Var.n(i5);
        while (i2 < t60Var.i) {
            f50Var.e(t60Var.c(i2));
            i2++;
        }
    }

    public static int K(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.t60)) {
            int iR = 0;
            while (i < size) {
                iR += defpackage.f50.r(((java.lang.Long) list.get(i)).longValue());
                i++;
            }
            return iR;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        int iR2 = 0;
        while (i < size) {
            iR2 += defpackage.f50.r(t60Var.c(i));
            i++;
        }
        return iR2;
    }

    public static void L(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        if (list instanceof defpackage.x50) {
            defpackage.mr.a();
            return;
        }
        int i2 = 0;
        if (!z) {
            while (i2 < list.size()) {
                f50Var.c(i, java.lang.Float.floatToRawIntBits(((java.lang.Float) list.get(i2)).floatValue()));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i3 = 0;
        for (int i4 = 0; i4 < list.size(); i4++) {
            ((java.lang.Float) list.get(i4)).getClass();
            i3 += 4;
        }
        f50Var.n(i3);
        while (i2 < list.size()) {
            f50Var.b(java.lang.Float.floatToRawIntBits(((java.lang.Float) list.get(i2)).floatValue()));
            i2++;
        }
    }

    public static int M(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.d60)) {
            int iT = 0;
            while (i < size) {
                int iIntValue = ((java.lang.Integer) list.get(i)).intValue();
                iT += defpackage.f50.t((iIntValue >> 31) ^ (iIntValue << 1));
                i++;
            }
            return iT;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        int iT2 = 0;
        while (i < size) {
            int iB = d60Var.b(i);
            iT2 += defpackage.f50.t((iB >> 31) ^ (iB << 1));
            i++;
        }
        return iT2;
    }

    public static void N(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.j(i, ((java.lang.Integer) list.get(i2)).intValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iR = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                iR += defpackage.f50.r(((java.lang.Integer) list.get(i3)).intValue());
            }
            f50Var.n(iR);
            while (i2 < list.size()) {
                f50Var.i(((java.lang.Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                f50Var.j(i, d60Var.b(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iR2 = 0;
        for (int i4 = 0; i4 < d60Var.i; i4++) {
            iR2 += defpackage.f50.r(d60Var.b(i4));
        }
        f50Var.n(iR2);
        while (i2 < d60Var.i) {
            f50Var.i(d60Var.b(i2));
            i2++;
        }
    }

    public static int O(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.t60)) {
            int iR = 0;
            while (i < size) {
                long jLongValue = ((java.lang.Long) list.get(i)).longValue();
                iR += defpackage.f50.r((jLongValue >> 63) ^ (jLongValue << 1));
                i++;
            }
            return iR;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        int iR2 = 0;
        while (i < size) {
            long jC = t60Var.c(i);
            iR2 += defpackage.f50.r((jC >> 63) ^ (jC << 1));
            i++;
        }
        return iR2;
    }

    public static void P(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.t60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.k(i, ((java.lang.Long) list.get(i2)).longValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iR = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                iR += defpackage.f50.r(((java.lang.Long) list.get(i3)).longValue());
            }
            f50Var.n(iR);
            while (i2 < list.size()) {
                f50Var.l(((java.lang.Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        if (!z) {
            while (i2 < t60Var.i) {
                f50Var.k(i, t60Var.c(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iR2 = 0;
        for (int i4 = 0; i4 < t60Var.i; i4++) {
            iR2 += defpackage.f50.r(t60Var.c(i4));
        }
        f50Var.n(iR2);
        while (i2 < t60Var.i) {
            f50Var.l(t60Var.c(i2));
            i2++;
        }
    }

    public static int Q(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.d60)) {
            int iT = 0;
            while (i < size) {
                iT += defpackage.f50.t(((java.lang.Integer) list.get(i)).intValue());
                i++;
            }
            return iT;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        int iT2 = 0;
        while (i < size) {
            iT2 += defpackage.f50.t(d60Var.b(i));
            i++;
        }
        return iT2;
    }

    public static void R(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.c(i, ((java.lang.Integer) list.get(i2)).intValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int i3 = 0;
            for (int i4 = 0; i4 < list.size(); i4++) {
                ((java.lang.Integer) list.get(i4)).getClass();
                i3 += 4;
            }
            f50Var.n(i3);
            while (i2 < list.size()) {
                f50Var.b(((java.lang.Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                f50Var.c(i, d60Var.b(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i5 = 0;
        for (int i6 = 0; i6 < d60Var.i; i6++) {
            d60Var.b(i6);
            i5 += 4;
        }
        f50Var.n(i5);
        while (i2 < d60Var.i) {
            f50Var.b(d60Var.b(i2));
            i2++;
        }
    }

    public static int S(java.util.List list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        if (!(list instanceof defpackage.t60)) {
            int iR = 0;
            while (i < size) {
                iR += defpackage.f50.r(((java.lang.Long) list.get(i)).longValue());
                i++;
            }
            return iR;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        int iR2 = 0;
        while (i < size) {
            iR2 += defpackage.f50.r(t60Var.c(i));
            i++;
        }
        return iR2;
    }

    public static void T(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.t60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.d(i, ((java.lang.Long) list.get(i2)).longValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int i3 = 0;
            for (int i4 = 0; i4 < list.size(); i4++) {
                ((java.lang.Long) list.get(i4)).getClass();
                i3 += 8;
            }
            f50Var.n(i3);
            while (i2 < list.size()) {
                f50Var.e(((java.lang.Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        if (!z) {
            while (i2 < t60Var.i) {
                f50Var.d(i, t60Var.c(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int i5 = 0;
        for (int i6 = 0; i6 < t60Var.i; i6++) {
            t60Var.c(i6);
            i5 += 8;
        }
        f50Var.n(i5);
        while (i2 < t60Var.i) {
            f50Var.e(t60Var.c(i2));
            i2++;
        }
    }

    public static void U(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    int iIntValue = ((java.lang.Integer) list.get(i2)).intValue();
                    f50Var.q(i, (iIntValue >> 31) ^ (iIntValue << 1));
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iT = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                int iIntValue2 = ((java.lang.Integer) list.get(i3)).intValue();
                iT += defpackage.f50.t((iIntValue2 >> 31) ^ (iIntValue2 << 1));
            }
            f50Var.n(iT);
            while (i2 < list.size()) {
                int iIntValue3 = ((java.lang.Integer) list.get(i2)).intValue();
                f50Var.n((iIntValue3 >> 31) ^ (iIntValue3 << 1));
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                int iB = d60Var.b(i2);
                f50Var.q(i, (iB >> 31) ^ (iB << 1));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iT2 = 0;
        for (int i4 = 0; i4 < d60Var.i; i4++) {
            int iB2 = d60Var.b(i4);
            iT2 += defpackage.f50.t((iB2 >> 31) ^ (iB2 << 1));
        }
        f50Var.n(iT2);
        while (i2 < d60Var.i) {
            int iB3 = d60Var.b(i2);
            f50Var.n((iB3 >> 31) ^ (iB3 << 1));
            i2++;
        }
    }

    public static void V(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.t60)) {
            if (!z) {
                while (i2 < list.size()) {
                    long jLongValue = ((java.lang.Long) list.get(i2)).longValue();
                    f50Var.k(i, (jLongValue >> 63) ^ (jLongValue << 1));
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iR = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                long jLongValue2 = ((java.lang.Long) list.get(i3)).longValue();
                iR += defpackage.f50.r((jLongValue2 >> 63) ^ (jLongValue2 << 1));
            }
            f50Var.n(iR);
            while (i2 < list.size()) {
                long jLongValue3 = ((java.lang.Long) list.get(i2)).longValue();
                f50Var.l((jLongValue3 >> 63) ^ (jLongValue3 << 1));
                i2++;
            }
            return;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        if (!z) {
            while (i2 < t60Var.i) {
                long jC = t60Var.c(i2);
                f50Var.k(i, (jC >> 63) ^ (jC << 1));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iR2 = 0;
        for (int i4 = 0; i4 < t60Var.i; i4++) {
            long jC2 = t60Var.c(i4);
            iR2 += defpackage.f50.r((jC2 >> 63) ^ (jC2 << 1));
        }
        f50Var.n(iR2);
        while (i2 < t60Var.i) {
            long jC3 = t60Var.c(i2);
            f50Var.l((jC3 >> 63) ^ (jC3 << 1));
            i2++;
        }
    }

    public static void W(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.d60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.q(i, ((java.lang.Integer) list.get(i2)).intValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iT = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                iT += defpackage.f50.t(((java.lang.Integer) list.get(i3)).intValue());
            }
            f50Var.n(iT);
            while (i2 < list.size()) {
                f50Var.n(((java.lang.Integer) list.get(i2)).intValue());
                i2++;
            }
            return;
        }
        defpackage.d60 d60Var = (defpackage.d60) list;
        if (!z) {
            while (i2 < d60Var.i) {
                f50Var.q(i, d60Var.b(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iT2 = 0;
        for (int i4 = 0; i4 < d60Var.i; i4++) {
            iT2 += defpackage.f50.t(d60Var.b(i4));
        }
        f50Var.n(iT2);
        while (i2 < d60Var.i) {
            f50Var.n(d60Var.b(i2));
            i2++;
        }
    }

    public static void X(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        int i2 = 0;
        if (!(list instanceof defpackage.t60)) {
            if (!z) {
                while (i2 < list.size()) {
                    f50Var.k(i, ((java.lang.Long) list.get(i2)).longValue());
                    i2++;
                }
                return;
            }
            f50Var.o(i, 2);
            int iR = 0;
            for (int i3 = 0; i3 < list.size(); i3++) {
                iR += defpackage.f50.r(((java.lang.Long) list.get(i3)).longValue());
            }
            f50Var.n(iR);
            while (i2 < list.size()) {
                f50Var.l(((java.lang.Long) list.get(i2)).longValue());
                i2++;
            }
            return;
        }
        defpackage.t60 t60Var = (defpackage.t60) list;
        if (!z) {
            while (i2 < t60Var.i) {
                f50Var.k(i, t60Var.c(i2));
                i2++;
            }
            return;
        }
        f50Var.o(i, 2);
        int iR2 = 0;
        for (int i4 = 0; i4 < t60Var.i; i4++) {
            iR2 += defpackage.f50.r(t60Var.c(i4));
        }
        f50Var.n(iR2);
        while (i2 < t60Var.i) {
            f50Var.l(t60Var.c(i2));
            i2++;
        }
    }

    public static void a(java.lang.Object obj) {
        if (obj != null) {
            if (obj instanceof defpackage.sd) {
                if ((obj instanceof defpackage.td ? ((defpackage.td) obj).getArity() : obj instanceof kotlin.jvm.functions.Function0 ? 0 : obj instanceof kotlin.jvm.functions.Function1 ? 1 : obj instanceof kotlin.jvm.functions.Function2 ? 2 : -1) == 2) {
                    return;
                }
            }
            java.lang.ClassCastException classCastException = new java.lang.ClassCastException(obj.getClass().getName().concat(" cannot be cast to kotlin.jvm.functions.Function2"));
            kotlin.jvm.internal.Intrinsics.b(classCastException, defpackage.or.class.getName());
            throw classCastException;
        }
    }

    public static int b(android.content.Context context, java.lang.String str) {
        int iNoteProxyOpNoThrow;
        int iMyPid = android.os.Process.myPid();
        int iMyUid = android.os.Process.myUid();
        java.lang.String packageName = context.getPackageName();
        if (context.checkPermission(str, iMyPid, iMyUid) != -1) {
            java.lang.String strPermissionToOp = android.app.AppOpsManager.permissionToOp(str);
            if (strPermissionToOp != null) {
                if (packageName == null) {
                    java.lang.String[] packagesForUid = context.getPackageManager().getPackagesForUid(iMyUid);
                    if (packagesForUid != null && packagesForUid.length > 0) {
                        packageName = packagesForUid[0];
                    }
                }
                int iMyUid2 = android.os.Process.myUid();
                java.lang.String packageName2 = context.getPackageName();
                if (iMyUid2 == iMyUid && java.util.Objects.equals(packageName2, packageName) && android.os.Build.VERSION.SDK_INT >= 29) {
                    android.app.AppOpsManager appOpsManager = (android.app.AppOpsManager) context.getSystemService(android.app.AppOpsManager.class);
                    iNoteProxyOpNoThrow = appOpsManager == null ? 1 : appOpsManager.checkOpNoThrow(strPermissionToOp, android.os.Binder.getCallingUid(), packageName);
                    if (iNoteProxyOpNoThrow == 0) {
                        iNoteProxyOpNoThrow = appOpsManager != null ? appOpsManager.checkOpNoThrow(strPermissionToOp, iMyUid, defpackage.m0.a(context)) : 1;
                    }
                } else {
                    iNoteProxyOpNoThrow = ((android.app.AppOpsManager) context.getSystemService(android.app.AppOpsManager.class)).noteProxyOpNoThrow(strPermissionToOp, packageName);
                }
                if (iNoteProxyOpNoThrow != 0) {
                    return -2;
                }
            }
            return 0;
        }
        return -1;
    }

    public static boolean c(java.io.File file, java.io.FileInputStream fileInputStream) throws java.lang.Throwable {
        java.io.FileOutputStream fileOutputStream;
        android.os.StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = android.os.StrictMode.allowThreadDiskWrites();
        java.io.FileOutputStream fileOutputStream2 = null;
        try {
            try {
                fileOutputStream = new java.io.FileOutputStream(file, false);
            } catch (java.io.IOException e) {
                e = e;
            }
        } catch (java.lang.Throwable th) {
            th = th;
        }
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int i = fileInputStream.read(bArr);
                if (i != -1) {
                    fileOutputStream.write(bArr, 0, i);
                } else {
                    try {
                        break;
                    } catch (java.io.IOException unused) {
                    }
                }
            }
            fileOutputStream.close();
            android.os.StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            return true;
        } catch (java.io.IOException e2) {
            e = e2;
            fileOutputStream2 = fileOutputStream;
            android.util.Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
            if (fileOutputStream2 != null) {
                try {
                    fileOutputStream2.close();
                } catch (java.io.IOException unused2) {
                }
            }
            android.os.StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            return false;
        } catch (java.lang.Throwable th2) {
            th = th2;
            fileOutputStream2 = fileOutputStream;
            if (fileOutputStream2 != null) {
                try {
                    fileOutputStream2.close();
                } catch (java.io.IOException unused3) {
                }
            }
            android.os.StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            throw th;
        }
    }

    public static android.os.Bundle d(android.os.Parcel parcel, int i) {
        int iQ = q(parcel, i);
        int iDataPosition = parcel.dataPosition();
        if (iQ == 0) {
            return null;
        }
        android.os.Bundle bundle = parcel.readBundle();
        parcel.setDataPosition(iDataPosition + iQ);
        return bundle;
    }

    public static android.os.Parcelable e(android.os.Parcel parcel, int i, android.os.Parcelable.Creator creator) {
        int iQ = q(parcel, i);
        int iDataPosition = parcel.dataPosition();
        if (iQ == 0) {
            return null;
        }
        android.os.Parcelable parcelable = (android.os.Parcelable) creator.createFromParcel(parcel);
        parcel.setDataPosition(iDataPosition + iQ);
        return parcelable;
    }

    public static java.lang.String f(android.os.Parcel parcel, int i) {
        int iQ = q(parcel, i);
        int iDataPosition = parcel.dataPosition();
        if (iQ == 0) {
            return null;
        }
        java.lang.String string = parcel.readString();
        parcel.setDataPosition(iDataPosition + iQ);
        return string;
    }

    public static java.lang.Object[] g(android.os.Parcel parcel, int i, android.os.Parcelable.Creator creator) {
        int iQ = q(parcel, i);
        int iDataPosition = parcel.dataPosition();
        if (iQ == 0) {
            return null;
        }
        java.lang.Object[] objArrCreateTypedArray = parcel.createTypedArray(creator);
        parcel.setDataPosition(iDataPosition + iQ);
        return objArrCreateTypedArray;
    }

    public static void h(android.os.Parcel parcel, int i) {
        if (parcel.dataPosition() == i) {
            return;
        }
        java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(i).length() + 26);
        sb.append("Overread allowed size end=");
        sb.append(i);
        throw new defpackage.fo(sb.toString(), parcel);
    }

    public static void i(defpackage.hi hiVar) {
        if (!hiVar.isDone()) {
            defpackage.q8.g(defpackage.r20.h("Future was expected to be done: %s", hiVar));
            return;
        }
        boolean z = false;
        while (true) {
            try {
                hiVar.get();
                break;
            } catch (java.lang.InterruptedException unused) {
                z = true;
            } catch (java.lang.Throwable th) {
                if (z) {
                    java.lang.Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z) {
            java.lang.Thread.currentThread().interrupt();
        }
    }

    public static final void j(kotlin.coroutines.CoroutineContext coroutineContext, java.lang.Throwable th) {
        java.lang.Throwable runtimeException;
        java.util.Iterator it = defpackage.p6.a.iterator();
        while (it.hasNext()) {
            try {
                ((defpackage.f0) ((defpackage.o6) it.next())).c(th);
            } catch (java.lang.Throwable th2) {
                if (th == th2) {
                    runtimeException = th;
                } else {
                    runtimeException = new java.lang.RuntimeException("Exception while trying to handle coroutine exception", th2);
                    defpackage.db.a(runtimeException, th);
                }
                java.lang.Thread threadCurrentThread = java.lang.Thread.currentThread();
                threadCurrentThread.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread, runtimeException);
            }
        }
        try {
            defpackage.db.a(th, new defpackage.k9(coroutineContext));
        } catch (java.lang.Throwable unused) {
        }
        java.lang.Thread threadCurrentThread2 = java.lang.Thread.currentThread();
        threadCurrentThread2.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread2, th);
    }

    public static java.nio.MappedByteBuffer k(android.content.Context context, android.net.Uri uri) throws java.io.IOException {
        android.os.ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor;
        try {
            parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", null);
        } catch (java.io.IOException unused) {
        }
        if (parcelFileDescriptorOpenFileDescriptor == null) {
            if (parcelFileDescriptorOpenFileDescriptor != null) {
                parcelFileDescriptorOpenFileDescriptor.close();
                return null;
            }
            return null;
        }
        try {
            java.io.FileInputStream fileInputStream = new java.io.FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
            try {
                java.nio.channels.FileChannel channel = fileInputStream.getChannel();
                java.nio.MappedByteBuffer map = channel.map(java.nio.channels.FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                fileInputStream.close();
                parcelFileDescriptorOpenFileDescriptor.close();
                return map;
            } finally {
            }
        } finally {
        }
    }

    public static java.lang.String l(java.lang.String str, java.util.List list) throws java.io.UnsupportedEncodingException {
        list.getClass();
        str.getClass();
        java.lang.StringBuilder sb = new java.lang.StringBuilder();
        java.util.Iterator it = list.iterator();
        while (it.hasNext()) {
            kotlin.Pair pair = (kotlin.Pair) it.next();
            java.lang.String str2 = (java.lang.String) pair.d;
            java.lang.String str3 = (java.lang.String) pair.e;
            if (str3.length() != 0) {
                if (sb.length() > 0) {
                    sb.append('&');
                }
                java.lang.String strEncode = java.net.URLEncoder.encode(str2, "UTF-8");
                strEncode.getClass();
                sb.append(strEncode);
                sb.append('=');
                java.lang.String strEncode2 = java.net.URLEncoder.encode(str3, "UTF-8");
                strEncode2.getClass();
                sb.append(strEncode2);
            }
        }
        java.lang.String string = kotlin.text.StringsKt.j(str).toString();
        char[] cArr = {'?', '&'};
        string.getClass();
        int length = string.length() - 1;
        int i = 0;
        boolean z = false;
        while (i <= length) {
            char cCharAt = string.charAt(!z ? i : length);
            int i2 = 0;
            while (true) {
                if (i2 >= 2) {
                    i2 = -1;
                    break;
                }
                if (cCharAt == cArr[i2]) {
                    break;
                }
                i2++;
            }
            boolean z2 = i2 >= 0;
            if (z) {
                if (!z2) {
                    break;
                }
                length--;
            } else if (z2) {
                i++;
            } else {
                z = true;
            }
        }
        java.lang.String string2 = string.subSequence(i, length + 1).toString();
        if (string2.length() > 0) {
            if (sb.length() > 0) {
                sb.append('&');
            }
            sb.append(string2);
        }
        return sb.toString();
    }

    public static boolean m(android.os.Parcel parcel, int i) {
        x(parcel, i, 4);
        return parcel.readInt() != 0;
    }

    public static android.os.IBinder n(android.os.Parcel parcel, int i) {
        int iQ = q(parcel, i);
        int iDataPosition = parcel.dataPosition();
        if (iQ == 0) {
            return null;
        }
        android.os.IBinder strongBinder = parcel.readStrongBinder();
        parcel.setDataPosition(iDataPosition + iQ);
        return strongBinder;
    }

    public static int o(android.os.Parcel parcel, int i) {
        x(parcel, i, 4);
        return parcel.readInt();
    }

    public static long p(android.os.Parcel parcel, int i) {
        x(parcel, i, 8);
        return parcel.readLong();
    }

    public static int q(android.os.Parcel parcel, int i) {
        return (i & (-65536)) != -65536 ? (char) (i >> 16) : parcel.readInt();
    }

    public static final void r(defpackage.c6 c6Var, kotlin.Unit unit) {
        if (!(c6Var instanceof defpackage.p9)) {
            c6Var.e(unit);
            return;
        }
        defpackage.p9 p9Var = (defpackage.p9) c6Var;
        defpackage.n6 n6Var = p9Var.m;
        defpackage.e6 e6Var = p9Var.n;
        kotlin.coroutines.CoroutineContext coroutineContext = e6Var.e;
        java.lang.Throwable thA = defpackage.nn.a(unit);
        java.lang.Object d5Var = thA == null ? unit : new defpackage.d5(thA);
        e6Var.c();
        if (n6Var.e()) {
            p9Var.o = d5Var;
            p9Var.i = 1;
            coroutineContext.getClass();
            n6Var.c(coroutineContext, p9Var);
            return;
        }
        defpackage.bb bbVarA = defpackage.uq.a();
        if (bbVarA.i >= 4294967296L) {
            p9Var.o = d5Var;
            p9Var.i = 1;
            defpackage.p0 p0Var = bbVarA.n;
            if (p0Var == null) {
                p0Var = new defpackage.p0();
                bbVarA.n = p0Var;
            }
            p0Var.addLast(p9Var);
            return;
        }
        bbVarA.k(true);
        try {
            coroutineContext.getClass();
            defpackage.sg sgVar = (defpackage.sg) coroutineContext.b(defpackage.pe.p);
            if (sgVar == null || sgVar.a()) {
                java.lang.Object obj = p9Var.p;
                coroutineContext.getClass();
                java.lang.Object objB = defpackage.tq.b(coroutineContext, obj);
                if (objB != defpackage.tq.a) {
                    defpackage.bg.m(e6Var, coroutineContext);
                }
                try {
                    e6Var.e(unit);
                } finally {
                    defpackage.tq.a(coroutineContext, objB);
                }
            } else {
                java.util.concurrent.CancellationException cancellationExceptionN = ((defpackage.bh) sgVar).n();
                p9Var.b(d5Var, cancellationExceptionN);
                p9Var.e(new defpackage.mn(cancellationExceptionN));
            }
            while (bbVarA.n()) {
            }
        } finally {
            try {
            } finally {
            }
        }
    }

    public static void s(android.os.Parcel parcel, int i) {
        parcel.setDataPosition(parcel.dataPosition() + q(parcel, i));
    }

    public static int t(android.os.Parcel parcel) {
        int i = parcel.readInt();
        int iQ = q(parcel, i);
        char c2 = (char) i;
        int iDataPosition = parcel.dataPosition();
        if (c2 != 20293) {
            throw new defpackage.fo("Expected object header. Got 0x".concat(java.lang.String.valueOf(java.lang.Integer.toHexString(i))), parcel);
        }
        int i2 = iQ + iDataPosition;
        if (i2 >= iDataPosition && i2 <= parcel.dataSize()) {
            return i2;
        }
        java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(iDataPosition).length() + 32 + java.lang.String.valueOf(i2).length());
        sb.append("Size read is invalid start=");
        sb.append(iDataPosition);
        sb.append(" end=");
        sb.append(i2);
        throw new defpackage.fo(sb.toString(), parcel);
    }

    public static defpackage.zk u(android.content.Context context) {
        java.io.File file;
        defpackage.zk glVar = defpackage.a.d;
        android.os.StrictMode.ThreadPolicy threadPolicyAllowThreadDiskReads = android.os.StrictMode.allowThreadDiskReads();
        try {
            android.os.StrictMode.allowThreadDiskWrites();
            try {
                file = new java.io.File(context.getDir("phenotype_hermetic", 0), "overrides.txt");
            } catch (java.lang.RuntimeException e) {
                android.util.Log.e("HermeticFileOverrides", "no data dir", e);
            }
            defpackage.zk glVar2 = file.exists() ? new defpackage.gl(file) : glVar;
            if (glVar2.b()) {
                glVar = new defpackage.gl(v(context, (java.io.File) glVar2.a()));
            }
            return glVar;
        } finally {
            android.os.StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskReads);
        }
    }

    public static defpackage.i30 v(android.content.Context context, java.io.File file) throws java.io.IOException {
        try {
            java.io.BufferedReader bufferedReader = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(file)));
            try {
                defpackage.dp dpVar = new defpackage.dp(0);
                java.util.HashMap map = new java.util.HashMap();
                while (true) {
                    java.lang.String line = bufferedReader.readLine();
                    if (line == null) {
                        android.util.Log.w("HermeticFileOverrides", "Parsed " + java.lang.String.valueOf(file) + " for Android package " + context.getPackageName());
                        defpackage.i30 i30Var = new defpackage.i30(dpVar);
                        bufferedReader.close();
                        return i30Var;
                    }
                    java.lang.String[] strArrSplit = line.split(" ", 3);
                    if (strArrSplit.length != 3) {
                        android.util.Log.e("HermeticFileOverrides", "Invalid: " + line);
                    } else {
                        java.lang.String str = new java.lang.String(strArrSplit[0]);
                        java.lang.String strDecode = android.net.Uri.decode(new java.lang.String(strArrSplit[1]));
                        java.lang.String strDecode2 = (java.lang.String) map.get(strArrSplit[2]);
                        if (strDecode2 == null) {
                            java.lang.String str2 = new java.lang.String(strArrSplit[2]);
                            strDecode2 = android.net.Uri.decode(str2);
                            if (strDecode2.length() < 1024 || strDecode2 == str2) {
                                map.put(str2, strDecode2);
                            }
                        }
                        defpackage.dp dpVar2 = (defpackage.dp) dpVar.get(str);
                        if (dpVar2 == null) {
                            dpVar2 = new defpackage.dp(0);
                            dpVar.put(str, dpVar2);
                        }
                        dpVar2.put(strDecode, strDecode2);
                    }
                }
            } finally {
            }
        } catch (java.io.IOException e) {
            throw new java.lang.RuntimeException(e);
        }
    }

    public static void w(int i, java.util.List list, defpackage.zd zdVar, boolean z) {
        if (list == null || list.isEmpty()) {
            return;
        }
        defpackage.f50 f50Var = (defpackage.f50) zdVar.e;
        if (list instanceof defpackage.t40) {
            defpackage.mr.a();
            return;
        }
        if (!z) {
            for (int i2 = 0; i2 < list.size(); i2++) {
                boolean zBooleanValue = ((java.lang.Boolean) list.get(i2)).booleanValue();
                f50Var.o(i, 0);
                f50Var.a(zBooleanValue ? (byte) 1 : (byte) 0);
            }
            return;
        }
        f50Var.o(i, 2);
        int i3 = 0;
        for (int i4 = 0; i4 < list.size(); i4++) {
            ((java.lang.Boolean) list.get(i4)).getClass();
            i3++;
        }
        f50Var.n(i3);
        for (int i5 = 0; i5 < list.size(); i5++) {
            f50Var.a(((java.lang.Boolean) list.get(i5)).booleanValue() ? (byte) 1 : (byte) 0);
        }
    }

    public static void x(android.os.Parcel parcel, int i, int i2) {
        int iQ = q(parcel, i);
        if (iQ == i2) {
            return;
        }
        java.lang.String hexString = java.lang.Integer.toHexString(iQ);
        int length = java.lang.String.valueOf(i2).length();
        java.lang.StringBuilder sb = new java.lang.StringBuilder(java.lang.String.valueOf(hexString).length() + length + 19 + java.lang.String.valueOf(iQ).length() + 4 + 1);
        sb.append("Expected size ");
        sb.append(i2);
        sb.append(" got ");
        sb.append(iQ);
        sb.append(" (0x");
        sb.append(hexString);
        sb.append(")");
        throw new defpackage.fo(sb.toString(), parcel);
    }

    public static void y(java.lang.Object obj, java.lang.Object obj2) {
        defpackage.a60 a60Var = (defpackage.a60) obj;
        defpackage.w70 w70Var = a60Var.zzb;
        defpackage.w70 w70Var2 = ((defpackage.a60) obj2).zzb;
        defpackage.w70 w70Var3 = defpackage.w70.f;
        if (!w70Var3.equals(w70Var2)) {
            if (w70Var3.equals(w70Var)) {
                int i = w70Var.a + w70Var2.a;
                int[] iArrCopyOf = java.util.Arrays.copyOf(w70Var.b, i);
                java.lang.System.arraycopy(w70Var2.b, 0, iArrCopyOf, w70Var.a, w70Var2.a);
                java.lang.Object[] objArrCopyOf = java.util.Arrays.copyOf(w70Var.c, i);
                java.lang.System.arraycopy(w70Var2.c, 0, objArrCopyOf, w70Var.a, w70Var2.a);
                w70Var = new defpackage.w70(i, iArrCopyOf, objArrCopyOf, true);
            } else {
                w70Var.getClass();
                if (!w70Var2.equals(w70Var3)) {
                    if (!w70Var.e) {
                        defpackage.mr.e();
                        return;
                    }
                    int i2 = w70Var.a + w70Var2.a;
                    w70Var.b(i2);
                    java.lang.System.arraycopy(w70Var2.b, 0, w70Var.b, w70Var.a, w70Var2.a);
                    java.lang.System.arraycopy(w70Var2.c, 0, w70Var.c, w70Var.a, w70Var2.a);
                    w70Var.a = i2;
                }
            }
        }
        a60Var.zzb = w70Var;
    }

    public static boolean z(java.lang.Object obj, java.lang.Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }
}
