package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class h1 implements java.lang.Runnable {
    public final /* synthetic */ byte d;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ java.lang.Object i;
    public final /* synthetic */ java.lang.Object m;

    public /* synthetic */ h1(byte b, java.lang.Object obj, java.lang.Object obj2, boolean z) {
        this.d = b;
        this.i = obj;
        this.e = z;
        this.m = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.d) {
            case 0:
                java.lang.String[] strArr = (java.lang.String[]) this.i;
                boolean z = this.e;
                java.util.concurrent.CountDownLatch countDownLatch = (java.util.concurrent.CountDownLatch) this.m;
                java.lang.String str = "";
                if (z) {
                    java.lang.String str2 = defpackage.fr.a;
                    try {
                        defpackage.ln lnVar = defpackage.nn.d;
                        defpackage.fr.b.await(10000L, java.util.concurrent.TimeUnit.MILLISECONDS);
                    } catch (java.lang.Throwable unused) {
                        defpackage.ln lnVar2 = defpackage.nn.d;
                    }
                    java.lang.String str3 = defpackage.fr.a;
                    if (str3 != null) {
                        str = str3;
                    }
                }
                strArr[2] = str;
                countDownLatch.countDown();
                return;
            default:
                android.content.Context context = (android.content.Context) this.i;
                boolean z2 = this.e;
                defpackage.iq iqVar = (defpackage.iq) this.m;
                try {
                    if (android.os.Binder.getCallingUid() == context.getApplicationInfo().uid) {
                        android.content.SharedPreferences.Editor editorEdit = defpackage.z7.i(context).edit();
                        editorEdit.putBoolean("proxy_notification_initialized", true);
                        editorEdit.apply();
                        android.app.NotificationManager notificationManager = (android.app.NotificationManager) context.getSystemService(android.app.NotificationManager.class);
                        if (z2) {
                            notificationManager.setNotificationDelegate("com.google.android.gms");
                        } else if ("com.google.android.gms".equals(notificationManager.getNotificationDelegate())) {
                            notificationManager.setNotificationDelegate(null);
                        }
                    } else {
                        android.util.Log.e("FirebaseMessaging", "error configuring notification delegate for package " + context.getPackageName());
                    }
                    return;
                } finally {
                    iqVar.c(null);
                }
        }
    }
}
