package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class f1 implements java.lang.Runnable {
    public final /* synthetic */ byte d;
    public final /* synthetic */ java.lang.Object e;
    public final /* synthetic */ java.lang.Object i;
    public final /* synthetic */ java.lang.Object m;

    public /* synthetic */ f1(defpackage.m8 m8Var, defpackage.b3 b3Var, defpackage.q8 q8Var, defpackage.i2 i2Var) {
        this.d = (byte) 2;
        this.e = m8Var;
        this.i = b3Var;
        this.m = i2Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.d) {
            case 0:
                java.lang.String[] strArr = (java.lang.String[]) this.e;
                android.content.Context context = (android.content.Context) this.i;
                java.util.concurrent.CountDownLatch countDownLatch = (java.util.concurrent.CountDownLatch) this.m;
                context.getClass();
                java.lang.String str = "";
                try {
                    defpackage.y yVarA = defpackage.z.a(context);
                    if (!yVarA.c) {
                        java.lang.String str2 = (java.lang.String) yVarA.b;
                        if (str2 != null) {
                            str = str2;
                        }
                    }
                } catch (java.lang.Throwable unused) {
                }
                strArr[1] = str;
                countDownLatch.countDown();
                return;
            case 1:
                defpackage.k1.a((defpackage.pm) this.e, (defpackage.g1) this.i, (com.android.installreferrer.api.InstallReferrerClient) this.m, "");
                return;
            case 2:
                defpackage.m8 m8Var = (defpackage.m8) this.e;
                defpackage.b3 b3Var = (defpackage.b3) this.i;
                java.lang.String str3 = b3Var.a;
                defpackage.i2 i2Var = (defpackage.i2) this.m;
                m8Var.getClass();
                java.util.logging.Logger logger = defpackage.m8.f;
                try {
                    defpackage.ir irVarA = m8Var.c.a(str3);
                    if (irVarA == null) {
                        java.lang.String str4 = "Transport backend '" + str3 + "' is not registered";
                        logger.warning(str4);
                        new java.lang.IllegalArgumentException(str4);
                    } else {
                        m8Var.e.f(new defpackage.k8((java.lang.Object) m8Var, (java.lang.Object) b3Var, (java.lang.Object) ((defpackage.b4) irVarA).a(i2Var), (byte) 0));
                    }
                    return;
                } catch (java.lang.Exception e) {
                    logger.warning("Error scheduling event " + e.getMessage());
                    return;
                }
            case 3:
                defpackage.u7 u7Var = (defpackage.u7) this.e;
                defpackage.x7 x7Var = (defpackage.x7) this.i;
                java.util.concurrent.ThreadPoolExecutor threadPoolExecutor = (java.util.concurrent.ThreadPoolExecutor) this.m;
                try {
                    defpackage.uc ucVarB = defpackage.b30.b(u7Var.d);
                    if (ucVarB == null) {
                        throw new java.lang.RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    defpackage.tc tcVar = (defpackage.tc) ucVarB.a;
                    synchronized (tcVar.i) {
                        tcVar.n = threadPoolExecutor;
                    }
                    ucVarB.a.a(new defpackage.fa(x7Var, threadPoolExecutor));
                    return;
                } catch (java.lang.Throwable th) {
                    x7Var.e(th);
                    threadPoolExecutor.shutdown();
                    return;
                }
            case 4:
                defpackage.va vaVar = (defpackage.va) this.e;
                android.content.Intent intent = (android.content.Intent) this.i;
                defpackage.iq iqVar = (defpackage.iq) this.m;
                try {
                    vaVar.handleIntent(intent);
                    return;
                } finally {
                    iqVar.a(null);
                }
            case 5:
                ((com.google.androidbrowserhelper.trusted.TwaLauncher) this.e).lambda$launchWhenSessionEstablished$4((androidx.browser.trusted.TrustedWebActivityIntentBuilder) this.i, (java.lang.Runnable) this.m);
                return;
            case 6:
                ((com.appsflyer.internal.AFb1rSDK) this.e).i_((android.content.Context) this.i, (android.content.Intent) this.m);
                return;
            case androidx.browser.trusted.ScreenOrientation.PORTRAIT /* 7 */:
                com.appsflyer.internal.AFd1fSDK.getMonetizationNetwork((com.appsflyer.internal.AFd1fSDK) this.e, (java.lang.Throwable) this.i, (java.lang.String) this.m);
                return;
            default:
                ((com.appsflyer.internal.AFj1sSDK) this.e).AFAdRevenueData((com.appsflyer.internal.AFi1eSDK) this.i, (java.lang.Runnable) this.m);
                return;
        }
    }

    public /* synthetic */ f1(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, byte b) {
        this.d = b;
        this.e = obj;
        this.i = obj2;
        this.m = obj3;
    }
}
