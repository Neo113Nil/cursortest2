package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class m7 {
    public final android.content.Intent a = new android.content.Intent("android.intent.action.VIEW");
    public final defpackage.j0 b = new defpackage.j0((byte) 6);
    public android.app.ActivityOptions c;
    public android.util.SparseArray d;
    public android.os.Bundle e;

    public final defpackage.n7 a() {
        android.content.Intent intent = this.a;
        if (!intent.hasExtra("android.support.customtabs.extra.SESSION")) {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putBinder("android.support.customtabs.extra.SESSION", null);
            intent.putExtras(bundle);
        }
        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
        defpackage.j0 j0Var = this.b;
        java.lang.Integer num = (java.lang.Integer) j0Var.e;
        java.lang.Integer num2 = (java.lang.Integer) j0Var.i;
        java.lang.Integer num3 = (java.lang.Integer) j0Var.m;
        android.os.Bundle bundle2 = new android.os.Bundle();
        if (num != null) {
            bundle2.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", num.intValue());
        }
        if (num2 != null) {
            bundle2.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR", num2.intValue());
        }
        if (num3 != null) {
            bundle2.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR", num3.intValue());
        }
        intent.putExtras(bundle2);
        android.os.Bundle bundle3 = this.e;
        if (bundle3 != null) {
            intent.putExtras(bundle3);
        }
        if (this.d != null) {
            android.os.Bundle bundle4 = new android.os.Bundle();
            bundle4.putSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS", this.d);
            intent.putExtras(bundle4);
        }
        intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 0);
        android.os.LocaleList adjustedDefault = android.os.LocaleList.getAdjustedDefault();
        java.lang.String languageTag = adjustedDefault.size() > 0 ? adjustedDefault.get(0).toLanguageTag() : null;
        if (!android.text.TextUtils.isEmpty(languageTag)) {
            android.os.Bundle bundleExtra = intent.hasExtra("com.android.browser.headers") ? intent.getBundleExtra("com.android.browser.headers") : new android.os.Bundle();
            if (!bundleExtra.containsKey("Accept-Language")) {
                bundleExtra.putString("Accept-Language", languageTag);
                intent.putExtra("com.android.browser.headers", bundleExtra);
            }
        }
        int i = android.os.Build.VERSION.SDK_INT;
        if (i >= 34) {
            android.app.ActivityOptions activityOptionsMakeBasic = this.c;
            if (activityOptionsMakeBasic == null) {
                activityOptionsMakeBasic = android.app.ActivityOptions.makeBasic();
                this.c = activityOptionsMakeBasic;
            }
            defpackage.k7.a(activityOptionsMakeBasic);
        }
        if (i >= 36) {
            if (this.c == null) {
                this.c = android.app.ActivityOptions.makeBasic();
            }
            defpackage.l7.a(this.c, !intent.getBooleanExtra("androidx.browser.customtabs.extra.DISABLE_BACKGROUND_INTERACTION", false));
        }
        android.app.ActivityOptions activityOptions = this.c;
        return new defpackage.n7(intent, activityOptions != null ? activityOptions.toBundle() : null);
    }
}
