package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public abstract class fr {
    public static volatile java.lang.String a;
    public static final java.util.concurrent.CountDownLatch b = new java.util.concurrent.CountDownLatch(1);
}
