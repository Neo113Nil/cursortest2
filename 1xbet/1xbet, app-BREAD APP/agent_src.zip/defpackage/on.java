package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class on implements defpackage.m5, defpackage.d6, defpackage.y60, defpackage.dm, defpackage.ml, com.appsflyer.AppsFlyerConversionListener, kotlin.coroutines.g, defpackage.sv, defpackage.y00 {
    public static defpackage.on e;
    public static final defpackage.on i = new defpackage.on((byte) 1);
    public static final defpackage.on m = new defpackage.on((byte) 2);
    public static final defpackage.on n = new defpackage.on((byte) 3);
    public static final defpackage.on o = new defpackage.on((byte) 4);
    public static final defpackage.on p = new defpackage.on((byte) 5);
    public static final defpackage.on q = new defpackage.on((byte) 6);
    public static final /* synthetic */ defpackage.on r = new defpackage.on((byte) 7);
    public static final defpackage.on s = new defpackage.on((byte) 8);
    public static defpackage.on t;
    public final /* synthetic */ byte d;

    public on(defpackage.q30 q30Var) {
        this.d = (byte) 13;
        new java.util.concurrent.CopyOnWriteArrayList();
    }

    @Override // defpackage.y00
    public java.lang.Object a() {
        switch (this.d) {
            case 24:
                defpackage.u80.e.get();
                java.lang.Long l = (java.lang.Long) defpackage.x80.a.a();
                l.getClass();
                return l;
            case 25:
                defpackage.k90.e.get();
                java.lang.Boolean bool = (java.lang.Boolean) defpackage.n90.a.a();
                bool.getClass();
                return bool;
            case 26:
                defpackage.ib0.e.get();
                java.lang.Boolean bool2 = (java.lang.Boolean) defpackage.kb0.d.a();
                bool2.getClass();
                return bool2;
            case 27:
                defpackage.ib0.e.get();
                java.lang.Boolean bool3 = (java.lang.Boolean) defpackage.kb0.i.a();
                bool3.getClass();
                return bool3;
            case 28:
                defpackage.ib0.e.get();
                java.lang.Boolean bool4 = (java.lang.Boolean) defpackage.kb0.g.a();
                bool4.getClass();
                return bool4;
            default:
                defpackage.u80.e.get();
                return java.lang.Integer.valueOf((int) ((java.lang.Long) defpackage.x80.Q.a()).longValue());
        }
    }

    @Override // defpackage.sv
    public java.lang.String b(java.lang.String str, java.lang.String str2) {
        return null;
    }

    @Override // defpackage.m5
    public java.lang.Object c(defpackage.n8 n8Var) {
        switch (this.d) {
            case 2:
                java.lang.Object objF = n8Var.f(new defpackage.km(defpackage.d3.class, java.util.concurrent.Executor.class));
                objF.getClass();
                return new defpackage.fb((java.util.concurrent.Executor) objF);
            case 3:
                java.lang.Object objF2 = n8Var.f(new defpackage.km(defpackage.ei.class, java.util.concurrent.Executor.class));
                objF2.getClass();
                return new defpackage.fb((java.util.concurrent.Executor) objF2);
            case 4:
                java.lang.Object objF3 = n8Var.f(new defpackage.km(defpackage.m3.class, java.util.concurrent.Executor.class));
                objF3.getClass();
                return new defpackage.fb((java.util.concurrent.Executor) objF3);
            default:
                java.lang.Object objF4 = n8Var.f(new defpackage.km(defpackage.as.class, java.util.concurrent.Executor.class));
                objF4.getClass();
                return new defpackage.fb((java.util.concurrent.Executor) objF4);
        }
    }

    public java.util.List d(com.google.firebase.components.ComponentRegistrar componentRegistrar) {
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (defpackage.i5 i5Var : componentRegistrar.getComponents()) {
            java.lang.String str = i5Var.a;
            if (str != null) {
                defpackage.n5 n5Var = new defpackage.n5(str, i5Var, (byte) 0);
                java.util.Set set = i5Var.b;
                java.util.Set set2 = i5Var.c;
                byte b = i5Var.d;
                boolean z = i5Var.e;
                i5Var = new defpackage.i5(str, set, set2, b, z ? 1 : 0, n5Var, i5Var.g);
            }
            arrayList.add(i5Var);
        }
        return arrayList;
    }

    @Override // defpackage.y60
    public defpackage.q70 e(java.lang.Class cls) {
        if (!defpackage.a60.class.isAssignableFrom(cls)) {
            defpackage.q8.b("Unsupported message type: ".concat(cls.getName()));
            return null;
        }
        try {
            return (defpackage.q70) defpackage.a60.e(cls.asSubclass(defpackage.a60.class)).c(3);
        } catch (java.lang.Exception e2) {
            throw new java.lang.RuntimeException("Unable to get message info for ".concat(cls.getName()), e2);
        }
    }

    @Override // defpackage.y60
    public boolean f(java.lang.Class cls) {
        return defpackage.a60.class.isAssignableFrom(cls);
    }

    @Override // defpackage.ml
    public void g() {
        android.util.Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    @Override // defpackage.dm
    public java.lang.Object get() {
        switch (this.d) {
            case 12:
                return new defpackage.eo(java.util.concurrent.Executors.newSingleThreadExecutor(), (byte) 0);
            default:
                defpackage.pe peVar = new defpackage.pe((byte) 22);
                java.util.HashMap map = new java.util.HashMap();
                java.util.Set set = java.util.Collections.EMPTY_SET;
                if (set == null) {
                    defpackage.mr.d("Null flags");
                    return null;
                }
                map.put(defpackage.hl.d, new defpackage.x2(30000L, 86400000L, set));
                if (set == null) {
                    defpackage.mr.d("Null flags");
                    return null;
                }
                map.put(defpackage.hl.i, new defpackage.x2(1000L, 86400000L, set));
                if (set == null) {
                    defpackage.mr.d("Null flags");
                    return null;
                }
                java.util.Set setUnmodifiableSet = java.util.Collections.unmodifiableSet(new java.util.HashSet(java.util.Arrays.asList(defpackage.oo.e)));
                if (setUnmodifiableSet == null) {
                    defpackage.mr.d("Null flags");
                    return null;
                }
                map.put(defpackage.hl.e, new defpackage.x2(86400000L, 86400000L, setUnmodifiableSet));
                if (map.keySet().size() >= defpackage.hl.values().length) {
                    new java.util.HashMap();
                    return new defpackage.w2(peVar, map);
                }
                defpackage.q8.g("Not all priorities have been configured");
                return null;
        }
    }

    @Override // defpackage.d6
    public java.lang.Object h(com.google.android.gms.tasks.Task task) throws java.io.IOException {
        if (task.l()) {
            return (android.os.Bundle) task.h();
        }
        if (android.util.Log.isLoggable("Rpc", 3)) {
            android.util.Log.d("Rpc", "Error making request: ".concat(java.lang.String.valueOf(task.g())));
        }
        throw new java.io.IOException("SERVICE_NOT_AVAILABLE", task.g());
    }

    @Override // defpackage.ml
    public void i(int i2, java.lang.Object obj) {
        java.lang.String str;
        switch (i2) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case 2:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case 3:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case 4:
                str = "RESULT_NOT_WRITABLE";
                break;
            case 5:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case 6:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case androidx.browser.trusted.ScreenOrientation.PORTRAIT /* 7 */:
                str = "RESULT_IO_EXCEPTION";
                break;
            case androidx.browser.trusted.ScreenOrientation.NATURAL /* 8 */:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 9:
            default:
                str = "";
                break;
            case com.appsflyer.attribution.RequestError.EVENT_TIMEOUT /* 10 */:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case com.appsflyer.attribution.RequestError.STOP_TRACKING /* 11 */:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i2 == 6 || i2 == 7 || i2 == 8) {
            android.util.Log.e("ProfileInstaller", str, (java.lang.Throwable) obj);
        } else {
            android.util.Log.d("ProfileInstaller", str);
        }
    }

    @Override // com.appsflyer.AppsFlyerConversionListener
    public void onConversionDataFail(java.lang.String str) {
        defpackage.fr.b.countDown();
    }

    @Override // com.appsflyer.AppsFlyerConversionListener
    public void onConversionDataSuccess(java.util.Map map) {
        java.lang.String str = defpackage.fr.a;
        java.lang.String str2 = null;
        java.lang.Object obj = map != null ? map.get(com.novasport.rivals.play.MainActivity.KEY_CAMPAIGN) : null;
        java.lang.String str3 = obj instanceof java.lang.String ? (java.lang.String) obj : null;
        if (str3 != null && !kotlin.text.StringsKt.f(str3) && !str3.equalsIgnoreCase("None")) {
            str2 = str3;
        }
        defpackage.fr.a = str2;
        defpackage.fr.b.countDown();
    }

    public /* synthetic */ on(byte b) {
        this.d = b;
    }

    public on(defpackage.o9 o9Var) {
        this.d = (byte) 11;
    }

    @Override // com.appsflyer.AppsFlyerConversionListener
    public void onAppOpenAttribution(java.util.Map map) {
    }

    @Override // com.appsflyer.AppsFlyerConversionListener
    public void onAttributionFailure(java.lang.String str) {
    }
}
