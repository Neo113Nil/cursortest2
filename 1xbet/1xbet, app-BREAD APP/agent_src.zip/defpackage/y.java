package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class y {
    public final /* synthetic */ byte a;
    public final java.lang.Object b;
    public final boolean c;

    public y() {
        this.a = (byte) 2;
        this.c = true;
        this.b = java.util.Collections.singletonList(null);
    }

    public java.lang.String toString() {
        switch (this.a) {
            case 0:
                java.lang.String str = (java.lang.String) this.b;
                int length = java.lang.String.valueOf(str).length();
                boolean z = this.c;
                java.lang.StringBuilder sb = new java.lang.StringBuilder(length + 2 + java.lang.String.valueOf(z).length());
                sb.append("{");
                sb.append(str);
                sb.append("}");
                sb.append(z);
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public /* synthetic */ y(java.lang.String str, boolean z, byte b) {
        this.a = b;
        this.b = str;
        this.c = z;
    }

    public y(java.util.ArrayList arrayList) {
        this.a = (byte) 2;
        this.c = false;
        this.b = arrayList;
    }
}
