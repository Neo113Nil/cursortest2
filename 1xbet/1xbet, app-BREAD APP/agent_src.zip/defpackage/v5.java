package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public abstract /* synthetic */ class v5 {
    public static final /* synthetic */ int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    public static int a(int i) {
        if (i == 0) {
            return 1;
        }
        if (i == 1) {
            return 2;
        }
        if (i == 2) {
            return 3;
        }
        if (i != 3) {
            return i != 4 ? 0 : 5;
        }
        return 4;
    }

    public static int b(int i) {
        if (i == 0) {
            return 1;
        }
        if (i == 1) {
            return 2;
        }
        if (i == 2) {
            return 3;
        }
        if (i != 3) {
            return i != 4 ? 0 : 5;
        }
        return 4;
    }

    public static int c(int i) {
        if (i == 0) {
            return 1;
        }
        if (i == 1) {
            return 2;
        }
        if (i == 2) {
            return 3;
        }
        if (i != 3) {
            return i != 4 ? 0 : 5;
        }
        return 4;
    }

    public static /* synthetic */ boolean d(int i, int i2) {
        if (i != 0) {
            return i == i2;
        }
        throw null;
    }

    public static int e(int i, int i2, int i3) {
        return defpackage.f50.t(i) + i2 + i3;
    }

    public static java.lang.String f(int i, java.lang.String str) {
        return str + i;
    }

    public static java.lang.String g(java.lang.String str, java.lang.String str2) {
        return str + str2;
    }

    public static java.lang.String h(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        return str + str2 + str3;
    }

    public static java.lang.String i(java.lang.StringBuilder sb, java.lang.String str, java.lang.String str2) {
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    public static java.util.HashMap j(java.lang.Class cls, defpackage.c1 c1Var) {
        java.util.HashMap map = new java.util.HashMap();
        map.put(cls, c1Var);
        return map;
    }

    public static java.util.Map k(java.util.HashMap map) {
        return java.util.Collections.unmodifiableMap(new java.util.HashMap(map));
    }

    public static /* synthetic */ void l(java.lang.Object obj) {
        if (obj == null) {
            return;
        }
        defpackage.mr.a();
    }

    public static /* synthetic */ int m(int i) {
        if (i != 0) {
            return i - 1;
        }
        throw null;
    }

    public static /* synthetic */ int[] n(int i) {
        int[] iArr = new int[i];
        java.lang.System.arraycopy(a, 0, iArr, 0, i);
        return iArr;
    }
}
