package defpackage;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class n7 {
    public final android.content.Intent a;
    public final android.os.Bundle b;

    public n7(android.content.Intent intent, android.os.Bundle bundle) {
        this.a = intent;
        this.b = bundle;
    }

    public static defpackage.a7 a(android.content.Intent intent, int i) {
        android.os.Bundle bundle;
        if (i < 0 || i > 2 || i == 0) {
            defpackage.q8.b(defpackage.v5.f(i, "Invalid colorScheme: "));
            return null;
        }
        android.os.Bundle extras = intent.getExtras();
        if (extras == null) {
            return defpackage.a7.a(null);
        }
        defpackage.a7 a7VarA = defpackage.a7.a(extras);
        android.util.SparseArray sparseParcelableArray = extras.getSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS");
        if (sparseParcelableArray == null || (bundle = (android.os.Bundle) sparseParcelableArray.get(i)) == null) {
            return a7VarA;
        }
        defpackage.a7 a7VarA2 = defpackage.a7.a(bundle);
        java.lang.Integer num = a7VarA2.a;
        if (num == null) {
            num = a7VarA.a;
        }
        java.lang.Integer num2 = a7VarA2.b;
        if (num2 == null) {
            num2 = a7VarA.b;
        }
        java.lang.Integer num3 = a7VarA2.c;
        if (num3 == null) {
            num3 = a7VarA.c;
        }
        java.lang.Integer num4 = a7VarA2.d;
        if (num4 == null) {
            num4 = a7VarA.d;
        }
        return new defpackage.a7(num, num2, num3, num4);
    }
}
