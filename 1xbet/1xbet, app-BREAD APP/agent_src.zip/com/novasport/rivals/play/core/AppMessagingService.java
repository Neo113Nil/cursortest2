package com.novasport.rivals.play.core;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final class AppMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public final void onMessageReceived(defpackage.bn bnVar) {
        java.lang.String str;
        java.lang.String str2;
        bnVar.getClass();
        super.onMessageReceived(bnVar);
        android.os.Bundle bundle = bnVar.d;
        if (bnVar.i == null && defpackage.zd.t(bundle)) {
            bnVar.i = new defpackage.q30(new defpackage.zd(bundle));
        }
        defpackage.q30 q30Var = bnVar.i;
        if ((q30Var == null || (str = (java.lang.String) q30Var.e) == null) && (str = (java.lang.String) ((defpackage.v0) bnVar.b()).get("title")) == null) {
            str = "Notification";
        }
        if (bnVar.i == null && defpackage.zd.t(bundle)) {
            bnVar.i = new defpackage.q30(new defpackage.zd(bundle));
        }
        defpackage.q30 q30Var2 = bnVar.i;
        if ((q30Var2 == null || (str2 = (java.lang.String) q30Var2.i) == null) && (str2 = (java.lang.String) ((defpackage.v0) bnVar.b()).get("body")) == null && (str2 = (java.lang.String) ((defpackage.v0) bnVar.b()).get("text")) == null) {
            str2 = "";
        }
        java.lang.Object systemService = getSystemService("notification");
        systemService.getClass();
        android.app.NotificationManager notificationManager = (android.app.NotificationManager) systemService;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            defpackage.z4.m();
            notificationManager.createNotificationChannel(new android.app.NotificationChannel("default_push", "Notifications", 4));
        }
        defpackage.ok okVar = new defpackage.ok(this, "default_push");
        okVar.s.icon = com.novasport.rivals.play.R.mipmap.ic_launcher;
        okVar.e = defpackage.ok.b(str);
        okVar.f = defpackage.ok.b(str2);
        okVar.c(true);
        okVar.j = 1;
        android.app.Notification notificationA = okVar.a();
        notificationA.getClass();
        notificationManager.notify((int) java.lang.System.currentTimeMillis(), notificationA);
    }
}
