package com.novasport.rivals.play;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class App extends android.app.Application {
    @Override // android.app.Application
    public final void onCreate() {
        com.google.firebase.messaging.FirebaseMessaging firebaseMessaging;
        super.onCreate();
        java.lang.String str = defpackage.fr.a;
        android.content.Context applicationContext = getApplicationContext();
        com.appsflyer.AppsFlyerLib appsFlyerLib = com.appsflyer.AppsFlyerLib.getInstance();
        appsFlyerLib.setAppInviteOneLink("2PkS");
        appsFlyerLib.init("Fxju8uHqrWqGxz6qEeLEdM", new defpackage.on((byte) 20), applicationContext);
        appsFlyerLib.start(applicationContext);
        java.lang.String languageTag = getResources().getConfiguration().getLocales().get(0).toLanguageTag();
        languageTag.getClass();
        java.lang.String strReplace = new kotlin.text.Regex("[^a-zA-Z0-9-_.~%]").replace(languageTag, "-");
        if (kotlin.text.StringsKt.f(strReplace)) {
            strReplace = "all";
        }
        try {
            defpackage.ln lnVar = defpackage.nn.d;
            synchronized (com.google.firebase.messaging.FirebaseMessaging.class) {
                firebaseMessaging = com.google.firebase.messaging.FirebaseMessaging.getInstance(defpackage.dc.b());
            }
            defpackage.hc0 hc0Var = firebaseMessaging.h;
            defpackage.z3 z3Var = new defpackage.z3(strReplace, (byte) 1);
            hc0Var.getClass();
            hc0Var.b.c(new defpackage.l30(defpackage.kq.a, z3Var, new defpackage.hc0()));
            hc0Var.r();
        } catch (java.lang.Throwable unused) {
            defpackage.ln lnVar2 = defpackage.nn.d;
        }
    }
}
