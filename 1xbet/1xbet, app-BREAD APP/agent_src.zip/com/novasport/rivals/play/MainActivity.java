package com.novasport.rivals.play;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
@kotlin.Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 \u001f2\u00020\u0001:\u0001 B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\b\u0010\u0003J\u0017\u0010\u000b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\r\u001a\u00020\u0004H\u0014¢\u0006\u0004\b\r\u0010\u0006J\u0019\u0010\u0010\u001a\u00020\u00072\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0014¢\u0006\u0004\b\u0010\u0010\u0011J/\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00122\u000e\u0010\u0015\u001a\n\u0012\u0006\b\u0001\u0012\u00020\t0\u00142\u0006\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001b\u001a\u00020\u001aH\u0014¢\u0006\u0004\b\u001b\u0010\u001cR\u0018\u0010\u001d\u001a\u0004\u0018\u00010\u001a8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001d\u0010\u001e¨\u0006!"}, d2 = {"Lcom/novasport/rivals/play/MainActivity;", "Lcom/google/androidbrowserhelper/trusted/LauncherActivity;", "<init>", "()V", "", "needsNotificationPermission", "()Z", "", "resolveAndLaunch", "", "url", "openOffer", "(Ljava/lang/String;)V", "shouldLaunchImmediately", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "", "requestCode", "", "permissions", "", "grantResults", "onRequestPermissionsResult", "(I[Ljava/lang/String;[I)V", "Landroid/net/Uri;", "getLaunchingUrl", "()Landroid/net/Uri;", "targetUri", "Landroid/net/Uri;", "Companion", "zi", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class MainActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {
    private static final defpackage.zi Companion = new defpackage.zi();

    @java.lang.Deprecated
    public static final java.lang.String KEY_ATTRIBUTED = "attributed";

    @java.lang.Deprecated
    public static final java.lang.String KEY_CAMPAIGN = "campaign";

    @java.lang.Deprecated
    public static final java.lang.String KEY_GAME_REACHED = "game_reached";

    @java.lang.Deprecated
    public static final java.lang.String PREFS = "twa_shell";

    @java.lang.Deprecated
    public static final int REQ_NOTIFICATIONS = 4192;
    private android.net.Uri targetUri;

    private final boolean needsNotificationPermission() {
        return android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0;
    }

    private final void openOffer(java.lang.String url) {
        android.net.Uri uri = android.net.Uri.parse(url);
        try {
            defpackage.n7 n7VarA = new defpackage.m7().a();
            android.content.Intent intent = n7VarA.a;
            intent.setData(uri);
            startActivity(intent, n7VarA.b);
        } catch (java.lang.Exception unused) {
            startActivity(new android.content.Intent("android.intent.action.VIEW", uri));
        }
    }

    private final void resolveAndLaunch() {
        java.lang.String strReplace;
        android.content.SharedPreferences sharedPreferences = getSharedPreferences(PREFS, 0);
        android.net.Uri launchingUrl = super.getLaunchingUrl();
        if (sharedPreferences.getBoolean(KEY_GAME_REACHED, false)) {
            this.targetUri = launchingUrl;
            if (isFinishing() || isDestroyed()) {
                return;
            }
            launchTwa();
            return;
        }
        java.lang.String str = launchingUrl.getScheme() + "://" + launchingUrl.getHost();
        final boolean z = !sharedPreferences.getBoolean(KEY_ATTRIBUTED, false);
        try {
            java.lang.String defaultUserAgent = android.webkit.WebSettings.getDefaultUserAgent(this);
            defaultUserAgent.getClass();
            strReplace = new kotlin.text.Regex("Version/\\d+\\.\\d+\\s+").replace(kotlin.text.b.b(defaultUserAgent, "; wv", ""), "");
        } catch (java.lang.Throwable unused) {
            strReplace = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
        }
        final defpackage.yi yiVar = new defpackage.yi(sharedPreferences, this, str, strReplace, launchingUrl);
        final android.content.Context applicationContext = getApplicationContext();
        final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
        new java.lang.Thread(new java.lang.Runnable() { // from class: e1
            @Override // java.lang.Runnable
            public final void run() {
                java.util.concurrent.CountDownLatch countDownLatch = new java.util.concurrent.CountDownLatch(3);
                java.lang.String[] strArr = {"", "", ""};
                android.content.Context context = applicationContext;
                new java.lang.Thread(new defpackage.f1((java.lang.Object) strArr, (java.lang.Object) context, (java.lang.Object) countDownLatch, (byte) 0)).start();
                context.getClass();
                defpackage.g1 g1Var = new defpackage.g1(strArr, countDownLatch);
                android.os.Handler handler2 = new android.os.Handler(android.os.Looper.getMainLooper());
                com.android.installreferrer.api.InstallReferrerClient installReferrerClientBuild = com.android.installreferrer.api.InstallReferrerClient.newBuilder(context).build();
                defpackage.pm pmVar = new defpackage.pm();
                handler2.postDelayed(new defpackage.f1((java.lang.Object) pmVar, (java.lang.Object) g1Var, (java.lang.Object) installReferrerClientBuild, (byte) 1), 3000L);
                try {
                    installReferrerClientBuild.startConnection(new defpackage.j0(installReferrerClientBuild, pmVar, g1Var, (byte) 1));
                } catch (java.lang.Exception unused2) {
                    defpackage.k1.a(pmVar, g1Var, installReferrerClientBuild, "");
                }
                new java.lang.Thread(new defpackage.h1((byte) 0, strArr, countDownLatch, z)).start();
                try {
                    defpackage.ln lnVar = defpackage.nn.d;
                    countDownLatch.await(11000L, java.util.concurrent.TimeUnit.MILLISECONDS);
                } catch (java.lang.Throwable unused3) {
                    defpackage.ln lnVar2 = defpackage.nn.d;
                }
                handler.post(new defpackage.i1(yiVar, strArr, (byte) 0));
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit resolveAndLaunch$lambda$3(final android.content.SharedPreferences sharedPreferences, final com.novasport.rivals.play.MainActivity mainActivity, final java.lang.String str, final java.lang.String str2, final android.net.Uri uri, final defpackage.j1 j1Var) throws java.io.UnsupportedEncodingException {
        final java.lang.String str3;
        j1Var.getClass();
        sharedPreferences.edit().putBoolean(KEY_ATTRIBUTED, true).apply();
        java.lang.String str4 = j1Var.c;
        if (str4.length() == 0) {
            java.lang.String string = sharedPreferences.getString(KEY_CAMPAIGN, "");
            if (string == null) {
                string = "";
            }
            str3 = string;
        } else {
            str3 = str4;
        }
        if (str4.length() > 0) {
            sharedPreferences.edit().putString(KEY_CAMPAIGN, str4).apply();
        }
        mainActivity.getClass();
        android.content.SharedPreferences sharedPreferences2 = mainActivity.getApplicationContext().getSharedPreferences(PREFS, 0);
        java.lang.String string2 = sharedPreferences2.getString("user_uuid", null);
        if (string2 == null || string2.length() == 0) {
            string2 = java.util.UUID.randomUUID().toString();
            sharedPreferences2.edit().putString("user_uuid", string2).apply();
        }
        final java.lang.String str5 = string2;
        java.lang.String str6 = defpackage.fr.a;
        java.lang.String appsFlyerUID = com.appsflyer.AppsFlyerLib.getInstance().getAppsFlyerUID(mainActivity.getApplicationContext());
        final java.lang.String str7 = appsFlyerUID != null ? appsFlyerUID : "";
        final java.lang.String strL = defpackage.or.l(j1Var.a, defpackage.q4.a(new kotlin.Pair("user", str5), new kotlin.Pair("deviceIdKey", str7), new kotlin.Pair("advertisingIdKey", j1Var.b), new kotlin.Pair("campaignKey", str3)));
        new java.lang.Thread(new java.lang.Runnable() { // from class: wi
            @Override // java.lang.Runnable
            public final void run() throws java.io.IOException {
                com.novasport.rivals.play.MainActivity.resolveAndLaunch$lambda$3$lambda$2(str, str5, str7, j1Var, str3, str2, mainActivity, sharedPreferences, strL, uri);
            }
        }).start();
        return kotlin.Unit.a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void resolveAndLaunch$lambda$3$lambda$2(final java.lang.String str, java.lang.String str2, java.lang.String str3, defpackage.j1 j1Var, java.lang.String str4, java.lang.String str5, final com.novasport.rivals.play.MainActivity mainActivity, final android.content.SharedPreferences sharedPreferences, final java.lang.String str6, final android.net.Uri uri) throws java.io.IOException {
        final java.lang.String str7;
        java.net.HttpURLConnection httpURLConnection;
        java.lang.String str8 = j1Var.b;
        java.lang.String str9 = j1Var.a;
        str.getClass();
        str2.getClass();
        str3.getClass();
        str8.getClass();
        str4.getClass();
        str9.getClass();
        str5.getClass();
        java.lang.String strL = defpackage.or.l(str9, defpackage.q4.a(new kotlin.Pair("user", str2), new kotlin.Pair("deviceIdKey", str3), new kotlin.Pair("advertisingIdKey", str8), new kotlin.Pair("campaignKey", str4)));
        try {
            java.net.URLConnection uRLConnectionOpenConnection = new java.net.URL(defpackage.v5.h(str, "/api", strL.length() > 0 ? "?".concat(strL) : "")).openConnection();
            uRLConnectionOpenConnection.getClass();
            httpURLConnection = (java.net.HttpURLConnection) uRLConnectionOpenConnection;
            httpURLConnection.setRequestMethod(androidx.browser.trusted.sharing.ShareTarget.METHOD_GET);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setInstanceFollowRedirects(true);
            httpURLConnection.setRequestProperty("Accept", "application/json");
            httpURLConnection.setRequestProperty("User-Agent", str5);
            if (str2.length() > 0) {
                httpURLConnection.setRequestProperty("user", str2);
            }
            if (str9.length() > 0) {
                httpURLConnection.setRequestProperty("X-Referer", str9);
            }
            if (str4.length() > 0) {
                httpURLConnection.setRequestProperty("campaignKey", str4);
            }
            httpURLConnection.setRequestProperty("deviceIdKey", str3);
            if (str8.length() == 0) {
                str8 = "none";
            }
            httpURLConnection.setRequestProperty("advertisingIdKey", str8);
        } catch (java.lang.Exception unused) {
        }
        if (httpURLConnection.getResponseCode() == 200) {
            java.io.InputStream inputStream = httpURLConnection.getInputStream();
            inputStream.getClass();
            java.io.BufferedReader bufferedReader = new java.io.BufferedReader(new java.io.InputStreamReader(inputStream, kotlin.text.Charsets.UTF_8), 8192);
            try {
                java.lang.String strH = defpackage.x7.h(bufferedReader);
                bufferedReader.close();
                httpURLConnection.disconnect();
                java.lang.String strOptString = new org.json.JSONObject(strH).optString("url");
                strOptString.getClass();
                java.lang.String string = kotlin.text.StringsKt.j(strOptString).toString();
                if (kotlin.text.b.c(string, "http://") || string.startsWith("https://")) {
                    str7 = string;
                }
                mainActivity.runOnUiThread(new java.lang.Runnable() { // from class: xi
                    @Override // java.lang.Runnable
                    public final void run() {
                        com.novasport.rivals.play.MainActivity.resolveAndLaunch$lambda$3$lambda$2$lambda$1(this.d, str7, sharedPreferences, str6, uri, str);
                    }
                });
            } finally {
            }
        } else {
            httpURLConnection.disconnect();
        }
        str7 = null;
        mainActivity.runOnUiThread(new java.lang.Runnable() { // from class: xi
            @Override // java.lang.Runnable
            public final void run() {
                com.novasport.rivals.play.MainActivity.resolveAndLaunch$lambda$3$lambda$2$lambda$1(this.d, str7, sharedPreferences, str6, uri, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void resolveAndLaunch$lambda$3$lambda$2$lambda$1(com.novasport.rivals.play.MainActivity mainActivity, java.lang.String str, android.content.SharedPreferences sharedPreferences, java.lang.String str2, android.net.Uri uri, java.lang.String str3) {
        if (mainActivity.isFinishing() || mainActivity.isDestroyed()) {
            return;
        }
        if (str != null) {
            mainActivity.openOffer(str);
            mainActivity.finish();
            return;
        }
        sharedPreferences.edit().putBoolean(KEY_GAME_REACHED, true).apply();
        if (str2.length() != 0) {
            uri = android.net.Uri.parse(str3 + "/?" + str2);
        }
        mainActivity.targetUri = uri;
        mainActivity.launchTwa();
    }

    @Override // com.google.androidbrowserhelper.trusted.LauncherActivity
    public android.net.Uri getLaunchingUrl() {
        android.net.Uri uri = this.targetUri;
        if (uri != null) {
            return uri;
        }
        android.net.Uri launchingUrl = super.getLaunchingUrl();
        launchingUrl.getClass();
        return launchingUrl;
    }

    @Override // com.google.androidbrowserhelper.trusted.LauncherActivity, android.app.Activity
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (needsNotificationPermission()) {
            requestPermissions(new java.lang.String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFICATIONS);
        } else {
            resolveAndLaunch();
        }
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int requestCode, java.lang.String[] permissions, int[] grantResults) {
        permissions.getClass();
        grantResults.getClass();
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 4192) {
            resolveAndLaunch();
        }
    }

    @Override // com.google.androidbrowserhelper.trusted.LauncherActivity
    public boolean shouldLaunchImmediately() {
        return false;
    }
}
