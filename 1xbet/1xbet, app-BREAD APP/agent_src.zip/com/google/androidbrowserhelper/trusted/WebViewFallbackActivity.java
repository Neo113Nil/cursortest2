package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class WebViewFallbackActivity extends android.app.Activity {
    private static final java.lang.String KEY_EXTRA_ORIGINS = "com.google.browser.examples.twawebviewfallback.WebViewFallbackActivity.KEY_EXTRA_ORIGINS";
    private static final java.lang.String KEY_LAUNCH_URI = "com.google.browser.examples.twawebviewfallback.WebViewFallbackActivity.LAUNCH_URL";
    private static final java.lang.String KEY_NAVIGATION_BAR_COLOR = "com.google.browser.examples.twawebviewfallback.WebViewFallbackActivity.KEY_NAVIGATION_BAR_COLOR";
    private static final java.lang.String KEY_PREFIX = "com.google.browser.examples.twawebviewfallback.WebViewFallbackActivity.";
    private static final java.lang.String KEY_STATUS_BAR_COLOR = "com.google.browser.examples.twawebviewfallback.WebViewFallbackActivity.KEY_STATUS_BAR_COLOR";
    private static final java.lang.String TAG = "WebViewFallbackActivity";
    private java.util.List<android.net.Uri> mExtraOrigins = new java.util.ArrayList();
    private android.net.Uri mLaunchUrl;
    private int mStatusBarColor;
    private android.webkit.WebView mWebView;

    public static android.content.Intent createLaunchIntent(android.content.Context context, android.net.Uri uri, com.google.androidbrowserhelper.trusted.LauncherActivityMetadata launcherActivityMetadata) {
        android.content.Intent intent = new android.content.Intent(context, (java.lang.Class<?>) com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.class);
        intent.putExtra(KEY_LAUNCH_URI, uri);
        intent.putExtra(KEY_STATUS_BAR_COLOR, context.getColor(launcherActivityMetadata.statusBarColorId));
        intent.putExtra(KEY_NAVIGATION_BAR_COLOR, context.getColor(launcherActivityMetadata.navigationBarColorId));
        if (launcherActivityMetadata.additionalTrustedOrigins != null) {
            intent.putStringArrayListExtra(KEY_EXTRA_ORIGINS, new java.util.ArrayList<>(launcherActivityMetadata.additionalTrustedOrigins));
        }
        return intent;
    }

    private android.webkit.WebChromeClient createWebViewChromeClient() {
        return new android.webkit.WebChromeClient() { // from class: com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.2
            private android.view.View fullScreenView;
            private int originalOrientation;

            @Override // android.webkit.WebChromeClient
            public void onHideCustomView() {
                if (this.fullScreenView == null) {
                    return;
                }
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.getWindow().clearFlags(1024);
                ((android.view.ViewGroup) this.fullScreenView.getParent()).removeView(this.fullScreenView);
                this.fullScreenView = null;
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.setRequestedOrientation(this.originalOrientation);
            }

            @Override // android.webkit.WebChromeClient
            public void onShowCustomView(android.view.View view, android.webkit.WebChromeClient.CustomViewCallback customViewCallback) {
                if (this.fullScreenView != null) {
                    onHideCustomView();
                }
                this.fullScreenView = view;
                this.originalOrientation = com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.getRequestedOrientation();
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.getWindow().addFlags(1024);
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.getWindow().addContentView(this.fullScreenView, new android.widget.FrameLayout.LayoutParams(-1, -1, 17));
            }
        };
    }

    private android.webkit.WebViewClient createWebViewClient() {
        return new android.webkit.WebViewClient() { // from class: com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.1
            private boolean matchExtraOrigins(android.net.Uri uri) {
                java.util.Iterator it = com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mExtraOrigins.iterator();
                while (it.hasNext()) {
                    if (uriOriginsMatch((android.net.Uri) it.next(), uri)) {
                        return true;
                    }
                }
                return false;
            }

            private boolean shouldOverrideUrlLoading(android.net.Uri uri) {
                android.net.Uri uri2 = com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mLaunchUrl;
                if (!"data".equals(uri.getScheme()) && !uriOriginsMatch(uri, uri2) && !matchExtraOrigins(uri)) {
                    try {
                        defpackage.m7 m7Var = new defpackage.m7();
                        int i = com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mStatusBarColor;
                        m7Var.b.e = java.lang.Integer.valueOf(i | (-16777216));
                        defpackage.n7 n7VarA = m7Var.a();
                        com.google.androidbrowserhelper.trusted.WebViewFallbackActivity webViewFallbackActivity = com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this;
                        android.content.Intent intent = n7VarA.a;
                        intent.setData(uri);
                        webViewFallbackActivity.startActivity(intent, n7VarA.b);
                        return true;
                    } catch (android.content.ActivityNotFoundException unused) {
                        android.util.Log.e(com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.TAG, java.lang.String.format("ActivityNotFoundException while launching '%s'", uri));
                    }
                }
                return false;
            }

            private boolean uriOriginsMatch(android.net.Uri uri, android.net.Uri uri2) {
                return uri.getScheme().equalsIgnoreCase(uri2.getScheme()) && uri.getHost().equalsIgnoreCase(uri2.getHost()) && uri.getPort() == uri2.getPort();
            }

            @Override // android.webkit.WebViewClient
            public boolean onRenderProcessGone(android.webkit.WebView webView, android.webkit.RenderProcessGoneDetail renderProcessGoneDetail) {
                android.view.ViewGroup viewGroup = (android.view.ViewGroup) webView.getParent();
                viewGroup.removeView(webView);
                webView.destroy();
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mWebView = new android.webkit.WebView(webView.getContext());
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mWebView.setWebViewClient(this);
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.setupWebSettings(com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mWebView.getSettings());
                viewGroup.addView(com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mWebView);
                android.widget.Toast.makeText(webView.getContext(), "Recovering from crash", 1).show();
                com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mWebView.loadUrl(com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.this.mLaunchUrl.toString());
                return true;
            }

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, java.lang.String str) {
                return shouldOverrideUrlLoading(android.net.Uri.parse(str));
            }

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest) {
                return shouldOverrideUrlLoading(webResourceRequest.getUrl());
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void setupWebSettings(android.webkit.WebSettings webSettings) {
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(android.content.res.Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        java.util.ArrayList<java.lang.String> stringArrayListExtra;
        super.onCreate(bundle);
        android.net.Uri uri = (android.net.Uri) getIntent().getParcelableExtra(KEY_LAUNCH_URI);
        this.mLaunchUrl = uri;
        if (!"https".equals(uri.getScheme())) {
            defpackage.q8.b("launchUrl scheme must be 'https'");
            return;
        }
        int i = 0;
        if (getIntent().hasExtra(KEY_NAVIGATION_BAR_COLOR)) {
            getWindow().setNavigationBarColor(getIntent().getIntExtra(KEY_NAVIGATION_BAR_COLOR, 0));
        }
        if (getIntent().hasExtra(KEY_STATUS_BAR_COLOR)) {
            this.mStatusBarColor = getIntent().getIntExtra(KEY_STATUS_BAR_COLOR, 0);
            getWindow().setStatusBarColor(this.mStatusBarColor);
        } else {
            this.mStatusBarColor = getWindow().getStatusBarColor();
        }
        if (getIntent().hasExtra(KEY_EXTRA_ORIGINS) && (stringArrayListExtra = getIntent().getStringArrayListExtra(KEY_EXTRA_ORIGINS)) != null) {
            int size = stringArrayListExtra.size();
            while (i < size) {
                java.lang.String str = stringArrayListExtra.get(i);
                i++;
                java.lang.String str2 = str;
                android.net.Uri uri2 = android.net.Uri.parse(str2);
                if ("https".equalsIgnoreCase(uri2.getScheme())) {
                    this.mExtraOrigins.add(uri2);
                } else {
                    android.util.Log.w(TAG, "Only 'https' origins are accepted. Ignoring extra origin: " + str2);
                }
            }
        }
        android.webkit.WebView webView = new android.webkit.WebView(this);
        this.mWebView = webView;
        webView.setWebViewClient(createWebViewClient());
        this.mWebView.setWebChromeClient(createWebViewChromeClient());
        setupWebSettings(this.mWebView.getSettings());
        setContentView(this.mWebView, new android.view.ViewGroup.LayoutParams(-1, -1));
        if (bundle != null) {
            this.mWebView.restoreState(bundle);
            return;
        }
        java.util.HashMap map = new java.util.HashMap();
        map.put("Referer", "android-app://" + getPackageName() + "/");
        this.mWebView.loadUrl(this.mLaunchUrl.toString(), map);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, android.view.KeyEvent keyEvent) {
        if (i != 4 || !this.mWebView.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.mWebView.goBack();
        return true;
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        android.webkit.WebView webView = this.mWebView;
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        android.webkit.WebView webView = this.mWebView;
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(android.os.Bundle bundle) {
        super.onSaveInstanceState(bundle);
        android.webkit.WebView webView = this.mWebView;
        if (webView != null) {
            webView.saveState(bundle);
        }
    }
}
