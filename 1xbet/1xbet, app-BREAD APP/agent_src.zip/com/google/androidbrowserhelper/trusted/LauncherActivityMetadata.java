package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class LauncherActivityMetadata {
    private static final int DEFAULT_COLOR_ID = 17170443;
    private static final int DEFAULT_DIVIDER_COLOR_ID = 17170445;
    private static final java.util.Map<java.lang.String, java.lang.Integer> LAUNCH_HANDLER_CLIENT_MODE_MAP;
    private static final java.lang.String LAUNCH_HANDLER_CLIENT_MODE_METADATA_NAME = "android.support.customtabs.trusted.LAUNCH_HANDLER_CLIENT_MODE";
    private static final java.lang.String METADATA_ADDITIONAL_TRUSTED_ORIGINS = "android.support.customtabs.trusted.ADDITIONAL_TRUSTED_ORIGINS";
    private static final java.lang.String METADATA_DEFAULT_URL = "android.support.customtabs.trusted.DEFAULT_URL";
    private static final java.lang.String METADATA_DISPLAY_MODE = "android.support.customtabs.trusted.DISPLAY_MODE";
    private static final java.lang.String METADATA_FALLBACK_STRATEGY = "android.support.customtabs.trusted.FALLBACK_STRATEGY";
    private static final java.lang.String METADATA_FILE_HANDLING_ACTION_URL = "android.support.customtabs.trusted.FILE_HANDLING_ACTION_URL";
    private static final java.lang.String METADATA_FILE_PROVIDER_AUTHORITY = "android.support.customtabs.trusted.FILE_PROVIDER_AUTHORITY";
    private static final java.lang.String METADATA_NAVIGATION_BAR_COLOR_DARK_ID = "android.support.customtabs.trusted.NAVIGATION_BAR_COLOR_DARK";
    private static final java.lang.String METADATA_NAVIGATION_BAR_COLOR_ID = "android.support.customtabs.trusted.NAVIGATION_BAR_COLOR";
    private static final java.lang.String METADATA_NAVIGATION_BAR_DIVIDER_COLOR_DARK_ID = "androix.browser.trusted.NAVIGATION_BAR_DIVIDER_COLOR_DARK";
    private static final java.lang.String METADATA_NAVIGATION_BAR_DIVIDER_COLOR_ID = "androix.browser.trusted.NAVIGATION_BAR_DIVIDER_COLOR";
    private static final java.lang.String METADATA_SCREEN_ORIENTATION = "android.support.customtabs.trusted.SCREEN_ORIENTATION";
    private static final java.lang.String METADATA_SHARE_TARGET = "android.support.customtabs.trusted.METADATA_SHARE_TARGET";
    private static final java.lang.String METADATA_SPLASH_IMAGE_DRAWABLE_ID = "android.support.customtabs.trusted.SPLASH_IMAGE_DRAWABLE";
    private static final java.lang.String METADATA_SPLASH_SCREEN_BACKGROUND_COLOR = "android.support.customtabs.trusted.SPLASH_SCREEN_BACKGROUND_COLOR";
    private static final java.lang.String METADATA_SPLASH_SCREEN_FADE_OUT_DURATION = "android.support.customtabs.trusted.SPLASH_SCREEN_FADE_OUT_DURATION";
    private static final java.lang.String METADATA_START_CHROME_BEFORE_ANIMATION_COMPLETE = "android.support.customtabs.trusted.START_CHROME_BEFORE_ANIMATION_COMPLETE";
    private static final java.lang.String METADATA_STATUS_BAR_COLOR_DARK_ID = "android.support.customtabs.trusted.STATUS_BAR_COLOR_DARK";
    private static final java.lang.String METADATA_STATUS_BAR_COLOR_ID = "android.support.customtabs.trusted.STATUS_BAR_COLOR";
    private static final java.lang.String TAG = "LauncherActivityMetadata";
    public final java.util.List<java.lang.String> additionalTrustedOrigins;
    public final java.lang.String defaultUrl;
    public final androidx.browser.trusted.TrustedWebActivityDisplayMode displayMode;
    public final java.lang.String fallbackStrategyType;
    public final java.lang.String fileHandlingActionUrl;
    public final java.lang.String fileProviderAuthority;
    public final int launchHandlerClientMode;
    public final int navigationBarColorDarkId;
    public final int navigationBarColorId;
    public final int navigationBarDividerColorDarkId;
    public final int navigationBarDividerColorId;
    public final int screenOrientation;
    public final java.lang.String shareTarget;
    public final int splashImageDrawableId;
    public final int splashScreenBackgroundColorId;
    public final int splashScreenFadeOutDurationMillis;
    public final boolean startChromeBeforeAnimationComplete;
    public final int statusBarColorDarkId;
    public final int statusBarColorId;

    /*  JADX ERROR: Types fix failed
        jadx.core.utils.exceptions.JadxRuntimeException: Several immutable types in one variable: [short[], byte[]], vars: [r3v2 ??, r3v6 ??, r3v4 short[], r3v10 ??, r3v11 byte[]]
        	at jadx.core.dex.visitors.InitCodeVariables.setCodeVarType(InitCodeVariables.java:107)
        	at jadx.core.dex.visitors.InitCodeVariables.setCodeVar(InitCodeVariables.java:83)
        	at jadx.core.dex.visitors.InitCodeVariables.initCodeVar(InitCodeVariables.java:74)
        	at jadx.core.dex.visitors.InitCodeVariables.initCodeVars(InitCodeVariables.java:48)
        	at jadx.core.dex.visitors.InitCodeVariables.rerun(InitCodeVariables.java:36)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryInsertAdditionalMove(FixTypesVisitor.java:553)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:91)
        */
    static {
        /*
            Method dump skipped, instructions count: 430
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.androidbrowserhelper.trusted.LauncherActivityMetadata.<clinit>():void");
    }

    private LauncherActivityMetadata(android.os.Bundle bundle, android.content.res.Resources resources) {
        this.defaultUrl = bundle.getString(METADATA_DEFAULT_URL);
        int i = bundle.getInt(METADATA_STATUS_BAR_COLOR_ID, 17170443);
        this.statusBarColorId = i;
        this.statusBarColorDarkId = bundle.getInt(METADATA_STATUS_BAR_COLOR_DARK_ID, i);
        int i2 = bundle.getInt(METADATA_NAVIGATION_BAR_COLOR_ID, 17170443);
        this.navigationBarColorId = i2;
        this.navigationBarColorDarkId = bundle.getInt(METADATA_NAVIGATION_BAR_COLOR_DARK_ID, i2);
        this.navigationBarDividerColorId = bundle.getInt(METADATA_NAVIGATION_BAR_DIVIDER_COLOR_ID, 17170445);
        this.navigationBarDividerColorDarkId = bundle.getInt(METADATA_NAVIGATION_BAR_DIVIDER_COLOR_DARK_ID, i2);
        this.splashImageDrawableId = bundle.getInt(METADATA_SPLASH_IMAGE_DRAWABLE_ID, 0);
        this.splashScreenBackgroundColorId = bundle.getInt(METADATA_SPLASH_SCREEN_BACKGROUND_COLOR, 17170443);
        this.fileProviderAuthority = bundle.getString(METADATA_FILE_PROVIDER_AUTHORITY);
        this.splashScreenFadeOutDurationMillis = bundle.getInt(METADATA_SPLASH_SCREEN_FADE_OUT_DURATION, 0);
        if (bundle.containsKey(METADATA_ADDITIONAL_TRUSTED_ORIGINS)) {
            this.additionalTrustedOrigins = java.util.Arrays.asList(resources.getStringArray(bundle.getInt(METADATA_ADDITIONAL_TRUSTED_ORIGINS)));
        } else {
            this.additionalTrustedOrigins = null;
        }
        this.fallbackStrategyType = bundle.getString(METADATA_FALLBACK_STRATEGY);
        this.displayMode = getDisplayMode(bundle);
        this.screenOrientation = getOrientation(bundle.getString(METADATA_SCREEN_ORIENTATION));
        int i3 = bundle.getInt(METADATA_SHARE_TARGET, 0);
        this.shareTarget = i3 != 0 ? resources.getString(i3) : null;
        this.fileHandlingActionUrl = bundle.getString(METADATA_FILE_HANDLING_ACTION_URL);
        this.launchHandlerClientMode = getLaunchHandlerClientMode(bundle.getString(LAUNCH_HANDLER_CLIENT_MODE_METADATA_NAME));
        this.startChromeBeforeAnimationComplete = bundle.getBoolean(METADATA_START_CHROME_BEFORE_ANIMATION_COMPLETE, true);
    }

    private static androidx.browser.trusted.TrustedWebActivityDisplayMode getDisplayMode(android.os.Bundle bundle) {
        java.lang.String string = bundle.getString(METADATA_DISPLAY_MODE);
        return "immersive".equals(string) ? new androidx.browser.trusted.TrustedWebActivityDisplayMode.ImmersiveMode(false, 0) : "sticky-immersive".equals(string) ? new androidx.browser.trusted.TrustedWebActivityDisplayMode.ImmersiveMode(true, 0) : "minimal-ui".equals(string) ? new androidx.browser.trusted.TrustedWebActivityDisplayMode.MinimalUiMode() : "browser".equals(string) ? new androidx.browser.trusted.TrustedWebActivityDisplayMode.BrowserMode() : new androidx.browser.trusted.TrustedWebActivityDisplayMode.DefaultMode();
    }

    private int getLaunchHandlerClientMode(java.lang.String str) {
        java.lang.Integer num = LAUNCH_HANDLER_CLIENT_MODE_MAP.get(str);
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    private int getOrientation(java.lang.String str) {
        if (str == null) {
            return 0;
        }
        switch (str) {
        }
        return 0;
    }

    public static com.google.androidbrowserhelper.trusted.LauncherActivityMetadata parse(android.content.Context context) throws android.content.pm.PackageManager.NameNotFoundException {
        android.os.Bundle bundle;
        android.content.res.Resources resources = context.getResources();
        android.os.Bundle bundle2 = new android.os.Bundle();
        try {
            android.os.Bundle bundle3 = context.getPackageManager().getActivityInfo(new android.content.ComponentName(context, context.getClass()), 128).metaData;
            if (bundle3 != null) {
                bundle2.putAll(bundle3);
            }
            if (context instanceof android.app.Activity) {
                android.app.Activity activity = (android.app.Activity) context;
                android.content.pm.ActivityInfo activityInfo = activity.getPackageManager().getActivityInfo(activity.getComponentName(), 128);
                if (activityInfo.targetActivity != null && (bundle = activityInfo.metaData) != null) {
                    bundle2.putAll(bundle);
                }
            }
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
        }
        return new com.google.androidbrowserhelper.trusted.LauncherActivityMetadata(bundle2, resources);
    }
}
