package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class FocusActivity extends android.app.Activity {
    private static final java.lang.String EXTRA_FOCUS_INTENT = "androidx.browser.customtabs.extra.FOCUS_INTENT";
    private static java.lang.Boolean mActivityExistsCached;

    public static void addToIntent(android.content.Intent intent, android.content.Context context) {
        android.content.Intent intent2 = new android.content.Intent(context, (java.lang.Class<?>) com.google.androidbrowserhelper.trusted.FocusActivity.class);
        java.lang.Boolean boolValueOf = mActivityExistsCached;
        if (boolValueOf == null) {
            boolValueOf = java.lang.Boolean.valueOf(intent2.resolveActivityInfo(context.getPackageManager(), 0) != null);
            mActivityExistsCached = boolValueOf;
        }
        if (java.lang.Boolean.FALSE.equals(boolValueOf)) {
            return;
        }
        intent2.setFlags(268435456);
        intent.putExtra(EXTRA_FOCUS_INTENT, android.app.PendingIntent.getActivity(context, 0, intent2, 67108864));
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        super.onCreate(bundle);
        finish();
    }
}
