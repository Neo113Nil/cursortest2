package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class ManageDataLauncherActivity extends android.app.Activity {
    public static final java.lang.String ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA = "android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA";
    public static final java.lang.String CATEGORY_LAUNCH_SITE_SETTINGS = "androidx.browser.trusted.category.LaunchSiteSettings";
    private static final java.lang.String METADATA_MANAGE_SPACE_DEFAULT_URL = "android.support.customtabs.trusted.MANAGE_SPACE_URL";
    public static final java.lang.String OVERRIDE_IC_SITE_SETTINGS_ID = "drawable/override_ic_site_settings";
    public static final java.lang.String SITE_SETTINGS_SHORTCUT_ID = "android.support.customtabs.action.SITE_SETTINGS_SHORTCUT";
    private static final java.lang.String TAG = "ManageDataLauncher";
    private defpackage.p7 mConnection;
    private java.lang.String mProviderPackage;

    public static void addSiteSettingsShortcut(android.content.Context context, java.lang.String str) {
        if (android.os.Build.VERSION.SDK_INT < 25) {
            return;
        }
        android.content.pm.PackageManager packageManager = context.getPackageManager();
        android.content.pm.ShortcutManager shortcutManagerA = defpackage.bj.a(context.getSystemService(defpackage.bj.b()));
        if (!packageSupportsSiteSettings(str, packageManager)) {
            shortcutManagerA.removeDynamicShortcuts(java.util.Collections.singletonList(SITE_SETTINGS_SHORTCUT_ID));
            return;
        }
        android.content.pm.ShortcutInfo siteSettingsShortcutOrNull = getSiteSettingsShortcutOrNull(context, packageManager);
        if (siteSettingsShortcutOrNull == null) {
            shortcutManagerA.removeDynamicShortcuts(java.util.Collections.singletonList(SITE_SETTINGS_SHORTCUT_ID));
        } else {
            shortcutManagerA.addDynamicShortcuts(java.util.Collections.singletonList(siteSettingsShortcutOrNull));
        }
    }

    public static android.content.pm.ShortcutInfo getSiteSettingsShortcutOrNull(android.content.Context context, android.content.pm.PackageManager packageManager) {
        if (android.os.Build.VERSION.SDK_INT < 25) {
            return null;
        }
        android.content.Intent intent = new android.content.Intent(context, (java.lang.Class<?>) com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.class);
        intent.setAction(ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA);
        if (packageManager.queryIntentActivities(intent, 65536).size() == 0) {
            return null;
        }
        int identifier = context.getResources().getIdentifier(OVERRIDE_IC_SITE_SETTINGS_ID, "drawable", context.getPackageName());
        android.content.pm.ShortcutInfo.Builder longLabel = new android.content.pm.ShortcutInfo.Builder(context, SITE_SETTINGS_SHORTCUT_ID).setShortLabel("Site Settings").setLongLabel("Manage website notifications, permissions, etc.");
        if (identifier == 0) {
            identifier = 2131165299;
        }
        return longLabel.setIcon(android.graphics.drawable.Icon.createWithResource(context, identifier)).setIntent(intent).build();
    }

    private static boolean launchBrowserSiteSettings(android.app.Activity activity, defpackage.q7 q7Var, java.lang.String str, android.net.Uri uri) {
        defpackage.m7 m7Var = new defpackage.m7();
        java.lang.String packageName = q7Var.c.getPackageName();
        android.content.Intent intent = m7Var.a;
        intent.setPackage(packageName);
        defpackage.i7 i7Var = q7Var.b;
        android.app.PendingIntent pendingIntent = q7Var.d;
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putBinder("android.support.customtabs.extra.SESSION", i7Var);
        if (pendingIntent != null) {
            bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", pendingIntent);
        }
        intent.putExtras(bundle);
        android.content.Intent intent2 = m7Var.a().a;
        intent2.setAction(ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA);
        intent2.setPackage(str);
        intent2.setData(uri);
        try {
            activity.startActivity(intent2);
            return true;
        } catch (android.content.ActivityNotFoundException unused) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchSettings(defpackage.q7 q7Var) throws android.content.pm.PackageManager.NameNotFoundException {
        if (launchBrowserSiteSettings(this, q7Var, this.mProviderPackage, getDefaultUrlForManagingSpace())) {
            finish();
        } else {
            handleNoSupportForManageSpace();
        }
    }

    public static boolean packageSupportsSiteSettings(java.lang.String str, android.content.pm.PackageManager packageManager) {
        if (str == null) {
            return false;
        }
        if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsSiteSettings(packageManager, str)) {
            return true;
        }
        android.content.Intent intent = new android.content.Intent("android.support.customtabs.action.CustomTabsService");
        intent.addCategory(CATEGORY_LAUNCH_SITE_SETTINGS);
        intent.setPackage(str);
        return packageManager.queryIntentServices(intent, 64).size() > 0;
    }

    private boolean supportsTrustedWebActivities(java.lang.String str) {
        android.content.IntentFilter intentFilter;
        if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsTrustedWebActivities(getPackageManager(), str)) {
            return true;
        }
        java.util.List<android.content.pm.ResolveInfo> listQueryIntentServices = getPackageManager().queryIntentServices(new android.content.Intent("android.support.customtabs.action.CustomTabsService").setPackage(str), 64);
        return (listQueryIntentServices.isEmpty() || (intentFilter = listQueryIntentServices.get(0).filter) == null || !intentFilter.hasCategory("androidx.browser.trusted.category.TrustedWebActivities")) ? false : true;
    }

    public android.view.View createLoadingView() {
        android.view.View progressBar = new android.widget.ProgressBar(this);
        android.widget.FrameLayout.LayoutParams layoutParams = new android.widget.FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        progressBar.setLayoutParams(layoutParams);
        android.widget.FrameLayout frameLayout = new android.widget.FrameLayout(this);
        frameLayout.addView(progressBar);
        return frameLayout;
    }

    public android.net.Uri getDefaultUrlForManagingSpace() throws android.content.pm.PackageManager.NameNotFoundException {
        try {
            android.content.pm.ActivityInfo activityInfo = getPackageManager().getActivityInfo(getComponentName(), 128);
            android.os.Bundle bundle = activityInfo.metaData;
            if (bundle == null || !bundle.containsKey(METADATA_MANAGE_SPACE_DEFAULT_URL)) {
                return null;
            }
            android.net.Uri uri = android.net.Uri.parse(activityInfo.metaData.getString(METADATA_MANAGE_SPACE_DEFAULT_URL));
            android.util.Log.d(TAG, "Using clean-up URL from Manifest (" + uri + ").");
            return uri;
        } catch (android.content.pm.PackageManager.NameNotFoundException e) {
            onError(new java.lang.RuntimeException(e));
            return null;
        }
    }

    public void handleNoSupportForManageSpace() throws android.content.pm.PackageManager.NameNotFoundException {
        java.lang.String string;
        try {
            string = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(this.mProviderPackage, 0)).toString();
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            string = this.mProviderPackage;
        }
        android.widget.Toast.makeText(this, getString(com.novasport.rivals.play.R.string.manage_space_not_supported_toast, string), 1).show();
        finish();
    }

    public void handleTwaNeverLaunched() {
        android.widget.Toast.makeText(this, getString(com.novasport.rivals.play.R.string.manage_space_no_data_toast), 1).show();
        finish();
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) throws android.content.pm.PackageManager.NameNotFoundException {
        defpackage.p7 legacyChromeConnection;
        super.onCreate(bundle);
        java.lang.String lastLaunchedProviderPackageName = new com.google.androidbrowserhelper.trusted.TwaSharedPreferencesManager(this).readLastLaunchedProviderPackageName();
        this.mProviderPackage = lastLaunchedProviderPackageName;
        if (lastLaunchedProviderPackageName == null) {
            handleTwaNeverLaunched();
            return;
        }
        if (!supportsTrustedWebActivities(lastLaunchedProviderPackageName)) {
            handleNoSupportForManageSpace();
            return;
        }
        android.view.View viewCreateLoadingView = createLoadingView();
        if (viewCreateLoadingView != null) {
            setContentView(viewCreateLoadingView);
        }
        if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsManageSpaceWithoutWarmupAndValidation(getPackageManager(), this.mProviderPackage)) {
            legacyChromeConnection = new com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.Connection();
            this.mConnection = legacyChromeConnection;
        } else {
            legacyChromeConnection = new com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.LegacyChromeConnection();
            this.mConnection = legacyChromeConnection;
        }
        java.lang.String str = this.mProviderPackage;
        legacyChromeConnection.setApplicationContext(getApplicationContext());
        android.content.Intent intent = new android.content.Intent("android.support.customtabs.action.CustomTabsService");
        if (!android.text.TextUtils.isEmpty(str)) {
            intent.setPackage(str);
        }
        bindService(intent, legacyChromeConnection, 33);
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        defpackage.p7 p7Var = this.mConnection;
        if (p7Var != null) {
            unbindService(p7Var);
        }
        finish();
    }

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public class Connection extends defpackage.p7 {
        private Connection() {
        }

        @Override // defpackage.p7
        public void onCustomTabsServiceConnected(android.content.ComponentName componentName, defpackage.j7 j7Var) throws android.content.pm.PackageManager.NameNotFoundException {
            if (com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.isFinishing()) {
                return;
            }
            com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.launchSettings(j7Var.a(null, null));
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(android.content.ComponentName componentName) {
        }
    }

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public class LegacyChromeConnection extends defpackage.p7 {
        private defpackage.b7 mCustomTabsCallback;
        private defpackage.q7 mSession;

        private LegacyChromeConnection() {
            this.mCustomTabsCallback = new defpackage.b7() { // from class: com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.LegacyChromeConnection.1
                @Override // defpackage.b7
                public void onRelationshipValidationResult(int i, android.net.Uri uri, boolean z, android.os.Bundle bundle) throws android.content.pm.PackageManager.NameNotFoundException {
                    if (com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.isFinishing()) {
                        return;
                    }
                    com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.LegacyChromeConnection legacyChromeConnection = com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.LegacyChromeConnection.this;
                    if (z) {
                        com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.launchSettings(legacyChromeConnection.mSession);
                        return;
                    }
                    com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.onError(new java.lang.RuntimeException("Failed to validate origin " + uri));
                    com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.finish();
                }
            };
        }

        @Override // defpackage.p7
        public void onCustomTabsServiceConnected(android.content.ComponentName componentName, defpackage.j7 j7Var) throws android.content.pm.PackageManager.NameNotFoundException {
            boolean z;
            if (com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.isFinishing()) {
                return;
            }
            android.net.Uri defaultUrlForManagingSpace = com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.getDefaultUrlForManagingSpace();
            if (defaultUrlForManagingSpace == null) {
                com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.onError(new java.lang.RuntimeException("Can't launch settings without an url"));
                com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.finish();
                return;
            }
            this.mSession = j7Var.a(this.mCustomTabsCallback, null);
            try {
                z = ((defpackage.we) j7Var.a).z();
            } catch (android.os.RemoteException unused) {
                z = false;
            }
            if (!z) {
                com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.this.handleTwaNeverLaunched();
                return;
            }
            defpackage.q7 q7Var = this.mSession;
            q7Var.getClass();
            android.os.Bundle bundleA = q7Var.a();
            try {
                ((defpackage.we) q7Var.a).y(q7Var.b, defaultUrlForManagingSpace, bundleA);
            } catch (android.os.RemoteException unused2) {
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(android.content.ComponentName componentName) {
        }
    }

    public void onError(java.lang.RuntimeException runtimeException) {
        throw runtimeException;
    }
}
