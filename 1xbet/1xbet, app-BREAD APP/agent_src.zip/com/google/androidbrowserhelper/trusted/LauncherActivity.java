package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class LauncherActivity extends android.app.Activity {
    private static final java.lang.String BROWSER_WAS_LAUNCHED_KEY = "android.support.customtabs.trusted.BROWSER_WAS_LAUNCHED_KEY";
    private static final java.lang.String FALLBACK_TYPE_WEBVIEW = "webview";
    private static final java.lang.String TAG = "TWALauncherActivity";
    private static boolean sChromeVersionChecked;
    private static int sLauncherActivitiesAlive;
    private boolean mBrowserWasLaunched;
    private com.google.androidbrowserhelper.trusted.LauncherActivityMetadata mMetadata;
    private com.google.androidbrowserhelper.trusted.splashscreens.PwaWrapperSplashScreenStrategy mSplashScreenStrategy;
    private long mStartupUptimeMillis;
    private com.google.androidbrowserhelper.trusted.TwaLauncher mTwaLauncher;

    private void addFileDataIfPresent(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        java.util.List<android.net.Uri> listAsList;
        if (getIntent().hasExtra(androidx.browser.trusted.TrustedWebActivityIntentBuilder.EXTRA_FILE_HANDLING_DATA)) {
            android.os.Bundle bundleExtra = getIntent().getBundleExtra(androidx.browser.trusted.TrustedWebActivityIntentBuilder.EXTRA_FILE_HANDLING_DATA);
            if (bundleExtra == null) {
                return;
            } else {
                listAsList = androidx.browser.trusted.FileHandlingData.fromBundle(bundleExtra).uris;
            }
        } else {
            listAsList = java.util.Arrays.asList(getIntent().getData());
        }
        for (android.net.Uri uri : listAsList) {
            if (uri == null || !"content".equals(uri.getScheme())) {
                return;
            }
            if (checkCallingOrSelfUriPermission(uri, 3) != 0) {
                android.util.Log.d(TAG, "Failed to open a file - no read / write permissions: " + uri);
                return;
            }
        }
        trustedWebActivityIntentBuilder.setFileHandlingData(new androidx.browser.trusted.FileHandlingData(listAsList));
    }

    private void addShareDataIfPresent(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        androidx.browser.trusted.sharing.ShareData shareDataRetrieveShareDataFromIntent = com.google.androidbrowserhelper.trusted.SharingUtils.retrieveShareDataFromIntent(getIntent());
        if (shareDataRetrieveShareDataFromIntent == null) {
            return;
        }
        java.lang.String str = this.mMetadata.shareTarget;
        if (str == null) {
            android.util.Log.d(TAG, "Failed to share: share target not defined in the AndroidManifest");
            return;
        }
        try {
            trustedWebActivityIntentBuilder.setShareParams(com.google.androidbrowserhelper.trusted.SharingUtils.parseShareTargetJson(str), shareDataRetrieveShareDataFromIntent);
        } catch (org.json.JSONException e) {
            android.util.Log.d(TAG, "Failed to parse share target json: " + e.toString());
        }
    }

    private int getColorCompat(int i) {
        return getColor(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$launchTwa$0() {
        this.mBrowserWasLaunched = true;
    }

    private boolean restartInNewTask() {
        boolean z = (getIntent().getFlags() & 268435456) != 0;
        boolean z2 = (getIntent().getFlags() & 524288) != 0;
        if (z && !z2) {
            return false;
        }
        android.content.Intent intent = new android.content.Intent(getIntent());
        intent.setFlags((268435456 | getIntent().getFlags()) & (-524289));
        startActivity(intent);
        return true;
    }

    private boolean splashScreenNeeded() {
        if (this.mMetadata.splashImageDrawableId == 0) {
            return false;
        }
        return isTaskRoot();
    }

    public com.google.androidbrowserhelper.trusted.TwaLauncher createTwaLauncher() {
        return new com.google.androidbrowserhelper.trusted.TwaLauncher(this, null, com.google.androidbrowserhelper.trusted.SessionStore.makeSessionId(java.lang.Integer.valueOf(getTaskId())), new com.google.androidbrowserhelper.trusted.SharedPreferencesTokenStore(this));
    }

    public defpackage.b7 getCustomTabsCallback() {
        return new com.google.androidbrowserhelper.trusted.QualityEnforcer();
    }

    public androidx.browser.trusted.TrustedWebActivityDisplayMode getDisplayMode() {
        return this.mMetadata.displayMode;
    }

    public com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy getFallbackStrategy() {
        return FALLBACK_TYPE_WEBVIEW.equalsIgnoreCase(this.mMetadata.fallbackStrategyType) ? com.google.androidbrowserhelper.trusted.TwaLauncher.WEBVIEW_FALLBACK_STRATEGY : com.google.androidbrowserhelper.trusted.TwaLauncher.CCT_FALLBACK_STRATEGY;
    }

    public android.net.Uri getLaunchingUrl() {
        android.net.Uri uri = android.net.Uri.parse(this.mMetadata.defaultUrl);
        android.net.Uri data = getIntent().getData();
        if (data != null) {
            java.util.Map<java.lang.String, android.net.Uri> protocolHandlers = getProtocolHandlers();
            java.lang.String scheme = data.getScheme();
            if ("https".equals(scheme)) {
                android.util.Log.d(TAG, "Using url from Intent: " + data);
                return data;
            }
            if ("content".equals(scheme)) {
                java.lang.String str = this.mMetadata.fileHandlingActionUrl;
                return str == null ? uri : android.net.Uri.parse(str);
            }
            android.net.Uri uri2 = protocolHandlers.get(scheme);
            if (uri2 != null) {
                android.net.Uri uri3 = android.net.Uri.parse(java.lang.String.format(uri2.toString(), android.net.Uri.encode(data.toString())));
                android.util.Log.d(TAG, "Using protocol handler url: " + uri3);
                return uri3;
            }
            android.util.Log.w(TAG, "Scheme " + scheme + " was registered in the manifest but not in getProtocolHandlers()! Ignoring it and falling back to the default url.");
        }
        android.util.Log.d(TAG, "Using url from Manifest: " + uri);
        return uri;
    }

    public java.util.Map<java.lang.String, android.net.Uri> getProtocolHandlers() {
        return java.util.Collections.EMPTY_MAP;
    }

    public android.widget.ImageView.ScaleType getSplashImageScaleType() {
        return android.widget.ImageView.ScaleType.CENTER;
    }

    public android.graphics.Matrix getSplashImageTransformationMatrix() {
        return null;
    }

    public void launchTwa() {
        if (isFinishing()) {
            android.util.Log.d(TAG, "Aborting launchTwa() as Activity is finishing");
            return;
        }
        defpackage.a7 a7Var = new defpackage.a7(java.lang.Integer.valueOf(getColorCompat(this.mMetadata.statusBarColorDarkId) | (-16777216)), null, java.lang.Integer.valueOf((-16777216) | getColorCompat(this.mMetadata.navigationBarColorDarkId)), java.lang.Integer.valueOf(getColorCompat(this.mMetadata.navigationBarDividerColorDarkId)));
        android.net.Uri launchingUrl = getLaunchingUrl();
        androidx.browser.trusted.TrustedWebActivityIntentBuilder launchHandlerClientMode = new androidx.browser.trusted.TrustedWebActivityIntentBuilder(launchingUrl).setToolbarColor(getColorCompat(this.mMetadata.statusBarColorId)).setNavigationBarColor(getColorCompat(this.mMetadata.navigationBarColorId)).setNavigationBarDividerColor(getColorCompat(this.mMetadata.navigationBarDividerColorId)).setColorScheme(0).setColorSchemeParams(2, a7Var).setDisplayMode(getDisplayMode()).setScreenOrientation(this.mMetadata.screenOrientation).setLaunchHandlerClientMode(this.mMetadata.launchHandlerClientMode);
        android.net.Uri data = getIntent().getData();
        if (!launchingUrl.equals(data)) {
            launchHandlerClientMode.setOriginalLaunchUrl(data);
        }
        java.util.List<java.lang.String> list = this.mMetadata.additionalTrustedOrigins;
        if (list != null) {
            launchHandlerClientMode.setAdditionalTrustedOrigins(list);
        }
        addShareDataIfPresent(launchHandlerClientMode);
        addFileDataIfPresent(launchHandlerClientMode);
        com.google.androidbrowserhelper.trusted.TwaLauncher twaLauncherCreateTwaLauncher = createTwaLauncher();
        this.mTwaLauncher = twaLauncherCreateTwaLauncher;
        twaLauncherCreateTwaLauncher.setStartupUptimeMillis(this.mStartupUptimeMillis);
        this.mTwaLauncher.launch(launchHandlerClientMode, getCustomTabsCallback(), this.mSplashScreenStrategy, new defpackage.sc(this, (byte) 1), getFallbackStrategy());
        if (!sChromeVersionChecked) {
            com.google.androidbrowserhelper.trusted.ChromeUpdatePrompt.promptIfNeeded(this, this.mTwaLauncher.getProviderPackage());
            sChromeVersionChecked = true;
        }
        if (com.google.androidbrowserhelper.trusted.ChromeOsSupport.isRunningOnArc(getApplicationContext().getPackageManager())) {
            new com.google.androidbrowserhelper.trusted.TwaSharedPreferencesManager(this).writeLastLaunchedProviderPackageName(com.google.androidbrowserhelper.trusted.ChromeOsSupport.ARC_PAYMENT_APP);
        } else {
            new com.google.androidbrowserhelper.trusted.TwaSharedPreferencesManager(this).writeLastLaunchedProviderPackageName(this.mTwaLauncher.getProviderPackage());
        }
        com.google.androidbrowserhelper.trusted.ManageDataLauncherActivity.addSiteSettingsShortcut(this, this.mTwaLauncher.getProviderPackage());
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        com.google.androidbrowserhelper.trusted.LauncherActivity launcherActivity;
        super.onCreate(bundle);
        this.mStartupUptimeMillis = android.os.SystemClock.uptimeMillis();
        int i = sLauncherActivitiesAlive + 1;
        sLauncherActivitiesAlive = i;
        boolean z = i > 1;
        boolean z2 = getIntent().getData() != null;
        boolean zIsShareIntent = com.google.androidbrowserhelper.trusted.SharingUtils.isShareIntent(getIntent());
        if (z && !z2 && !zIsShareIntent) {
            finish();
            return;
        }
        if (restartInNewTask()) {
            finish();
            return;
        }
        if (bundle != null && bundle.getBoolean(BROWSER_WAS_LAUNCHED_KEY)) {
            finish();
            return;
        }
        this.mMetadata = com.google.androidbrowserhelper.trusted.LauncherActivityMetadata.parse(this);
        if (splashScreenNeeded()) {
            com.google.androidbrowserhelper.trusted.LauncherActivityMetadata launcherActivityMetadata = this.mMetadata;
            int i2 = launcherActivityMetadata.splashImageDrawableId;
            int colorCompat = getColorCompat(launcherActivityMetadata.splashScreenBackgroundColorId);
            android.widget.ImageView.ScaleType splashImageScaleType = getSplashImageScaleType();
            android.graphics.Matrix splashImageTransformationMatrix = getSplashImageTransformationMatrix();
            com.google.androidbrowserhelper.trusted.LauncherActivityMetadata launcherActivityMetadata2 = this.mMetadata;
            launcherActivity = this;
            launcherActivity.mSplashScreenStrategy = new com.google.androidbrowserhelper.trusted.splashscreens.PwaWrapperSplashScreenStrategy(launcherActivity, i2, colorCompat, splashImageScaleType, splashImageTransformationMatrix, launcherActivityMetadata2.splashScreenFadeOutDurationMillis, launcherActivityMetadata2.fileProviderAuthority, launcherActivityMetadata2.startChromeBeforeAnimationComplete);
        } else {
            launcherActivity = this;
        }
        if (launcherActivity.shouldLaunchImmediately()) {
            launcherActivity.launchTwa();
        }
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        sLauncherActivitiesAlive--;
        com.google.androidbrowserhelper.trusted.TwaLauncher twaLauncher = this.mTwaLauncher;
        if (twaLauncher != null) {
            twaLauncher.destroy();
        }
        com.google.androidbrowserhelper.trusted.splashscreens.PwaWrapperSplashScreenStrategy pwaWrapperSplashScreenStrategy = this.mSplashScreenStrategy;
        if (pwaWrapperSplashScreenStrategy != null) {
            pwaWrapperSplashScreenStrategy.destroy();
        }
    }

    @Override // android.app.Activity
    public void onEnterAnimationComplete() {
        super.onEnterAnimationComplete();
        com.google.androidbrowserhelper.trusted.splashscreens.PwaWrapperSplashScreenStrategy pwaWrapperSplashScreenStrategy = this.mSplashScreenStrategy;
        if (pwaWrapperSplashScreenStrategy != null) {
            pwaWrapperSplashScreenStrategy.onActivityEnterAnimationComplete();
        }
    }

    @Override // android.app.Activity
    public void onRestart() {
        super.onRestart();
        if (this.mBrowserWasLaunched) {
            finish();
        }
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(android.os.Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBoolean(BROWSER_WAS_LAUNCHED_KEY, this.mBrowserWasLaunched);
    }

    public boolean shouldLaunchImmediately() {
        return true;
    }
}
