package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class SessionStore {
    private static final java.util.Map<java.lang.Integer, java.lang.Integer> mTaskIdToSessionId = new java.util.HashMap();

    public static java.lang.Integer makeSessionId(java.lang.Integer num) {
        if (num == null) {
            return Integer.MAX_VALUE;
        }
        java.util.Map<java.lang.Integer, java.lang.Integer> map = mTaskIdToSessionId;
        java.lang.Integer num2 = map.get(num);
        if (num2 != null) {
            return num2;
        }
        java.lang.Integer numValueOf = java.lang.Integer.valueOf(new java.util.Random().nextInt(Integer.MAX_VALUE));
        map.put(num, numValueOf);
        return numValueOf;
    }
}
