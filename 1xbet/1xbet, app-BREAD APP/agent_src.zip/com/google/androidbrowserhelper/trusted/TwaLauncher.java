package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class TwaLauncher {
    private static final int DEFAULT_SESSION_ID = 96375;
    private static final java.lang.String EXTRA_ANDROID_BROWSER_HELPER_VERSION = "org.chromium.chrome.browser.ANDROID_BROWSER_HELPER_VERSION";
    private static final java.lang.String EXTRA_STARTUP_UPTIME_MILLIS = "org.chromium.chrome.browser.customtabs.trusted.STARTUP_UPTIME_MILLIS";
    private static final java.lang.String TAG = "TwaLauncher";
    private android.content.Context mContext;
    private boolean mDestroyed;
    private final int mLaunchMode;
    private final java.lang.String mProviderPackage;
    private com.google.androidbrowserhelper.trusted.TwaLauncher.TwaCustomTabsServiceConnection mServiceConnection;
    private defpackage.q7 mSession;
    private final int mSessionId;
    private long mStartupUptimeMillis;
    private androidx.browser.trusted.TokenStore mTokenStore;
    public static final com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy CCT_FALLBACK_STRATEGY = new defpackage.mr(0);
    public static final com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy WEBVIEW_FALLBACK_STRATEGY = new defpackage.mr(1);

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public interface FallbackStrategy {
        void launch(android.content.Context context, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, java.lang.String str, java.lang.Runnable runnable);
    }

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public class TwaCustomTabsServiceConnection extends defpackage.p7 {
        private defpackage.b7 mCustomTabsCallback;
        private java.lang.Runnable mOnSessionCreatedRunnable;
        private java.lang.Runnable mOnSessionCreationFailedRunnable;

        public TwaCustomTabsServiceConnection(defpackage.b7 b7Var) {
            this.mCustomTabsCallback = b7Var;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSessionCreationRunnables(java.lang.Runnable runnable, java.lang.Runnable runnable2) {
            this.mOnSessionCreatedRunnable = runnable;
            this.mOnSessionCreationFailedRunnable = runnable2;
        }

        @Override // defpackage.p7
        public void onCustomTabsServiceConnected(android.content.ComponentName componentName, defpackage.j7 j7Var) {
            java.lang.Runnable runnable;
            java.lang.Runnable runnable2;
            if (!com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsLaunchWithoutWarmup(com.google.androidbrowserhelper.trusted.TwaLauncher.this.mContext.getPackageManager(), com.google.androidbrowserhelper.trusted.TwaLauncher.this.mProviderPackage)) {
                j7Var.getClass();
                try {
                    ((defpackage.we) j7Var.a).z();
                } catch (android.os.RemoteException unused) {
                }
            }
            try {
                com.google.androidbrowserhelper.trusted.TwaLauncher twaLauncher = com.google.androidbrowserhelper.trusted.TwaLauncher.this;
                twaLauncher.mSession = j7Var.a(this.mCustomTabsCallback, android.app.PendingIntent.getActivity(j7Var.c, twaLauncher.mSessionId, new android.content.Intent(), 67108864));
                if (com.google.androidbrowserhelper.trusted.TwaLauncher.this.mSession != null && (runnable2 = this.mOnSessionCreatedRunnable) != null) {
                    runnable2.run();
                } else if (com.google.androidbrowserhelper.trusted.TwaLauncher.this.mSession == null && (runnable = this.mOnSessionCreationFailedRunnable) != null) {
                    runnable.run();
                }
            } catch (java.lang.RuntimeException e) {
                android.util.Log.w(com.google.androidbrowserhelper.trusted.TwaLauncher.TAG, e);
                this.mOnSessionCreationFailedRunnable.run();
            }
            this.mOnSessionCreatedRunnable = null;
            this.mOnSessionCreationFailedRunnable = null;
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(android.content.ComponentName componentName) {
            com.google.androidbrowserhelper.trusted.TwaLauncher.this.mSession = null;
        }
    }

    public TwaLauncher(android.content.Context context, java.lang.String str, java.lang.Integer num, androidx.browser.trusted.TokenStore tokenStore) {
        this.mContext = context;
        this.mSessionId = num.intValue();
        this.mTokenStore = tokenStore;
        if (str != null) {
            this.mProviderPackage = str;
            this.mLaunchMode = 0;
        } else {
            com.google.androidbrowserhelper.trusted.TwaProviderPicker.Action actionPickProvider = com.google.androidbrowserhelper.trusted.TwaProviderPicker.pickProvider(context.getPackageManager());
            this.mProviderPackage = actionPickProvider.provider;
            this.mLaunchMode = actionPickProvider.launchMode;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$launchTwa$3(com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy fallbackStrategy, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, java.lang.Runnable runnable) {
        fallbackStrategy.launch(this.mContext, trustedWebActivityIntentBuilder, this.mProviderPackage, runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void lambda$static$0(android.content.Context context, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, java.lang.String str, java.lang.Runnable runnable) {
        defpackage.n7 n7VarBuildCustomTabsIntent = trustedWebActivityIntentBuilder.buildCustomTabsIntent();
        if (str != null) {
            n7VarBuildCustomTabsIntent.a.setPackage(str);
        }
        if (com.google.androidbrowserhelper.trusted.ChromeOsSupport.isRunningOnArc(context.getPackageManager())) {
            n7VarBuildCustomTabsIntent.a.putExtra("android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY", true);
        }
        android.net.Uri uri = trustedWebActivityIntentBuilder.getUri();
        android.content.Intent intent = n7VarBuildCustomTabsIntent.a;
        intent.setData(uri);
        context.startActivity(intent, n7VarBuildCustomTabsIntent.b);
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$static$1(android.content.Context context, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, java.lang.String str, java.lang.Runnable runnable) {
        context.startActivity(com.google.androidbrowserhelper.trusted.WebViewFallbackActivity.createLaunchIntent(context, trustedWebActivityIntentBuilder.getUri(), com.google.androidbrowserhelper.trusted.LauncherActivityMetadata.parse(context)));
        if (runnable != null) {
            runnable.run();
        }
    }

    private void launchTwa(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, defpackage.b7 b7Var, com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy splashScreenStrategy, java.lang.Runnable runnable, com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy fallbackStrategy) {
        if (splashScreenStrategy != null) {
            splashScreenStrategy.onTwaLaunchInitiated(this.mProviderPackage, trustedWebActivityIntentBuilder);
        }
        defpackage.nr nrVar = new defpackage.nr(this, trustedWebActivityIntentBuilder, splashScreenStrategy, runnable);
        if (this.mSession != null) {
            nrVar.run();
            return;
        }
        defpackage.nr nrVar2 = new defpackage.nr(this, fallbackStrategy, trustedWebActivityIntentBuilder, runnable);
        com.google.androidbrowserhelper.trusted.TwaLauncher.TwaCustomTabsServiceConnection twaCustomTabsServiceConnection = this.mServiceConnection;
        if (twaCustomTabsServiceConnection == null) {
            twaCustomTabsServiceConnection = new com.google.androidbrowserhelper.trusted.TwaLauncher.TwaCustomTabsServiceConnection(b7Var);
            this.mServiceConnection = twaCustomTabsServiceConnection;
        }
        twaCustomTabsServiceConnection.setSessionCreationRunnables(nrVar, nrVar2);
        android.content.Context context = this.mContext;
        java.lang.String str = this.mProviderPackage;
        com.google.androidbrowserhelper.trusted.TwaLauncher.TwaCustomTabsServiceConnection twaCustomTabsServiceConnection2 = this.mServiceConnection;
        twaCustomTabsServiceConnection2.setApplicationContext(context.getApplicationContext());
        android.content.Intent intent = new android.content.Intent("android.support.customtabs.action.CustomTabsService");
        if (!android.text.TextUtils.isEmpty(str)) {
            intent.setPackage(str);
        }
        context.bindService(intent, twaCustomTabsServiceConnection2, 1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: launchWhenSessionEstablished, reason: merged with bridge method [inline-methods] */
    public void lambda$launchTwa$2(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy splashScreenStrategy, java.lang.Runnable runnable) {
        defpackage.q7 q7Var = this.mSession;
        if (q7Var == null) {
            defpackage.q8.g("mSession is null in launchWhenSessionEstablished");
        } else if (splashScreenStrategy != null) {
            splashScreenStrategy.configureTwaBuilder(trustedWebActivityIntentBuilder, q7Var, new defpackage.f1((java.lang.Object) this, (java.lang.Object) trustedWebActivityIntentBuilder, (java.lang.Object) runnable, (byte) 5));
        } else {
            lambda$launchWhenSessionEstablished$4(trustedWebActivityIntentBuilder, runnable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: launchWhenSplashScreenReady, reason: merged with bridge method [inline-methods] */
    public void lambda$launchWhenSessionEstablished$4(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, java.lang.Runnable runnable) {
        if (this.mDestroyed || this.mSession == null) {
            return;
        }
        android.util.Log.d(TAG, "Launching Trusted Web Activity.");
        androidx.browser.trusted.TrustedWebActivityIntent trustedWebActivityIntentBuild = trustedWebActivityIntentBuilder.build(this.mSession);
        if (this.mStartupUptimeMillis != 0) {
            trustedWebActivityIntentBuild.getIntent().putExtra(EXTRA_STARTUP_UPTIME_MILLIS, this.mStartupUptimeMillis);
        }
        trustedWebActivityIntentBuild.getIntent().putExtra(EXTRA_ANDROID_BROWSER_HELPER_VERSION, 2);
        com.google.androidbrowserhelper.trusted.FocusActivity.addToIntent(trustedWebActivityIntentBuild.getIntent(), this.mContext);
        trustedWebActivityIntentBuild.launchTrustedWebActivity(this.mContext);
        if (runnable != null) {
            runnable.run();
        }
    }

    public void destroy() {
        if (this.mDestroyed) {
            return;
        }
        com.google.androidbrowserhelper.trusted.TwaLauncher.TwaCustomTabsServiceConnection twaCustomTabsServiceConnection = this.mServiceConnection;
        if (twaCustomTabsServiceConnection != null) {
            this.mContext.unbindService(twaCustomTabsServiceConnection);
        }
        this.mContext = null;
        this.mDestroyed = true;
    }

    public java.lang.String getProviderPackage() {
        return this.mProviderPackage;
    }

    public void launch(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, defpackage.b7 b7Var, com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy splashScreenStrategy, java.lang.Runnable runnable, com.google.androidbrowserhelper.trusted.TwaLauncher.FallbackStrategy fallbackStrategy) {
        if (this.mDestroyed) {
            defpackage.q8.g("TwaLauncher already destroyed");
            return;
        }
        if (this.mLaunchMode == 0) {
            launchTwa(trustedWebActivityIntentBuilder, b7Var, splashScreenStrategy, runnable, fallbackStrategy);
        } else {
            fallbackStrategy.launch(this.mContext, trustedWebActivityIntentBuilder, this.mProviderPackage, runnable);
        }
        if (com.google.androidbrowserhelper.trusted.ChromeOsSupport.isRunningOnArc(this.mContext.getPackageManager())) {
            return;
        }
        this.mTokenStore.store(androidx.browser.trusted.Token.create(this.mProviderPackage, this.mContext.getPackageManager()));
    }

    public void setStartupUptimeMillis(long j) {
        this.mStartupUptimeMillis = j;
    }

    public TwaLauncher(android.content.Context context, java.lang.String str) {
        this(context, str, java.lang.Integer.valueOf(DEFAULT_SESSION_ID), new com.google.androidbrowserhelper.trusted.SharedPreferencesTokenStore(context));
    }

    @java.lang.Deprecated(forRemoval = true)
    public TwaLauncher(android.content.Context context, java.lang.Integer num) {
        this(context, null, num);
    }

    @java.lang.Deprecated(forRemoval = true)
    public TwaLauncher(android.content.Context context, java.lang.String str, java.lang.Integer num) {
        this(context, str, com.google.androidbrowserhelper.trusted.SessionStore.makeSessionId(num), new com.google.androidbrowserhelper.trusted.SharedPreferencesTokenStore(context));
    }

    public TwaLauncher(android.content.Context context) {
        this(context, (java.lang.String) null);
    }

    public void launch(android.net.Uri uri) {
        launch(new androidx.browser.trusted.TrustedWebActivityIntentBuilder(uri), new com.google.androidbrowserhelper.trusted.QualityEnforcer(), null, null, null);
    }

    public void launch(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, defpackage.b7 b7Var, com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy splashScreenStrategy, java.lang.Runnable runnable) {
        launch(trustedWebActivityIntentBuilder, b7Var, splashScreenStrategy, runnable, CCT_FALLBACK_STRATEGY);
    }
}
