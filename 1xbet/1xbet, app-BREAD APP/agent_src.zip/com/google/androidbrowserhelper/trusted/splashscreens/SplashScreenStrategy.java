package com.google.androidbrowserhelper.trusted.splashscreens;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public interface SplashScreenStrategy {
    void configureTwaBuilder(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, defpackage.q7 q7Var, java.lang.Runnable runnable);

    void onTwaLaunchInitiated(java.lang.String str, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder);
}
