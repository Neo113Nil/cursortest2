package com.google.androidbrowserhelper.trusted.splashscreens;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
class SystemBarColorPredictor {
    private java.util.Map<java.lang.String, com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures> mSupportedFeaturesCache = new java.util.HashMap();

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public static class SupportedFeatures {
        public final boolean colorSchemeCustomization;
        public final boolean navbarColorCustomization;

        private SupportedFeatures(boolean z, boolean z2) {
            this.navbarColorCustomization = z;
            this.colorSchemeCustomization = z2;
        }
    }

    private static int getExpectedColorScheme(android.content.Context context, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        android.os.Bundle extras = trustedWebActivityIntentBuilder.buildCustomTabsIntent().a.getExtras();
        java.lang.Integer num = extras == null ? null : (java.lang.Integer) extras.get("androidx.browser.customtabs.extra.COLOR_SCHEME");
        return (num == null || num.intValue() == 0) ? (context.getResources().getConfiguration().uiMode & 48) == 32 ? 2 : 1 : num.intValue();
    }

    private com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures getSupportedFeatures(android.content.Context context, java.lang.String str) {
        com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures supportedFeatures = this.mSupportedFeaturesCache.get(str);
        if (supportedFeatures != null) {
            return supportedFeatures;
        }
        if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsNavbarAndColorCustomization(context.getPackageManager(), str)) {
            boolean z = true;
            com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures supportedFeatures2 = new com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures(z, z);
            this.mSupportedFeaturesCache.put(str, supportedFeatures2);
            return supportedFeatures2;
        }
        android.content.pm.ResolveInfo resolveInfoResolveService = context.getPackageManager().resolveService(new android.content.Intent().setAction("android.support.customtabs.action.CustomTabsService").setPackage(str), 64);
        com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures supportedFeatures3 = new com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor.SupportedFeatures(hasCategory(resolveInfoResolveService, "androidx.browser.customtabs.category.NavBarColorCustomization"), hasCategory(resolveInfoResolveService, "androidx.browser.customtabs.category.ColorSchemeCustomization"));
        this.mSupportedFeaturesCache.put(str, supportedFeatures3);
        return supportedFeatures3;
    }

    private static boolean hasCategory(android.content.pm.ResolveInfo resolveInfo, java.lang.String str) {
        android.content.IntentFilter intentFilter;
        return (resolveInfo == null || (intentFilter = resolveInfo.filter) == null || !intentFilter.hasCategory(str)) ? false : true;
    }

    private boolean providerSupportsColorSchemeParams(android.content.Context context, java.lang.String str) {
        return getSupportedFeatures(context, str).colorSchemeCustomization;
    }

    private boolean providerSupportsNavBarColorCustomization(android.content.Context context, java.lang.String str) {
        return getSupportedFeatures(context, str).navbarColorCustomization;
    }

    public java.lang.Integer getExpectedNavbarColor(android.content.Context context, java.lang.String str, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        android.content.Intent intent = trustedWebActivityIntentBuilder.buildCustomTabsIntent().a;
        if (!providerSupportsNavBarColorCustomization(context, str)) {
            return com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.usesWhiteNavbar(str) ? -1 : null;
        }
        if (providerSupportsColorSchemeParams(context, str)) {
            return defpackage.n7.a(intent, getExpectedColorScheme(context, trustedWebActivityIntentBuilder)).c;
        }
        android.os.Bundle extras = intent.getExtras();
        if (extras == null) {
            return null;
        }
        return (java.lang.Integer) extras.get("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR");
    }

    public java.lang.Integer getExpectedStatusBarColor(android.content.Context context, java.lang.String str, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        android.content.Intent intent = trustedWebActivityIntentBuilder.buildCustomTabsIntent().a;
        if (providerSupportsColorSchemeParams(context, str)) {
            return defpackage.n7.a(intent, getExpectedColorScheme(context, trustedWebActivityIntentBuilder)).a;
        }
        android.os.Bundle extras = intent.getExtras();
        if (extras == null) {
            return null;
        }
        return (java.lang.Integer) extras.get("android.support.customtabs.extra.TOOLBAR_COLOR");
    }
}
