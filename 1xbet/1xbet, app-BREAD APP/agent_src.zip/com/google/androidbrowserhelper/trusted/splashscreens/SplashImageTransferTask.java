package com.google.androidbrowserhelper.trusted.splashscreens;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class SplashImageTransferTask {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final java.lang.String FILE_NAME = "splash_image.png";
    private static final java.lang.String FOLDER_NAME = "twa_splash";
    private static final java.lang.String PREFS_FILE = "splashImagePrefs";
    private static final java.lang.String PREF_LAST_UPDATE_TIME = "lastUpdateTime";
    private static final java.lang.String TAG = "SplashImageTransferTask";
    private final android.os.AsyncTask<java.lang.Void, java.lang.Void, java.lang.Boolean> mAsyncTask = new android.os.AsyncTask<java.lang.Void, java.lang.Void, java.lang.Boolean>() { // from class: com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.1
        private long getLastAppUpdateTime() {
            try {
                return com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mContext.getPackageManager().getPackageInfo(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mContext.getPackageName(), 0).lastUpdateTime;
            } catch (android.content.pm.PackageManager.NameNotFoundException e) {
                throw new java.lang.RuntimeException(e);
            }
        }

        private boolean transferToCustomTabsProvider(java.io.File file) throws java.io.IOException {
            android.content.Context context = com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mContext;
            java.lang.String str = com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mAuthority;
            java.lang.String str2 = com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mProviderPackage;
            defpackage.q7 q7Var = com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mSession;
            defpackage.mb mbVarB = androidx.core.content.FileProvider.b(0, context, str);
            try {
                java.lang.String canonicalPath = file.getCanonicalPath();
                java.util.Map.Entry entry = null;
                for (java.util.Map.Entry entry2 : mbVarB.b.entrySet()) {
                    java.lang.String path = ((java.io.File) entry2.getValue()).getPath();
                    if (androidx.core.content.FileProvider.d(canonicalPath).startsWith(androidx.core.content.FileProvider.d(path).concat("/")) && (entry == null || path.length() > ((java.io.File) entry.getValue()).getPath().length())) {
                        entry = entry2;
                    }
                }
                if (entry == null) {
                    defpackage.q8.b(defpackage.v5.g("Failed to find configured root that contains ", canonicalPath));
                    return com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.$assertionsDisabled;
                }
                java.lang.String path2 = ((java.io.File) entry.getValue()).getPath();
                android.net.Uri uriBuild = new android.net.Uri.Builder().scheme("content").authority(mbVarB.a).encodedPath(android.net.Uri.encode((java.lang.String) entry.getKey()) + '/' + android.net.Uri.encode(path2.endsWith("/") ? canonicalPath.substring(path2.length()) : canonicalPath.substring(path2.length() + 1), "/")).build();
                context.grantUriPermission(str2, uriBuild, 1);
                try {
                    return ((defpackage.we) q7Var.a).x(q7Var.b, uriBuild, q7Var.a());
                } catch (android.os.RemoteException unused) {
                    return com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.$assertionsDisabled;
                }
            } catch (java.io.IOException unused2) {
                defpackage.mr.c(file, "Failed to resolve canonical path for ");
                return com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.$assertionsDisabled;
            }
        }

        @Override // android.os.AsyncTask
        public java.lang.Boolean doInBackground(java.lang.Void... voidArr) throws java.io.IOException {
            java.lang.Boolean boolValueOf;
            if (isCancelled()) {
                return java.lang.Boolean.FALSE;
            }
            java.io.File file = new java.io.File(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mContext.getFilesDir(), com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.FOLDER_NAME);
            if (!file.exists() && !file.mkdir()) {
                android.util.Log.w(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.TAG, "Failed to create a directory for storing a splash image");
                return java.lang.Boolean.FALSE;
            }
            java.io.File file2 = new java.io.File(file, com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.FILE_NAME);
            android.content.SharedPreferences sharedPreferences = com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mContext.getSharedPreferences(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.PREFS_FILE, 0);
            long lastAppUpdateTime = getLastAppUpdateTime();
            if (file2.exists() && lastAppUpdateTime == sharedPreferences.getLong(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.PREF_LAST_UPDATE_TIME, 0L)) {
                return java.lang.Boolean.valueOf(transferToCustomTabsProvider(file2));
            }
            try {
                java.io.FileOutputStream fileOutputStream = new java.io.FileOutputStream(file2);
                try {
                    if (isCancelled()) {
                        boolValueOf = java.lang.Boolean.FALSE;
                    } else {
                        com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mBitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                        fileOutputStream.flush();
                        sharedPreferences.edit().putLong(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.PREF_LAST_UPDATE_TIME, lastAppUpdateTime).commit();
                        boolValueOf = isCancelled() ? java.lang.Boolean.FALSE : java.lang.Boolean.valueOf(transferToCustomTabsProvider(file2));
                    }
                    fileOutputStream.close();
                    return boolValueOf;
                } finally {
                }
            } catch (java.lang.Exception e) {
                throw new java.lang.RuntimeException(e);
            }
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(java.lang.Boolean bool) {
            if (com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mCallback == null || isCancelled()) {
                return;
            }
            com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.this.mCallback.onFinished(bool.booleanValue());
        }
    };
    private final java.lang.String mAuthority;
    private final android.graphics.Bitmap mBitmap;
    private com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.Callback mCallback;
    private final android.content.Context mContext;
    private final java.lang.String mProviderPackage;
    private final defpackage.q7 mSession;

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public interface Callback {
        void onFinished(boolean z);
    }

    public SplashImageTransferTask(android.content.Context context, android.graphics.Bitmap bitmap, java.lang.String str, defpackage.q7 q7Var, java.lang.String str2) {
        this.mContext = context.getApplicationContext();
        this.mBitmap = bitmap;
        this.mAuthority = str;
        this.mSession = q7Var;
        this.mProviderPackage = str2;
    }

    public void cancel() {
        this.mAsyncTask.cancel(true);
        this.mCallback = null;
    }

    public void execute(com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.Callback callback) {
        this.mCallback = callback;
        this.mAsyncTask.execute(new java.lang.Void[0]);
    }
}
