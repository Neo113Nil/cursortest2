package com.google.androidbrowserhelper.trusted.splashscreens;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class PwaWrapperSplashScreenStrategy implements com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy {
    private static final java.lang.String TAG = "SplashScreenStrategy";
    private static com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor sSystemBarColorPredictor = new com.google.androidbrowserhelper.trusted.splashscreens.SystemBarColorPredictor();
    private final android.app.Activity mActivity;
    private final int mBackgroundColor;
    private final int mDrawableId;
    private boolean mEnterAnimationComplete = false;
    private final int mFadeOutDurationMillis;
    private final java.lang.String mFileProviderAuthority;
    private java.lang.Runnable mOnEnterAnimationCompleteRunnable;
    private java.lang.String mProviderPackage;
    private boolean mProviderSupportsSplashScreens;
    private final android.widget.ImageView.ScaleType mScaleType;
    private android.graphics.Bitmap mSplashImage;
    private com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask mSplashImageTransferTask;
    private boolean mStartChromeBeforeAnimationComplete;
    private final android.graphics.Matrix mTransformationMatrix;

    public PwaWrapperSplashScreenStrategy(android.app.Activity activity, int i, int i2, android.widget.ImageView.ScaleType scaleType, android.graphics.Matrix matrix, int i3, java.lang.String str, boolean z) {
        this.mDrawableId = i;
        this.mBackgroundColor = i2;
        this.mScaleType = scaleType;
        this.mTransformationMatrix = matrix;
        this.mActivity = activity;
        this.mFileProviderAuthority = str;
        this.mFadeOutDurationMillis = i3;
        this.mStartChromeBeforeAnimationComplete = z;
    }

    private void customizeStatusAndNavBarDuringSplashScreen(java.lang.String str, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        java.lang.Integer expectedNavbarColor = sSystemBarColorPredictor.getExpectedNavbarColor(this.mActivity, str, trustedWebActivityIntentBuilder);
        if (expectedNavbarColor != null) {
            com.google.androidbrowserhelper.trusted.Utils.setNavigationBarColor(this.mActivity, expectedNavbarColor.intValue());
        }
        java.lang.Integer expectedStatusBarColor = sSystemBarColorPredictor.getExpectedStatusBarColor(this.mActivity, str, trustedWebActivityIntentBuilder);
        if (expectedStatusBarColor != null) {
            com.google.androidbrowserhelper.trusted.Utils.setStatusBarColor(this.mActivity, expectedStatusBarColor.intValue());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onSplashImageTransferred$1(java.lang.Runnable runnable) {
        runnable.run();
        this.mActivity.overridePendingTransition(0, 0);
    }

    private android.os.Bundle makeSplashScreenParamsBundle() {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putString(androidx.browser.trusted.splashscreens.SplashScreenParamKey.KEY_VERSION, androidx.browser.trusted.splashscreens.SplashScreenVersion.V1);
        bundle.putInt(androidx.browser.trusted.splashscreens.SplashScreenParamKey.KEY_FADE_OUT_DURATION_MS, this.mFadeOutDurationMillis);
        bundle.putInt(androidx.browser.trusted.splashscreens.SplashScreenParamKey.KEY_BACKGROUND_COLOR, this.mBackgroundColor);
        bundle.putInt(androidx.browser.trusted.splashscreens.SplashScreenParamKey.KEY_SCALE_TYPE, this.mScaleType.ordinal());
        android.graphics.Matrix matrix = this.mTransformationMatrix;
        if (matrix != null) {
            float[] fArr = new float[9];
            matrix.getValues(fArr);
            bundle.putFloatArray(androidx.browser.trusted.splashscreens.SplashScreenParamKey.KEY_IMAGE_TRANSFORMATION_MATRIX, fArr);
        }
        return bundle;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: onSplashImageTransferred, reason: merged with bridge method [inline-methods] */
    public void lambda$configureTwaBuilder$0(androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, boolean z, java.lang.Runnable runnable, defpackage.q7 q7Var) throws java.lang.Exception {
        if (!z) {
            android.util.Log.w(TAG, "Failed to transfer splash image.");
            runnable.run();
            return;
        }
        trustedWebActivityIntentBuilder.setSplashScreenParams(makeSplashScreenParamsBundle());
        defpackage.i1 i1Var = new defpackage.i1(this, runnable, (byte) 8);
        if (this.mStartChromeBeforeAnimationComplete) {
            i1Var.run();
        } else {
            runWhenEnterAnimationComplete(i1Var, q7Var, trustedWebActivityIntentBuilder.getUri());
        }
    }

    private void runWhenEnterAnimationComplete(java.lang.Runnable runnable, defpackage.q7 q7Var, android.net.Uri uri) {
        boolean zA;
        if (this.mEnterAnimationComplete) {
            runnable.run();
            return;
        }
        this.mOnEnterAnimationCompleteRunnable = runnable;
        try {
            zA = ((defpackage.we) q7Var.a).a(q7Var.b, uri, q7Var.a());
        } catch (android.os.RemoteException unused) {
            zA = false;
        }
        android.util.Log.i(TAG, "Enter animation not complete, try preload url. Result: " + zA);
    }

    private void showSplashScreen() {
        android.graphics.Bitmap bitmapConvertDrawableToBitmap = com.google.androidbrowserhelper.trusted.Utils.convertDrawableToBitmap(this.mActivity, this.mDrawableId);
        this.mSplashImage = bitmapConvertDrawableToBitmap;
        if (bitmapConvertDrawableToBitmap == null) {
            android.util.Log.w(TAG, "Failed to retrieve splash image from provided drawable id");
            return;
        }
        android.widget.ImageView imageView = new android.widget.ImageView(this.mActivity);
        imageView.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, -1));
        imageView.setImageBitmap(this.mSplashImage);
        imageView.setBackgroundColor(this.mBackgroundColor);
        imageView.setScaleType(this.mScaleType);
        if (this.mScaleType == android.widget.ImageView.ScaleType.MATRIX) {
            imageView.setImageMatrix(this.mTransformationMatrix);
        }
        this.mActivity.setContentView(imageView);
    }

    @Override // com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy
    public void configureTwaBuilder(final androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder, final defpackage.q7 q7Var, final java.lang.Runnable runnable) {
        if (!this.mProviderSupportsSplashScreens || this.mSplashImage == null) {
            runnable.run();
            return;
        }
        if (android.text.TextUtils.isEmpty(this.mFileProviderAuthority)) {
            android.util.Log.w(TAG, "FileProvider authority not specified, can't transfer splash image.");
            runnable.run();
        } else {
            com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask splashImageTransferTask = new com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask(this.mActivity, this.mSplashImage, this.mFileProviderAuthority, q7Var, this.mProviderPackage);
            this.mSplashImageTransferTask = splashImageTransferTask;
            splashImageTransferTask.execute(new com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.Callback() { // from class: hm
                @Override // com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask.Callback
                public final void onFinished(boolean z) throws java.lang.Exception {
                    this.a.lambda$configureTwaBuilder$0(trustedWebActivityIntentBuilder, runnable, q7Var, z);
                }
            });
        }
    }

    public void destroy() {
        com.google.androidbrowserhelper.trusted.splashscreens.SplashImageTransferTask splashImageTransferTask = this.mSplashImageTransferTask;
        if (splashImageTransferTask != null) {
            splashImageTransferTask.cancel();
        }
    }

    public void onActivityEnterAnimationComplete() {
        this.mEnterAnimationComplete = true;
        java.lang.Runnable runnable = this.mOnEnterAnimationCompleteRunnable;
        if (runnable != null) {
            runnable.run();
            this.mOnEnterAnimationCompleteRunnable = null;
        }
    }

    @Override // com.google.androidbrowserhelper.trusted.splashscreens.SplashScreenStrategy
    public void onTwaLaunchInitiated(java.lang.String str, androidx.browser.trusted.TrustedWebActivityIntentBuilder trustedWebActivityIntentBuilder) {
        android.content.IntentFilter intentFilter;
        this.mProviderPackage = str;
        android.content.pm.ResolveInfo resolveInfoResolveService = this.mActivity.getPackageManager().resolveService(new android.content.Intent().setAction("android.support.customtabs.action.CustomTabsService").setPackage(str), 64);
        boolean zHasCategory = (resolveInfoResolveService == null || (intentFilter = resolveInfoResolveService.filter) == null) ? false : intentFilter.hasCategory(androidx.browser.trusted.splashscreens.SplashScreenVersion.V1);
        this.mProviderSupportsSplashScreens = zHasCategory;
        if (zHasCategory) {
            showSplashScreen();
            if (this.mSplashImage != null) {
                customizeStatusAndNavBarDuringSplashScreen(str, trustedWebActivityIntentBuilder);
                return;
            }
            return;
        }
        android.util.Log.w(TAG, "Provider " + str + " doesn't support splash screens");
    }
}
