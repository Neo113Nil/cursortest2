package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class SharedPreferencesTokenStore implements androidx.browser.trusted.TokenStore {
    private static final java.lang.String KEY_TOKEN = "SharedPreferencesTokenStore.TOKEN";
    private final android.content.Context mContext;

    public SharedPreferencesTokenStore(android.content.Context context) {
        this.mContext = context.getApplicationContext();
    }

    @Override // androidx.browser.trusted.TokenStore
    public androidx.browser.trusted.Token load() {
        java.lang.String string = com.google.androidbrowserhelper.trusted.PrefUtils.getAppSharedPreferences(this.mContext).getString(KEY_TOKEN, null);
        if (string == null) {
            return null;
        }
        return androidx.browser.trusted.Token.deserialize(android.util.Base64.decode(string, 3));
    }

    public void setVerifiedProvider(java.lang.String str, android.content.pm.PackageManager packageManager) {
        store(androidx.browser.trusted.Token.create(str, packageManager));
    }

    @Override // androidx.browser.trusted.TokenStore
    public void store(androidx.browser.trusted.Token token) {
        android.content.SharedPreferences appSharedPreferences = com.google.androidbrowserhelper.trusted.PrefUtils.getAppSharedPreferences(this.mContext);
        if (token == null) {
            appSharedPreferences.edit().remove(KEY_TOKEN).apply();
        } else {
            appSharedPreferences.edit().putString(KEY_TOKEN, android.util.Base64.encodeToString(token.serialize(), 3)).apply();
        }
    }
}
