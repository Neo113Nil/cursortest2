package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class NotificationUtils {
    private NotificationUtils() {
    }

    public static boolean areNotificationsEnabled(android.content.Context context, java.lang.String str) {
        if (!new defpackage.rk(context).a.areNotificationsEnabled()) {
            return false;
        }
        int i = android.os.Build.VERSION.SDK_INT;
        if (i < 26) {
            return true;
        }
        android.app.NotificationChannel notificationChannelD = i >= 26 ? defpackage.a6.d(new defpackage.rk(context).a, channelNameToId(str)) : null;
        return notificationChannelD == null || notificationChannelD.getImportance() != 0;
    }

    private static java.lang.String channelNameToId(java.lang.String str) {
        return str.toLowerCase(java.util.Locale.ROOT).replace(' ', '_') + "_channel_id";
    }

    public static void createNotificationChannel(android.content.Context context, java.lang.String str) {
        int i = android.os.Build.VERSION.SDK_INT;
        if (i < 26) {
            return;
        }
        defpackage.z4.m();
        android.app.NotificationChannel notificationChannelD = defpackage.z4.d(channelNameToId(str), str);
        defpackage.rk rkVar = new defpackage.rk(context);
        if (i >= 26) {
            defpackage.a6.b(rkVar.a, notificationChannelD);
        }
    }
}
