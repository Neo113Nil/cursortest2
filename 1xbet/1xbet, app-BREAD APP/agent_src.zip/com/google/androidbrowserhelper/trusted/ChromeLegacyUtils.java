package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class ChromeLegacyUtils {
    private static final int VERSION_SUPPORTS_CUSTOM_COLOR = 380900000;
    private static final int VERSION_SUPPORTS_NO_PREWARM = 368300000;
    private static final int VERSION_SUPPORTS_SIMPLIFIED_MANAGE_DATA = 389000000;
    static final int VERSION_SUPPORTS_TRUSTED_WEB_ACTIVITIES = 362600000;
    private static final java.lang.String CHROME_LOCAL_BUILD_PACKAGE = "com.google.android.apps.chrome";
    private static final java.lang.String CHROMIUM_LOCAL_BUILD_PACKAGE = "org.chromium.chrome";
    private static final java.lang.String CHROME_CANARY_PACKAGE = "com.chrome.canary";
    private static final java.lang.String CHROME_DEV_PACKAGE = "com.chrome.dev";
    private static final java.lang.String CHROME_BETA_PACKAGE = "com.chrome.beta";
    private static final java.lang.String CHROME_STABLE_PACKAGE = "com.android.chrome";
    private static final java.util.List<java.lang.String> SUPPORTED_CHROME_PACKAGES = java.util.Arrays.asList(CHROME_LOCAL_BUILD_PACKAGE, CHROMIUM_LOCAL_BUILD_PACKAGE, CHROME_CANARY_PACKAGE, CHROME_DEV_PACKAGE, CHROME_BETA_PACKAGE, CHROME_STABLE_PACKAGE);
    static final java.util.List<java.lang.String> VERSION_CHECK_CHROME_PACKAGES = java.util.Arrays.asList(CHROME_BETA_PACKAGE, CHROME_STABLE_PACKAGE);
    private static final java.util.List<java.lang.String> LOCAL_BUILD_PACKAGES = java.util.Arrays.asList(CHROME_LOCAL_BUILD_PACKAGE, CHROMIUM_LOCAL_BUILD_PACKAGE);

    private ChromeLegacyUtils() {
    }

    private static boolean checkChromeVersion(android.content.pm.PackageManager packageManager, java.lang.String str, int i) {
        return LOCAL_BUILD_PACKAGES.contains(str) || getVersionCode(packageManager, str) >= i;
    }

    public static int getVersionCode(android.content.pm.PackageManager packageManager, java.lang.String str) {
        try {
            return android.os.Build.VERSION.SDK_INT >= 28 ? (int) packageManager.getPackageInfo(str, 0).getLongVersionCode() : packageManager.getPackageInfo(str, 0).versionCode;
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return 0;
        }
    }

    public static boolean supportsLaunchWithoutWarmup(android.content.pm.PackageManager packageManager, java.lang.String str) {
        if (SUPPORTED_CHROME_PACKAGES.contains(str)) {
            return checkChromeVersion(packageManager, str, VERSION_SUPPORTS_NO_PREWARM);
        }
        return true;
    }

    public static boolean supportsManageSpaceWithoutWarmupAndValidation(android.content.pm.PackageManager packageManager, java.lang.String str) {
        if (SUPPORTED_CHROME_PACKAGES.contains(str)) {
            return checkChromeVersion(packageManager, str, VERSION_SUPPORTS_SIMPLIFIED_MANAGE_DATA);
        }
        return false;
    }

    public static boolean supportsNavbarAndColorCustomization(android.content.pm.PackageManager packageManager, java.lang.String str) {
        if (SUPPORTED_CHROME_PACKAGES.contains(str)) {
            return checkChromeVersion(packageManager, str, VERSION_SUPPORTS_CUSTOM_COLOR);
        }
        return false;
    }

    public static boolean supportsSiteSettings(android.content.pm.PackageManager packageManager, java.lang.String str) {
        return supportsTrustedWebActivities(packageManager, str);
    }

    public static boolean supportsTrustedWebActivities(android.content.pm.PackageManager packageManager, java.lang.String str) {
        if (SUPPORTED_CHROME_PACKAGES.contains(str)) {
            return checkChromeVersion(packageManager, str, VERSION_SUPPORTS_TRUSTED_WEB_ACTIVITIES);
        }
        return false;
    }

    public static boolean usesWhiteNavbar(java.lang.String str) {
        return SUPPORTED_CHROME_PACKAGES.contains(str);
    }
}
