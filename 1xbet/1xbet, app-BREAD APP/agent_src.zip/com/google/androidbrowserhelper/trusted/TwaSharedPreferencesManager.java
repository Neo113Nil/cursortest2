package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class TwaSharedPreferencesManager {
    private static final java.lang.String KEY_PROVIDER_PACKAGE = "KEY_PROVIDER_PACKAGE";
    private static final java.lang.String PREFS_NAME = "TrustedWebActivityLauncherPrefs";
    private final android.content.SharedPreferences mSharedPreferences;

    public TwaSharedPreferencesManager(android.content.Context context) {
        this.mSharedPreferences = context.getSharedPreferences(PREFS_NAME, 0);
    }

    public java.lang.String readLastLaunchedProviderPackageName() {
        return this.mSharedPreferences.getString(KEY_PROVIDER_PACKAGE, null);
    }

    public void writeLastLaunchedProviderPackageName(java.lang.String str) {
        this.mSharedPreferences.edit().putString(KEY_PROVIDER_PACKAGE, str).apply();
    }
}
