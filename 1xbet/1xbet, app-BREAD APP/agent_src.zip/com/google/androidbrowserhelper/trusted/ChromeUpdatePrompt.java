package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class ChromeUpdatePrompt {
    private static final java.lang.String UPDATE_CHROME_MESSAGE_RESOURCE_ID = "string/update_chrome_toast";

    private ChromeUpdatePrompt() {
    }

    private static boolean chromeNeedsUpdate(android.content.pm.PackageManager packageManager, java.lang.String str) {
        int versionCode = com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.getVersionCode(packageManager, str);
        return versionCode != 0 && versionCode < 362600000;
    }

    public static void promptIfNeeded(android.content.Context context, java.lang.String str) {
        if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.VERSION_CHECK_CHROME_PACKAGES.contains(str) && chromeNeedsUpdate(context.getPackageManager(), str)) {
            showToastIfResourceExists(context, UPDATE_CHROME_MESSAGE_RESOURCE_ID);
        }
    }

    private static void showToastIfResourceExists(android.content.Context context, java.lang.String str) {
        int identifier = context.getResources().getIdentifier(str, null, context.getPackageName());
        if (identifier == 0) {
            return;
        }
        android.widget.Toast.makeText(context, identifier, 1).show();
    }
}
