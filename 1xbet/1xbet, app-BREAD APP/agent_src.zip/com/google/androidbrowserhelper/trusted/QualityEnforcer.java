package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class QualityEnforcer extends defpackage.b7 {
    static final java.lang.String CRASH = "quality_enforcement.crash";
    static final java.lang.String KEY_CRASH_REASON = "crash_reason";
    static final java.lang.String KEY_SUCCESS = "success";
    private static final java.lang.String TAG = "TwaQualityEnforcement";
    private final com.google.androidbrowserhelper.trusted.QualityEnforcer.Delegate mDelegate;

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public interface Delegate {
        void crash(java.lang.String str);
    }

    public QualityEnforcer() {
        this.mDelegate = new com.google.androidbrowserhelper.trusted.a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$new$0(java.lang.String str) {
        throw new java.lang.RuntimeException(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$new$1(java.lang.String str) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(new defpackage.sc(str, (byte) 3));
    }

    @Override // defpackage.b7
    public android.os.Bundle extraCallbackWithResult(java.lang.String str, android.os.Bundle bundle) {
        java.lang.String string = bundle != null ? bundle.getString(KEY_CRASH_REASON) : null;
        if (string == null) {
            return android.os.Bundle.EMPTY;
        }
        android.os.Bundle bundle2 = new android.os.Bundle();
        if (str.equals(CRASH)) {
            bundle2.putBoolean("success", true);
            this.mDelegate.crash(string);
        }
        return bundle2;
    }

    public QualityEnforcer(com.google.androidbrowserhelper.trusted.QualityEnforcer.Delegate delegate) {
        this.mDelegate = delegate;
    }
}
