package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public final /* synthetic */ class a implements com.google.androidbrowserhelper.trusted.QualityEnforcer.Delegate {
    @Override // com.google.androidbrowserhelper.trusted.QualityEnforcer.Delegate
    public final void crash(java.lang.String str) {
        com.google.androidbrowserhelper.trusted.QualityEnforcer.lambda$new$1(str);
    }
}
