package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class SharingUtils {
    private SharingUtils() {
    }

    public static boolean isShareIntent(android.content.Intent intent) {
        java.lang.String action = intent.getAction();
        return "android.intent.action.SEND".equals(action) || "android.intent.action.SEND_MULTIPLE".equals(action);
    }

    private static java.util.List<java.lang.String> parseAcceptedTypes(java.lang.Object obj) {
        if (!(obj instanceof org.json.JSONArray)) {
            return java.util.Collections.singletonList(obj.toString());
        }
        org.json.JSONArray jSONArray = (org.json.JSONArray) obj;
        java.util.ArrayList arrayList = new java.util.ArrayList(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        return arrayList;
    }

    private static java.util.List<androidx.browser.trusted.sharing.ShareTarget.FileFormField> parseFiles(org.json.JSONArray jSONArray) throws org.json.JSONException {
        if (jSONArray == null) {
            return null;
        }
        java.util.ArrayList arrayList = new java.util.ArrayList(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            org.json.JSONObject jSONObject = jSONArray.getJSONObject(i);
            arrayList.add(new androidx.browser.trusted.sharing.ShareTarget.FileFormField(jSONObject.getString("name"), parseAcceptedTypes(jSONObject.get("accept"))));
        }
        return arrayList;
    }

    public static androidx.browser.trusted.sharing.ShareTarget parseShareTargetJson(java.lang.String str) throws org.json.JSONException {
        org.json.JSONObject jSONObject = new org.json.JSONObject(str);
        java.lang.String string = jSONObject.getString("action");
        java.lang.String strOptString = jSONObject.optString("method", null);
        java.lang.String strOptString2 = jSONObject.optString("enctype", null);
        org.json.JSONObject jSONObject2 = jSONObject.getJSONObject("params");
        return new androidx.browser.trusted.sharing.ShareTarget(string, strOptString, strOptString2, new androidx.browser.trusted.sharing.ShareTarget.Params(jSONObject2.optString("title", "title"), jSONObject2.optString("text", "text"), parseFiles(jSONObject2.optJSONArray("files"))));
    }

    public static androidx.browser.trusted.sharing.ShareData retrieveShareDataFromIntent(android.content.Intent intent) {
        java.util.List parcelableArrayListExtra = null;
        if (!isShareIntent(intent)) {
            return null;
        }
        if ("android.intent.action.SEND".equals(intent.getAction())) {
            android.net.Uri uri = (android.net.Uri) intent.getParcelableExtra("android.intent.extra.STREAM");
            if (uri != null) {
                parcelableArrayListExtra = java.util.Collections.singletonList(uri);
            }
        } else {
            parcelableArrayListExtra = intent.getParcelableArrayListExtra("android.intent.extra.STREAM");
        }
        return new androidx.browser.trusted.sharing.ShareData(intent.getStringExtra("android.intent.extra.SUBJECT"), intent.getStringExtra("android.intent.extra.TEXT"), parcelableArrayListExtra);
    }
}
