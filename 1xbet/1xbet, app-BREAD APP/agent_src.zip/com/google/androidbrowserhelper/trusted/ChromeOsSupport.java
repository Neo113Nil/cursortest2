package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class ChromeOsSupport {
    public static final java.lang.String ARC_FEATURE = "org.chromium.arc";
    public static final java.lang.String ARC_PAYMENT_APP = "org.chromium.arc.payment_app";

    public static boolean isRunningOnArc(android.content.pm.PackageManager packageManager) {
        return packageManager.hasSystemFeature(ARC_FEATURE);
    }
}
