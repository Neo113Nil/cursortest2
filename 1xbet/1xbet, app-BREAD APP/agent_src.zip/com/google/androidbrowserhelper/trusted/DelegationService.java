package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class DelegationService extends androidx.browser.trusted.TrustedWebActivityService {
    private final java.util.List<com.google.androidbrowserhelper.trusted.ExtraCommandHandler> mExtraCommandHandlers = new java.util.ArrayList();
    private com.google.androidbrowserhelper.trusted.SharedPreferencesTokenStore mTokenStore;

    public DelegationService() {
        registerExtraCommandHandler(new com.google.androidbrowserhelper.trusted.NotificationDelegationExtraCommandHandler());
    }

    @Override // androidx.browser.trusted.TrustedWebActivityService
    public androidx.browser.trusted.TokenStore getTokenStore() {
        if (this.mTokenStore == null) {
            this.mTokenStore = new com.google.androidbrowserhelper.trusted.SharedPreferencesTokenStore(this);
            android.content.pm.PackageManager packageManager = getPackageManager();
            if (com.google.androidbrowserhelper.trusted.ChromeOsSupport.isRunningOnArc(packageManager)) {
                this.mTokenStore.store(androidx.browser.trusted.Token.create(com.google.androidbrowserhelper.trusted.ChromeOsSupport.ARC_PAYMENT_APP, packageManager));
            }
        }
        return this.mTokenStore;
    }

    @Override // androidx.browser.trusted.TrustedWebActivityService
    public android.os.Bundle onExtraCommand(java.lang.String str, android.os.Bundle bundle, androidx.browser.trusted.TrustedWebActivityCallbackRemote trustedWebActivityCallbackRemote) {
        java.util.Iterator<com.google.androidbrowserhelper.trusted.ExtraCommandHandler> it = this.mExtraCommandHandlers.iterator();
        while (it.hasNext()) {
            android.os.Bundle bundleHandleExtraCommand = it.next().handleExtraCommand(this, str, bundle, trustedWebActivityCallbackRemote);
            if (bundleHandleExtraCommand.getBoolean(com.google.androidbrowserhelper.trusted.ExtraCommandHandler.EXTRA_COMMAND_SUCCESS)) {
                return bundleHandleExtraCommand;
            }
        }
        return android.os.Bundle.EMPTY;
    }

    public void registerExtraCommandHandler(com.google.androidbrowserhelper.trusted.ExtraCommandHandler extraCommandHandler) {
        this.mExtraCommandHandlers.add(extraCommandHandler);
    }
}
