package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class TwaProviderPicker {
    private static final java.lang.String TAG = "TWAProviderPicker";
    private static java.lang.String sPackageNameForTesting;

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    public static class Action {
        public final int launchMode;
        public final java.lang.String provider;

        public Action(int i, java.lang.String str) {
            this.launchMode = i;
            this.provider = str;
        }
    }

    /* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface LaunchMode {
        public static final int BROWSER = 2;
        public static final int CUSTOM_TAB = 1;
        public static final int TRUSTED_WEB_ACTIVITY = 0;
    }

    private static java.util.Map<java.lang.String, java.lang.Integer> getLaunchModesForCustomTabsServices(android.content.pm.PackageManager packageManager) {
        java.util.List<android.content.pm.ResolveInfo> listQueryIntentServices = packageManager.queryIntentServices(new android.content.Intent("android.support.customtabs.action.CustomTabsService"), 64);
        java.util.HashMap map = new java.util.HashMap();
        for (android.content.pm.ResolveInfo resolveInfo : listQueryIntentServices) {
            java.lang.String str = resolveInfo.serviceInfo.packageName;
            int i = 0;
            if (com.google.androidbrowserhelper.trusted.ChromeLegacyUtils.supportsTrustedWebActivities(packageManager, str)) {
                map.put(str, 0);
            } else {
                android.content.IntentFilter intentFilter = resolveInfo.filter;
                if (intentFilter != null && intentFilter.hasCategory("androidx.browser.trusted.category.TrustedWebActivities")) {
                    i = 1;
                }
                map.put(str, java.lang.Integer.valueOf(i ^ 1));
            }
        }
        return map;
    }

    public static com.google.androidbrowserhelper.trusted.TwaProviderPicker.Action pickProvider(android.content.pm.PackageManager packageManager) {
        java.lang.String str = null;
        android.content.Intent data = new android.content.Intent().setAction("android.intent.action.VIEW").addCategory("android.intent.category.BROWSABLE").setData(android.net.Uri.fromParts("http", "", null));
        java.lang.String str2 = sPackageNameForTesting;
        if (str2 != null) {
            data.setPackage(str2);
        }
        java.util.List<android.content.pm.ResolveInfo> listQueryIntentActivities = packageManager.queryIntentActivities(data, 65536);
        listQueryIntentActivities.addAll(packageManager.queryIntentActivities(data, 131072));
        java.util.Map<java.lang.String, java.lang.Integer> launchModesForCustomTabsServices = getLaunchModesForCustomTabsServices(packageManager);
        java.util.Iterator<android.content.pm.ResolveInfo> it = listQueryIntentActivities.iterator();
        java.lang.String str3 = null;
        while (it.hasNext()) {
            java.lang.String str4 = it.next().activityInfo.packageName;
            int iIntValue = launchModesForCustomTabsServices.containsKey(str4) ? launchModesForCustomTabsServices.get(str4).intValue() : 2;
            if (iIntValue == 0) {
                android.util.Log.d(TAG, "Found TWA provider, finishing search: " + str4);
                return new com.google.androidbrowserhelper.trusted.TwaProviderPicker.Action(0, str4);
            }
            if (iIntValue == 1) {
                android.util.Log.d(TAG, "Found Custom Tabs provider: " + str4);
                if (str == null) {
                    str = str4;
                }
            } else if (iIntValue == 2) {
                android.util.Log.d(TAG, "Found browser: " + str4);
                if (str3 == null) {
                    str3 = str4;
                }
            }
        }
        if (str != null) {
            android.util.Log.d(TAG, "Found no TWA providers, using first Custom Tabs provider: ".concat(str));
            return new com.google.androidbrowserhelper.trusted.TwaProviderPicker.Action(1, str);
        }
        android.util.Log.d(TAG, "Found no TWA providers, using first browser: " + str3);
        return new com.google.androidbrowserhelper.trusted.TwaProviderPicker.Action(2, str3);
    }

    public static void restrictToPackageForTesting(java.lang.String str) {
        sPackageNameForTesting = str;
    }
}
