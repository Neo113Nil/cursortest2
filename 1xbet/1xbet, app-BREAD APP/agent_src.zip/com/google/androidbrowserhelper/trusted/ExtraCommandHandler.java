package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public interface ExtraCommandHandler {
    public static final java.lang.String EXTRA_COMMAND_SUCCESS = "success";

    android.os.Bundle handleExtraCommand(android.content.Context context, java.lang.String str, android.os.Bundle bundle, androidx.browser.trusted.TrustedWebActivityCallbackRemote trustedWebActivityCallbackRemote);
}
