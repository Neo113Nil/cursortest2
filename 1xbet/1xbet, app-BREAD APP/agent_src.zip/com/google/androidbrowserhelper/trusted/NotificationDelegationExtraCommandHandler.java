package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class NotificationDelegationExtraCommandHandler implements com.google.androidbrowserhelper.trusted.ExtraCommandHandler {
    static final java.lang.String COMMAND_CHECK_NOTIFICATION_PERMISSION = "checkNotificationPermission";
    private static final java.lang.String COMMAND_GET_NOTIFICATION_PERMISSION_REQUEST_PENDING_INTENT = "getNotificationPermissionRequestPendingIntent";
    private static final java.lang.String KEY_NOTIFICATION_CHANNEL_NAME = "notificationChannelName";
    private static final java.lang.String KEY_NOTIFICATION_PERMISSION_REQUEST_PENDING_INTENT = "notificationPermissionRequestPendingIntent";

    @Override // com.google.androidbrowserhelper.trusted.ExtraCommandHandler
    public android.os.Bundle handleExtraCommand(android.content.Context context, java.lang.String str, android.os.Bundle bundle, androidx.browser.trusted.TrustedWebActivityCallbackRemote trustedWebActivityCallbackRemote) {
        android.os.Bundle bundle2 = new android.os.Bundle();
        bundle2.putBoolean(com.google.androidbrowserhelper.trusted.ExtraCommandHandler.EXTRA_COMMAND_SUCCESS, false);
        java.lang.String string = bundle.getString(KEY_NOTIFICATION_CHANNEL_NAME);
        str.getClass();
        if (str.equals(COMMAND_CHECK_NOTIFICATION_PERMISSION)) {
            if (!android.text.TextUtils.isEmpty(string)) {
                int i = !com.google.androidbrowserhelper.trusted.NotificationUtils.areNotificationsEnabled(context, string) ? 1 : 0;
                if (i == 1 && !com.google.androidbrowserhelper.trusted.PrefUtils.hasRequestedNotificationPermission(context)) {
                    i = 2;
                }
                bundle2.putInt("permissionStatus", i);
                bundle2.putBoolean(com.google.androidbrowserhelper.trusted.ExtraCommandHandler.EXTRA_COMMAND_SUCCESS, true);
                return bundle2;
            }
        } else if (str.equals(COMMAND_GET_NOTIFICATION_PERMISSION_REQUEST_PENDING_INTENT) && !android.text.TextUtils.isEmpty(string)) {
            bundle2.putParcelable(KEY_NOTIFICATION_PERMISSION_REQUEST_PENDING_INTENT, com.google.androidbrowserhelper.trusted.NotificationPermissionRequestActivity.createPermissionRequestPendingIntent(context, string));
            bundle2.putBoolean(com.google.androidbrowserhelper.trusted.ExtraCommandHandler.EXTRA_COMMAND_SUCCESS, true);
            return bundle2;
        }
        return bundle2;
    }
}
