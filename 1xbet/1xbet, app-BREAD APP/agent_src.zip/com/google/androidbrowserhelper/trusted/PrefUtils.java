package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class PrefUtils {
    private static final java.lang.String KEY_HAS_REQUESTED_NOTIFICATION_PERMISSION = "HAS_REQUESTED_NOTIFICATION_PERMISSION";
    private static final java.lang.String SHARED_PREFERENCES_NAME = "com.google.androidbrowserhelper";

    private PrefUtils() {
    }

    public static android.content.SharedPreferences getAppSharedPreferences(android.content.Context context) {
        return context.getApplicationContext().getSharedPreferences(SHARED_PREFERENCES_NAME, 0);
    }

    public static boolean hasRequestedNotificationPermission(android.content.Context context) {
        return getAppSharedPreferences(context).getBoolean(KEY_HAS_REQUESTED_NOTIFICATION_PERMISSION, false);
    }

    public static void setHasRequestedNotificationPermission(android.content.Context context) {
        getAppSharedPreferences(context).edit().putBoolean(KEY_HAS_REQUESTED_NOTIFICATION_PERMISSION, true).apply();
    }
}
