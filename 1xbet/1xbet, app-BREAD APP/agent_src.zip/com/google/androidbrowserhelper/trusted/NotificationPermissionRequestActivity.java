package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class NotificationPermissionRequestActivity extends android.app.Activity {
    private static final java.lang.String EXTRA_MESSENGER = "messenger";
    private static final java.lang.String EXTRA_NOTIFICATION_CHANNEL_NAME = "notificationChannelName";
    static final java.lang.String KEY_PERMISSION_STATUS = "permissionStatus";
    private static final java.lang.String PERMISSION_POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS";
    private static final java.lang.String TAG = "Notifications";
    private static final int VERSION_T = 33;
    private java.lang.String mChannelName;
    private android.os.Messenger mMessenger;

    public static android.app.PendingIntent createPermissionRequestPendingIntent(android.content.Context context, java.lang.String str) {
        android.content.Intent intent = new android.content.Intent(context.getApplicationContext(), (java.lang.Class<?>) com.google.androidbrowserhelper.trusted.NotificationPermissionRequestActivity.class);
        intent.putExtra(EXTRA_NOTIFICATION_CHANNEL_NAME, str);
        return android.app.PendingIntent.getActivity(context.getApplicationContext(), 0, intent, android.os.Build.VERSION.SDK_INT >= 31 ? 33554432 : 0);
    }

    private static void sendPermissionMessage(android.os.Messenger messenger, boolean z) throws android.os.RemoteException {
        android.os.Bundle bundle = new android.os.Bundle();
        bundle.putInt(KEY_PERMISSION_STATUS, !z ? 1 : 0);
        android.os.Message messageObtain = android.os.Message.obtain();
        messageObtain.setData(bundle);
        try {
            messenger.send(messageObtain);
        } catch (android.os.RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        super.onCreate(bundle);
        this.mChannelName = getIntent().getStringExtra(EXTRA_NOTIFICATION_CHANNEL_NAME);
        android.os.Messenger messenger = (android.os.Messenger) getIntent().getParcelableExtra(EXTRA_MESSENGER);
        this.mMessenger = messenger;
        if (this.mChannelName == null || messenger == null) {
            android.util.Log.w(TAG, "Finishing because no channel name or messenger for returning the result was provided.");
            finish();
            return;
        }
        int i = android.os.Build.VERSION.SDK_INT;
        if (i >= VERSION_T && getApplicationContext().getApplicationInfo().targetSdkVersion < VERSION_T) {
            com.google.androidbrowserhelper.trusted.NotificationUtils.createNotificationChannel(this, this.mChannelName);
        }
        java.lang.String[] strArr = {PERMISSION_POST_NOTIFICATIONS};
        java.util.HashSet hashSet = new java.util.HashSet();
        if (android.text.TextUtils.isEmpty(strArr[0])) {
            defpackage.q8.b(defpackage.v5.i(new java.lang.StringBuilder("Permission request for permissions "), java.util.Arrays.toString(strArr), " must not contain null or empty values"));
            return;
        }
        if (i < VERSION_T && android.text.TextUtils.equals(strArr[0], PERMISSION_POST_NOTIFICATIONS)) {
            hashSet.add(0);
        }
        int size = hashSet.size();
        java.lang.String[] strArr2 = size > 0 ? new java.lang.String[1 - size] : strArr;
        if (size > 0) {
            if (size == 1) {
                return;
            }
            if (!hashSet.contains(0)) {
                strArr2[0] = strArr[0];
            }
        }
        requestPermissions(strArr, 0);
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, java.lang.String[] strArr, int[] iArr) throws android.os.RemoteException {
        boolean zAreNotificationsEnabled = false;
        int i2 = 0;
        while (true) {
            if (i2 >= strArr.length) {
                break;
            }
            if (strArr[i2].equals(PERMISSION_POST_NOTIFICATIONS)) {
                com.google.androidbrowserhelper.trusted.PrefUtils.setHasRequestedNotificationPermission(this);
                if (iArr[i2] == 0) {
                    zAreNotificationsEnabled = true;
                }
            } else {
                i2++;
            }
        }
        if (!zAreNotificationsEnabled) {
            zAreNotificationsEnabled = com.google.androidbrowserhelper.trusted.NotificationUtils.areNotificationsEnabled(this, this.mChannelName);
        }
        sendPermissionMessage(this.mMessenger, zAreNotificationsEnabled);
        finish();
    }
}
