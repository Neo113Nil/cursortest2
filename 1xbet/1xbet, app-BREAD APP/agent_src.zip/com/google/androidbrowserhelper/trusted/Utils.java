package com.google.androidbrowserhelper.trusted;

/* compiled from: r8-map-id-8cc992600e412236b882cae5c2253031d983d7d828c4afbf3060a63d36e37072 */
/* loaded from: classes.dex */
public class Utils {
    private static void addSystemUiVisibilityFlag(android.app.Activity activity, int i) {
        android.view.View rootView = activity.getWindow().getDecorView().getRootView();
        rootView.setSystemUiVisibility(i | rootView.getSystemUiVisibility());
    }

    public static android.graphics.Bitmap convertDrawableToBitmap(android.content.Context context, int i) {
        android.graphics.drawable.Drawable drawable = context.getDrawable(i);
        if (drawable == null) {
            return null;
        }
        android.graphics.Bitmap bitmapCreateBitmap = android.graphics.Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bitmapCreateBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmapCreateBitmap;
    }

    private static float luminanceOfColorComponent(float f) {
        float f2 = f / 255.0f;
        return f2 < 0.03928f ? f2 / 12.92f : (float) java.lang.Math.pow((f2 + 0.055f) / 1.055f, 2.4000000953674316d);
    }

    public static void setNavigationBarColor(android.app.Activity activity, int i) {
        activity.getWindow().setNavigationBarColor(i);
        if (android.os.Build.VERSION.SDK_INT < 26 || !shouldUseDarkIconsOnBackground(i)) {
            return;
        }
        addSystemUiVisibilityFlag(activity, 16);
    }

    public static void setStatusBarColor(android.app.Activity activity, int i) {
        activity.getWindow().setStatusBarColor(i);
        if (shouldUseDarkIconsOnBackground(i)) {
            addSystemUiVisibilityFlag(activity, 8192);
        }
    }

    private static boolean shouldUseDarkIconsOnBackground(int i) {
        return java.lang.Math.abs(1.05f / (((luminanceOfColorComponent((float) android.graphics.Color.blue(i)) * 0.0722f) + ((luminanceOfColorComponent((float) android.graphics.Color.green(i)) * 0.7152f) + (luminanceOfColorComponent((float) android.graphics.Color.red(i)) * 0.2126f))) + 0.05f)) < 3.0f;
    }
}
