package com.ultrafanatics.football.game.splash.core.junk;

import java.util.ArrayList;
import kotlin.Metadata;

/* compiled from: RequestResponse_2474.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005J\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/ultrafanatics/football/game/splash/core/junk/RequestResponse_2474;", "", "<init>", "()V", "process", "", "validate", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class RequestResponse_2474 {
    public static final int $stable = 0;

    public final void process() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < 11; i++) {
            arrayList.add("item_" + i);
        }
    }

    public final boolean validate() {
        return System.currentTimeMillis() % 2 == 0;
    }
}
