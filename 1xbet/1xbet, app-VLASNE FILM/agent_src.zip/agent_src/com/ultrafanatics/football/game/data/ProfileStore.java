package com.ultrafanatics.football.game.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.ultrafanatics.football.game.domain.Callsigns;
import com.ultrafanatics.football.game.domain.Profile;
import com.ultrafanatics.football.game.domain.ProfileRepository;
import com.ultrafanatics.football.game.domain.Settings;
import com.ultrafanatics.football.game.presentation.Routes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ProfileStore.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0004\b\u0007\u0018\u0000 \u001a2\u00020\u0001:\u0001\u001aB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\b\u001a\u00020\tH\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tH\u0016J\b\u0010\r\u001a\u00020\u000bH\u0016J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\tH\u0002J \u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00140\u0012*\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\u0013H\u0002J\u001a\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00130\u0017*\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\u0013H\u0002J\u0010\u0010\u0018\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u000fH\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Lcom/ultrafanatics/football/game/data/ProfileStore;", "Lcom/ultrafanatics/football/game/domain/ProfileRepository;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "prefs", "Landroid/content/SharedPreferences;", "load", "Lcom/ultrafanatics/football/game/domain/Profile;", "save", "", "profile", "wipe", "toJson", "Lorg/json/JSONObject;", "p", "intMap", "", "", "", "key", "csv", "", "fromJson", "o", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ProfileStore implements ProfileRepository {
    private static final String KEY = "profile_v1";
    private final SharedPreferences prefs;
    public static final int $stable = 8;

    public ProfileStore(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("ultra_fanatics_save", 0);
        Intrinsics.checkNotNullExpressionValue(sharedPreferences, "getSharedPreferences(...)");
        this.prefs = sharedPreferences;
    }

    @Override // com.ultrafanatics.football.game.domain.ProfileRepository
    public Profile load() {
        String string = this.prefs.getString(KEY, null);
        if (string == null) {
            return new Profile(null, 0, 0, 0, 0, 0, 0, 0, null, 0, null, null, false, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
        }
        try {
            return fromJson(new JSONObject(string));
        } catch (Throwable unused) {
            return new Profile(null, 0, 0, 0, 0, 0, 0, 0, null, 0, null, null, false, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
        }
    }

    @Override // com.ultrafanatics.football.game.domain.ProfileRepository
    public void save(Profile profile) {
        Intrinsics.checkNotNullParameter(profile, "profile");
        this.prefs.edit().putString(KEY, toJson(profile).toString()).apply();
    }

    @Override // com.ultrafanatics.football.game.domain.ProfileRepository
    public void wipe() {
        this.prefs.edit().clear().apply();
    }

    private final JSONObject toJson(Profile p) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("name", p.getName());
        jSONObject.put("avatar", p.getAvatar());
        jSONObject.put("coins", p.getCoins());
        jSONObject.put("gems", p.getGems());
        jSONObject.put("xp", p.getXp());
        jSONObject.put("stars", p.getStars());
        jSONObject.put("currentLevel", p.getCurrentLevel());
        jSONObject.put("dayStreak", p.getDayStreak());
        jSONObject.put("lastPlayDate", p.getLastPlayDate());
        jSONObject.put("dailyRewardDay", p.getDailyRewardDay());
        jSONObject.put("lastDailyClaim", p.getLastDailyClaim());
        jSONObject.put("lastDailyChallenge", p.getLastDailyChallenge());
        jSONObject.put("dailyChallengeCleared", p.getDailyChallengeCleared());
        jSONObject.put("tournamentRound", p.getTournamentRound());
        jSONObject.put("tournamentScore", p.getTournamentScore());
        jSONObject.put("missionDate", p.getMissionDate());
        jSONObject.put("weeklyDate", p.getWeeklyDate());
        JSONObject jSONObject2 = new JSONObject();
        for (Map.Entry<Integer, Integer> entry : p.getLevelStars().entrySet()) {
            int iIntValue = entry.getKey().intValue();
            jSONObject2.put(String.valueOf(iIntValue), entry.getValue().intValue());
        }
        Unit unit = Unit.INSTANCE;
        jSONObject.put("levelStars", jSONObject2);
        JSONObject jSONObject3 = new JSONObject();
        for (Map.Entry<String, Integer> entry2 : p.getBoosters().entrySet()) {
            jSONObject3.put(entry2.getKey(), entry2.getValue().intValue());
        }
        Unit unit2 = Unit.INSTANCE;
        jSONObject.put("boosters", jSONObject3);
        JSONObject jSONObject4 = new JSONObject();
        for (Map.Entry<String, Integer> entry3 : p.getBestScores().entrySet()) {
            jSONObject4.put(entry3.getKey(), entry3.getValue().intValue());
        }
        Unit unit3 = Unit.INSTANCE;
        jSONObject.put("bestScores", jSONObject4);
        JSONObject jSONObject5 = new JSONObject();
        for (Map.Entry<String, Integer> entry4 : p.getStats().entrySet()) {
            jSONObject5.put(entry4.getKey(), entry4.getValue().intValue());
        }
        Unit unit4 = Unit.INSTANCE;
        jSONObject.put("stats", jSONObject5);
        jSONObject.put("achievementsClaimed", CollectionsKt.joinToString$default(p.getAchievementsClaimed(), ",", null, null, 0, null, null, 62, null));
        jSONObject.put(Routes.MISSIONS, CollectionsKt.joinToString$default(p.getMissions(), ",", null, null, 0, null, null, 62, null));
        JSONObject jSONObject6 = new JSONObject();
        for (Map.Entry<String, Integer> entry5 : p.getMissionProgress().entrySet()) {
            jSONObject6.put(entry5.getKey(), entry5.getValue().intValue());
        }
        Unit unit5 = Unit.INSTANCE;
        jSONObject.put("missionProgress", jSONObject6);
        jSONObject.put("missionsClaimed", CollectionsKt.joinToString$default(p.getMissionsClaimed(), ",", null, null, 0, null, null, 62, null));
        jSONObject.put("weeklyMissions", CollectionsKt.joinToString$default(p.getWeeklyMissions(), ",", null, null, 0, null, null, 62, null));
        JSONObject jSONObject7 = new JSONObject();
        for (Map.Entry<String, Integer> entry6 : p.getWeeklyProgress().entrySet()) {
            jSONObject7.put(entry6.getKey(), entry6.getValue().intValue());
        }
        Unit unit6 = Unit.INSTANCE;
        jSONObject.put("weeklyProgress", jSONObject7);
        jSONObject.put("weeklyClaimed", CollectionsKt.joinToString$default(p.getWeeklyClaimed(), ",", null, null, 0, null, null, 62, null));
        jSONObject.put("challengesDone", CollectionsKt.joinToString$default(p.getChallengesDone(), ",", null, null, 0, null, null, 62, null));
        jSONObject.put("collectionSeen", CollectionsKt.joinToString$default(p.getCollectionSeen(), ",", null, null, 0, null, null, 62, null));
        JSONObject jSONObject8 = new JSONObject();
        jSONObject8.put("sound", p.getSettings().getSound());
        jSONObject8.put("music", p.getSettings().getMusic());
        jSONObject8.put("vibration", p.getSettings().getVibration());
        jSONObject8.put("animations", p.getSettings().getAnimations());
        jSONObject8.put("showHints", p.getSettings().getShowHints());
        jSONObject8.put("gridGuides", p.getSettings().getGridGuides());
        jSONObject8.put("leftHanded", p.getSettings().getLeftHanded());
        jSONObject8.put("sfxVolume", p.getSettings().getSfxVolume());
        jSONObject8.put("musicVolume", p.getSettings().getMusicVolume());
        Unit unit7 = Unit.INSTANCE;
        jSONObject.put(Routes.SETTINGS, jSONObject8);
        return jSONObject;
    }

    private final Map<String, Integer> intMap(JSONObject jSONObject, String str) {
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject(str);
        if (jSONObjectOptJSONObject == null) {
            return MapsKt.emptyMap();
        }
        HashMap map = new HashMap();
        Iterator<String> itKeys = jSONObjectOptJSONObject.keys();
        Intrinsics.checkNotNullExpressionValue(itKeys, "keys(...)");
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            map.put(next, Integer.valueOf(jSONObjectOptJSONObject.optInt(next)));
        }
        return map;
    }

    private final List<String> csv(JSONObject jSONObject, String str) {
        String strOptString = jSONObject.optString(str, "");
        Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
        List listSplit$default = StringsKt.split$default((CharSequence) strOptString, new String[]{","}, false, 0, 6, (Object) null);
        ArrayList arrayList = new ArrayList();
        for (Object obj : listSplit$default) {
            if (!StringsKt.isBlank((String) obj)) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    private final Profile fromJson(JSONObject o) {
        JSONObject jSONObjectOptJSONObject = o.optJSONObject(Routes.SETTINGS);
        if (jSONObjectOptJSONObject == null) {
            jSONObjectOptJSONObject = new JSONObject();
        }
        Profile profile = new Profile(null, 0, 0, 0, 0, 0, 0, 0, null, 0, null, null, false, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
        String strSanitize = Callsigns.INSTANCE.sanitize(o.optString("name", profile.getName()));
        int iOptInt = o.optInt("avatar", 0);
        int iOptInt2 = o.optInt("coins", profile.getCoins());
        int iOptInt3 = o.optInt("gems", profile.getGems());
        int iOptInt4 = o.optInt("xp", 0);
        int iOptInt5 = o.optInt("stars", 0);
        int iCoerceIn = RangesKt.coerceIn(o.optInt("currentLevel", 1), 1, 80);
        int iOptInt6 = o.optInt("dayStreak", 0);
        String strOptString = o.optString("lastPlayDate", "");
        Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
        int iOptInt7 = o.optInt("dailyRewardDay", 0);
        String strOptString2 = o.optString("lastDailyClaim", "");
        Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
        String strOptString3 = o.optString("lastDailyChallenge", "");
        Intrinsics.checkNotNullExpressionValue(strOptString3, "optString(...)");
        boolean zOptBoolean = o.optBoolean("dailyChallengeCleared", false);
        int iOptInt8 = o.optInt("tournamentRound", 0);
        int iOptInt9 = o.optInt("tournamentScore", 0);
        String strOptString4 = o.optString("missionDate", "");
        Intrinsics.checkNotNullExpressionValue(strOptString4, "optString(...)");
        String strOptString5 = o.optString("weeklyDate", "");
        Intrinsics.checkNotNullExpressionValue(strOptString5, "optString(...)");
        Map<String, Integer> mapIntMap = intMap(o, "levelStars");
        LinkedHashMap linkedHashMap = new LinkedHashMap(MapsKt.mapCapacity(mapIntMap.size()));
        for (Iterator it = mapIntMap.entrySet().iterator(); it.hasNext(); it = it) {
            Map.Entry entry = (Map.Entry) it.next();
            linkedHashMap.put(Integer.valueOf(Integer.parseInt((String) entry.getKey())), entry.getValue());
        }
        return new Profile(strSanitize, iOptInt, iOptInt2, iOptInt3, iOptInt4, iOptInt5, iCoerceIn, iOptInt6, strOptString, iOptInt7, strOptString2, strOptString3, zOptBoolean, iOptInt8, iOptInt9, strOptString4, strOptString5, linkedHashMap, MapsKt.plus(profile.getBoosters(), intMap(o, "boosters")), intMap(o, "bestScores"), intMap(o, "stats"), CollectionsKt.toSet(csv(o, "achievementsClaimed")), csv(o, Routes.MISSIONS), intMap(o, "missionProgress"), CollectionsKt.toSet(csv(o, "missionsClaimed")), csv(o, "weeklyMissions"), intMap(o, "weeklyProgress"), CollectionsKt.toSet(csv(o, "weeklyClaimed")), CollectionsKt.toSet(csv(o, "challengesDone")), CollectionsKt.toSet(csv(o, "collectionSeen")), new Settings(jSONObjectOptJSONObject.optBoolean("sound", true), jSONObjectOptJSONObject.optBoolean("music", true), jSONObjectOptJSONObject.optBoolean("vibration", true), jSONObjectOptJSONObject.optBoolean("animations", true), jSONObjectOptJSONObject.optBoolean("showHints", true), jSONObjectOptJSONObject.optBoolean("gridGuides", true), jSONObjectOptJSONObject.optBoolean("leftHanded", false), jSONObjectOptJSONObject.optInt("sfxVolume", 80), jSONObjectOptJSONObject.optInt("musicVolume", 60)));
    }
}
