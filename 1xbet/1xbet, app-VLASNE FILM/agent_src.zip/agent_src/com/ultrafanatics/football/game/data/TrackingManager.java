package com.ultrafanatics.football.game.data;

import android.content.Context;
import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerLib;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.ultrafanatics.football.game.data.TrackingManager;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.TimeoutKt;

/* compiled from: TrackingManager.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010J\u0010\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0005H\u0086@¢\u0006\u0002\u0010\u0014J\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0005H\u0086@¢\u0006\u0002\u0010\u0014J\u000e\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u0010R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/ultrafanatics/football/game/data/TrackingManager;", "", "<init>", "()V", "AF_KEY", "", "CAMPAIGN_WAIT_TIMEOUT_MS", "", "CAMPAIGN_FAIL_GRACE_MS", "AD_ID_WAIT_TIMEOUT_MS", "adIdDeferred", "Lkotlinx/coroutines/CompletableDeferred;", "campaignDeferred", "init", "", "context", "Landroid/content/Context;", "fetchAdId", "startAppsFlyer", "getCampaign", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getAdId", "getDeviceId", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class TrackingManager {
    private static final long AD_ID_WAIT_TIMEOUT_MS = 2500;
    private static final String AF_KEY = "xudgnAsizL7FSF5bjtHW29";
    private static final long CAMPAIGN_FAIL_GRACE_MS = 2500;
    private static final long CAMPAIGN_WAIT_TIMEOUT_MS = 10000;
    public static final TrackingManager INSTANCE = new TrackingManager();
    private static final CompletableDeferred<String> adIdDeferred = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
    private static final CompletableDeferred<String> campaignDeferred = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
    public static final int $stable = 8;

    private TrackingManager() {
    }

    public final void init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        fetchAdId(context);
        startAppsFlyer(context);
    }

    private final void fetchAdId(final Context context) {
        new Thread(new Runnable() { // from class: com.ultrafanatics.football.game.data.TrackingManager$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                TrackingManager.fetchAdId$lambda$0(context);
            }
        }).start();
    }

    static final void fetchAdId$lambda$0(Context context) throws Throwable {
        try {
            AdvertisingIdClient.Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            Intrinsics.checkNotNullExpressionValue(advertisingIdInfo, "getAdvertisingIdInfo(...)");
            String id = advertisingIdInfo.isLimitAdTrackingEnabled() ? null : advertisingIdInfo.getId();
            CompletableDeferred<String> completableDeferred = adIdDeferred;
            if (completableDeferred.isCompleted()) {
                return;
            }
            completableDeferred.complete(id);
        } catch (Exception unused) {
            CompletableDeferred<String> completableDeferred2 = adIdDeferred;
            if (completableDeferred2.isCompleted()) {
                return;
            }
            completableDeferred2.complete(null);
        }
    }

    private final void startAppsFlyer(Context context) {
        Context applicationContext = context.getApplicationContext();
        try {
            AppsFlyerLib.getInstance().init(AF_KEY, new AnonymousClass1(), applicationContext);
            AppsFlyerLib.getInstance().start(applicationContext);
        } catch (Exception unused) {
            CompletableDeferred<String> completableDeferred = campaignDeferred;
            if (completableDeferred.isCompleted()) {
                return;
            }
            completableDeferred.complete(null);
        }
    }

    /* compiled from: TrackingManager.kt */
    @Metadata(d1 = {"\u0000!\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\b\u0006*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001e\u0010\u0002\u001a\u00020\u00032\u0014\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0005H\u0016J\u0012\u0010\b\u001a\u00020\u00032\b\u0010\t\u001a\u0004\u0018\u00010\u0006H\u0016J\u001e\u0010\n\u001a\u00020\u00032\u0014\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005H\u0016J\u0012\u0010\f\u001a\u00020\u00032\b\u0010\u000b\u001a\u0004\u0018\u00010\u0006H\u0016¨\u0006\r"}, d2 = {"com/ultrafanatics/football/game/data/TrackingManager$startAppsFlyer$1", "Lcom/appsflyer/AppsFlyerConversionListener;", "onConversionDataSuccess", "", "data", "", "", "", "onConversionDataFail", "error", "onAppOpenAttribution", "p0", "onAttributionFailure", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.ultrafanatics.football.game.data.TrackingManager$startAppsFlyer$1, reason: invalid class name */
    public static final class AnonymousClass1 implements AppsFlyerConversionListener {
        @Override // com.appsflyer.AppsFlyerConversionListener
        public void onAppOpenAttribution(Map<String, String> p0) {
        }

        @Override // com.appsflyer.AppsFlyerConversionListener
        public void onAttributionFailure(String p0) {
        }

        AnonymousClass1() {
        }

        @Override // com.appsflyer.AppsFlyerConversionListener
        public void onConversionDataSuccess(Map<String, ? extends Object> data) {
            Object obj = data != null ? data.get("campaign") : null;
            String str = obj instanceof String ? (String) obj : null;
            if (TrackingManager.campaignDeferred.isCompleted()) {
                return;
            }
            TrackingManager.campaignDeferred.complete(str);
        }

        @Override // com.appsflyer.AppsFlyerConversionListener
        public void onConversionDataFail(String error) {
            new Thread(new Runnable() { // from class: com.ultrafanatics.football.game.data.TrackingManager$startAppsFlyer$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() throws InterruptedException {
                    TrackingManager.AnonymousClass1.onConversionDataFail$lambda$0();
                }
            }).start();
        }

        static final void onConversionDataFail$lambda$0() throws InterruptedException {
            try {
                Thread.sleep(2500L);
            } catch (InterruptedException unused) {
            }
            if (TrackingManager.campaignDeferred.isCompleted()) {
                return;
            }
            TrackingManager.campaignDeferred.complete(null);
        }
    }

    /* compiled from: TrackingManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.ultrafanatics.football.game.data.TrackingManager$getCampaign$2", f = "TrackingManager.kt", i = {}, l = {71}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.ultrafanatics.football.game.data.TrackingManager$getCampaign$2, reason: invalid class name and case insensitive filesystem */
    static final class C03602 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
        int label;

        C03602(Continuation<? super C03602> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C03602(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
            return ((C03602) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: TrackingManager.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.ultrafanatics.football.game.data.TrackingManager$getCampaign$2$1", f = "TrackingManager.kt", i = {}, l = {72}, m = "invokeSuspend", n = {}, s = {}, v = 1)
        /* renamed from: com.ultrafanatics.football.game.data.TrackingManager$getCampaign$2$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
            int label;

            AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass1(continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) throws Throwable {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i != 0) {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                    return obj;
                }
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                Object objAwait = TrackingManager.campaignDeferred.await(this);
                return objAwait == coroutine_suspended ? coroutine_suspended : objAwait;
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i != 0) {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                return obj;
            }
            ResultKt.throwOnFailure(obj);
            this.label = 1;
            Object objWithTimeoutOrNull = TimeoutKt.withTimeoutOrNull(10000L, new AnonymousClass1(null), this);
            return objWithTimeoutOrNull == coroutine_suspended ? coroutine_suspended : objWithTimeoutOrNull;
        }
    }

    public final Object getCampaign(Continuation<? super String> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new C03602(null), continuation);
    }

    /* compiled from: TrackingManager.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.ultrafanatics.football.game.data.TrackingManager$getAdId$2", f = "TrackingManager.kt", i = {}, l = {77}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    /* renamed from: com.ultrafanatics.football.game.data.TrackingManager$getAdId$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* compiled from: TrackingManager.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @DebugMetadata(c = "com.ultrafanatics.football.game.data.TrackingManager$getAdId$2$1", f = "TrackingManager.kt", i = {}, l = {78}, m = "invokeSuspend", n = {}, s = {}, v = 1)
        /* renamed from: com.ultrafanatics.football.game.data.TrackingManager$getAdId$2$1, reason: invalid class name */
        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
            int label;

            AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                super(2, continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass1(continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) throws Throwable {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i != 0) {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ResultKt.throwOnFailure(obj);
                    return obj;
                }
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                Object objAwait = TrackingManager.adIdDeferred.await(this);
                return objAwait == coroutine_suspended ? coroutine_suspended : objAwait;
            }
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i != 0) {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                return obj;
            }
            ResultKt.throwOnFailure(obj);
            this.label = 1;
            Object objWithTimeoutOrNull = TimeoutKt.withTimeoutOrNull(2500L, new AnonymousClass1(null), this);
            return objWithTimeoutOrNull == coroutine_suspended ? coroutine_suspended : objWithTimeoutOrNull;
        }
    }

    public final Object getAdId(Continuation<? super String> continuation) {
        return BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(null), continuation);
    }

    public final String getDeviceId(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        String appsFlyerUID = AppsFlyerLib.getInstance().getAppsFlyerUID(context);
        return appsFlyerUID == null ? "" : appsFlyerUID;
    }
}
