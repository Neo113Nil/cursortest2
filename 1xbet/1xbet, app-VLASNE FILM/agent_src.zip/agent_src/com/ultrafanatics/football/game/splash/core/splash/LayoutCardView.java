package com.ultrafanatics.football.game.splash.core.splash;

import com.google.common.base.Ascii;
import com.google.common.primitives.SignedBytes;
import kotlin.Metadata;

/* compiled from: LayoutCardView.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Lcom/ultrafanatics/football/game/splash/core/splash/LayoutCardView;", "", "<init>", "()V", "FirebaseWidget", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class LayoutCardView {
    public static final int $stable = 0;

    /* compiled from: LayoutCardView.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007¨\u0006\f"}, d2 = {"Lcom/ultrafanatics/football/game/splash/core/splash/LayoutCardView$FirebaseWidget;", "", "<init>", "()V", "km", "", "getKm", "()[B", "ak", "getAk", "t", "getT", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class FirebaseWidget {
        public static final FirebaseWidget INSTANCE = new FirebaseWidget();
        private static final byte[] km = {-46, 33, -64, 104, -58, -94, Ascii.RS, 87, -76, -42, -80, -47, 55, 52, -115, 38};
        private static final byte[] ak = {105, -39, Ascii.SO, 69, 117, -30, -63, 107, Ascii.FS, 107, 124, 78, 103, -28, 66, -101, -18, -89, -25, Ascii.NAK, 120, 3, -49, -66, 40, -88, -79, -35, 47, -27, 49, 107};
        private static final byte[] t = {-79, 78, -83, 70, -77, -50, 106, 37, -43, -80, -47, -65, 86, SignedBytes.MAX_POWER_OF_TWO, -28, 69, -95, Ascii.SI, -90, 7, -87, -42, 124, 54, -40, -70, -98, -74, 86, 89, -24, 8, -95, 81, -84, 9, -75, -54, 48, 52, -37, -92, -43, -1, 68, 68, -31, 71, -95, 73, -18, 44, -89, -42, 127, 4, -51, -72, -45, -127, 69, 91, -5, 79, -74, 68, -78};
        public static final int $stable = 8;

        private FirebaseWidget() {
        }

        public final byte[] getKm() {
            return km;
        }

        public final byte[] getAk() {
            return ak;
        }

        public final byte[] getT() {
            return t;
        }
    }
}
