package com.ultrafanatics.football.game.data.audio;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import com.ultrafanatics.football.game.domain.Sfx;
import com.ultrafanatics.football.game.domain.SoundPlayer;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: SoundManager.kt */
@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010\u0007\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0013\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u0001:\u0001;B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020,H\u0016J\u0010\u0010-\u001a\u00020*2\u0006\u0010+\u001a\u00020,H\u0002J\u0016\u0010.\u001a\b\u0012\u0004\u0012\u0002000/2\u0006\u0010+\u001a\u00020,H\u0002J\u0010\u00101\u001a\u00020*2\u0006\u0010+\u001a\u00020,H\u0002J\b\u00106\u001a\u00020$H\u0002J\b\u00107\u001a\u00020*H\u0016J\b\u00108\u001a\u00020*H\u0016J\b\u00109\u001a\u00020*H\u0016J\b\u0010:\u001a\u00020*H\u0016R\u0016\u0010\u0006\u001a\n \u0007*\u0004\u0018\u00010\u00030\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n \u0007*\u0004\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u00020\rX\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\rX\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u000f\"\u0004\b\u0014\u0010\u0011R\u001a\u0010\u0015\u001a\u00020\u0016X\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\u00020\rX\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u000f\"\u0004\b\u001d\u0010\u0011R\u001a\u0010\u001e\u001a\u00020\u0016X\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u0018\"\u0004\b \u0010\u001aR\u0010\u0010!\u001a\u0004\u0018\u00010\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010'\u001a\u0004\u0018\u00010(X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u00102\u001a\b\u0012\u0004\u0012\u00020403X\u0082\u0004¢\u0006\u0004\n\u0002\u00105¨\u0006<"}, d2 = {"Lcom/ultrafanatics/football/game/data/audio/SoundManager;", "Lcom/ultrafanatics/football/game/domain/SoundPlayer;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "appContext", "kotlin.jvm.PlatformType", "pool", "Ljava/util/concurrent/ExecutorService;", "sampleRate", "", "soundEnabled", "", "getSoundEnabled", "()Z", "setSoundEnabled", "(Z)V", "vibrationEnabled", "getVibrationEnabled", "setVibrationEnabled", "volume", "", "getVolume", "()F", "setVolume", "(F)V", "musicEnabled", "getMusicEnabled", "setMusicEnabled", "musicVolume", "getMusicVolume", "setMusicVolume", "musicTrack", "Landroid/media/AudioTrack;", "musicBuffer", "", "musicLock", "", "vibrator", "Landroid/os/Vibrator;", "play", "", "sfx", "Lcom/ultrafanatics/football/game/domain/Sfx;", "vibrate", "notesFor", "", "Lcom/ultrafanatics/football/game/data/audio/SoundManager$Note;", "render", "chords", "", "", "[[D", "buildMusic", "startMusic", "stopMusic", "applyMusicVolume", "release", "Note", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SoundManager implements SoundPlayer {
    public static final int $stable = 8;
    private final Context appContext;
    private final double[][] chords;
    private short[] musicBuffer;
    private volatile boolean musicEnabled;
    private final Object musicLock;
    private AudioTrack musicTrack;
    private volatile float musicVolume;
    private final ExecutorService pool;
    private final int sampleRate;
    private volatile boolean soundEnabled;
    private volatile boolean vibrationEnabled;
    private final Vibrator vibrator;
    private volatile float volume;

    /* compiled from: SoundManager.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Sfx.values().length];
            try {
                iArr[Sfx.TAP.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Sfx.PICK.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Sfx.DROP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Sfx.INVALID.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[Sfx.LINE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[Sfx.COMBO.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[Sfx.SPECIAL.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[Sfx.SUCCESS.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[Sfx.RECORD.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[Sfx.LOSE.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[Sfx.REWARD.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[Sfx.BOOSTER.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public SoundManager(Context context) {
        Vibrator defaultVibrator;
        Intrinsics.checkNotNullParameter(context, "context");
        Context applicationContext = context.getApplicationContext();
        this.appContext = applicationContext;
        this.pool = Executors.newFixedThreadPool(2);
        this.sampleRate = 22050;
        this.soundEnabled = true;
        this.vibrationEnabled = true;
        this.volume = 0.8f;
        this.musicEnabled = true;
        this.musicVolume = 0.6f;
        this.musicLock = new Object();
        Vibrator vibrator = null;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                Object systemService = applicationContext.getSystemService("vibrator_manager");
                VibratorManager vibratorManager = systemService instanceof VibratorManager ? (VibratorManager) systemService : null;
                if (vibratorManager != null) {
                    defaultVibrator = vibratorManager.getDefaultVibrator();
                    vibrator = defaultVibrator;
                }
            } else {
                Object systemService2 = applicationContext.getSystemService("vibrator");
                if (systemService2 instanceof Vibrator) {
                    defaultVibrator = (Vibrator) systemService2;
                    vibrator = defaultVibrator;
                }
            }
        } catch (Throwable unused) {
        }
        this.vibrator = vibrator;
        this.chords = new double[][]{new double[]{130.81d, 164.81d, 196.0d}, new double[]{110.0d, 130.81d, 164.81d}, new double[]{87.31d, 110.0d, 130.81d}, new double[]{98.0d, 123.47d, 146.83d}};
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public boolean getSoundEnabled() {
        return this.soundEnabled;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void setSoundEnabled(boolean z) {
        this.soundEnabled = z;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public boolean getVibrationEnabled() {
        return this.vibrationEnabled;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void setVibrationEnabled(boolean z) {
        this.vibrationEnabled = z;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public float getVolume() {
        return this.volume;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void setVolume(float f) {
        this.volume = f;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public boolean getMusicEnabled() {
        return this.musicEnabled;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void setMusicEnabled(boolean z) {
        this.musicEnabled = z;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public float getMusicVolume() {
        return this.musicVolume;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void setMusicVolume(float f) {
        this.musicVolume = f;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void play(final Sfx sfx) {
        Intrinsics.checkNotNullParameter(sfx, "sfx");
        if (getSoundEnabled()) {
            try {
                this.pool.execute(new Runnable() { // from class: com.ultrafanatics.football.game.data.audio.SoundManager$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.render(sfx);
                    }
                });
            } catch (Throwable unused) {
            }
        }
        vibrate(sfx);
    }

    private final void vibrate(Sfx sfx) {
        Vibrator vibrator;
        long j;
        if (getVibrationEnabled() && (vibrator = this.vibrator) != null) {
            switch (WhenMappings.$EnumSwitchMapping$0[sfx.ordinal()]) {
                case 1:
                case 2:
                    j = 8;
                    break;
                case 3:
                    j = 14;
                    break;
                case 4:
                    j = 40;
                    break;
                case 5:
                    j = 22;
                    break;
                case 6:
                case 7:
                    j = 30;
                    break;
                case 8:
                case 9:
                    j = 60;
                    break;
                case 10:
                    j = 70;
                    break;
                case 11:
                case 12:
                    j = 20;
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
            try {
                vibrator.vibrate(VibrationEffect.createOneShot(j, -1));
            } catch (Throwable unused) {
            }
        }
    }

    /* compiled from: SoundManager.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\r¨\u0006\u001b"}, d2 = {"Lcom/ultrafanatics/football/game/data/audio/SoundManager$Note;", "", "freq", "", AccessibilityNodeInfoCompat.MathInfoCompat.MATH_TAG_STRING_LITERAL, "", "gain", "wave", "<init>", "(DIDI)V", "getFreq", "()D", "getMs", "()I", "getGain", "getWave", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final /* data */ class Note {
        private final double freq;
        private final double gain;
        private final int ms;
        private final int wave;

        public static /* synthetic */ Note copy$default(Note note, double d, int i, double d2, int i2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                d = note.freq;
            }
            double d3 = d;
            if ((i3 & 2) != 0) {
                i = note.ms;
            }
            int i4 = i;
            if ((i3 & 4) != 0) {
                d2 = note.gain;
            }
            double d4 = d2;
            if ((i3 & 8) != 0) {
                i2 = note.wave;
            }
            return note.copy(d3, i4, d4, i2);
        }

        /* renamed from: component1, reason: from getter */
        public final double getFreq() {
            return this.freq;
        }

        /* renamed from: component2, reason: from getter */
        public final int getMs() {
            return this.ms;
        }

        /* renamed from: component3, reason: from getter */
        public final double getGain() {
            return this.gain;
        }

        /* renamed from: component4, reason: from getter */
        public final int getWave() {
            return this.wave;
        }

        public final Note copy(double freq, int ms, double gain, int wave) {
            return new Note(freq, ms, gain, wave);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Note)) {
                return false;
            }
            Note note = (Note) other;
            return Double.compare(this.freq, note.freq) == 0 && this.ms == note.ms && Double.compare(this.gain, note.gain) == 0 && this.wave == note.wave;
        }

        public int hashCode() {
            return (((((Double.hashCode(this.freq) * 31) + Integer.hashCode(this.ms)) * 31) + Double.hashCode(this.gain)) * 31) + Integer.hashCode(this.wave);
        }

        public String toString() {
            return "Note(freq=" + this.freq + ", ms=" + this.ms + ", gain=" + this.gain + ", wave=" + this.wave + ")";
        }

        public Note(double d, int i, double d2, int i2) {
            this.freq = d;
            this.ms = i;
            this.gain = d2;
            this.wave = i2;
        }

        public /* synthetic */ Note(double d, int i, double d2, int i2, int i3, DefaultConstructorMarker defaultConstructorMarker) {
            this(d, i, (i3 & 4) != 0 ? 1.0d : d2, (i3 & 8) != 0 ? 0 : i2);
        }

        public final double getFreq() {
            return this.freq;
        }

        public final double getGain() {
            return this.gain;
        }

        public final int getMs() {
            return this.ms;
        }

        public final int getWave() {
            return this.wave;
        }
    }

    private final List<Note> notesFor(Sfx sfx) {
        switch (WhenMappings.$EnumSwitchMapping$0[sfx.ordinal()]) {
            case 1:
                return CollectionsKt.listOf(new Note(760.0d, 45, 0.35d, 0, 8, null));
            case 2:
                return CollectionsKt.listOf(new Note(560.0d, 55, 0.4d, 0, 8, null));
            case 3:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(330.0d, 70, 0.5d, 0, 8, null), new Note(440.0d, 60, 0.4d, 0, 8, null)});
            case 4:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(180.0d, 90, 0.5d, 1), new Note(140.0d, 110, 0.45d, 1)});
            case 5:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(660.0d, 70, 0.5d, 0, 8, null), new Note(880.0d, 80, 0.5d, 0, 8, null), new Note(1180.0d, 110, 0.45d, 0, 8, null)});
            case 6:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(700.0d, 60, 0.5d, 0, 8, null), new Note(930.0d, 60, 0.5d, 0, 8, null), new Note(1240.0d, 70, 0.5d, 0, 8, null), new Note(1560.0d, 110, 0.45d, 0, 8, null)});
            case 7:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(220.0d, 60, 0.6d, 1), new Note(440.0d, 70, 0.5d, 0, 8, null), new Note(1320.0d, 130, 0.45d, 0, 8, null)});
            case 8:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(523.0d, 110, 0.5d, 0, 8, null), new Note(659.0d, 110, 0.5d, 0, 8, null), new Note(784.0d, 110, 0.5d, 0, 8, null), new Note(1046.0d, 240, 0.5d, 0, 8, null)});
            case 9:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(659.0d, 90, 0.5d, 0, 8, null), new Note(880.0d, 90, 0.5d, 0, 8, null), new Note(1174.0d, 90, 0.5d, 0, 8, null), new Note(1568.0d, 260, 0.5d, 0, 8, null)});
            case 10:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(392.0d, 150, 0.5d, 0, 8, null), new Note(330.0d, 160, 0.5d, 0, 8, null), new Note(262.0d, 300, 0.5d, 0, 8, null)});
            case 11:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(880.0d, 70, 0.45d, 0, 8, null), new Note(1174.0d, 70, 0.45d, 0, 8, null), new Note(1568.0d, 160, 0.45d, 0, 8, null)});
            case 12:
                return CollectionsKt.listOf((Object[]) new Note[]{new Note(500.0d, 60, 0.45d, 0, 8, null), new Note(750.0d, 90, 0.45d, 0, 8, null)});
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void render(Sfx sfx) {
        double dSin;
        List<Note> listNotesFor = notesFor(sfx);
        List<Note> list = listNotesFor;
        Iterator<T> it = list.iterator();
        int ms = 0;
        while (it.hasNext()) {
            ms += (((Note) it.next()).getMs() * this.sampleRate) / 1000;
        }
        if (ms <= 0) {
            return;
        }
        short[] sArr = new short[ms];
        int i = 0;
        for (Note note : list) {
            int ms2 = (note.getMs() * this.sampleRate) / 1000;
            int i2 = 0;
            while (i2 < ms2) {
                double d = i2;
                int i3 = ms;
                double d2 = ms2;
                double dExp = Math.exp(((-4.0d) * d) / d2) * (1.0d - Math.exp((d * (-60.0d)) / d2));
                double freq = note.getFreq() * 6.283185307179586d * (d / this.sampleRate);
                if (note.getWave() == 1) {
                    dSin = Math.sin(freq) >= 0.0d ? 0.7d : -0.7d;
                } else {
                    dSin = (Math.sin(freq) * 0.8d) + (Math.sin(freq * 2.0d) * 0.2d);
                }
                sArr[i + i2] = (short) RangesKt.coerceIn((int) (dSin * dExp * note.getGain() * getVolume() * 32767.0d * 0.7d), -32768, 32767);
                i2++;
                ms = i3;
            }
            i += ms2;
        }
        int i4 = ms;
        AudioTrack audioTrackBuild = null;
        try {
            int ms3 = 0;
            audioTrackBuild = new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).setAudioFormat(new AudioFormat.Builder().setEncoding(2).setSampleRate(this.sampleRate).setChannelMask(4).build()).setBufferSizeInBytes(i4 * 2).setTransferMode(0).build();
            audioTrackBuild.write(sArr, 0, i4);
            audioTrackBuild.play();
            Iterator<T> it2 = listNotesFor.iterator();
            while (it2.hasNext()) {
                ms3 += ((Note) it2.next()).getMs();
            }
            Thread.sleep(ms3 + 60);
            if (audioTrackBuild != null) {
                try {
                    audioTrackBuild.stop();
                } catch (Throwable unused) {
                }
            }
            if (audioTrackBuild == null) {
                return;
            }
        } catch (Throwable unused2) {
            if (audioTrackBuild != null) {
                try {
                    audioTrackBuild.stop();
                } catch (Throwable unused3) {
                }
            }
            if (audioTrackBuild == null) {
                return;
            }
        }
        try {
            audioTrackBuild.release();
        } catch (Throwable unused4) {
        }
    }

    private final short[] buildMusic() {
        short[] sArr = this.musicBuffer;
        if (sArr != null) {
            return sArr;
        }
        int i = (this.sampleRate * 1800) / 1000;
        double[][] dArr = this.chords;
        short[] sArr2 = new short[dArr.length * i];
        double[][] dArr2 = dArr;
        int length = dArr2.length;
        int i2 = 0;
        int i3 = 0;
        while (i2 < length) {
            int i4 = i3 + 1;
            double[] dArr3 = dArr2[i2];
            int i5 = 0;
            while (i5 < i) {
                double d = i5;
                double d2 = d / this.sampleRate;
                int i6 = i2;
                double dSin = Math.sin((d / i) * 3.141592653589793d);
                double d3 = (dSin * dSin * 0.9d) + 0.1d;
                int length2 = dArr3.length;
                double dSin2 = 0.0d;
                int i7 = 0;
                int i8 = 0;
                while (i7 < length2) {
                    double d4 = dArr3[i7];
                    int i9 = i;
                    double d5 = i8;
                    double dSin3 = (Math.sin((3.7699111843077517d * d2) + d5) * 0.0015d) + 1.0d;
                    double d6 = d4 * 6.283185307179586d;
                    dSin2 = dSin2 + (Math.sin(d6 * dSin3 * d2) * (0.55d - (d5 * 0.12d))) + (Math.sin(d6 * 2.0d * dSin3 * d2) * 0.06d);
                    i7++;
                    i8++;
                    i = i9;
                    dArr2 = dArr2;
                }
                int i10 = i;
                sArr2[(i3 * i10) + i5] = (short) RangesKt.coerceIn((int) (32767.0d * dSin2 * d3 * 0.16d), -32768, 32767);
                i5++;
                i2 = i6;
                i = i10;
                dArr2 = dArr2;
            }
            i2++;
            i3 = i4;
        }
        this.musicBuffer = sArr2;
        return sArr2;
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void startMusic() {
        if (getMusicEnabled()) {
            try {
                this.pool.execute(new Runnable() { // from class: com.ultrafanatics.football.game.data.audio.SoundManager$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        SoundManager.startMusic$lambda$0(this.f$0);
                    }
                });
            } catch (Throwable unused) {
            }
        }
    }

    static final void startMusic$lambda$0(SoundManager soundManager) {
        synchronized (soundManager.musicLock) {
            if (soundManager.musicTrack == null && soundManager.getMusicEnabled()) {
                short[] sArrBuildMusic = soundManager.buildMusic();
                AudioTrack audioTrackBuild = new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(2).build()).setAudioFormat(new AudioFormat.Builder().setEncoding(2).setSampleRate(soundManager.sampleRate).setChannelMask(4).build()).setBufferSizeInBytes(sArrBuildMusic.length * 2).setTransferMode(0).build();
                Intrinsics.checkNotNull(audioTrackBuild);
                audioTrackBuild.write(sArrBuildMusic, 0, sArrBuildMusic.length);
                audioTrackBuild.setLoopPoints(0, sArrBuildMusic.length, -1);
                audioTrackBuild.setVolume(RangesKt.coerceIn(soundManager.getMusicVolume(), 0.0f, 1.0f));
                audioTrackBuild.play();
                soundManager.musicTrack = audioTrackBuild;
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void stopMusic() {
        synchronized (this.musicLock) {
            AudioTrack audioTrack = this.musicTrack;
            this.musicTrack = null;
            if (audioTrack != null) {
                try {
                    audioTrack.pause();
                } catch (Throwable unused) {
                }
            }
            if (audioTrack != null) {
                audioTrack.stop();
            }
            if (audioTrack != null) {
                try {
                    audioTrack.release();
                    Unit unit = Unit.INSTANCE;
                } catch (Throwable unused2) {
                    Unit unit2 = Unit.INSTANCE;
                }
            }
        }
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void applyMusicVolume() {
        synchronized (this.musicLock) {
            try {
                AudioTrack audioTrack = this.musicTrack;
                if (audioTrack != null) {
                    Integer.valueOf(audioTrack.setVolume(RangesKt.coerceIn(getMusicVolume(), 0.0f, 1.0f)));
                }
            } catch (Throwable unused) {
                Unit unit = Unit.INSTANCE;
            }
        }
    }

    @Override // com.ultrafanatics.football.game.domain.SoundPlayer
    public void release() {
        stopMusic();
        try {
            this.pool.shutdownNow();
        } catch (Throwable unused) {
        }
    }
}
