package com.slidigu.app;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class MainActivity1 extends androidx.appcompat.app.AppCompatActivity {
    public static void i0(com.slidigu.app.MainActivity1 mainActivity1, android.view.View view) {
        android.util.Log.i("XUR", "h=" + java.lang.Boolean.hashCode(new defpackage.xu().a(2370)));
        mainActivity1.finishAffinity();
    }

    public static void j0(com.slidigu.app.MainActivity1 mainActivity1, android.view.View view) {
        int iA = new defpackage.l6().a(6918, 9386);
        if (java.lang.Integer.hashCode(iA) > 8993) {
            android.util.Log.v("LIDUTU", java.lang.String.valueOf(iA));
        }
        mainActivity1.startActivity(new android.content.Intent(mainActivity1, (java.lang.Class<?>) com.slidigu.app.MainActivity.class));
    }

    public static void k0(com.slidigu.app.MainActivity1 mainActivity1, android.view.View view) {
        android.util.Log.v("DUDEKU", new defpackage.xu().b("xijyun").toString());
        mainActivity1.startActivity(new android.content.Intent(mainActivity1, (java.lang.Class<?>) com.slidigu.app.MainActivity2.class));
    }

    public static void l0(com.slidigu.app.MainActivity1 mainActivity1, android.view.View view) {
        defpackage.jm jmVar = new defpackage.jm();
        java.lang.String strB = jmVar.b("mirtntbb", "dzg");
        long jA = jmVar.a(9894, 7313, 3670);
        if (jmVar.toString().length() >= 10) {
            android.util.Log.i("XEJUD", defpackage.oz.R(jmVar.toString(), 8));
        }
        if (strB.hashCode() > 6328) {
            android.util.Log.v("JESI", strB.toString());
        }
        android.util.Log.v("SUTIME", java.lang.String.valueOf(jA));
        mainActivity1.startActivity(new android.content.Intent(mainActivity1, (java.lang.Class<?>) com.slidigu.app.MainActivity3.class));
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        android.util.Log.v("QEHERE", java.lang.String.valueOf(new defpackage.xu().c(6074, 3643)));
        super.onCreate(bundle);
        int iA = new defpackage.m6().a("ppbagw", "iab");
        if (java.lang.Integer.hashCode(iA) != 781) {
            android.util.Log.d("TIF", java.lang.String.valueOf(iA));
        }
        setContentView(com.slidigu.app.R.layout.activity_main1);
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA = j40Var.a("ysldvw");
        int iB = j40Var.b(6619);
        android.util.Log.d("BOJUFU", "v=" + j40Var);
        if (strA.toString().length() >= 5) {
            android.util.Log.i("MEREJA", defpackage.oz.R(strA.toString(), 8));
        }
        if (java.lang.Integer.hashCode(iB) > 8720) {
            android.util.Log.v("SOK", java.lang.String.valueOf(iB));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnPlay)).setOnClickListener(new android.view.View.OnClickListener() { // from class: xn
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity1.k0(this.d, view);
            }
        });
        int iA2 = new defpackage.l6().a(5779, 2415);
        if (java.lang.Integer.hashCode(iA2) > 1319) {
            android.util.Log.v("SIQ", java.lang.String.valueOf(iA2));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnStatistics)).setOnClickListener(new android.view.View.OnClickListener() { // from class: yn
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity1.l0(this.d, view);
            }
        });
        int iC = new defpackage.xu().c(6880, 4235);
        if (java.lang.String.valueOf(iC).length() >= 4) {
            android.util.Log.i("NEFUD", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnAbout)).setOnClickListener(new android.view.View.OnClickListener() { // from class: zn
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity1.j0(this.d, view);
            }
        });
        android.util.Log.i("BEQ", "h=" + new defpackage.zx().a("azzyikssj", "irwc", "zefvv").hashCode());
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnExit)).setOnClickListener(new android.view.View.OnClickListener() { // from class: ao
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity1.i0(this.d, view);
            }
        });
    }
}
