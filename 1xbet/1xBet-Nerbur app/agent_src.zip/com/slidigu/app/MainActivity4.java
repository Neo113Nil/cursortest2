package com.slidigu.app;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class MainActivity4 extends androidx.appcompat.app.AppCompatActivity {
    public static final com.slidigu.app.MainActivity4.a E = new com.slidigu.app.MainActivity4.a(null);

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class a {
        public a() {
        }

        public /* synthetic */ a(defpackage.za zaVar) {
            this();
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final /* synthetic */ class b {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[defpackage.aj.values().length];
            try {
                iArr[defpackage.aj.e.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                iArr[defpackage.aj.f.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                iArr[defpackage.aj.g.ordinal()] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            a = iArr;
        }
    }

    public static void i0(com.slidigu.app.MainActivity4 mainActivity4, android.view.View view) {
        android.util.Log.v("SEX", java.lang.String.valueOf(new defpackage.l6().b("ziekt", "egizst")));
        mainActivity4.startActivity(new android.content.Intent(mainActivity4, (java.lang.Class<?>) com.slidigu.app.MainActivity2.class));
        long jA = new defpackage.jm().a(9060, 9152, 6722);
        if (java.lang.String.valueOf(jA).length() >= 10) {
            android.util.Log.i("DEVUSA", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        mainActivity4.finish();
    }

    public static void j0(com.slidigu.app.MainActivity4 mainActivity4, android.view.View view) {
        int iA = new defpackage.l6().a(7692, 1528);
        if (java.lang.String.valueOf(iA).length() >= 5) {
            android.util.Log.i("GUYOBE", defpackage.oz.R(java.lang.String.valueOf(iA), 8));
        }
        mainActivity4.startActivity(new android.content.Intent(mainActivity4, (java.lang.Class<?>) com.slidigu.app.MainActivity1.class));
        android.util.Log.v("KUMOXI", new defpackage.rj().b(907).toString());
        mainActivity4.finish();
    }

    private final java.lang.String k0(int i) {
        java.lang.String strB = new defpackage.jm().b("hnldqw", "wvajxb");
        if (strB.hashCode() != 2014) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        int i2 = i / 60;
        java.lang.String strB2 = new defpackage.xu().b("tyoapebxx");
        if (strB2.hashCode() != 919) {
            java.lang.System.out.println((java.lang.Object) strB2.toString());
        }
        int i3 = i % 60;
        java.lang.String strB3 = new defpackage.rj().b(9547);
        if (strB3.hashCode() != 531) {
            java.lang.System.out.println((java.lang.Object) strB3.toString());
        }
        java.lang.String string = getString(com.slidigu.app.R.string.time_format, java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(i3));
        string.getClass();
        return string;
    }

    private final java.lang.String l0(defpackage.aj ajVar) {
        int i = com.slidigu.app.MainActivity4.b.a[ajVar.ordinal()];
        if (i == 1) {
            java.lang.String string = getString(com.slidigu.app.R.string.result_hull_breach);
            string.getClass();
            return string;
        }
        if (i == 2) {
            java.lang.String string2 = getString(com.slidigu.app.R.string.result_out_of_fuel);
            string2.getClass();
            return string2;
        }
        if (i != 3) {
            throw new defpackage.tr();
        }
        java.lang.String string3 = getString(com.slidigu.app.R.string.result_aborted);
        string3.getClass();
        return string3;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        android.util.Log.v("RIM", java.lang.String.valueOf(new defpackage.jm().a(3893, 6998, 1722)));
        super.onCreate(bundle);
        int iB = defpackage.no.b(30);
        if (java.lang.Integer.hashCode(iB) > 5778) {
            android.util.Log.v("TOP", java.lang.String.valueOf(iB));
        }
        setContentView(com.slidigu.app.R.layout.activity_main4);
        android.util.Log.d("BIMAW", "v=" + new defpackage.m6().a("ful", "efejunanfq"));
        int intExtra = getIntent().getIntExtra("extra_score", 0);
        android.util.Log.v("MIX", new defpackage.rj().b(9261).toString());
        int intExtra2 = getIntent().getIntExtra("extra_time", 0);
        android.util.Log.v("KUVE", new defpackage.rj().b(819).toString());
        int intExtra3 = getIntent().getIntExtra("extra_fuel", 0);
        java.lang.String strB = new defpackage.rj().b(2249);
        if (strB.hashCode() != 6553) {
            android.util.Log.d("NEKOPU", strB.toString());
        }
        int intExtra4 = getIntent().getIntExtra("extra_cargo", 0);
        int iC = new defpackage.xu().c(7840, 5141);
        if (java.lang.Integer.hashCode(iC) != 695) {
            android.util.Log.d("DIYU", java.lang.String.valueOf(iC));
        }
        aj.a aVar = defpackage.aj.d;
        java.lang.String stringExtra = getIntent().getStringExtra("extra_result");
        if (stringExtra == null) {
            stringExtra = "";
        }
        defpackage.aj ajVarA = aVar.a(stringExtra);
        long jA = new defpackage.jm().a(7900, 9022, 4189);
        if (java.lang.String.valueOf(jA).length() >= 7) {
            android.util.Log.i("DENO", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        ((android.widget.TextView) findViewById(com.slidigu.app.R.id.resultReason)).setText(l0(ajVarA));
        int iB2 = new defpackage.m6().b(682);
        if (java.lang.Integer.hashCode(iB2) > 1665) {
            android.util.Log.v("QIWAG", java.lang.String.valueOf(iB2));
        }
        ((android.widget.TextView) findViewById(com.slidigu.app.R.id.resultScore)).setText(java.lang.String.valueOf(intExtra));
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA = j40Var.a("hmtd");
        int iB3 = j40Var.b(1104);
        defpackage.l6 l6Var = new defpackage.l6();
        int iB4 = l6Var.b("fqg", "wzmhs");
        int iA = l6Var.a(190, 561);
        android.util.Log.d("WEGEVE", "v=" + j40Var);
        if (strA.hashCode() != 9825) {
            android.util.Log.d("LIZI", strA.toString());
        }
        if (java.lang.Integer.hashCode(iB3) != 7106) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
        }
        if (l6Var.toString().length() >= 4) {
            android.util.Log.i("CEMUK", defpackage.oz.R(l6Var.toString(), 8));
        }
        android.util.Log.d("WIS", "v=" + iB4);
        if (java.lang.Integer.hashCode(iA) > 8290) {
            android.util.Log.v("SEGOPE", java.lang.String.valueOf(iA));
        }
        ((android.widget.TextView) findViewById(com.slidigu.app.R.id.resultTime)).setText(k0(intExtra2));
        android.util.Log.d("LEWU", "v=" + new defpackage.jm().a(1824, 1872, 9641));
        ((android.widget.TextView) findViewById(com.slidigu.app.R.id.resultFuel)).setText(java.lang.String.valueOf(intExtra3));
        boolean zA = new defpackage.xu().a(9996);
        if (java.lang.Boolean.hashCode(zA) > 7365) {
            android.util.Log.v("MIJAHU", java.lang.String.valueOf(zA));
        }
        ((android.widget.TextView) findViewById(com.slidigu.app.R.id.resultCargo)).setText(java.lang.String.valueOf(intExtra4));
        int iA2 = new defpackage.m6().a("bzxx", "twhhuelnf");
        if (java.lang.Integer.hashCode(iA2) > 5870) {
            android.util.Log.v("PEBI", java.lang.String.valueOf(iA2));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnPlayAgain)).setOnClickListener(new android.view.View.OnClickListener() { // from class: lo
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity4.i0(this.d, view);
            }
        });
        boolean zA2 = new defpackage.rj().a(3637, 5676, 9772);
        if (java.lang.String.valueOf(zA2).length() >= 2) {
            android.util.Log.i("NAVI", defpackage.oz.R(java.lang.String.valueOf(zA2), 8));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnMainMenu)).setOnClickListener(new android.view.View.OnClickListener() { // from class: mo
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity4.j0(this.d, view);
            }
        });
    }
}
