package com.slidigu.app;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class MainActivity2 extends androidx.appcompat.app.AppCompatActivity implements com.slidigu.app.game.SpaceGameView.f {
    public com.slidigu.app.game.SpaceGameView E;
    public android.widget.ProgressBar F;
    public android.widget.ProgressBar G;
    public android.widget.TextView H;
    public android.widget.TextView I;
    public android.widget.TextView J;
    public android.widget.TextView K;
    public android.widget.TextView L;
    public android.view.View M;
    public android.widget.TextView N;
    public defpackage.rf O;
    public boolean P;

    public static void i0(com.slidigu.app.MainActivity2 mainActivity2, int i, int i2, int i3, int i4, int i5) {
        android.util.Log.v("PULEL", java.lang.String.valueOf(new defpackage.l6().b("kjceg", "onqp")));
        android.widget.ProgressBar progressBar = mainActivity2.F;
        android.widget.TextView textView = null;
        if (progressBar == null) {
            defpackage.vk.f("healthBar");
            progressBar = null;
        }
        progressBar.setProgress(defpackage.zu.e(i, 0, 100));
        int iB = new defpackage.zx().b(1883);
        if (java.lang.Integer.hashCode(iB) != 3929) {
            android.util.Log.d("JAPAN", java.lang.String.valueOf(iB));
        }
        android.widget.ProgressBar progressBar2 = mainActivity2.G;
        if (progressBar2 == null) {
            defpackage.vk.f("fuelBar");
            progressBar2 = null;
        }
        progressBar2.setProgress(defpackage.zu.e(i2, 0, 100));
        long jA = new defpackage.jm().a(7723, 6510, 7479);
        if (java.lang.String.valueOf(jA).length() >= 3) {
            android.util.Log.i("JIK", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        android.widget.TextView textView2 = mainActivity2.H;
        if (textView2 == null) {
            defpackage.vk.f("healthValue");
            textView2 = null;
        }
        textView2.setText(java.lang.String.valueOf(java.lang.Math.max(i, 0)));
        defpackage.rj rjVar = new defpackage.rj();
        java.lang.String strB = rjVar.b(2788);
        boolean zA = rjVar.a(8005, 4733, 6397);
        if (rjVar.hashCode() > 9209) {
            android.util.Log.v("SOZ", rjVar.toString());
        }
        if (strB.hashCode() != 492) {
            android.util.Log.d("RAK", strB.toString());
        }
        if (java.lang.Boolean.hashCode(zA) != 8412) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(zA));
        }
        android.widget.TextView textView3 = mainActivity2.I;
        if (textView3 == null) {
            defpackage.vk.f("fuelValue");
            textView3 = null;
        }
        textView3.setText(java.lang.String.valueOf(java.lang.Math.max(i2, 0)));
        android.util.Log.v("FAKEW", java.lang.String.valueOf(new defpackage.xu().c(1110, 991)));
        android.widget.TextView textView4 = mainActivity2.J;
        if (textView4 == null) {
            defpackage.vk.f("scoreValue");
            textView4 = null;
        }
        textView4.setText(java.lang.String.valueOf(i3));
        defpackage.xu xuVar = new defpackage.xu();
        int iC = xuVar.c(7697, 5363);
        java.lang.String strB2 = xuVar.b("evbxu");
        boolean zA2 = xuVar.a(1687);
        android.util.Log.v("KEJURO", xuVar.toString());
        if (java.lang.String.valueOf(iC).length() >= 6) {
            android.util.Log.i("QENI", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        android.util.Log.v("SAM", strB2.toString());
        if (java.lang.String.valueOf(zA2).length() >= 8) {
            android.util.Log.i("FECO", defpackage.oz.R(java.lang.String.valueOf(zA2), 8));
        }
        android.widget.TextView textView5 = mainActivity2.K;
        if (textView5 == null) {
            defpackage.vk.f("timeValue");
            textView5 = null;
        }
        textView5.setText(mainActivity2.l0(i4));
        int iC2 = new defpackage.xu().c(9609, 5016);
        if (java.lang.Integer.hashCode(iC2) > 380) {
            android.util.Log.v("POSU", java.lang.String.valueOf(iC2));
        }
        android.widget.TextView textView6 = mainActivity2.L;
        if (textView6 == null) {
            defpackage.vk.f("cargoValue");
            textView6 = null;
        }
        textView6.setText(java.lang.String.valueOf(i5));
        java.lang.String strA = new defpackage.zx().a("hcumuohjl", "zwhnaaac", "twgxdcckw");
        if (strA.hashCode() > 882) {
            android.util.Log.v("LENE", strA.toString());
        }
        if (i4 >= 5) {
            android.util.Log.d("XAV", "v=" + new defpackage.l6().b("wphwadc", "vchl"));
            android.widget.TextView textView7 = mainActivity2.N;
            if (textView7 == null) {
                defpackage.vk.f("controlHint");
            } else {
                textView = textView7;
            }
            textView.setVisibility(8);
        }
    }

    public static void j0(com.slidigu.app.MainActivity2 mainActivity2, android.view.View view) {
        long jA = new defpackage.jm().a(7106, 2008, 4193);
        if (java.lang.Long.hashCode(jA) != 2136) {
            android.util.Log.d("ZOLUZU", java.lang.String.valueOf(jA));
        }
        android.view.View view2 = mainActivity2.M;
        com.slidigu.app.game.SpaceGameView spaceGameView = null;
        if (view2 == null) {
            defpackage.vk.f("pauseOverlay");
            view2 = null;
        }
        view2.setVisibility(8);
        java.lang.String strB = new defpackage.xu().b("uwebltqo");
        if (strB.hashCode() != 4658) {
            android.util.Log.d("PAVI", strB.toString());
        }
        com.slidigu.app.game.SpaceGameView spaceGameView2 = mainActivity2.E;
        if (spaceGameView2 == null) {
            defpackage.vk.f("gameView");
        } else {
            spaceGameView = spaceGameView2;
        }
        spaceGameView.t();
    }

    public static void k0(com.slidigu.app.MainActivity2 mainActivity2, android.view.View view) {
        android.util.Log.d("TAFA", "v=" + new defpackage.xu().a(488));
        com.slidigu.app.game.SpaceGameView spaceGameView = mainActivity2.E;
        if (spaceGameView == null) {
            defpackage.vk.f("gameView");
            spaceGameView = null;
        }
        spaceGameView.d();
    }

    @Override // com.slidigu.app.game.SpaceGameView.f
    public void f(int i, int i2, int i3, int i4, defpackage.aj ajVar) {
        ajVar.getClass();
        boolean z = this.P;
        java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(z);
        defpackage.rf rfVar = null;
        if (!z) {
            boolValueOf = null;
        }
        if (boolValueOf != null) {
            return;
        }
        this.P = true;
        defpackage.rf rfVar2 = this.O;
        if (rfVar2 == null) {
            defpackage.vk.f("database");
        } else {
            rfVar = rfVar2;
        }
        rfVar.c(new defpackage.sf(0L, i, i2, i3, i4, ajVar, 0L, 65, null));
        android.content.Intent intent = new android.content.Intent(this, (java.lang.Class<?>) com.slidigu.app.MainActivity4.class);
        intent.putExtra("extra_score", i);
        intent.putExtra("extra_time", i2);
        intent.putExtra("extra_fuel", i3);
        intent.putExtra("extra_cargo", i4);
        intent.putExtra("extra_result", ajVar.name());
        startActivity(intent);
        finish();
    }

    public final java.lang.String l0(int i) {
        boolean zA = new defpackage.xu().a(2757);
        if (java.lang.Boolean.hashCode(zA) > 6890) {
            android.util.Log.v("SAK", java.lang.String.valueOf(zA));
        }
        int i2 = i / 60;
        android.util.Log.i("CAK", "h=" + java.lang.Integer.hashCode(new defpackage.l6().b("zov", "tryxohzzk")));
        int i3 = i % 60;
        int iB = new defpackage.zx().b(4572);
        if (java.lang.Integer.hashCode(iB) != 1326) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        java.lang.String string = getString(com.slidigu.app.R.string.time_format, java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(i3));
        string.getClass();
        return string;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        boolean zC = defpackage.fo.c("ycy");
        if (java.lang.Boolean.hashCode(zC) > 2022) {
            android.util.Log.v("NEWOZO", java.lang.String.valueOf(zC));
        }
        super.onCreate(bundle);
        int iB = new defpackage.l6().b("dba", "cpuisqfbq");
        if (java.lang.String.valueOf(iB).length() >= 8) {
            android.util.Log.i("HONO", defpackage.oz.R(java.lang.String.valueOf(iB), 8));
        }
        setContentView(com.slidigu.app.R.layout.activity_main2);
        int iC = new defpackage.xu().c(198, 5341);
        if (java.lang.Integer.hashCode(iC) != 8880) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iC));
        }
        this.O = new defpackage.rf(this);
        java.lang.String strA = new defpackage.zx().a("kzmxjxer", "jxgy", "psd");
        if (strA.hashCode() != 6850) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        android.view.View viewFindViewById = findViewById(com.slidigu.app.R.id.gameView);
        viewFindViewById.getClass();
        this.E = (com.slidigu.app.game.SpaceGameView) viewFindViewById;
        java.lang.String strB = new defpackage.jm().b("odihnsnnvc", "qhkcwmi");
        if (strB.hashCode() != 2713) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        android.view.View viewFindViewById2 = findViewById(com.slidigu.app.R.id.healthBar);
        viewFindViewById2.getClass();
        this.F = (android.widget.ProgressBar) viewFindViewById2;
        int iB2 = new defpackage.zx().b(208);
        if (java.lang.Integer.hashCode(iB2) != 8931) {
            android.util.Log.d("XARA", java.lang.String.valueOf(iB2));
        }
        android.view.View viewFindViewById3 = findViewById(com.slidigu.app.R.id.fuelBar);
        viewFindViewById3.getClass();
        this.G = (android.widget.ProgressBar) viewFindViewById3;
        android.util.Log.v("HOR", java.lang.String.valueOf(new defpackage.l6().b("whdwvn", "zpxy")));
        android.view.View viewFindViewById4 = findViewById(com.slidigu.app.R.id.healthValue);
        viewFindViewById4.getClass();
        this.H = (android.widget.TextView) viewFindViewById4;
        android.util.Log.v("VUK", java.lang.String.valueOf(new defpackage.zx().b(2362)));
        android.view.View viewFindViewById5 = findViewById(com.slidigu.app.R.id.fuelValue);
        viewFindViewById5.getClass();
        this.I = (android.widget.TextView) viewFindViewById5;
        android.util.Log.v("XAH", java.lang.String.valueOf(new defpackage.rj().a(3798, 8364, 6989)));
        android.view.View viewFindViewById6 = findViewById(com.slidigu.app.R.id.scoreValue);
        viewFindViewById6.getClass();
        this.J = (android.widget.TextView) viewFindViewById6;
        java.lang.String strB2 = new defpackage.jm().b("yeubvvhhk", "lvlvukv");
        if (strB2.toString().length() >= 9) {
            android.util.Log.i("FUR", defpackage.oz.R(strB2.toString(), 8));
        }
        android.view.View viewFindViewById7 = findViewById(com.slidigu.app.R.id.timeValue);
        viewFindViewById7.getClass();
        this.K = (android.widget.TextView) viewFindViewById7;
        android.util.Log.v("GAJI", new defpackage.zx().a("oyiyqnqzug", "blwf", "bmk").toString());
        android.view.View viewFindViewById8 = findViewById(com.slidigu.app.R.id.cargoValue);
        viewFindViewById8.getClass();
        this.L = (android.widget.TextView) viewFindViewById8;
        boolean zA = new defpackage.xu().a(5452);
        if (java.lang.Boolean.hashCode(zA) > 8489) {
            android.util.Log.v("MUWU", java.lang.String.valueOf(zA));
        }
        android.view.View viewFindViewById9 = findViewById(com.slidigu.app.R.id.pauseOverlay);
        viewFindViewById9.getClass();
        this.M = viewFindViewById9;
        int iB3 = new defpackage.l6().b("hgfnopkpdf", "tnqczfvc");
        if (java.lang.String.valueOf(iB3).length() >= 10) {
            android.util.Log.i("KUGU", defpackage.oz.R(java.lang.String.valueOf(iB3), 8));
        }
        android.view.View viewFindViewById10 = findViewById(com.slidigu.app.R.id.controlHint);
        viewFindViewById10.getClass();
        this.N = (android.widget.TextView) viewFindViewById10;
        java.lang.String strA2 = new defpackage.zx().a("wrggtdda", "yjhqx", "drvjg");
        if (strA2.toString().length() >= 3) {
            android.util.Log.i("YEF", defpackage.oz.R(strA2.toString(), 8));
        }
        com.slidigu.app.game.SpaceGameView spaceGameView = this.E;
        if (spaceGameView == null) {
            defpackage.vk.f("gameView");
            spaceGameView = null;
        }
        spaceGameView.setGameListener(this);
        defpackage.rj rjVar = new defpackage.rj();
        java.lang.String strB3 = rjVar.b(5177);
        boolean zA2 = rjVar.a(7896, 824, 652);
        android.util.Log.i("PIY", "h=" + rjVar.hashCode());
        if (strB3.hashCode() != 2193) {
            java.lang.System.out.println((java.lang.Object) strB3.toString());
        }
        if (java.lang.Boolean.hashCode(zA2) != 3842) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(zA2));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnResume)).setOnClickListener(new android.view.View.OnClickListener() { // from class: bo
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity2.j0(this.d, view);
            }
        });
        android.util.Log.d("VUDA", "v=" + new defpackage.j40().b(7236));
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnQuitRun)).setOnClickListener(new android.view.View.OnClickListener() { // from class: co
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity2.k0(this.d, view);
            }
        });
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPause() {
        long jD = defpackage.fo.d(1987);
        if (java.lang.Long.hashCode(jD) != 3893) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(jD));
        }
        super.onPause();
        int iC = new defpackage.xu().c(1935, 8398);
        if (java.lang.String.valueOf(iC).length() >= 7) {
            android.util.Log.i("WECA", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        if (this.P) {
            return;
        }
        com.slidigu.app.game.SpaceGameView spaceGameView = this.E;
        android.view.View view = null;
        if (spaceGameView == null) {
            defpackage.vk.f("gameView");
            spaceGameView = null;
        }
        if (spaceGameView.q()) {
            return;
        }
        int iC2 = new defpackage.xu().c(5110, 8494);
        if (java.lang.String.valueOf(iC2).length() >= 4) {
            android.util.Log.i("VEZAQ", defpackage.oz.R(java.lang.String.valueOf(iC2), 8));
        }
        com.slidigu.app.game.SpaceGameView spaceGameView2 = this.E;
        if (spaceGameView2 == null) {
            defpackage.vk.f("gameView");
            spaceGameView2 = null;
        }
        spaceGameView2.r();
        java.lang.String strB = new defpackage.jm().b("djl", "hfbk");
        if (strB.toString().length() >= 3) {
            android.util.Log.i("LUSU", defpackage.oz.R(strB.toString(), 8));
        }
        android.view.View view2 = this.M;
        if (view2 == null) {
            defpackage.vk.f("pauseOverlay");
        } else {
            view = view2;
        }
        view.setVisibility(0);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        java.lang.String strA = new defpackage.zx().a("stxakf", "ssd", "gfdbjjsorb");
        if (strA.toString().length() >= 6) {
            android.util.Log.i("LINEX", defpackage.oz.R(strA.toString(), 8));
        }
        super.onResume();
        java.lang.String strA2 = new defpackage.zx().a("qgklojgaa", "qaetaeq", "sod");
        if (strA2.hashCode() != 2978) {
            java.lang.System.out.println((java.lang.Object) strA2.toString());
        }
        if (this.P) {
            return;
        }
        android.util.Log.v("SARO", java.lang.String.valueOf(new defpackage.zx().b(1207)));
        com.slidigu.app.game.SpaceGameView spaceGameView = this.E;
        if (spaceGameView == null) {
            defpackage.vk.f("gameView");
            spaceGameView = null;
        }
        spaceGameView.A();
    }

    @Override // com.slidigu.app.game.SpaceGameView.f
    public void v(final int i, final int i2, final int i3, final int i4, final int i5) {
        int iB = new defpackage.m6().b(3180);
        if (java.lang.Integer.hashCode(iB) != 9861) {
            android.util.Log.d("NOK", java.lang.String.valueOf(iB));
        }
        runOnUiThread(new java.lang.Runnable() { // from class: eo
            @Override // java.lang.Runnable
            public final void run() {
                com.slidigu.app.MainActivity2.i0(this.d, i, i2, i3, i4, i5);
            }
        });
    }
}
