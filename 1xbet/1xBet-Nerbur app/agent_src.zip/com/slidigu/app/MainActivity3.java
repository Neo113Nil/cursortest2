package com.slidigu.app;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class MainActivity3 extends androidx.appcompat.app.AppCompatActivity {
    public defpackage.rf E;
    public android.widget.LinearLayout F;
    public android.widget.TextView G;
    public android.view.View H;

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[defpackage.aj.values().length];
            try {
                iArr[defpackage.aj.e.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                iArr[defpackage.aj.f.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                iArr[defpackage.aj.g.ordinal()] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            a = iArr;
        }
    }

    public static void i0(com.slidigu.app.MainActivity3 mainActivity3, android.view.View view) {
        mainActivity3.l0();
    }

    public static void j0(com.slidigu.app.MainActivity3 mainActivity3, android.view.View view) {
        mainActivity3.finish();
    }

    public static void k0(com.slidigu.app.MainActivity3 mainActivity3, android.content.DialogInterface dialogInterface, int i) throws java.lang.IllegalAccessException, java.io.IOException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        android.util.Log.v("TUHEG", new defpackage.xu().b("bffmvsar").toString());
        defpackage.rf rfVar = mainActivity3.E;
        if (rfVar == null) {
            defpackage.vk.f("database");
            rfVar = null;
        }
        rfVar.a();
        java.lang.String strB = new defpackage.xu().b("odthhavvp");
        if (strB.hashCode() > 4704) {
            android.util.Log.v("PUQI", strB.toString());
        }
        mainActivity3.o0();
    }

    public final void l0() {
        new androidx.appcompat.app.a.C0005a(this).f(com.slidigu.app.R.string.clear_history_confirm).i(com.slidigu.app.R.string.yes, new android.content.DialogInterface.OnClickListener() { // from class: io
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(android.content.DialogInterface dialogInterface, int i) throws java.lang.IllegalAccessException, java.io.IOException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
                com.slidigu.app.MainActivity3.k0(this.d, dialogInterface, i);
            }
        }).g(com.slidigu.app.R.string.no, null).l();
    }

    public final java.lang.String m0(long j) {
        java.lang.String strA = new defpackage.j40().a("kfoa");
        if (strA.toString().length() >= 4) {
            android.util.Log.i("JUROWE", defpackage.oz.R(strA.toString(), 8));
        }
        java.text.SimpleDateFormat simpleDateFormat = new java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.US);
        int iB = new defpackage.m6().b(7105);
        if (java.lang.Integer.hashCode(iB) != 8077) {
            android.util.Log.d("MOKA", java.lang.String.valueOf(iB));
        }
        java.lang.String str = simpleDateFormat.format(new java.util.Date(j));
        str.getClass();
        return str;
    }

    public final java.lang.String n0(int i) {
        int iA = new defpackage.m6().a("mrlwim", "bmz");
        if (java.lang.Integer.hashCode(iA) != 2285) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
        }
        int i2 = i / 60;
        int iB = new defpackage.j40().b(6509);
        if (java.lang.Integer.hashCode(iB) > 9972) {
            android.util.Log.v("RAGIR", java.lang.String.valueOf(iB));
        }
        int i3 = i % 60;
        int iB2 = new defpackage.m6().b(3927);
        if (java.lang.Integer.hashCode(iB2) > 5789) {
            android.util.Log.v("SOZO", java.lang.String.valueOf(iB2));
        }
        java.lang.String string = getString(com.slidigu.app.R.string.time_format, java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(i3));
        string.getClass();
        return string;
    }

    public final void o0() throws java.lang.IllegalAccessException, java.io.IOException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        char c;
        android.view.View view;
        android.util.Log.d("VIZEMA", "v=" + new defpackage.jm().a(7356, 7960, 1879));
        defpackage.rf rfVar = this.E;
        if (rfVar == null) {
            defpackage.vk.f("database");
            rfVar = null;
        }
        java.util.List listB = rfVar.b();
        java.lang.String strB = new defpackage.rj().b(9251);
        if (strB.hashCode() != 4312) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        android.widget.LinearLayout linearLayout = this.F;
        java.lang.String str = "historyContainer";
        if (linearLayout == null) {
            defpackage.vk.f("historyContainer");
            linearLayout = null;
        }
        linearLayout.removeAllViews();
        android.util.Log.i("PEQIME", "h=" + java.lang.Integer.hashCode(new defpackage.xu().c(811, 8260)));
        if (listB.isEmpty()) {
            int iB = new defpackage.m6().b(1076);
            if (java.lang.Integer.hashCode(iB) != 8050) {
                android.util.Log.d("GUKOSU", java.lang.String.valueOf(iB));
            }
            android.widget.TextView textView = this.G;
            if (textView == null) {
                defpackage.vk.f("emptyText");
                textView = null;
            }
            textView.setVisibility(0);
            int iB2 = new defpackage.zx().b(2281);
            if (java.lang.Integer.hashCode(iB2) != 7598) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB2));
            }
            android.view.View view2 = this.H;
            if (view2 == null) {
                defpackage.vk.f("headerRow");
                view = null;
            } else {
                view = view2;
            }
            view.setVisibility(8);
            java.lang.String strB2 = new defpackage.jm().b("vzerpq", "ilrgf");
            if (strB2.hashCode() > 2812) {
                android.util.Log.v("BUXIWI", strB2.toString());
                return;
            }
            return;
        }
        android.util.Log.d("VIB", "v=" + new defpackage.xu().b("ojsolfvlu"));
        android.widget.TextView textView2 = this.G;
        if (textView2 == null) {
            defpackage.vk.f("emptyText");
            textView2 = null;
        }
        textView2.setVisibility(8);
        boolean zA = new defpackage.xu().a(7611);
        if (java.lang.Boolean.hashCode(zA) != 1549) {
            android.util.Log.d("MEX", java.lang.String.valueOf(zA));
        }
        android.view.View view3 = this.H;
        if (view3 == null) {
            defpackage.vk.f("headerRow");
            view3 = null;
        }
        view3.setVisibility(0);
        android.util.Log.d("XOX", "v=" + new defpackage.rj().a(1025, 9351, 2394));
        android.view.LayoutInflater layoutInflaterFrom = android.view.LayoutInflater.from(this);
        defpackage.m6 m6Var = new defpackage.m6();
        int iA = m6Var.a("svkqdjuddb", "mrwcjo");
        int iB3 = m6Var.b(8883);
        if (m6Var.toString().length() >= 5) {
            android.util.Log.i("TIGU", defpackage.oz.R(m6Var.toString(), 8));
        }
        android.util.Log.i("GODEW", "h=" + java.lang.Integer.hashCode(iA));
        if (java.lang.Integer.hashCode(iB3) != 5245) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
        }
        java.util.Iterator it = listB.iterator();
        while (it.hasNext()) {
            defpackage.sf sfVar = (defpackage.sf) it.next();
            defpackage.xu xuVar = new defpackage.xu();
            int iC = xuVar.c(9860, 6526);
            java.lang.String strB3 = xuVar.b("ctgwhvuj");
            boolean zA2 = xuVar.a(8751);
            defpackage.j40 j40Var = new defpackage.j40();
            java.lang.String strA = j40Var.a("bflhezhx");
            int iB4 = j40Var.b(5662);
            java.lang.String strC = defpackage.ko.c(6841);
            defpackage.rj rjVar = new defpackage.rj();
            java.lang.String strB4 = rjVar.b(4859);
            java.util.Iterator it2 = it;
            java.lang.String str2 = str;
            boolean zA3 = rjVar.a(3755, 3029, 1658);
            if (xuVar.toString().length() >= 8) {
                android.util.Log.i("MACU", defpackage.oz.R(xuVar.toString(), 8));
            }
            android.util.Log.i("ZIHA", "h=" + java.lang.Integer.hashCode(iC));
            android.util.Log.v("CENOCI", strB3.toString());
            android.util.Log.d("GIF", "v=" + zA2);
            if (j40Var.hashCode() != 7019) {
                android.util.Log.d("ZIZ", j40Var.toString());
            }
            if (strA.hashCode() != 5306) {
                java.lang.System.out.println((java.lang.Object) strA.toString());
            }
            android.util.Log.d("LITEK", "v=" + iB4);
            if (strC.hashCode() != 6436) {
                android.util.Log.d("QEFADI", strC.toString());
            }
            android.util.Log.i("YODAF", "h=" + rjVar.hashCode());
            android.util.Log.i("LEN", "h=" + strB4.hashCode());
            if (java.lang.String.valueOf(zA3).length() >= 5) {
                c = '\b';
                android.util.Log.i("YIYI", defpackage.oz.R(java.lang.String.valueOf(zA3), 8));
            } else {
                c = '\b';
            }
            int i = com.slidigu.app.R.layout.item_flight_record;
            android.widget.LinearLayout linearLayout2 = this.F;
            if (linearLayout2 == null) {
                defpackage.vk.f(str2);
                linearLayout2 = null;
            }
            android.view.View viewInflate = layoutInflaterFrom.inflate(i, (android.view.ViewGroup) linearLayout2, false);
            java.lang.String strA2 = new defpackage.j40().a("ytqmpjee");
            if (strA2.hashCode() != 1796) {
                android.util.Log.d("MECU", strA2.toString());
            }
            ((android.widget.TextView) viewInflate.findViewById(com.slidigu.app.R.id.rowDate)).setText(m0(sfVar.d()));
            int iC2 = new defpackage.xu().c(2034, 1587);
            if (java.lang.Integer.hashCode(iC2) > 6541) {
                android.util.Log.v("JOWAY", java.lang.String.valueOf(iC2));
            }
            ((android.widget.TextView) viewInflate.findViewById(com.slidigu.app.R.id.rowScore)).setText(java.lang.String.valueOf(sfVar.f()));
            int iB5 = new defpackage.l6().b("csgjcclloi", "ysg");
            if (java.lang.Integer.hashCode(iB5) != 921) {
                android.util.Log.d("BOYEJ", java.lang.String.valueOf(iB5));
            }
            ((android.widget.TextView) viewInflate.findViewById(com.slidigu.app.R.id.rowTime)).setText(n0(sfVar.b()));
            int iC3 = new defpackage.xu().c(7580, 9062);
            if (java.lang.Integer.hashCode(iC3) > 8945) {
                android.util.Log.v("MOQ", java.lang.String.valueOf(iC3));
            }
            ((android.widget.TextView) viewInflate.findViewById(com.slidigu.app.R.id.rowFuel)).setText(java.lang.String.valueOf(sfVar.c()));
            int iC4 = new defpackage.xu().c(3293, 1530);
            if (java.lang.Integer.hashCode(iC4) > 5155) {
                android.util.Log.v("XADUB", java.lang.String.valueOf(iC4));
            }
            ((android.widget.TextView) viewInflate.findViewById(com.slidigu.app.R.id.rowResult)).setText(p0(sfVar.e()));
            int iB6 = new defpackage.l6().b("nyxnwj", "lbutzdggvk");
            if (java.lang.Integer.hashCode(iB6) != 5942) {
                android.util.Log.d("CAMAS", java.lang.String.valueOf(iB6));
            }
            android.widget.LinearLayout linearLayout3 = this.F;
            if (linearLayout3 == null) {
                defpackage.vk.f(str2);
                linearLayout3 = null;
            }
            linearLayout3.addView(viewInflate);
            it = it2;
            str = str2;
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(android.os.Bundle bundle) throws java.lang.IllegalAccessException, java.io.IOException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        java.lang.String strC = defpackage.ko.c(1790);
        if (strC.hashCode() != 1467) {
            java.lang.System.out.println((java.lang.Object) strC.toString());
        }
        super.onCreate(bundle);
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA = j40Var.a("tkmevzt");
        int iB = j40Var.b(6766);
        android.util.Log.d("VIG", "v=" + j40Var);
        if (strA.toString().length() >= 6) {
            android.util.Log.i("SUKUWU", defpackage.oz.R(strA.toString(), 8));
        }
        if (java.lang.Integer.hashCode(iB) != 5370) {
            android.util.Log.d("DALI", java.lang.String.valueOf(iB));
        }
        setContentView(com.slidigu.app.R.layout.activity_main3);
        boolean zA = new defpackage.xu().a(6210);
        if (java.lang.String.valueOf(zA).length() >= 8) {
            android.util.Log.i("HOPES", defpackage.oz.R(java.lang.String.valueOf(zA), 8));
        }
        this.E = new defpackage.rf(this);
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA2 = zxVar.a("lhhfjfsj", "iwkgii", "yfwqwcuaby");
        int iB2 = zxVar.b(5893);
        android.util.Log.d("ZULI", "v=" + zxVar);
        if (strA2.hashCode() != 1102) {
            java.lang.System.out.println((java.lang.Object) strA2.toString());
        }
        if (java.lang.Integer.hashCode(iB2) > 8269) {
            android.util.Log.v("WET", java.lang.String.valueOf(iB2));
        }
        android.view.View viewFindViewById = findViewById(com.slidigu.app.R.id.historyContainer);
        viewFindViewById.getClass();
        this.F = (android.widget.LinearLayout) viewFindViewById;
        java.lang.String strB = new defpackage.xu().b("qejcdcpqpz");
        if (strB.hashCode() != 3716) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        android.view.View viewFindViewById2 = findViewById(com.slidigu.app.R.id.emptyText);
        viewFindViewById2.getClass();
        this.G = (android.widget.TextView) viewFindViewById2;
        android.util.Log.v("BUJO", new defpackage.xu().b("ypo").toString());
        android.view.View viewFindViewById3 = findViewById(com.slidigu.app.R.id.headerRow);
        viewFindViewById3.getClass();
        this.H = viewFindViewById3;
        android.util.Log.d("NASEPA", "v=" + new defpackage.j40().a("jzhucboy"));
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnBack)).setOnClickListener(new android.view.View.OnClickListener() { // from class: go
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity3.j0(this.d, view);
            }
        });
        int iB3 = new defpackage.j40().b(1949);
        if (java.lang.Integer.hashCode(iB3) > 9022) {
            android.util.Log.v("VAR", java.lang.String.valueOf(iB3));
        }
        ((com.google.android.material.button.MaterialButton) findViewById(com.slidigu.app.R.id.btnClearHistory)).setOnClickListener(new android.view.View.OnClickListener() { // from class: ho
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity3.i0(this.d, view);
            }
        });
        int iB4 = new defpackage.l6().b("blovr", "pvabt");
        if (java.lang.String.valueOf(iB4).length() >= 8) {
            android.util.Log.i("GUJO", defpackage.oz.R(java.lang.String.valueOf(iB4), 8));
        }
        o0();
    }

    public final java.lang.String p0(defpackage.aj ajVar) {
        int i = com.slidigu.app.MainActivity3.a.a[ajVar.ordinal()];
        if (i == 1) {
            java.lang.String string = getString(com.slidigu.app.R.string.result_hull_breach);
            string.getClass();
            return string;
        }
        if (i == 2) {
            java.lang.String string2 = getString(com.slidigu.app.R.string.result_out_of_fuel);
            string2.getClass();
            return string2;
        }
        if (i != 3) {
            throw new defpackage.tr();
        }
        java.lang.String string3 = getString(com.slidigu.app.R.string.result_aborted);
        string3.getClass();
        return string3;
    }
}
