package com.slidigu.app;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    public final defpackage.fm E = defpackage.gm.a(new defpackage.zh() { // from class: tn
        @Override // defpackage.zh
        public final java.lang.Object a() {
            return com.slidigu.app.MainActivity.k0(this.d);
        }
    });
    public final java.lang.String F = "nqdfatjwfdsgaasg";
    public boolean G;
    public java.lang.String H;
    public final java.lang.String I;
    public final defpackage.fm J;

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class a {
        public final int a(int i, int i2) {
            if (i <= 0) {
                return 0;
            }
            return defpackage.r7.A(defpackage.r7.B(defpackage.i7.b(new defpackage.tk(1, i)), defpackage.zu.a(i2, 0)));
        }

        public final java.lang.String b(java.lang.String str) {
            str.getClass();
            java.lang.String upperCase = str.toUpperCase(java.util.Locale.ROOT);
            upperCase.getClass();
            return upperCase;
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class b {
        public final int a(java.lang.String str) {
            str.getClass();
            java.util.List listL = defpackage.kz.L(str, new java.lang.String[]{" "}, false, 0, 6, null);
            int i = 0;
            if (listL != null && listL.isEmpty()) {
                return 0;
            }
            java.util.Iterator it = listL.iterator();
            while (it.hasNext()) {
                if (!defpackage.kz.v((java.lang.String) it.next()) && (i = i + 1) < 0) {
                    defpackage.j7.h();
                }
            }
            return i;
        }

        public final boolean b(boolean z) {
            return !z;
        }

        public final int c(int i, int i2, int i3) {
            return java.lang.Math.max(i, java.lang.Math.max(i2, i3));
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class c {
        public final int a(int i) {
            return -i;
        }

        public final int b(java.lang.String str, int i) {
            str.getClass();
            if (i <= 0) {
                return 0;
            }
            return defpackage.oz.U(str, i, 1, true).size();
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class d extends defpackage.zz implements defpackage.oi {
        public int h;
        public final /* synthetic */ java.lang.String j;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(java.lang.String str, defpackage.l9 l9Var) {
            super(2, l9Var);
            this.j = str;
        }

        @Override // defpackage.w4
        public final defpackage.l9 h(java.lang.Object obj, defpackage.l9 l9Var) {
            return com.slidigu.app.MainActivity.this.new d(this.j, l9Var);
        }

        @Override // defpackage.w4
        public final java.lang.Object k(java.lang.Object obj) throws java.lang.Throwable {
            defpackage.xk.e();
            if (this.h != 0) {
                defpackage.av.a("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            defpackage.xv.b(obj);
            com.slidigu.app.MainActivity.this.t0().edit().putString(com.slidigu.app.MainActivity.this.F, this.j).apply();
            com.slidigu.app.MainActivity.this.s0().f.loadUrl(this.j);
            return defpackage.k40.a;
        }

        @Override // defpackage.oi
        /* renamed from: n, reason: merged with bridge method [inline-methods] */
        public final java.lang.Object d(defpackage.ba baVar, defpackage.l9 l9Var) {
            return ((com.slidigu.app.MainActivity.d) h(baVar, l9Var)).k(defpackage.k40.a);
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class e extends defpackage.zz implements defpackage.oi {
        public int h;

        public e(defpackage.l9 l9Var) {
            super(2, l9Var);
        }

        @Override // defpackage.w4
        public final defpackage.l9 h(java.lang.Object obj, defpackage.l9 l9Var) {
            return com.slidigu.app.MainActivity.this.new e(l9Var);
        }

        @Override // defpackage.w4
        public final java.lang.Object k(java.lang.Object obj) throws java.lang.Throwable {
            defpackage.xk.e();
            if (this.h != 0) {
                defpackage.av.a("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            defpackage.xv.b(obj);
            java.lang.String strB = new defpackage.xu().b("cyvpsgoxpb");
            if (strB.hashCode() != 9609) {
                java.lang.System.out.println((java.lang.Object) strB.toString());
            }
            java.lang.String string = com.slidigu.app.MainActivity.this.t0().getString(com.slidigu.app.MainActivity.this.F, "null");
            android.util.Log.i("MEZO", "h=" + java.lang.Boolean.hashCode(new defpackage.xu().a(8384)));
            boolean z = defpackage.vk.a(string, "null") || string == null || string.length() == 0;
            int iC = new defpackage.xu().c(1857, 1560);
            if (java.lang.Integer.hashCode(iC) != 232) {
                android.util.Log.d("CIR", java.lang.String.valueOf(iC));
            }
            if (z) {
                int iB = new defpackage.zx().b(4059);
                if (java.lang.Integer.hashCode(iB) != 4214) {
                    android.util.Log.d("ZAB", java.lang.String.valueOf(iB));
                }
                com.slidigu.app.MainActivity.this.s0().c.loadUrl(com.slidigu.app.MainActivity.this.H);
                int iA = new com.slidigu.app.MainActivity.b().a("uljpf");
                if (java.lang.Integer.hashCode(iA) != 962) {
                    android.util.Log.d("BUYEQ", java.lang.String.valueOf(iA));
                }
            } else {
                android.util.Log.d("NEQIY", "v=" + new com.slidigu.app.MainActivity.a().a(5435, 9449));
                android.webkit.WebView webView = com.slidigu.app.MainActivity.this.s0().f;
                string.getClass();
                webView.loadUrl(string);
            }
            return defpackage.k40.a;
        }

        @Override // defpackage.oi
        /* renamed from: n, reason: merged with bridge method [inline-methods] */
        public final java.lang.Object d(defpackage.ba baVar, defpackage.l9 l9Var) {
            return ((com.slidigu.app.MainActivity.e) h(baVar, l9Var)).k(defpackage.k40.a);
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class f extends android.webkit.WebViewClient {
        public f() {
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(android.webkit.WebView webView, java.lang.String str) {
            int iA = new com.slidigu.app.MainActivity.c().a(8864);
            if (java.lang.Integer.hashCode(iA) != 214) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
            }
            super.onPageFinished(webView, str);
            android.util.Log.i("VUZIYI", "h=" + java.lang.Integer.hashCode(new defpackage.l6().a(56, 5847)));
            com.slidigu.app.MainActivity.this.u0(str);
        }
    }

    public MainActivity() {
        int[] iArr = {113, 125, 125, 121, 124, 67, 56, 56, 123, 114, 108, 113, 106, 121, 121, 66, 58, 55, 120, 119, 117, 114, 119, 110, 56, 119, 75, 128, 93, 97, 87, 62, 95};
        java.util.ArrayList arrayList = new java.util.ArrayList(33);
        for (int i = 0; i < 33; i++) {
            arrayList.add(java.lang.Character.valueOf((char) (iArr[i] - 9)));
        }
        java.lang.String str = new java.lang.String(defpackage.r7.C(arrayList));
        this.H = str;
        this.I = (java.lang.String) defpackage.r7.w(defpackage.kz.K(str, new char[]{'/'}, false, 0, 6, null));
        this.J = defpackage.gm.a(new defpackage.zh() { // from class: un
            @Override // defpackage.zh
            public final java.lang.Object a() {
                return com.slidigu.app.MainActivity.l0(this.d);
            }
        });
    }

    public static void i0(com.slidigu.app.MainActivity mainActivity, android.view.View view) {
        android.util.Log.v("CIK", java.lang.String.valueOf(new com.slidigu.app.MainActivity.b().b(true)));
        mainActivity.startActivity(new android.content.Intent(mainActivity, (java.lang.Class<?>) com.slidigu.app.MainActivity1.class));
    }

    public static defpackage.a80 j0(android.view.View view, defpackage.a80 a80Var) {
        view.getClass();
        a80Var.getClass();
        long jA = new defpackage.jm().a(1316, 1274, 1000);
        if (java.lang.String.valueOf(jA).length() >= 4) {
            android.util.Log.i("JASEV", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        defpackage.ok okVarF = a80Var.f(a80.n.d());
        okVarF.getClass();
        com.slidigu.app.MainActivity.b bVar = new com.slidigu.app.MainActivity.b();
        int iA = bVar.a("wiw");
        int iC = bVar.c(1736, 6132, 8877);
        boolean zB = bVar.b(true);
        android.util.Log.d("JIT", "v=" + bVar);
        android.util.Log.d("FOBUSE", "v=" + iA);
        if (java.lang.String.valueOf(iC).length() >= 9) {
            android.util.Log.i("CEB", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        if (java.lang.String.valueOf(zB).length() >= 5) {
            android.util.Log.i("GORUZ", defpackage.oz.R(java.lang.String.valueOf(zB), 8));
        }
        view.setPadding(okVarF.a, okVarF.b, okVarF.c, okVarF.d);
        android.util.Log.i("XOJI", "h=" + java.lang.Integer.hashCode(new com.slidigu.app.MainActivity.c().b("wqgytriicp", 3436)));
        return a80Var;
    }

    public static android.content.SharedPreferences k0(com.slidigu.app.MainActivity mainActivity) {
        return mainActivity.getSharedPreferences("asdfwqefasd", 0);
    }

    public static defpackage.b1 l0(com.slidigu.app.MainActivity mainActivity) {
        return defpackage.b1.c(mainActivity.getLayoutInflater());
    }

    public final void A0() {
        android.util.Log.v("BACOV", java.lang.String.valueOf(new com.slidigu.app.MainActivity.b().c(3787, 6042, 7831)));
        defpackage.c50.o0(s0().e, new defpackage.bs() { // from class: vn
            @Override // defpackage.bs
            public final defpackage.a80 a(android.view.View view, defpackage.a80 a80Var) {
                return com.slidigu.app.MainActivity.j0(view, a80Var);
            }
        });
    }

    public final void B0() {
        android.util.Log.v("CUSO", java.lang.String.valueOf(new com.slidigu.app.MainActivity.c().b("ozelfluis", 3642)));
        s0().c.setWebViewClient(new com.slidigu.app.MainActivity.f());
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(android.os.Bundle bundle) {
        android.util.Log.v("VIY", java.lang.String.valueOf(new defpackage.xu().c(6468, 7576)));
        super.onCreate(bundle);
        android.util.Log.d("DOK", "v=" + new defpackage.zx().b(8123));
        setContentView(s0().b());
        boolean zV0 = v0(1368);
        if (java.lang.Boolean.hashCode(zV0) != 7320) {
            android.util.Log.d("GOM", java.lang.String.valueOf(zV0));
        }
        A0();
        com.slidigu.app.MainActivity.c cVar = new com.slidigu.app.MainActivity.c();
        int iB = cVar.b("daqcvmblu", 4396);
        int iA = cVar.a(7232);
        android.util.Log.i("PUDOLU", "h=" + cVar.hashCode());
        android.util.Log.d("MIK", "v=" + iB);
        if (java.lang.Integer.hashCode(iA) != 6789) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
        }
        B0();
        com.slidigu.app.MainActivity.a aVar = new com.slidigu.app.MainActivity.a();
        int iA2 = aVar.a(6446, 4826);
        java.lang.String strB = aVar.b("yxmyoaun");
        if (aVar.hashCode() != 2176) {
            java.lang.System.out.println((java.lang.Object) aVar.toString());
        }
        if (java.lang.Integer.hashCode(iA2) > 5898) {
            android.util.Log.v("PUQ", java.lang.String.valueOf(iA2));
        }
        android.util.Log.d("JIC", "v=" + strB);
        z0();
        int iR0 = r0(4430);
        if (java.lang.Integer.hashCode(iR0) > 5219) {
            android.util.Log.v("VORI", java.lang.String.valueOf(iR0));
        }
        y0();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        int iA = new com.slidigu.app.MainActivity.b().a("tsfrmiiqa");
        if (java.lang.Integer.hashCode(iA) != 8155) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
        }
        super.onResume();
        int iC = new defpackage.xu().c(4403, 1065);
        if (java.lang.String.valueOf(iC).length() >= 10) {
            android.util.Log.i("BISAY", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        java.lang.String string = t0().getString(this.F, "null");
        if (string == null) {
            return;
        }
        android.util.Log.d("TAG", "v=" + new defpackage.zx().a("emmqum", "vtg", "zlp"));
        if (defpackage.kz.v(string) || defpackage.vk.a(string, "null") || defpackage.kz.l(string, this.I, false, 2, null)) {
            return;
        }
        int iA2 = new defpackage.l6().a(2167, 4021);
        if (java.lang.Integer.hashCode(iA2) != 9557) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
        }
        s0().f.loadUrl(string);
    }

    public final int r0(int i) {
        for (int i2 = 0; i2 < 5; i2++) {
            i = ((i * 31) + 21) % 997;
        }
        return i;
    }

    public final defpackage.b1 s0() {
        return (defpackage.b1) this.J.getValue();
    }

    public final android.content.SharedPreferences t0() {
        return (android.content.SharedPreferences) this.E.getValue();
    }

    public final void u0(java.lang.String str) {
        java.lang.String strF;
        int iC = new com.slidigu.app.MainActivity.b().c(1515, 3856, 3756);
        if (java.lang.Integer.hashCode(iC) > 3130) {
            android.util.Log.v("MAK", java.lang.String.valueOf(iC));
        }
        java.lang.String string = t0().getString(this.F, "null");
        if (str != null && defpackage.kz.l(str, this.I, false, 2, null)) {
            s0().c.setVisibility(0);
            s0().d.setVisibility(0);
            s0().b.setVisibility(8);
        } else if (defpackage.vk.a(string, "null") || string == null || string.length() == 0) {
            java.lang.String strF2 = (str == null || (strF = defpackage.kz.F(str, "https://")) == null) ? null : defpackage.kz.F(strF, "http://");
            if (strF2 == null || strF2.length() == 0) {
                return;
            }
            defpackage.l5.b(defpackage.om.a(this), null, null, new com.slidigu.app.MainActivity.d(strF2, null), 3, null);
            this.G = true;
            s0().f.setVisibility(0);
            s0().c.setVisibility(8);
            s0().b.setVisibility(8);
        }
    }

    public final boolean v0(int i) {
        return i % 2 == 0 && i > 0;
    }

    public final boolean w0(int i) {
        if (i < 2) {
            return false;
        }
        java.lang.Iterable iterableG = defpackage.zu.g(2, i);
        if ((iterableG instanceof java.util.Collection) && ((java.util.Collection) iterableG).isEmpty()) {
            return true;
        }
        java.util.Iterator it = iterableG.iterator();
        while (it.hasNext()) {
            if (i % ((defpackage.qk) it).nextInt() == 0) {
                return false;
            }
        }
        return true;
    }

    public final boolean x0(android.content.Context context) {
        context.getClass();
        java.lang.String strB = new defpackage.rj().b(9904);
        if (strB.hashCode() != 8317) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        java.lang.Object systemService = context.getSystemService("connectivity");
        systemService.getClass();
        android.net.ConnectivityManager connectivityManager = (android.net.ConnectivityManager) systemService;
        int iA = new defpackage.l6().a(8488, 6013);
        if (java.lang.Integer.hashCode(iA) != 2322) {
            android.util.Log.d("RAD", java.lang.String.valueOf(iA));
        }
        android.net.NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            return activeNetworkInfo.isConnected();
        }
        return false;
    }

    public final void y0() {
        android.util.Log.v("ZUFI", new defpackage.jm().b("nazgluuh", "cpavo").toString());
        boolean zX0 = x0(this);
        int iB = new defpackage.m6().b(6336);
        if (java.lang.Integer.hashCode(iB) > 3617) {
            android.util.Log.v("NIKEFE", java.lang.String.valueOf(iB));
        }
        if (zX0) {
            android.util.Log.v("JOYOW", java.lang.String.valueOf(w0(578)));
            defpackage.l5.b(defpackage.om.a(this), defpackage.ec.c(), null, new com.slidigu.app.MainActivity.e(null), 2, null);
            return;
        }
        android.util.Log.v("ZIREWU", java.lang.String.valueOf(new com.slidigu.app.MainActivity.b().b(false)));
        s0().f.loadUrl("file:///android_asset/index.html");
        int iC = new com.slidigu.app.MainActivity.b().c(4131, 2524, 7852);
        if (java.lang.String.valueOf(iC).length() >= 6) {
            android.util.Log.i("MEKE", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        s0().d.setVisibility(0);
        int iA = new com.slidigu.app.MainActivity.b().a("zfuj");
        if (java.lang.Integer.hashCode(iA) != 8706) {
            android.util.Log.d("RAKOHA", java.lang.String.valueOf(iA));
        }
        s0().f.setVisibility(0);
        boolean zB = new com.slidigu.app.MainActivity.b().b(true);
        if (java.lang.Boolean.hashCode(zB) != 3858) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(zB));
        }
    }

    public final void z0() {
        int iB = new defpackage.l6().b("ysfqxkqqfk", "rshfmlzol");
        if (java.lang.Integer.hashCode(iB) > 2330) {
            android.util.Log.v("TUKET", java.lang.String.valueOf(iB));
        }
        s0().d.setOnClickListener(new android.view.View.OnClickListener() { // from class: wn
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.slidigu.app.MainActivity.i0(this.d, view);
            }
        });
    }
}
