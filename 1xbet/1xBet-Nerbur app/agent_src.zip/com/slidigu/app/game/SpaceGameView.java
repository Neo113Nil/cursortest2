package com.slidigu.app.game;

/* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
/* loaded from: classes.dex */
public final class SpaceGameView extends android.view.View {
    public static final com.slidigu.app.game.SpaceGameView.d G = new com.slidigu.app.game.SpaceGameView.d(null);
    public final java.util.List A;
    public final java.util.List B;
    public float C;
    public float D;
    public float E;
    public float F;
    public final android.graphics.Paint d;
    public final android.graphics.Path e;
    public com.slidigu.app.game.SpaceGameView.f f;
    public boolean g;
    public boolean h;
    public long i;
    public float j;
    public float k;
    public float l;
    public float m;
    public float n;
    public int o;
    public float p;
    public int q;
    public int r;
    public int s;
    public int t;
    public long u;
    public float v;
    public final java.util.List w;
    public final java.util.List x;
    public final java.util.List y;
    public final java.util.List z;

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class a {
        public float a;
        public float b;
        public final float c;
        public final float d;
        public float e;
        public final float f;
        public final float[] g;

        public a(float f, float f2, float f3, float f4, float f5, float f6, float[] fArr) {
            fArr.getClass();
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = f4;
            this.e = f5;
            this.f = f6;
            this.g = fArr;
        }

        public final float a() {
            return this.c;
        }

        public final float b() {
            return this.e;
        }

        public final float[] c() {
            return this.g;
        }

        public final float d() {
            return this.d;
        }

        public final float e() {
            return this.f;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.a)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.a aVar = (com.slidigu.app.game.SpaceGameView.a) obj;
            return java.lang.Float.compare(this.a, aVar.a) == 0 && java.lang.Float.compare(this.b, aVar.b) == 0 && java.lang.Float.compare(this.c, aVar.c) == 0 && java.lang.Float.compare(this.d, aVar.d) == 0 && java.lang.Float.compare(this.e, aVar.e) == 0 && java.lang.Float.compare(this.f, aVar.f) == 0 && defpackage.vk.a(this.g, aVar.g);
        }

        public final float f() {
            return this.a;
        }

        public final float g() {
            return this.b;
        }

        public final void h(float f) {
            this.e = f;
        }

        public int hashCode() {
            return (((((((((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Float.hashCode(this.d)) * 31) + java.lang.Float.hashCode(this.e)) * 31) + java.lang.Float.hashCode(this.f)) * 31) + java.util.Arrays.hashCode(this.g);
        }

        public final void i(float f) {
            this.a = f;
        }

        public java.lang.String toString() {
            return "Asteroid(x=" + this.a + ", y=" + this.b + ", radius=" + this.c + ", speed=" + this.d + ", rotation=" + this.e + ", spin=" + this.f + ", shapeRadii=" + java.util.Arrays.toString(this.g) + ")";
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class b {
        public final float a;
        public final float b;
        public final float c;
        public final int d;
        public final boolean e;

        public b(float f, float f2, float f3, int i, boolean z) {
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = i;
            this.e = z;
        }

        public final int a() {
            return this.d;
        }

        public final float b() {
            return this.c;
        }

        public final boolean c() {
            return this.e;
        }

        public final float d() {
            return this.a;
        }

        public final float e() {
            return this.b;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.b)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.b bVar = (com.slidigu.app.game.SpaceGameView.b) obj;
            return java.lang.Float.compare(this.a, bVar.a) == 0 && java.lang.Float.compare(this.b, bVar.b) == 0 && java.lang.Float.compare(this.c, bVar.c) == 0 && this.d == bVar.d && this.e == bVar.e;
        }

        public int hashCode() {
            return (((((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Integer.hashCode(this.d)) * 31) + java.lang.Boolean.hashCode(this.e);
        }

        public java.lang.String toString() {
            return "BackgroundPlanet(x=" + this.a + ", y=" + this.b + ", radius=" + this.c + ", color=" + this.d + ", ring=" + this.e + ")";
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class c {
        public float a;
        public float b;
        public final float c;
        public final float d;

        public c(float f, float f2, float f3, float f4) {
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = f4;
        }

        public final float a() {
            return this.c;
        }

        public final float b() {
            return this.d;
        }

        public final float c() {
            return this.a;
        }

        public final float d() {
            return this.b;
        }

        public final void e(float f) {
            this.a = f;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.c)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.c cVar = (com.slidigu.app.game.SpaceGameView.c) obj;
            return java.lang.Float.compare(this.a, cVar.a) == 0 && java.lang.Float.compare(this.b, cVar.b) == 0 && java.lang.Float.compare(this.c, cVar.c) == 0 && java.lang.Float.compare(this.d, cVar.d) == 0;
        }

        public int hashCode() {
            return (((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Float.hashCode(this.d);
        }

        public java.lang.String toString() {
            return "CargoPod(x=" + this.a + ", y=" + this.b + ", radius=" + this.c + ", speed=" + this.d + ")";
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class d {
        public d() {
        }

        public /* synthetic */ d(defpackage.za zaVar) {
            this();
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class e {
        public float a;
        public float b;
        public final float c;
        public final float d;
        public float e;

        public e(float f, float f2, float f3, float f4, float f5) {
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = f4;
            this.e = f5;
        }

        public final float a() {
            return this.e;
        }

        public final float b() {
            return this.c;
        }

        public final float c() {
            return this.d;
        }

        public final float d() {
            return this.a;
        }

        public final float e() {
            return this.b;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.e)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.e eVar = (com.slidigu.app.game.SpaceGameView.e) obj;
            return java.lang.Float.compare(this.a, eVar.a) == 0 && java.lang.Float.compare(this.b, eVar.b) == 0 && java.lang.Float.compare(this.c, eVar.c) == 0 && java.lang.Float.compare(this.d, eVar.d) == 0 && java.lang.Float.compare(this.e, eVar.e) == 0;
        }

        public final void f(float f) {
            this.e = f;
        }

        public final void g(float f) {
            this.a = f;
        }

        public int hashCode() {
            return (((((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Float.hashCode(this.d)) * 31) + java.lang.Float.hashCode(this.e);
        }

        public java.lang.String toString() {
            return "FuelCanister(x=" + this.a + ", y=" + this.b + ", radius=" + this.c + ", speed=" + this.d + ", pulse=" + this.e + ")";
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public interface f {
        void f(int i, int i2, int i3, int i4, defpackage.aj ajVar);

        void v(int i, int i2, int i3, int i4, int i5);
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class g {
        public float a;
        public float b;
        public final float c;
        public final float d;
        public final float e;
        public final int f;
        public final int g;

        public g(float f, float f2, float f3, float f4, float f5, int i, int i2) {
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = f4;
            this.e = f5;
            this.f = i;
            this.g = i2;
        }

        public final int a() {
            return this.f;
        }

        public final int b() {
            return this.g;
        }

        public final float c() {
            return this.e;
        }

        public final float d() {
            return this.c;
        }

        public final float e() {
            return this.d;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.g)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.g gVar = (com.slidigu.app.game.SpaceGameView.g) obj;
            return java.lang.Float.compare(this.a, gVar.a) == 0 && java.lang.Float.compare(this.b, gVar.b) == 0 && java.lang.Float.compare(this.c, gVar.c) == 0 && java.lang.Float.compare(this.d, gVar.d) == 0 && java.lang.Float.compare(this.e, gVar.e) == 0 && this.f == gVar.f && this.g == gVar.g;
        }

        public final float f() {
            return this.a;
        }

        public final float g() {
            return this.b;
        }

        public final void h(float f) {
            this.a = f;
        }

        public int hashCode() {
            return (((((((((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Float.hashCode(this.d)) * 31) + java.lang.Float.hashCode(this.e)) * 31) + java.lang.Integer.hashCode(this.f)) * 31) + java.lang.Integer.hashCode(this.g);
        }

        public final void i(float f) {
            this.b = f;
        }

        public java.lang.String toString() {
            return "Particle(x=" + this.a + ", y=" + this.b + ", vx=" + this.c + ", vy=" + this.d + ", radius=" + this.e + ", alpha=" + this.f + ", color=" + this.g + ")";
        }
    }

    /* compiled from: r8-map-id-ac1f1555f186986d1aee3934605e29f8da4dbfa486767f37c53c08a533fc3c9a */
    public static final class h {
        public float a;
        public float b;
        public final float c;
        public final float d;

        public h(float f, float f2, float f3, float f4) {
            this.a = f;
            this.b = f2;
            this.c = f3;
            this.d = f4;
        }

        public final float a() {
            return this.c;
        }

        public final float b() {
            return this.d;
        }

        public final float c() {
            return this.a;
        }

        public final float d() {
            return this.b;
        }

        public final void e(float f) {
            this.a = f;
        }

        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof com.slidigu.app.game.SpaceGameView.h)) {
                return false;
            }
            com.slidigu.app.game.SpaceGameView.h hVar = (com.slidigu.app.game.SpaceGameView.h) obj;
            return java.lang.Float.compare(this.a, hVar.a) == 0 && java.lang.Float.compare(this.b, hVar.b) == 0 && java.lang.Float.compare(this.c, hVar.c) == 0 && java.lang.Float.compare(this.d, hVar.d) == 0;
        }

        public final void f(float f) {
            this.b = f;
        }

        public int hashCode() {
            return (((((java.lang.Float.hashCode(this.a) * 31) + java.lang.Float.hashCode(this.b)) * 31) + java.lang.Float.hashCode(this.c)) * 31) + java.lang.Float.hashCode(this.d);
        }

        public java.lang.String toString() {
            return "Star(x=" + this.a + ", y=" + this.b + ", size=" + this.c + ", speed=" + this.d + ")";
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SpaceGameView(android.content.Context context, android.util.AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.d = new android.graphics.Paint(1);
        this.e = new android.graphics.Path();
        this.n = 48.0f;
        this.o = 100;
        this.p = 100.0f;
        this.v = 1.0f;
        this.w = new java.util.ArrayList();
        this.x = new java.util.ArrayList();
        this.y = new java.util.ArrayList();
        this.z = new java.util.ArrayList();
        this.A = new java.util.ArrayList();
        this.B = new java.util.ArrayList();
    }

    public static boolean a(com.slidigu.app.game.SpaceGameView spaceGameView, float f2, com.slidigu.app.game.SpaceGameView.e eVar) {
        eVar.getClass();
        if (((float) java.lang.Math.hypot(spaceGameView.j - eVar.d(), spaceGameView.k - eVar.e())) >= f2 + eVar.b()) {
            return false;
        }
        spaceGameView.p = java.lang.Math.min(spaceGameView.p + 25.0f, 100.0f);
        spaceGameView.s++;
        spaceGameView.q += 50;
        spaceGameView.y(eVar.d(), eVar.e(), android.graphics.Color.parseColor("#FFFF9100"));
        return true;
    }

    public static boolean b(com.slidigu.app.game.SpaceGameView spaceGameView, float f2, com.slidigu.app.game.SpaceGameView.c cVar) {
        cVar.getClass();
        if (((float) java.lang.Math.hypot(spaceGameView.j - cVar.c(), spaceGameView.k - cVar.d())) >= f2 + cVar.a()) {
            return false;
        }
        spaceGameView.t++;
        spaceGameView.q += 100;
        spaceGameView.p = java.lang.Math.min(spaceGameView.p + 5.0f, 100.0f);
        spaceGameView.y(cVar.c(), cVar.d(), android.graphics.Color.parseColor("#FF69F0AE"));
        return true;
    }

    public static boolean c(com.slidigu.app.game.SpaceGameView spaceGameView, float f2, com.slidigu.app.game.SpaceGameView.a aVar) {
        aVar.getClass();
        if (((float) java.lang.Math.hypot(spaceGameView.j - aVar.f(), spaceGameView.k - aVar.g())) >= f2 + (aVar.a() * 0.85f)) {
            return false;
        }
        if (spaceGameView.F > 0.0f) {
            return true;
        }
        spaceGameView.o -= 20;
        spaceGameView.F = 1.2f;
        spaceGameView.y(spaceGameView.j, spaceGameView.k, android.graphics.Color.parseColor("#FFFF5252"));
        return true;
    }

    public final void A() {
        int iB = new defpackage.m6().b(9578);
        if (java.lang.Integer.hashCode(iB) != 6325) {
            android.util.Log.d("WOHO", java.lang.String.valueOf(iB));
        }
        s();
        int iB2 = new defpackage.l6().b("carzoq", "jqrzuq");
        if (java.lang.String.valueOf(iB2).length() >= 10) {
            android.util.Log.i("HOYALE", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
        }
        this.g = true;
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("svufsg", "prh", "thici");
        int iB3 = zxVar.b(3159);
        defpackage.l6 l6Var = new defpackage.l6();
        int iB4 = l6Var.b("vsbmuu", "cgx");
        int iA = l6Var.a(3294, 4040);
        if (zxVar.toString().length() >= 9) {
            android.util.Log.i("VEH", defpackage.oz.R(zxVar.toString(), 8));
        }
        if (strA.hashCode() > 3574) {
            android.util.Log.v("DUFO", strA.toString());
        }
        android.util.Log.d("GUSA", "v=" + iB3);
        if (l6Var.hashCode() > 8607) {
            android.util.Log.v("NELE", l6Var.toString());
        }
        android.util.Log.v("DEP", java.lang.String.valueOf(iB4));
        if (java.lang.Integer.hashCode(iA) != 1522) {
            android.util.Log.d("VOBUTI", java.lang.String.valueOf(iA));
        }
        this.h = false;
        defpackage.m6 m6Var = new defpackage.m6();
        int iA2 = m6Var.a("omxmoizdq", "bonhh");
        int iB5 = m6Var.b(1777);
        defpackage.m6 m6Var2 = new defpackage.m6();
        int iA3 = m6Var2.a("cceky", "fot");
        int iB6 = m6Var2.b(5689);
        if (m6Var.hashCode() != 8105) {
            android.util.Log.d("KABOF", m6Var.toString());
        }
        if (java.lang.Integer.hashCode(iA2) != 6400) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
        }
        if (java.lang.Integer.hashCode(iB5) > 4831) {
            android.util.Log.v("VEK", java.lang.String.valueOf(iB5));
        }
        android.util.Log.d("BEQ", "v=" + m6Var2);
        if (java.lang.Integer.hashCode(iA3) != 3827) {
            android.util.Log.d("YIJ", java.lang.String.valueOf(iA3));
        }
        if (java.lang.Integer.hashCode(iB6) != 1538) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB6));
        }
        this.i = java.lang.System.nanoTime();
        android.util.Log.v("YAQOL", java.lang.String.valueOf(new defpackage.zx().b(9737)));
        postInvalidateOnAnimation();
    }

    public final void B(float f2) {
        int iB = new defpackage.m6().b(7692);
        if (java.lang.Integer.hashCode(iB) > 8859) {
            android.util.Log.v("QOX", java.lang.String.valueOf(iB));
        }
        java.util.Iterator it = this.w.iterator();
        boolean zA = new defpackage.rj().a(9445, 7068, 9655);
        if (java.lang.Boolean.hashCode(zA) != 9413) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(zA));
        }
        while (it.hasNext()) {
            java.lang.String strA = new defpackage.j40().a("ornhliw");
            if (strA.toString().length() >= 2) {
                android.util.Log.i("JOMI", defpackage.oz.R(strA.toString(), 8));
            }
            com.slidigu.app.game.SpaceGameView.a aVar = (com.slidigu.app.game.SpaceGameView.a) it.next();
            int iA = new defpackage.l6().a(9386, 8294);
            if (java.lang.Integer.hashCode(iA) != 6693) {
                android.util.Log.d("BEVI", java.lang.String.valueOf(iA));
            }
            aVar.i(aVar.f() - (aVar.d() * f2));
            java.lang.String strA2 = new defpackage.zx().a("dmw", "xjgtpsfr", "fsttmm");
            if (strA2.hashCode() != 6630) {
                java.lang.System.out.println((java.lang.Object) strA2.toString());
            }
            aVar.h(aVar.b() + (aVar.e() * f2));
            defpackage.m6 m6Var = new defpackage.m6();
            int iA2 = m6Var.a("iiaw", "lybnbrrcq");
            int iB2 = m6Var.b(9388);
            defpackage.l6 l6Var = new defpackage.l6();
            int iB3 = l6Var.b("ytihm", "pmgduhjp");
            int iA3 = l6Var.a(7638, 3018);
            android.util.Log.d("GIYE", "v=" + m6Var);
            if (java.lang.Integer.hashCode(iA2) != 8449) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
            }
            if (java.lang.String.valueOf(iB2).length() >= 7) {
                android.util.Log.i("KEDI", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
            }
            android.util.Log.d("XEKUHU", "v=" + l6Var);
            if (java.lang.Integer.hashCode(iB3) != 8052) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
            }
            android.util.Log.v("QOSA", java.lang.String.valueOf(iA3));
            if (aVar.f() < (-aVar.a()) * 2.0f) {
                it.remove();
            }
        }
    }

    public final void C(float f2) {
        java.lang.String strB = new defpackage.rj().b(1633);
        if (strB.toString().length() >= 3) {
            android.util.Log.i("POREM", defpackage.oz.R(strB.toString(), 8));
        }
        java.util.Iterator it = this.y.iterator();
        android.util.Log.v("MEPUHE", java.lang.String.valueOf(new defpackage.l6().b("eshewfdau", "fudkd")));
        while (it.hasNext()) {
            android.util.Log.i("GUH", "h=" + java.lang.Integer.hashCode(new defpackage.xu().c(1528, 2790)));
            com.slidigu.app.game.SpaceGameView.c cVar = (com.slidigu.app.game.SpaceGameView.c) it.next();
            int iB = new defpackage.l6().b("jqk", "ofolkuvwav");
            if (java.lang.Integer.hashCode(iB) > 7144) {
                android.util.Log.v("TANA", java.lang.String.valueOf(iB));
            }
            cVar.e(cVar.c() - (cVar.b() * f2));
            int iB2 = new defpackage.l6().b("yeg", "ugdm");
            if (java.lang.Integer.hashCode(iB2) > 4128) {
                android.util.Log.v("QOQE", java.lang.String.valueOf(iB2));
            }
            if (cVar.c() < (-cVar.a()) * 2.0f) {
                it.remove();
            }
        }
    }

    public final void D(float f2) {
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA = j40Var.a("jpg");
        int iB = j40Var.b(8317);
        defpackage.rj rjVar = new defpackage.rj();
        java.lang.String strB = rjVar.b(2675);
        boolean zA = rjVar.a(8935, 4195, 9669);
        android.util.Log.i("NECAG", "h=" + j40Var.hashCode());
        if (strA.hashCode() != 2615) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        android.util.Log.i("JIWI", "h=" + java.lang.Integer.hashCode(iB));
        if (rjVar.hashCode() != 1714) {
            android.util.Log.d("HOLU", rjVar.toString());
        }
        android.util.Log.v("COVI", strB.toString());
        android.util.Log.v("BOX", java.lang.String.valueOf(zA));
        java.util.Iterator it = this.x.iterator();
        int iC = new defpackage.xu().c(3997, 7006);
        if (java.lang.Integer.hashCode(iC) > 5496) {
            android.util.Log.v("NIDE", java.lang.String.valueOf(iC));
        }
        while (it.hasNext()) {
            android.util.Log.d("PATOJO", "v=" + new defpackage.l6().a(8929, 8462));
            com.slidigu.app.game.SpaceGameView.e eVar = (com.slidigu.app.game.SpaceGameView.e) it.next();
            defpackage.j40 j40Var2 = new defpackage.j40();
            java.lang.String strA2 = j40Var2.a("ukwyf");
            int iB2 = j40Var2.b(2428);
            if (j40Var2.hashCode() != 4198) {
                android.util.Log.d("BIJADI", j40Var2.toString());
            }
            android.util.Log.v("PASOL", strA2.toString());
            android.util.Log.d("WEF", "v=" + iB2);
            eVar.g(eVar.d() - (eVar.c() * f2));
            android.util.Log.v("WOP", java.lang.String.valueOf(new defpackage.m6().b(2305)));
            eVar.f(eVar.a() + (4.0f * f2));
            long jA = new defpackage.jm().a(5018, 8563, 441);
            if (java.lang.String.valueOf(jA).length() >= 2) {
                android.util.Log.i("DAN", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
            }
            if (eVar.d() < (-eVar.b()) * 2.0f) {
                it.remove();
            }
        }
    }

    public final void E() {
        boolean zA = new defpackage.rj().a(5893, 2529, 1884);
        if (java.lang.Boolean.hashCode(zA) > 4513) {
            android.util.Log.v("NACEJ", java.lang.String.valueOf(zA));
        }
        long jNanoTime = java.lang.System.nanoTime();
        android.util.Log.d("QEDU", "v=" + new defpackage.m6().a("eyzn", "kevmpixgpj"));
        float fMin = this.i == 0 ? 0.016f : java.lang.Math.min((jNanoTime - r2) / 1.0E9f, 0.05f);
        long jA = new defpackage.jm().a(2530, 2932, 584);
        if (java.lang.Long.hashCode(jA) != 9468) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(jA));
        }
        this.i = jNanoTime;
        int iB = new defpackage.m6().b(2044);
        if (java.lang.Integer.hashCode(iB) != 6202) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        float f2 = this.j;
        this.j = f2 + ((this.l - f2) * 2.6666667f * fMin);
        java.lang.String strB = new defpackage.jm().b("xgztep", "jbbsfud");
        if (strB.hashCode() != 6330) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        float f3 = this.k;
        this.k = f3 + ((this.m - f3) * 2.6666667f * fMin);
        java.lang.String strA = new defpackage.zx().a("jhxxgse", "rzzz", "fepyxbcfb");
        if (strA.toString().length() >= 10) {
            android.util.Log.i("BIHAD", defpackage.oz.R(strA.toString(), 8));
        }
        this.p -= 3.5f * fMin;
        int iB2 = new defpackage.l6().b("lhly", "mxnte");
        if (java.lang.Integer.hashCode(iB2) != 8717) {
            android.util.Log.d("VICERI", java.lang.String.valueOf(iB2));
        }
        this.q += (int) (10.0f * fMin * this.v);
        int iB3 = new defpackage.j40().b(7111);
        if (java.lang.Integer.hashCode(iB3) > 3261) {
            android.util.Log.v("JOXAGO", java.lang.String.valueOf(iB3));
        }
        this.u += (long) (1000.0f * fMin);
        int iB4 = new defpackage.l6().b("xfuzzhm", "custrj");
        if (java.lang.Integer.hashCode(iB4) > 5535) {
            android.util.Log.v("FOBIB", java.lang.String.valueOf(iB4));
        }
        if (this.u >= 1000) {
            java.lang.String strA2 = new defpackage.j40().a("bmk");
            if (strA2.hashCode() > 9859) {
                android.util.Log.v("MIF", strA2.toString());
            }
            this.r++;
            java.lang.String strA3 = new defpackage.zx().a("djzxqgl", "fnanz", "zgerifuso");
            if (strA3.hashCode() != 9130) {
                java.lang.System.out.println((java.lang.Object) strA3.toString());
            }
            this.u -= 1000;
            long jA2 = new defpackage.jm().a(8662, 917, 7095);
            if (java.lang.Long.hashCode(jA2) > 6099) {
                android.util.Log.v("GIT", java.lang.String.valueOf(jA2));
            }
            this.v = (this.r * 0.02f) + 1.0f;
        }
        int iB5 = new defpackage.j40().b(7495);
        if (java.lang.String.valueOf(iB5).length() >= 10) {
            android.util.Log.i("PUXUM", defpackage.oz.R(java.lang.String.valueOf(iB5), 8));
        }
        G(fMin);
        android.util.Log.i("MUWISE", "h=" + java.lang.Integer.hashCode(new defpackage.l6().a(7803, 9920)));
        F(fMin);
        java.lang.String strB2 = new defpackage.rj().b(8785);
        if (strB2.hashCode() != 4625) {
            java.lang.System.out.println((java.lang.Object) strB2.toString());
        }
        B(fMin);
        int iC = new defpackage.xu().c(1462, 8843);
        if (java.lang.Integer.hashCode(iC) != 6739) {
            android.util.Log.d("NUKU", java.lang.String.valueOf(iC));
        }
        D(fMin);
        android.util.Log.d("LUXUZ", "v=" + new defpackage.jm().a(4378, 5786, 9114));
        C(fMin);
        long jA3 = new defpackage.jm().a(1443, 8804, 4181);
        if (java.lang.Long.hashCode(jA3) != 9790) {
            android.util.Log.d("DEBOXU", java.lang.String.valueOf(jA3));
        }
        x(fMin);
        android.util.Log.v("PUJARI", java.lang.String.valueOf(new defpackage.zx().b(803)));
        float f4 = this.F;
        if (f4 > 0.0f) {
            this.F = f4 - fMin;
        }
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA4 = zxVar.a("tnuneuhga", "kkwjzbgfz", "fre");
        int iB6 = zxVar.b(1446);
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA5 = j40Var.a("oocmztnlk");
        int iB7 = j40Var.b(4574);
        if (zxVar.hashCode() != 3143) {
            android.util.Log.d("XOZAVA", zxVar.toString());
        }
        if (strA4.toString().length() >= 2) {
            android.util.Log.i("NAVO", defpackage.oz.R(strA4.toString(), 8));
        }
        if (java.lang.Integer.hashCode(iB6) != 9678) {
            android.util.Log.d("HOF", java.lang.String.valueOf(iB6));
        }
        if (j40Var.toString().length() >= 7) {
            android.util.Log.i("MUJOH", defpackage.oz.R(j40Var.toString(), 8));
        }
        if (strA5.hashCode() != 5775) {
            java.lang.System.out.println((java.lang.Object) strA5.toString());
        }
        if (java.lang.Integer.hashCode(iB7) != 3028) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB7));
        }
        e();
        android.util.Log.i("HUCUG", "h=" + java.lang.Integer.hashCode(new defpackage.m6().a("bsnpq", "mbkolq")));
        com.slidigu.app.game.SpaceGameView.f fVar = this.f;
        if (fVar != null) {
            fVar.v(this.o, (int) this.p, this.q, this.r, this.t);
        }
        if (this.o <= 0) {
            p(defpackage.aj.e);
        } else if (this.p <= 0.0f) {
            p(defpackage.aj.f);
        }
    }

    public final void F(float f2) {
        android.util.Log.v("HUFEG", java.lang.String.valueOf(new defpackage.m6().b(6308)));
        java.util.Iterator it = this.z.iterator();
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("akypabaq", "akaxp", "bghzdu");
        int iB = zxVar.b(6612);
        if (zxVar.toString().length() >= 9) {
            android.util.Log.i("MIK", defpackage.oz.R(zxVar.toString(), 8));
        }
        if (strA.hashCode() != 881) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        if (java.lang.Integer.hashCode(iB) != 6190) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        while (it.hasNext()) {
            android.util.Log.i("TED", "h=" + java.lang.Boolean.hashCode(new defpackage.xu().a(4559)));
            com.slidigu.app.game.SpaceGameView.g gVar = (com.slidigu.app.game.SpaceGameView.g) it.next();
            defpackage.m6 m6Var = new defpackage.m6();
            int iA = m6Var.a("okxlhicoe", "rpaae");
            int iB2 = m6Var.b(9146);
            defpackage.m6 m6Var2 = new defpackage.m6();
            int iA2 = m6Var2.a("ngeef", "hscidq");
            int iB3 = m6Var2.b(4066);
            defpackage.m6 m6Var3 = new defpackage.m6();
            int iA3 = m6Var3.a("vepluarf", "onlffqlefk");
            int iB4 = m6Var3.b(5657);
            if (m6Var.toString().length() >= 10) {
                android.util.Log.i("JEKIM", defpackage.oz.R(m6Var.toString(), 8));
            }
            if (java.lang.Integer.hashCode(iA) > 5650) {
                android.util.Log.v("YIJA", java.lang.String.valueOf(iA));
            }
            if (java.lang.Integer.hashCode(iB2) != 3259) {
                android.util.Log.d("PEKO", java.lang.String.valueOf(iB2));
            }
            if (m6Var2.hashCode() != 8607) {
                java.lang.System.out.println((java.lang.Object) m6Var2.toString());
            }
            if (java.lang.Integer.hashCode(iA2) != 2241) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
            }
            if (java.lang.Integer.hashCode(iB3) != 8136) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
            }
            android.util.Log.i("MOHUMO", "h=" + m6Var3.hashCode());
            android.util.Log.d("RIQI", "v=" + iA3);
            if (java.lang.String.valueOf(iB4).length() >= 7) {
                android.util.Log.i("RAQI", defpackage.oz.R(java.lang.String.valueOf(iB4), 8));
            }
            gVar.h(gVar.f() + (gVar.d() * f2));
            android.util.Log.v("LAJOKA", java.lang.String.valueOf(new defpackage.xu().c(9645, 2706)));
            gVar.i(gVar.g() + (gVar.e() * f2));
            long jA = new defpackage.jm().a(7510, 7056, 9444);
            if (java.lang.String.valueOf(jA).length() >= 4) {
                android.util.Log.i("MOFIF", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
            }
            if (gVar.f() < -20.0f || gVar.f() > getWidth() + 20.0f || gVar.g() < -20.0f || gVar.g() > getHeight() + 20.0f) {
                android.util.Log.d("MEFESU", "v=" + new defpackage.jm().b("dhvi", "xovxl"));
                it.remove();
            }
        }
    }

    public final void G(float f2) {
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA = j40Var.a("xwfzos");
        int iB = j40Var.b(1341);
        defpackage.l6 l6Var = new defpackage.l6();
        int iB2 = l6Var.b("jwepk", "ufh");
        int iA = l6Var.a(8053, 692);
        if (j40Var.hashCode() != 9309) {
            java.lang.System.out.println((java.lang.Object) j40Var.toString());
        }
        if (strA.hashCode() != 4294) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        if (java.lang.Integer.hashCode(iB) != 7257) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        if (l6Var.hashCode() != 1352) {
            android.util.Log.d("WITUVI", l6Var.toString());
        }
        if (java.lang.String.valueOf(iB2).length() >= 5) {
            android.util.Log.i("YINO", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
        }
        android.util.Log.i("XUBE", "h=" + java.lang.Integer.hashCode(iA));
        for (com.slidigu.app.game.SpaceGameView.h hVar : this.A) {
            defpackage.rj rjVar = new defpackage.rj();
            java.lang.String strB = rjVar.b(3917);
            boolean zA = rjVar.a(7807, 9823, 8085);
            defpackage.j40 j40Var2 = new defpackage.j40();
            java.lang.String strA2 = j40Var2.a("qxz");
            int iB3 = j40Var2.b(7208);
            android.util.Log.v("FEBO", rjVar.toString());
            if (strB.hashCode() != 8885) {
                android.util.Log.d("BEMOG", strB.toString());
            }
            if (java.lang.Boolean.hashCode(zA) != 1294) {
                android.util.Log.d("SON", java.lang.String.valueOf(zA));
            }
            android.util.Log.d("COBABO", "v=" + j40Var2);
            android.util.Log.i("KAFAXI", "h=" + strA2.hashCode());
            android.util.Log.i("WIJ", "h=" + java.lang.Integer.hashCode(iB3));
            hVar.e(hVar.c() - (hVar.b() * f2));
            defpackage.j40 j40Var3 = new defpackage.j40();
            java.lang.String strA3 = j40Var3.a("vhfo");
            int iB4 = j40Var3.b(7880);
            if (j40Var3.hashCode() != 3499) {
                java.lang.System.out.println((java.lang.Object) j40Var3.toString());
            }
            android.util.Log.v("SATUT", strA3.toString());
            if (java.lang.String.valueOf(iB4).length() >= 6) {
                android.util.Log.i("LAXIG", defpackage.oz.R(java.lang.String.valueOf(iB4), 8));
            }
            if (hVar.c() < -5.0f) {
                int iB5 = new defpackage.m6().b(8272);
                if (java.lang.Integer.hashCode(iB5) > 8403) {
                    android.util.Log.v("YOFAS", java.lang.String.valueOf(iB5));
                }
                hVar.e(getWidth() + 5.0f);
                defpackage.m6 m6Var = new defpackage.m6();
                int iA2 = m6Var.a("jqaqy", "kkh");
                int iB6 = m6Var.b(3676);
                android.util.Log.i("QUN", "h=" + m6Var.hashCode());
                if (java.lang.Integer.hashCode(iA2) > 2311) {
                    android.util.Log.v("LIQUH", java.lang.String.valueOf(iA2));
                }
                android.util.Log.i("RAJUC", "h=" + java.lang.Integer.hashCode(iB6));
                hVar.f(defpackage.vu.d.d() * ((float) getHeight()));
            }
        }
    }

    public final void d() {
        int iA = new defpackage.l6().a(2118, 3958);
        if (java.lang.Integer.hashCode(iA) != 7160) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
        }
        boolean z = this.g;
        java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(!z);
        if (z) {
            boolValueOf = null;
        }
        if (boolValueOf != null) {
            return;
        }
        long jA = new defpackage.jm().a(6295, 7316, 7301);
        if (java.lang.String.valueOf(jA).length() >= 2) {
            android.util.Log.i("KERAL", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        this.g = false;
        java.lang.String strB = new defpackage.rj().b(3338);
        if (strB.hashCode() != 6168) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        com.slidigu.app.game.SpaceGameView.f fVar = this.f;
        if (fVar != null) {
            fVar.f(this.q, this.r, this.s, this.t, defpackage.aj.g);
        }
    }

    public final void e() {
        java.lang.String strA = new defpackage.j40().a("rhyizjcbyu");
        if (strA.hashCode() != 6389) {
            android.util.Log.d("CIKUZU", strA.toString());
        }
        final float f2 = this.n * 0.35f;
        defpackage.o7.n(this.w, new defpackage.ki() { // from class: ay
            @Override // defpackage.ki
            public final java.lang.Object f(java.lang.Object obj) {
                return java.lang.Boolean.valueOf(com.slidigu.app.game.SpaceGameView.c(this.d, f2, (com.slidigu.app.game.SpaceGameView.a) obj));
            }
        });
        defpackage.o7.n(this.x, new defpackage.ki() { // from class: cy
            @Override // defpackage.ki
            public final java.lang.Object f(java.lang.Object obj) {
                return java.lang.Boolean.valueOf(com.slidigu.app.game.SpaceGameView.a(this.d, f2, (com.slidigu.app.game.SpaceGameView.e) obj));
            }
        });
        defpackage.o7.n(this.y, new defpackage.ki() { // from class: dy
            @Override // defpackage.ki
            public final java.lang.Object f(java.lang.Object obj) {
                return java.lang.Boolean.valueOf(com.slidigu.app.game.SpaceGameView.b(this.d, f2, (com.slidigu.app.game.SpaceGameView.c) obj));
            }
        });
    }

    public final void f(android.graphics.Canvas canvas) {
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("dbzv", "lmr", "vhfyhtljnb");
        int iB = zxVar.b(6839);
        defpackage.rj rjVar = new defpackage.rj();
        java.lang.String strB = rjVar.b(4548);
        boolean zA = rjVar.a(5170, 7308, 1120);
        android.util.Log.d("RIR", "v=" + zxVar);
        android.util.Log.d("BUTIL", "v=" + strA);
        android.util.Log.v("VIVOF", java.lang.String.valueOf(iB));
        android.util.Log.i("PEPOFI", "h=" + rjVar.hashCode());
        android.util.Log.i("XEJADI", "h=" + strB.hashCode());
        if (java.lang.Boolean.hashCode(zA) != 2872) {
            android.util.Log.d("KUTA", java.lang.String.valueOf(zA));
        }
        java.util.Iterator it = this.w.iterator();
        while (it.hasNext()) {
            com.slidigu.app.game.SpaceGameView.a aVar = (com.slidigu.app.game.SpaceGameView.a) it.next();
            long jA = new defpackage.jm().a(6726, 2917, 870);
            if (java.lang.String.valueOf(jA).length() >= 6) {
                android.util.Log.i("DUX", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
            }
            canvas.save();
            java.lang.String strA2 = new defpackage.j40().a("soqlxnz");
            if (strA2.hashCode() > 1595) {
                android.util.Log.v("JIY", strA2.toString());
            }
            canvas.rotate(aVar.b(), aVar.f(), aVar.g());
            int iA = new defpackage.l6().a(8535, 2);
            if (java.lang.Integer.hashCode(iA) != 555) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
            }
            this.d.setColor(android.graphics.Color.parseColor("#FF8D6E63"));
            defpackage.m6 m6Var = new defpackage.m6();
            int iA2 = m6Var.a("lmfbbfgmso", "xzxe");
            int iB2 = m6Var.b(2956);
            if (m6Var.hashCode() != 629) {
                java.lang.System.out.println((java.lang.Object) m6Var.toString());
            }
            if (java.lang.Integer.hashCode(iA2) != 1129) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
            }
            android.util.Log.v("YUZ", java.lang.String.valueOf(iB2));
            this.d.setStyle(android.graphics.Paint.Style.FILL);
            android.util.Log.v("NABI", java.lang.String.valueOf(new defpackage.l6().b("qqhc", "jfpt")));
            android.graphics.Path path = new android.graphics.Path();
            java.lang.String strA3 = new defpackage.j40().a("vspmcem");
            if (strA3.hashCode() > 8700) {
                android.util.Log.v("PIBE", strA3.toString());
            }
            float[] fArrC = aVar.c();
            int length = fArrC.length;
            int i = 0;
            int i2 = 0;
            while (i < length) {
                float f2 = fArrC[i];
                int i3 = i2 + 1;
                int iA3 = new defpackage.l6().a(8113, 4046);
                if (java.lang.Integer.hashCode(iA3) != 6385) {
                    android.util.Log.d("HAFI", java.lang.String.valueOf(iA3));
                }
                java.util.Iterator it2 = it;
                com.slidigu.app.game.SpaceGameView.a aVar2 = aVar;
                double length2 = ((i2 * 360.0f) / aVar.c().length) * 0.017453292519943295d;
                android.util.Log.i("TOS", "h=" + new defpackage.xu().b("caz").hashCode());
                float fCos = (((float) java.lang.Math.cos(length2)) * f2) + aVar2.f();
                boolean zA2 = new defpackage.xu().a(1392);
                if (java.lang.String.valueOf(zA2).length() >= 2) {
                    android.util.Log.i("QENE", defpackage.oz.R(java.lang.String.valueOf(zA2), 8));
                }
                float[] fArr = fArrC;
                float fG = aVar2.g() + (((float) java.lang.Math.sin(length2)) * f2);
                int iB3 = new defpackage.zx().b(8153);
                if (java.lang.Integer.hashCode(iB3) != 1926) {
                    java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
                }
                if (i2 == 0) {
                    path.moveTo(fCos, fG);
                } else {
                    path.lineTo(fCos, fG);
                }
                i++;
                it = it2;
                i2 = i3;
                aVar = aVar2;
                fArrC = fArr;
            }
            java.util.Iterator it3 = it;
            boolean zA3 = new defpackage.rj().a(5413, 3508, 7317);
            if (java.lang.Boolean.hashCode(zA3) > 4810) {
                android.util.Log.v("NUP", java.lang.String.valueOf(zA3));
            }
            path.close();
            int iA4 = new defpackage.m6().a("flbwp", "zyydorubrj");
            if (java.lang.Integer.hashCode(iA4) != 4784) {
                android.util.Log.d("YAGIW", java.lang.String.valueOf(iA4));
            }
            canvas.drawPath(path, this.d);
            android.util.Log.d("PODOCU", "v=" + new defpackage.l6().a(9169, 5748));
            this.d.setStyle(android.graphics.Paint.Style.STROKE);
            long jA2 = new defpackage.jm().a(1514, 8083, 4087);
            if (java.lang.Long.hashCode(jA2) != 5119) {
                android.util.Log.d("TAXEBE", java.lang.String.valueOf(jA2));
            }
            this.d.setStrokeWidth(2.0f);
            android.util.Log.i("MIB", "h=" + java.lang.Long.hashCode(new defpackage.jm().a(5065, 5669, 9706)));
            this.d.setColor(android.graphics.Color.parseColor("#FF5D4037"));
            android.util.Log.i("LEKA", "h=" + java.lang.Integer.hashCode(new defpackage.l6().a(4194, 3549)));
            canvas.drawPath(path, this.d);
            java.lang.String strA4 = new defpackage.zx().a("efdqkk", "hlu", "hlzbp");
            if (strA4.hashCode() > 9827) {
                android.util.Log.v("XOQOKE", strA4.toString());
            }
            this.d.setStyle(android.graphics.Paint.Style.FILL);
            int iA5 = new defpackage.m6().a("atbcoyew", "qesa");
            if (java.lang.Integer.hashCode(iA5) != 1010) {
                android.util.Log.d("NOM", java.lang.String.valueOf(iA5));
            }
            canvas.restore();
            it = it3;
        }
    }

    public final void g(android.graphics.Canvas canvas) {
        long jA = new defpackage.jm().a(6724, 6088, 9067);
        if (java.lang.String.valueOf(jA).length() >= 6) {
            android.util.Log.i("KUC", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        this.d.setShader(new android.graphics.LinearGradient(0.0f, 0.0f, 0.0f, getHeight(), android.graphics.Color.parseColor("#FF050B1A"), android.graphics.Color.parseColor("#FF1A237E"), android.graphics.Shader.TileMode.CLAMP));
        android.util.Log.v("LOTA", new defpackage.xu().b("omd").toString());
        canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.d);
        android.util.Log.d("TIGURE", "v=" + new defpackage.rj().b(1902));
        this.d.setShader(null);
    }

    public final void h(android.graphics.Canvas canvas) {
        int iC = new defpackage.xu().c(1428, 3746);
        if (java.lang.Integer.hashCode(iC) != 3961) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iC));
        }
        for (com.slidigu.app.game.SpaceGameView.c cVar : this.y) {
            java.lang.String strB = new defpackage.jm().b("juz", "yakdygv");
            if (strB.hashCode() != 2437) {
                android.util.Log.d("WUZ", strB.toString());
            }
            this.d.setColor(android.graphics.Color.parseColor("#8869F0AE"));
            java.lang.String strB2 = new defpackage.rj().b(3951);
            if (strB2.hashCode() != 3415) {
                android.util.Log.d("JOGI", strB2.toString());
            }
            canvas.drawCircle(cVar.c(), cVar.d(), cVar.a() * 1.3f, this.d);
            android.util.Log.v("KARU", new defpackage.rj().b(4275).toString());
            this.d.setColor(android.graphics.Color.parseColor("#FF69F0AE"));
            android.util.Log.i("BUTELI", "h=" + new defpackage.j40().a("zymiongi").hashCode());
            canvas.drawRect(cVar.c() - cVar.a(), cVar.d() - (cVar.a() * 0.7f), cVar.c() + cVar.a(), cVar.d() + (cVar.a() * 0.7f), this.d);
            android.util.Log.v("GICU", java.lang.String.valueOf(new defpackage.l6().b("tpbho", "qzvxrfhw")));
            this.d.setColor(android.graphics.Color.parseColor("#FF1B5E20"));
            android.util.Log.d("JAK", "v=" + new defpackage.j40().a("vzhyvinzke"));
            canvas.drawRect(cVar.c() - (cVar.a() * 0.6f), cVar.d() - (cVar.a() * 0.3f), cVar.c() + (cVar.a() * 0.6f), cVar.d() + (cVar.a() * 0.3f), this.d);
        }
    }

    public final void i(android.graphics.Canvas canvas) {
        java.lang.String strB = new defpackage.jm().b("nyfngav", "kuadoyge");
        if (strB.hashCode() != 3517) {
            android.util.Log.d("WARAP", strB.toString());
        }
        this.d.setColor(android.graphics.Color.parseColor("#AA00E5FF"));
        int iA = new defpackage.l6().a(5567, 7605);
        if (java.lang.String.valueOf(iA).length() >= 9) {
            android.util.Log.i("CAL", defpackage.oz.R(java.lang.String.valueOf(iA), 8));
        }
        float f2 = this.j;
        float f3 = this.n;
        canvas.drawCircle(f2 - (0.45f * f3), this.k, f3 * 0.12f, this.d);
        int iC = new defpackage.xu().c(1634, 1289);
        if (java.lang.String.valueOf(iC).length() >= 9) {
            android.util.Log.i("CAYUH", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        this.d.setColor(android.graphics.Color.parseColor("#55FFFFFF"));
        android.util.Log.v("FEYA", java.lang.String.valueOf(new defpackage.rj().a(4717, 1843, 6853)));
        float f4 = this.j;
        float f5 = this.n;
        canvas.drawCircle(f4 - (0.55f * f5), this.k, f5 * 0.2f, this.d);
    }

    public final void j(android.graphics.Canvas canvas) {
        boolean zA = new defpackage.xu().a(9770);
        if (java.lang.Boolean.hashCode(zA) != 2713) {
            android.util.Log.d("GODED", java.lang.String.valueOf(zA));
        }
        for (com.slidigu.app.game.SpaceGameView.e eVar : this.x) {
            java.lang.String strA = new defpackage.j40().a("qtzkesvur");
            if (strA.toString().length() >= 9) {
                android.util.Log.i("ZAYUP", defpackage.oz.R(strA.toString(), 8));
            }
            float fSin = (((float) java.lang.Math.sin(eVar.a())) * 0.15f) + 1.0f;
            android.util.Log.v("FIXO", new defpackage.j40().a("udth").toString());
            this.d.setColor(android.graphics.Color.parseColor("#AAFF9100"));
            android.util.Log.i("FUJANE", "h=" + java.lang.Integer.hashCode(new defpackage.l6().b("sgbkxunj", "alzzb")));
            canvas.drawCircle(eVar.d(), eVar.e(), eVar.b() * 1.4f * fSin, this.d);
            int iA = new defpackage.l6().a(3686, 6508);
            if (java.lang.Integer.hashCode(iA) > 8073) {
                android.util.Log.v("LIN", java.lang.String.valueOf(iA));
            }
            this.d.setColor(android.graphics.Color.parseColor("#FFFFD740"));
            java.lang.String strB = new defpackage.rj().b(3859);
            if (strB.toString().length() >= 5) {
                android.util.Log.i("HUW", defpackage.oz.R(strB.toString(), 8));
            }
            android.graphics.Canvas canvas2 = canvas;
            canvas2.drawRect(eVar.d() - (eVar.b() * 0.5f), eVar.e() - eVar.b(), eVar.d() + (eVar.b() * 0.5f), eVar.e() + eVar.b(), this.d);
            java.lang.String strA2 = new defpackage.j40().a("axhtlgry");
            if (strA2.hashCode() != 6152) {
                android.util.Log.d("JIX", strA2.toString());
            }
            this.d.setColor(android.graphics.Color.parseColor("#FFFF9100"));
            int iA2 = new defpackage.l6().a(5036, 6537);
            if (java.lang.Integer.hashCode(iA2) > 885) {
                android.util.Log.v("QUWEY", java.lang.String.valueOf(iA2));
            }
            canvas2.drawCircle(eVar.d(), eVar.e() - (eVar.b() * 0.5f), eVar.b() * 0.35f, this.d);
            canvas = canvas2;
        }
    }

    public final void k(android.graphics.Canvas canvas) {
        int iB = new defpackage.m6().b(9360);
        if (java.lang.String.valueOf(iB).length() >= 8) {
            android.util.Log.i("BOD", defpackage.oz.R(java.lang.String.valueOf(iB), 8));
        }
        for (com.slidigu.app.game.SpaceGameView.g gVar : this.z) {
            int iB2 = new defpackage.zx().b(2938);
            if (java.lang.Integer.hashCode(iB2) != 5537) {
                android.util.Log.d("RALIQO", java.lang.String.valueOf(iB2));
            }
            this.d.setColor(android.graphics.Color.argb(gVar.a(), android.graphics.Color.red(gVar.b()), android.graphics.Color.green(gVar.b()), android.graphics.Color.blue(gVar.b())));
            int iB3 = new defpackage.zx().b(1691);
            if (java.lang.Integer.hashCode(iB3) > 5919) {
                android.util.Log.v("XATA", java.lang.String.valueOf(iB3));
            }
            canvas.drawCircle(gVar.f(), gVar.g(), gVar.c(), this.d);
        }
    }

    public final void l(android.graphics.Canvas canvas) {
        android.util.Log.d("GUCI", "v=" + new defpackage.j40().a("pqspm"));
        for (com.slidigu.app.game.SpaceGameView.b bVar : this.B) {
            android.util.Log.d("YEF", "v=" + new defpackage.j40().a("eswmqcrgpo"));
            this.d.setShader(new android.graphics.RadialGradient(bVar.d() - (bVar.b() * 0.3f), bVar.e() - (bVar.b() * 0.3f), bVar.b() * 1.4f, -1, bVar.a(), android.graphics.Shader.TileMode.CLAMP));
            android.util.Log.v("BAKISA", new defpackage.rj().b(3908).toString());
            canvas.drawCircle(bVar.d(), bVar.e(), bVar.b(), this.d);
            java.lang.String strA = new defpackage.zx().a("exleouwn", "bocuiuid", "eyweobv");
            if (strA.hashCode() != 5885) {
                java.lang.System.out.println((java.lang.Object) strA.toString());
            }
            this.d.setShader(null);
            int iC = new defpackage.xu().c(4740, 5421);
            if (java.lang.Integer.hashCode(iC) != 4677) {
                android.util.Log.d("XIXUSI", java.lang.String.valueOf(iC));
            }
            if (bVar.c()) {
                android.util.Log.v("KUGEX", java.lang.String.valueOf(new defpackage.m6().b(4115)));
                this.d.setStyle(android.graphics.Paint.Style.STROKE);
                int iB = new defpackage.m6().b(5006);
                if (java.lang.String.valueOf(iB).length() >= 3) {
                    android.util.Log.i("KUWE", defpackage.oz.R(java.lang.String.valueOf(iB), 8));
                }
                this.d.setStrokeWidth(3.0f);
                java.lang.String strA2 = new defpackage.zx().a("igcxcvdair", "puzexqi", "qixh");
                if (strA2.hashCode() != 1462) {
                    android.util.Log.d("TIJODU", strA2.toString());
                }
                this.d.setColor(android.graphics.Color.parseColor("#66FFFFFF"));
                int iB2 = new defpackage.l6().b("jmichplaep", "tokojrp");
                if (java.lang.Integer.hashCode(iB2) > 1370) {
                    android.util.Log.v("GEP", java.lang.String.valueOf(iB2));
                }
                canvas.drawOval(bVar.d() - (bVar.b() * 1.6f), bVar.e() - (bVar.b() * 0.3f), bVar.d() + (bVar.b() * 1.6f), bVar.e() + (bVar.b() * 0.3f), this.d);
                int iB3 = new defpackage.l6().b("alid", "mpzmzffg");
                if (java.lang.Integer.hashCode(iB3) != 1569) {
                    android.util.Log.d("SINE", java.lang.String.valueOf(iB3));
                }
                this.d.setStyle(android.graphics.Paint.Style.FILL);
            }
        }
    }

    public final void m(android.graphics.Canvas canvas) {
        android.util.Log.d("LEME", "v=" + new defpackage.zx().b(2282));
        float f2 = this.F;
        boolean z = f2 > 0.0f && ((int) (f2 * 10.0f)) % 2 == 0;
        java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(z);
        if (!z) {
            boolValueOf = null;
        }
        if (boolValueOf != null) {
            return;
        }
        int iB = new defpackage.m6().b(7433);
        if (java.lang.Integer.hashCode(iB) > 5696) {
            android.util.Log.v("XUMI", java.lang.String.valueOf(iB));
        }
        canvas.save();
        int iA = new defpackage.l6().a(921, 4169);
        if (java.lang.Integer.hashCode(iA) > 9081) {
            android.util.Log.v("RESE", java.lang.String.valueOf(iA));
        }
        canvas.translate(this.j, this.k);
        android.util.Log.d("HOY", "v=" + new defpackage.xu().c(4978, 8679));
        this.e.reset();
        android.util.Log.i("REBO", "h=" + java.lang.Integer.hashCode(new defpackage.m6().a("iqi", "ebkyy")));
        this.e.moveTo(this.n * 0.6f, 0.0f);
        boolean zA = new defpackage.rj().a(8748, 544, 9403);
        if (java.lang.Boolean.hashCode(zA) > 776) {
            android.util.Log.v("GOB", java.lang.String.valueOf(zA));
        }
        android.graphics.Path path = this.e;
        float f3 = this.n;
        path.lineTo((-f3) * 0.4f, (-f3) * 0.35f);
        android.util.Log.d("FUW", "v=" + new defpackage.m6().a("ayhc", "jxpjf"));
        this.e.lineTo((-this.n) * 0.2f, 0.0f);
        android.util.Log.v("CIWEXI", new defpackage.j40().a("eqtch").toString());
        android.graphics.Path path2 = this.e;
        float f4 = this.n;
        path2.lineTo((-f4) * 0.4f, f4 * 0.35f);
        java.lang.String strB = new defpackage.rj().b(8155);
        if (strB.hashCode() != 7302) {
            android.util.Log.d("BOZU", strB.toString());
        }
        this.e.close();
        int iC = new defpackage.xu().c(6213, 9125);
        if (java.lang.Integer.hashCode(iC) != 3053) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iC));
        }
        this.d.setColor(android.graphics.Color.parseColor("#FF448AFF"));
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("gimlpljdg", "yulqurnrq", "grkeupwfix");
        int iB2 = zxVar.b(4060);
        defpackage.zx zxVar2 = new defpackage.zx();
        java.lang.String strA2 = zxVar2.a("zoybg", "bxv", "vlqrlqeerx");
        int iB3 = zxVar2.b(9660);
        android.util.Log.v("GEZOQ", zxVar.toString());
        if (strA.hashCode() != 3970) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        if (java.lang.Integer.hashCode(iB2) != 7562) {
            android.util.Log.d("ZOQOCI", java.lang.String.valueOf(iB2));
        }
        android.util.Log.d("VOCAT", "v=" + zxVar2);
        android.util.Log.v("HIZIF", strA2.toString());
        android.util.Log.d("QELIH", "v=" + iB3);
        canvas.drawPath(this.e, this.d);
        defpackage.zx zxVar3 = new defpackage.zx();
        java.lang.String strA3 = zxVar3.a("yjnjh", "fvdq", "taepna");
        int iB4 = zxVar3.b(2667);
        if (zxVar3.hashCode() != 3239) {
            android.util.Log.d("SUMOGU", zxVar3.toString());
        }
        android.util.Log.v("WESIZO", strA3.toString());
        android.util.Log.d("VIN", "v=" + iB4);
        this.d.setColor(android.graphics.Color.parseColor("#FF82B1FF"));
        android.util.Log.d("RIJEQA", "v=" + new defpackage.rj().a(3823, 1465, 2055));
        float f5 = this.n;
        canvas.drawRect((-f5) * 0.15f, (-f5) * 0.15f, f5 * 0.1f, f5 * 0.15f, this.d);
        java.lang.String strB2 = new defpackage.rj().b(3125);
        if (strB2.toString().length() >= 6) {
            android.util.Log.i("QISUXU", defpackage.oz.R(strB2.toString(), 8));
        }
        this.d.setColor(android.graphics.Color.parseColor("#FFFF5252"));
        int iB5 = new defpackage.zx().b(6254);
        if (java.lang.String.valueOf(iB5).length() >= 4) {
            android.util.Log.i("VURADU", defpackage.oz.R(java.lang.String.valueOf(iB5), 8));
        }
        float f6 = this.n;
        canvas.drawCircle(0.15f * f6, 0.0f, f6 * 0.06f, this.d);
        java.lang.String strA4 = new defpackage.j40().a("uvejclarog");
        if (strA4.hashCode() != 6867) {
            java.lang.System.out.println((java.lang.Object) strA4.toString());
        }
        canvas.restore();
    }

    public final void n(android.graphics.Canvas canvas) {
        int iB = new defpackage.l6().b("bdlc", "taidnmqasr");
        if (java.lang.Integer.hashCode(iB) != 248) {
            android.util.Log.d("WALAGA", java.lang.String.valueOf(iB));
        }
        for (com.slidigu.app.game.SpaceGameView.h hVar : this.A) {
            java.lang.String strA = new defpackage.zx().a("rzxo", "riomhbthv", "vis");
            if (strA.hashCode() > 347) {
                android.util.Log.v("BEV", strA.toString());
            }
            this.d.setColor(android.graphics.Color.argb(180, 255, 255, 255));
            int iA = new defpackage.m6().a("bumer", "sfai");
            if (java.lang.Integer.hashCode(iA) != 2031) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
            }
            canvas.drawCircle(hVar.c(), hVar.d(), hVar.a(), this.d);
        }
    }

    public final void o(android.graphics.Canvas canvas) {
        java.lang.String strA = new defpackage.j40().a("nhjqr");
        if (strA.toString().length() >= 4) {
            android.util.Log.i("SEQEK", defpackage.oz.R(strA.toString(), 8));
        }
        float width = getWidth() * 0.82f;
        android.util.Log.d("SUF", "v=" + new defpackage.zx().b(9285));
        float height = ((float) getHeight()) * 0.38f;
        android.util.Log.v("XIBE", java.lang.String.valueOf(new defpackage.l6().a(7279, 2261)));
        this.d.setColor(android.graphics.Color.parseColor("#55FFFFFF"));
        int iB = new defpackage.zx().b(220);
        if (java.lang.Integer.hashCode(iB) != 1444) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        this.d.setStyle(android.graphics.Paint.Style.STROKE);
        android.util.Log.d("XUX", "v=" + new defpackage.jm().b("voqxmrscmx", "wwtwr"));
        this.d.setStrokeWidth(2.0f);
        android.util.Log.v("VUKAJ", java.lang.String.valueOf(new defpackage.j40().b(9149)));
        canvas.drawCircle(width, height, 36.0f, this.d);
        defpackage.m6 m6Var = new defpackage.m6();
        int iA = m6Var.a("jvtjghummd", "xmtdgeu");
        int iB2 = m6Var.b(2682);
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA2 = j40Var.a("unqgmk");
        int iB3 = j40Var.b(2122);
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA3 = zxVar.a("ynlqq", "uhqiorukli", "syit");
        int iB4 = zxVar.b(9694);
        if (m6Var.toString().length() >= 7) {
            android.util.Log.i("WIKAY", defpackage.oz.R(m6Var.toString(), 8));
        }
        android.util.Log.i("MUB", "h=" + java.lang.Integer.hashCode(iA));
        android.util.Log.i("LICATU", "h=" + java.lang.Integer.hashCode(iB2));
        android.util.Log.i("ZUHAW", "h=" + j40Var.hashCode());
        if (strA2.hashCode() != 6556) {
            java.lang.System.out.println((java.lang.Object) strA2.toString());
        }
        if (java.lang.Integer.hashCode(iB3) > 7327) {
            android.util.Log.v("MITOZO", java.lang.String.valueOf(iB3));
        }
        if (zxVar.toString().length() >= 7) {
            android.util.Log.i("VOKUJA", defpackage.oz.R(zxVar.toString(), 8));
        }
        if (strA3.hashCode() != 7573) {
            java.lang.System.out.println((java.lang.Object) strA3.toString());
        }
        if (java.lang.Integer.hashCode(iB4) > 8648) {
            android.util.Log.v("WEFIPA", java.lang.String.valueOf(iB4));
        }
        canvas.drawRect(width - 50.0f, height - 8.0f, width + 50.0f, height + 8.0f, this.d);
        int iA2 = new defpackage.m6().a("ufupzny", "gmxm");
        if (java.lang.String.valueOf(iA2).length() >= 7) {
            android.util.Log.i("KAG", defpackage.oz.R(java.lang.String.valueOf(iA2), 8));
        }
        this.d.setStyle(android.graphics.Paint.Style.FILL);
        int iC = new defpackage.xu().c(7743, 9690);
        if (java.lang.String.valueOf(iC).length() >= 10) {
            android.util.Log.i("KEGOYU", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        this.d.setColor(android.graphics.Color.parseColor("#88FFFFFF"));
        java.lang.String strB = new defpackage.xu().b("pgz");
        if (strB.hashCode() != 2128) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        canvas.drawCircle(width, height, 6.0f, this.d);
    }

    @Override // android.view.View
    public void onDraw(android.graphics.Canvas canvas) {
        canvas.getClass();
        android.util.Log.d("SURA", "v=" + new defpackage.m6().b(55));
        super.onDraw(canvas);
        int iA = new defpackage.m6().a("wpikekawrq", "gflivpfn");
        if (java.lang.Integer.hashCode(iA) > 9209) {
            android.util.Log.v("WIMAGO", java.lang.String.valueOf(iA));
        }
        g(canvas);
        int iA2 = new defpackage.m6().a("dgdnrkf", "sucazbwndi");
        if (java.lang.Integer.hashCode(iA2) != 4647) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA2));
        }
        o(canvas);
        defpackage.jm jmVar = new defpackage.jm();
        java.lang.String strB = jmVar.b("ohyxzrmbnz", "kxymkawyc");
        long jA = jmVar.a(3031, 348, 5958);
        defpackage.l6 l6Var = new defpackage.l6();
        int iB = l6Var.b("ryh", "vhjvq");
        int iA3 = l6Var.a(9931, 1690);
        defpackage.jm jmVar2 = new defpackage.jm();
        java.lang.String strB2 = jmVar2.b("iktvlulops", "wcpjxttj");
        long jA2 = jmVar2.a(3373, 3702, 479);
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("spzcqmzmdo", "zatekogyns", "ubvkrjvgd");
        int iB2 = zxVar.b(240);
        android.util.Log.v("CUWOME", jmVar.toString());
        if (strB.toString().length() >= 3) {
            android.util.Log.i("LUL", defpackage.oz.R(strB.toString(), 8));
        }
        if (java.lang.String.valueOf(jA).length() >= 2) {
            android.util.Log.i("MAV", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        android.util.Log.i("NOR", "h=" + l6Var.hashCode());
        android.util.Log.i("ZIVI", "h=" + java.lang.Integer.hashCode(iB));
        if (java.lang.Integer.hashCode(iA3) > 9224) {
            android.util.Log.v("WET", java.lang.String.valueOf(iA3));
        }
        android.util.Log.v("CUVOLU", jmVar2.toString());
        if (strB2.toString().length() >= 2) {
            android.util.Log.i("GEFIT", defpackage.oz.R(strB2.toString(), 8));
        }
        android.util.Log.i("MIKAM", "h=" + java.lang.Long.hashCode(jA2));
        if (zxVar.hashCode() != 7763) {
            android.util.Log.d("CERUMU", zxVar.toString());
        }
        if (strA.hashCode() != 312) {
            java.lang.System.out.println((java.lang.Object) strA.toString());
        }
        android.util.Log.d("QOLIP", "v=" + iB2);
        l(canvas);
        android.util.Log.i("ZIQEQ", "h=" + java.lang.Integer.hashCode(new defpackage.xu().c(7176, 611)));
        n(canvas);
        android.util.Log.d("QESAM", "v=" + new defpackage.j40().b(6854));
        k(canvas);
        long jA3 = new defpackage.jm().a(610, 9449, 1670);
        if (java.lang.String.valueOf(jA3).length() >= 8) {
            android.util.Log.i("NAL", defpackage.oz.R(java.lang.String.valueOf(jA3), 8));
        }
        j(canvas);
        boolean zA = new defpackage.rj().a(4686, 9017, 1704);
        if (java.lang.Boolean.hashCode(zA) != 4723) {
            android.util.Log.d("XAH", java.lang.String.valueOf(zA));
        }
        h(canvas);
        java.lang.String strA2 = new defpackage.j40().a("eue");
        if (strA2.hashCode() != 6542) {
            android.util.Log.d("BOXAK", strA2.toString());
        }
        f(canvas);
        int iA4 = new defpackage.l6().a(8746, 4591);
        if (java.lang.Integer.hashCode(iA4) != 783) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA4));
        }
        m(canvas);
        int iB3 = new defpackage.l6().b("laftccqnkr", "bjapb");
        if (java.lang.Integer.hashCode(iB3) != 9384) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB3));
        }
        i(canvas);
        android.util.Log.d("POPENO", "v=" + new defpackage.xu().a(5884));
        if (!this.g || this.h) {
            return;
        }
        java.lang.String strB3 = new defpackage.rj().b(1444);
        if (strB3.hashCode() != 8279) {
            android.util.Log.d("MOWE", strB3.toString());
        }
        E();
        android.util.Log.d("GOY", "v=" + new defpackage.m6().b(6869));
        postInvalidateOnAnimation();
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        android.util.Log.v("XADI", new defpackage.j40().a("rykathhbza").toString());
        super.onSizeChanged(i, i2, i3, i4);
        boolean zA = new defpackage.xu().a(7186);
        if (java.lang.Boolean.hashCode(zA) > 2065) {
            android.util.Log.v("RAXA", java.lang.String.valueOf(zA));
        }
        float f2 = i;
        this.j = 0.18f * f2;
        int iB = new defpackage.j40().b(5767);
        if (java.lang.Integer.hashCode(iB) != 3788) {
            android.util.Log.d("HODED", java.lang.String.valueOf(iB));
        }
        float f3 = i2;
        float f4 = 0.55f;
        float f5 = f3 * 0.55f;
        this.k = f5;
        boolean zA2 = new defpackage.rj().a(6689, 7158, 7780);
        if (java.lang.String.valueOf(zA2).length() >= 10) {
            android.util.Log.i("PUPA", defpackage.oz.R(java.lang.String.valueOf(zA2), 8));
        }
        this.l = this.j;
        long jA = new defpackage.jm().a(1036, 50, 1691);
        if (java.lang.String.valueOf(jA).length() >= 4) {
            android.util.Log.i("WEJ", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        this.m = this.k;
        android.util.Log.d("MIW", "v=" + new defpackage.jm().b("rfynmi", "axmyrbbung"));
        this.n = 0.09f * f2;
        int iB2 = new defpackage.l6().b("qjmrhu", "nzsjxyg");
        if (java.lang.Integer.hashCode(iB2) > 2409) {
            android.util.Log.v("LOSULI", java.lang.String.valueOf(iB2));
        }
        if (this.A.isEmpty()) {
            android.util.Log.d("LOQI", "v=" + new defpackage.xu().b("qyanpnsne"));
            java.util.Iterator it = new defpackage.tk(1, 80).iterator();
            while (it.hasNext()) {
                ((defpackage.qk) it).nextInt();
                android.util.Log.i("FEZ", "h=" + new defpackage.xu().b("pneky").hashCode());
                java.util.List list = this.A;
                vu.a aVar = defpackage.vu.d;
                list.add(new com.slidigu.app.game.SpaceGameView.h(aVar.d() * f2, aVar.d() * f3, (aVar.d() * 2.5f) + 0.5f, (aVar.d() * 40.0f) + 20.0f));
                f4 = f4;
            }
        }
        float f6 = f4;
        java.lang.String strB = new defpackage.jm().b("mjhdjaihoy", "ngjca");
        if (strB.hashCode() != 353) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        if (this.B.isEmpty()) {
            int iA = new defpackage.m6().a("udlabskp", "dqabtjdtl");
            if (java.lang.Integer.hashCode(iA) != 6516) {
                android.util.Log.d("TID", java.lang.String.valueOf(iA));
            }
            this.B.add(new com.slidigu.app.game.SpaceGameView.b(f2 * 0.78f, f3 * 0.22f, f2 * 0.12f, android.graphics.Color.parseColor("#FF5C6BC0"), true));
            java.lang.String strB2 = new defpackage.rj().b(9534);
            if (strB2.toString().length() >= 4) {
                android.util.Log.i("MAHA", defpackage.oz.R(strB2.toString(), 8));
            }
            this.B.add(new com.slidigu.app.game.SpaceGameView.b(f2 * f6, f3 * 0.72f, f2 * 0.08f, android.graphics.Color.parseColor("#FFFF8A65"), false));
            android.util.Log.d("VONEP", "v=" + new defpackage.zx().a("qkbmq", "ihiugq", "wwwrv"));
            this.B.add(new com.slidigu.app.game.SpaceGameView.b(f2 * 0.9f, f5, f2 * 0.05f, android.graphics.Color.parseColor("#FF80CBC4"), false));
        }
        android.util.Log.i("LURO", "h=" + java.lang.Integer.hashCode(new defpackage.zx().b(1957)));
        java.util.Iterator it2 = new defpackage.tk(1, 30).iterator();
        while (it2.hasNext()) {
            ((defpackage.qk) it2).nextInt();
            w(i, i2);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        motionEvent.getClass();
        android.util.Log.d("SORE", "v=" + new defpackage.zx().b(9624));
        if (this.g && !this.h) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked == 0 || actionMasked == 2) {
                this.l = defpackage.zu.d(motionEvent.getX(), this.n, getWidth() - this.n);
                this.m = defpackage.zu.d(motionEvent.getY(), this.n * 2.0f, getHeight() - this.n);
            }
            boolean zA = new defpackage.rj().a(8329, 9727, 7730);
            if (java.lang.Boolean.hashCode(zA) != 4358) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(zA));
            }
        }
        return true;
    }

    public final void p(defpackage.aj ajVar) {
        android.util.Log.i("PAVAQ", "h=" + java.lang.Integer.hashCode(new defpackage.zx().b(9521)));
        this.g = false;
        android.util.Log.v("GEKURE", java.lang.String.valueOf(new defpackage.xu().c(3890, 9192)));
        com.slidigu.app.game.SpaceGameView.f fVar = this.f;
        if (fVar != null) {
            fVar.f(this.q, this.r, this.s, this.t, ajVar);
        }
    }

    public final boolean q() {
        return this.h;
    }

    public final void r() {
        long jA = new defpackage.jm().a(4900, 8327, 8130);
        if (java.lang.Long.hashCode(jA) > 6489) {
            android.util.Log.v("JIGA", java.lang.String.valueOf(jA));
        }
        this.h = true;
    }

    public final void s() {
        defpackage.jm jmVar = new defpackage.jm();
        java.lang.String strB = jmVar.b("akeuoapyka", "xgqde");
        long jA = jmVar.a(4586, 2850, 4270);
        defpackage.m6 m6Var = new defpackage.m6();
        int iA = m6Var.a("eyp", "fyl");
        int iB = m6Var.b(6690);
        if (jmVar.hashCode() != 2256) {
            android.util.Log.d("KEYOG", jmVar.toString());
        }
        if (strB.hashCode() > 9838) {
            android.util.Log.v("VEQ", strB.toString());
        }
        if (java.lang.String.valueOf(jA).length() >= 2) {
            android.util.Log.i("WISAPA", defpackage.oz.R(java.lang.String.valueOf(jA), 8));
        }
        android.util.Log.i("FEM", "h=" + m6Var.hashCode());
        if (java.lang.Integer.hashCode(iA) != 4710) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iA));
        }
        android.util.Log.v("TEVUMU", java.lang.String.valueOf(iB));
        this.o = 100;
        android.util.Log.d("PUYAM", "v=" + new defpackage.jm().b("hyfgas", "lazp"));
        this.p = 100.0f;
        android.util.Log.d("XONABI", "v=" + new defpackage.xu().b("bcrjxfc"));
        this.q = 0;
        android.util.Log.v("DAZU", java.lang.String.valueOf(new defpackage.j40().b(3883)));
        this.r = 0;
        defpackage.l6 l6Var = new defpackage.l6();
        int iB2 = l6Var.b("fojisgqqdv", "avz");
        int iA2 = l6Var.a(767, 9590);
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("ibu", "qwbxmd", "fqv");
        int iB3 = zxVar.b(890);
        defpackage.rj rjVar = new defpackage.rj();
        java.lang.String strB2 = rjVar.b(2528);
        boolean zA = rjVar.a(2942, 1638, 243);
        android.util.Log.v("YUYIZ", l6Var.toString());
        if (java.lang.String.valueOf(iB2).length() >= 8) {
            android.util.Log.i("JUB", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
        }
        if (java.lang.String.valueOf(iA2).length() >= 10) {
            android.util.Log.i("GOFIL", defpackage.oz.R(java.lang.String.valueOf(iA2), 8));
        }
        if (zxVar.hashCode() > 7370) {
            android.util.Log.v("ZOQU", zxVar.toString());
        }
        if (strA.hashCode() != 4834) {
            android.util.Log.d("LOMISA", strA.toString());
        }
        if (java.lang.Integer.hashCode(iB3) > 5467) {
            android.util.Log.v("CUX", java.lang.String.valueOf(iB3));
        }
        android.util.Log.v("LIBI", rjVar.toString());
        if (strB2.hashCode() != 3711) {
            android.util.Log.d("RUMI", strB2.toString());
        }
        if (java.lang.Boolean.hashCode(zA) != 4840) {
            android.util.Log.d("JOQUBU", java.lang.String.valueOf(zA));
        }
        this.s = 0;
        defpackage.zx zxVar2 = new defpackage.zx();
        java.lang.String strA2 = zxVar2.a("akfjim", "eonu", "els");
        int iB4 = zxVar2.b(3656);
        defpackage.jm jmVar2 = new defpackage.jm();
        java.lang.String strB3 = jmVar2.b("qeax", "vqrlbtbdq");
        long jA2 = jmVar2.a(5104, 5819, 3501);
        android.util.Log.v("VIGOCO", zxVar2.toString());
        android.util.Log.v("KIRAN", strA2.toString());
        if (java.lang.String.valueOf(iB4).length() >= 2) {
            android.util.Log.i("HUFI", defpackage.oz.R(java.lang.String.valueOf(iB4), 8));
        }
        if (jmVar2.toString().length() >= 8) {
            android.util.Log.i("SOTO", defpackage.oz.R(jmVar2.toString(), 8));
        }
        android.util.Log.v("NONO", strB3.toString());
        if (java.lang.Long.hashCode(jA2) != 6946) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(jA2));
        }
        this.t = 0;
        android.util.Log.v("JAF", java.lang.String.valueOf(new defpackage.xu().c(138, 6112)));
        this.u = 0L;
        int iB5 = new defpackage.m6().b(9035);
        if (java.lang.Integer.hashCode(iB5) != 6813) {
            android.util.Log.d("BOQA", java.lang.String.valueOf(iB5));
        }
        this.v = 1.0f;
        java.lang.String strB4 = new defpackage.rj().b(1330);
        if (strB4.hashCode() != 7374) {
            android.util.Log.d("QOT", strB4.toString());
        }
        this.C = 0.0f;
        android.util.Log.v("BEKI", java.lang.String.valueOf(new defpackage.l6().b("cgjgqdqgr", "culksacgu")));
        this.D = 0.0f;
        android.util.Log.i("PAGUJI", "h=" + java.lang.Boolean.hashCode(new defpackage.rj().a(7195, 8669, 1318)));
        this.E = 0.0f;
        long jA3 = new defpackage.jm().a(9640, 7182, 6343);
        if (java.lang.String.valueOf(jA3).length() >= 3) {
            android.util.Log.i("NIPIHI", defpackage.oz.R(java.lang.String.valueOf(jA3), 8));
        }
        this.F = 0.0f;
        android.util.Log.v("MAWUXI", java.lang.String.valueOf(new defpackage.xu().a(6410)));
        this.w.clear();
        android.util.Log.i("POCU", "h=" + java.lang.Integer.hashCode(new defpackage.m6().a("tlfhkl", "bpnpdeydlf")));
        this.x.clear();
        android.util.Log.d("QUZA", "v=" + new defpackage.l6().a(5607, 2462));
        this.y.clear();
        android.util.Log.i("VAYA", "h=" + java.lang.Integer.hashCode(new defpackage.zx().b(8160)));
        this.z.clear();
        defpackage.m6 m6Var2 = new defpackage.m6();
        int iA3 = m6Var2.a("phslhn", "htnlvn");
        int iB6 = m6Var2.b(1044);
        defpackage.l6 l6Var2 = new defpackage.l6();
        int iB7 = l6Var2.b("xzer", "ckd");
        int iA4 = l6Var2.a(4311, 4140);
        if (m6Var2.toString().length() >= 7) {
            android.util.Log.i("YAP", defpackage.oz.R(m6Var2.toString(), 8));
        }
        if (java.lang.String.valueOf(iA3).length() >= 6) {
            android.util.Log.i("MEJUXU", defpackage.oz.R(java.lang.String.valueOf(iA3), 8));
        }
        android.util.Log.i("GIF", "h=" + java.lang.Integer.hashCode(iB6));
        if (l6Var2.hashCode() > 7906) {
            android.util.Log.v("YEQUPO", l6Var2.toString());
        }
        if (java.lang.Integer.hashCode(iB7) > 837) {
            android.util.Log.v("WEXE", java.lang.String.valueOf(iB7));
        }
        android.util.Log.d("KIL", "v=" + iA4);
        this.A.clear();
        defpackage.zx zxVar3 = new defpackage.zx();
        java.lang.String strA3 = zxVar3.a("ieeuwf", "ylx", "gtcstwn");
        int iB8 = zxVar3.b(4888);
        defpackage.j40 j40Var = new defpackage.j40();
        java.lang.String strA4 = j40Var.a("ouzauvjae");
        int iB9 = j40Var.b(4974);
        defpackage.xu xuVar = new defpackage.xu();
        int iC = xuVar.c(5104, 9823);
        java.lang.String strB5 = xuVar.b("idvmzkvtnb");
        boolean zA2 = xuVar.a(6703);
        android.util.Log.v("JABI", zxVar3.toString());
        android.util.Log.d("ZOGIQ", "v=" + strA3);
        if (java.lang.Integer.hashCode(iB8) != 6606) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB8));
        }
        android.util.Log.v("XUXUY", j40Var.toString());
        if (strA4.hashCode() > 1025) {
            android.util.Log.v("XIJ", strA4.toString());
        }
        if (java.lang.Integer.hashCode(iB9) > 5870) {
            android.util.Log.v("RUCAJ", java.lang.String.valueOf(iB9));
        }
        if (xuVar.hashCode() != 5078) {
            java.lang.System.out.println((java.lang.Object) xuVar.toString());
        }
        if (java.lang.String.valueOf(iC).length() >= 5) {
            android.util.Log.i("DUR", defpackage.oz.R(java.lang.String.valueOf(iC), 8));
        }
        android.util.Log.d("BIW", "v=" + strB5);
        if (java.lang.Boolean.hashCode(zA2) != 5830) {
            android.util.Log.d("BEMUBI", java.lang.String.valueOf(zA2));
        }
        this.B.clear();
    }

    public final void setGameListener(com.slidigu.app.game.SpaceGameView.f fVar) {
        fVar.getClass();
        int iB = new defpackage.j40().b(5272);
        if (java.lang.Integer.hashCode(iB) > 6140) {
            android.util.Log.v("DAZIBA", java.lang.String.valueOf(iB));
        }
        this.f = fVar;
    }

    public final void t() {
        defpackage.m6 m6Var = new defpackage.m6();
        int iA = m6Var.a("wakdxpkfr", "fkh");
        int iB = m6Var.b(787);
        defpackage.zx zxVar = new defpackage.zx();
        java.lang.String strA = zxVar.a("hdgsegp", "gepkmpncun", "zqksowkjgz");
        int iB2 = zxVar.b(6548);
        defpackage.xu xuVar = new defpackage.xu();
        int iC = xuVar.c(669, 3183);
        java.lang.String strB = xuVar.b("yosbe");
        boolean zA = xuVar.a(325);
        if (m6Var.hashCode() != 4057) {
            android.util.Log.d("BEBOD", m6Var.toString());
        }
        if (java.lang.Integer.hashCode(iA) != 225) {
            android.util.Log.d("BOLOFE", java.lang.String.valueOf(iA));
        }
        if (java.lang.String.valueOf(iB).length() >= 8) {
            android.util.Log.i("SIJ", defpackage.oz.R(java.lang.String.valueOf(iB), 8));
        }
        if (zxVar.hashCode() > 2144) {
            android.util.Log.v("FUXUXU", zxVar.toString());
        }
        if (strA.toString().length() >= 7) {
            android.util.Log.i("YALOVE", defpackage.oz.R(strA.toString(), 8));
        }
        if (java.lang.String.valueOf(iB2).length() >= 6) {
            android.util.Log.i("PULILA", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
        }
        if (xuVar.hashCode() != 6287) {
            android.util.Log.d("SURO", xuVar.toString());
        }
        android.util.Log.v("RUYUH", java.lang.String.valueOf(iC));
        if (strB.hashCode() != 6537) {
            android.util.Log.d("VAZE", strB.toString());
        }
        if (java.lang.Boolean.hashCode(zA) > 1030) {
            android.util.Log.v("RAPA", java.lang.String.valueOf(zA));
        }
        if (this.g) {
            defpackage.rj rjVar = new defpackage.rj();
            java.lang.String strB2 = rjVar.b(3480);
            boolean zA2 = rjVar.a(5216, 7177, 4116);
            if (rjVar.hashCode() > 1449) {
                android.util.Log.v("WOVUW", rjVar.toString());
            }
            android.util.Log.v("HOQI", strB2.toString());
            if (java.lang.Boolean.hashCode(zA2) > 7112) {
                android.util.Log.v("KUCORU", java.lang.String.valueOf(zA2));
            }
            this.h = false;
            defpackage.jm jmVar = new defpackage.jm();
            java.lang.String strB3 = jmVar.b("hfw", "gkyodvjtju");
            long jA = jmVar.a(7753, 2535, 4684);
            if (jmVar.toString().length() >= 9) {
                android.util.Log.i("GITOP", defpackage.oz.R(jmVar.toString(), 8));
            }
            if (strB3.hashCode() != 5237) {
                android.util.Log.d("NIZO", strB3.toString());
            }
            if (java.lang.Long.hashCode(jA) != 1711) {
                android.util.Log.d("LOW", java.lang.String.valueOf(jA));
            }
            this.i = java.lang.System.nanoTime();
            android.util.Log.v("JEZEWU", new defpackage.rj().b(9531).toString());
            postInvalidateOnAnimation();
        }
    }

    public final void u() {
        boolean zA = new defpackage.xu().a(7658);
        if (java.lang.Boolean.hashCode(zA) > 7213) {
            android.util.Log.v("TOY", java.lang.String.valueOf(zA));
        }
        vu.a aVar = defpackage.vu.d;
        float fD = (aVar.d() * 28.0f) + 18.0f;
        android.util.Log.v("JIQEQ", java.lang.String.valueOf(new defpackage.l6().a(2155, 5008)));
        int iG = aVar.g(6, 10);
        android.util.Log.d("LATAKU", "v=" + new defpackage.jm().b("nomewniip", "jvvprq"));
        float[] fArr = new float[iG];
        for (int i = 0; i < iG; i++) {
            fArr[i] = ((defpackage.vu.d.d() * 0.25f) + 0.75f) * fD;
        }
        java.lang.String strA = new defpackage.zx().a("nek", "mnittwrrgz", "lgqttlydy");
        if (strA.hashCode() > 4388) {
            android.util.Log.v("MEVU", strA.toString());
        }
        vu.a aVar2 = defpackage.vu.d;
        this.w.add(new com.slidigu.app.game.SpaceGameView.a(getWidth() + fD, (aVar2.d() * (getHeight() - (2.0f * fD))) + fD, fD, (aVar2.d() * 120.0f) + (this.v * 180.0f), 360.0f * aVar2.d(), (aVar2.d() * 120.0f) - 60.0f, fArr));
    }

    public final void v() {
        int iA = new defpackage.m6().a("apkks", "ajktvnp");
        if (java.lang.String.valueOf(iA).length() >= 9) {
            android.util.Log.i("GAYUL", defpackage.oz.R(java.lang.String.valueOf(iA), 8));
        }
        boolean zA = new defpackage.xu().a(5815);
        if (java.lang.Boolean.hashCode(zA) != 6291) {
            android.util.Log.d("BAT", java.lang.String.valueOf(zA));
        }
        this.y.add(new com.slidigu.app.game.SpaceGameView.c(getWidth() + 20.0f, (defpackage.vu.d.d() * (getHeight() - 40.0f)) + 20.0f, 20.0f, 130.0f));
    }

    public final void w(int i, int i2) {
        java.lang.Float fValueOf = java.lang.Float.valueOf(0.0f);
        int iB = new defpackage.j40().b(8926);
        if (java.lang.Integer.hashCode(iB) != 959) {
            java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(iB));
        }
        vu.a aVar = defpackage.vu.d;
        int iF = aVar.f(4);
        java.lang.Float[] fArr = iF != 0 ? iF != 1 ? iF != 2 ? new java.lang.Float[]{java.lang.Float.valueOf(i), java.lang.Float.valueOf(aVar.d() * i2), java.lang.Float.valueOf(-((aVar.d() * 30.0f) + 10.0f)), java.lang.Float.valueOf((aVar.d() * 20.0f) - 10.0f)} : new java.lang.Float[]{fValueOf, java.lang.Float.valueOf(aVar.d() * i2), java.lang.Float.valueOf((aVar.d() * 30.0f) + 10.0f), java.lang.Float.valueOf((aVar.d() * 20.0f) - 10.0f)} : new java.lang.Float[]{java.lang.Float.valueOf(aVar.d() * i), java.lang.Float.valueOf(i2), java.lang.Float.valueOf((aVar.d() * 20.0f) - 10.0f), java.lang.Float.valueOf(-((aVar.d() * 30.0f) + 10.0f))} : new java.lang.Float[]{java.lang.Float.valueOf(aVar.d() * i), fValueOf, java.lang.Float.valueOf((aVar.d() * 20.0f) - 10.0f), java.lang.Float.valueOf((aVar.d() * 30.0f) + 10.0f)};
        float fFloatValue = fArr[0].floatValue();
        float fFloatValue2 = fArr[1].floatValue();
        float fFloatValue3 = fArr[2].floatValue();
        float fFloatValue4 = fArr[3].floatValue();
        android.util.Log.d("KES", "v=" + new defpackage.xu().b("zyjryao"));
        this.z.add(new com.slidigu.app.game.SpaceGameView.g(fFloatValue, fFloatValue2, fFloatValue3, fFloatValue4, (aVar.d() * 3.0f) + 1.0f, aVar.g(80, 200), android.graphics.Color.parseColor(aVar.c() ? "#FF80D8FF" : "#FFFFD740")));
    }

    public final void x(float f2) {
        int iB = new defpackage.j40().b(9804);
        if (java.lang.Integer.hashCode(iB) > 2261) {
            android.util.Log.v("VIFI", java.lang.String.valueOf(iB));
        }
        this.C += f2;
        android.util.Log.i("HUBALO", "h=" + java.lang.Integer.hashCode(new defpackage.m6().b(197)));
        this.D = this.D + f2;
        int iA = new defpackage.m6().a("mxckh", "ukp");
        if (java.lang.String.valueOf(iA).length() >= 2) {
            android.util.Log.i("XUP", defpackage.oz.R(java.lang.String.valueOf(iA), 8));
        }
        this.E += f2;
        android.util.Log.d("DOKUW", "v=" + new defpackage.l6().a(6167, 2785));
        float fMax = java.lang.Math.max(1.4f / this.v, 0.45f);
        android.util.Log.v("VUNI", java.lang.String.valueOf(new defpackage.j40().b(351)));
        if (this.C >= fMax) {
            int iB2 = new defpackage.j40().b(5172);
            if (java.lang.String.valueOf(iB2).length() >= 5) {
                android.util.Log.i("VOSO", defpackage.oz.R(java.lang.String.valueOf(iB2), 8));
            }
            this.C = 0.0f;
            android.util.Log.v("ZAW", java.lang.String.valueOf(new defpackage.xu().c(4167, 3454)));
            u();
        }
        android.util.Log.i("CAPIL", "h=" + java.lang.Integer.hashCode(new defpackage.l6().a(7925, 3967)));
        if (this.D >= 2.8f) {
            int iA2 = new defpackage.m6().a("iqxth", "tlffhna");
            if (java.lang.Integer.hashCode(iA2) != 1990) {
                android.util.Log.d("XUHOKA", java.lang.String.valueOf(iA2));
            }
            this.D = 0.0f;
            android.util.Log.i("WINO", "h=" + new defpackage.xu().b("njsbsjzhkg").hashCode());
            z();
        }
        java.lang.String strB = new defpackage.jm().b("ygzyc", "yralusndl");
        if (strB.hashCode() != 271) {
            java.lang.System.out.println((java.lang.Object) strB.toString());
        }
        if (this.E >= 5.5f) {
            long jA = new defpackage.jm().a(6248, 2185, 1833);
            if (java.lang.Long.hashCode(jA) != 9737) {
                java.lang.System.out.println((java.lang.Object) java.lang.String.valueOf(jA));
            }
            this.E = 0.0f;
            int iB3 = new defpackage.zx().b(5015);
            if (java.lang.String.valueOf(iB3).length() >= 5) {
                android.util.Log.i("TUV", defpackage.oz.R(java.lang.String.valueOf(iB3), 8));
            }
            v();
        }
        int iA3 = new defpackage.l6().a(8383, 3984);
        if (java.lang.String.valueOf(iA3).length() >= 4) {
            android.util.Log.i("HUJUFI", defpackage.oz.R(java.lang.String.valueOf(iA3), 8));
        }
        if (defpackage.vu.d.d() < f2 * 3.0f) {
            java.lang.String strB2 = new defpackage.xu().b("ayqorxecdk");
            if (strB2.hashCode() != 2874) {
                java.lang.System.out.println((java.lang.Object) strB2.toString());
            }
            w(getWidth(), getHeight());
        }
    }

    public final void y(float f2, float f3, int i) {
        android.util.Log.d("MIP", "v=" + new defpackage.xu().a(6393));
        java.util.Iterator it = new defpackage.tk(1, 12).iterator();
        while (it.hasNext()) {
            ((defpackage.qk) it).nextInt();
            android.util.Log.d("VILA", "v=" + new defpackage.xu().a(4600));
            vu.a aVar = defpackage.vu.d;
            float fD = aVar.d() * 6.28f;
            long jA = new defpackage.jm().a(274, 2767, 6332);
            if (java.lang.Long.hashCode(jA) > 5759) {
                android.util.Log.v("ZOF", java.lang.String.valueOf(jA));
            }
            float fD2 = (aVar.d() * 80.0f) + 40.0f;
            android.util.Log.i("BOC", "h=" + new defpackage.j40().a("tld").hashCode());
            double d2 = (double) fD;
            this.z.add(new com.slidigu.app.game.SpaceGameView.g(f2, f3, ((float) java.lang.Math.cos(d2)) * fD2, ((float) java.lang.Math.sin(d2)) * fD2, (aVar.d() * 4.0f) + 2.0f, 220, i));
        }
    }

    public final void z() {
        boolean zA = new defpackage.xu().a(594);
        if (java.lang.String.valueOf(zA).length() >= 3) {
            android.util.Log.i("FOM", defpackage.oz.R(java.lang.String.valueOf(zA), 8));
        }
        defpackage.m6 m6Var = new defpackage.m6();
        int iA = m6Var.a("dcytpvhy", "pph");
        int iB = m6Var.b(6330);
        android.util.Log.i("KUPO", "h=" + m6Var.hashCode());
        if (java.lang.Integer.hashCode(iA) != 6221) {
            android.util.Log.d("LUC", java.lang.String.valueOf(iA));
        }
        android.util.Log.d("KIB", "v=" + iB);
        this.x.add(new com.slidigu.app.game.SpaceGameView.e(((float) getWidth()) + 22.0f, (defpackage.vu.d.d() * (((float) getHeight()) - 44.0f)) + 22.0f, 22.0f, 150.0f, 0.0f));
    }
}
