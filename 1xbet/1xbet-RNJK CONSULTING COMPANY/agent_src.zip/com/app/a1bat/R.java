package com.app.a1bat;

/* loaded from: classes3.dex */
public final class R {

    public static final class color {
        public static int black = 0x7f050021;
        public static int ic_launcher_background = 0x7f050036;
        public static int purple_200 = 0x7f05004d;
        public static int purple_500 = 0x7f05004e;
        public static int purple_700 = 0x7f05004f;
        public static int teal_200 = 0x7f05005c;
        public static int teal_700 = 0x7f05005d;
        public static int white = 0x7f050062;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher_background = 0x7f07005e;
        public static int ic_launcher_foreground = 0x7f07005f;
        public static int land = 0x7f070060;
        public static int prize_1 = 0x7f07006e;
        public static int prize_2 = 0x7f07006f;
        public static int star_selected = 0x7f070070;
        public static int star_unselected = 0x7f070071;

        private drawable() {
        }
    }

    public static final class font {
        public static int poppins_light = 0x7f080000;
        public static int poppins_regular = 0x7f080001;
        public static int poppins_semibold = 0x7f080002;

        private font() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f0d0000;
        public static int ic_launcher_foreground = 0x7f0d0001;
        public static int ic_launcher_round = 0x7f0d0002;

        private mipmap() {
        }
    }

    public static final class raw {
        public static int classes4 = 0x7f0e0000;

        private raw() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0f001c;

        private string() {
        }
    }

    public static final class style {
        public static int Theme__1Bat = 0x7f10010f;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 0x7f120000;
        public static int data_extraction_rules = 0x7f120001;

        private xml() {
        }
    }

    private R() {
    }
}
