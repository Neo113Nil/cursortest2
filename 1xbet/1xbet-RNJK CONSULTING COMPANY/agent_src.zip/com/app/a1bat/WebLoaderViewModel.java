package com.app.a1bat;

/* compiled from: WebLoaderViewModel.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082D¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0011"}, d2 = {"Lcom/app/a1bat/WebLoaderViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "TAG", "", "_webScreenMethod", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Ljava/lang/reflect/Method;", "webScreenMethod", "Lkotlinx/coroutines/flow/StateFlow;", "getWebScreenMethod", "()Lkotlinx/coroutines/flow/StateFlow;", "loadWebScreen", "", "context", "Landroid/content/Context;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class WebLoaderViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final java.lang.String TAG = "DexLoader";
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.reflect.Method> _webScreenMethod;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.reflect.Method> webScreenMethod;

    public WebLoaderViewModel() {
        kotlinx.coroutines.flow.MutableStateFlow<java.lang.reflect.Method> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._webScreenMethod = MutableStateFlow;
        this.webScreenMethod = MutableStateFlow;
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.reflect.Method> getWebScreenMethod() {
        return this.webScreenMethod;
    }

    public final void loadWebScreen(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.Dispatchers.getIO(), null, new com.app.a1bat.WebLoaderViewModel$loadWebScreen$1(this, context, null), 2, null);
    }
}
