package com.app.a1bat.ui.navigation;

/* compiled from: AppNavigation.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class AppNavigationKt$MainAppNavigation$3$1$2 implements kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.navigation.NavHostController $navController;

    AppNavigationKt$MainAppNavigation$3$1$2(androidx.navigation.NavHostController navHostController) {
        this.$navController = navHostController;
    }

    @Override // kotlin.jvm.functions.Function4
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C88@3075L183,87@3020L252:AppNavigation.kt#d7vqwb");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-873284500, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation.<anonymous>.<anonymous>.<anonymous> (AppNavigation.kt:87)");
        }
        composer.startReplaceGroup(-706057139);
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):AppNavigation.kt#9igjgp");
        boolean changedInstance = composer.changedInstance(this.$navController);
        final androidx.navigation.NavHostController navHostController = this.$navController;
        java.lang.Object rememberedValue = composer.rememberedValue();
        if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    kotlin.Unit invoke$lambda$3$lambda$2;
                    invoke$lambda$3$lambda$2 = com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2.invoke$lambda$3$lambda$2(androidx.navigation.NavHostController.this);
                    return invoke$lambda$3$lambda$2;
                }
            };
            composer.updateRememberedValue(rememberedValue);
        }
        composer.endReplaceGroup();
        com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.OnboardingScreen((kotlin.jvm.functions.Function0) rememberedValue, null, composer, 0, 2);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$3$lambda$2(androidx.navigation.NavHostController navHostController) {
        navHostController.navigate(com.app.a1bat.ui.navigation.Screen.Main.INSTANCE.getRoute(), new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit invoke$lambda$3$lambda$2$lambda$1;
                invoke$lambda$3$lambda$2$lambda$1 = com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2.invoke$lambda$3$lambda$2$lambda$1((androidx.navigation.NavOptionsBuilder) obj);
                return invoke$lambda$3$lambda$2$lambda$1;
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$3$lambda$2$lambda$1(androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo(com.app.a1bat.ui.navigation.Screen.Onboarding.INSTANCE.getRoute(), new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit invoke$lambda$3$lambda$2$lambda$1$lambda$0;
                invoke$lambda$3$lambda$2$lambda$1$lambda$0 = com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2.invoke$lambda$3$lambda$2$lambda$1$lambda$0((androidx.navigation.PopUpToBuilder) obj);
                return invoke$lambda$3$lambda$2$lambda$1$lambda$0;
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$3$lambda$2$lambda$1$lambda$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(true);
        return kotlin.Unit.INSTANCE;
    }
}
