package com.app.a1bat.ui.navigation;

/* compiled from: AppNavigation.kt */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\u001a\r\u0010\u0000\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0002\u001a\r\u0010\u0003\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0002¨\u0006\u0004²\u0006\n\u0010\u0005\u001a\u00020\u0006X\u008a\u0084\u0002"}, d2 = {"AppNavigation", "", "(Landroidx/compose/runtime/Composer;I)V", "MainAppNavigation", "app_release", "uiState", "Lcom/app/a1bat/ui/screens/splash/SplashUiState;"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class AppNavigationKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavigation$lambda$1(int i, androidx.compose.runtime.Composer composer, int i2) {
        AppNavigation(composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit MainAppNavigation$lambda$8(int i, androidx.compose.runtime.Composer composer, int i2) {
        MainAppNavigation(composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    public static final void AppNavigation(androidx.compose.runtime.Composer composer, final int i) {
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(2038994315);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(AppNavigation)39@1618L15,40@1677L16:AppNavigation.kt#d7vqwb");
        if (i != 0 || !startRestartGroup.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(2038994315, i, -1, "com.app.a1bat.ui.navigation.AppNavigation (AppNavigation.kt:38)");
            }
            startRestartGroup.startReplaceableGroup(-1614864554);
            androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
            if (current == null) {
                throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
            }
            androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.splash.SplashViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
            startRestartGroup.endReplaceableGroup();
            com.app.a1bat.ui.screens.splash.SplashUiState AppNavigation$lambda$0 = AppNavigation$lambda$0(androidx.compose.runtime.SnapshotStateKt.collectAsState(((com.app.a1bat.ui.screens.splash.SplashViewModel) resolveViewModel).getUiState(), null, startRestartGroup, 0, 1));
            if (kotlin.jvm.internal.Intrinsics.areEqual(AppNavigation$lambda$0, com.app.a1bat.ui.screens.splash.SplashUiState.Loading.INSTANCE)) {
                startRestartGroup.startReplaceGroup(-501786615);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "45@1776L15");
                com.app.a1bat.LoadingScreenKt.LoadingScreen(startRestartGroup, 0);
                startRestartGroup.endReplaceGroup();
            } else if (AppNavigation$lambda$0 instanceof com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb) {
                startRestartGroup.startReplaceGroup(-501706263);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "");
                com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb showWeb = (com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb) AppNavigation$lambda$0;
                if (kotlin.text.StringsKt.isBlank(showWeb.getUrl())) {
                    startRestartGroup.startReplaceGroup(-501671295);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "50@1896L15");
                    com.app.a1bat.LoadingScreenKt.LoadingScreen(startRestartGroup, 0);
                    startRestartGroup.endReplaceGroup();
                } else {
                    startRestartGroup.startReplaceGroup(-501618161);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "52@1949L33");
                    com.app.a1bat.WebWrapperScreenKt.WebWrapperScreen(showWeb.getUrl(), null, startRestartGroup, 0, 2);
                    startRestartGroup.endReplaceGroup();
                }
                startRestartGroup.endReplaceGroup();
            } else {
                if (!kotlin.jvm.internal.Intrinsics.areEqual(AppNavigation$lambda$0, com.app.a1bat.ui.screens.splash.SplashUiState.ShowOnboarding.INSTANCE)) {
                    startRestartGroup.startReplaceGroup(-2094398304);
                    startRestartGroup.endReplaceGroup();
                    throw new kotlin.NoWhenBranchMatchedException();
                }
                startRestartGroup.startReplaceGroup(-501502779);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "57@2062L19");
                MainAppNavigation(startRestartGroup, 0);
                startRestartGroup.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit AppNavigation$lambda$1;
                    AppNavigation$lambda$1 = com.app.a1bat.ui.navigation.AppNavigationKt.AppNavigation$lambda$1(i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return AppNavigation$lambda$1;
                }
            });
        }
    }

    public static final void MainAppNavigation(androidx.compose.runtime.Composer composer, final int i) {
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(1228504786);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(MainAppNavigation)64@2163L23,69@2314L38,70@2379L39,71@2425L1925,66@2192L2158:AppNavigation.kt#d7vqwb");
        if (i != 0 || !startRestartGroup.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1228504786, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation (AppNavigation.kt:63)");
            }
            final androidx.navigation.NavHostController rememberNavController = androidx.navigation.compose.NavHostControllerKt.rememberNavController(new androidx.navigation.Navigator[0], startRestartGroup, 0);
            java.lang.String route = com.app.a1bat.ui.navigation.Screen.Splash.INSTANCE.getRoute();
            startRestartGroup.startReplaceGroup(2048459423);
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):AppNavigation.kt#9igjgp");
            java.lang.Object rememberedValue = startRestartGroup.rememberedValue();
            if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        androidx.compose.animation.EnterTransition MainAppNavigation$lambda$3$lambda$2;
                        MainAppNavigation$lambda$3$lambda$2 = com.app.a1bat.ui.navigation.AppNavigationKt.MainAppNavigation$lambda$3$lambda$2((androidx.compose.animation.AnimatedContentTransitionScope) obj);
                        return MainAppNavigation$lambda$3$lambda$2;
                    }
                };
                startRestartGroup.updateRememberedValue(rememberedValue);
            }
            kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) rememberedValue;
            startRestartGroup.endReplaceGroup();
            startRestartGroup.startReplaceGroup(2048461504);
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):AppNavigation.kt#9igjgp");
            java.lang.Object rememberedValue2 = startRestartGroup.rememberedValue();
            if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        androidx.compose.animation.ExitTransition MainAppNavigation$lambda$5$lambda$4;
                        MainAppNavigation$lambda$5$lambda$4 = com.app.a1bat.ui.navigation.AppNavigationKt.MainAppNavigation$lambda$5$lambda$4((androidx.compose.animation.AnimatedContentTransitionScope) obj);
                        return MainAppNavigation$lambda$5$lambda$4;
                    }
                };
                startRestartGroup.updateRememberedValue(rememberedValue2);
            }
            kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) rememberedValue2;
            startRestartGroup.endReplaceGroup();
            startRestartGroup.startReplaceGroup(2048464862);
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):AppNavigation.kt#9igjgp");
            boolean changedInstance = startRestartGroup.changedInstance(rememberNavController);
            java.lang.Object rememberedValue3 = startRestartGroup.rememberedValue();
            if (changedInstance || rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        kotlin.Unit MainAppNavigation$lambda$7$lambda$6;
                        MainAppNavigation$lambda$7$lambda$6 = com.app.a1bat.ui.navigation.AppNavigationKt.MainAppNavigation$lambda$7$lambda$6(androidx.navigation.NavHostController.this, (androidx.navigation.NavGraphBuilder) obj);
                        return MainAppNavigation$lambda$7$lambda$6;
                    }
                };
                startRestartGroup.updateRememberedValue(rememberedValue3);
            }
            startRestartGroup.endReplaceGroup();
            androidx.navigation.compose.NavHostKt.NavHost(rememberNavController, route, null, null, null, function1, function12, null, null, null, (kotlin.jvm.functions.Function1) rememberedValue3, startRestartGroup, 1769472, 0, 924);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit MainAppNavigation$lambda$8;
                    MainAppNavigation$lambda$8 = com.app.a1bat.ui.navigation.AppNavigationKt.MainAppNavigation$lambda$8(i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return MainAppNavigation$lambda$8;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.animation.EnterTransition MainAppNavigation$lambda$3$lambda$2(androidx.compose.animation.AnimatedContentTransitionScope NavHost) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        return androidx.compose.animation.EnterExitTransitionKt.fadeIn$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(500, 0, null, 6, null), 0.0f, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.animation.ExitTransition MainAppNavigation$lambda$5$lambda$4(androidx.compose.animation.AnimatedContentTransitionScope NavHost) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        return androidx.compose.animation.EnterExitTransitionKt.fadeOut$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(500, 0, null, 6, null), 0.0f, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit MainAppNavigation$lambda$7$lambda$6(final androidx.navigation.NavHostController navHostController, androidx.navigation.NavGraphBuilder NavHost) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.Splash.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1350313333, true, new com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$1(navHostController)), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.Onboarding.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-873284500, true, new com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$2(navHostController)), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.Main.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-951274771, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$3
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C96@3335L45:AppNavigation.kt#d7vqwb");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-951274771, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation.<anonymous>.<anonymous>.<anonymous> (AppNavigation.kt:96)");
                }
                com.app.a1bat.ui.screens.main.MainScreenKt.MainScreen(androidx.navigation.NavHostController.this, composer, 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.ServiceDetails.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1029265042, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry backStackEntry, androidx.compose.runtime.Composer composer, int i) {
                java.lang.String string;
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(backStackEntry, "backStackEntry");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C101@3634L46:AppNavigation.kt#d7vqwb");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1029265042, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation.<anonymous>.<anonymous>.<anonymous> (AppNavigation.kt:99)");
                }
                android.os.Bundle arguments = backStackEntry.getArguments();
                java.lang.Integer intOrNull = (arguments == null || (string = arguments.getString("serviceId")) == null) ? null : kotlin.text.StringsKt.toIntOrNull(string);
                if (intOrNull != null) {
                    com.app.a1bat.ui.screens.home.ServiceDetailsScreenKt.ServiceDetailsScreen(intOrNull.intValue(), androidx.navigation.NavHostController.this, null, composer, 0, 4);
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.BookConsultation.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1107255313, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$5
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry backStackEntry, androidx.compose.runtime.Composer composer, int i) {
                java.lang.String string;
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(backStackEntry, "backStackEntry");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C107@3953L48:AppNavigation.kt#d7vqwb");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1107255313, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation.<anonymous>.<anonymous>.<anonymous> (AppNavigation.kt:105)");
                }
                android.os.Bundle arguments = backStackEntry.getArguments();
                java.lang.Integer intOrNull = (arguments == null || (string = arguments.getString("serviceId")) == null) ? null : kotlin.text.StringsKt.toIntOrNull(string);
                if (intOrNull != null) {
                    com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen(intOrNull.intValue(), androidx.navigation.NavHostController.this, null, null, composer, 0, 12);
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.navigation.Screen.ArticleDetails.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1185245584, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.navigation.AppNavigationKt$MainAppNavigation$3$1$6
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry backStackEntry, androidx.compose.runtime.Composer composer, int i) {
                java.lang.String string;
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(backStackEntry, "backStackEntry");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C113@4274L46:AppNavigation.kt#d7vqwb");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1185245584, i, -1, "com.app.a1bat.ui.navigation.MainAppNavigation.<anonymous>.<anonymous>.<anonymous> (AppNavigation.kt:111)");
                }
                android.os.Bundle arguments = backStackEntry.getArguments();
                java.lang.Integer intOrNull = (arguments == null || (string = arguments.getString("articleId")) == null) ? null : kotlin.text.StringsKt.toIntOrNull(string);
                if (intOrNull != null) {
                    com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt.ArticleDetailsScreen(intOrNull.intValue(), androidx.navigation.NavHostController.this, null, composer, 0, 4);
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        return kotlin.Unit.INSTANCE;
    }

    private static final com.app.a1bat.ui.screens.splash.SplashUiState AppNavigation$lambda$0(androidx.compose.runtime.State<? extends com.app.a1bat.ui.screens.splash.SplashUiState> state) {
        return state.getValue();
    }
}
