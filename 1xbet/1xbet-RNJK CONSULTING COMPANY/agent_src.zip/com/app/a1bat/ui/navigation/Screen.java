package com.app.a1bat.ui.navigation;

/* compiled from: AppNavigation.kt */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0006\b\t\n\u000b\f\rB\u0011\b\u0004\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007\u0082\u0001\u0006\u000e\u000f\u0010\u0011\u0012\u0013¨\u0006\u0014"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen;", "", "route", "", "<init>", "(Ljava/lang/String;)V", "getRoute", "()Ljava/lang/String;", "Splash", "Onboarding", "Main", "ServiceDetails", "BookConsultation", "ArticleDetails", "Lcom/app/a1bat/ui/navigation/Screen$ArticleDetails;", "Lcom/app/a1bat/ui/navigation/Screen$BookConsultation;", "Lcom/app/a1bat/ui/navigation/Screen$Main;", "Lcom/app/a1bat/ui/navigation/Screen$Onboarding;", "Lcom/app/a1bat/ui/navigation/Screen$ServiceDetails;", "Lcom/app/a1bat/ui/navigation/Screen$Splash;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public abstract class Screen {
    public static final int $stable = 0;
    private final java.lang.String route;

    public /* synthetic */ Screen(java.lang.String str, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this(str);
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$Splash;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Splash extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.Splash INSTANCE = new com.app.a1bat.ui.navigation.Screen.Splash();

        private Splash() {
            super("splash", null);
        }
    }

    private Screen(java.lang.String str) {
        this.route = str;
    }

    public final java.lang.String getRoute() {
        return this.route;
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$Onboarding;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Onboarding extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.Onboarding INSTANCE = new com.app.a1bat.ui.navigation.Screen.Onboarding();

        private Onboarding() {
            super("onboarding", null);
        }
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$Main;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Main extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.Main INSTANCE = new com.app.a1bat.ui.navigation.Screen.Main();

        private Main() {
            super("main", null);
        }
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$ServiceDetails;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "createRoute", "", "serviceId", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ServiceDetails extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.ServiceDetails INSTANCE = new com.app.a1bat.ui.navigation.Screen.ServiceDetails();

        private ServiceDetails() {
            super("service_details/{serviceId}", null);
        }

        public final java.lang.String createRoute(int serviceId) {
            return "service_details/" + serviceId;
        }
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$BookConsultation;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "createRoute", "", "serviceId", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class BookConsultation extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.BookConsultation INSTANCE = new com.app.a1bat.ui.navigation.Screen.BookConsultation();

        private BookConsultation() {
            super("book_consultation/{serviceId}", null);
        }

        public final java.lang.String createRoute(int serviceId) {
            return "book_consultation/" + serviceId;
        }
    }

    /* compiled from: AppNavigation.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/app/a1bat/ui/navigation/Screen$ArticleDetails;", "Lcom/app/a1bat/ui/navigation/Screen;", "<init>", "()V", "createRoute", "", "articleId", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ArticleDetails extends com.app.a1bat.ui.navigation.Screen {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.navigation.Screen.ArticleDetails INSTANCE = new com.app.a1bat.ui.navigation.Screen.ArticleDetails();

        private ArticleDetails() {
            super("article_details/{articleId}", null);
        }

        public final java.lang.String createRoute(int articleId) {
            return "article_details/" + articleId;
        }
    }
}
