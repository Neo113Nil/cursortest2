package com.app.a1bat.ui.screens.home;

/* compiled from: HomeViewModel.kt */
@kotlin.Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\bR\u0016\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001d\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e0\n¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\f¨\u0006\u0014"}, d2 = {"Lcom/app/a1bat/ui/screens/home/HomeViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "_selectedCategory", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "selectedCategory", "Lkotlinx/coroutines/flow/StateFlow;", "getSelectedCategory", "()Lkotlinx/coroutines/flow/StateFlow;", "services", "", "Lcom/app/a1bat/domain/model/ConsultingService;", "getServices", "setCategory", "", "category", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class HomeViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _selectedCategory;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> selectedCategory;
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> services;

    public HomeViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._selectedCategory = MutableStateFlow;
        this.selectedCategory = MutableStateFlow;
        this.services = kotlinx.coroutines.flow.FlowKt.stateIn(kotlinx.coroutines.flow.FlowKt.flowCombine(repository.getAllServices(), MutableStateFlow, new com.app.a1bat.ui.screens.home.HomeViewModel$services$1(null)), androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed$default(kotlinx.coroutines.flow.SharingStarted.INSTANCE, androidx.lifecycle.CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), kotlin.collections.CollectionsKt.emptyList());
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getSelectedCategory() {
        return this.selectedCategory;
    }

    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> getServices() {
        return this.services;
    }

    public final void setCategory(java.lang.String category) {
        this._selectedCategory.setValue(category);
    }
}
