package com.app.a1bat.ui.screens.onboarding;

/* compiled from: OnboardingScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"}, d2 = {"Lcom/app/a1bat/ui/screens/onboarding/OnboardingPage;", "", io.ktor.http.LinkHeader.Parameters.Title, "", "description", "imageUrl", "tag", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getTitle", "()Ljava/lang/String;", "getDescription", "getImageUrl", "getTag", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class OnboardingPage {
    public static final int $stable = 0;
    private final java.lang.String description;
    private final java.lang.String imageUrl;
    private final java.lang.String tag;
    private final java.lang.String title;

    public static /* synthetic */ com.app.a1bat.ui.screens.onboarding.OnboardingPage copy$default(com.app.a1bat.ui.screens.onboarding.OnboardingPage onboardingPage, java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            str = onboardingPage.title;
        }
        if ((i & 2) != 0) {
            str2 = onboardingPage.description;
        }
        if ((i & 4) != 0) {
            str3 = onboardingPage.imageUrl;
        }
        if ((i & 8) != 0) {
            str4 = onboardingPage.tag;
        }
        return onboardingPage.copy(str, str2, str3, str4);
    }

    /* renamed from: component1, reason: from getter */
    public final java.lang.String getTitle() {
        return this.title;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getDescription() {
        return this.description;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getTag() {
        return this.tag;
    }

    public final com.app.a1bat.ui.screens.onboarding.OnboardingPage copy(java.lang.String title, java.lang.String description, java.lang.String imageUrl, java.lang.String tag) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tag, "tag");
        return new com.app.a1bat.ui.screens.onboarding.OnboardingPage(title, description, imageUrl, tag);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.ui.screens.onboarding.OnboardingPage)) {
            return false;
        }
        com.app.a1bat.ui.screens.onboarding.OnboardingPage onboardingPage = (com.app.a1bat.ui.screens.onboarding.OnboardingPage) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.title, onboardingPage.title) && kotlin.jvm.internal.Intrinsics.areEqual(this.description, onboardingPage.description) && kotlin.jvm.internal.Intrinsics.areEqual(this.imageUrl, onboardingPage.imageUrl) && kotlin.jvm.internal.Intrinsics.areEqual(this.tag, onboardingPage.tag);
    }

    public int hashCode() {
        return (((((this.title.hashCode() * 31) + this.description.hashCode()) * 31) + this.imageUrl.hashCode()) * 31) + this.tag.hashCode();
    }

    public java.lang.String toString() {
        return "OnboardingPage(title=" + this.title + ", description=" + this.description + ", imageUrl=" + this.imageUrl + ", tag=" + this.tag + ")";
    }

    public OnboardingPage(java.lang.String title, java.lang.String description, java.lang.String imageUrl, java.lang.String tag) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tag, "tag");
        this.title = title;
        this.description = description;
        this.imageUrl = imageUrl;
        this.tag = tag;
    }

    public final java.lang.String getTitle() {
        return this.title;
    }

    public final java.lang.String getDescription() {
        return this.description;
    }

    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final java.lang.String getTag() {
        return this.tag;
    }
}
