package com.app.a1bat.ui.screens.home;

/* compiled from: ServiceDetailsViewModel.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0011"}, d2 = {"Lcom/app/a1bat/ui/screens/home/ServiceDetailsViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "_service", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/app/a1bat/domain/model/ConsultingService;", androidx.core.app.NotificationCompat.CATEGORY_SERVICE, "Lkotlinx/coroutines/flow/StateFlow;", "getService", "()Lkotlinx/coroutines/flow/StateFlow;", "loadService", "", "id", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ServiceDetailsViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.domain.model.ConsultingService> _service;
    private final com.app.a1bat.domain.repository.AppRepository repository;
    private final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.domain.model.ConsultingService> service;

    public ServiceDetailsViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.domain.model.ConsultingService> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._service = MutableStateFlow;
        this.service = MutableStateFlow;
    }

    public final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.domain.model.ConsultingService> getService() {
        return this.service;
    }

    public final void loadService(int id) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1(this, id, null), 3, null);
    }
}
