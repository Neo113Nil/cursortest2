package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingViewModel.kt */
@kotlin.Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005JB\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u00122\b\u0010\u0016\u001a\u0004\u0018\u00010\u00122\b\u0010\u0017\u001a\u0004\u0018\u00010\u0012J\u0006\u0010\u0018\u001a\u00020\u000eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0019"}, d2 = {"Lcom/app/a1bat/ui/screens/booking/BookingViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "_bookingSuccess", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/app/a1bat/domain/model/Booking;", "bookingSuccess", "Lkotlinx/coroutines/flow/StateFlow;", "getBookingSuccess", "()Lkotlinx/coroutines/flow/StateFlow;", "submitBooking", "", "serviceId", "", "serviceName", "", "firstName", "lastName", "email", "companyName", "notes", "resetBookingSuccess", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class BookingViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.domain.model.Booking> _bookingSuccess;
    private final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.domain.model.Booking> bookingSuccess;
    private final com.app.a1bat.domain.repository.AppRepository repository;

    public BookingViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.domain.model.Booking> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._bookingSuccess = MutableStateFlow;
        this.bookingSuccess = MutableStateFlow;
    }

    public final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.domain.model.Booking> getBookingSuccess() {
        return this.bookingSuccess;
    }

    public final void submitBooking(int serviceId, java.lang.String serviceName, java.lang.String firstName, java.lang.String lastName, java.lang.String email, java.lang.String companyName, java.lang.String notes) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(serviceName, "serviceName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(firstName, "firstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(lastName, "lastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(email, "email");
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new com.app.a1bat.ui.screens.booking.BookingViewModel$submitBooking$1(serviceId, serviceName, firstName, lastName, email, companyName, notes, this, null), 3, null);
    }

    public final void resetBookingSuccess() {
        this._bookingSuccess.setValue(null);
    }
}
