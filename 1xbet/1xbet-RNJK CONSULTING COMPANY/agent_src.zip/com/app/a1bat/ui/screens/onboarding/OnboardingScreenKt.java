package com.app.a1bat.ui.screens.onboarding;

/* compiled from: OnboardingScreen.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\u001a%\u0010\u0005\u001a\u00020\u00062\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\b2\b\b\u0002\u0010\t\u001a\u00020\nH\u0007¢\u0006\u0002\u0010\u000b\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\f²\u0006\n\u0010\r\u001a\u00020\u000eX\u008a\u0084\u0002"}, d2 = {"onboardingPages", "", "Lcom/app/a1bat/ui/screens/onboarding/OnboardingPage;", "getOnboardingPages", "()Ljava/util/List;", "OnboardingScreen", "", "onFinishOnboarding", "Lkotlin/Function0;", "viewModel", "Lcom/app/a1bat/ui/screens/onboarding/OnboardingViewModel;", "(Lkotlin/jvm/functions/Function0;Lcom/app/a1bat/ui/screens/onboarding/OnboardingViewModel;Landroidx/compose/runtime/Composer;II)V", "app_release", "width", "Landroidx/compose/ui/unit/Dp;"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class OnboardingScreenKt {
    private static final java.util.List<com.app.a1bat.ui.screens.onboarding.OnboardingPage> onboardingPages = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.ui.screens.onboarding.OnboardingPage[]{new com.app.a1bat.ui.screens.onboarding.OnboardingPage("Strategic Planning", "Navigate complexity and unlock sustainable growth with data-driven corporate strategies.", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80", "Strategy"), new com.app.a1bat.ui.screens.onboarding.OnboardingPage("Business Analytics", "Transform raw data into actionable insights for competitive advantage.", "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80", "Analytics"), new com.app.a1bat.ui.screens.onboarding.OnboardingPage("Corporate Leadership", "Develop resilient leadership teams capable of steering through industry disruptions.", "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80", "Leadership")});

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingScreen$lambda$12(kotlin.jvm.functions.Function0 function0, com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        OnboardingScreen(function0, onboardingViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final java.util.List<com.app.a1bat.ui.screens.onboarding.OnboardingPage> getOnboardingPages() {
        return onboardingPages;
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x007a, code lost:
    
        if ((r55 & 2) != 0) goto L44;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void OnboardingScreen(final kotlin.jvm.functions.Function0<kotlin.Unit> function0, com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        int i4;
        float m6803constructorimpl;
        int i5;
        final kotlin.jvm.functions.Function0<kotlin.Unit> onFinishOnboarding = function0;
        final com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel2 = onboardingViewModel;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onFinishOnboarding, "onFinishOnboarding");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-533407078);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(OnboardingScreen)81@3421L24,81@3390L56,82@3472L24,84@3502L5682:OnboardingScreen.kt#g4j41z");
        if ((i2 & 1) != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = i | (startRestartGroup.changedInstance(onFinishOnboarding) ? 4 : 2);
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                if ((i & 64) == 0 ? startRestartGroup.changed(onboardingViewModel2) : startRestartGroup.changedInstance(onboardingViewModel2)) {
                    i5 = 32;
                    i3 |= i5;
                }
            }
            i5 = 16;
            i3 |= i5;
        }
        if ((i3 & 19) != 18 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "79@3349L15");
            if ((i & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 2) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.onboarding.OnboardingViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    onboardingViewModel2 = (com.app.a1bat.ui.screens.onboarding.OnboardingViewModel) resolveViewModel;
                    i3 &= -113;
                }
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-533407078, i3, -1, "com.app.a1bat.ui.screens.onboarding.OnboardingScreen (OnboardingScreen.kt:80)");
                }
                startRestartGroup.startReplaceGroup(235333588);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):OnboardingScreen.kt#9igjgp");
                java.lang.Object rememberedValue = startRestartGroup.rememberedValue();
                if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            int OnboardingScreen$lambda$1$lambda$0;
                            OnboardingScreen$lambda$1$lambda$0 = com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.OnboardingScreen$lambda$1$lambda$0();
                            return java.lang.Integer.valueOf(OnboardingScreen$lambda$1$lambda$0);
                        }
                    };
                    startRestartGroup.updateRememberedValue(rememberedValue);
                }
                startRestartGroup.endReplaceGroup();
                int i6 = i3;
                final androidx.compose.foundation.pager.PagerState rememberPagerState = androidx.compose.foundation.pager.PagerStateKt.rememberPagerState(0, 0.0f, (kotlin.jvm.functions.Function0) rememberedValue, startRestartGroup, 384, 3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 773894976, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp");
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 683737348, "CC(remember):Effects.kt#9igjgp");
                java.lang.Object rememberedValue2 = startRestartGroup.rememberedValue();
                if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue2 = androidx.compose.runtime.EffectsKt.createCompositionCoroutineScope(kotlin.coroutines.EmptyCoroutineContext.INSTANCE, startRestartGroup);
                    startRestartGroup.updateRememberedValue(rememberedValue2);
                }
                final kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) rememberedValue2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.ui.Modifier m249backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.ColorKt.Color(4279046423L), null, 2, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, m249backgroundbw27NRU$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                startRestartGroup.startReusableNode();
                if (startRestartGroup.getInserting()) {
                    startRestartGroup.createNode(constructor);
                } else {
                    startRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1458148099, "C87@3599L2718,153@6327L2851:OnboardingScreen.kt#g4j41z");
                final com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel3 = onboardingViewModel2;
                androidx.compose.foundation.pager.PagerKt.m931HorizontalPageroI3XNZo(rememberPagerState, androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, 0, 0.0f, null, null, false, false, null, null, null, com.app.a1bat.ui.screens.onboarding.ComposableSingletons$OnboardingScreenKt.INSTANCE.m7421getLambda1$app_release(), startRestartGroup, 48, 3072, 8188);
                androidx.compose.runtime.Composer composer2 = startRestartGroup;
                float f = 24;
                androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getBottomCenter()), 0.0f, 1, null), com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), null, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(20));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, m695paddingVpY3zN4);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor2);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 1431518916, "C160@6571L2597:OnboardingScreen.kt#g4j41z");
                androidx.compose.ui.Modifier fillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical spaceBetween = androidx.compose.foundation.layout.Arrangement.INSTANCE.getSpaceBetween();
                androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, 54);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, fillMaxWidth$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor3);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                    m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                    m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1960827827, "C166@6831L123,165@6789L301,174@7108L973,205@8628L41,195@8137L445,208@8833L321,194@8099L1055:OnboardingScreen.kt#g4j41z");
                composer2.startReplaceGroup(629483252);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "CC(remember):OnboardingScreen.kt#9igjgp");
                int i7 = (i6 & 112) ^ 48;
                int i8 = i6 & 14;
                boolean z = ((i7 > 32 && composer2.changedInstance(onboardingViewModel3)) || (i6 & 48) == 32) | (i8 == 4);
                java.lang.Object rememberedValue3 = composer2.rememberedValue();
                if (z || rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue3 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            kotlin.Unit OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$3$lambda$2;
                            OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$3$lambda$2 = com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$3$lambda$2(com.app.a1bat.ui.screens.onboarding.OnboardingViewModel.this, function0);
                            return OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$3$lambda$2;
                        }
                    };
                    composer2.updateRememberedValue(rememberedValue3);
                }
                composer2.endReplaceGroup();
                androidx.compose.material3.ButtonKt.TextButton((kotlin.jvm.functions.Function0) rememberedValue3, null, false, null, null, null, null, null, null, com.app.a1bat.ui.screens.onboarding.ComposableSingletons$OnboardingScreenKt.INSTANCE.m7422getLambda2$app_release(), composer2, 805306368, 510);
                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical center = androidx.compose.foundation.layout.Arrangement.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                char c = 6;
                androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy2 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(center, androidx.compose.ui.Alignment.INSTANCE.getTop(), composer2, 6);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, companion);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor4);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, rowMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                    m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                    m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 489275350, "C:OnboardingScreen.kt#g4j41z");
                composer2.startReplaceGroup(1401256397);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "*177@7328L252,182@7605L436");
                int size = onboardingPages.size();
                int i9 = 0;
                while (i9 < size) {
                    boolean z2 = rememberPagerState.getCurrentPage() == i9;
                    if (z2) {
                        m6803constructorimpl = androidx.compose.ui.unit.Dp.m6803constructorimpl(f);
                        i4 = 8;
                    } else {
                        i4 = 8;
                        m6803constructorimpl = androidx.compose.ui.unit.Dp.m6803constructorimpl(8);
                    }
                    char c2 = c;
                    androidx.compose.runtime.Composer composer3 = composer2;
                    androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m741sizeVpY3zN4(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(3), 0.0f, 2, null), OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$6$lambda$5$lambda$4(androidx.compose.animation.core.AnimateAsStateKt.m141animateDpAsStateAjpBEmI(m6803constructorimpl, androidx.compose.animation.core.AnimationSpecKt.tween$default(androidx.compose.animation.core.AnimationConstants.DefaultDurationMillis, 0, androidx.compose.animation.core.EasingKt.getFastOutSlowInEasing(), 2, null), "dot_width", null, composer3, 384, 8)), androidx.compose.ui.unit.Dp.m6803constructorimpl(i4)), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), z2 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.25f, 0.0f, 0.0f, 0.0f, 14, null), null, 2, null), composer3, 0);
                    i9++;
                    c = c2;
                    composer2 = composer3;
                }
                androidx.compose.runtime.Composer composer4 = composer2;
                composer4.endReplaceGroup();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                composer4.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.material3.ButtonColors m1501buttonColorsro_MJ88 = androidx.compose.material3.ButtonDefaults.INSTANCE.m1501buttonColorsro_MJ88(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, 0L, 0L, composer4, (androidx.compose.material3.ButtonDefaults.$stable << 12) | 6, 14);
                startRestartGroup = composer4;
                androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14));
                androidx.compose.foundation.layout.PaddingValues m688PaddingValuesYgX7TsA = androidx.compose.foundation.layout.PaddingKt.m688PaddingValuesYgX7TsA(androidx.compose.ui.unit.Dp.m6803constructorimpl(22), androidx.compose.ui.unit.Dp.m6803constructorimpl(12));
                startRestartGroup.startReplaceGroup(629525366);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):OnboardingScreen.kt#9igjgp");
                boolean changed = startRestartGroup.changed(rememberPagerState) | ((i7 > 32 && startRestartGroup.changedInstance(onboardingViewModel3)) || (i6 & 48) == 32) | (i8 == 4) | startRestartGroup.changedInstance(coroutineScope);
                java.lang.Object rememberedValue4 = startRestartGroup.rememberedValue();
                if (changed || rememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    onFinishOnboarding = function0;
                    rememberedValue4 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            kotlin.Unit OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$8$lambda$7;
                            OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$8$lambda$7 = com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$8$lambda$7(androidx.compose.foundation.pager.PagerState.this, onboardingViewModel3, onFinishOnboarding, coroutineScope);
                            return OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$8$lambda$7;
                        }
                    };
                    startRestartGroup.updateRememberedValue(rememberedValue4);
                } else {
                    onFinishOnboarding = function0;
                }
                startRestartGroup.endReplaceGroup();
                androidx.compose.material3.ButtonKt.Button((kotlin.jvm.functions.Function0) rememberedValue4, null, false, m977RoundedCornerShape0680j_4, m1501buttonColorsro_MJ88, null, null, m688PaddingValuesYgX7TsA, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(179992762, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$OnboardingScreen$1$1$1$4
                    @Override // kotlin.jvm.functions.Function3
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer5, java.lang.Integer num) {
                        invoke(rowScope, composer5, num.intValue());
                        return kotlin.Unit.INSTANCE;
                    }

                    public final void invoke(androidx.compose.foundation.layout.RowScope Button, androidx.compose.runtime.Composer composer5, int i10) {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Button, "$this$Button");
                        androidx.compose.runtime.ComposerKt.sourceInformation(composer5, "C209@8855L281:OnboardingScreen.kt#g4j41z");
                        if ((i10 & 17) != 16 || !composer5.getSkipping()) {
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(179992762, i10, -1, "com.app.a1bat.ui.screens.onboarding.OnboardingScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OnboardingScreen.kt:209)");
                            }
                            androidx.compose.material3.TextKt.m2386Text4IGK_g(androidx.compose.foundation.pager.PagerState.this.getCurrentPage() == com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.getOnboardingPages().size() + (-1) ? "Get Started" : "Next", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(15), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer5, 200064, 0, 131026);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        composer5.skipToGroupEnd();
                    }
                }, startRestartGroup, 54), startRestartGroup, 817889280, 358);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                startRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                startRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                startRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                onboardingViewModel2 = onboardingViewModel3;
            } else {
                startRestartGroup.skipToGroupEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit OnboardingScreen$lambda$12;
                    OnboardingScreen$lambda$12 = com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt.OnboardingScreen$lambda$12(kotlin.jvm.functions.Function0.this, onboardingViewModel2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return OnboardingScreen$lambda$12;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int OnboardingScreen$lambda$1$lambda$0() {
        return onboardingPages.size();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$3$lambda$2(com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel, kotlin.jvm.functions.Function0 function0) {
        onboardingViewModel.completeOnboarding();
        function0.invoke();
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$8$lambda$7(androidx.compose.foundation.pager.PagerState pagerState, com.app.a1bat.ui.screens.onboarding.OnboardingViewModel onboardingViewModel, kotlin.jvm.functions.Function0 function0, kotlinx.coroutines.CoroutineScope coroutineScope) {
        if (pagerState.getCurrentPage() != onboardingPages.size() - 1) {
            kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.onboarding.OnboardingScreenKt$OnboardingScreen$1$1$1$3$1$1(pagerState, null), 3, null);
        } else {
            onboardingViewModel.completeOnboarding();
            function0.invoke();
        }
        return kotlin.Unit.INSTANCE;
    }

    private static final float OnboardingScreen$lambda$11$lambda$10$lambda$9$lambda$6$lambda$5$lambda$4(androidx.compose.runtime.State<androidx.compose.ui.unit.Dp> state) {
        return state.getValue().m6817unboximpl();
    }
}
