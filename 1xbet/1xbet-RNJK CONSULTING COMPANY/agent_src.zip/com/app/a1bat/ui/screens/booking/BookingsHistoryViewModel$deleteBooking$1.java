package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingsHistoryViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel$deleteBooking$1", f = "BookingsHistoryViewModel.kt", i = {}, l = {25}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class BookingsHistoryViewModel$deleteBooking$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ java.lang.String $bookingId;
    int label;
    final /* synthetic */ com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    BookingsHistoryViewModel$deleteBooking$1(com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel bookingsHistoryViewModel, java.lang.String str, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel$deleteBooking$1> continuation) {
        super(2, continuation);
        this.this$0 = bookingsHistoryViewModel;
        this.$bookingId = str;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel$deleteBooking$1(this.this$0, this.$bookingId, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel$deleteBooking$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        com.app.a1bat.domain.repository.AppRepository appRepository;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            appRepository = this.this$0.repository;
            this.label = 1;
            if (appRepository.deleteBooking(this.$bookingId, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(obj);
        }
        return kotlin.Unit.INSTANCE;
    }
}
