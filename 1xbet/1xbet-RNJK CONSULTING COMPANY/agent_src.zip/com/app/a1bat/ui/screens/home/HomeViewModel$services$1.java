package com.app.a1bat.ui.screens.home;

/* compiled from: HomeViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u00012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\n"}, d2 = {"<anonymous>", "", "Lcom/app/a1bat/domain/model/ConsultingService;", "services", "category", ""}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.home.HomeViewModel$services$1", f = "HomeViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class HomeViewModel$services$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function3<java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>, java.lang.String, kotlin.coroutines.Continuation<? super java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>>, java.lang.Object> {
    /* synthetic */ java.lang.Object L$0;
    /* synthetic */ java.lang.Object L$1;
    int label;

    HomeViewModel$services$1(kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.home.HomeViewModel$services$1> continuation) {
        super(3, continuation);
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ java.lang.Object invoke(java.util.List<? extends com.app.a1bat.domain.model.ConsultingService> list, java.lang.String str, kotlin.coroutines.Continuation<? super java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>> continuation) {
        return invoke2((java.util.List<com.app.a1bat.domain.model.ConsultingService>) list, str, (kotlin.coroutines.Continuation<? super java.util.List<com.app.a1bat.domain.model.ConsultingService>>) continuation);
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final java.lang.Object invoke2(java.util.List<com.app.a1bat.domain.model.ConsultingService> list, java.lang.String str, kotlin.coroutines.Continuation<? super java.util.List<com.app.a1bat.domain.model.ConsultingService>> continuation) {
        com.app.a1bat.ui.screens.home.HomeViewModel$services$1 homeViewModel$services$1 = new com.app.a1bat.ui.screens.home.HomeViewModel$services$1(continuation);
        homeViewModel$services$1.L$0 = list;
        homeViewModel$services$1.L$1 = str;
        return homeViewModel$services$1.invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.ResultKt.throwOnFailure(obj);
        java.util.List list = (java.util.List) this.L$0;
        java.lang.String str = (java.lang.String) this.L$1;
        if (str == null) {
            return list;
        }
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (java.lang.Object obj2 : list) {
            if (kotlin.jvm.internal.Intrinsics.areEqual(((com.app.a1bat.domain.model.ConsultingService) obj2).getCategory(), str)) {
                arrayList.add(obj2);
            }
        }
        return arrayList;
    }
}
