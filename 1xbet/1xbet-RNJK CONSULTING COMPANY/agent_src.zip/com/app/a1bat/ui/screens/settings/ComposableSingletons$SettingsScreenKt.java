package com.app.a1bat.ui.screens.settings;

/* compiled from: SettingsScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ComposableSingletons$SettingsScreenKt {
    public static final com.app.a1bat.ui.screens.settings.ComposableSingletons$SettingsScreenKt INSTANCE = new com.app.a1bat.ui.screens.settings.ComposableSingletons$SettingsScreenKt();

    /* renamed from: lambda-1, reason: not valid java name */
    public static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f92lambda1 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(874680095, false, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.settings.ComposableSingletons$SettingsScreenKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.runtime.Composer composer, int i) {
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C135@5035L195,141@5243L177:SettingsScreen.kt#f3fv0f");
            if ((i & 3) != 2 || !composer.getSkipping()) {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(874680095, i, -1, "com.app.a1bat.ui.screens.settings.ComposableSingletons$SettingsScreenKt.lambda-1.<anonymous> (SettingsScreen.kt:135)");
                }
                com.app.a1bat.ui.screens.settings.SettingsScreenKt.SettingsItem(androidx.compose.material.icons.filled.BusinessKt.getBusiness(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Company", "1 Bat Consulting LTD", true, composer, 3504, 0);
                com.app.a1bat.ui.screens.settings.SettingsScreenKt.SettingsItem(androidx.compose.material.icons.filled.InfoKt.getInfo(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Version", "1.0.0", false, composer, 3504, 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            composer.skipToGroupEnd();
        }
    });

    /* renamed from: getLambda-1$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7426getLambda1$app_release() {
        return f92lambda1;
    }
}
