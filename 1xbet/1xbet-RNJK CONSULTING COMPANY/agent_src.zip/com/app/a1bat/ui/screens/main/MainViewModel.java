package com.app.a1bat.ui.screens.main;

/* compiled from: MainViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0019\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\t¨\u0006\n"}, d2 = {"Lcom/app/a1bat/ui/screens/main/MainViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "isOnboardingCompleted", "Lkotlinx/coroutines/flow/StateFlow;", "", "()Lkotlinx/coroutines/flow/StateFlow;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class MainViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isOnboardingCompleted;

    public MainViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.isOnboardingCompleted = kotlinx.coroutines.flow.FlowKt.stateIn(repository.isOnboardingCompleted(), androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed$default(kotlinx.coroutines.flow.SharingStarted.INSTANCE, androidx.lifecycle.CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), null);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isOnboardingCompleted() {
        return this.isOnboardingCompleted;
    }
}
