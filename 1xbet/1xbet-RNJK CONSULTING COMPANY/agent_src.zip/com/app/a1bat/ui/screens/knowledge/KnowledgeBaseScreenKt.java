package com.app.a1bat.ui.screens.knowledge;

/* compiled from: KnowledgeBaseScreen.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \u001a#\u0010\u0000\u001a\u00020\u00012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a/\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00010\u000b2\b\b\u0002\u0010\f\u001a\u00020\rH\u0007¢\u0006\u0002\u0010\u000e¨\u0006\u000f²\u0006\u0010\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\t0\u0011X\u008a\u0084\u0002"}, d2 = {"KnowledgeBaseScreen", "", "rootNavController", "Landroidx/navigation/NavController;", "viewModel", "Lcom/app/a1bat/ui/screens/knowledge/KnowledgeBaseViewModel;", "(Landroidx/navigation/NavController;Lcom/app/a1bat/ui/screens/knowledge/KnowledgeBaseViewModel;Landroidx/compose/runtime/Composer;II)V", "ArticleCard", "article", "Lcom/app/a1bat/domain/model/Article;", "onClick", "Lkotlin/Function0;", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/app/a1bat/domain/model/Article;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release", "articles", ""}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class KnowledgeBaseScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ArticleCard$lambda$9(com.app.a1bat.domain.model.Article article, kotlin.jvm.functions.Function0 function0, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ArticleCard(article, function0, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit KnowledgeBaseScreen$lambda$5(androidx.navigation.NavController navController, com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel knowledgeBaseViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        KnowledgeBaseScreen(navController, knowledgeBaseViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0151  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void KnowledgeBaseScreen(androidx.navigation.NavController navController, com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel knowledgeBaseViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.navigation.NavController navController2;
        int i3;
        final com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel knowledgeBaseViewModel2;
        com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel knowledgeBaseViewModel3;
        final androidx.navigation.NavController navController3;
        boolean changed;
        java.lang.Object rememberedValue;
        int i4;
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-1413800706);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(KnowledgeBaseScreen)55@2364L16,62@2558L1905,57@2386L2077:KnowledgeBaseScreen.kt#tolt0g");
        int i5 = i2 & 1;
        if (i5 != 0) {
            i3 = i | 6;
            navController2 = navController;
        } else if ((i & 6) == 0) {
            navController2 = navController;
            i3 = (startRestartGroup.changedInstance(navController2) ? 4 : 2) | i;
        } else {
            navController2 = navController;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                knowledgeBaseViewModel2 = knowledgeBaseViewModel;
                if (startRestartGroup.changedInstance(knowledgeBaseViewModel2)) {
                    i4 = 32;
                    i3 |= i4;
                }
            } else {
                knowledgeBaseViewModel2 = knowledgeBaseViewModel;
            }
            i4 = 16;
            i3 |= i4;
        } else {
            knowledgeBaseViewModel2 = knowledgeBaseViewModel;
        }
        if ((i3 & 19) != 18 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "53@2305L15");
            if ((i & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if (i5 != 0) {
                    navController2 = null;
                }
                if ((i2 & 2) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    i3 &= -113;
                    knowledgeBaseViewModel3 = (com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel) resolveViewModel;
                    navController3 = navController2;
                    startRestartGroup.endDefaults();
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventStart(-1413800706, i3, -1, "com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreen (KnowledgeBaseScreen.kt:54)");
                    }
                    final androidx.compose.runtime.State collectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(knowledgeBaseViewModel3.getArticles(), null, startRestartGroup, 0, 1);
                    androidx.compose.ui.Modifier m249backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.ColorKt.Color(4293980917L), null, 2, null);
                    androidx.compose.foundation.layout.PaddingValues m691PaddingValuesa9UjIt4$default = androidx.compose.foundation.layout.PaddingKt.m691PaddingValuesa9UjIt4$default(0.0f, 0.0f, 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(24), 7, null);
                    startRestartGroup.startReplaceGroup(-1148368706);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
                    changed = startRestartGroup.changed(collectAsState) | startRestartGroup.changedInstance(navController3);
                    rememberedValue = startRestartGroup.rememberedValue();
                    if (!changed || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        rememberedValue = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object invoke(java.lang.Object obj) {
                                kotlin.Unit KnowledgeBaseScreen$lambda$4$lambda$3;
                                KnowledgeBaseScreen$lambda$4$lambda$3 = com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.KnowledgeBaseScreen$lambda$4$lambda$3(androidx.compose.runtime.State.this, navController3, (androidx.compose.foundation.lazy.LazyListScope) obj);
                                return KnowledgeBaseScreen$lambda$4$lambda$3;
                            }
                        };
                        startRestartGroup.updateRememberedValue(rememberedValue);
                    }
                    startRestartGroup.endReplaceGroup();
                    androidx.compose.foundation.lazy.LazyDslKt.LazyColumn(m249backgroundbw27NRU$default, null, m691PaddingValuesa9UjIt4$default, false, null, null, null, false, (kotlin.jvm.functions.Function1) rememberedValue, startRestartGroup, 390, 250);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    knowledgeBaseViewModel2 = knowledgeBaseViewModel3;
                }
            } else {
                startRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
            }
            navController3 = navController2;
            knowledgeBaseViewModel3 = knowledgeBaseViewModel2;
            startRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            final androidx.compose.runtime.State collectAsState2 = androidx.compose.runtime.SnapshotStateKt.collectAsState(knowledgeBaseViewModel3.getArticles(), null, startRestartGroup, 0, 1);
            androidx.compose.ui.Modifier m249backgroundbw27NRU$default2 = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.ColorKt.Color(4293980917L), null, 2, null);
            androidx.compose.foundation.layout.PaddingValues m691PaddingValuesa9UjIt4$default2 = androidx.compose.foundation.layout.PaddingKt.m691PaddingValuesa9UjIt4$default(0.0f, 0.0f, 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(24), 7, null);
            startRestartGroup.startReplaceGroup(-1148368706);
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
            changed = startRestartGroup.changed(collectAsState2) | startRestartGroup.changedInstance(navController3);
            rememberedValue = startRestartGroup.rememberedValue();
            if (!changed) {
            }
            rememberedValue = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function1
                public final java.lang.Object invoke(java.lang.Object obj) {
                    kotlin.Unit KnowledgeBaseScreen$lambda$4$lambda$3;
                    KnowledgeBaseScreen$lambda$4$lambda$3 = com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.KnowledgeBaseScreen$lambda$4$lambda$3(androidx.compose.runtime.State.this, navController3, (androidx.compose.foundation.lazy.LazyListScope) obj);
                    return KnowledgeBaseScreen$lambda$4$lambda$3;
                }
            };
            startRestartGroup.updateRememberedValue(rememberedValue);
            startRestartGroup.endReplaceGroup();
            androidx.compose.foundation.lazy.LazyDslKt.LazyColumn(m249backgroundbw27NRU$default2, null, m691PaddingValuesa9UjIt4$default2, false, null, null, null, false, (kotlin.jvm.functions.Function1) rememberedValue, startRestartGroup, 390, 250);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            knowledgeBaseViewModel2 = knowledgeBaseViewModel3;
        } else {
            startRestartGroup.skipToGroupEnd();
            navController3 = navController2;
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit KnowledgeBaseScreen$lambda$5;
                    KnowledgeBaseScreen$lambda$5 = com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.KnowledgeBaseScreen$lambda$5(androidx.navigation.NavController.this, knowledgeBaseViewModel2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return KnowledgeBaseScreen$lambda$5;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit KnowledgeBaseScreen$lambda$4$lambda$3(androidx.compose.runtime.State state, final androidx.navigation.NavController navController, androidx.compose.foundation.lazy.LazyListScope LazyColumn) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyColumn, null, null, com.app.a1bat.ui.screens.knowledge.ComposableSingletons$KnowledgeBaseScreenKt.INSTANCE.m7413getLambda1$app_release(), 3, null);
        final java.util.List<com.app.a1bat.domain.model.Article> KnowledgeBaseScreen$lambda$0 = KnowledgeBaseScreen$lambda$0(state);
        final com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$KnowledgeBaseScreen$lambda$4$lambda$3$$inlined$items$default$1 knowledgeBaseScreenKt$KnowledgeBaseScreen$lambda$4$lambda$3$$inlined$items$default$1 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$KnowledgeBaseScreen$lambda$4$lambda$3$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Void invoke(com.app.a1bat.domain.model.Article article) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object obj) {
                return invoke((com.app.a1bat.domain.model.Article) obj);
            }
        };
        LazyColumn.items(KnowledgeBaseScreen$lambda$0.size(), null, new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$KnowledgeBaseScreen$lambda$4$lambda$3$$inlined$items$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return kotlin.jvm.functions.Function1.this.invoke(KnowledgeBaseScreen$lambda$0.get(i));
            }
        }, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-632812321, true, new kotlin.jvm.functions.Function4<androidx.compose.foundation.lazy.LazyItemScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$KnowledgeBaseScreen$lambda$4$lambda$3$$inlined$items$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(4);
            }

            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, java.lang.Integer num, androidx.compose.runtime.Composer composer, java.lang.Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, int i, androidx.compose.runtime.Composer composer, int i2) {
                int i3;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C152@7074L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if ((i3 & 147) == 146 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-632812321, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)");
                }
                final com.app.a1bat.domain.model.Article article = (com.app.a1bat.domain.model.Article) KnowledgeBaseScreen$lambda$0.get(i);
                composer.startReplaceGroup(-2127633924);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C*108@4301L78,105@4162L231,110@4406L41:KnowledgeBaseScreen.kt#tolt0g");
                float f = 16;
                androidx.compose.ui.Modifier m696paddingVpY3zN4$default = androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f), 0.0f, 2, null);
                composer.startReplaceGroup(-622818440);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
                boolean changedInstance = composer.changedInstance(navController) | composer.changed(article);
                java.lang.Object rememberedValue = composer.rememberedValue();
                if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final androidx.navigation.NavController navController2 = navController;
                    rememberedValue = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$KnowledgeBaseScreen$1$1$1$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            androidx.navigation.NavController navController3 = androidx.navigation.NavController.this;
                            if (navController3 != null) {
                                androidx.navigation.NavController.navigate$default(navController3, com.app.a1bat.ui.navigation.Screen.ArticleDetails.INSTANCE.createRoute(article.getId()), (androidx.navigation.NavOptions) null, (androidx.navigation.Navigator.Extras) null, 6, (java.lang.Object) null);
                            }
                        }
                    };
                    composer.updateRememberedValue(rememberedValue);
                }
                composer.endReplaceGroup();
                com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.ArticleCard(article, (kotlin.jvm.functions.Function0) rememberedValue, m696paddingVpY3zN4$default, composer, 384, 0);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer, 6);
                composer.endReplaceGroup();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0192  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0051  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ArticleCard(final com.app.a1bat.domain.model.Article article, kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        kotlin.jvm.functions.Function0<kotlin.Unit> function02;
        int i4;
        androidx.compose.ui.Modifier modifier2;
        kotlin.jvm.functions.Function0<kotlin.Unit> function03;
        final androidx.compose.ui.Modifier.Companion companion;
        java.lang.Object rememberedValue;
        androidx.compose.runtime.Composer composer2;
        final kotlin.jvm.functions.Function0<kotlin.Unit> function04;
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(article, "article");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-1779591502);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(ArticleCard)P(!1,2)118@4544L2,127@4810L39,132@5008L40,133@5083L19,134@5109L3789,121@4590L4308:KnowledgeBaseScreen.kt#tolt0g");
        if ((i2 & 1) != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = (startRestartGroup.changed(article) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i5 = i2 & 2;
        if (i5 != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            function02 = function0;
            i3 |= startRestartGroup.changedInstance(function02) ? 32 : 16;
            i4 = i2 & 4;
            if (i4 == 0) {
                i3 |= 384;
            } else if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= startRestartGroup.changed(modifier2) ? 256 : 128;
                if ((i3 & 147) == 146 || !startRestartGroup.getSkipping()) {
                    if (i5 != 0) {
                        startRestartGroup.startReplaceGroup(-367903686);
                        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
                        java.lang.Object rememberedValue2 = startRestartGroup.rememberedValue();
                        if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                            rememberedValue2 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$$ExternalSyntheticLambda2
                                @Override // kotlin.jvm.functions.Function0
                                public final java.lang.Object invoke() {
                                    kotlin.Unit unit;
                                    unit = kotlin.Unit.INSTANCE;
                                    return unit;
                                }
                            };
                            startRestartGroup.updateRememberedValue(rememberedValue2);
                        }
                        startRestartGroup.endReplaceGroup();
                        function03 = (kotlin.jvm.functions.Function0) rememberedValue2;
                    } else {
                        function03 = function02;
                    }
                    companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventStart(-1779591502, i3, -1, "com.app.a1bat.ui.screens.knowledge.ArticleCard (KnowledgeBaseScreen.kt:120)");
                    }
                    float f = 20;
                    androidx.compose.ui.Modifier clip = androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(6), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)));
                    startRestartGroup.startReplaceGroup(-367895137);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
                    rememberedValue = startRestartGroup.rememberedValue();
                    if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        rememberedValue = androidx.compose.foundation.interaction.InteractionSourceKt.MutableInteractionSource();
                        startRestartGroup.updateRememberedValue(rememberedValue);
                    }
                    startRestartGroup.endReplaceGroup();
                    androidx.compose.material3.CardKt.Card(androidx.compose.foundation.ClickableKt.m280clickableO2vRcR0$default(clip, (androidx.compose.foundation.interaction.MutableInteractionSource) rememberedValue, null, false, null, null, function03, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.material3.CardDefaults.INSTANCE.m1521cardColorsro_MJ88(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0L, 0L, 0L, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 12) | 6, 14), androidx.compose.material3.CardDefaults.INSTANCE.m1522cardElevationaqJV_2Y(androidx.compose.ui.unit.Dp.m6803constructorimpl(0), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 18) | 6, 62), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(741582720, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.ColumnScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$ArticleCard$3
                        @Override // kotlin.jvm.functions.Function3
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.ColumnScope columnScope, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                            invoke(columnScope, composer3, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        public final void invoke(androidx.compose.foundation.layout.ColumnScope Card, androidx.compose.runtime.Composer composer3, int i6) {
                            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Card, "$this$Card");
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C135@5119L3773:KnowledgeBaseScreen.kt#tolt0g");
                            if ((i6 & 17) != 16 || !composer3.getSkipping()) {
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(741582720, i6, -1, "com.app.a1bat.ui.screens.knowledge.ArticleCard.<anonymous> (KnowledgeBaseScreen.kt:135)");
                                }
                                com.app.a1bat.domain.model.Article article2 = com.app.a1bat.domain.model.Article.this;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion2);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 891908015, "C136@5140L1427,174@6581L2301:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(190));
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m725height3ABfNKs);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor2);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2091136218, "C141@5285L239,147@5541L373,157@5931L622:KnowledgeBaseScreen.kt#tolt0g");
                                coil.compose.SingletonAsyncImageKt.m7328AsyncImagegl8XCv8(article2.getImageUrl(), article2.getTitle(), androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, null, 0, false, null, composer3, 1573248, 0, 4024);
                                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU())}), 300.0f, 0.0f, 0, 12, (java.lang.Object) null), null, 0.0f, 6, null), composer3, 6);
                                float f2 = 12;
                                androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0.85f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(8))), androidx.compose.ui.unit.Dp.m6803constructorimpl(10), androidx.compose.ui.unit.Dp.m6803constructorimpl(4));
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m695paddingVpY3zN4);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor3);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                                    m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                                    m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 916988200, "C164@6272L263:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getCategory(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(10), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.3d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 12782976, 0, 130898);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                float f3 = 16;
                                androidx.compose.ui.Modifier m698paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m698paddingqDBjuR0$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 2, null);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m698paddingqDBjuR0$default);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor4);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                                    m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                                    m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2092576447, "C177@6709L234,184@6960L40,185@7017L225,192@7259L41,193@7317L1551:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getTitle(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(17), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(23), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 6, 130002);
                                float f4 = 6;
                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getContent(), (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4285231744L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(19), 0, false, 2, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 3078, 121842);
                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), composer3, 6);
                                androidx.compose.ui.Modifier fillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical spaceBetween = androidx.compose.foundation.layout.Arrangement.INSTANCE.getSpaceBetween();
                                androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                                androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer3, 54);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, fillMaxWidth$default);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor5);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                                    m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                                    m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash5);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 918292928, "C198@7555L1064,220@8640L210:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.ui.Alignment.Vertical centerVertically2 = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                                androidx.compose.ui.Modifier.Companion companion3 = androidx.compose.ui.Modifier.INSTANCE;
                                androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy2 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically2, composer3, 48);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion3);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor6);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, rowMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                                    m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                                    m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash6);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -355435572, "C199@7633L610,212@8268L39,213@8332L265:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.ui.Modifier m248backgroundbw27NRU = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(22)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.12f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                                androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                int currentCompositeKeyHash7 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap7 = composer3.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier7 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m248backgroundbw27NRU);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                composer3.startReusableNode();
                                if (composer3.getInserting()) {
                                    composer3.createNode(constructor7);
                                } else {
                                    composer3.useNode();
                                }
                                androidx.compose.runtime.Composer m3405constructorimpl7 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, currentCompositionLocalMap7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (m3405constructorimpl7.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl7.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash7))) {
                                    m3405constructorimpl7.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash7));
                                    m3405constructorimpl7.apply(java.lang.Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash7);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, materializeModifier7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2135454813, "C205@7941L276:KnowledgeBaseScreen.kt#tolt0g");
                                androidx.compose.material3.IconKt.m1843Iconww6aTOc(androidx.compose.material.icons.filled.TimerKt.getTimer(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), composer3, 3504, 0);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getReadTimeMinutes() + " min read", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 0, 131026);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.material3.TextKt.m2386Text4IGK_g("Read More", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200070, 0, 131026);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                composer3.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                    return;
                                }
                                return;
                            }
                            composer3.skipToGroupEnd();
                        }
                    }, startRestartGroup, 54), startRestartGroup, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 16);
                    composer2 = startRestartGroup;
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    function04 = function03;
                } else {
                    startRestartGroup.skipToGroupEnd();
                    function04 = function02;
                    companion = modifier2;
                    composer2 = startRestartGroup;
                }
                endRestartGroup = composer2.endRestartGroup();
                if (endRestartGroup != null) {
                    endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                            kotlin.Unit ArticleCard$lambda$9;
                            ArticleCard$lambda$9 = com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.ArticleCard$lambda$9(com.app.a1bat.domain.model.Article.this, function04, companion, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                            return ArticleCard$lambda$9;
                        }
                    });
                    return;
                }
                return;
            }
            modifier2 = modifier;
            if ((i3 & 147) == 146) {
            }
            if (i5 != 0) {
            }
            if (i4 != 0) {
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            float f2 = 20;
            androidx.compose.ui.Modifier clip2 = androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(6), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)));
            startRestartGroup.startReplaceGroup(-367895137);
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
            rememberedValue = startRestartGroup.rememberedValue();
            if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            }
            startRestartGroup.endReplaceGroup();
            androidx.compose.material3.CardKt.Card(androidx.compose.foundation.ClickableKt.m280clickableO2vRcR0$default(clip2, (androidx.compose.foundation.interaction.MutableInteractionSource) rememberedValue, null, false, null, null, function03, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), androidx.compose.material3.CardDefaults.INSTANCE.m1521cardColorsro_MJ88(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0L, 0L, 0L, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 12) | 6, 14), androidx.compose.material3.CardDefaults.INSTANCE.m1522cardElevationaqJV_2Y(androidx.compose.ui.unit.Dp.m6803constructorimpl(0), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 18) | 6, 62), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(741582720, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.ColumnScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$ArticleCard$3
                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.ColumnScope columnScope, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                    invoke(columnScope, composer3, num.intValue());
                    return kotlin.Unit.INSTANCE;
                }

                public final void invoke(androidx.compose.foundation.layout.ColumnScope Card, androidx.compose.runtime.Composer composer3, int i6) {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Card, "$this$Card");
                    androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C135@5119L3773:KnowledgeBaseScreen.kt#tolt0g");
                    if ((i6 & 17) != 16 || !composer3.getSkipping()) {
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventStart(741582720, i6, -1, "com.app.a1bat.ui.screens.knowledge.ArticleCard.<anonymous> (KnowledgeBaseScreen.kt:135)");
                        }
                        com.app.a1bat.domain.model.Article article2 = com.app.a1bat.domain.model.Article.this;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                        androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                        androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion2);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                            m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                            m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                        androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 891908015, "C136@5140L1427,174@6581L2301:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(190));
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m725height3ABfNKs);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor2);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                            m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                            m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2091136218, "C141@5285L239,147@5541L373,157@5931L622:KnowledgeBaseScreen.kt#tolt0g");
                        coil.compose.SingletonAsyncImageKt.m7328AsyncImagegl8XCv8(article2.getImageUrl(), article2.getTitle(), androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, null, 0, false, null, composer3, 1573248, 0, 4024);
                        androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU())}), 300.0f, 0.0f, 0, 12, (java.lang.Object) null), null, 0.0f, 6, null), composer3, 6);
                        float f22 = 12;
                        androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0.85f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(8))), androidx.compose.ui.unit.Dp.m6803constructorimpl(10), androidx.compose.ui.unit.Dp.m6803constructorimpl(4));
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m695paddingVpY3zN4);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor3);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                            m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                            m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 916988200, "C164@6272L263:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getCategory(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(10), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.3d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 12782976, 0, 130898);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        float f3 = 16;
                        androidx.compose.ui.Modifier m698paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m698paddingqDBjuR0$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 2, null);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m698paddingqDBjuR0$default);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor4);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                            m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                            m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                        androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2092576447, "C177@6709L234,184@6960L40,185@7017L225,192@7259L41,193@7317L1551:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getTitle(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(17), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(23), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 6, 130002);
                        float f4 = 6;
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                        androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getContent(), (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4285231744L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(19), 0, false, 2, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 3078, 121842);
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)), composer3, 6);
                        androidx.compose.ui.Modifier fillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                        androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical spaceBetween = androidx.compose.foundation.layout.Arrangement.INSTANCE.getSpaceBetween();
                        androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer3, 54);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, fillMaxWidth$default);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor5);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                            m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                            m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash5);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                        androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 918292928, "C198@7555L1064,220@8640L210:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.ui.Alignment.Vertical centerVertically2 = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                        androidx.compose.ui.Modifier.Companion companion3 = androidx.compose.ui.Modifier.INSTANCE;
                        androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy2 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically2, composer3, 48);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion3);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor6);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, rowMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                            m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                            m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash6);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                        androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -355435572, "C199@7633L610,212@8268L39,213@8332L265:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.ui.Modifier m248backgroundbw27NRU = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(22)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.12f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                        androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash7 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap7 = composer3.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier7 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m248backgroundbw27NRU);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer3.startReusableNode();
                        if (composer3.getInserting()) {
                            composer3.createNode(constructor7);
                        } else {
                            composer3.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl7 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, currentCompositionLocalMap7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl7.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl7.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash7))) {
                            m3405constructorimpl7.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash7));
                            m3405constructorimpl7.apply(java.lang.Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash7);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, materializeModifier7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2135454813, "C205@7941L276:KnowledgeBaseScreen.kt#tolt0g");
                        androidx.compose.material3.IconKt.m1843Iconww6aTOc(androidx.compose.material.icons.filled.TimerKt.getTimer(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), composer3, 3504, 0);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                        androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getReadTimeMinutes() + " min read", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 0, 131026);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.material3.TextKt.m2386Text4IGK_g("Read More", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200070, 0, 131026);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer3.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    composer3.skipToGroupEnd();
                }
            }, startRestartGroup, 54), startRestartGroup, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 16);
            composer2 = startRestartGroup;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            function04 = function03;
            endRestartGroup = composer2.endRestartGroup();
            if (endRestartGroup != null) {
            }
        }
        function02 = function0;
        i4 = i2 & 4;
        if (i4 == 0) {
        }
        modifier2 = modifier;
        if ((i3 & 147) == 146) {
        }
        if (i5 != 0) {
        }
        if (i4 != 0) {
        }
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
        }
        float f22 = 20;
        androidx.compose.ui.Modifier clip22 = androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(6), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)));
        startRestartGroup.startReplaceGroup(-367895137);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):KnowledgeBaseScreen.kt#9igjgp");
        rememberedValue = startRestartGroup.rememberedValue();
        if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
        }
        startRestartGroup.endReplaceGroup();
        androidx.compose.material3.CardKt.Card(androidx.compose.foundation.ClickableKt.m280clickableO2vRcR0$default(clip22, (androidx.compose.foundation.interaction.MutableInteractionSource) rememberedValue, null, false, null, null, function03, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f22)), androidx.compose.material3.CardDefaults.INSTANCE.m1521cardColorsro_MJ88(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0L, 0L, 0L, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 12) | 6, 14), androidx.compose.material3.CardDefaults.INSTANCE.m1522cardElevationaqJV_2Y(androidx.compose.ui.unit.Dp.m6803constructorimpl(0), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, startRestartGroup, (androidx.compose.material3.CardDefaults.$stable << 18) | 6, 62), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(741582720, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.ColumnScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt$ArticleCard$3
            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.ColumnScope columnScope, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                invoke(columnScope, composer3, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.layout.ColumnScope Card, androidx.compose.runtime.Composer composer3, int i6) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Card, "$this$Card");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C135@5119L3773:KnowledgeBaseScreen.kt#tolt0g");
                if ((i6 & 17) != 16 || !composer3.getSkipping()) {
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventStart(741582720, i6, -1, "com.app.a1bat.ui.screens.knowledge.ArticleCard.<anonymous> (KnowledgeBaseScreen.kt:135)");
                    }
                    com.app.a1bat.domain.model.Article article2 = com.app.a1bat.domain.model.Article.this;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                    androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion2);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                        m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                        m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 891908015, "C136@5140L1427,174@6581L2301:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(190));
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m725height3ABfNKs);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor2);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                        m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                        m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2091136218, "C141@5285L239,147@5541L373,157@5931L622:KnowledgeBaseScreen.kt#tolt0g");
                    coil.compose.SingletonAsyncImageKt.m7328AsyncImagegl8XCv8(article2.getImageUrl(), article2.getTitle(), androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, null, 0, false, null, composer3, 1573248, 0, 4024);
                    androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU())}), 300.0f, 0.0f, 0, 12, (java.lang.Object) null), null, 0.0f, 6, null), composer3, 6);
                    float f222 = 12;
                    androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f222)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0.85f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(8))), androidx.compose.ui.unit.Dp.m6803constructorimpl(10), androidx.compose.ui.unit.Dp.m6803constructorimpl(4));
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m695paddingVpY3zN4);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor3);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                        m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                        m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 916988200, "C164@6272L263:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getCategory(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(10), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.3d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 12782976, 0, 130898);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    float f3 = 16;
                    androidx.compose.ui.Modifier m698paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m698paddingqDBjuR0$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), 2, null);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m698paddingqDBjuR0$default);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor4);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                        m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                        m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2092576447, "C177@6709L234,184@6960L40,185@7017L225,192@7259L41,193@7317L1551:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getTitle(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(17), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(23), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 6, 130002);
                    float f4 = 6;
                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                    androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getContent(), (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4285231744L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(19), 0, false, 2, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 3078, 121842);
                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f222)), composer3, 6);
                    androidx.compose.ui.Modifier fillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                    androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical spaceBetween = androidx.compose.foundation.layout.Arrangement.INSTANCE.getSpaceBetween();
                    androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer3, 54);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, fillMaxWidth$default);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor5);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                        m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                        m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash5);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                    androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 918292928, "C198@7555L1064,220@8640L210:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.ui.Alignment.Vertical centerVertically2 = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                    androidx.compose.ui.Modifier.Companion companion3 = androidx.compose.ui.Modifier.INSTANCE;
                    androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy2 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically2, composer3, 48);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion3);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor6);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, rowMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                        m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                        m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash6);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                    androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -355435572, "C199@7633L610,212@8268L39,213@8332L265:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.ui.Modifier m248backgroundbw27NRU = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(22)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.12f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                    androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    int currentCompositeKeyHash7 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap7 = composer3.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier7 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m248backgroundbw27NRU);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composer3.startReusableNode();
                    if (composer3.getInserting()) {
                        composer3.createNode(constructor7);
                    } else {
                        composer3.useNode();
                    }
                    androidx.compose.runtime.Composer m3405constructorimpl7 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, currentCompositionLocalMap7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (m3405constructorimpl7.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl7.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash7))) {
                        m3405constructorimpl7.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash7));
                        m3405constructorimpl7.apply(java.lang.Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash7);
                    }
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, materializeModifier7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 2135454813, "C205@7941L276:KnowledgeBaseScreen.kt#tolt0g");
                    androidx.compose.material3.IconKt.m1843Iconww6aTOc(androidx.compose.material.icons.filled.TimerKt.getTimer(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f222)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), composer3, 3504, 0);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer3, 6);
                    androidx.compose.material3.TextKt.m2386Text4IGK_g(article2.getReadTimeMinutes() + " min read", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 0, 131026);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.material3.TextKt.m2386Text4IGK_g("Read More", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200070, 0, 131026);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer3.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                        return;
                    }
                    return;
                }
                composer3.skipToGroupEnd();
            }
        }, startRestartGroup, 54), startRestartGroup, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 16);
        composer2 = startRestartGroup;
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
        }
        function04 = function03;
        endRestartGroup = composer2.endRestartGroup();
        if (endRestartGroup != null) {
        }
    }

    private static final java.util.List<com.app.a1bat.domain.model.Article> KnowledgeBaseScreen$lambda$0(androidx.compose.runtime.State<? extends java.util.List<com.app.a1bat.domain.model.Article>> state) {
        return state.getValue();
    }
}
