package com.app.a1bat.ui.screens.booking;

/* compiled from: BookConsultationScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class BookConsultationScreenKt$BookConsultationScreen$6 implements kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.PaddingValues, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ com.app.a1bat.ui.screens.booking.BookingViewModel $bookingViewModel;
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.String> $companyName$delegate;
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.String> $email$delegate;
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.String> $firstName$delegate;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $formAlpha;
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.String> $lastName$delegate;
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.String> $notes$delegate;
    final /* synthetic */ androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> $service$delegate;

    BookConsultationScreenKt$BookConsultationScreen$6(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state, androidx.compose.runtime.MutableState<java.lang.String> mutableState, androidx.compose.runtime.MutableState<java.lang.String> mutableState2, androidx.compose.runtime.MutableState<java.lang.String> mutableState3, androidx.compose.runtime.MutableState<java.lang.String> mutableState4, androidx.compose.runtime.MutableState<java.lang.String> mutableState5, com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel) {
        this.$formAlpha = animatable;
        this.$service$delegate = state;
        this.$firstName$delegate = mutableState;
        this.$lastName$delegate = mutableState2;
        this.$email$delegate = mutableState3;
        this.$companyName$delegate = mutableState4;
        this.$notes$delegate = mutableState5;
        this.$bookingViewModel = bookingViewModel;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.PaddingValues paddingValues, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(paddingValues, composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:144:0x101d  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x1029  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x10ac  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x11e8  */
    /* JADX WARN: Removed duplicated region for block: B:164:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:166:0x10b1  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x102d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void invoke(androidx.compose.foundation.layout.PaddingValues innerPadding, androidx.compose.runtime.Composer composer, int i) {
        int i2;
        com.app.a1bat.domain.model.ConsultingService BookConsultationScreen$lambda$0;
        float f;
        java.lang.String str;
        java.lang.String str2;
        androidx.compose.runtime.MutableState<java.lang.String> mutableState;
        androidx.compose.runtime.MutableState<java.lang.String> mutableState2;
        com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel;
        androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state;
        java.lang.String str3;
        java.lang.String str4;
        java.lang.String str5;
        java.lang.String str6;
        androidx.compose.runtime.MutableState<java.lang.String> mutableState3;
        androidx.compose.runtime.MutableState<java.lang.String> mutableState4;
        androidx.compose.runtime.MutableState<java.lang.String> mutableState5;
        int i3;
        java.lang.String BookConsultationScreen$lambda$3;
        final androidx.compose.runtime.MutableState<java.lang.String> mutableState6;
        java.lang.String BookConsultationScreen$lambda$6;
        final androidx.compose.runtime.MutableState<java.lang.String> mutableState7;
        java.lang.String BookConsultationScreen$lambda$9;
        final androidx.compose.runtime.MutableState<java.lang.String> mutableState8;
        java.lang.String BookConsultationScreen$lambda$12;
        final androidx.compose.runtime.MutableState<java.lang.String> mutableState9;
        java.lang.String BookConsultationScreen$lambda$15;
        final androidx.compose.runtime.MutableState<java.lang.String> mutableState10;
        java.lang.String BookConsultationScreen$lambda$32;
        boolean z;
        int currentCompositeKeyHash;
        androidx.compose.runtime.Composer m3405constructorimpl;
        boolean changed;
        java.lang.Object obj;
        float f2;
        final boolean z2;
        java.lang.String BookConsultationScreen$lambda$62;
        java.lang.String BookConsultationScreen$lambda$92;
        androidx.compose.runtime.Composer composer2 = composer;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C221@9485L21,216@9296L9914:BookConsultationScreen.kt#rof5hh");
        if ((i & 6) == 0) {
            i2 = i | (composer2.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i2 & 19) != 18 || !composer2.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1680462652, i2, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous> (BookConsultationScreen.kt:216)");
            }
            androidx.compose.ui.Modifier alpha = androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.ScrollKt.verticalScroll$default(androidx.compose.foundation.layout.PaddingKt.padding(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.ColorKt.Color(4293980917L), null, 2, null), innerPadding), androidx.compose.foundation.ScrollKt.rememberScrollState(0, composer2, 0, 1), false, null, false, 14, null), this.$formAlpha.getValue().floatValue());
            androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state2 = this.$service$delegate;
            androidx.compose.runtime.MutableState<java.lang.String> mutableState11 = this.$firstName$delegate;
            androidx.compose.runtime.MutableState<java.lang.String> mutableState12 = this.$lastName$delegate;
            androidx.compose.runtime.MutableState<java.lang.String> mutableState13 = this.$email$delegate;
            androidx.compose.runtime.MutableState<java.lang.String> mutableState14 = this.$companyName$delegate;
            androidx.compose.runtime.MutableState<java.lang.String> mutableState15 = this.$notes$delegate;
            com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel2 = this.$bookingViewModel;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer2, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer2.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, alpha);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                composer2.createNode(constructor);
            } else {
                composer2.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -384784025, "C88@4444L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 611824888, "C224@9572L1867,268@11453L41,270@11508L1411,307@12933L41,309@12988L1479,347@14481L41,349@14536L2413,403@16963L41,406@17118L1621,444@18753L41,446@18808L337,456@19159L41:BookConsultationScreen.kt#rof5hh");
            float f3 = 20;
            androidx.compose.ui.Modifier m697paddingqDBjuR0 = androidx.compose.foundation.layout.PaddingKt.m697paddingqDBjuR0(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryMedium())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(28));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, m697paddingqDBjuR0);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                composer2.createNode(constructor2);
            } else {
                composer2.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash2);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 463607269, "C232@9905L1520:BookConsultationScreen.kt#rof5hh");
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer2, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, companion);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                composer2.createNode(constructor3);
            } else {
                composer2.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash3);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -384784025, "C88@4444L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2112937099, "C258@11047L40,259@11108L299:BookConsultationScreen.kt#rof5hh");
            BookConsultationScreen$lambda$0 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$0(state2);
            composer2.startReplaceGroup(-760896024);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "*234@9973L720,250@10718L40,251@10783L221");
            if (BookConsultationScreen$lambda$0 != null) {
                androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.15f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(6))), androidx.compose.ui.unit.Dp.m6803constructorimpl(10), androidx.compose.ui.unit.Dp.m6803constructorimpl(3));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, m695paddingVpY3zN4);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor4);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                    m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                    m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash4);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -748564403, "C242@10368L299:BookConsultationScreen.kt#rof5hh");
                f = f3;
                str = "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo";
                str2 = "C73@3429L9:Box.kt#2w3rfo";
                mutableState = mutableState12;
                mutableState2 = mutableState13;
                bookingViewModel = bookingViewModel2;
                state = state2;
                str3 = "C88@4444L9:Column.kt#2w3rfo";
                str4 = "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo";
                str5 = "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh";
                str6 = "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp";
                mutableState3 = mutableState11;
                mutableState4 = mutableState14;
                mutableState5 = mutableState15;
                i3 = 6;
                androidx.compose.material3.TextKt.m2386Text4IGK_g(BookConsultationScreen$lambda$0.getCategory(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(10), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.5d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 12782976, 0, 130898);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(8)), composer, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g(BookConsultationScreen$lambda$0.getTitle(), (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), androidx.compose.ui.unit.TextUnitKt.getSp(16), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200064, 0, 131026);
                composer2 = composer;
                kotlin.Unit unit = kotlin.Unit.INSTANCE;
                kotlin.Unit unit2 = kotlin.Unit.INSTANCE;
            } else {
                str2 = "C73@3429L9:Box.kt#2w3rfo";
                str3 = "C88@4444L9:Column.kt#2w3rfo";
                i3 = 6;
                str = "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo";
                str4 = "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo";
                mutableState = mutableState12;
                mutableState2 = mutableState13;
                str5 = "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh";
                str6 = "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp";
                f = f3;
                mutableState3 = mutableState11;
                mutableState4 = mutableState14;
                mutableState5 = mutableState15;
                bookingViewModel = bookingViewModel2;
                state = state2;
            }
            composer2.endReplaceGroup();
            float f4 = i3;
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer2, i3);
            androidx.compose.material3.TextKt.m2386Text4IGK_g("Fill out the form and a senior consultant will confirm your appointment within 24 hours.", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(19), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3462, 6, 130034);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer, i3);
            float f5 = 16;
            androidx.compose.ui.Modifier m694padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f5), 0.0f, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f4), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f))), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), null, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
            java.lang.String str7 = str;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, str7);
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            java.lang.String str8 = str5;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m694padding3ABfNKs);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            java.lang.String str9 = str6;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor5);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash5);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            java.lang.String str10 = str2;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, str10);
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 465532865, "C279@11861L1044:BookConsultationScreen.kt#rof5hh");
            java.lang.String str11 = str4;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, str11);
            androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy3 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash7 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, companion2);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor6);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl7 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, columnMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl7.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl7.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash7))) {
                m3405constructorimpl7.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash7));
                m3405constructorimpl7.apply(java.lang.Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash6);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            java.lang.String str12 = str3;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, str12);
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance3 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2111011503, "C280@11890L267,287@12178L41,291@12342L18,289@12241L283,296@12545L41,299@12707L17,297@12607L280:BookConsultationScreen.kt#rof5hh");
            androidx.compose.material3.TextKt.m2386Text4IGK_g("Personal Details", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(15), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.3d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 12782982, 0, 130898);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f5)), composer, 6);
            BookConsultationScreen$lambda$3 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$3(mutableState3);
            composer.startReplaceGroup(-760820321);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            java.lang.Object rememberedValue = composer.rememberedValue();
            if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                mutableState6 = mutableState3;
                rememberedValue = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj2) {
                        kotlin.Unit invoke$lambda$26$lambda$9$lambda$8$lambda$5$lambda$4;
                        invoke$lambda$26$lambda$9$lambda$8$lambda$5$lambda$4 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$9$lambda$8$lambda$5$lambda$4(androidx.compose.runtime.MutableState.this, (java.lang.String) obj2);
                        return invoke$lambda$26$lambda$9$lambda$8$lambda$5$lambda$4;
                    }
                };
                composer.updateRememberedValue(rememberedValue);
            } else {
                mutableState6 = mutableState3;
            }
            composer.endReplaceGroup();
            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.m7384PremiumTextFieldKznfkUg(BookConsultationScreen$lambda$3, (kotlin.jvm.functions.Function1) rememberedValue, "First Name", androidx.compose.material.icons.filled.PersonKt.getPerson(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), true, 0, composer, 25008, 32);
            float f6 = 12;
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
            BookConsultationScreen$lambda$6 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$6(mutableState);
            composer.startReplaceGroup(-760808642);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            java.lang.Object rememberedValue2 = composer.rememberedValue();
            if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                mutableState7 = mutableState;
                rememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj2) {
                        kotlin.Unit invoke$lambda$26$lambda$9$lambda$8$lambda$7$lambda$6;
                        invoke$lambda$26$lambda$9$lambda$8$lambda$7$lambda$6 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$9$lambda$8$lambda$7$lambda$6(androidx.compose.runtime.MutableState.this, (java.lang.String) obj2);
                        return invoke$lambda$26$lambda$9$lambda$8$lambda$7$lambda$6;
                    }
                };
                composer.updateRememberedValue(rememberedValue2);
            } else {
                mutableState7 = mutableState;
            }
            composer.endReplaceGroup();
            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.m7384PremiumTextFieldKznfkUg(BookConsultationScreen$lambda$6, (kotlin.jvm.functions.Function1) rememberedValue2, "Last Name", androidx.compose.material.icons.filled.PersonKt.getPerson(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), true, 0, composer, 25008, 32);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
            androidx.compose.ui.Modifier m694padding3ABfNKs2 = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f5), 0.0f, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f4), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f))), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), null, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, str7);
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy4 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash8 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap7 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier7 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m694padding3ABfNKs2);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor7);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl8 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl8, maybeCachedBoxMeasurePolicy4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl8, currentCompositionLocalMap7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl8.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl8.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash8))) {
                m3405constructorimpl8.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash8));
                m3405constructorimpl8.apply(java.lang.Integer.valueOf(currentCompositeKeyHash8), setCompositeKeyHash7);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl8, materializeModifier7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, str10);
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance4 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 467003133, "C318@13341L1112:BookConsultationScreen.kt#rof5hh");
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, str11);
            androidx.compose.ui.Modifier.Companion companion3 = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy4 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash9 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap8 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier8 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, companion3);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor8 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor8);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl9 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl9, columnMeasurePolicy4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl9, currentCompositionLocalMap8, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash8 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl9.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl9.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash9))) {
                m3405constructorimpl9.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash9));
                m3405constructorimpl9.apply(java.lang.Integer.valueOf(currentCompositeKeyHash9), setCompositeKeyHash8);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl9, materializeModifier8, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, str12);
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance4 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2109541235, "C319@13370L270,326@13661L41,330@13821L14,328@13724L336,336@14081L41,339@14246L20,337@14143L292:BookConsultationScreen.kt#rof5hh");
            final androidx.compose.runtime.MutableState<java.lang.String> mutableState16 = mutableState6;
            final androidx.compose.runtime.MutableState<java.lang.String> mutableState17 = mutableState7;
            androidx.compose.material3.TextKt.m2386Text4IGK_g("Contact Information", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(15), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.3d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 12782982, 0, 130898);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f5)), composer, 6);
            BookConsultationScreen$lambda$9 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$9(mutableState2);
            androidx.compose.ui.graphics.vector.ImageVector email = androidx.compose.material.icons.filled.EmailKt.getEmail(androidx.compose.material.icons.Icons.INSTANCE.getDefault());
            int m6503getEmailPjHm6EE = androidx.compose.ui.text.input.KeyboardType.INSTANCE.m6503getEmailPjHm6EE();
            composer.startReplaceGroup(-760772997);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            java.lang.Object rememberedValue3 = composer.rememberedValue();
            if (rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                mutableState8 = mutableState2;
                rememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj2) {
                        kotlin.Unit invoke$lambda$26$lambda$15$lambda$14$lambda$11$lambda$10;
                        invoke$lambda$26$lambda$15$lambda$14$lambda$11$lambda$10 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$15$lambda$14$lambda$11$lambda$10(androidx.compose.runtime.MutableState.this, (java.lang.String) obj2);
                        return invoke$lambda$26$lambda$15$lambda$14$lambda$11$lambda$10;
                    }
                };
                composer.updateRememberedValue(rememberedValue3);
            } else {
                mutableState8 = mutableState2;
            }
            composer.endReplaceGroup();
            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.m7384PremiumTextFieldKznfkUg(BookConsultationScreen$lambda$9, (kotlin.jvm.functions.Function1) rememberedValue3, "Email Address", email, true, m6503getEmailPjHm6EE, composer, 221616, 0);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
            BookConsultationScreen$lambda$12 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$12(mutableState4);
            composer.startReplaceGroup(-760759391);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            java.lang.Object rememberedValue4 = composer.rememberedValue();
            if (rememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                mutableState9 = mutableState4;
                rememberedValue4 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj2) {
                        kotlin.Unit invoke$lambda$26$lambda$15$lambda$14$lambda$13$lambda$12;
                        invoke$lambda$26$lambda$15$lambda$14$lambda$13$lambda$12 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$15$lambda$14$lambda$13$lambda$12(androidx.compose.runtime.MutableState.this, (java.lang.String) obj2);
                        return invoke$lambda$26$lambda$15$lambda$14$lambda$13$lambda$12;
                    }
                };
                composer.updateRememberedValue(rememberedValue4);
            } else {
                mutableState9 = mutableState4;
            }
            composer.endReplaceGroup();
            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.m7384PremiumTextFieldKznfkUg(BookConsultationScreen$lambda$12, (kotlin.jvm.functions.Function1) rememberedValue4, "Company Name", androidx.compose.material.icons.filled.BusinessKt.getBusiness(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), false, 0, composer, 25008, 32);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
            androidx.compose.ui.Modifier m694padding3ABfNKs3 = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f5), 0.0f, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f4), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f))), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), null, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, str7);
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy5 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash10 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap9 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier9 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m694padding3ABfNKs3);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor9 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor9);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl10 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl10, maybeCachedBoxMeasurePolicy5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl10, currentCompositionLocalMap9, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash9 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl10.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl10.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash10))) {
                m3405constructorimpl10.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash10));
                m3405constructorimpl10.apply(java.lang.Integer.valueOf(currentCompositeKeyHash10), setCompositeKeyHash9);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl10, materializeModifier9, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, str10);
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance5 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 468567703, "C358@14889L2046:BookConsultationScreen.kt#rof5hh");
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, str11);
            androidx.compose.ui.Modifier.Companion companion4 = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy5 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash11 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap10 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier10 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, companion4);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor10 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor10);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl11 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl11, columnMeasurePolicy5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl11, currentCompositionLocalMap10, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash10 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl11.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl11.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash11))) {
                m3405constructorimpl11.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash11));
                m3405constructorimpl11.apply(java.lang.Integer.valueOf(currentCompositeKeyHash11), setCompositeKeyHash10);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl11, materializeModifier10, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, str12);
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance5 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2107976665, "C359@14918L478,369@15417L41,392@16534L361,372@15577L14,370@15479L1438:BookConsultationScreen.kt#rof5hh");
            androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
            androidx.compose.ui.Modifier.Companion companion5 = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composer, 48);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            int currentCompositeKeyHash12 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap11 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier11 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, companion5);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor11 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor11);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl12 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl12, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl12, currentCompositionLocalMap11, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash11 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl12.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl12.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash12))) {
                m3405constructorimpl12.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash12));
                m3405constructorimpl12.apply(java.lang.Integer.valueOf(currentCompositeKeyHash12), setCompositeKeyHash11);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl12, materializeModifier11, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -407840262, "C101@5126L9:Row.kt#2w3rfo");
            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 839751549, "C360@14996L228,366@15249L39,367@15313L61:BookConsultationScreen.kt#rof5hh");
            final androidx.compose.runtime.MutableState<java.lang.String> mutableState18 = mutableState8;
            final androidx.compose.runtime.MutableState<java.lang.String> mutableState19 = mutableState9;
            androidx.compose.material3.TextKt.m2386Text4IGK_g("Notes", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(15), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200070, 0, 131026);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer, 6);
            androidx.compose.material3.TextKt.m2386Text4IGK_g("Optional", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3462, 0, 131058);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f5)), composer, 6);
            BookConsultationScreen$lambda$15 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$15(mutableState5);
            androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(androidx.compose.material3.MenuKt.InTransitionDuration));
            androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14));
            androidx.compose.material3.TextFieldColors m2036colors0hiis_0 = androidx.compose.material3.OutlinedTextFieldDefaults.INSTANCE.m2036colors0hiis_0(0L, 0L, 0L, 0L, androidx.compose.ui.graphics.ColorKt.Color(4294638588L), androidx.compose.ui.graphics.ColorKt.Color(4294638588L), 0L, 0L, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.graphics.ColorKt.Color(4293454576L), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer, 100884480, 432, 0, 0, 3072, 2147477199, 4095);
            composer.startReplaceGroup(-760716805);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            java.lang.Object rememberedValue5 = composer.rememberedValue();
            if (rememberedValue5 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                mutableState10 = mutableState5;
                rememberedValue5 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj2) {
                        kotlin.Unit invoke$lambda$26$lambda$20$lambda$19$lambda$18$lambda$17;
                        invoke$lambda$26$lambda$20$lambda$19$lambda$18$lambda$17 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$20$lambda$19$lambda$18$lambda$17(androidx.compose.runtime.MutableState.this, (java.lang.String) obj2);
                        return invoke$lambda$26$lambda$20$lambda$19$lambda$18$lambda$17;
                    }
                };
                composer.updateRememberedValue(rememberedValue5);
            } else {
                mutableState10 = mutableState5;
            }
            composer.endReplaceGroup();
            final androidx.compose.runtime.MutableState<java.lang.String> mutableState20 = mutableState10;
            androidx.compose.material3.OutlinedTextFieldKt.OutlinedTextField(BookConsultationScreen$lambda$15, (kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit>) rememberedValue5, m725height3ABfNKs, false, false, (androidx.compose.ui.text.TextStyle) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) com.app.a1bat.ui.screens.booking.ComposableSingletons$BookConsultationScreenKt.INSTANCE.m7394getLambda4$app_release(), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) com.app.a1bat.ui.screens.booking.ComposableSingletons$BookConsultationScreenKt.INSTANCE.m7395getLambda5$app_release(), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, false, (androidx.compose.ui.text.input.VisualTransformation) null, (androidx.compose.foundation.text.KeyboardOptions) null, (androidx.compose.foundation.text.KeyboardActions) null, false, 0, 0, (androidx.compose.foundation.interaction.MutableInteractionSource) null, (androidx.compose.ui.graphics.Shape) m977RoundedCornerShape0680j_4, m2036colors0hiis_0, composer, 113246640, 0, 0, 2096760);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            float f7 = 24;
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f7)), composer, 6);
            BookConsultationScreen$lambda$32 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$3(mutableState16);
            if (!kotlin.text.StringsKt.isBlank(BookConsultationScreen$lambda$32)) {
                BookConsultationScreen$lambda$62 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$6(mutableState17);
                if (!kotlin.text.StringsKt.isBlank(BookConsultationScreen$lambda$62)) {
                    BookConsultationScreen$lambda$92 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$9(mutableState18);
                    if (!kotlin.text.StringsKt.isBlank(BookConsultationScreen$lambda$92)) {
                        z = true;
                        androidx.compose.ui.Modifier m696paddingVpY3zN4$default = androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f5), 0.0f, 2, null);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, str7);
                        androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy6 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
                        currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap12 = composer.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier12 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m696paddingVpY3zN4$default);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor12 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
                        if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer.startReusableNode();
                        if (!composer.getInserting()) {
                            composer.createNode(constructor12);
                        } else {
                            composer.useNode();
                        }
                        m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap12, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash12 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (!m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                            m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                            m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash12);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier12, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, str10);
                        androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance6 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 470917100, "C429@18171L196,412@17314L636,434@18429L296,411@17276L1449:BookConsultationScreen.kt#rof5hh");
                        androidx.compose.ui.Modifier m725height3ABfNKs2 = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(58));
                        androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_42 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f5));
                        androidx.compose.material3.ButtonColors m1501buttonColorsro_MJ88 = androidx.compose.material3.ButtonDefaults.INSTANCE.m1501buttonColorsro_MJ88(!z ? com.app.a1bat.ui.theme.ColorKt.getPrimaryDark() : androidx.compose.ui.graphics.ColorKt.Color(4291941851L), 0L, androidx.compose.ui.graphics.ColorKt.Color(4291941851L), 0L, composer, (androidx.compose.material3.ButtonDefaults.$stable << 12) | 384, 10);
                        composer.startReplaceGroup(985022602);
                        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
                        final androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state3 = state;
                        final com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel3 = bookingViewModel;
                        changed = composer.changed(z) | composer.changed(state3) | composer.changedInstance(bookingViewModel3);
                        java.lang.Object rememberedValue6 = composer.rememberedValue();
                        if (!changed || rememberedValue6 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                            f2 = f7;
                            final boolean z3 = z;
                            obj = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda5
                                @Override // kotlin.jvm.functions.Function0
                                public final java.lang.Object invoke() {
                                    kotlin.Unit invoke$lambda$26$lambda$25$lambda$24$lambda$23;
                                    invoke$lambda$26$lambda$25$lambda$24$lambda$23 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$25$lambda$24$lambda$23(z3, bookingViewModel3, state3, mutableState16, mutableState17, mutableState18, mutableState19, mutableState20);
                                    return invoke$lambda$26$lambda$25$lambda$24$lambda$23;
                                }
                            };
                            z2 = z3;
                            composer.updateRememberedValue(obj);
                        } else {
                            obj = rememberedValue6;
                            f2 = f7;
                            z2 = z;
                        }
                        composer.endReplaceGroup();
                        androidx.compose.material3.ButtonKt.Button((kotlin.jvm.functions.Function0) obj, m725height3ABfNKs2, z2, m977RoundedCornerShape0680j_42, m1501buttonColorsro_MJ88, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1123305386, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$1$5$2
                            @Override // kotlin.jvm.functions.Function3
                            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                                invoke(rowScope, composer3, num.intValue());
                                return kotlin.Unit.INSTANCE;
                            }

                            public final void invoke(androidx.compose.foundation.layout.RowScope Button, androidx.compose.runtime.Composer composer3, int i4) {
                                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Button, "$this$Button");
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C435@18451L256:BookConsultationScreen.kt#rof5hh");
                                if ((i4 & 17) != 16 || !composer3.getSkipping()) {
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventStart(1123305386, i4, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (BookConsultationScreen.kt:435)");
                                    }
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g("Confirm Booking", (androidx.compose.ui.Modifier) null, z2 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(16), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 199686, 0, 131026);
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                                        return;
                                    }
                                    return;
                                }
                                composer3.skipToGroupEnd();
                            }
                        }, composer, 54), composer, 805306416, 480);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        composer.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
                        androidx.compose.material3.TextKt.m2386Text4IGK_g("By confirming you agree to our terms of service", androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2), 0.0f, 2, null), androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(11), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, androidx.compose.ui.text.style.TextAlign.m6680boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m6687getCentere0LSkKk()), 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3510, 0, 130544);
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(32)), composer, 6);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        composer.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            return;
                        }
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                        return;
                    }
                }
            }
            z = false;
            androidx.compose.ui.Modifier m696paddingVpY3zN4$default2 = androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f5), 0.0f, 2, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, str7);
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy62 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, str8);
            currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap122 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier122 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m696paddingVpY3zN4$default2);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor122 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, str9);
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
            }
            composer.startReusableNode();
            if (!composer.getInserting()) {
            }
            m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy62, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap122, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash122 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!m3405constructorimpl.getInserting()) {
            }
            m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
            m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash122);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier122, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, str10);
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance62 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 470917100, "C429@18171L196,412@17314L636,434@18429L296,411@17276L1449:BookConsultationScreen.kt#rof5hh");
            androidx.compose.ui.Modifier m725height3ABfNKs22 = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(58));
            androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_422 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f5));
            androidx.compose.material3.ButtonColors m1501buttonColorsro_MJ882 = androidx.compose.material3.ButtonDefaults.INSTANCE.m1501buttonColorsro_MJ88(!z ? com.app.a1bat.ui.theme.ColorKt.getPrimaryDark() : androidx.compose.ui.graphics.ColorKt.Color(4291941851L), 0L, androidx.compose.ui.graphics.ColorKt.Color(4291941851L), 0L, composer, (androidx.compose.material3.ButtonDefaults.$stable << 12) | 384, 10);
            composer.startReplaceGroup(985022602);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
            final androidx.compose.runtime.State state32 = state;
            final com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel32 = bookingViewModel;
            changed = composer.changed(z) | composer.changed(state32) | composer.changedInstance(bookingViewModel32);
            java.lang.Object rememberedValue62 = composer.rememberedValue();
            if (changed) {
            }
            f2 = f7;
            final boolean z32 = z;
            obj = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    kotlin.Unit invoke$lambda$26$lambda$25$lambda$24$lambda$23;
                    invoke$lambda$26$lambda$25$lambda$24$lambda$23 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6.invoke$lambda$26$lambda$25$lambda$24$lambda$23(z32, bookingViewModel32, state32, mutableState16, mutableState17, mutableState18, mutableState19, mutableState20);
                    return invoke$lambda$26$lambda$25$lambda$24$lambda$23;
                }
            };
            z2 = z32;
            composer.updateRememberedValue(obj);
            composer.endReplaceGroup();
            androidx.compose.material3.ButtonKt.Button((kotlin.jvm.functions.Function0) obj, m725height3ABfNKs22, z2, m977RoundedCornerShape0680j_422, m1501buttonColorsro_MJ882, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1123305386, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6$1$5$2
                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                    invoke(rowScope, composer3, num.intValue());
                    return kotlin.Unit.INSTANCE;
                }

                public final void invoke(androidx.compose.foundation.layout.RowScope Button, androidx.compose.runtime.Composer composer3, int i4) {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Button, "$this$Button");
                    androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C435@18451L256:BookConsultationScreen.kt#rof5hh");
                    if ((i4 & 17) != 16 || !composer3.getSkipping()) {
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventStart(1123305386, i4, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (BookConsultationScreen.kt:435)");
                        }
                        androidx.compose.material3.TextKt.m2386Text4IGK_g("Confirm Booking", (androidx.compose.ui.Modifier) null, z2 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(16), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 199686, 0, 131026);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    composer3.skipToGroupEnd();
                }
            }, composer, 54), composer, 805306416, 480);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f6)), composer, 6);
            androidx.compose.material3.TextKt.m2386Text4IGK_g("By confirming you agree to our terms of service", androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2), 0.0f, 2, null), androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(11), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, androidx.compose.ui.text.style.TextAlign.m6680boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m6687getCentere0LSkKk()), 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3510, 0, 130544);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(32)), composer, 6);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
        } else {
            composer2.skipToGroupEnd();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$9$lambda$8$lambda$5$lambda$4(androidx.compose.runtime.MutableState mutableState, java.lang.String it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        mutableState.setValue(it);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$9$lambda$8$lambda$7$lambda$6(androidx.compose.runtime.MutableState mutableState, java.lang.String it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        mutableState.setValue(it);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$15$lambda$14$lambda$11$lambda$10(androidx.compose.runtime.MutableState mutableState, java.lang.String it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        mutableState.setValue(it);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$15$lambda$14$lambda$13$lambda$12(androidx.compose.runtime.MutableState mutableState, java.lang.String it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        mutableState.setValue(it);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$20$lambda$19$lambda$18$lambda$17(androidx.compose.runtime.MutableState mutableState, java.lang.String it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        mutableState.setValue(it);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$26$lambda$25$lambda$24$lambda$23(boolean z, com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, androidx.compose.runtime.State state, androidx.compose.runtime.MutableState mutableState, androidx.compose.runtime.MutableState mutableState2, androidx.compose.runtime.MutableState mutableState3, androidx.compose.runtime.MutableState mutableState4, androidx.compose.runtime.MutableState mutableState5) {
        com.app.a1bat.domain.model.ConsultingService BookConsultationScreen$lambda$0;
        com.app.a1bat.domain.model.ConsultingService BookConsultationScreen$lambda$02;
        com.app.a1bat.domain.model.ConsultingService BookConsultationScreen$lambda$03;
        java.lang.String BookConsultationScreen$lambda$3;
        java.lang.String BookConsultationScreen$lambda$6;
        java.lang.String BookConsultationScreen$lambda$9;
        java.lang.String BookConsultationScreen$lambda$12;
        java.lang.String BookConsultationScreen$lambda$15;
        if (z) {
            BookConsultationScreen$lambda$0 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$0(state);
            if (BookConsultationScreen$lambda$0 != null) {
                BookConsultationScreen$lambda$02 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$0(state);
                kotlin.jvm.internal.Intrinsics.checkNotNull(BookConsultationScreen$lambda$02);
                int id = BookConsultationScreen$lambda$02.getId();
                BookConsultationScreen$lambda$03 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$0(state);
                kotlin.jvm.internal.Intrinsics.checkNotNull(BookConsultationScreen$lambda$03);
                java.lang.String title = BookConsultationScreen$lambda$03.getTitle();
                BookConsultationScreen$lambda$3 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$3(mutableState);
                BookConsultationScreen$lambda$6 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$6(mutableState2);
                BookConsultationScreen$lambda$9 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$9(mutableState3);
                BookConsultationScreen$lambda$12 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$12(mutableState4);
                java.lang.String str = !kotlin.text.StringsKt.isBlank(BookConsultationScreen$lambda$12) ? BookConsultationScreen$lambda$12 : null;
                BookConsultationScreen$lambda$15 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$15(mutableState5);
                bookingViewModel.submitBooking(id, title, BookConsultationScreen$lambda$3, BookConsultationScreen$lambda$6, BookConsultationScreen$lambda$9, str, !kotlin.text.StringsKt.isBlank(BookConsultationScreen$lambda$15) ? BookConsultationScreen$lambda$15 : null);
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
