package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingsScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class BookingsScreenKt$BookingsScreen$4 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> $bookingToDelete$delegate;

    BookingsScreenKt$BookingsScreen$4(androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> mutableState) {
        this.$bookingToDelete$delegate = mutableState;
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$1$lambda$0(androidx.compose.runtime.MutableState mutableState) {
        mutableState.setValue(null);
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C181@7252L26,181@7231L156:BookingsScreen.kt#rof5hh");
        if ((i & 3) == 2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
            return;
        }
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(789741954, i, -1, "com.app.a1bat.ui.screens.booking.BookingsScreen.<anonymous> (BookingsScreen.kt:181)");
        }
        composer.startReplaceGroup(-610157294);
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookingsScreen.kt#9igjgp");
        final androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> mutableState = this.$bookingToDelete$delegate;
        java.lang.Object rememberedValue = composer.rememberedValue();
        if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.booking.BookingsScreenKt$BookingsScreen$4$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    kotlin.Unit invoke$lambda$1$lambda$0;
                    invoke$lambda$1$lambda$0 = com.app.a1bat.ui.screens.booking.BookingsScreenKt$BookingsScreen$4.invoke$lambda$1$lambda$0(androidx.compose.runtime.MutableState.this);
                    return invoke$lambda$1$lambda$0;
                }
            };
            composer.updateRememberedValue(rememberedValue);
        }
        composer.endReplaceGroup();
        androidx.compose.material3.ButtonKt.TextButton((kotlin.jvm.functions.Function0) rememberedValue, null, false, null, null, null, null, null, null, com.app.a1bat.ui.screens.booking.ComposableSingletons$BookingsScreenKt.INSTANCE.m7398getLambda3$app_release(), composer, 805306374, 510);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
    }
}
