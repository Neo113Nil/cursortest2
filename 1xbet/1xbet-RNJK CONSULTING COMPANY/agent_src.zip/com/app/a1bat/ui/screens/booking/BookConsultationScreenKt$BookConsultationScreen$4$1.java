package com.app.a1bat.ui.screens.booking;

/* compiled from: BookConsultationScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class BookConsultationScreenKt$BookConsultationScreen$4$1 implements androidx.compose.ui.input.pointer.PointerInputEventHandler {
    final /* synthetic */ androidx.compose.ui.focus.FocusManager $focusManager;

    BookConsultationScreenKt$BookConsultationScreen$4$1(androidx.compose.ui.focus.FocusManager focusManager) {
        this.$focusManager = focusManager;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$0(androidx.compose.ui.focus.FocusManager focusManager, androidx.compose.ui.geometry.Offset offset) {
        androidx.compose.ui.focus.FocusManager.clearFocus$default(focusManager, false, 1, null);
        return kotlin.Unit.INSTANCE;
    }

    @Override // androidx.compose.ui.input.pointer.PointerInputEventHandler
    public final java.lang.Object invoke(androidx.compose.ui.input.pointer.PointerInputScope pointerInputScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        final androidx.compose.ui.focus.FocusManager focusManager = this.$focusManager;
        java.lang.Object detectTapGestures$default = androidx.compose.foundation.gestures.TapGestureDetectorKt.detectTapGestures$default(pointerInputScope, null, null, null, new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$4$1$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit invoke$lambda$0;
                invoke$lambda$0 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$4$1.invoke$lambda$0(androidx.compose.ui.focus.FocusManager.this, (androidx.compose.ui.geometry.Offset) obj);
                return invoke$lambda$0;
            }
        }, continuation, 7, null);
        return detectTapGestures$default == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? detectTapGestures$default : kotlin.Unit.INSTANCE;
    }
}
