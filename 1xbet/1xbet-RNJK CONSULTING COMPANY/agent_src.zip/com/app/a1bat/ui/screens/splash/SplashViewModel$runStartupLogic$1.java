package com.app.a1bat.ui.screens.splash;

/* compiled from: SplashViewModel.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashViewModel", f = "SplashViewModel.kt", i = {0, 1, 2, 3, 3, 4, 4, 5, 5}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_14, 51, 54, 56, 59, kotlinx.coroutines.internal.LockFreeTaskQueueCore.FROZEN_SHIFT}, m = "runStartupLogic", n = {"this", "this", "this", "this", "fetchedUrl", "this", "fetchedUrl", "this", "fetchedUrl"}, s = {"L$0", "L$0", "L$0", "L$0", "L$1", "L$0", "L$1", "L$0", "L$1"})
/* loaded from: classes3.dex */
final class SplashViewModel$runStartupLogic$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    java.lang.Object L$0;
    java.lang.Object L$1;
    int label;
    /* synthetic */ java.lang.Object result;
    final /* synthetic */ com.app.a1bat.ui.screens.splash.SplashViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    SplashViewModel$runStartupLogic$1(com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashViewModel$runStartupLogic$1> continuation) {
        super(continuation);
        this.this$0 = splashViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.runStartupLogic(this);
    }
}
