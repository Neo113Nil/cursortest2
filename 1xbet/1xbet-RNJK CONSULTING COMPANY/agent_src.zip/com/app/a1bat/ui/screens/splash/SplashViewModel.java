package com.app.a1bat.ui.screens.splash;

/* compiled from: SplashViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u000e\u0010\u0019\u001a\u00020\u001aH\u0082@¢\u0006\u0002\u0010\u001bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\rR\u0016\u0010\u000e\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0010\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\rR\u0016\u0010\u0011\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0013\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\rR\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00160\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\r¨\u0006\u001c"}, d2 = {"Lcom/app/a1bat/ui/screens/splash/SplashViewModel;", "Landroidx/lifecycle/ViewModel;", "remoteConfigRepository", "Lcom/app/a1bat/data/repository/RemoteConfigRepository;", "settingRepository", "Lcom/app/a1bat/data/repository/SettingRepository;", "dataStoreManager", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/data/repository/RemoteConfigRepository;Lcom/app/a1bat/data/repository/SettingRepository;Lcom/app/a1bat/domain/repository/AppRepository;)V", "isOnboardingCompleted", "Lkotlinx/coroutines/flow/StateFlow;", "", "()Lkotlinx/coroutines/flow/StateFlow;", "_isFirstLaunch", "Lkotlinx/coroutines/flow/MutableStateFlow;", "isFirstLaunch", "_destination", "", "destination", "getDestination", "_uiState", "Lcom/app/a1bat/ui/screens/splash/SplashUiState;", "uiState", "getUiState", "runStartupLogic", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SplashViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _destination;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isFirstLaunch;
    private final kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.ui.screens.splash.SplashUiState> _uiState;
    private final com.app.a1bat.domain.repository.AppRepository dataStoreManager;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> destination;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isFirstLaunch;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isOnboardingCompleted;
    private final com.app.a1bat.data.repository.RemoteConfigRepository remoteConfigRepository;
    private final com.app.a1bat.data.repository.SettingRepository settingRepository;
    private final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.ui.screens.splash.SplashUiState> uiState;

    public SplashViewModel(com.app.a1bat.data.repository.RemoteConfigRepository remoteConfigRepository, com.app.a1bat.data.repository.SettingRepository settingRepository, com.app.a1bat.domain.repository.AppRepository dataStoreManager) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(remoteConfigRepository, "remoteConfigRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(settingRepository, "settingRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataStoreManager, "dataStoreManager");
        this.remoteConfigRepository = remoteConfigRepository;
        this.settingRepository = settingRepository;
        this.dataStoreManager = dataStoreManager;
        com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel = this;
        this.isOnboardingCompleted = kotlinx.coroutines.flow.FlowKt.stateIn(dataStoreManager.isOnboardingCompleted(), androidx.lifecycle.ViewModelKt.getViewModelScope(splashViewModel), kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed$default(kotlinx.coroutines.flow.SharingStarted.INSTANCE, androidx.lifecycle.CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), null);
        kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._isFirstLaunch = MutableStateFlow;
        this.isFirstLaunch = MutableStateFlow;
        kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> MutableStateFlow2 = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(null);
        this._destination = MutableStateFlow2;
        this.destination = kotlinx.coroutines.flow.FlowKt.asStateFlow(MutableStateFlow2);
        kotlinx.coroutines.flow.MutableStateFlow<com.app.a1bat.ui.screens.splash.SplashUiState> MutableStateFlow3 = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(com.app.a1bat.ui.screens.splash.SplashUiState.Loading.INSTANCE);
        this._uiState = MutableStateFlow3;
        this.uiState = MutableStateFlow3;
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(splashViewModel), null, null, new com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1(null), 3, null);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isOnboardingCompleted() {
        return this.isOnboardingCompleted;
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isFirstLaunch() {
        return this.isFirstLaunch;
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getDestination() {
        return this.destination;
    }

    public final kotlinx.coroutines.flow.StateFlow<com.app.a1bat.ui.screens.splash.SplashUiState> getUiState() {
        return this.uiState;
    }

    /* compiled from: SplashViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashViewModel$1", f = "SplashViewModel.kt", i = {0}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_3}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashViewModel$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        private /* synthetic */ java.lang.Object L$0;
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1 anonymousClass1 = com.app.a1bat.ui.screens.splash.SplashViewModel.this.new AnonymousClass1(continuation);
            anonymousClass1.L$0 = obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            kotlinx.coroutines.CoroutineScope coroutineScope;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.CoroutineScope coroutineScope2 = (kotlinx.coroutines.CoroutineScope) this.L$0;
                this.L$0 = coroutineScope2;
                this.label = 1;
                if (com.app.a1bat.ui.screens.splash.SplashViewModel.this.runStartupLogic(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                coroutineScope = coroutineScope2;
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlinx.coroutines.CoroutineScope coroutineScope3 = (kotlinx.coroutines.CoroutineScope) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                coroutineScope = coroutineScope3;
            }
            kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1.C00571(com.app.a1bat.ui.screens.splash.SplashViewModel.this, null), 3, null);
            return kotlin.Unit.INSTANCE;
        }

        /* compiled from: SplashViewModel.kt */
        @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashViewModel$1$1", f = "SplashViewModel.kt", i = {}, l = {36}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.app.a1bat.ui.screens.splash.SplashViewModel$1$1, reason: invalid class name and collision with other inner class name */
        static final class C00571 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
            int label;
            final /* synthetic */ com.app.a1bat.ui.screens.splash.SplashViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C00571(com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1.C00571> continuation) {
                super(2, continuation);
                this.this$0 = splashViewModel;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
                return new com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1.C00571(this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                return ((com.app.a1bat.ui.screens.splash.SplashViewModel.AnonymousClass1.C00571) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    kotlinx.coroutines.flow.Flow<java.lang.Boolean> isOnboardingCompleted = this.this$0.dataStoreManager.isOnboardingCompleted();
                    final com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel = this.this$0;
                    this.label = 1;
                    if (isOnboardingCompleted.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: com.app.a1bat.ui.screens.splash.SplashViewModel.1.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                            return emit(((java.lang.Boolean) obj2).booleanValue(), (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                        }

                        public final java.lang.Object emit(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                            com.app.a1bat.ui.screens.splash.SplashViewModel.this._isFirstLaunch.setValue(kotlin.coroutines.jvm.internal.Boxing.boxBoolean(z));
                            return kotlin.Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                }
                return kotlin.Unit.INSTANCE;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00d5, code lost:
    
        if (r13.setFirstLaunch(false, r0) == r1) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00c2, code lost:
    
        if (r13 == r1) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ac, code lost:
    
        if (r13 != r1) goto L33;
     */
    /* JADX WARN: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0027  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object runStartupLogic(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        com.app.a1bat.ui.screens.splash.SplashViewModel$runStartupLogic$1 splashViewModel$runStartupLogic$1;
        com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel;
        java.lang.String str;
        com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel2;
        java.lang.String str2;
        com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel3;
        com.app.a1bat.data.repository.SettingRepository settingRepository;
        com.app.a1bat.ui.screens.splash.SplashViewModel splashViewModel4;
        if (continuation instanceof com.app.a1bat.ui.screens.splash.SplashViewModel$runStartupLogic$1) {
            splashViewModel$runStartupLogic$1 = (com.app.a1bat.ui.screens.splash.SplashViewModel$runStartupLogic$1) continuation;
            if ((splashViewModel$runStartupLogic$1.label & Integer.MIN_VALUE) != 0) {
                splashViewModel$runStartupLogic$1.label -= Integer.MIN_VALUE;
                java.lang.Object obj = splashViewModel$runStartupLogic$1.result;
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (splashViewModel$runStartupLogic$1.label) {
                    case 0:
                        kotlin.ResultKt.throwOnFailure(obj);
                        com.app.a1bat.data.repository.RemoteConfigRepository remoteConfigRepository = this.remoteConfigRepository;
                        splashViewModel$runStartupLogic$1.L$0 = this;
                        splashViewModel$runStartupLogic$1.label = 1;
                        obj = remoteConfigRepository.getSavedUrl(splashViewModel$runStartupLogic$1);
                        if (obj != coroutine_suspended) {
                            splashViewModel = this;
                            java.lang.String str3 = (java.lang.String) obj;
                            str = str3;
                            if (str == null && !kotlin.text.StringsKt.isBlank(str)) {
                                splashViewModel._uiState.setValue(new com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb(str3, false, 0, 6, null));
                                return kotlin.Unit.INSTANCE;
                            }
                            com.app.a1bat.data.repository.SettingRepository settingRepository2 = splashViewModel.settingRepository;
                            splashViewModel$runStartupLogic$1.L$0 = splashViewModel;
                            splashViewModel$runStartupLogic$1.label = 2;
                            obj = settingRepository2.isFirstLaunch(splashViewModel$runStartupLogic$1);
                            break;
                        }
                        return coroutine_suspended;
                    case 1:
                        splashViewModel = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        java.lang.String str32 = (java.lang.String) obj;
                        str = str32;
                        if (str == null) {
                            break;
                        }
                        com.app.a1bat.data.repository.SettingRepository settingRepository22 = splashViewModel.settingRepository;
                        splashViewModel$runStartupLogic$1.L$0 = splashViewModel;
                        splashViewModel$runStartupLogic$1.label = 2;
                        obj = settingRepository22.isFirstLaunch(splashViewModel$runStartupLogic$1);
                        break;
                    case 2:
                        splashViewModel = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        if (((java.lang.Boolean) obj).booleanValue()) {
                            com.app.a1bat.data.repository.RemoteConfigRepository remoteConfigRepository2 = splashViewModel.remoteConfigRepository;
                            splashViewModel$runStartupLogic$1.L$0 = splashViewModel;
                            splashViewModel$runStartupLogic$1.label = 3;
                            obj = remoteConfigRepository2.fetchUrl(splashViewModel$runStartupLogic$1);
                            break;
                        }
                        splashViewModel._uiState.setValue(com.app.a1bat.ui.screens.splash.SplashUiState.ShowOnboarding.INSTANCE);
                        return kotlin.Unit.INSTANCE;
                    case 3:
                        splashViewModel = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        splashViewModel2 = splashViewModel;
                        str2 = (java.lang.String) obj;
                        com.app.a1bat.data.repository.SettingRepository settingRepository3 = splashViewModel2.settingRepository;
                        splashViewModel$runStartupLogic$1.L$0 = splashViewModel2;
                        splashViewModel$runStartupLogic$1.L$1 = str2;
                        splashViewModel$runStartupLogic$1.label = 4;
                        break;
                    case 4:
                        str2 = (java.lang.String) splashViewModel$runStartupLogic$1.L$1;
                        splashViewModel2 = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        java.lang.String str4 = str2;
                        if (str4 != null && !kotlin.text.StringsKt.isBlank(str4) && kotlin.text.StringsKt.startsWith$default(str2, "http", false, 2, (java.lang.Object) null)) {
                            com.app.a1bat.data.repository.RemoteConfigRepository remoteConfigRepository3 = splashViewModel2.remoteConfigRepository;
                            splashViewModel$runStartupLogic$1.L$0 = splashViewModel2;
                            splashViewModel$runStartupLogic$1.L$1 = str2;
                            splashViewModel$runStartupLogic$1.label = 5;
                            if (remoteConfigRepository3.saveUrl(str2, splashViewModel$runStartupLogic$1) != coroutine_suspended) {
                                splashViewModel3 = splashViewModel2;
                                settingRepository = splashViewModel3.settingRepository;
                                splashViewModel$runStartupLogic$1.L$0 = splashViewModel3;
                                splashViewModel$runStartupLogic$1.L$1 = str2;
                                splashViewModel$runStartupLogic$1.label = 6;
                                if (settingRepository.setInstallDone(true, splashViewModel$runStartupLogic$1) != coroutine_suspended) {
                                    splashViewModel4 = splashViewModel3;
                                    splashViewModel4._uiState.setValue(new com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb(str2, false, 0, 6, null));
                                    return kotlin.Unit.INSTANCE;
                                }
                            }
                            return coroutine_suspended;
                        }
                        splashViewModel = splashViewModel2;
                        splashViewModel._uiState.setValue(com.app.a1bat.ui.screens.splash.SplashUiState.ShowOnboarding.INSTANCE);
                        return kotlin.Unit.INSTANCE;
                    case 5:
                        str2 = (java.lang.String) splashViewModel$runStartupLogic$1.L$1;
                        splashViewModel3 = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        settingRepository = splashViewModel3.settingRepository;
                        splashViewModel$runStartupLogic$1.L$0 = splashViewModel3;
                        splashViewModel$runStartupLogic$1.L$1 = str2;
                        splashViewModel$runStartupLogic$1.label = 6;
                        if (settingRepository.setInstallDone(true, splashViewModel$runStartupLogic$1) != coroutine_suspended) {
                        }
                        return coroutine_suspended;
                    case 6:
                        java.lang.String str5 = (java.lang.String) splashViewModel$runStartupLogic$1.L$1;
                        splashViewModel4 = (com.app.a1bat.ui.screens.splash.SplashViewModel) splashViewModel$runStartupLogic$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        str2 = str5;
                        splashViewModel4._uiState.setValue(new com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb(str2, false, 0, 6, null));
                        return kotlin.Unit.INSTANCE;
                    default:
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }
        splashViewModel$runStartupLogic$1 = new com.app.a1bat.ui.screens.splash.SplashViewModel$runStartupLogic$1(this, continuation);
        java.lang.Object obj2 = splashViewModel$runStartupLogic$1.result;
        java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (splashViewModel$runStartupLogic$1.label) {
        }
    }
}
