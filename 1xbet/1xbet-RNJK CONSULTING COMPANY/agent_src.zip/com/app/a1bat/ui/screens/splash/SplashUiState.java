package com.app.a1bat.ui.screens.splash;

/* compiled from: SplashViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0003\u0004\u0005\u0006B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0003\u0007\b\t¨\u0006\n"}, d2 = {"Lcom/app/a1bat/ui/screens/splash/SplashUiState;", "", "<init>", "()V", "Loading", "ShowOnboarding", "ShowWeb", "Lcom/app/a1bat/ui/screens/splash/SplashUiState$Loading;", "Lcom/app/a1bat/ui/screens/splash/SplashUiState$ShowOnboarding;", "Lcom/app/a1bat/ui/screens/splash/SplashUiState$ShowWeb;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public abstract class SplashUiState {
    public static final int $stable = 0;

    public /* synthetic */ SplashUiState(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    /* compiled from: SplashViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/splash/SplashUiState$Loading;", "Lcom/app/a1bat/ui/screens/splash/SplashUiState;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Loading extends com.app.a1bat.ui.screens.splash.SplashUiState {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.splash.SplashUiState.Loading INSTANCE = new com.app.a1bat.ui.screens.splash.SplashUiState.Loading();

        private Loading() {
            super(null);
        }
    }

    private SplashUiState() {
    }

    /* compiled from: SplashViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/splash/SplashUiState$ShowOnboarding;", "Lcom/app/a1bat/ui/screens/splash/SplashUiState;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class ShowOnboarding extends com.app.a1bat.ui.screens.splash.SplashUiState {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.splash.SplashUiState.ShowOnboarding INSTANCE = new com.app.a1bat.ui.screens.splash.SplashUiState.ShowOnboarding();

        private ShowOnboarding() {
            super(null);
        }
    }

    /* compiled from: SplashViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0087\b\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00052\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, d2 = {"Lcom/app/a1bat/ui/screens/splash/SplashUiState$ShowWeb;", "Lcom/app/a1bat/ui/screens/splash/SplashUiState;", com.google.android.gms.common.internal.ImagesContract.URL, "", "showBanner", "", "id", "", "<init>", "(Ljava/lang/String;ZI)V", "getUrl", "()Ljava/lang/String;", "getShowBanner", "()Z", "getId", "()I", "component1", "component2", "component3", "copy", "equals", "other", "", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final /* data */ class ShowWeb extends com.app.a1bat.ui.screens.splash.SplashUiState {
        public static final int $stable = 0;
        private final int id;
        private final boolean showBanner;
        private final java.lang.String url;

        public static /* synthetic */ com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb copy$default(com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb showWeb, java.lang.String str, boolean z, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = showWeb.url;
            }
            if ((i2 & 2) != 0) {
                z = showWeb.showBanner;
            }
            if ((i2 & 4) != 0) {
                i = showWeb.id;
            }
            return showWeb.copy(str, z, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getUrl() {
            return this.url;
        }

        /* renamed from: component2, reason: from getter */
        public final boolean getShowBanner() {
            return this.showBanner;
        }

        /* renamed from: component3, reason: from getter */
        public final int getId() {
            return this.id;
        }

        public final com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb copy(java.lang.String url, boolean showBanner, int id) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
            return new com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb(url, showBanner, id);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb)) {
                return false;
            }
            com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb showWeb = (com.app.a1bat.ui.screens.splash.SplashUiState.ShowWeb) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.url, showWeb.url) && this.showBanner == showWeb.showBanner && this.id == showWeb.id;
        }

        public int hashCode() {
            return (((this.url.hashCode() * 31) + java.lang.Boolean.hashCode(this.showBanner)) * 31) + java.lang.Integer.hashCode(this.id);
        }

        public java.lang.String toString() {
            return "ShowWeb(url=" + this.url + ", showBanner=" + this.showBanner + ", id=" + this.id + ")";
        }

        public /* synthetic */ ShowWeb(java.lang.String str, boolean z, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this(str, (i2 & 2) != 0 ? false : z, (i2 & 4) != 0 ? 0 : i);
        }

        public final java.lang.String getUrl() {
            return this.url;
        }

        public final boolean getShowBanner() {
            return this.showBanner;
        }

        public final int getId() {
            return this.id;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ShowWeb(java.lang.String url, boolean z, int i) {
            super(null);
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
            this.url = url;
            this.showBanner = z;
            this.id = i;
        }
    }
}
