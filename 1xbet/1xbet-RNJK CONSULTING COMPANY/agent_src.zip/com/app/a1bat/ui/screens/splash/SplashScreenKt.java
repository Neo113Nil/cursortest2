package com.app.a1bat.ui.screens.splash;

/* compiled from: SplashScreen.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\u001a3\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\u0007¢\u0006\u0002\u0010\u0007¨\u0006\b²\u0006\f\u0010\t\u001a\u0004\u0018\u00010\nX\u008a\u0084\u0002²\u0006\n\u0010\u000b\u001a\u00020\fX\u008a\u0084\u0002²\u0006\n\u0010\r\u001a\u00020\fX\u008a\u0084\u0002²\u0006\n\u0010\u000e\u001a\u00020\fX\u008a\u0084\u0002²\u0006\n\u0010\u000f\u001a\u00020\fX\u008a\u0084\u0002"}, d2 = {"SplashScreen", "", "onNavigateToOnboarding", "Lkotlin/Function0;", "onNavigateToMain", "viewModel", "Lcom/app/a1bat/ui/screens/main/MainViewModel;", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lcom/app/a1bat/ui/screens/main/MainViewModel;Landroidx/compose/runtime/Composer;II)V", "app_release", "isOnboardingCompleted", "", "glowPulse", "", "outerRingRotation", "innerRingRotation", "shimmerOffset"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SplashScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit SplashScreen$lambda$24(kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, com.app.a1bat.ui.screens.main.MainViewModel mainViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        SplashScreen(function0, function02, mainViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0096, code lost:
    
        if ((r54 & 4) != 0) goto L53;
     */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r13v7 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void SplashScreen(final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToOnboarding, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToMain, com.app.a1bat.ui.screens.main.MainViewModel mainViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        com.app.a1bat.ui.screens.main.MainViewModel mainViewModel2;
        androidx.compose.animation.core.Animatable animatable;
        androidx.compose.animation.core.Animatable animatable2;
        androidx.compose.animation.core.Animatable animatable3;
        java.lang.Boolean bool;
        java.lang.String str;
        androidx.compose.animation.core.Animatable animatable4;
        ?? r13;
        char c;
        androidx.compose.runtime.Composer composer2;
        com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1 splashScreenKt$SplashScreen$1$1;
        androidx.compose.runtime.Composer composer3;
        final com.app.a1bat.ui.screens.main.MainViewModel mainViewModel3;
        int i4;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToOnboarding, "onNavigateToOnboarding");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToMain, "onNavigateToMain");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(800241532);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(SplashScreen)P(1)61@2639L16,63@2677L29,64@2727L27,65@2775L29,66@2826L27,67@2876L28,68@2929L27,69@2980L27,70@3031L27,72@3089L41,74@3172L242,84@3464L237,94@3751L237,104@4034L237,114@4315L823,114@4277L861,136@5144L9444:SplashScreen.kt#kx1f5x");
        if ((i2 & 1) != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = (startRestartGroup.changedInstance(onNavigateToOnboarding) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i2 & 2) != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            i3 |= startRestartGroup.changedInstance(onNavigateToMain) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            if ((i2 & 4) == 0) {
                mainViewModel2 = mainViewModel;
                if (startRestartGroup.changedInstance(mainViewModel2)) {
                    i4 = 256;
                    i3 |= i4;
                }
            } else {
                mainViewModel2 = mainViewModel;
            }
            i4 = 128;
            i3 |= i4;
        } else {
            mainViewModel2 = mainViewModel;
        }
        if ((i3 & 147) != 146 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "59@2554L15");
            if ((i & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 4) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.main.MainViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    mainViewModel2 = (com.app.a1bat.ui.screens.main.MainViewModel) resolveViewModel;
                    i3 &= -897;
                }
                com.app.a1bat.ui.screens.main.MainViewModel mainViewModel4 = mainViewModel2;
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(800241532, i3, -1, "com.app.a1bat.ui.screens.splash.SplashScreen (SplashScreen.kt:60)");
                }
                androidx.compose.runtime.State collectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(mainViewModel4.isOnboardingCompleted(), null, startRestartGroup, 0, 1);
                startRestartGroup.startReplaceGroup(633012441);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue = startRestartGroup.rememberedValue();
                if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.5f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue);
                }
                androidx.compose.animation.core.Animatable animatable5 = (androidx.compose.animation.core.Animatable) rememberedValue;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633014039);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue2 = startRestartGroup.rememberedValue();
                if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue2 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue2);
                }
                androidx.compose.animation.core.Animatable animatable6 = (androidx.compose.animation.core.Animatable) rememberedValue2;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633015577);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue3 = startRestartGroup.rememberedValue();
                if (rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue3 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.6f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue3);
                }
                androidx.compose.animation.core.Animatable animatable7 = (androidx.compose.animation.core.Animatable) rememberedValue3;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633017207);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue4 = startRestartGroup.rememberedValue();
                if (rememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue4 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue4);
                }
                androidx.compose.animation.core.Animatable animatable8 = (androidx.compose.animation.core.Animatable) rememberedValue4;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633018808);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue5 = startRestartGroup.rememberedValue();
                if (rememberedValue5 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue5 = androidx.compose.animation.core.AnimatableKt.Animatable$default(30.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue5);
                }
                androidx.compose.animation.core.Animatable animatable9 = (androidx.compose.animation.core.Animatable) rememberedValue5;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633020503);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue6 = startRestartGroup.rememberedValue();
                if (rememberedValue6 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue6 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue6);
                }
                androidx.compose.animation.core.Animatable animatable10 = (androidx.compose.animation.core.Animatable) rememberedValue6;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633022135);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue7 = startRestartGroup.rememberedValue();
                if (rememberedValue7 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue7 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue7);
                }
                androidx.compose.animation.core.Animatable animatable11 = (androidx.compose.animation.core.Animatable) rememberedValue7;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(633023767);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                java.lang.Object rememberedValue8 = startRestartGroup.rememberedValue();
                int i5 = i3;
                if (rememberedValue8 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue8 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue8);
                }
                androidx.compose.animation.core.Animatable animatable12 = (androidx.compose.animation.core.Animatable) rememberedValue8;
                startRestartGroup.endReplaceGroup();
                androidx.compose.animation.core.InfiniteTransition rememberInfiniteTransition = androidx.compose.animation.core.InfiniteTransitionKt.rememberInfiniteTransition("inf", startRestartGroup, 6, 0);
                androidx.compose.runtime.State<java.lang.Float> animateFloat = androidx.compose.animation.core.InfiniteTransitionKt.animateFloat(rememberInfiniteTransition, 0.25f, 0.65f, androidx.compose.animation.core.AnimationSpecKt.m152infiniteRepeatable9IiC70o$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(2000, 0, androidx.compose.animation.core.EasingKt.getFastOutSlowInEasing(), 2, null), androidx.compose.animation.core.RepeatMode.Reverse, 0L, 4, null), "glow", startRestartGroup, androidx.compose.animation.core.InfiniteTransition.$stable | 25008 | (androidx.compose.animation.core.InfiniteRepeatableSpec.$stable << 9), 0);
                androidx.compose.runtime.State<java.lang.Float> animateFloat2 = androidx.compose.animation.core.InfiniteTransitionKt.animateFloat(rememberInfiniteTransition, 0.0f, 360.0f, androidx.compose.animation.core.AnimationSpecKt.m152infiniteRepeatable9IiC70o$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(8000, 0, androidx.compose.animation.core.EasingKt.getLinearEasing(), 2, null), androidx.compose.animation.core.RepeatMode.Restart, 0L, 4, null), "outer_ring", startRestartGroup, androidx.compose.animation.core.InfiniteTransition.$stable | 25008 | (androidx.compose.animation.core.InfiniteRepeatableSpec.$stable << 9), 0);
                androidx.compose.runtime.State<java.lang.Float> animateFloat3 = androidx.compose.animation.core.InfiniteTransitionKt.animateFloat(rememberInfiniteTransition, 360.0f, 0.0f, androidx.compose.animation.core.AnimationSpecKt.m152infiniteRepeatable9IiC70o$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(5000, 0, androidx.compose.animation.core.EasingKt.getLinearEasing(), 2, null), androidx.compose.animation.core.RepeatMode.Restart, 0L, 4, null), "inner_ring", startRestartGroup, androidx.compose.animation.core.InfiniteTransition.$stable | 25008 | (androidx.compose.animation.core.InfiniteRepeatableSpec.$stable << 9), 0);
                androidx.compose.runtime.State<java.lang.Float> animateFloat4 = androidx.compose.animation.core.InfiniteTransitionKt.animateFloat(rememberInfiniteTransition, -200.0f, 200.0f, androidx.compose.animation.core.AnimationSpecKt.m152infiniteRepeatable9IiC70o$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(2500, 0, androidx.compose.animation.core.EasingKt.getLinearEasing(), 2, null), androidx.compose.animation.core.RepeatMode.Restart, 0L, 4, null), "shimmer", startRestartGroup, androidx.compose.animation.core.InfiniteTransition.$stable | 24960 | (androidx.compose.animation.core.InfiniteRepeatableSpec.$stable << 9), 0);
                java.lang.Boolean SplashScreen$lambda$0 = SplashScreen$lambda$0(collectAsState);
                startRestartGroup.startReplaceGroup(633065651);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):SplashScreen.kt#9igjgp");
                boolean changedInstance = startRestartGroup.changedInstance(animatable7) | startRestartGroup.changedInstance(animatable5) | startRestartGroup.changedInstance(animatable6) | startRestartGroup.changedInstance(animatable8) | startRestartGroup.changedInstance(animatable9) | startRestartGroup.changedInstance(animatable10) | startRestartGroup.changedInstance(animatable11) | startRestartGroup.changedInstance(animatable12) | startRestartGroup.changed(collectAsState) | ((i5 & 112) == 32) | ((i5 & 14) == 4);
                java.lang.Object rememberedValue9 = startRestartGroup.rememberedValue();
                if (changedInstance || rememberedValue9 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    animatable = animatable12;
                    animatable2 = animatable8;
                    animatable3 = animatable9;
                    bool = SplashScreen$lambda$0;
                    str = "CC(remember):SplashScreen.kt#9igjgp";
                    animatable4 = animatable7;
                    r13 = 0;
                    c = ' ';
                    composer2 = startRestartGroup;
                    splashScreenKt$SplashScreen$1$1 = new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1(animatable10, animatable11, animatable, onNavigateToMain, onNavigateToOnboarding, animatable4, animatable5, animatable6, animatable2, animatable3, collectAsState, null);
                    composer2.updateRememberedValue(splashScreenKt$SplashScreen$1$1);
                } else {
                    bool = SplashScreen$lambda$0;
                    str = "CC(remember):SplashScreen.kt#9igjgp";
                    animatable = animatable12;
                    splashScreenKt$SplashScreen$1$1 = rememberedValue9;
                    animatable2 = animatable8;
                    animatable3 = animatable9;
                    animatable4 = animatable7;
                    r13 = 0;
                    c = ' ';
                    composer2 = startRestartGroup;
                }
                composer2.endReplaceGroup();
                androidx.compose.runtime.EffectsKt.LaunchedEffect(bool, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) splashScreenKt$SplashScreen$1$1, composer2, (int) r13);
                androidx.compose.ui.Modifier fillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.ui.graphics.Brush.Companion companion = androidx.compose.ui.graphics.Brush.INSTANCE;
                androidx.compose.ui.graphics.Color[] colorArr = new androidx.compose.ui.graphics.Color[3];
                colorArr[r13] = androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279901998L));
                colorArr[1] = androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279046423L));
                colorArr[2] = androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4278651663L));
                androidx.compose.ui.Modifier background$default = androidx.compose.foundation.BackgroundKt.background$default(fillMaxSize$default, androidx.compose.ui.graphics.Brush.Companion.m4038radialGradientP_VxKs$default(companion, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) colorArr), 0L, 1500.0f, 0, 10, (java.lang.Object) null), null, 0.0f, 6, null);
                androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, r13);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, r13);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, background$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -252617439, "C151@5583L201,158@5793L236,166@6038L234,175@6282L7232,354@13524L1058:SplashScreen.kt#kx1f5x");
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.draw.BlurKt.m3614blurF8QBwvs$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(420)), SplashScreen$lambda$9(animateFloat) * 0.12f), androidx.compose.ui.unit.Dp.m6803constructorimpl(100), null, 2, null), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), composer2, 0);
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.draw.BlurKt.m3614blurF8QBwvs$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopEnd()), androidx.compose.ui.unit.Dp.m6803constructorimpl(androidx.compose.runtime.ComposerKt.invocationKey)), 0.06f), androidx.compose.ui.unit.Dp.m6803constructorimpl(60), null, 2, null), androidx.compose.ui.graphics.ColorKt.Color(4283076825L), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), composer2, 0);
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.draw.BlurKt.m3614blurF8QBwvs$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getBottomStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(180)), 0.05f), androidx.compose.ui.unit.Dp.m6803constructorimpl(50), null, 2, null), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), composer2, 0);
                androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), centerHorizontally, composer2, 48);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, companion2);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor2);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1133593198, "C178@6377L5257,298@11648L41,300@11703L360,311@12077L40,313@12131L330,323@12475L41,325@12530L590,342@13134L41,344@13189L315:SplashScreen.kt#kx1f5x");
                androidx.compose.ui.Alignment center2 = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.ui.Modifier alpha = androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.ui.draw.ScaleKt.scale(androidx.compose.ui.Modifier.INSTANCE, ((java.lang.Number) animatable5.getValue()).floatValue()), ((java.lang.Number) animatable6.getValue()).floatValue());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, alpha);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor3);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                    m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                    m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 136032677, "C184@6591L431,200@7210L849,196@7040L1037,223@8265L854,219@8095L1042,242@9155L2465:SplashScreen.kt#kx1f5x");
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(170)), SplashScreen$lambda$9(animateFloat) * 0.3f), androidx.compose.ui.graphics.Brush.Companion.m4038radialGradientP_VxKs$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU())}), 0L, 0.0f, 0, 14, (java.lang.Object) null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape(), 0.0f, 4, null), composer2, 0);
                androidx.compose.ui.Modifier rotate = androidx.compose.ui.draw.RotateKt.rotate(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(148)), SplashScreen$lambda$10(animateFloat2));
                composer2.startReplaceGroup(-826880214);
                java.lang.String str2 = str;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, str2);
                java.lang.Object rememberedValue10 = composer2.rememberedValue();
                if (rememberedValue10 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue10 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.splash.SplashScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            kotlin.Unit SplashScreen$lambda$23$lambda$21$lambda$20$lambda$15$lambda$14;
                            SplashScreen$lambda$23$lambda$21$lambda$20$lambda$15$lambda$14 = com.app.a1bat.ui.screens.splash.SplashScreenKt.SplashScreen$lambda$23$lambda$21$lambda$20$lambda$15$lambda$14((androidx.compose.ui.graphics.drawscope.DrawScope) obj);
                            return SplashScreen$lambda$23$lambda$21$lambda$20$lambda$15$lambda$14;
                        }
                    };
                    composer2.updateRememberedValue(rememberedValue10);
                }
                composer2.endReplaceGroup();
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.ui.draw.DrawModifierKt.drawBehind(rotate, (kotlin.jvm.functions.Function1) rememberedValue10), composer2, 0);
                androidx.compose.ui.Modifier rotate2 = androidx.compose.ui.draw.RotateKt.rotate(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(okhttp3.internal.ws.WebSocketProtocol.PAYLOAD_SHORT)), SplashScreen$lambda$11(animateFloat3));
                composer2.startReplaceGroup(-826846449);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, str2);
                java.lang.Object rememberedValue11 = composer2.rememberedValue();
                if (rememberedValue11 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue11 = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.splash.SplashScreenKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            kotlin.Unit SplashScreen$lambda$23$lambda$21$lambda$20$lambda$17$lambda$16;
                            SplashScreen$lambda$23$lambda$21$lambda$20$lambda$17$lambda$16 = com.app.a1bat.ui.screens.splash.SplashScreenKt.SplashScreen$lambda$23$lambda$21$lambda$20$lambda$17$lambda$16((androidx.compose.ui.graphics.drawscope.DrawScope) obj);
                            return SplashScreen$lambda$23$lambda$21$lambda$20$lambda$17$lambda$16;
                        }
                    };
                    composer2.updateRememberedValue(rememberedValue11);
                }
                composer2.endReplaceGroup();
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.ui.draw.DrawModifierKt.drawBehind(rotate2, (kotlin.jvm.functions.Function1) rememberedValue11), composer2, 0);
                androidx.compose.ui.Modifier background$default2 = androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.ui.draw.ScaleKt.scale(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(112)), ((java.lang.Number) animatable4.getValue()).floatValue()), androidx.compose.ui.graphics.Brush.Companion.m4036linearGradientmHitzGk$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getAccentGold()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.8f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getGoldGradientEnd())}), 0L, 0L, 0, 14, (java.lang.Object) null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape(), 0.0f, 4, null);
                androidx.compose.ui.Alignment center3 = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center3, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, background$default2);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor4);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                    m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                    m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -424790564, "C254@9667L1935:SplashScreen.kt#kx1f5x");
                androidx.compose.ui.Modifier background$default3 = androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(90)), androidx.compose.ui.graphics.Brush.Companion.m4038radialGradientP_VxKs$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279901998L)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4279046423L))}), 0L, 0.0f, 0, 14, (java.lang.Object) null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape(), 0.0f, 4, null);
                androidx.compose.ui.Alignment center4 = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy4 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center4, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, background$default3);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor5);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, maybeCachedBoxMeasurePolicy4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                    m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                    m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash5);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance4 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 2029506496, "C265@10160L1118,287@11303L277:SplashScreen.kt#kx1f5x");
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(80)), 0.1f), androidx.compose.ui.graphics.Brush.Companion.m4036linearGradientmHitzGk$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.4f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU())}), androidx.compose.ui.geometry.Offset.m3834constructorimpl((java.lang.Float.floatToRawIntBits(SplashScreen$lambda$12(animateFloat4)) << c) | (java.lang.Float.floatToRawIntBits(0.0f) & 4294967295L)), androidx.compose.ui.geometry.Offset.m3834constructorimpl((java.lang.Float.floatToRawIntBits(SplashScreen$lambda$12(animateFloat4) + 100.0f) << c) | (java.lang.Float.floatToRawIntBits(100.0f) & 4294967295L)), 0, 8, (java.lang.Object) null), null, 0.0f, 6, null), composer2, 0);
                androidx.compose.runtime.Composer composer4 = composer2;
                androidx.compose.material3.TextKt.m2386Text4IGK_g("1B", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(28), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(-1), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer4, 12782982, 0, 130898);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                composer4.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                composer4.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                composer4.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                float f = 36;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer4, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("1  B A T", androidx.compose.foundation.layout.PaddingKt.m698paddingqDBjuR0$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.ui.Modifier.INSTANCE, ((java.lang.Number) animatable2.getValue()).floatValue()), 0.0f, 0.0f, 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(((java.lang.Number) animatable3.getValue()).floatValue() * 0.1f), 7, null), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), androidx.compose.ui.unit.TextUnitKt.getSp(38), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(6), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer4, 12782982, 0, 130896);
                float f2 = 8;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), composer4, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("C O N S U L T I N G", androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.ui.Modifier.INSTANCE, ((java.lang.Number) animatable10.getValue()).floatValue()), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(6), (androidx.compose.ui.text.style.TextDecoration) null, androidx.compose.ui.text.style.TextAlign.m6680boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m6687getCentere0LSkKk()), 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer4, 12782982, 0, 130384);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(20)), composer4, 6);
                float f3 = 1;
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(androidx.compose.ui.unit.Dp.m6803constructorimpl(androidx.compose.material3.MenuKt.InTransitionDuration) * ((java.lang.Number) animatable11.getValue()).floatValue())), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3)), androidx.compose.ui.graphics.Brush.Companion.m4034horizontalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getAccentGold()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getAccentGoldLight()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getAccentGold()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), composer4, 0);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(16)), composer4, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Excellence in Every Strategy", androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.ui.Modifier.INSTANCE, ((java.lang.Number) animatable10.getValue()).floatValue()), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.35f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getLight(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(0.8d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer4, 12782982, 0, 130896);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                composer4.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                androidx.compose.ui.Alignment.Horizontal centerHorizontally2 = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
                androidx.compose.ui.Modifier m698paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m698paddingqDBjuR0$default(androidx.compose.ui.draw.AlphaKt.alpha(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getBottomCenter()), ((java.lang.Number) animatable.getValue()).floatValue()), 0.0f, 0.0f, 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(44), 7, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer4, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), centerHorizontally2, composer4, 48);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer4, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer4, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer4.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer4, m698paddingqDBjuR0$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer4, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer4.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer4.startReusableNode();
                if (composer4.getInserting()) {
                    composer4.createNode(constructor6);
                } else {
                    composer4.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer4);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                    m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                    m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash6);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer4, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer4, -1126442924, "C361@13783L475,375@14271L40,376@14324L248:SplashScreen.kt#kx1f5x");
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.ui.unit.Dp.m6803constructorimpl(f3)), androidx.compose.ui.graphics.Brush.Companion.m4034horizontalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.4f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), composer4, 6);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), composer4, 6);
                composer3 = composer4;
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Premium Business Solutions", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.unit.TextUnitKt.getSp(11), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getLight(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(1.5d), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 12782982, 0, 130898);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                composer3.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                composer3.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                mainViewModel3 = mainViewModel4;
            } else {
                startRestartGroup.skipToGroupEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
            mainViewModel3 = mainViewModel2;
            composer3 = startRestartGroup;
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = composer3.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.splash.SplashScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit SplashScreen$lambda$24;
                    SplashScreen$lambda$24 = com.app.a1bat.ui.screens.splash.SplashScreenKt.SplashScreen$lambda$24(kotlin.jvm.functions.Function0.this, onNavigateToMain, mainViewModel3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return SplashScreen$lambda$24;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.Boolean SplashScreen$lambda$0(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue();
    }

    private static final float SplashScreen$lambda$9(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }

    private static final float SplashScreen$lambda$10(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }

    private static final float SplashScreen$lambda$11(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }

    private static final float SplashScreen$lambda$12(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit SplashScreen$lambda$23$lambda$21$lambda$20$lambda$15$lambda$14(androidx.compose.ui.graphics.drawscope.DrawScope drawBehind) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(drawBehind, "$this$drawBehind");
        float f = drawBehind.mo386toPx0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl((float) 1.5d));
        androidx.compose.ui.graphics.drawscope.DrawScope.m4644drawArcyD3GUKo$default(drawBehind, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.4f, 0.0f, 0.0f, 0.0f, 14, null), 0.0f, 270.0f, false, 0L, 0L, 0.0f, new androidx.compose.ui.graphics.drawscope.Stroke(f, 0.0f, androidx.compose.ui.graphics.StrokeCap.INSTANCE.m4457getRoundKaPHkGw(), 0, null, 26, null), null, 0, 880, null);
        androidx.compose.ui.graphics.drawscope.DrawScope.m4644drawArcyD3GUKo$default(drawBehind, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.15f, 0.0f, 0.0f, 0.0f, 14, null), 280.0f, 70.0f, false, 0L, 0L, 0.0f, new androidx.compose.ui.graphics.drawscope.Stroke(f, 0.0f, androidx.compose.ui.graphics.StrokeCap.INSTANCE.m4457getRoundKaPHkGw(), 0, null, 26, null), null, 0, 880, null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit SplashScreen$lambda$23$lambda$21$lambda$20$lambda$17$lambda$16(androidx.compose.ui.graphics.drawscope.DrawScope drawBehind) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(drawBehind, "$this$drawBehind");
        float f = drawBehind.mo386toPx0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(1));
        androidx.compose.ui.graphics.drawscope.DrawScope.m4644drawArcyD3GUKo$default(drawBehind, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.25f, 0.0f, 0.0f, 0.0f, 14, null), 0.0f, 180.0f, false, 0L, 0L, 0.0f, new androidx.compose.ui.graphics.drawscope.Stroke(f, 0.0f, androidx.compose.ui.graphics.StrokeCap.INSTANCE.m4457getRoundKaPHkGw(), 0, null, 26, null), null, 0, 880, null);
        androidx.compose.ui.graphics.drawscope.DrawScope.m4644drawArcyD3GUKo$default(drawBehind, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGoldLight(), 0.12f, 0.0f, 0.0f, 0.0f, 14, null), 190.0f, 160.0f, false, 0L, 0L, 0.0f, new androidx.compose.ui.graphics.drawscope.Stroke(f, 0.0f, androidx.compose.ui.graphics.StrokeCap.INSTANCE.m4457getRoundKaPHkGw(), 0, null, 26, null), null, 0, 880, null);
        return kotlin.Unit.INSTANCE;
    }
}
