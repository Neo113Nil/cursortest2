package com.app.a1bat.ui.screens.home;

/* compiled from: HomeScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class HomeScreenKt$HomeScreen$1$1$1 implements kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ java.util.List<java.lang.String> $categories;
    final /* synthetic */ androidx.compose.runtime.State<java.lang.String> $selectedCategory$delegate;
    final /* synthetic */ com.app.a1bat.ui.screens.home.HomeViewModel $viewModel;

    HomeScreenKt$HomeScreen$1$1$1(com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel, java.util.List<java.lang.String> list, androidx.compose.runtime.State<java.lang.String> state) {
        this.$viewModel = homeViewModel;
        this.$categories = list;
        this.$selectedCategory$delegate = state;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(lazyItemScope, composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
        java.lang.String HomeScreen$lambda$1;
        java.lang.String HomeScreen$lambda$12;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C192@7533L21,190@7454L2210,235@9677L41:HomeScreen.kt#8mqhoj");
        if ((i & 17) != 16 || !composer.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(219499917, i, -1, "com.app.a1bat.ui.screens.home.HomeScreen.<anonymous>.<anonymous>.<anonymous> (HomeScreen.kt:190)");
            }
            float f = 16;
            androidx.compose.ui.Modifier m696paddingVpY3zN4$default = androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.ScrollKt.horizontalScroll$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.foundation.ScrollKt.rememberScrollState(0, composer, 0, 1), false, null, false, 14, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), 0.0f, 2, null);
            float f2 = 8;
            androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical m574spacedBy0680j_4 = androidx.compose.foundation.layout.Arrangement.INSTANCE.m574spacedBy0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f2));
            final com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel = this.$viewModel;
            java.util.List<java.lang.String> list = this.$categories;
            androidx.compose.runtime.State<java.lang.String> state = this.$selectedCategory$delegate;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(m574spacedBy0680j_4, androidx.compose.ui.Alignment.INSTANCE.getTop(), composer, 6);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m696paddingVpY3zN4$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -407840262, "C101@5126L9:Row.kt#2w3rfo");
            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1046881646, "C202@8039L39,204@8152L31,197@7764L832:HomeScreen.kt#8mqhoj");
            HomeScreen$lambda$1 = com.app.a1bat.ui.screens.home.HomeScreenKt.HomeScreen$lambda$1(state);
            boolean z = HomeScreen$lambda$1 == null;
            float f3 = 20;
            androidx.compose.ui.Modifier m249backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f3))), z ? com.app.a1bat.ui.theme.ColorKt.getPrimaryDark() : androidx.compose.ui.graphics.ColorKt.Color(4293454576L), null, 2, null);
            composer.startReplaceGroup(797522399);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):HomeScreen.kt#9igjgp");
            java.lang.Object rememberedValue = composer.rememberedValue();
            if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue = androidx.compose.foundation.interaction.InteractionSourceKt.MutableInteractionSource();
                composer.updateRememberedValue(rememberedValue);
            }
            androidx.compose.foundation.interaction.MutableInteractionSource mutableInteractionSource = (androidx.compose.foundation.interaction.MutableInteractionSource) rememberedValue;
            composer.endReplaceGroup();
            composer.startReplaceGroup(797526007);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):HomeScreen.kt#9igjgp");
            boolean changedInstance = composer.changedInstance(homeViewModel);
            java.lang.Object rememberedValue2 = composer.rememberedValue();
            if (changedInstance || rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue2 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.home.HomeScreenKt$HomeScreen$1$1$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        kotlin.Unit invoke$lambda$9$lambda$2$lambda$1;
                        invoke$lambda$9$lambda$2$lambda$1 = com.app.a1bat.ui.screens.home.HomeScreenKt$HomeScreen$1$1$1.invoke$lambda$9$lambda$2$lambda$1(com.app.a1bat.ui.screens.home.HomeViewModel.this);
                        return invoke$lambda$9$lambda$2$lambda$1;
                    }
                };
                composer.updateRememberedValue(rememberedValue2);
            }
            composer.endReplaceGroup();
            androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.ClickableKt.m280clickableO2vRcR0$default(m249backgroundbw27NRU$default, mutableInteractionSource, null, false, null, null, (kotlin.jvm.functions.Function0) rememberedValue2, 28, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m695paddingVpY3zN4);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1286275664, "C207@8294L284:HomeScreen.kt#8mqhoj");
            long sp = androidx.compose.ui.unit.TextUnitKt.getSp(13);
            androidx.compose.ui.text.font.FontWeight.Companion companion = androidx.compose.ui.text.font.FontWeight.INSTANCE;
            com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel2 = homeViewModel;
            java.lang.String str = "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp";
            java.lang.String str2 = "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh";
            java.lang.String str3 = "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo";
            java.lang.String str4 = "C73@3429L9:Box.kt#2w3rfo";
            androidx.compose.material3.TextKt.m2386Text4IGK_g("All", (androidx.compose.ui.Modifier) null, z ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4281811281L), sp, (androidx.compose.ui.text.font.FontStyle) null, z ? companion.getBold() : companion.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3078, 0, 131026);
            androidx.compose.runtime.Composer composer2 = composer;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.startReplaceGroup(797542106);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "*221@9026L39,223@9147L35,216@8732L900");
            for (final java.lang.String str5 : list) {
                HomeScreen$lambda$12 = com.app.a1bat.ui.screens.home.HomeScreenKt.HomeScreen$lambda$1(state);
                boolean areEqual = kotlin.jvm.internal.Intrinsics.areEqual(HomeScreen$lambda$12, str5);
                androidx.compose.ui.Modifier m249backgroundbw27NRU$default2 = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f3))), areEqual ? com.app.a1bat.ui.theme.ColorKt.getPrimaryDark() : androidx.compose.ui.graphics.ColorKt.Color(4293454576L), null, 2, null);
                composer2.startReplaceGroup(-1704037570);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "CC(remember):HomeScreen.kt#9igjgp");
                java.lang.Object rememberedValue3 = composer2.rememberedValue();
                if (rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue3 = androidx.compose.foundation.interaction.InteractionSourceKt.MutableInteractionSource();
                    composer2.updateRememberedValue(rememberedValue3);
                }
                androidx.compose.foundation.interaction.MutableInteractionSource mutableInteractionSource2 = (androidx.compose.foundation.interaction.MutableInteractionSource) rememberedValue3;
                composer2.endReplaceGroup();
                composer2.startReplaceGroup(-1704033702);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "CC(remember):HomeScreen.kt#9igjgp");
                final com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel3 = homeViewModel2;
                boolean changedInstance2 = composer2.changedInstance(homeViewModel3) | composer2.changed(str5);
                java.lang.Object rememberedValue4 = composer2.rememberedValue();
                if (changedInstance2 || rememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue4 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.home.HomeScreenKt$HomeScreen$1$1$1$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            kotlin.Unit invoke$lambda$9$lambda$8$lambda$6$lambda$5;
                            invoke$lambda$9$lambda$8$lambda$6$lambda$5 = com.app.a1bat.ui.screens.home.HomeScreenKt$HomeScreen$1$1$1.invoke$lambda$9$lambda$8$lambda$6$lambda$5(com.app.a1bat.ui.screens.home.HomeViewModel.this, str5);
                            return invoke$lambda$9$lambda$8$lambda$6$lambda$5;
                        }
                    };
                    composer2.updateRememberedValue(rememberedValue4);
                }
                composer2.endReplaceGroup();
                androidx.compose.ui.Modifier m695paddingVpY3zN42 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.ClickableKt.m280clickableO2vRcR0$default(m249backgroundbw27NRU$default2, mutableInteractionSource2, null, false, null, null, (kotlin.jvm.functions.Function0) rememberedValue4, 28, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2));
                java.lang.String str6 = str3;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, str6);
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                java.lang.String str7 = str2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, str7);
                int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, m695paddingVpY3zN42);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                java.lang.String str8 = str;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str8);
                if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor3);
                } else {
                    composer2.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                    m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                    m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                java.lang.String str9 = str4;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, str9);
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -725187012, "C226@9305L305:HomeScreen.kt#8mqhoj");
                str3 = str6;
                long sp2 = androidx.compose.ui.unit.TextUnitKt.getSp(13);
                androidx.compose.ui.text.font.FontWeight.Companion companion2 = androidx.compose.ui.text.font.FontWeight.INSTANCE;
                str4 = str9;
                homeViewModel2 = homeViewModel3;
                str = str8;
                androidx.compose.runtime.Composer composer3 = composer2;
                androidx.compose.material3.TextKt.m2386Text4IGK_g(str5, (androidx.compose.ui.Modifier) null, areEqual ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4281811281L), sp2, (androidx.compose.ui.text.font.FontStyle) null, areEqual ? companion2.getBold() : companion2.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3072, 0, 131026);
                composer2 = composer3;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                str2 = str7;
            }
            composer2.endReplaceGroup();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(12)), composer2, 6);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
                return;
            }
            return;
        }
        composer.skipToGroupEnd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$9$lambda$2$lambda$1(com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel) {
        homeViewModel.setCategory(null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$9$lambda$8$lambda$6$lambda$5(com.app.a1bat.ui.screens.home.HomeViewModel homeViewModel, java.lang.String str) {
        homeViewModel.setCategory(str);
        return kotlin.Unit.INSTANCE;
    }
}
