package com.app.a1bat.ui.screens.booking;

/* compiled from: BookConsultationScreen.kt */
@kotlin.Metadata(d1 = {"\u0000R\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a1\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\u0010\n\u001aO\u0010\u000b\u001a\u00020\u00012\u0006\u0010\f\u001a\u00020\r2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00010\u000f2\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u00122\b\b\u0002\u0010\u0013\u001a\u00020\u00142\b\b\u0002\u0010\u0015\u001a\u00020\u0016H\u0007¢\u0006\u0004\b\u0017\u0010\u0018¨\u0006\u0019²\u0006\f\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u008a\u0084\u0002²\u0006\f\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u008a\u0084\u0002²\u0006\n\u0010\u001e\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\u001f\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010 \u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010!\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\"\u001a\u00020\rX\u008a\u008e\u0002"}, d2 = {"BookConsultationScreen", "", "serviceId", "", "navController", "Landroidx/navigation/NavController;", "serviceViewModel", "Lcom/app/a1bat/ui/screens/home/ServiceDetailsViewModel;", "bookingViewModel", "Lcom/app/a1bat/ui/screens/booking/BookingViewModel;", "(ILandroidx/navigation/NavController;Lcom/app/a1bat/ui/screens/home/ServiceDetailsViewModel;Lcom/app/a1bat/ui/screens/booking/BookingViewModel;Landroidx/compose/runtime/Composer;II)V", "PremiumTextField", "value", "", "onValueChange", "Lkotlin/Function1;", "label", "icon", "Landroidx/compose/ui/graphics/vector/ImageVector;", "isRequired", "", "keyboardType", "Landroidx/compose/ui/text/input/KeyboardType;", "PremiumTextField-KznfkUg", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroidx/compose/ui/graphics/vector/ImageVector;ZILandroidx/compose/runtime/Composer;II)V", "app_release", androidx.core.app.NotificationCompat.CATEGORY_SERVICE, "Lcom/app/a1bat/domain/model/ConsultingService;", "bookingSuccess", "Lcom/app/a1bat/domain/model/Booking;", "firstName", "lastName", "email", "companyName", "notes"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class BookConsultationScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit BookConsultationScreen$lambda$22(int i, androidx.navigation.NavController navController, com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel, com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) {
        BookConsultationScreen(i, navController, serviceDetailsViewModel, bookingViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit PremiumTextField_KznfkUg$lambda$25(java.lang.String str, kotlin.jvm.functions.Function1 function1, java.lang.String str2, androidx.compose.ui.graphics.vector.ImageVector imageVector, boolean z, int i, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) {
        m7384PremiumTextFieldKznfkUg(str, function1, str2, imageVector, z, i, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:42:0x00b1, code lost:
    
        if ((r32 & 8) != 0) goto L74;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void BookConsultationScreen(final int i, final androidx.navigation.NavController navController, com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel, com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, androidx.compose.runtime.Composer composer, final int i2, final int i3) {
        int i4;
        com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel2;
        com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel2;
        final com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel3;
        int i5;
        java.lang.String str;
        final com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel3;
        int i6;
        int i7;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navController, "navController");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-1597595149);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(BookConsultationScreen)P(2,1,3)80@3631L16,81@3706L16,82@3764L7,84@3794L31,85@3846L31,86@3895L31,87@3950L31,88@3999L31,90@4052L27,92@4111L99,92@4085L125,182@7945L80,185@8044L1219,215@9270L9946,181@7888L11328:BookConsultationScreen.kt#rof5hh");
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (startRestartGroup.changed(i) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= startRestartGroup.changedInstance(navController) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            if ((i3 & 4) == 0) {
                serviceDetailsViewModel2 = serviceDetailsViewModel;
                if (startRestartGroup.changedInstance(serviceDetailsViewModel2)) {
                    i7 = 256;
                    i4 |= i7;
                }
            } else {
                serviceDetailsViewModel2 = serviceDetailsViewModel;
            }
            i7 = 128;
            i4 |= i7;
        } else {
            serviceDetailsViewModel2 = serviceDetailsViewModel;
        }
        if ((i2 & 3072) == 0) {
            if ((i3 & 8) == 0) {
                bookingViewModel2 = bookingViewModel;
                if (startRestartGroup.changedInstance(bookingViewModel2)) {
                    i6 = 2048;
                    i4 |= i6;
                }
            } else {
                bookingViewModel2 = bookingViewModel;
            }
            i6 = 1024;
            i4 |= i6;
        } else {
            bookingViewModel2 = bookingViewModel;
        }
        if ((i4 & 1171) == 1170 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
            serviceDetailsViewModel3 = serviceDetailsViewModel2;
            bookingViewModel3 = bookingViewModel2;
        } else {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "77@3509L15,78@3567L15");
            if ((i2 & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if ((i3 & 4) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.home.ServiceDetailsViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    serviceDetailsViewModel2 = (com.app.a1bat.ui.screens.home.ServiceDetailsViewModel) resolveViewModel;
                    i4 &= -897;
                }
                if ((i3 & 8) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current2 = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current2 == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel2 = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.booking.BookingViewModel.class), current2.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current2, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    bookingViewModel2 = (com.app.a1bat.ui.screens.booking.BookingViewModel) resolveViewModel2;
                    i4 &= -7169;
                }
                com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel4 = serviceDetailsViewModel2;
                int i8 = i4;
                serviceDetailsViewModel3 = serviceDetailsViewModel4;
                final com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel4 = bookingViewModel2;
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1597595149, i8, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen (BookConsultationScreen.kt:79)");
                }
                androidx.compose.runtime.State collectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(serviceDetailsViewModel3.getService(), null, startRestartGroup, 0, 1);
                final androidx.compose.runtime.State collectAsState2 = androidx.compose.runtime.SnapshotStateKt.collectAsState(bookingViewModel4.getBookingSuccess(), null, startRestartGroup, 0, 1);
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.focus.FocusManager> localFocusManager = androidx.compose.ui.platform.CompositionLocalsKt.getLocalFocusManager();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object consume = startRestartGroup.consume(localFocusManager);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.ui.focus.FocusManager focusManager = (androidx.compose.ui.focus.FocusManager) consume;
                startRestartGroup.startReplaceGroup(-32111056);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue = startRestartGroup.rememberedValue();
                if (rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue);
                }
                androidx.compose.runtime.MutableState mutableState = (androidx.compose.runtime.MutableState) rememberedValue;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(-32109392);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue2 = startRestartGroup.rememberedValue();
                if (rememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue2 = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue2);
                }
                androidx.compose.runtime.MutableState mutableState2 = (androidx.compose.runtime.MutableState) rememberedValue2;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(-32107824);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue3 = startRestartGroup.rememberedValue();
                if (rememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue3 = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue3);
                }
                androidx.compose.runtime.MutableState mutableState3 = (androidx.compose.runtime.MutableState) rememberedValue3;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(-32106064);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue4 = startRestartGroup.rememberedValue();
                if (rememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue4 = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue4);
                }
                androidx.compose.runtime.MutableState mutableState4 = (androidx.compose.runtime.MutableState) rememberedValue4;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(-32104496);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue5 = startRestartGroup.rememberedValue();
                if (rememberedValue5 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue5 = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue5);
                }
                androidx.compose.runtime.MutableState mutableState5 = (androidx.compose.runtime.MutableState) rememberedValue5;
                startRestartGroup.endReplaceGroup();
                startRestartGroup.startReplaceGroup(-32102804);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                java.lang.Object rememberedValue6 = startRestartGroup.rememberedValue();
                if (rememberedValue6 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue6 = androidx.compose.animation.core.AnimatableKt.Animatable$default(0.0f, 0.0f, 2, null);
                    startRestartGroup.updateRememberedValue(rememberedValue6);
                }
                androidx.compose.animation.core.Animatable animatable = (androidx.compose.animation.core.Animatable) rememberedValue6;
                startRestartGroup.endReplaceGroup();
                java.lang.Integer valueOf = java.lang.Integer.valueOf(i);
                startRestartGroup.startReplaceGroup(-32100844);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                int i9 = i8 & 14;
                boolean changedInstance = startRestartGroup.changedInstance(serviceDetailsViewModel3) | (i9 == 4) | startRestartGroup.changedInstance(animatable);
                com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$1$1 rememberedValue7 = startRestartGroup.rememberedValue();
                if (changedInstance || rememberedValue7 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue7 = new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$1$1(serviceDetailsViewModel3, i, animatable, null);
                    startRestartGroup.updateRememberedValue(rememberedValue7);
                }
                startRestartGroup.endReplaceGroup();
                androidx.compose.runtime.EffectsKt.LaunchedEffect(valueOf, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) rememberedValue7, startRestartGroup, i9);
                startRestartGroup.startReplaceGroup(-32093917);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "99@4293L237,107@4643L3233,98@4254L3622");
                if (BookConsultationScreen$lambda$1(collectAsState2) != null) {
                    startRestartGroup.startReplaceGroup(-32094882);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):BookConsultationScreen.kt#9igjgp");
                    boolean changedInstance2 = startRestartGroup.changedInstance(bookingViewModel4) | startRestartGroup.changedInstance(navController);
                    java.lang.Object rememberedValue8 = startRestartGroup.rememberedValue();
                    if (changedInstance2 || rememberedValue8 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        rememberedValue8 = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                kotlin.Unit BookConsultationScreen$lambda$20$lambda$19;
                                BookConsultationScreen$lambda$20$lambda$19 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$20$lambda$19(com.app.a1bat.ui.screens.booking.BookingViewModel.this, navController);
                                return BookConsultationScreen$lambda$20$lambda$19;
                            }
                        };
                        startRestartGroup.updateRememberedValue(rememberedValue8);
                    }
                    startRestartGroup.endReplaceGroup();
                    androidx.compose.ui.window.DialogProperties dialogProperties = new androidx.compose.ui.window.DialogProperties(false, false, false, 4, (kotlin.jvm.internal.DefaultConstructorMarker) null);
                    androidx.compose.runtime.internal.ComposableLambda rememberComposableLambda = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1756056319, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3
                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer2, java.lang.Integer num) {
                            invoke(composer2, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        public final void invoke(androidx.compose.runtime.Composer composer2, int i10) {
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C113@4859L3007,108@4657L3209:BookConsultationScreen.kt#rof5hh");
                            if ((i10 & 3) != 2 || !composer2.getSkipping()) {
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(-1756056319, i10, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous> (BookConsultationScreen.kt:108)");
                                }
                                float f = 24;
                                androidx.compose.material3.SurfaceKt.m2236SurfaceT9BRK9s(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(0)), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0L, 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(f), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(167960966, true, new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3.AnonymousClass1(com.app.a1bat.ui.screens.booking.BookingViewModel.this, navController, collectAsState2), composer2, 54), composer2, 12779910, 88);
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                    return;
                                }
                                return;
                            }
                            composer2.skipToGroupEnd();
                        }

                        /* compiled from: BookConsultationScreen.kt */
                        @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                        /* renamed from: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3$1, reason: invalid class name */
                        static final class AnonymousClass1 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
                            final /* synthetic */ androidx.compose.runtime.State<com.app.a1bat.domain.model.Booking> $bookingSuccess$delegate;
                            final /* synthetic */ com.app.a1bat.ui.screens.booking.BookingViewModel $bookingViewModel;
                            final /* synthetic */ androidx.navigation.NavController $navController;

                            AnonymousClass1(com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, androidx.navigation.NavController navController, androidx.compose.runtime.State<com.app.a1bat.domain.model.Booking> state) {
                                this.$bookingViewModel = bookingViewModel;
                                this.$navController = navController;
                                this.$bookingSuccess$delegate = state;
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                                invoke(composer, num.intValue());
                                return kotlin.Unit.INSTANCE;
                            }

                            public final void invoke(androidx.compose.runtime.Composer composer, int i) {
                                com.app.a1bat.domain.model.Booking BookConsultationScreen$lambda$1;
                                com.app.a1bat.domain.model.Booking BookConsultationScreen$lambda$12;
                                com.app.a1bat.domain.model.Booking BookConsultationScreen$lambda$13;
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C114@4877L2975:BookConsultationScreen.kt#rof5hh");
                                if ((i & 3) != 2 || !composer.getSkipping()) {
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventStart(167960966, i, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous>.<anonymous> (BookConsultationScreen.kt:114)");
                                    }
                                    androidx.compose.ui.Modifier m694padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(32));
                                    androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
                                    final com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel = this.$bookingViewModel;
                                    final androidx.navigation.NavController navController = this.$navController;
                                    androidx.compose.runtime.State<com.app.a1bat.domain.model.Booking> state = this.$bookingSuccess$delegate;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), centerHorizontally, composer, 48);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m694padding3ABfNKs);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer.startReusableNode();
                                    if (composer.getInserting()) {
                                        composer.createNode(constructor);
                                    } else {
                                        composer.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                                        m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                                        m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 458832215, "C118@5052L572,131@5645L41,132@5707L221,138@5949L40,139@6010L512,151@6543L41,152@6605L379,159@7005L41,171@7600L42,161@7109L309,160@7067L767:BookConsultationScreen.kt#rof5hh");
                                    androidx.compose.ui.Modifier m248backgroundbw27NRU = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(80)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.1f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                                    androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m248backgroundbw27NRU);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer.startReusableNode();
                                    if (composer.getInserting()) {
                                        composer.createNode(constructor2);
                                    } else {
                                        composer.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                                        m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                                        m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2117536693, "C124@5335L267:BookConsultationScreen.kt#rof5hh");
                                    androidx.compose.material3.IconKt.m1843Iconww6aTOc(androidx.compose.material.icons.filled.CheckCircleKt.getCheckCircle(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Success", androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(48)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), composer, 3504, 0);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    composer.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(20)), composer, 6);
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g("Booking Confirmed!", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(22), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200070, 0, 131026);
                                    float f = 8;
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer, 6);
                                    androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.Modifier.INSTANCE, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f))), androidx.compose.ui.unit.Dp.m6803constructorimpl(12), androidx.compose.ui.unit.Dp.m6803constructorimpl(4));
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m695paddingVpY3zN4);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer.startReusableNode();
                                    if (composer.getInserting()) {
                                        composer.createNode(constructor3);
                                    } else {
                                        composer.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                                        m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                                        m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2116619930, "C144@6260L240:BookConsultationScreen.kt#rof5hh");
                                    BookConsultationScreen$lambda$1 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$1(state);
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g("ID: #" + (BookConsultationScreen$lambda$1 != null ? BookConsultationScreen$lambda$1.getId() : null), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(12), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200064, 0, 131026);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    composer.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(16)), composer, 6);
                                    BookConsultationScreen$lambda$12 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$1(state);
                                    java.lang.String firstName = BookConsultationScreen$lambda$12 != null ? BookConsultationScreen$lambda$12.getFirstName() : null;
                                    BookConsultationScreen$lambda$13 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$1(state);
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g("Thank you, " + firstName + "! A senior consultant will contact you shortly regarding " + (BookConsultationScreen$lambda$13 != null ? BookConsultationScreen$lambda$13.getServiceName() : null) + ".", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4285231744L), androidx.compose.ui.unit.TextUnitKt.getSp(14), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, androidx.compose.ui.text.style.TextAlign.m6680boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m6687getCentere0LSkKk()), androidx.compose.ui.unit.TextUnitKt.getSp(21), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3456, 6, 129522);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(28)), composer, 6);
                                    androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(52));
                                    androidx.compose.material3.ButtonColors m1501buttonColorsro_MJ88 = androidx.compose.material3.ButtonDefaults.INSTANCE.m1501buttonColorsro_MJ88(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0L, 0L, 0L, composer, (androidx.compose.material3.ButtonDefaults.$stable << 12) | 6, 14);
                                    androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14));
                                    composer.startReplaceGroup(984695715);
                                    androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
                                    boolean changedInstance = composer.changedInstance(bookingViewModel) | composer.changedInstance(navController);
                                    java.lang.Object rememberedValue = composer.rememberedValue();
                                    if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                                        rememberedValue = 
                                        /*  JADX ERROR: Method code generation error
                                            jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x04e7: CONSTRUCTOR (r4v23 'rememberedValue' java.lang.Object) = 
                                              (r9v0 'bookingViewModel' com.app.a1bat.ui.screens.booking.BookingViewModel A[DONT_INLINE])
                                              (r10v0 'navController' androidx.navigation.NavController A[DONT_INLINE])
                                             A[MD:(com.app.a1bat.ui.screens.booking.BookingViewModel, androidx.navigation.NavController):void (m)] (LINE:162) call: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3$1$$ExternalSyntheticLambda0.<init>(com.app.a1bat.ui.screens.booking.BookingViewModel, androidx.navigation.NavController):void type: CONSTRUCTOR in method: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3.1.invoke(androidx.compose.runtime.Composer, int):void, file: classes3.dex
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                                            	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:297)
                                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:276)
                                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:406)
                                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
                                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
                                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                                            	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                                            	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                            	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                                            Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Expected class to be processed at this point, class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3$1$$ExternalSyntheticLambda0, state: NOT_LOADED
                                            	at jadx.core.dex.nodes.ClassNode.ensureProcessed(ClassNode.java:305)
                                            	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:807)
                                            	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:730)
                                            	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:418)
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:303)
                                            	... 29 more
                                            */
                                        /*
                                            Method dump skipped, instructions count: 1320
                                            To view this dump add '--comments-level debug' option
                                        */
                                        throw new UnsupportedOperationException("Method not decompiled: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$3.AnonymousClass1.invoke(androidx.compose.runtime.Composer, int):void");
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
                                    public static final kotlin.Unit invoke$lambda$4$lambda$3$lambda$2(com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, androidx.navigation.NavController navController) {
                                        bookingViewModel.resetBookingSuccess();
                                        androidx.navigation.NavController.popBackStack$default(navController, com.app.a1bat.ui.navigation.Screen.Main.INSTANCE.getRoute(), false, false, 4, (java.lang.Object) null);
                                        return kotlin.Unit.INSTANCE;
                                    }
                                }
                            }, startRestartGroup, 54);
                            str = "CC(remember):BookConsultationScreen.kt#9igjgp";
                            i5 = 54;
                            androidx.compose.ui.window.AndroidDialog_androidKt.Dialog((kotlin.jvm.functions.Function0) rememberedValue8, dialogProperties, rememberComposableLambda, startRestartGroup, 432, 0);
                        } else {
                            i5 = 54;
                            str = "CC(remember):BookConsultationScreen.kt#9igjgp";
                        }
                        startRestartGroup.endReplaceGroup();
                        androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                        kotlin.Unit unit = kotlin.Unit.INSTANCE;
                        startRestartGroup.startReplaceGroup(-31978175);
                        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, str);
                        boolean changedInstance3 = startRestartGroup.changedInstance(focusManager);
                        com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$4$1 rememberedValue9 = startRestartGroup.rememberedValue();
                        if (changedInstance3 || rememberedValue9 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                            rememberedValue9 = new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$4$1(focusManager);
                            startRestartGroup.updateRememberedValue(rememberedValue9);
                        }
                        startRestartGroup.endReplaceGroup();
                        androidx.compose.ui.Modifier pointerInput = androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt.pointerInput(companion, unit, (androidx.compose.ui.input.pointer.PointerInputEventHandler) rememberedValue9);
                        androidx.compose.runtime.internal.ComposableLambda rememberComposableLambda2 = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1449145263, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5
                            @Override // kotlin.jvm.functions.Function2
                            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer2, java.lang.Integer num) {
                                invoke(composer2, num.intValue());
                                return kotlin.Unit.INSTANCE;
                            }

                            public final void invoke(androidx.compose.runtime.Composer composer2, int i10) {
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C195@8386L763,212@9194L45,186@8058L1195:BookConsultationScreen.kt#rof5hh");
                                if ((i10 & 3) != 2 || !composer2.getSkipping()) {
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventStart(1449145263, i10, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous> (BookConsultationScreen.kt:186)");
                                    }
                                    androidx.compose.material3.AppBarKt.m1465TopAppBarGHTll3U(com.app.a1bat.ui.screens.booking.ComposableSingletons$BookConsultationScreenKt.INSTANCE.m7392getLambda2$app_release(), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1378425205, true, new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5.AnonymousClass1(androidx.navigation.NavController.this), composer2, 54), null, 0.0f, null, androidx.compose.material3.TopAppBarDefaults.INSTANCE.m2557topAppBarColorszjMxDiM(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0L, 0L, 0L, 0L, composer2, (androidx.compose.material3.TopAppBarDefaults.$stable << 15) | 6, 30), null, composer2, 390, 186);
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                                        return;
                                    }
                                    return;
                                }
                                composer2.skipToGroupEnd();
                            }

                            /* compiled from: BookConsultationScreen.kt */
                            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                            /* renamed from: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5$1, reason: invalid class name */
                            static final class AnonymousClass1 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
                                final /* synthetic */ androidx.navigation.NavController $navController;

                                AnonymousClass1(androidx.navigation.NavController navController) {
                                    this.$navController = navController;
                                }

                                @Override // kotlin.jvm.functions.Function2
                                public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                                    invoke(composer, num.intValue());
                                    return kotlin.Unit.INSTANCE;
                                }

                                /* JADX INFO: Access modifiers changed from: private */
                                public static final kotlin.Unit invoke$lambda$1$lambda$0(androidx.navigation.NavController navController) {
                                    navController.navigateUp();
                                    return kotlin.Unit.INSTANCE;
                                }

                                public final void invoke(androidx.compose.runtime.Composer composer, int i) {
                                    androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C196@8429L30,196@8408L723:BookConsultationScreen.kt#rof5hh");
                                    if ((i & 3) == 2 && composer.getSkipping()) {
                                        composer.skipToGroupEnd();
                                        return;
                                    }
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventStart(1378425205, i, -1, "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous>.<anonymous> (BookConsultationScreen.kt:196)");
                                    }
                                    composer.startReplaceGroup(435332109);
                                    androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookConsultationScreen.kt#9igjgp");
                                    boolean changedInstance = composer.changedInstance(this.$navController);
                                    final androidx.navigation.NavController navController = this.$navController;
                                    java.lang.Object rememberedValue = composer.rememberedValue();
                                    if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                                        rememberedValue = 
                                        /*  JADX ERROR: Method code generation error
                                            jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0047: CONSTRUCTOR (r1v2 'rememberedValue' java.lang.Object) = (r0v3 'navController' androidx.navigation.NavController A[DONT_INLINE]) A[MD:(androidx.navigation.NavController):void (m)] (LINE:197) call: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5$1$$ExternalSyntheticLambda0.<init>(androidx.navigation.NavController):void type: CONSTRUCTOR in method: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5.1.invoke(androidx.compose.runtime.Composer, int):void, file: classes3.dex
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                                            	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:297)
                                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:276)
                                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:406)
                                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
                                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
                                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                                            	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                                            	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                            	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                                            Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Expected class to be processed at this point, class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5$1$$ExternalSyntheticLambda0, state: NOT_LOADED
                                            	at jadx.core.dex.nodes.ClassNode.ensureProcessed(ClassNode.java:305)
                                            	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:807)
                                            	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:730)
                                            	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:418)
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:303)
                                            	... 25 more
                                            */
                                        /*
                                            this = this;
                                            java.lang.String r0 = "C196@8429L30,196@8408L723:BookConsultationScreen.kt#rof5hh"
                                            androidx.compose.runtime.ComposerKt.sourceInformation(r12, r0)
                                            r0 = r13 & 3
                                            r1 = 2
                                            if (r0 != r1) goto L15
                                            boolean r0 = r12.getSkipping()
                                            if (r0 != 0) goto L11
                                            goto L15
                                        L11:
                                            r12.skipToGroupEnd()
                                            return
                                        L15:
                                            boolean r0 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
                                            if (r0 == 0) goto L24
                                            r0 = -1
                                            java.lang.String r1 = "com.app.a1bat.ui.screens.booking.BookConsultationScreen.<anonymous>.<anonymous> (BookConsultationScreen.kt:196)"
                                            r2 = 1378425205(0x52291975, float:1.8156914E11)
                                            androidx.compose.runtime.ComposerKt.traceEventStart(r2, r13, r0, r1)
                                        L24:
                                            r13 = 435332109(0x19f2a40d, float:2.5088473E-23)
                                            r12.startReplaceGroup(r13)
                                            java.lang.String r13 = "CC(remember):BookConsultationScreen.kt#9igjgp"
                                            androidx.compose.runtime.ComposerKt.sourceInformation(r12, r13)
                                            androidx.navigation.NavController r13 = r11.$navController
                                            boolean r13 = r12.changedInstance(r13)
                                            androidx.navigation.NavController r0 = r11.$navController
                                            java.lang.Object r1 = r12.rememberedValue()
                                            if (r13 != 0) goto L45
                                            androidx.compose.runtime.Composer$Companion r13 = androidx.compose.runtime.Composer.INSTANCE
                                            java.lang.Object r13 = r13.getEmpty()
                                            if (r1 != r13) goto L4d
                                        L45:
                                            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5$1$$ExternalSyntheticLambda0 r1 = new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5$1$$ExternalSyntheticLambda0
                                            r1.<init>(r0)
                                            r12.updateRememberedValue(r1)
                                        L4d:
                                            r2 = r1
                                            kotlin.jvm.functions.Function0 r2 = (kotlin.jvm.functions.Function0) r2
                                            r12.endReplaceGroup()
                                            com.app.a1bat.ui.screens.booking.ComposableSingletons$BookConsultationScreenKt r13 = com.app.a1bat.ui.screens.booking.ComposableSingletons$BookConsultationScreenKt.INSTANCE
                                            kotlin.jvm.functions.Function2 r7 = r13.m7393getLambda3$app_release()
                                            r9 = 196608(0x30000, float:2.75506E-40)
                                            r10 = 30
                                            r3 = 0
                                            r4 = 0
                                            r5 = 0
                                            r6 = 0
                                            r8 = r12
                                            androidx.compose.material3.IconButtonKt.IconButton(r2, r3, r4, r5, r6, r7, r8, r9, r10)
                                            boolean r12 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
                                            if (r12 == 0) goto L6e
                                            androidx.compose.runtime.ComposerKt.traceEventEnd()
                                        L6e:
                                            return
                                        */
                                        throw new UnsupportedOperationException("Method not decompiled: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$5.AnonymousClass1.invoke(androidx.compose.runtime.Composer, int):void");
                                    }
                                }
                            }, startRestartGroup, i5);
                            com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6 bookConsultationScreenKt$BookConsultationScreen$6 = new com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$BookConsultationScreen$6(animatable, collectAsState, mutableState, mutableState2, mutableState3, mutableState4, mutableState5, bookingViewModel4);
                            bookingViewModel3 = bookingViewModel4;
                            androidx.compose.material3.ScaffoldKt.m2101ScaffoldTvnljyQ(pointerInput, rememberComposableLambda2, null, null, null, 0, 0L, 0L, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1680462652, true, bookConsultationScreenKt$BookConsultationScreen$6, startRestartGroup, i5), startRestartGroup, 805306416, 508);
                            startRestartGroup = startRestartGroup;
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                            }
                        } else {
                            startRestartGroup.skipToGroupEnd();
                            if ((i3 & 4) != 0) {
                                i4 &= -897;
                            }
                        }
                    }
                    androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
                    if (endRestartGroup != null) {
                        endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function2
                            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                                kotlin.Unit BookConsultationScreen$lambda$22;
                                BookConsultationScreen$lambda$22 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.BookConsultationScreen$lambda$22(i, navController, serviceDetailsViewModel3, bookingViewModel3, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                                return BookConsultationScreen$lambda$22;
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final java.lang.String BookConsultationScreen$lambda$3(androidx.compose.runtime.MutableState<java.lang.String> mutableState) {
                    return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final java.lang.String BookConsultationScreen$lambda$6(androidx.compose.runtime.MutableState<java.lang.String> mutableState) {
                    return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final java.lang.String BookConsultationScreen$lambda$9(androidx.compose.runtime.MutableState<java.lang.String> mutableState) {
                    return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final java.lang.String BookConsultationScreen$lambda$12(androidx.compose.runtime.MutableState<java.lang.String> mutableState) {
                    return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final java.lang.String BookConsultationScreen$lambda$15(androidx.compose.runtime.MutableState<java.lang.String> mutableState) {
                    return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final kotlin.Unit BookConsultationScreen$lambda$20$lambda$19(com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, androidx.navigation.NavController navController) {
                    bookingViewModel.resetBookingSuccess();
                    androidx.navigation.NavController.popBackStack$default(navController, com.app.a1bat.ui.navigation.Screen.Main.INSTANCE.getRoute(), false, false, 4, (java.lang.Object) null);
                    return kotlin.Unit.INSTANCE;
                }

                /* JADX WARN: Removed duplicated region for block: B:19:0x00aa  */
                /* JADX WARN: Removed duplicated region for block: B:23:0x00c9  */
                /* JADX WARN: Removed duplicated region for block: B:28:0x0463  */
                /* JADX WARN: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
                /* JADX WARN: Removed duplicated region for block: B:34:0x00dc  */
                /* JADX WARN: Removed duplicated region for block: B:36:0x00e3  */
                /* JADX WARN: Removed duplicated region for block: B:39:0x00f4  */
                /* JADX WARN: Removed duplicated region for block: B:42:0x0140  */
                /* JADX WARN: Removed duplicated region for block: B:45:0x014c  */
                /* JADX WARN: Removed duplicated region for block: B:48:0x0175  */
                /* JADX WARN: Removed duplicated region for block: B:52:0x01f0  */
                /* JADX WARN: Removed duplicated region for block: B:55:0x01fc  */
                /* JADX WARN: Removed duplicated region for block: B:58:0x0225  */
                /* JADX WARN: Removed duplicated region for block: B:62:0x02cc  */
                /* JADX WARN: Removed duplicated region for block: B:65:0x0456  */
                /* JADX WARN: Removed duplicated region for block: B:68:0x0200  */
                /* JADX WARN: Removed duplicated region for block: B:70:0x0150  */
                /* JADX WARN: Removed duplicated region for block: B:71:0x00ec  */
                /* JADX WARN: Removed duplicated region for block: B:72:0x00df  */
                /* JADX WARN: Removed duplicated region for block: B:73:0x00ac  */
                /* renamed from: PremiumTextField-KznfkUg, reason: not valid java name */
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public static final void m7384PremiumTextFieldKznfkUg(final java.lang.String value, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onValueChange, final java.lang.String label, final androidx.compose.ui.graphics.vector.ImageVector icon, boolean z, int i, androidx.compose.runtime.Composer composer, final int i2, final int i3) {
                    int i4;
                    boolean z2;
                    int i5;
                    int i6;
                    boolean z3;
                    int currentCompositeKeyHash;
                    androidx.compose.runtime.Composer m3405constructorimpl;
                    int currentCompositeKeyHash2;
                    androidx.compose.runtime.Composer m3405constructorimpl2;
                    androidx.compose.runtime.Composer composer2;
                    final boolean z4;
                    final int i7;
                    androidx.compose.runtime.ScopeUpdateScope endRestartGroup;
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(value, "value");
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onValueChange, "onValueChange");
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(label, "label");
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icon, "icon");
                    androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-1460901483);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(PremiumTextField)P(5,4,3!,2:c#ui.text.input.KeyboardType)471@19484L1628:BookConsultationScreen.kt#rof5hh");
                    if ((i3 & 1) != 0) {
                        i4 = i2 | 6;
                    } else if ((i2 & 6) == 0) {
                        i4 = (startRestartGroup.changed(value) ? 4 : 2) | i2;
                    } else {
                        i4 = i2;
                    }
                    if ((i3 & 2) != 0) {
                        i4 |= 48;
                    } else if ((i2 & 48) == 0) {
                        i4 |= startRestartGroup.changedInstance(onValueChange) ? 32 : 16;
                    }
                    if ((i3 & 4) != 0) {
                        i4 |= 384;
                    } else if ((i2 & 384) == 0) {
                        i4 |= startRestartGroup.changed(label) ? 256 : 128;
                    }
                    if ((i3 & 8) != 0) {
                        i4 |= 3072;
                    } else if ((i2 & 3072) == 0) {
                        i4 |= startRestartGroup.changed(icon) ? 2048 : 1024;
                    }
                    int i8 = i3 & 16;
                    if (i8 != 0) {
                        i4 |= 24576;
                    } else if ((i2 & 24576) == 0) {
                        z2 = z;
                        i4 |= startRestartGroup.changed(z2) ? 16384 : 8192;
                        i5 = i3 & 32;
                        if (i5 == 0) {
                            i4 |= androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE;
                        } else if ((196608 & i2) == 0) {
                            i6 = i;
                            i4 |= startRestartGroup.changed(i6) ? 131072 : 65536;
                            if ((74899 & i4) == 74898 || !startRestartGroup.getSkipping()) {
                                z3 = i8 != 0 ? false : z2;
                                int m6508getTextPjHm6EE = i5 != 0 ? androidx.compose.ui.text.input.KeyboardType.INSTANCE.m6508getTextPjHm6EE() : i6;
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(-1460901483, i4, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField (BookConsultationScreen.kt:470)");
                                }
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), startRestartGroup, 0);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                startRestartGroup.startReusableNode();
                                if (startRestartGroup.getInserting()) {
                                    startRestartGroup.createNode(constructor);
                                } else {
                                    startRestartGroup.useNode();
                                }
                                m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (!m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -807087850, "C472@19501L390,483@19900L40,502@20697L399,487@20064L88,490@20180L266,484@19949L1157:BookConsultationScreen.kt#rof5hh");
                                androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                                androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                                androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, startRestartGroup, 48);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = startRestartGroup.getCurrentCompositionLocalMap();
                                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion2);
                                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                                }
                                startRestartGroup.startReusableNode();
                                if (startRestartGroup.getInserting()) {
                                    startRestartGroup.createNode(constructor2);
                                } else {
                                    startRestartGroup.useNode();
                                }
                                m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                if (!m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                                }
                                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1881248158, "C473@19567L175:BookConsultationScreen.kt#rof5hh");
                                int i9 = i4;
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281811281L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, startRestartGroup, ((i9 >> 6) & 14) | 200064, 0, 131026);
                                startRestartGroup.startReplaceGroup(1601888389);
                                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "480@19789L78");
                                if (z3) {
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g(" *", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, startRestartGroup, 200070, 0, 131026);
                                }
                                startRestartGroup.endReplaceGroup();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                                startRestartGroup.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(6)), startRestartGroup, 6);
                                int i10 = m6508getTextPjHm6EE;
                                composer2 = startRestartGroup;
                                androidx.compose.material3.OutlinedTextFieldKt.OutlinedTextField(value, onValueChange, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), false, false, (androidx.compose.ui.text.TextStyle) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1032466234, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$2
                                    @Override // kotlin.jvm.functions.Function2
                                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                                        invoke(composer3, num.intValue());
                                        return kotlin.Unit.INSTANCE;
                                    }

                                    public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                                        androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C488@20082L56:BookConsultationScreen.kt#rof5hh");
                                        if ((i11 & 3) == 2 && composer3.getSkipping()) {
                                            composer3.skipToGroupEnd();
                                            return;
                                        }
                                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                            androidx.compose.runtime.ComposerKt.traceEventStart(-1032466234, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:488)");
                                        }
                                        androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4290758092L), androidx.compose.ui.unit.TextUnitKt.getSp(14), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 0, 131058);
                                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                            androidx.compose.runtime.ComposerKt.traceEventEnd();
                                        }
                                    }
                                }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-105711481, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$3
                                    @Override // kotlin.jvm.functions.Function2
                                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                                        invoke(composer3, num.intValue());
                                        return kotlin.Unit.INSTANCE;
                                    }

                                    public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                                        androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C491@20198L234:BookConsultationScreen.kt#rof5hh");
                                        if ((i11 & 3) != 2 || !composer3.getSkipping()) {
                                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                                androidx.compose.runtime.ComposerKt.traceEventStart(-105711481, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:491)");
                                            }
                                            androidx.compose.material3.IconKt.m1843Iconww6aTOc(icon, (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(20)), value.length() > 0 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4290758092L), composer3, 432, 0);
                                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                                                return;
                                            }
                                            return;
                                        }
                                        composer3.skipToGroupEnd();
                                    }
                                }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, false, (androidx.compose.ui.text.input.VisualTransformation) null, new androidx.compose.foundation.text.KeyboardOptions(0, (java.lang.Boolean) null, i10, 0, (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 123, (kotlin.jvm.internal.DefaultConstructorMarker) null), (androidx.compose.foundation.text.KeyboardActions) null, true, 0, 0, (androidx.compose.foundation.interaction.MutableInteractionSource) null, (androidx.compose.ui.graphics.Shape) androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14)), androidx.compose.material3.OutlinedTextFieldDefaults.INSTANCE.m2036colors0hiis_0(androidx.compose.ui.graphics.ColorKt.Color(4279900718L), androidx.compose.ui.graphics.ColorKt.Color(4279900718L), 0L, 0L, androidx.compose.ui.graphics.ColorKt.Color(4294638588L), androidx.compose.ui.graphics.ColorKt.Color(4294638588L), 0L, 0L, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.graphics.ColorKt.Color(4293454576L), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, startRestartGroup, 100884534, 432, 0, 0, 3072, 2147477196, 4095), composer2, (i9 & 14) | 113246592 | (i9 & 112), 12582912, 0, 1932920);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                                composer2.endNode();
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                }
                                z4 = z3;
                                i7 = i10;
                            } else {
                                startRestartGroup.skipToGroupEnd();
                                composer2 = startRestartGroup;
                                z4 = z2;
                                i7 = i6;
                            }
                            endRestartGroup = composer2.endRestartGroup();
                            if (endRestartGroup != null) {
                                endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function2
                                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                                        kotlin.Unit PremiumTextField_KznfkUg$lambda$25;
                                        PremiumTextField_KznfkUg$lambda$25 = com.app.a1bat.ui.screens.booking.BookConsultationScreenKt.PremiumTextField_KznfkUg$lambda$25(value, onValueChange, label, icon, z4, i7, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                                        return PremiumTextField_KznfkUg$lambda$25;
                                    }
                                });
                                return;
                            }
                            return;
                        }
                        i6 = i;
                        if ((74899 & i4) == 74898) {
                        }
                        if (i8 != 0) {
                        }
                        if (i5 != 0) {
                        }
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        }
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                        androidx.compose.ui.Modifier.Companion companion3 = androidx.compose.ui.Modifier.INSTANCE;
                        androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), startRestartGroup, 0);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = startRestartGroup.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion3);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        }
                        startRestartGroup.startReusableNode();
                        if (startRestartGroup.getInserting()) {
                        }
                        m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (!m3405constructorimpl.getInserting()) {
                        }
                        m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                        m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash3);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                        androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -807087850, "C472@19501L390,483@19900L40,502@20697L399,487@20064L88,490@20180L266,484@19949L1157:BookConsultationScreen.kt#rof5hh");
                        androidx.compose.ui.Alignment.Vertical centerVertically2 = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                        androidx.compose.ui.Modifier.Companion companion22 = androidx.compose.ui.Modifier.INSTANCE;
                        androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy2 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically2, startRestartGroup, 48);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap22 = startRestartGroup.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier22 = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion22);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor22 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        }
                        startRestartGroup.startReusableNode();
                        if (startRestartGroup.getInserting()) {
                        }
                        m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, rowMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap22, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash22 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (!m3405constructorimpl2.getInserting()) {
                        }
                        m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                        m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash22);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier22, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                        androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1881248158, "C473@19567L175:BookConsultationScreen.kt#rof5hh");
                        int i92 = i4;
                        androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281811281L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, startRestartGroup, ((i92 >> 6) & 14) | 200064, 0, 131026);
                        startRestartGroup.startReplaceGroup(1601888389);
                        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "480@19789L78");
                        if (z3) {
                        }
                        startRestartGroup.endReplaceGroup();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                        startRestartGroup.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(6)), startRestartGroup, 6);
                        int i102 = m6508getTextPjHm6EE;
                        composer2 = startRestartGroup;
                        androidx.compose.material3.OutlinedTextFieldKt.OutlinedTextField(value, onValueChange, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), false, false, (androidx.compose.ui.text.TextStyle) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1032466234, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$2
                            @Override // kotlin.jvm.functions.Function2
                            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                                invoke(composer3, num.intValue());
                                return kotlin.Unit.INSTANCE;
                            }

                            public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C488@20082L56:BookConsultationScreen.kt#rof5hh");
                                if ((i11 & 3) == 2 && composer3.getSkipping()) {
                                    composer3.skipToGroupEnd();
                                    return;
                                }
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(-1032466234, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:488)");
                                }
                                androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4290758092L), androidx.compose.ui.unit.TextUnitKt.getSp(14), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 0, 131058);
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                }
                            }
                        }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-105711481, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$3
                            @Override // kotlin.jvm.functions.Function2
                            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                                invoke(composer3, num.intValue());
                                return kotlin.Unit.INSTANCE;
                            }

                            public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C491@20198L234:BookConsultationScreen.kt#rof5hh");
                                if ((i11 & 3) != 2 || !composer3.getSkipping()) {
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventStart(-105711481, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:491)");
                                    }
                                    androidx.compose.material3.IconKt.m1843Iconww6aTOc(icon, (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(20)), value.length() > 0 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4290758092L), composer3, 432, 0);
                                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                                        return;
                                    }
                                    return;
                                }
                                composer3.skipToGroupEnd();
                            }
                        }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, false, (androidx.compose.ui.text.input.VisualTransformation) null, new androidx.compose.foundation.text.KeyboardOptions(0, (java.lang.Boolean) null, i102, 0, (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 123, (kotlin.jvm.internal.DefaultConstructorMarker) null), (androidx.compose.foundation.text.KeyboardActions) null, true, 0, 0, (androidx.compose.foundation.interaction.MutableInteractionSource) null, (androidx.compose.ui.graphics.Shape) androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14)), androidx.compose.material3.OutlinedTextFieldDefaults.INSTANCE.m2036colors0hiis_0(androidx.compose.ui.graphics.ColorKt.Color(4279900718L), androidx.compose.ui.graphics.ColorKt.Color(4279900718L), 0L, 0L, androidx.compose.ui.graphics.ColorKt.Color(4294638588L), androidx.compose.ui.graphics.ColorKt.Color(4294638588L), 0L, 0L, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.graphics.ColorKt.Color(4293454576L), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, startRestartGroup, 100884534, 432, 0, 0, 3072, 2147477196, 4095), composer2, (i92 & 14) | 113246592 | (i92 & 112), 12582912, 0, 1932920);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        }
                        z4 = z3;
                        i7 = i102;
                        endRestartGroup = composer2.endRestartGroup();
                        if (endRestartGroup != null) {
                        }
                    }
                    z2 = z;
                    i5 = i3 & 32;
                    if (i5 == 0) {
                    }
                    i6 = i;
                    if ((74899 & i4) == 74898) {
                    }
                    if (i8 != 0) {
                    }
                    if (i5 != 0) {
                    }
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                    androidx.compose.ui.Modifier.Companion companion32 = androidx.compose.ui.Modifier.INSTANCE;
                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy22 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), startRestartGroup, 0);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap32 = startRestartGroup.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier32 = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion32);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor32 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    }
                    startRestartGroup.startReusableNode();
                    if (startRestartGroup.getInserting()) {
                    }
                    m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy22, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap32, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash32 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!m3405constructorimpl.getInserting()) {
                    }
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash32);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier32, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance22 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -807087850, "C472@19501L390,483@19900L40,502@20697L399,487@20064L88,490@20180L266,484@19949L1157:BookConsultationScreen.kt#rof5hh");
                    androidx.compose.ui.Alignment.Vertical centerVertically22 = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                    androidx.compose.ui.Modifier.Companion companion222 = androidx.compose.ui.Modifier.INSTANCE;
                    androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy22 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically22, startRestartGroup, 48);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap222 = startRestartGroup.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier materializeModifier222 = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, companion222);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor222 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    }
                    startRestartGroup.startReusableNode();
                    if (startRestartGroup.getInserting()) {
                    }
                    m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, rowMeasurePolicy22, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap222, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash222 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!m3405constructorimpl2.getInserting()) {
                    }
                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash222);
                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier222, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                    androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance22 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1881248158, "C473@19567L175:BookConsultationScreen.kt#rof5hh");
                    int i922 = i4;
                    androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281811281L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, startRestartGroup, ((i922 >> 6) & 14) | 200064, 0, 131026);
                    startRestartGroup.startReplaceGroup(1601888389);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "480@19789L78");
                    if (z3) {
                    }
                    startRestartGroup.endReplaceGroup();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                    startRestartGroup.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(6)), startRestartGroup, 6);
                    int i1022 = m6508getTextPjHm6EE;
                    composer2 = startRestartGroup;
                    androidx.compose.material3.OutlinedTextFieldKt.OutlinedTextField(value, onValueChange, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), false, false, (androidx.compose.ui.text.TextStyle) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1032466234, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$2
                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                            invoke(composer3, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C488@20082L56:BookConsultationScreen.kt#rof5hh");
                            if ((i11 & 3) == 2 && composer3.getSkipping()) {
                                composer3.skipToGroupEnd();
                                return;
                            }
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(-1032466234, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:488)");
                            }
                            androidx.compose.material3.TextKt.m2386Text4IGK_g(label, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4290758092L), androidx.compose.ui.unit.TextUnitKt.getSp(14), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 0, 131058);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                            }
                        }
                    }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-105711481, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.booking.BookConsultationScreenKt$PremiumTextField$1$3
                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                            invoke(composer3, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        public final void invoke(androidx.compose.runtime.Composer composer3, int i11) {
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C491@20198L234:BookConsultationScreen.kt#rof5hh");
                            if ((i11 & 3) != 2 || !composer3.getSkipping()) {
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(-105711481, i11, -1, "com.app.a1bat.ui.screens.booking.PremiumTextField.<anonymous>.<anonymous> (BookConsultationScreen.kt:491)");
                                }
                                androidx.compose.material3.IconKt.m1843Iconww6aTOc(icon, (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(20)), value.length() > 0 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.ColorKt.Color(4290758092L), composer3, 432, 0);
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                    return;
                                }
                                return;
                            }
                            composer3.skipToGroupEnd();
                        }
                    }, startRestartGroup, 54), (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, false, (androidx.compose.ui.text.input.VisualTransformation) null, new androidx.compose.foundation.text.KeyboardOptions(0, (java.lang.Boolean) null, i1022, 0, (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 123, (kotlin.jvm.internal.DefaultConstructorMarker) null), (androidx.compose.foundation.text.KeyboardActions) null, true, 0, 0, (androidx.compose.foundation.interaction.MutableInteractionSource) null, (androidx.compose.ui.graphics.Shape) androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(14)), androidx.compose.material3.OutlinedTextFieldDefaults.INSTANCE.m2036colors0hiis_0(androidx.compose.ui.graphics.ColorKt.Color(4279900718L), androidx.compose.ui.graphics.ColorKt.Color(4279900718L), 0L, 0L, androidx.compose.ui.graphics.ColorKt.Color(4294638588L), androidx.compose.ui.graphics.ColorKt.Color(4294638588L), 0L, 0L, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.graphics.ColorKt.Color(4293454576L), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, startRestartGroup, 100884534, 432, 0, 0, 3072, 2147477196, 4095), composer2, (i922 & 14) | 113246592 | (i922 & 112), 12582912, 0, 1932920);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    }
                    z4 = z3;
                    i7 = i1022;
                    endRestartGroup = composer2.endRestartGroup();
                    if (endRestartGroup != null) {
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final com.app.a1bat.domain.model.ConsultingService BookConsultationScreen$lambda$0(androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state) {
                    return state.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final com.app.a1bat.domain.model.Booking BookConsultationScreen$lambda$1(androidx.compose.runtime.State<com.app.a1bat.domain.model.Booking> state) {
                    return state.getValue();
                }
            }
