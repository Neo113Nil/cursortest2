package com.app.a1bat.ui.screens.splash;

/* compiled from: SplashScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1", f = "SplashScreen.kt", i = {0}, l = {122, 125, okhttp3.internal.ws.WebSocketProtocol.PAYLOAD_SHORT, 127, 128, 129, 130}, m = "invokeSuspend", n = {"$this$LaunchedEffect"}, s = {"L$0"})
/* loaded from: classes3.dex */
final class SplashScreenKt$SplashScreen$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $dividerWidth;
    final /* synthetic */ androidx.compose.runtime.State<java.lang.Boolean> $isOnboardingCompleted$delegate;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoAlpha;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoScale;
    final /* synthetic */ kotlin.jvm.functions.Function0<kotlin.Unit> $onNavigateToMain;
    final /* synthetic */ kotlin.jvm.functions.Function0<kotlin.Unit> $onNavigateToOnboarding;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $ringScale;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $subtitleAlpha;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $taglineAlpha;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $titleAlpha;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $titleOffset;
    private /* synthetic */ java.lang.Object L$0;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    SplashScreenKt$SplashScreen$1$1(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable2, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable3, kotlin.jvm.functions.Function0<kotlin.Unit> function0, kotlin.jvm.functions.Function0<kotlin.Unit> function02, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable4, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable5, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable6, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable7, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable8, androidx.compose.runtime.State<java.lang.Boolean> state, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1> continuation) {
        super(2, continuation);
        this.$subtitleAlpha = animatable;
        this.$dividerWidth = animatable2;
        this.$taglineAlpha = animatable3;
        this.$onNavigateToMain = function0;
        this.$onNavigateToOnboarding = function02;
        this.$ringScale = animatable4;
        this.$logoScale = animatable5;
        this.$logoAlpha = animatable6;
        this.$titleAlpha = animatable7;
        this.$titleOffset = animatable8;
        this.$isOnboardingCompleted$delegate = state;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1 splashScreenKt$SplashScreen$1$1 = new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1(this.$subtitleAlpha, this.$dividerWidth, this.$taglineAlpha, this.$onNavigateToMain, this.$onNavigateToOnboarding, this.$ringScale, this.$logoScale, this.$logoAlpha, this.$titleAlpha, this.$titleOffset, this.$isOnboardingCompleted$delegate, continuation);
        splashScreenKt$SplashScreen$1$1.L$0 = obj;
        return splashScreenKt$SplashScreen$1$1;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    /* compiled from: SplashScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$1", f = "SplashScreen.kt", i = {}, l = {117, 118}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $ringScale;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass1> continuation) {
            super(2, continuation);
            this.$ringScale = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass1(this.$ringScale, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:13:0x006a, code lost:
        
            if (androidx.compose.animation.core.Animatable.animateTo$default(r14.$ringScale, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(androidx.compose.runtime.ComposerKt.invocationKey, 0, null, 6, null), null, null, r14, 12, null) == r0) goto L15;
         */
        /* JADX WARN: Code restructure failed: missing block: B:14:0x006c, code lost:
        
            return r0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:16:0x0047, code lost:
        
            if (androidx.compose.animation.core.Animatable.animateTo$default(r14.$ringScale, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.1f), androidx.compose.animation.core.AnimationSpecKt.tween$default(600, 0, androidx.compose.animation.core.EasingFunctionsKt.getEaseOutCubic(), 2, null), null, null, r14, 12, null) == r0) goto L15;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
            } else {
                if (i != 1) {
                    if (i != 2) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                    return kotlin.Unit.INSTANCE;
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            this.label = 2;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x013a, code lost:
    
        if (kotlinx.coroutines.DelayKt.delay(800, r18) == r1) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x012b, code lost:
    
        if (androidx.compose.animation.core.Animatable.animateTo$default(r18.$taglineAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(400, 0, null, 6, null), null, null, r18, 12, null) == r1) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x010c, code lost:
    
        if (kotlinx.coroutines.DelayKt.delay(150, r18) == r1) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00fd, code lost:
    
        if (androidx.compose.animation.core.Animatable.animateTo$default(r18.$dividerWidth, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(600, 0, androidx.compose.animation.core.EasingFunctionsKt.getEaseOutCubic(), 2, null), null, null, r18, 12, null) == r1) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00d7, code lost:
    
        if (androidx.compose.animation.core.Animatable.animateTo$default(r18.$subtitleAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(400, 0, null, 6, null), null, null, r18, 12, null) == r1) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00b6, code lost:
    
        if (kotlinx.coroutines.DelayKt.delay(200, r18) != r1) goto L20;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        kotlinx.coroutines.CoroutineScope coroutineScope;
        java.lang.Boolean SplashScreen$lambda$0;
        java.lang.Boolean SplashScreen$lambda$02;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.CoroutineScope coroutineScope2 = (kotlinx.coroutines.CoroutineScope) this.L$0;
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope2, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass1(this.$ringScale, null), 3, null);
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope2, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass2(this.$logoScale, null), 3, null);
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope2, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass3(this.$logoAlpha, null), 3, null);
                this.L$0 = coroutineScope2;
                this.label = 1;
                if (kotlinx.coroutines.DelayKt.delay(300L, this) != coroutine_suspended) {
                    coroutineScope = coroutineScope2;
                    kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass4(this.$titleAlpha, null), 3, null);
                    kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass5(this.$titleOffset, null), 3, null);
                    this.L$0 = null;
                    this.label = 2;
                    break;
                }
                return coroutine_suspended;
            case 1:
                kotlinx.coroutines.CoroutineScope coroutineScope3 = (kotlinx.coroutines.CoroutineScope) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                coroutineScope = coroutineScope3;
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass4(this.$titleAlpha, null), 3, null);
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass5(this.$titleOffset, null), 3, null);
                this.L$0 = null;
                this.label = 2;
                break;
            case 2:
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 3;
                break;
            case 3:
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 4;
                break;
            case 4:
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 5;
                break;
            case 5:
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 6;
                break;
            case 6:
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 7;
                break;
            case 7:
                kotlin.ResultKt.throwOnFailure(obj);
                SplashScreen$lambda$0 = com.app.a1bat.ui.screens.splash.SplashScreenKt.SplashScreen$lambda$0(this.$isOnboardingCompleted$delegate);
                if (SplashScreen$lambda$0 != null) {
                    SplashScreen$lambda$02 = com.app.a1bat.ui.screens.splash.SplashScreenKt.SplashScreen$lambda$0(this.$isOnboardingCompleted$delegate);
                    if (kotlin.jvm.internal.Intrinsics.areEqual(SplashScreen$lambda$02, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(true))) {
                        this.$onNavigateToMain.invoke();
                    } else {
                        this.$onNavigateToOnboarding.invoke();
                    }
                }
                return kotlin.Unit.INSTANCE;
            default:
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* compiled from: SplashScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$2", f = "SplashScreen.kt", i = {}, l = {androidx.compose.material3.MenuKt.InTransitionDuration}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoScale;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass2> continuation) {
            super(2, continuation);
            this.$logoScale = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass2(this.$logoScale, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (androidx.compose.animation.core.Animatable.animateTo$default(this.$logoScale, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(650, 0, androidx.compose.animation.core.EasingFunctionsKt.getEaseOutCubic(), 2, null), null, null, this, 12, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    /* compiled from: SplashScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$3", f = "SplashScreen.kt", i = {}, l = {121}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$3, reason: invalid class name */
    static final class AnonymousClass3 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoAlpha;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass3(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass3> continuation) {
            super(2, continuation);
            this.$logoAlpha = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass3(this.$logoAlpha, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (androidx.compose.animation.core.Animatable.animateTo$default(this.$logoAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(500, 0, null, 6, null), null, null, this, 12, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    /* compiled from: SplashScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$4", f = "SplashScreen.kt", i = {}, l = {123}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$4, reason: invalid class name */
    static final class AnonymousClass4 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $titleAlpha;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass4(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass4> continuation) {
            super(2, continuation);
            this.$titleAlpha = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass4(this.$titleAlpha, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (androidx.compose.animation.core.Animatable.animateTo$default(this.$titleAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(500, 0, null, 6, null), null, null, this, 12, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    /* compiled from: SplashScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$5", f = "SplashScreen.kt", i = {}, l = {124}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1$5, reason: invalid class name */
    static final class AnonymousClass5 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $titleOffset;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass5(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass5> continuation) {
            super(2, continuation);
            this.$titleOffset = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass5(this.$titleOffset, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((com.app.a1bat.ui.screens.splash.SplashScreenKt$SplashScreen$1$1.AnonymousClass5) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (androidx.compose.animation.core.Animatable.animateTo$default(this.$titleOffset, kotlin.coroutines.jvm.internal.Boxing.boxFloat(0.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(500, 0, androidx.compose.animation.core.EasingFunctionsKt.getEaseOut(), 2, null), null, null, this, 12, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }
}
