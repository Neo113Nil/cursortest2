package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingsHistoryViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0010"}, d2 = {"Lcom/app/a1bat/ui/screens/booking/BookingsHistoryViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "bookings", "Lkotlinx/coroutines/flow/StateFlow;", "", "Lcom/app/a1bat/domain/model/Booking;", "getBookings", "()Lkotlinx/coroutines/flow/StateFlow;", "deleteBooking", "", "bookingId", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class BookingsHistoryViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.Booking>> bookings;
    private final com.app.a1bat.domain.repository.AppRepository repository;

    public BookingsHistoryViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        this.bookings = kotlinx.coroutines.flow.FlowKt.stateIn(repository.getAllBookings(), androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed$default(kotlinx.coroutines.flow.SharingStarted.INSTANCE, androidx.lifecycle.CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), kotlin.collections.CollectionsKt.emptyList());
    }

    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.Booking>> getBookings() {
        return this.bookings;
    }

    public final void deleteBooking(java.lang.String bookingId) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bookingId, "bookingId");
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel$deleteBooking$1(this, bookingId, null), 3, null);
    }
}
