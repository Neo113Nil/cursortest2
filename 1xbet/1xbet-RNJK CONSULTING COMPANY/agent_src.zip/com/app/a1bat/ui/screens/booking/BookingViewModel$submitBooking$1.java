package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.booking.BookingViewModel$submitBooking$1", f = "BookingViewModel.kt", i = {0}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_10}, m = "invokeSuspend", n = {"booking"}, s = {"L$0"})
/* loaded from: classes3.dex */
final class BookingViewModel$submitBooking$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ java.lang.String $companyName;
    final /* synthetic */ java.lang.String $email;
    final /* synthetic */ java.lang.String $firstName;
    final /* synthetic */ java.lang.String $lastName;
    final /* synthetic */ java.lang.String $notes;
    final /* synthetic */ int $serviceId;
    final /* synthetic */ java.lang.String $serviceName;
    java.lang.Object L$0;
    int label;
    final /* synthetic */ com.app.a1bat.ui.screens.booking.BookingViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    BookingViewModel$submitBooking$1(int i, java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, java.lang.String str5, java.lang.String str6, com.app.a1bat.ui.screens.booking.BookingViewModel bookingViewModel, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.booking.BookingViewModel$submitBooking$1> continuation) {
        super(2, continuation);
        this.$serviceId = i;
        this.$serviceName = str;
        this.$firstName = str2;
        this.$lastName = str3;
        this.$email = str4;
        this.$companyName = str5;
        this.$notes = str6;
        this.this$0 = bookingViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new com.app.a1bat.ui.screens.booking.BookingViewModel$submitBooking$1(this.$serviceId, this.$serviceName, this.$firstName, this.$lastName, this.$email, this.$companyName, this.$notes, this.this$0, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.ui.screens.booking.BookingViewModel$submitBooking$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        com.app.a1bat.domain.repository.AppRepository appRepository;
        com.app.a1bat.domain.model.Booking booking;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            java.lang.String uuid = java.util.UUID.randomUUID().toString();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(uuid, "toString(...)");
            java.lang.String upperCase = kotlin.text.StringsKt.take(uuid, 8).toUpperCase(java.util.Locale.ROOT);
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            com.app.a1bat.domain.model.Booking booking2 = new com.app.a1bat.domain.model.Booking(upperCase, this.$serviceId, this.$serviceName, this.$firstName, this.$lastName, this.$email, this.$companyName, this.$notes, java.lang.System.currentTimeMillis(), "Confirmed");
            appRepository = this.this$0.repository;
            this.L$0 = booking2;
            this.label = 1;
            if (appRepository.addBooking(booking2, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            booking = booking2;
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            booking = (com.app.a1bat.domain.model.Booking) this.L$0;
            kotlin.ResultKt.throwOnFailure(obj);
        }
        mutableStateFlow = this.this$0._bookingSuccess;
        mutableStateFlow.setValue(booking);
        return kotlin.Unit.INSTANCE;
    }
}
