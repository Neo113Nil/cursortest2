package com.app.a1bat.ui.screens.home;

/* compiled from: ServiceDetailsScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class ServiceDetailsScreenKt$ServiceDetailsScreen$3 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.navigation.NavController $navController;
    final /* synthetic */ androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> $service$delegate;

    ServiceDetailsScreenKt$ServiceDetailsScreen$3(androidx.compose.runtime.State<com.app.a1bat.domain.model.ConsultingService> state, androidx.navigation.NavController navController) {
        this.$service$delegate = state;
        this.$navController = navController;
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.runtime.Composer composer, int i) {
        final com.app.a1bat.domain.model.ConsultingService ServiceDetailsScreen$lambda$0;
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C*93@3891L823:ServiceDetailsScreen.kt#8mqhoj");
        if ((i & 3) != 2 || !composer.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-920018199, i, -1, "com.app.a1bat.ui.screens.home.ServiceDetailsScreen.<anonymous> (ServiceDetailsScreen.kt:92)");
            }
            ServiceDetailsScreen$lambda$0 = com.app.a1bat.ui.screens.home.ServiceDetailsScreenKt.ServiceDetailsScreen$lambda$0(this.$service$delegate);
            if (ServiceDetailsScreen$lambda$0 != null) {
                final androidx.navigation.NavController navController = this.$navController;
                float f = 16;
                androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), null, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(12));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m695paddingVpY3zN4);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -496216916, "C104@4431L42,100@4178L71,99@4136L560:ServiceDetailsScreen.kt#8mqhoj");
                androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(56));
                androidx.compose.material3.ButtonColors m1501buttonColorsro_MJ88 = androidx.compose.material3.ButtonDefaults.INSTANCE.m1501buttonColorsro_MJ88(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0L, 0L, 0L, composer, (androidx.compose.material3.ButtonDefaults.$stable << 12) | 6, 14);
                androidx.compose.foundation.shape.RoundedCornerShape m977RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
                composer.startReplaceGroup(399635854);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):ServiceDetailsScreen.kt#9igjgp");
                boolean changedInstance = composer.changedInstance(navController) | composer.changedInstance(ServiceDetailsScreen$lambda$0);
                java.lang.Object rememberedValue = composer.rememberedValue();
                if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.home.ServiceDetailsScreenKt$ServiceDetailsScreen$3$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            kotlin.Unit invoke$lambda$3$lambda$2$lambda$1$lambda$0;
                            invoke$lambda$3$lambda$2$lambda$1$lambda$0 = com.app.a1bat.ui.screens.home.ServiceDetailsScreenKt$ServiceDetailsScreen$3.invoke$lambda$3$lambda$2$lambda$1$lambda$0(androidx.navigation.NavController.this, ServiceDetailsScreen$lambda$0);
                            return invoke$lambda$3$lambda$2$lambda$1$lambda$0;
                        }
                    };
                    composer.updateRememberedValue(rememberedValue);
                }
                composer.endReplaceGroup();
                androidx.compose.material3.ButtonKt.Button((kotlin.jvm.functions.Function0) rememberedValue, m725height3ABfNKs, false, m977RoundedCornerShape0680j_4, m1501buttonColorsro_MJ88, null, null, null, null, com.app.a1bat.ui.screens.home.ComposableSingletons$ServiceDetailsScreenKt.INSTANCE.m7407getLambda3$app_release(), composer, 805306416, 484);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
                return;
            }
            return;
        }
        composer.skipToGroupEnd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$3$lambda$2$lambda$1$lambda$0(androidx.navigation.NavController navController, com.app.a1bat.domain.model.ConsultingService consultingService) {
        androidx.navigation.NavController.navigate$default(navController, com.app.a1bat.ui.navigation.Screen.BookConsultation.INSTANCE.createRoute(consultingService.getId()), (androidx.navigation.NavOptions) null, (androidx.navigation.Navigator.Extras) null, 6, (java.lang.Object) null);
        return kotlin.Unit.INSTANCE;
    }
}
