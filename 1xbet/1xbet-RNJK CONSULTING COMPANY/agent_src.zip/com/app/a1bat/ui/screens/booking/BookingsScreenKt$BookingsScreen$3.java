package com.app.a1bat.ui.screens.booking;

/* compiled from: BookingsScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class BookingsScreenKt$BookingsScreen$3 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> $bookingToDelete$delegate;
    final /* synthetic */ com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel $viewModel;

    BookingsScreenKt$BookingsScreen$3(com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel bookingsHistoryViewModel, androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> mutableState) {
        this.$viewModel = bookingsHistoryViewModel;
        this.$bookingToDelete$delegate = mutableState;
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C172@6886L150,171@6844L325:BookingsScreen.kt#rof5hh");
        if ((i & 3) != 2 || !composer.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(720094080, i, -1, "com.app.a1bat.ui.screens.booking.BookingsScreen.<anonymous> (BookingsScreen.kt:171)");
            }
            composer.startReplaceGroup(-610168882);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):BookingsScreen.kt#9igjgp");
            boolean changedInstance = composer.changedInstance(this.$viewModel);
            final androidx.compose.runtime.MutableState<com.app.a1bat.domain.model.Booking> mutableState = this.$bookingToDelete$delegate;
            final com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel bookingsHistoryViewModel = this.$viewModel;
            java.lang.Object rememberedValue = composer.rememberedValue();
            if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.booking.BookingsScreenKt$BookingsScreen$3$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        kotlin.Unit invoke$lambda$2$lambda$1;
                        invoke$lambda$2$lambda$1 = com.app.a1bat.ui.screens.booking.BookingsScreenKt$BookingsScreen$3.invoke$lambda$2$lambda$1(androidx.compose.runtime.MutableState.this, bookingsHistoryViewModel);
                        return invoke$lambda$2$lambda$1;
                    }
                };
                composer.updateRememberedValue(rememberedValue);
            }
            composer.endReplaceGroup();
            androidx.compose.material3.ButtonKt.TextButton((kotlin.jvm.functions.Function0) rememberedValue, null, false, null, null, null, null, null, null, com.app.a1bat.ui.screens.booking.ComposableSingletons$BookingsScreenKt.INSTANCE.m7397getLambda2$app_release(), composer, 805306368, 510);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
                return;
            }
            return;
        }
        composer.skipToGroupEnd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$2$lambda$1(androidx.compose.runtime.MutableState mutableState, com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel bookingsHistoryViewModel) {
        com.app.a1bat.domain.model.Booking BookingsScreen$lambda$2;
        BookingsScreen$lambda$2 = com.app.a1bat.ui.screens.booking.BookingsScreenKt.BookingsScreen$lambda$2(mutableState);
        if (BookingsScreen$lambda$2 != null) {
            bookingsHistoryViewModel.deleteBooking(BookingsScreen$lambda$2.getId());
        }
        mutableState.setValue(null);
        return kotlin.Unit.INSTANCE;
    }
}
