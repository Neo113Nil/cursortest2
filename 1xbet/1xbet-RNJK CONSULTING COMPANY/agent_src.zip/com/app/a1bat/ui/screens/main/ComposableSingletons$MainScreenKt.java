package com.app.a1bat.ui.screens.main;

/* compiled from: MainScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ComposableSingletons$MainScreenKt {
    public static final com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt INSTANCE = new com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt();

    /* renamed from: lambda-1, reason: not valid java name */
    public static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f86lambda1 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1713610897, false, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function4
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C176@8514L16:MainScreen.kt#8mnl7t");
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1713610897, i, -1, "com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.lambda-1.<anonymous> (MainScreen.kt:176)");
            }
            com.app.a1bat.ui.screens.booking.BookingsScreenKt.BookingsScreen(null, composer, 0, 1);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
    });

    /* renamed from: lambda-2, reason: not valid java name */
    public static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f87lambda2 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1417775214, false, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt$lambda-2$1
        @Override // kotlin.jvm.functions.Function4
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C179@8652L17:MainScreen.kt#8mnl7t");
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1417775214, i, -1, "com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.lambda-2.<anonymous> (MainScreen.kt:179)");
            }
            com.app.a1bat.ui.screens.portfolio.PortfolioScreenKt.PortfolioScreen(null, composer, 0, 1);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
    });

    /* renamed from: lambda-3, reason: not valid java name */
    public static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f88lambda3 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(909387156, false, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt$lambda-3$1
        @Override // kotlin.jvm.functions.Function4
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C185@8973L16:MainScreen.kt#8mnl7t");
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(909387156, i, -1, "com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.lambda-3.<anonymous> (MainScreen.kt:185)");
            }
            com.app.a1bat.ui.screens.settings.SettingsScreenKt.SettingsScreen(composer, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
    });

    /* renamed from: getLambda-1$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7416getLambda1$app_release() {
        return f86lambda1;
    }

    /* renamed from: getLambda-2$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7417getLambda2$app_release() {
        return f87lambda2;
    }

    /* renamed from: getLambda-3$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7418getLambda3$app_release() {
        return f88lambda3;
    }
}
