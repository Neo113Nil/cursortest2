package com.app.a1bat.ui.screens.main;

/* compiled from: MainScreen.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\u001a\u0015\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0007¢\u0006\u0002\u0010\t\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\n²\u0006\f\u0010\u000b\u001a\u0004\u0018\u00010\fX\u008a\u0084\u0002²\u0006\n\u0010\r\u001a\u00020\u000eX\u008a\u0084\u0002"}, d2 = {"bottomNavItems", "", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "getBottomNavItems", "()Ljava/util/List;", "MainScreen", "", "rootNavController", "Landroidx/navigation/NavController;", "(Landroidx/navigation/NavController;Landroidx/compose/runtime/Composer;I)V", "app_release", "navBackStackEntry", "Landroidx/navigation/NavBackStackEntry;", "iconScale", ""}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class MainScreenKt {
    private static final java.util.List<com.app.a1bat.ui.screens.main.BottomNavItem> bottomNavItems = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.ui.screens.main.BottomNavItem[]{com.app.a1bat.ui.screens.main.BottomNavItem.Services.INSTANCE, com.app.a1bat.ui.screens.main.BottomNavItem.Bookings.INSTANCE, com.app.a1bat.ui.screens.main.BottomNavItem.Portfolio.INSTANCE, com.app.a1bat.ui.screens.main.BottomNavItem.KnowledgeBase.INSTANCE, com.app.a1bat.ui.screens.main.BottomNavItem.Settings.INSTANCE});

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit MainScreen$lambda$0(androidx.navigation.NavController navController, int i, androidx.compose.runtime.Composer composer, int i2) {
        MainScreen(navController, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    public static final java.util.List<com.app.a1bat.ui.screens.main.BottomNavItem> getBottomNavItems() {
        return bottomNavItems;
    }

    public static final void MainScreen(final androidx.navigation.NavController rootNavController, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(rootNavController, "rootNavController");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-992583130);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(MainScreen)67@3040L23,70@3099L4964,166@8070L949,69@3069L5950:MainScreen.kt#8mnl7t");
        if ((i & 6) == 0) {
            i2 = (startRestartGroup.changedInstance(rootNavController) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i2 & 3) != 2 || !startRestartGroup.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-992583130, i2, -1, "com.app.a1bat.ui.screens.main.MainScreen (MainScreen.kt:66)");
            }
            final androidx.navigation.NavHostController rememberNavController = androidx.navigation.compose.NavHostControllerKt.rememberNavController(new androidx.navigation.Navigator[0], startRestartGroup, 0);
            androidx.compose.material3.ScaffoldKt.m2101ScaffoldTvnljyQ(null, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(288715905, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1
                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer2, java.lang.Integer num) {
                    invoke(composer2, num.intValue());
                    return kotlin.Unit.INSTANCE;
                }

                public final void invoke(androidx.compose.runtime.Composer composer2, int i3) {
                    androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C71@3113L4940:MainScreen.kt#8mnl7t");
                    if ((i3 & 3) != 2 || !composer2.getSkipping()) {
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventStart(288715905, i3, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous> (MainScreen.kt:71)");
                        }
                        androidx.compose.ui.Modifier background$default = androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryMedium()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null);
                        androidx.navigation.NavHostController navHostController = androidx.navigation.NavHostController.this;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                        int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                        androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer2.getCurrentCompositionLocalMap();
                        androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer2, background$default);
                        kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer2.getApplier() instanceof androidx.compose.runtime.Applier)) {
                            androidx.compose.runtime.ComposablesKt.invalidApplier();
                        }
                        composer2.startReusableNode();
                        if (composer2.getInserting()) {
                            composer2.createNode(constructor);
                        } else {
                            composer2.useNode();
                        }
                        androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer2);
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                            m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                            m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                        }
                        androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, -1494312247, "C84@3609L4430,80@3431L4608:MainScreen.kt#8mnl7t");
                        androidx.compose.material3.NavigationBarKt.m1966NavigationBarHsRjFd4(null, androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU(), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.Dp.m6803constructorimpl(0), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(278566772, true, new com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1(navHostController), composer2, 54), composer2, 200112, 17);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    composer2.skipToGroupEnd();
                }
            }, startRestartGroup, 54), null, null, 0, 0L, 0L, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1259776521, true, new com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$2(rememberNavController, rootNavController), startRestartGroup, 54), startRestartGroup, 805306752, 507);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit MainScreen$lambda$0;
                    MainScreen$lambda$0 = com.app.a1bat.ui.screens.main.MainScreenKt.MainScreen$lambda$0(androidx.navigation.NavController.this, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return MainScreen$lambda$0;
                }
            });
        }
    }
}
