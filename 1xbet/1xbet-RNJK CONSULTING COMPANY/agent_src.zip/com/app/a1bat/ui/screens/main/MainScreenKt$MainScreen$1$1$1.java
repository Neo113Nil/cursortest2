package com.app.a1bat.ui.screens.main;

/* compiled from: MainScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class MainScreenKt$MainScreen$1$1$1 implements kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.navigation.NavHostController $navController;

    MainScreenKt$MainScreen$1$1$1(androidx.navigation.NavHostController navHostController) {
        this.$navController = navHostController;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(rowScope, composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.foundation.layout.RowScope NavigationBar, androidx.compose.runtime.Composer composer, int i) {
        boolean z;
        kotlin.sequences.Sequence<androidx.navigation.NavDestination> hierarchy;
        androidx.compose.runtime.Composer composer2 = composer;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavigationBar, "$this$NavigationBar");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C85@3670L30,*92@4010L266,156@7739L234,147@7237L437,99@4356L2338,138@6732L416,98@4302L3697:MainScreen.kt#8mnl7t");
        int i2 = (i & 6) == 0 ? i | (composer2.changed(NavigationBar) ? 4 : 2) : i;
        if ((i2 & 19) != 18 || !composer2.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(278566772, i2, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:85)");
            }
            boolean z2 = false;
            androidx.navigation.NavBackStackEntry invoke$lambda$0 = invoke$lambda$0(androidx.navigation.compose.NavHostControllerKt.currentBackStackEntryAsState(this.$navController, composer2, 0));
            java.lang.Object obj = null;
            androidx.navigation.NavDestination destination = invoke$lambda$0 != null ? invoke$lambda$0.getDestination() : null;
            java.util.List<com.app.a1bat.ui.screens.main.BottomNavItem> bottomNavItems = com.app.a1bat.ui.screens.main.MainScreenKt.getBottomNavItems();
            androidx.navigation.NavHostController navHostController = this.$navController;
            for (final com.app.a1bat.ui.screens.main.BottomNavItem bottomNavItem : bottomNavItems) {
                if (destination != null && (hierarchy = androidx.navigation.NavDestination.INSTANCE.getHierarchy(destination)) != null) {
                    java.util.Iterator<androidx.navigation.NavDestination> it = hierarchy.iterator();
                    while (it.hasNext()) {
                        if (kotlin.jvm.internal.Intrinsics.areEqual(it.next().getRoute(), bottomNavItem.getRoute())) {
                            z = true;
                            break;
                        }
                    }
                }
                z = z2;
                final boolean z3 = z;
                final androidx.compose.runtime.State<java.lang.Float> animateFloatAsState = androidx.compose.animation.core.AnimateAsStateKt.animateFloatAsState(z ? 1.15f : 1.0f, androidx.compose.animation.core.AnimationSpecKt.spring$default(0.5f, 0.0f, obj, 6, obj), 0.0f, "icon_scale", null, composer2, 3120, 20);
                int i3 = i2;
                java.lang.Object obj2 = obj;
                androidx.navigation.NavDestination navDestination = destination;
                final androidx.navigation.NavHostController navHostController2 = navHostController;
                androidx.compose.material3.NavigationBarItemColors m1964colors69fazGs = androidx.compose.material3.NavigationBarItemDefaults.INSTANCE.m1964colors69fazGs(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0L, androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU(), androidx.compose.ui.graphics.Color.INSTANCE.m4116getGray0d7_KjU(), 0L, 0L, 0L, composer, (androidx.compose.material3.NavigationBarItemDefaults.$stable << 21) | 3462, 114);
                composer.startReplaceGroup(-2054320275);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):MainScreen.kt#9igjgp");
                boolean changedInstance = composer.changedInstance(navHostController2) | composer.changed(bottomNavItem);
                java.lang.Object rememberedValue = composer.rememberedValue();
                if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            kotlin.Unit invoke$lambda$7$lambda$6$lambda$5;
                            invoke$lambda$7$lambda$6$lambda$5 = com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1.invoke$lambda$7$lambda$6$lambda$5(androidx.navigation.NavHostController.this, bottomNavItem);
                            return invoke$lambda$7$lambda$6$lambda$5;
                        }
                    };
                    composer.updateRememberedValue(rememberedValue);
                }
                composer.endReplaceGroup();
                androidx.compose.material3.NavigationBarKt.NavigationBarItem(NavigationBar, z3, (kotlin.jvm.functions.Function0) rememberedValue, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1251195739, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1$1$2
                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                        invoke(composer3, num.intValue());
                        return kotlin.Unit.INSTANCE;
                    }

                    public final void invoke(androidx.compose.runtime.Composer composer3, int i4) {
                        float invoke$lambda$7$lambda$2;
                        androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C100@4390L2274:MainScreen.kt#8mnl7t");
                        if ((i4 & 3) != 2 || !composer3.getSkipping()) {
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(1251195739, i4, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:100)");
                            }
                            androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
                            boolean z4 = z3;
                            com.app.a1bat.ui.screens.main.BottomNavItem bottomNavItem2 = bottomNavItem;
                            androidx.compose.runtime.State<java.lang.Float> state = animateFloatAsState;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                            androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), centerHorizontally, composer3, 48);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                            int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer3.getCurrentCompositionLocalMap();
                            androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion);
                            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                            if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                androidx.compose.runtime.ComposablesKt.invalidApplier();
                            }
                            composer3.startReusableNode();
                            if (composer3.getInserting()) {
                                composer3.createNode(constructor);
                            } else {
                                composer3.useNode();
                            }
                            androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                            if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                                m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                                m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                            }
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 890078926, "C101@4487L1780,130@6304L326:MainScreen.kt#8mnl7t");
                            androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                            float f = 40;
                            androidx.compose.ui.Modifier m739size3ABfNKs = androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                            androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                            int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
                            androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m739size3ABfNKs);
                            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                            if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                androidx.compose.runtime.ComposablesKt.invalidApplier();
                            }
                            composer3.startReusableNode();
                            if (composer3.getInserting()) {
                                composer3.createNode(constructor2);
                            } else {
                                composer3.useNode();
                            }
                            androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                            kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                            if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                                m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                                m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                            }
                            androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1918184566, "C105@4721L877,119@5639L590:MainScreen.kt#8mnl7t");
                            androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.ui.draw.AlphaKt.alpha(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(12))), z4 ? 1.0f : 0.0f), androidx.compose.ui.graphics.Brush.Companion.m4036linearGradientmHitzGk$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.25f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.08f, 0.0f, 0.0f, 0.0f, 14, null))}), 0L, 0L, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), composer3, 0);
                            androidx.compose.ui.graphics.vector.ImageVector icon = bottomNavItem2.getIcon();
                            java.lang.String title = bottomNavItem2.getTitle();
                            long accentGold = z4 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4116getGray0d7_KjU(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null);
                            androidx.compose.ui.Modifier m739size3ABfNKs2 = androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(22));
                            invoke$lambda$7$lambda$2 = com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1.invoke$lambda$7$lambda$2(state);
                            androidx.compose.material3.IconKt.m1843Iconww6aTOc(icon, title, androidx.compose.ui.draw.ScaleKt.scale(m739size3ABfNKs2, invoke$lambda$7$lambda$2), accentGold, composer3, 0, 0);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            composer3.endNode();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(4)), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), z4 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU(), null, 2, null), composer3, 0);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            composer3.endNode();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        composer3.skipToGroupEnd();
                    }
                }, composer, 54), null, false, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1070764066, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1$1$3
                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                        invoke(composer3, num.intValue());
                        return kotlin.Unit.INSTANCE;
                    }

                    public final void invoke(androidx.compose.runtime.Composer composer3, int i4) {
                        androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C139@6766L352:MainScreen.kt#8mnl7t");
                        if ((i4 & 3) != 2 || !composer3.getSkipping()) {
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(-1070764066, i4, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:139)");
                            }
                            androidx.compose.material3.TextKt.m2386Text4IGK_g(com.app.a1bat.ui.screens.main.BottomNavItem.this.getTitle(), (androidx.compose.ui.Modifier) null, z3 ? com.app.a1bat.ui.theme.ColorKt.getAccentGold() : androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4116getGray0d7_KjU(), 0.5f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.unit.TextUnitKt.getSp(10), (androidx.compose.ui.text.font.FontStyle) null, z3 ? androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold() : androidx.compose.ui.text.font.FontWeight.INSTANCE.getNormal(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3072, 0, 131026);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        composer3.skipToGroupEnd();
                    }
                }, composer, 54), false, m1964colors69fazGs, null, composer, (i3 & 14) | 1575936, 344);
                composer2 = composer;
                navHostController = navHostController2;
                obj = obj2;
                destination = navDestination;
                z2 = false;
                i2 = i3;
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
                return;
            }
            return;
        }
        composer2.skipToGroupEnd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$7$lambda$6$lambda$5(final androidx.navigation.NavHostController navHostController, com.app.a1bat.ui.screens.main.BottomNavItem bottomNavItem) {
        navHostController.navigate(bottomNavItem.getRoute(), new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit invoke$lambda$7$lambda$6$lambda$5$lambda$4;
                invoke$lambda$7$lambda$6$lambda$5$lambda$4 = com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1.invoke$lambda$7$lambda$6$lambda$5$lambda$4(androidx.navigation.NavHostController.this, (androidx.navigation.NavOptionsBuilder) obj);
                return invoke$lambda$7$lambda$6$lambda$5$lambda$4;
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$7$lambda$6$lambda$5$lambda$4(androidx.navigation.NavHostController navHostController, androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo(androidx.navigation.NavGraph.INSTANCE.findStartDestination(navHostController.getGraph()).getId(), new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit invoke$lambda$7$lambda$6$lambda$5$lambda$4$lambda$3;
                invoke$lambda$7$lambda$6$lambda$5$lambda$4$lambda$3 = com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$1$1$1.invoke$lambda$7$lambda$6$lambda$5$lambda$4$lambda$3((androidx.navigation.PopUpToBuilder) obj);
                return invoke$lambda$7$lambda$6$lambda$5$lambda$4$lambda$3;
            }
        });
        navigate.setLaunchSingleTop(true);
        navigate.setRestoreState(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$7$lambda$6$lambda$5$lambda$4$lambda$3(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setSaveState(true);
        return kotlin.Unit.INSTANCE;
    }

    private static final androidx.navigation.NavBackStackEntry invoke$lambda$0(androidx.compose.runtime.State<androidx.navigation.NavBackStackEntry> state) {
        return state.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float invoke$lambda$7$lambda$2(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }
}
