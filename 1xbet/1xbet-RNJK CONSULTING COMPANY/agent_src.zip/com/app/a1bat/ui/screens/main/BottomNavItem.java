package com.app.a1bat.ui.screens.main;

/* compiled from: MainScreen.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0005\u000e\u000f\u0010\u0011\u0012B!\b\u0004\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r\u0082\u0001\u0005\u0013\u0014\u0015\u0016\u0017¨\u0006\u0018"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "", "route", "", io.ktor.http.LinkHeader.Parameters.Title, "icon", "Landroidx/compose/ui/graphics/vector/ImageVector;", "<init>", "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/graphics/vector/ImageVector;)V", "getRoute", "()Ljava/lang/String;", "getTitle", "getIcon", "()Landroidx/compose/ui/graphics/vector/ImageVector;", "Services", "Bookings", "Portfolio", "KnowledgeBase", "Settings", "Lcom/app/a1bat/ui/screens/main/BottomNavItem$Bookings;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem$KnowledgeBase;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem$Portfolio;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem$Services;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem$Settings;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public abstract class BottomNavItem {
    public static final int $stable = 0;
    private final androidx.compose.ui.graphics.vector.ImageVector icon;
    private final java.lang.String route;
    private final java.lang.String title;

    public /* synthetic */ BottomNavItem(java.lang.String str, java.lang.String str2, androidx.compose.ui.graphics.vector.ImageVector imageVector, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, imageVector);
    }

    /* compiled from: MainScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem$Services;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Services extends com.app.a1bat.ui.screens.main.BottomNavItem {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.main.BottomNavItem.Services INSTANCE = new com.app.a1bat.ui.screens.main.BottomNavItem.Services();

        private Services() {
            super("services", "Services", androidx.compose.material.icons.filled.HomeKt.getHome(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), null);
        }
    }

    private BottomNavItem(java.lang.String str, java.lang.String str2, androidx.compose.ui.graphics.vector.ImageVector imageVector) {
        this.route = str;
        this.title = str2;
        this.icon = imageVector;
    }

    public final androidx.compose.ui.graphics.vector.ImageVector getIcon() {
        return this.icon;
    }

    public final java.lang.String getRoute() {
        return this.route;
    }

    public final java.lang.String getTitle() {
        return this.title;
    }

    /* compiled from: MainScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem$Bookings;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Bookings extends com.app.a1bat.ui.screens.main.BottomNavItem {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.main.BottomNavItem.Bookings INSTANCE = new com.app.a1bat.ui.screens.main.BottomNavItem.Bookings();

        private Bookings() {
            super("bookings", "Bookings", androidx.compose.material.icons.filled.BookKt.getBook(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), null);
        }
    }

    /* compiled from: MainScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem$Portfolio;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Portfolio extends com.app.a1bat.ui.screens.main.BottomNavItem {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.main.BottomNavItem.Portfolio INSTANCE = new com.app.a1bat.ui.screens.main.BottomNavItem.Portfolio();

        private Portfolio() {
            super("portfolio", "Portfolio", androidx.compose.material.icons.filled.AutoGraphKt.getAutoGraph(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), null);
        }
    }

    /* compiled from: MainScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem$KnowledgeBase;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class KnowledgeBase extends com.app.a1bat.ui.screens.main.BottomNavItem {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.main.BottomNavItem.KnowledgeBase INSTANCE = new com.app.a1bat.ui.screens.main.BottomNavItem.KnowledgeBase();

        private KnowledgeBase() {
            super("knowledge", "Knowledge", androidx.compose.material.icons.filled.LibraryBooksKt.getLibraryBooks(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), null);
        }
    }

    /* compiled from: MainScreen.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/app/a1bat/ui/screens/main/BottomNavItem$Settings;", "Lcom/app/a1bat/ui/screens/main/BottomNavItem;", "<init>", "()V", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Settings extends com.app.a1bat.ui.screens.main.BottomNavItem {
        public static final int $stable = 0;
        public static final com.app.a1bat.ui.screens.main.BottomNavItem.Settings INSTANCE = new com.app.a1bat.ui.screens.main.BottomNavItem.Settings();

        private Settings() {
            super("settings", "Settings", androidx.compose.material.icons.filled.SettingsKt.getSettings(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), null);
        }
    }
}
