package com.app.a1bat.ui.screens.knowledge;

/* compiled from: ArticleDetailsScreen.kt */
@kotlin.Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0002\u0010\b¨\u0006\t²\u0006\f\u0010\n\u001a\u0004\u0018\u00010\u000bX\u008a\u0084\u0002"}, d2 = {"ArticleDetailsScreen", "", "articleId", "", "navController", "Landroidx/navigation/NavController;", "viewModel", "Lcom/app/a1bat/ui/screens/knowledge/ArticleDetailsViewModel;", "(ILandroidx/navigation/NavController;Lcom/app/a1bat/ui/screens/knowledge/ArticleDetailsViewModel;Landroidx/compose/runtime/Composer;II)V", "app_release", "article", "Lcom/app/a1bat/domain/model/Article;"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ArticleDetailsScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ArticleDetailsScreen$lambda$2(int i, androidx.navigation.NavController navController, com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) {
        ArticleDetailsScreen(i, navController, articleDetailsViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0091, code lost:
    
        if ((r26 & 4) != 0) goto L53;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ArticleDetailsScreen(final int i, final androidx.navigation.NavController navController, com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel, androidx.compose.runtime.Composer composer, final int i2, final int i3) {
        int i4;
        com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel2;
        androidx.compose.runtime.Composer composer2;
        final com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel3;
        int i5;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navController, "navController");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(333461870);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(ArticleDetailsScreen)56@2421L16,58@2469L48,58@2443L74,63@2550L1071,88@3628L6409,62@2523L7514:ArticleDetailsScreen.kt#tolt0g");
        if ((i3 & 1) != 0) {
            i4 = i2 | 6;
        } else if ((i2 & 6) == 0) {
            i4 = (startRestartGroup.changed(i) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        if ((i3 & 2) != 0) {
            i4 |= 48;
        } else if ((i2 & 48) == 0) {
            i4 |= startRestartGroup.changedInstance(navController) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            if ((i3 & 4) == 0) {
                articleDetailsViewModel2 = articleDetailsViewModel;
                if (startRestartGroup.changedInstance(articleDetailsViewModel2)) {
                    i5 = 256;
                    i4 |= i5;
                }
            } else {
                articleDetailsViewModel2 = articleDetailsViewModel;
            }
            i5 = 128;
            i4 |= i5;
        } else {
            articleDetailsViewModel2 = articleDetailsViewModel;
        }
        if ((i4 & 147) != 146 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "54@2364L15");
            if ((i2 & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if ((i3 & 4) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    articleDetailsViewModel2 = (com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel) resolveViewModel;
                    i4 &= -897;
                }
                com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel4 = articleDetailsViewModel2;
                int i6 = i4;
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(333461870, i6, -1, "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreen (ArticleDetailsScreen.kt:55)");
                }
                final androidx.compose.runtime.State collectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(articleDetailsViewModel4.getArticle(), null, startRestartGroup, 0, 1);
                java.lang.Integer valueOf = java.lang.Integer.valueOf(i);
                startRestartGroup.startReplaceGroup(1273151094);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):ArticleDetailsScreen.kt#9igjgp");
                int i7 = i6 & 14;
                boolean changedInstance = startRestartGroup.changedInstance(articleDetailsViewModel4) | (i7 == 4);
                com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1 rememberedValue = startRestartGroup.rememberedValue();
                if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = new com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1(articleDetailsViewModel4, i, null);
                    startRestartGroup.updateRememberedValue(rememberedValue);
                }
                startRestartGroup.endReplaceGroup();
                androidx.compose.runtime.EffectsKt.LaunchedEffect(valueOf, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) rememberedValue, startRestartGroup, i7);
                composer2 = startRestartGroup;
                androidx.compose.material3.ScaffoldKt.m2101ScaffoldTvnljyQ(null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1337300686, true, new kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2
                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                        invoke(composer3, num.intValue());
                        return kotlin.Unit.INSTANCE;
                    }

                    public final void invoke(androidx.compose.runtime.Composer composer3, int i8) {
                        androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C68@2744L763,85@3552L45,64@2564L1047:ArticleDetailsScreen.kt#tolt0g");
                        if ((i8 & 3) != 2 || !composer3.getSkipping()) {
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(-1337300686, i8, -1, "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreen.<anonymous> (ArticleDetailsScreen.kt:64)");
                            }
                            androidx.compose.material3.AppBarKt.m1465TopAppBarGHTll3U(com.app.a1bat.ui.screens.knowledge.ComposableSingletons$ArticleDetailsScreenKt.INSTANCE.m7411getLambda1$app_release(), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(382074156, true, new com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2.AnonymousClass1(androidx.navigation.NavController.this), composer3, 54), null, 0.0f, null, androidx.compose.material3.TopAppBarDefaults.INSTANCE.m2557topAppBarColorszjMxDiM(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0L, 0L, 0L, 0L, composer3, (androidx.compose.material3.TopAppBarDefaults.$stable << 15) | 6, 30), null, composer3, 390, 186);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        composer3.skipToGroupEnd();
                    }

                    /* compiled from: ArticleDetailsScreen.kt */
                    @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                    /* renamed from: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2$1, reason: invalid class name */
                    static final class AnonymousClass1 implements kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
                        final /* synthetic */ androidx.navigation.NavController $navController;

                        AnonymousClass1(androidx.navigation.NavController navController) {
                            this.$navController = navController;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                            invoke(composer, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        /* JADX INFO: Access modifiers changed from: private */
                        public static final kotlin.Unit invoke$lambda$1$lambda$0(androidx.navigation.NavController navController) {
                            navController.navigateUp();
                            return kotlin.Unit.INSTANCE;
                        }

                        public final void invoke(androidx.compose.runtime.Composer composer, int i) {
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C69@2787L30,69@2766L723:ArticleDetailsScreen.kt#tolt0g");
                            if ((i & 3) == 2 && composer.getSkipping()) {
                                composer.skipToGroupEnd();
                                return;
                            }
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(382074156, i, -1, "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreen.<anonymous>.<anonymous> (ArticleDetailsScreen.kt:69)");
                            }
                            composer.startReplaceGroup(-1729736286);
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):ArticleDetailsScreen.kt#9igjgp");
                            boolean changedInstance = composer.changedInstance(this.$navController);
                            final androidx.navigation.NavController navController = this.$navController;
                            java.lang.Object rememberedValue = composer.rememberedValue();
                            if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                                rememberedValue = 
                                /*  JADX ERROR: Method code generation error
                                    jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0047: CONSTRUCTOR (r1v2 'rememberedValue' java.lang.Object) = (r0v3 'navController' androidx.navigation.NavController A[DONT_INLINE]) A[MD:(androidx.navigation.NavController):void (m)] (LINE:70) call: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2$1$$ExternalSyntheticLambda0.<init>(androidx.navigation.NavController):void type: CONSTRUCTOR in method: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2.1.invoke(androidx.compose.runtime.Composer, int):void, file: classes3.dex
                                    	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                                    	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                                    	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                                    	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                    	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                    	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                    	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:297)
                                    	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:276)
                                    	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:406)
                                    	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:335)
                                    	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:301)
                                    	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                                    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                                    	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                    	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                                    Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Expected class to be processed at this point, class: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2$1$$ExternalSyntheticLambda0, state: NOT_LOADED
                                    	at jadx.core.dex.nodes.ClassNode.ensureProcessed(ClassNode.java:305)
                                    	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:807)
                                    	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:730)
                                    	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:418)
                                    	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:303)
                                    	... 25 more
                                    */
                                /*
                                    this = this;
                                    java.lang.String r0 = "C69@2787L30,69@2766L723:ArticleDetailsScreen.kt#tolt0g"
                                    androidx.compose.runtime.ComposerKt.sourceInformation(r12, r0)
                                    r0 = r13 & 3
                                    r1 = 2
                                    if (r0 != r1) goto L15
                                    boolean r0 = r12.getSkipping()
                                    if (r0 != 0) goto L11
                                    goto L15
                                L11:
                                    r12.skipToGroupEnd()
                                    return
                                L15:
                                    boolean r0 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
                                    if (r0 == 0) goto L24
                                    r0 = -1
                                    java.lang.String r1 = "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreen.<anonymous>.<anonymous> (ArticleDetailsScreen.kt:69)"
                                    r2 = 382074156(0x16c5fd2c, float:3.198684E-25)
                                    androidx.compose.runtime.ComposerKt.traceEventStart(r2, r13, r0, r1)
                                L24:
                                    r13 = -1729736286(0xffffffff98e651a2, float:-5.9536035E-24)
                                    r12.startReplaceGroup(r13)
                                    java.lang.String r13 = "CC(remember):ArticleDetailsScreen.kt#9igjgp"
                                    androidx.compose.runtime.ComposerKt.sourceInformation(r12, r13)
                                    androidx.navigation.NavController r13 = r11.$navController
                                    boolean r13 = r12.changedInstance(r13)
                                    androidx.navigation.NavController r0 = r11.$navController
                                    java.lang.Object r1 = r12.rememberedValue()
                                    if (r13 != 0) goto L45
                                    androidx.compose.runtime.Composer$Companion r13 = androidx.compose.runtime.Composer.INSTANCE
                                    java.lang.Object r13 = r13.getEmpty()
                                    if (r1 != r13) goto L4d
                                L45:
                                    com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2$1$$ExternalSyntheticLambda0 r1 = new com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2$1$$ExternalSyntheticLambda0
                                    r1.<init>(r0)
                                    r12.updateRememberedValue(r1)
                                L4d:
                                    r2 = r1
                                    kotlin.jvm.functions.Function0 r2 = (kotlin.jvm.functions.Function0) r2
                                    r12.endReplaceGroup()
                                    com.app.a1bat.ui.screens.knowledge.ComposableSingletons$ArticleDetailsScreenKt r13 = com.app.a1bat.ui.screens.knowledge.ComposableSingletons$ArticleDetailsScreenKt.INSTANCE
                                    kotlin.jvm.functions.Function2 r7 = r13.m7412getLambda2$app_release()
                                    r9 = 196608(0x30000, float:2.75506E-40)
                                    r10 = 30
                                    r3 = 0
                                    r4 = 0
                                    r5 = 0
                                    r6 = 0
                                    r8 = r12
                                    androidx.compose.material3.IconButtonKt.IconButton(r2, r3, r4, r5, r6, r7, r8, r9, r10)
                                    boolean r12 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
                                    if (r12 == 0) goto L6e
                                    androidx.compose.runtime.ComposerKt.traceEventEnd()
                                L6e:
                                    return
                                */
                                throw new UnsupportedOperationException("Method not decompiled: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$2.AnonymousClass1.invoke(androidx.compose.runtime.Composer, int):void");
                            }
                        }
                    }, startRestartGroup, 54), null, null, null, 0, 0L, 0L, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1957791293, true, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.PaddingValues, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$3
                        @Override // kotlin.jvm.functions.Function3
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.PaddingValues paddingValues, androidx.compose.runtime.Composer composer3, java.lang.Integer num) {
                            invoke(paddingValues, composer3, num.intValue());
                            return kotlin.Unit.INSTANCE;
                        }

                        /* JADX WARN: Type inference failed for: r0v71 */
                        /* JADX WARN: Type inference failed for: r0v72, types: [boolean, int] */
                        /* JADX WARN: Type inference failed for: r0v83 */
                        public final void invoke(androidx.compose.foundation.layout.PaddingValues innerPadding, androidx.compose.runtime.Composer composer3, int i8) {
                            com.app.a1bat.domain.model.Article ArticleDetailsScreen$lambda$0;
                            boolean z;
                            int i9;
                            java.lang.Object obj;
                            int i10;
                            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
                            androidx.compose.runtime.ComposerKt.sourceInformation(composer3, "C*94@3846L21,90@3688L6333:ArticleDetailsScreen.kt#tolt0g");
                            int i11 = (i8 & 6) == 0 ? i8 | (composer3.changed(innerPadding) ? 4 : 2) : i8;
                            if ((i11 & 19) != 18 || !composer3.getSkipping()) {
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventStart(1957791293, i11, -1, "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreen.<anonymous> (ArticleDetailsScreen.kt:89)");
                                }
                                ArticleDetailsScreen$lambda$0 = com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt.ArticleDetailsScreen$lambda$0(collectAsState);
                                if (ArticleDetailsScreen$lambda$0 != null) {
                                    androidx.compose.ui.Modifier m249backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m249backgroundbw27NRU$default(androidx.compose.foundation.ScrollKt.verticalScroll$default(androidx.compose.foundation.layout.PaddingKt.padding(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), innerPadding), androidx.compose.foundation.ScrollKt.rememberScrollState(0, composer3, 0, 1), false, null, false, 14, null), androidx.compose.ui.graphics.ColorKt.Color(4293980917L), null, 2, null);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m249backgroundbw27NRU$default);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                                        m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                                        m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 1446982265, "C97@3952L1513,134@5483L4467,230@9967L40:ArticleDetailsScreen.kt#tolt0g");
                                    androidx.compose.ui.Modifier m725height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(280));
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m725height3ABfNKs);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor2);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                                        m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                                        m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1895137265, "C102@4117L251,108@4389L415,118@4825L622:ArticleDetailsScreen.kt#tolt0g");
                                    coil.compose.SingletonAsyncImageKt.m7328AsyncImagegl8XCv8(ArticleDetailsScreen$lambda$0.getImageUrl(), ArticleDetailsScreen$lambda$0.getTitle(), androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, null, 0, false, null, composer3, 1573248, 0, 4024);
                                    androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.ColorKt.Color(4293980917L))}), 420.0f, 0.0f, 0, 12, (java.lang.Object) null), null, 0.0f, 6, null), composer3, 6);
                                    float f = 16;
                                    float f2 = 8;
                                    androidx.compose.ui.Modifier m248backgroundbw27NRU = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0.85f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)));
                                    float f3 = 12;
                                    androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(m248backgroundbw27NRU, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3), androidx.compose.ui.unit.Dp.m6803constructorimpl(5));
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m695paddingVpY3zN4);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor3);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                                        m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                                        m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 1833683259, "C125@5194L231:ArticleDetailsScreen.kt#tolt0g");
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g(ArticleDetailsScreen$lambda$0.getCategory(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(11), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 0, 131026);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    composer3.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    composer3.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.ui.Modifier m655offsetVpY3zN4$default = androidx.compose.foundation.layout.OffsetKt.m655offsetVpY3zN4$default(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), 0.0f, 2, null), 0.0f, androidx.compose.ui.unit.Dp.m6803constructorimpl(-20), 1, null);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy3 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash4 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap4 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier4 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m655offsetVpY3zN4$default);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor4);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl4 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, maybeCachedBoxMeasurePolicy3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, currentCompositionLocalMap4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash4 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl4.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl4.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash4))) {
                                        m3405constructorimpl4.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash4));
                                        m3405constructorimpl4.apply(java.lang.Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash4);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl4, materializeModifier4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance3 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1893470240, "C140@5707L4225:ArticleDetailsScreen.kt#tolt0g");
                                    float f4 = 20;
                                    androidx.compose.ui.Modifier m694padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f4))), androidx.compose.ui.unit.Dp.m6803constructorimpl(f4));
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy2 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer3, 0);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash5 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap5 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier5 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m694padding3ABfNKs);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor5);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl5 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, columnMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, currentCompositionLocalMap5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash5 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl5.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl5.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash5))) {
                                        m3405constructorimpl5.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash5));
                                        m3405constructorimpl5.apply(java.lang.Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash5);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl5, materializeModifier5, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance2 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 1834572835, "C146@5975L278,153@6278L41,155@6345L1144,178@7515L41,180@7582L634,194@8241L41,227@9869L41:ArticleDetailsScreen.kt#tolt0g");
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g(ArticleDetailsScreen$lambda$0.getTitle(), (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(24), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(32), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 6, 130002);
                                    float f5 = 14;
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f5)), composer3, 6);
                                    androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 693286680, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo");
                                    androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                                    androidx.compose.ui.layout.MeasurePolicy rowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composer3, 48);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash6 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap6 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier6 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, companion);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor6);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl6 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, rowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, currentCompositionLocalMap6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash6 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl6.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl6.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash6))) {
                                        m3405constructorimpl6.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash6));
                                        m3405constructorimpl6.apply(java.lang.Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash6);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl6, materializeModifier6, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -407840262, "C101@5126L9:Row.kt#2w3rfo");
                                    androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1367798793, "C156@6427L658,169@7114L39,170@7182L281:ArticleDetailsScreen.kt#tolt0g");
                                    androidx.compose.ui.Modifier m248backgroundbw27NRU2 = androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(28)), androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.12f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                                    androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                                    androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy4 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                                    int currentCompositeKeyHash7 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer3, 0);
                                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap7 = composer3.getCurrentCompositionLocalMap();
                                    androidx.compose.ui.Modifier materializeModifier7 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer3, m248backgroundbw27NRU2);
                                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                                    if (!(composer3.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                                    }
                                    composer3.startReusableNode();
                                    if (composer3.getInserting()) {
                                        composer3.createNode(constructor7);
                                    } else {
                                        composer3.useNode();
                                    }
                                    androidx.compose.runtime.Composer m3405constructorimpl7 = androidx.compose.runtime.Updater.m3405constructorimpl(composer3);
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, maybeCachedBoxMeasurePolicy4, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, currentCompositionLocalMap7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                                    kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash7 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                                    if (m3405constructorimpl7.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl7.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash7))) {
                                        m3405constructorimpl7.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash7));
                                        m3405constructorimpl7.apply(java.lang.Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash7);
                                    }
                                    androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl7, materializeModifier7, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance4 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer3, -1633491268, "C162@6759L296:ArticleDetailsScreen.kt#tolt0g");
                                    androidx.compose.material3.IconKt.m1843Iconww6aTOc(androidx.compose.material.icons.filled.TimerKt.getTimer(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f5)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), composer3, 3504, 0);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    composer3.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer3);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m744width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), composer3, 6);
                                    androidx.compose.material3.TextKt.m2386Text4IGK_g(ArticleDetailsScreen$lambda$0.getReadTimeMinutes() + " min read", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4288455599L), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 0, 131026);
                                    androidx.compose.runtime.Composer composer4 = composer3;
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    composer4.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    char c = 6;
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer4, 6);
                                    java.lang.Object obj2 = null;
                                    int i12 = 1;
                                    int i13 = 2;
                                    ?? r0 = 0;
                                    androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(2)), androidx.compose.ui.graphics.Brush.Companion.m4034horizontalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getAccentGold()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getAccentGold(), 0.2f, 0.0f, 0.0f, 0.0f, 14, null)), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), composer4, 6);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f4)), composer4, 6);
                                    java.util.List split$default = kotlin.text.StringsKt.split$default((java.lang.CharSequence) ArticleDetailsScreen$lambda$0.getContent(), new java.lang.String[]{"\n\n"}, false, 0, 6, (java.lang.Object) null);
                                    composer4.startReplaceGroup(-772029549);
                                    androidx.compose.runtime.ComposerKt.sourceInformation(composer4, "");
                                    int i14 = 0;
                                    for (java.lang.Object obj3 : split$default) {
                                        int i15 = i14 + 1;
                                        if (i14 < 0) {
                                            kotlin.collections.CollectionsKt.throwIndexOverflow();
                                        }
                                        java.lang.String obj4 = kotlin.text.StringsKt.trim((java.lang.CharSequence) obj3).toString();
                                        java.lang.String str = obj4;
                                        if (str.length() == 0) {
                                            z = r0;
                                            i9 = i13;
                                            obj = obj2;
                                            i10 = i12;
                                        } else {
                                            int i16 = (obj4.length() >= 80 || kotlin.text.StringsKt.endsWith$default(obj4, ".", (boolean) r0, i13, obj2) || kotlin.text.StringsKt.startsWith$default(obj4, "1.", (boolean) r0, i13, obj2) || kotlin.text.StringsKt.startsWith$default(obj4, "2.", (boolean) r0, i13, obj2) || kotlin.text.StringsKt.startsWith$default(obj4, "3.", (boolean) r0, i13, obj2) || kotlin.text.StringsKt.lines(str).size() != i12) ? r0 : i12;
                                            composer4.startReplaceGroup(-772012205);
                                            androidx.compose.runtime.ComposerKt.sourceInformation(composer4, "208@8986L67");
                                            if (i14 > 0) {
                                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, i16 != 0 ? androidx.compose.ui.unit.Dp.m6803constructorimpl(f4) : androidx.compose.ui.unit.Dp.m6803constructorimpl(f3)), composer4, r0);
                                            }
                                            composer4.endReplaceGroup();
                                            if (i16 != 0) {
                                                composer4.startReplaceGroup(-1365169281);
                                                androidx.compose.runtime.ComposerKt.sourceInformation(composer4, "211@9132L323");
                                                obj = obj2;
                                                z = r0;
                                                i10 = i12;
                                                i9 = i13;
                                                androidx.compose.material3.TextKt.m2386Text4IGK_g(obj4, (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(17), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(24), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 200064, 6, 130002);
                                                composer4 = composer3;
                                                composer4.endReplaceGroup();
                                            } else {
                                                z = r0;
                                                i9 = i13;
                                                obj = obj2;
                                                i10 = i12;
                                                composer4.startReplaceGroup(-1364781285);
                                                androidx.compose.runtime.ComposerKt.sourceInformation(composer4, "219@9525L263");
                                                androidx.compose.material3.TextKt.m2386Text4IGK_g(obj4, (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281811281L), androidx.compose.ui.unit.TextUnitKt.getSp(15), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(26), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer3, 3456, 6, 130034);
                                                composer4 = composer3;
                                                composer4.endReplaceGroup();
                                            }
                                        }
                                        i14 = i15;
                                        i12 = i10;
                                        r0 = z;
                                        i13 = i9;
                                        obj2 = obj;
                                        c = 6;
                                    }
                                    composer4.endReplaceGroup();
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(32)), composer4, 6);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    composer4.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    composer4.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f2)), composer4, 6);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    composer4.endNode();
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                                    kotlin.Unit unit = kotlin.Unit.INSTANCE;
                                    kotlin.Unit unit2 = kotlin.Unit.INSTANCE;
                                }
                                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                                    return;
                                }
                                return;
                            }
                            composer3.skipToGroupEnd();
                        }
                    }, startRestartGroup, 54), composer2, 805306416, 509);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    articleDetailsViewModel3 = articleDetailsViewModel4;
                } else {
                    startRestartGroup.skipToGroupEnd();
                }
            } else {
                startRestartGroup.skipToGroupEnd();
                composer2 = startRestartGroup;
                articleDetailsViewModel3 = articleDetailsViewModel2;
            }
            androidx.compose.runtime.ScopeUpdateScope endRestartGroup = composer2.endRestartGroup();
            if (endRestartGroup != null) {
                endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        kotlin.Unit ArticleDetailsScreen$lambda$2;
                        ArticleDetailsScreen$lambda$2 = com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt.ArticleDetailsScreen$lambda$2(i, navController, articleDetailsViewModel3, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                        return ArticleDetailsScreen$lambda$2;
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final com.app.a1bat.domain.model.Article ArticleDetailsScreen$lambda$0(androidx.compose.runtime.State<com.app.a1bat.domain.model.Article> state) {
            return state.getValue();
        }
    }
