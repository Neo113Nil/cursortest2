package com.app.a1bat.ui.screens.knowledge;

/* compiled from: KnowledgeBaseViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u001d\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lcom/app/a1bat/ui/screens/knowledge/KnowledgeBaseViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "articles", "Lkotlinx/coroutines/flow/StateFlow;", "", "Lcom/app/a1bat/domain/model/Article;", "getArticles", "()Lkotlinx/coroutines/flow/StateFlow;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class KnowledgeBaseViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.Article>> articles;

    public KnowledgeBaseViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.articles = kotlinx.coroutines.flow.FlowKt.stateIn(repository.getAllArticles(), androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed$default(kotlinx.coroutines.flow.SharingStarted.INSTANCE, androidx.lifecycle.CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), kotlin.collections.CollectionsKt.emptyList());
    }

    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.app.a1bat.domain.model.Article>> getArticles() {
        return this.articles;
    }
}
