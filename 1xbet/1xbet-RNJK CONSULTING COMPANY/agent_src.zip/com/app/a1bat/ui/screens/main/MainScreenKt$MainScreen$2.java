package com.app.a1bat.ui.screens.main;

/* compiled from: MainScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
final class MainScreenKt$MainScreen$2 implements kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.PaddingValues, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ androidx.navigation.NavHostController $navController;
    final /* synthetic */ androidx.navigation.NavController $rootNavController;

    MainScreenKt$MainScreen$2(androidx.navigation.NavHostController navHostController, androidx.navigation.NavController navController) {
        this.$navController = navHostController;
        this.$rootNavController = navController;
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.PaddingValues paddingValues, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
        invoke(paddingValues, composer, num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(androidx.compose.foundation.layout.PaddingValues innerPadding, androidx.compose.runtime.Composer composer, int i) {
        int i2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C171@8273L740,167@8096L917:MainScreen.kt#8mnl7t");
        if ((i & 6) == 0) {
            i2 = i | (composer.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i2 & 19) != 18 || !composer.getSkipping()) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1259776521, i2, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous> (MainScreen.kt:167)");
            }
            androidx.navigation.NavHostController navHostController = this.$navController;
            java.lang.String route = com.app.a1bat.ui.screens.main.BottomNavItem.Services.INSTANCE.getRoute();
            androidx.compose.ui.Modifier padding = androidx.compose.foundation.layout.PaddingKt.padding(androidx.compose.ui.Modifier.INSTANCE, innerPadding);
            composer.startReplaceGroup(1025331487);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CC(remember):MainScreen.kt#9igjgp");
            boolean changedInstance = composer.changedInstance(this.$rootNavController);
            final androidx.navigation.NavController navController = this.$rootNavController;
            java.lang.Object rememberedValue = composer.rememberedValue();
            if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                rememberedValue = new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$2$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        kotlin.Unit invoke$lambda$1$lambda$0;
                        invoke$lambda$1$lambda$0 = com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$2.invoke$lambda$1$lambda$0(androidx.navigation.NavController.this, (androidx.navigation.NavGraphBuilder) obj);
                        return invoke$lambda$1$lambda$0;
                    }
                };
                composer.updateRememberedValue(rememberedValue);
            }
            composer.endReplaceGroup();
            androidx.navigation.compose.NavHostKt.NavHost(navHostController, route, padding, null, null, null, null, null, null, null, (kotlin.jvm.functions.Function1) rememberedValue, composer, 0, 0, androidx.core.view.PointerIconCompat.TYPE_TOP_RIGHT_DIAGONAL_DOUBLE_ARROW);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
                return;
            }
            return;
        }
        composer.skipToGroupEnd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit invoke$lambda$1$lambda$0(final androidx.navigation.NavController navController, androidx.navigation.NavGraphBuilder NavHost) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.screens.main.BottomNavItem.Services.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1675350502, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$2$1$1$1
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C173@8346L49:MainScreen.kt#8mnl7t");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1675350502, i, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:173)");
                }
                com.app.a1bat.ui.screens.home.HomeScreenKt.HomeScreen(androidx.navigation.NavController.this, null, composer, 0, 2);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.screens.main.BottomNavItem.Bookings.INSTANCE.getRoute(), null, null, null, null, null, null, null, com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.INSTANCE.m7416getLambda1$app_release(), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.screens.main.BottomNavItem.Portfolio.INSTANCE.getRoute(), null, null, null, null, null, null, null, com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.INSTANCE.m7417getLambda2$app_release(), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.screens.main.BottomNavItem.KnowledgeBase.INSTANCE.getRoute(), null, null, null, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-254194029, true, new kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.main.MainScreenKt$MainScreen$2$1$1$2
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.animation.AnimatedContentScope animatedContentScope, androidx.navigation.NavBackStackEntry navBackStackEntry, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
                invoke(animatedContentScope, navBackStackEntry, composer, num.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C182@8795L58:MainScreen.kt#8mnl7t");
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-254194029, i, -1, "com.app.a1bat.ui.screens.main.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:182)");
                }
                com.app.a1bat.ui.screens.knowledge.KnowledgeBaseScreenKt.KnowledgeBaseScreen(androidx.navigation.NavController.this, null, composer, 0, 2);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }), 254, null);
        androidx.navigation.compose.NavGraphBuilderKt.composable$default(NavHost, com.app.a1bat.ui.screens.main.BottomNavItem.Settings.INSTANCE.getRoute(), null, null, null, null, null, null, null, com.app.a1bat.ui.screens.main.ComposableSingletons$MainScreenKt.INSTANCE.m7418getLambda3$app_release(), 254, null);
        return kotlin.Unit.INSTANCE;
    }
}
