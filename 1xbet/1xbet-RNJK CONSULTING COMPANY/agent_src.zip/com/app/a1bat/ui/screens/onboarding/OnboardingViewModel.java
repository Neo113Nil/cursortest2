package com.app.a1bat.ui.screens.onboarding;

/* compiled from: OnboardingViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0006\u001a\u00020\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/app/a1bat/ui/screens/onboarding/OnboardingViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/app/a1bat/domain/repository/AppRepository;", "<init>", "(Lcom/app/a1bat/domain/repository/AppRepository;)V", "completeOnboarding", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class OnboardingViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final com.app.a1bat.domain.repository.AppRepository repository;

    public OnboardingViewModel(com.app.a1bat.domain.repository.AppRepository repository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
    }

    public final void completeOnboarding() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new com.app.a1bat.ui.screens.onboarding.OnboardingViewModel$completeOnboarding$1(this, null), 3, null);
    }
}
