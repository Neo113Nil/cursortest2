package com.app.a1bat.ui.screens.knowledge;

/* compiled from: ArticleDetailsScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1", f = "ArticleDetailsScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class ArticleDetailsScreenKt$ArticleDetailsScreen$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ int $articleId;
    final /* synthetic */ com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel $viewModel;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ArticleDetailsScreenKt$ArticleDetailsScreen$1$1(com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel articleDetailsViewModel, int i, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1> continuation) {
        super(2, continuation);
        this.$viewModel = articleDetailsViewModel;
        this.$articleId = i;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1(this.$viewModel, this.$articleId, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.ui.screens.knowledge.ArticleDetailsScreenKt$ArticleDetailsScreen$1$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        kotlin.ResultKt.throwOnFailure(obj);
        this.$viewModel.loadArticle(this.$articleId);
        return kotlin.Unit.INSTANCE;
    }
}
