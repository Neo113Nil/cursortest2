package com.app.a1bat.ui.screens.home;

/* compiled from: ServiceDetailsViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1", f = "ServiceDetailsViewModel.kt", i = {}, l = {20}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class ServiceDetailsViewModel$loadService$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ int $id;
    int label;
    final /* synthetic */ com.app.a1bat.ui.screens.home.ServiceDetailsViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ServiceDetailsViewModel$loadService$1(com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel, int i, kotlin.coroutines.Continuation<? super com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1> continuation) {
        super(2, continuation);
        this.this$0 = serviceDetailsViewModel;
        this.$id = i;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1(this.this$0, this.$id, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        com.app.a1bat.domain.repository.AppRepository appRepository;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            appRepository = this.this$0.repository;
            kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.ConsultingService> serviceById = appRepository.getServiceById(this.$id);
            final com.app.a1bat.ui.screens.home.ServiceDetailsViewModel serviceDetailsViewModel = this.this$0;
            this.label = 1;
            if (serviceById.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: com.app.a1bat.ui.screens.home.ServiceDetailsViewModel$loadService$1.1
                @Override // kotlinx.coroutines.flow.FlowCollector
                public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                    return emit((com.app.a1bat.domain.model.ConsultingService) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                }

                public final java.lang.Object emit(com.app.a1bat.domain.model.ConsultingService consultingService, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                    kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
                    mutableStateFlow = com.app.a1bat.ui.screens.home.ServiceDetailsViewModel.this._service;
                    mutableStateFlow.setValue(consultingService);
                    return kotlin.Unit.INSTANCE;
                }
            }, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(obj);
        }
        return kotlin.Unit.INSTANCE;
    }
}
