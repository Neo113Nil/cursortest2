package com.app.a1bat.ui.screens.home;

/* compiled from: HomeScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ComposableSingletons$HomeScreenKt {
    public static final com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt INSTANCE = new com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt();

    /* renamed from: lambda-1, reason: not valid java name */
    public static kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f77lambda1 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-870330427, false, new kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(lazyItemScope, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C82@3334L1719:HomeScreen.kt#8mqhoj");
            if ((i & 17) != 16 || !composer.getSkipping()) {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-870330427, i, -1, "com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt.lambda-1.<anonymous> (HomeScreen.kt:82)");
                }
                androidx.compose.ui.Modifier background$default = androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark()), androidx.compose.ui.graphics.Color.m4076boximpl(com.app.a1bat.ui.theme.ColorKt.getPrimaryMedium())}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, background$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1021484043, "C91@3644L1130,120@4791L248:HomeScreen.kt#8mqhoj");
                float f = 20;
                float f2 = 28;
                androidx.compose.ui.Modifier m697paddingqDBjuR0 = androidx.compose.foundation.layout.PaddingKt.m697paddingqDBjuR0(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2), androidx.compose.ui.unit.Dp.m6803constructorimpl(f), androidx.compose.ui.unit.Dp.m6803constructorimpl(f2));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m697paddingqDBjuR0);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor2);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1315217290, "C99@3915L253,106@4189L40,107@4250L214,113@4485L40,114@4546L210:HomeScreen.kt#8mqhoj");
                androidx.compose.material3.TextKt.m2386Text4IGK_g("1 BAT", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(4), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 12782982, 0, 130898);
                float f3 = 4;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3)), composer, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Our Services", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), androidx.compose.ui.unit.TextUnitKt.getSp(30), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200070, 0, 131026);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f3)), composer, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Premium consulting for your business growth", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.unit.TextUnitKt.getSp(14), (androidx.compose.ui.text.font.FontStyle) null, (androidx.compose.ui.text.font.FontWeight) null, (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 3462, 0, 131058);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.foundation.layout.SizeKt.m739size3ABfNKs(androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getTopEnd()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), androidx.compose.ui.unit.Dp.m6803constructorimpl(6)), com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), composer, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            composer.skipToGroupEnd();
        }
    });

    /* renamed from: lambda-2, reason: not valid java name */
    public static kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f78lambda2 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(612498862, false, new kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt$lambda-2$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(lazyItemScope, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C131@5092L41,132@5146L2215,186@7374L41:HomeScreen.kt#8mqhoj");
            if ((i & 17) != 16 || !composer.getSkipping()) {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(612498862, i, -1, "com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt.lambda-2.<anonymous> (HomeScreen.kt:131)");
                }
                float f = 20;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer, 6);
                androidx.compose.ui.Modifier clip = androidx.compose.ui.draw.ClipKt.clip(androidx.compose.ui.draw.ShadowKt.m3689shadows4CzXII$default(androidx.compose.foundation.layout.PaddingKt.m696paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(androidx.compose.runtime.ComposerKt.invocationKey)), androidx.compose.ui.unit.Dp.m6803constructorimpl(16), 0.0f, 2, null), androidx.compose.ui.unit.Dp.m6803constructorimpl(12), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), false, 0L, 0L, 28, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(f)));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, clip);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 768559417, "C140@5455L309,146@5781L451,158@6249L1098:HomeScreen.kt#8mqhoj");
                coil.compose.SingletonAsyncImageKt.m7328AsyncImagegl8XCv8("https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80", "Banner", androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), null, null, null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, null, 0, false, null, composer, 1573302, 0, 4024);
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.graphics.Brush.Companion.m4042verticalGradient8A3gB4$default(androidx.compose.ui.graphics.Brush.INSTANCE, kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new androidx.compose.ui.graphics.Color[]{androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.INSTANCE.m4121getTransparent0d7_KjU()), androidx.compose.ui.graphics.Color.m4076boximpl(androidx.compose.ui.graphics.Color.m4085copywmQWz5c$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), 0.7f, 0.0f, 0.0f, 0.0f, 14, null))}), 0.0f, 0.0f, 0, 14, (java.lang.Object) null), null, 0.0f, 6, null), composer, 6);
                androidx.compose.ui.Modifier m694padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m694padding3ABfNKs(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getBottomStart()), androidx.compose.ui.unit.Dp.m6803constructorimpl(f));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -483455358, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy columnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash2 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m694padding3ABfNKs);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor2);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl2 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, columnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl2.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl2.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash2))) {
                    m3405constructorimpl2.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash2));
                    m3405constructorimpl2.apply(java.lang.Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl2, materializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -384784025, "C88@4444L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 148860348, "C163@6431L542,176@6994L40,177@7055L274:HomeScreen.kt#8mqhoj");
                androidx.compose.ui.Modifier m695paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m695paddingVpY3zN4(androidx.compose.foundation.BackgroundKt.m248backgroundbw27NRU(androidx.compose.ui.Modifier.INSTANCE, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(4))), androidx.compose.ui.unit.Dp.m6803constructorimpl(8), androidx.compose.ui.unit.Dp.m6803constructorimpl(3));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash3 = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, m695paddingVpY3zN4);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor3);
                } else {
                    composer.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl3 = androidx.compose.runtime.Updater.m3405constructorimpl(composer);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, maybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl3.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl3.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash3))) {
                    m3405constructorimpl3.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash3));
                    m3405constructorimpl3.apply(java.lang.Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl3, materializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1828949937, "C168@6679L272:HomeScreen.kt#8mqhoj");
                androidx.compose.material3.TextKt.m2386Text4IGK_g("PREMIUM", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), androidx.compose.ui.unit.TextUnitKt.getSp(9), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBlack(), (androidx.compose.ui.text.font.FontFamily) null, androidx.compose.ui.unit.TextUnitKt.getSp(1), (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 12782982, 0, 130898);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(6)), composer, 6);
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Premium Consulting\nServices", (androidx.compose.ui.Modifier) null, androidx.compose.ui.graphics.Color.INSTANCE.m4123getWhite0d7_KjU(), androidx.compose.ui.unit.TextUnitKt.getSp(22), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, androidx.compose.ui.unit.TextUnitKt.getSp(28), 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200070, 6, 130002);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                composer.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m725height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m6803constructorimpl(f)), composer, 6);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            composer.skipToGroupEnd();
        }
    });

    /* renamed from: lambda-3, reason: not valid java name */
    public static kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f79lambda3 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(498062427, false, new kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt$lambda-3$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer, java.lang.Integer num) {
            invoke(rowScope, composer, num.intValue());
            return kotlin.Unit.INSTANCE;
        }

        public final void invoke(androidx.compose.foundation.layout.RowScope Button, androidx.compose.runtime.Composer composer, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Button, "$this$Button");
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C362@14611L226:HomeScreen.kt#8mqhoj");
            if ((i & 17) != 16 || !composer.getSkipping()) {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(498062427, i, -1, "com.app.a1bat.ui.screens.home.ComposableSingletons$HomeScreenKt.lambda-3.<anonymous> (HomeScreen.kt:362)");
                }
                androidx.compose.material3.TextKt.m2386Text4IGK_g("Book Now", (androidx.compose.ui.Modifier) null, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), androidx.compose.ui.unit.TextUnitKt.getSp(13), (androidx.compose.ui.text.font.FontStyle) null, androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold(), (androidx.compose.ui.text.font.FontFamily) null, 0L, (androidx.compose.ui.text.style.TextDecoration) null, (androidx.compose.ui.text.style.TextAlign) null, 0L, 0, false, 0, 0, (kotlin.jvm.functions.Function1<? super androidx.compose.ui.text.TextLayoutResult, kotlin.Unit>) null, (androidx.compose.ui.text.TextStyle) null, composer, 200070, 0, 131026);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            composer.skipToGroupEnd();
        }
    });

    /* renamed from: getLambda-1$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7402getLambda1$app_release() {
        return f77lambda1;
    }

    /* renamed from: getLambda-2$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7403getLambda2$app_release() {
        return f78lambda2;
    }

    /* renamed from: getLambda-3$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m7404getLambda3$app_release() {
        return f79lambda3;
    }
}
