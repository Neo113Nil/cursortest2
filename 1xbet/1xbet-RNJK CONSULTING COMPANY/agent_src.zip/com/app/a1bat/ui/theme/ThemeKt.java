package com.app.a1bat.ui.theme;

/* compiled from: Theme.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a*\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\u0011\u0010\n\u001a\r\u0012\u0004\u0012\u00020\u00070\u000b¢\u0006\u0002\b\fH\u0007¢\u0006\u0002\u0010\r\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005¨\u0006\u000e"}, d2 = {"LightColorScheme", "Landroidx/compose/material3/ColorScheme;", "AppShapes", "Landroidx/compose/material3/Shapes;", "getAppShapes", "()Landroidx/compose/material3/Shapes;", "_1BatTheme", "", "darkTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ThemeKt {
    private static final androidx.compose.material3.ColorScheme LightColorScheme = androidx.compose.material3.ColorSchemeKt.m1628lightColorSchemeCXl9yA$default(com.app.a1bat.ui.theme.ColorKt.getPrimaryDark(), com.app.a1bat.ui.theme.ColorKt.getSecondaryLight(), 0, 0, 0, com.app.a1bat.ui.theme.ColorKt.getSecondaryLight(), com.app.a1bat.ui.theme.ColorKt.getTextPrimary(), 0, 0, com.app.a1bat.ui.theme.ColorKt.getAccentGold(), com.app.a1bat.ui.theme.ColorKt.getSecondaryLight(), 0, 0, com.app.a1bat.ui.theme.ColorKt.getBackgroundLight(), com.app.a1bat.ui.theme.ColorKt.getTextPrimary(), com.app.a1bat.ui.theme.ColorKt.getSurfaceColor(), com.app.a1bat.ui.theme.ColorKt.getTextPrimary(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -124516, 15, null);
    private static final androidx.compose.material3.Shapes AppShapes = new androidx.compose.material3.Shapes(null, androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(8)), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(16)), androidx.compose.foundation.shape.RoundedCornerShapeKt.m977RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m6803constructorimpl(24)), null, 17, null);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit _1BatTheme$lambda$2(boolean z, kotlin.jvm.functions.Function2 function2, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        _1BatTheme(z, function2, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final androidx.compose.material3.Shapes getAppShapes() {
        return AppShapes;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x0055, code lost:
    
        if ((r12 & 1) != 0) goto L30;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void _1BatTheme(final boolean z, kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> content, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        final kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> function2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(content, "content");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(-45639080);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(_1BatTheme)P(1)41@1350L7,50@1651L142:Theme.kt#7jbc0i");
        if ((i2 & 2) != 0) {
            i3 = i | 48;
        } else if ((i & 48) == 0) {
            i3 = (startRestartGroup.changedInstance(content) ? 32 : 16) | i;
        } else {
            i3 = i;
        }
        if ((i3 & 17) != 16 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "36@1117L21");
            if ((i & 1) != 0 && !startRestartGroup.getDefaultsInvalid()) {
                startRestartGroup.skipToGroupEnd();
            } else {
                if ((i2 & 1) != 0) {
                    z = androidx.compose.foundation.DarkThemeKt.isSystemInDarkTheme(startRestartGroup, 0);
                    i3 &= -15;
                }
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-45639080, i3, -1, "com.app.a1bat.ui.theme._1BatTheme (Theme.kt:38)");
                }
                final androidx.compose.material3.ColorScheme colorScheme = LightColorScheme;
                androidx.compose.runtime.ProvidableCompositionLocal<android.view.View> localView = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalView();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object consume = startRestartGroup.consume(localView);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                final android.view.View view = (android.view.View) consume;
                startRestartGroup.startReplaceGroup(1219311165);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "43@1407L232,43@1396L243");
                if (!view.isInEditMode()) {
                    startRestartGroup.startReplaceGroup(1219312554);
                    androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):Theme.kt#9igjgp");
                    boolean changedInstance = startRestartGroup.changedInstance(view);
                    java.lang.Object rememberedValue = startRestartGroup.rememberedValue();
                    if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        rememberedValue = new kotlin.jvm.functions.Function0() { // from class: com.app.a1bat.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                kotlin.Unit _1BatTheme$lambda$1$lambda$0;
                                _1BatTheme$lambda$1$lambda$0 = com.app.a1bat.ui.theme.ThemeKt._1BatTheme$lambda$1$lambda$0(view, colorScheme);
                                return _1BatTheme$lambda$1$lambda$0;
                            }
                        };
                        startRestartGroup.updateRememberedValue(rememberedValue);
                    }
                    startRestartGroup.endReplaceGroup();
                    androidx.compose.runtime.EffectsKt.SideEffect((kotlin.jvm.functions.Function0) rememberedValue, startRestartGroup, 0);
                }
                startRestartGroup.endReplaceGroup();
                function2 = content;
                androidx.compose.material3.MaterialThemeKt.MaterialTheme(colorScheme, AppShapes, com.app.a1bat.ui.theme.TypeKt.getTypography(), function2, startRestartGroup, ((i3 << 6) & 7168) | 438, 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        } else {
            startRestartGroup.skipToGroupEnd();
            function2 = content;
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.ui.theme.ThemeKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit _1BatTheme$lambda$2;
                    _1BatTheme$lambda$2 = com.app.a1bat.ui.theme.ThemeKt._1BatTheme$lambda$2(z, function2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return _1BatTheme$lambda$2;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit _1BatTheme$lambda$1$lambda$0(android.view.View view, androidx.compose.material3.ColorScheme colorScheme) {
        android.content.Context context = view.getContext();
        kotlin.jvm.internal.Intrinsics.checkNotNull(context, "null cannot be cast to non-null type android.app.Activity");
        android.view.Window window = ((android.app.Activity) context).getWindow();
        window.setStatusBarColor(androidx.compose.ui.graphics.ColorKt.m4140toArgb8_81llA(colorScheme.getBackground()));
        androidx.core.view.WindowCompat.getInsetsController(window, view).setAppearanceLightStatusBars(true);
        return kotlin.Unit.INSTANCE;
    }
}
