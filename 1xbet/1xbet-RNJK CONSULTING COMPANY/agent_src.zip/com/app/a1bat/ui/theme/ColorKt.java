package com.app.a1bat.ui.theme;

/* compiled from: Color.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b,\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0013\u0010\u001d\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003\"\u0013\u0010\u001f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b \u0010\u0003\"\u0013\u0010!\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\"\u0010\u0003\"\u0013\u0010#\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b$\u0010\u0003\"\u0013\u0010%\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b&\u0010\u0003\"\u0013\u0010'\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b(\u0010\u0003\"\u0013\u0010)\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b*\u0010\u0003\"\u0013\u0010+\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b,\u0010\u0003¨\u0006-"}, d2 = {"PrimaryDark", "Landroidx/compose/ui/graphics/Color;", "getPrimaryDark", "()J", "J", "PrimaryMedium", "getPrimaryMedium", "SecondaryLight", "getSecondaryLight", "AccentGold", "getAccentGold", "AccentGoldLight", "getAccentGoldLight", "AccentGoldDim", "getAccentGoldDim", "BackgroundLight", "getBackgroundLight", "BackgroundCard", "getBackgroundCard", "TextPrimary", "getTextPrimary", "TextSecondary", "getTextSecondary", "SurfaceColor", "getSurfaceColor", "SplashGradientStart", "getSplashGradientStart", "SplashGradientMid", "getSplashGradientMid", "SplashGradientEnd", "getSplashGradientEnd", "GoldGradientStart", "getGoldGradientStart", "GoldGradientEnd", "getGoldGradientEnd", "CardGradientStart", "getCardGradientStart", "CardGradientEnd", "getCardGradientEnd", "ErrorRed", "getErrorRed", "SuccessGreen", "getSuccessGreen", "SuccessGreenDim", "getSuccessGreenDim", "app_release"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ColorKt {
    private static final long PrimaryDark = androidx.compose.ui.graphics.ColorKt.Color(4279046423L);
    private static final long PrimaryMedium = androidx.compose.ui.graphics.ColorKt.Color(4279638818L);
    private static final long SecondaryLight = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long AccentGold = androidx.compose.ui.graphics.ColorKt.Color(4291405914L);
    private static final long AccentGoldLight = androidx.compose.ui.graphics.ColorKt.Color(4293446010L);
    private static final long AccentGoldDim = androidx.compose.ui.graphics.ColorKt.Color(4287329088L);
    private static final long BackgroundLight = androidx.compose.ui.graphics.ColorKt.Color(4293980917L);
    private static final long BackgroundCard = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long TextPrimary = androidx.compose.ui.graphics.ColorKt.Color(4279900718L);
    private static final long TextSecondary = androidx.compose.ui.graphics.ColorKt.Color(4285231744L);
    private static final long SurfaceColor = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long SplashGradientStart = androidx.compose.ui.graphics.ColorKt.Color(4279046423L);
    private static final long SplashGradientMid = androidx.compose.ui.graphics.ColorKt.Color(4279638818L);
    private static final long SplashGradientEnd = androidx.compose.ui.graphics.ColorKt.Color(4280232247L);
    private static final long GoldGradientStart = androidx.compose.ui.graphics.ColorKt.Color(4291405914L);
    private static final long GoldGradientEnd = androidx.compose.ui.graphics.ColorKt.Color(4287326484L);
    private static final long CardGradientStart = androidx.compose.ui.graphics.ColorKt.Color(4279900718L);
    private static final long CardGradientEnd = androidx.compose.ui.graphics.ColorKt.Color(4279640382L);
    private static final long ErrorRed = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
    private static final long SuccessGreen = androidx.compose.ui.graphics.ColorKt.Color(4279286145L);
    private static final long SuccessGreenDim = androidx.compose.ui.graphics.ColorKt.Color(4278607686L);

    public static final long getPrimaryDark() {
        return PrimaryDark;
    }

    public static final long getPrimaryMedium() {
        return PrimaryMedium;
    }

    public static final long getSecondaryLight() {
        return SecondaryLight;
    }

    public static final long getAccentGold() {
        return AccentGold;
    }

    public static final long getAccentGoldLight() {
        return AccentGoldLight;
    }

    public static final long getAccentGoldDim() {
        return AccentGoldDim;
    }

    public static final long getBackgroundLight() {
        return BackgroundLight;
    }

    public static final long getBackgroundCard() {
        return BackgroundCard;
    }

    public static final long getTextPrimary() {
        return TextPrimary;
    }

    public static final long getTextSecondary() {
        return TextSecondary;
    }

    public static final long getSurfaceColor() {
        return SurfaceColor;
    }

    public static final long getSplashGradientStart() {
        return SplashGradientStart;
    }

    public static final long getSplashGradientMid() {
        return SplashGradientMid;
    }

    public static final long getSplashGradientEnd() {
        return SplashGradientEnd;
    }

    public static final long getGoldGradientStart() {
        return GoldGradientStart;
    }

    public static final long getGoldGradientEnd() {
        return GoldGradientEnd;
    }

    public static final long getCardGradientStart() {
        return CardGradientStart;
    }

    public static final long getCardGradientEnd() {
        return CardGradientEnd;
    }

    public static final long getErrorRed() {
        return ErrorRed;
    }

    public static final long getSuccessGreen() {
        return SuccessGreen;
    }

    public static final long getSuccessGreenDim() {
        return SuccessGreenDim;
    }
}
