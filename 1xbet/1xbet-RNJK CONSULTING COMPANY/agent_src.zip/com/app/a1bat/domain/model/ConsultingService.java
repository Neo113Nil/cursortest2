package com.app.a1bat.domain.model;

/* compiled from: ConsultingService.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u001a\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BU\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000e¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\tHÆ\u0003J\t\u0010#\u001a\u00020\u0005HÆ\u0003J\t\u0010$\u001a\u00020\u0005HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eHÆ\u0003Ji\u0010'\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\u00052\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eHÆ\u0001J\u0013\u0010(\u001a\u00020)2\b\u0010*\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010+\u001a\u00020\u0003HÖ\u0001J\t\u0010,\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0014R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0014R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001d¨\u0006-"}, d2 = {"Lcom/app/a1bat/domain/model/ConsultingService;", "", "id", "", io.ktor.http.LinkHeader.Parameters.Title, "", "shortDescription", "fullDescription", "startingPrice", "", "engagementType", "category", "imageUrl", "whatsIncluded", "", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;DLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getId", "()I", "getTitle", "()Ljava/lang/String;", "getShortDescription", "getFullDescription", "getStartingPrice", "()D", "getEngagementType", "getCategory", "getImageUrl", "getWhatsIncluded", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class ConsultingService {
    public static final int $stable = 8;
    private final java.lang.String category;
    private final java.lang.String engagementType;
    private final java.lang.String fullDescription;
    private final int id;
    private final java.lang.String imageUrl;
    private final java.lang.String shortDescription;
    private final double startingPrice;
    private final java.lang.String title;
    private final java.util.List<java.lang.String> whatsIncluded;

    public static /* synthetic */ com.app.a1bat.domain.model.ConsultingService copy$default(com.app.a1bat.domain.model.ConsultingService consultingService, int i, java.lang.String str, java.lang.String str2, java.lang.String str3, double d, java.lang.String str4, java.lang.String str5, java.lang.String str6, java.util.List list, int i2, java.lang.Object obj) {
        if ((i2 & 1) != 0) {
            i = consultingService.id;
        }
        if ((i2 & 2) != 0) {
            str = consultingService.title;
        }
        if ((i2 & 4) != 0) {
            str2 = consultingService.shortDescription;
        }
        if ((i2 & 8) != 0) {
            str3 = consultingService.fullDescription;
        }
        if ((i2 & 16) != 0) {
            d = consultingService.startingPrice;
        }
        if ((i2 & 32) != 0) {
            str4 = consultingService.engagementType;
        }
        if ((i2 & 64) != 0) {
            str5 = consultingService.category;
        }
        if ((i2 & 128) != 0) {
            str6 = consultingService.imageUrl;
        }
        if ((i2 & 256) != 0) {
            list = consultingService.whatsIncluded;
        }
        double d2 = d;
        java.lang.String str7 = str2;
        java.lang.String str8 = str3;
        return consultingService.copy(i, str, str7, str8, d2, str4, str5, str6, list);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getTitle() {
        return this.title;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getShortDescription() {
        return this.shortDescription;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getFullDescription() {
        return this.fullDescription;
    }

    /* renamed from: component5, reason: from getter */
    public final double getStartingPrice() {
        return this.startingPrice;
    }

    /* renamed from: component6, reason: from getter */
    public final java.lang.String getEngagementType() {
        return this.engagementType;
    }

    /* renamed from: component7, reason: from getter */
    public final java.lang.String getCategory() {
        return this.category;
    }

    /* renamed from: component8, reason: from getter */
    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final java.util.List<java.lang.String> component9() {
        return this.whatsIncluded;
    }

    public final com.app.a1bat.domain.model.ConsultingService copy(int id, java.lang.String title, java.lang.String shortDescription, java.lang.String fullDescription, double startingPrice, java.lang.String engagementType, java.lang.String category, java.lang.String imageUrl, java.util.List<java.lang.String> whatsIncluded) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(shortDescription, "shortDescription");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(fullDescription, "fullDescription");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(engagementType, "engagementType");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(category, "category");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(whatsIncluded, "whatsIncluded");
        return new com.app.a1bat.domain.model.ConsultingService(id, title, shortDescription, fullDescription, startingPrice, engagementType, category, imageUrl, whatsIncluded);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.domain.model.ConsultingService)) {
            return false;
        }
        com.app.a1bat.domain.model.ConsultingService consultingService = (com.app.a1bat.domain.model.ConsultingService) other;
        return this.id == consultingService.id && kotlin.jvm.internal.Intrinsics.areEqual(this.title, consultingService.title) && kotlin.jvm.internal.Intrinsics.areEqual(this.shortDescription, consultingService.shortDescription) && kotlin.jvm.internal.Intrinsics.areEqual(this.fullDescription, consultingService.fullDescription) && java.lang.Double.compare(this.startingPrice, consultingService.startingPrice) == 0 && kotlin.jvm.internal.Intrinsics.areEqual(this.engagementType, consultingService.engagementType) && kotlin.jvm.internal.Intrinsics.areEqual(this.category, consultingService.category) && kotlin.jvm.internal.Intrinsics.areEqual(this.imageUrl, consultingService.imageUrl) && kotlin.jvm.internal.Intrinsics.areEqual(this.whatsIncluded, consultingService.whatsIncluded);
    }

    public int hashCode() {
        return (((((((((((((((java.lang.Integer.hashCode(this.id) * 31) + this.title.hashCode()) * 31) + this.shortDescription.hashCode()) * 31) + this.fullDescription.hashCode()) * 31) + java.lang.Double.hashCode(this.startingPrice)) * 31) + this.engagementType.hashCode()) * 31) + this.category.hashCode()) * 31) + this.imageUrl.hashCode()) * 31) + this.whatsIncluded.hashCode();
    }

    public java.lang.String toString() {
        return "ConsultingService(id=" + this.id + ", title=" + this.title + ", shortDescription=" + this.shortDescription + ", fullDescription=" + this.fullDescription + ", startingPrice=" + this.startingPrice + ", engagementType=" + this.engagementType + ", category=" + this.category + ", imageUrl=" + this.imageUrl + ", whatsIncluded=" + this.whatsIncluded + ")";
    }

    public ConsultingService(int i, java.lang.String title, java.lang.String shortDescription, java.lang.String fullDescription, double d, java.lang.String engagementType, java.lang.String category, java.lang.String imageUrl, java.util.List<java.lang.String> whatsIncluded) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(shortDescription, "shortDescription");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(fullDescription, "fullDescription");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(engagementType, "engagementType");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(category, "category");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(whatsIncluded, "whatsIncluded");
        this.id = i;
        this.title = title;
        this.shortDescription = shortDescription;
        this.fullDescription = fullDescription;
        this.startingPrice = d;
        this.engagementType = engagementType;
        this.category = category;
        this.imageUrl = imageUrl;
        this.whatsIncluded = whatsIncluded;
    }

    public final int getId() {
        return this.id;
    }

    public final java.lang.String getTitle() {
        return this.title;
    }

    public final java.lang.String getShortDescription() {
        return this.shortDescription;
    }

    public final java.lang.String getFullDescription() {
        return this.fullDescription;
    }

    public final double getStartingPrice() {
        return this.startingPrice;
    }

    public final java.lang.String getEngagementType() {
        return this.engagementType;
    }

    public final java.lang.String getCategory() {
        return this.category;
    }

    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final java.util.List<java.lang.String> getWhatsIncluded() {
        return this.whatsIncluded;
    }
}
