package com.app.a1bat.domain.model;

/* compiled from: Booking.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\u001c\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B[\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010&\u001a\u00020\rHÆ\u0003J\t\u0010'\u001a\u00020\u0003HÆ\u0003Jq\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u0003HÆ\u0001J\u0013\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0005HÖ\u0001J\t\u0010-\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0012R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0012R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0012R\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u000e\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0012¨\u0006."}, d2 = {"Lcom/app/a1bat/domain/model/Booking;", "", "id", "", "serviceId", "", "serviceName", "firstName", "lastName", "email", "companyName", "notes", "timestamp", "", androidx.core.app.NotificationCompat.CATEGORY_STATUS, "<init>", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V", "getId", "()Ljava/lang/String;", "getServiceId", "()I", "getServiceName", "getFirstName", "getLastName", "getEmail", "getCompanyName", "getNotes", "getTimestamp", "()J", "getStatus", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class Booking {
    public static final int $stable = 0;
    private final java.lang.String companyName;
    private final java.lang.String email;
    private final java.lang.String firstName;
    private final java.lang.String id;
    private final java.lang.String lastName;
    private final java.lang.String notes;
    private final int serviceId;
    private final java.lang.String serviceName;
    private final java.lang.String status;
    private final long timestamp;

    public static /* synthetic */ com.app.a1bat.domain.model.Booking copy$default(com.app.a1bat.domain.model.Booking booking, java.lang.String str, int i, java.lang.String str2, java.lang.String str3, java.lang.String str4, java.lang.String str5, java.lang.String str6, java.lang.String str7, long j, java.lang.String str8, int i2, java.lang.Object obj) {
        if ((i2 & 1) != 0) {
            str = booking.id;
        }
        if ((i2 & 2) != 0) {
            i = booking.serviceId;
        }
        if ((i2 & 4) != 0) {
            str2 = booking.serviceName;
        }
        if ((i2 & 8) != 0) {
            str3 = booking.firstName;
        }
        if ((i2 & 16) != 0) {
            str4 = booking.lastName;
        }
        if ((i2 & 32) != 0) {
            str5 = booking.email;
        }
        if ((i2 & 64) != 0) {
            str6 = booking.companyName;
        }
        if ((i2 & 128) != 0) {
            str7 = booking.notes;
        }
        if ((i2 & 256) != 0) {
            j = booking.timestamp;
        }
        if ((i2 & 512) != 0) {
            str8 = booking.status;
        }
        java.lang.String str9 = str8;
        long j2 = j;
        java.lang.String str10 = str6;
        java.lang.String str11 = str7;
        java.lang.String str12 = str4;
        java.lang.String str13 = str5;
        return booking.copy(str, i, str2, str3, str12, str13, str10, str11, j2, str9);
    }

    /* renamed from: component1, reason: from getter */
    public final java.lang.String getId() {
        return this.id;
    }

    /* renamed from: component10, reason: from getter */
    public final java.lang.String getStatus() {
        return this.status;
    }

    /* renamed from: component2, reason: from getter */
    public final int getServiceId() {
        return this.serviceId;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getServiceName() {
        return this.serviceName;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getFirstName() {
        return this.firstName;
    }

    /* renamed from: component5, reason: from getter */
    public final java.lang.String getLastName() {
        return this.lastName;
    }

    /* renamed from: component6, reason: from getter */
    public final java.lang.String getEmail() {
        return this.email;
    }

    /* renamed from: component7, reason: from getter */
    public final java.lang.String getCompanyName() {
        return this.companyName;
    }

    /* renamed from: component8, reason: from getter */
    public final java.lang.String getNotes() {
        return this.notes;
    }

    /* renamed from: component9, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    public final com.app.a1bat.domain.model.Booking copy(java.lang.String id, int serviceId, java.lang.String serviceName, java.lang.String firstName, java.lang.String lastName, java.lang.String email, java.lang.String companyName, java.lang.String notes, long timestamp, java.lang.String status) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(id, "id");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(serviceName, "serviceName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(firstName, "firstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(lastName, "lastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(email, "email");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(status, "status");
        return new com.app.a1bat.domain.model.Booking(id, serviceId, serviceName, firstName, lastName, email, companyName, notes, timestamp, status);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.domain.model.Booking)) {
            return false;
        }
        com.app.a1bat.domain.model.Booking booking = (com.app.a1bat.domain.model.Booking) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.id, booking.id) && this.serviceId == booking.serviceId && kotlin.jvm.internal.Intrinsics.areEqual(this.serviceName, booking.serviceName) && kotlin.jvm.internal.Intrinsics.areEqual(this.firstName, booking.firstName) && kotlin.jvm.internal.Intrinsics.areEqual(this.lastName, booking.lastName) && kotlin.jvm.internal.Intrinsics.areEqual(this.email, booking.email) && kotlin.jvm.internal.Intrinsics.areEqual(this.companyName, booking.companyName) && kotlin.jvm.internal.Intrinsics.areEqual(this.notes, booking.notes) && this.timestamp == booking.timestamp && kotlin.jvm.internal.Intrinsics.areEqual(this.status, booking.status);
    }

    public int hashCode() {
        int hashCode = ((((((((((this.id.hashCode() * 31) + java.lang.Integer.hashCode(this.serviceId)) * 31) + this.serviceName.hashCode()) * 31) + this.firstName.hashCode()) * 31) + this.lastName.hashCode()) * 31) + this.email.hashCode()) * 31;
        java.lang.String str = this.companyName;
        int hashCode2 = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        java.lang.String str2 = this.notes;
        return ((((hashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31) + java.lang.Long.hashCode(this.timestamp)) * 31) + this.status.hashCode();
    }

    public java.lang.String toString() {
        return "Booking(id=" + this.id + ", serviceId=" + this.serviceId + ", serviceName=" + this.serviceName + ", firstName=" + this.firstName + ", lastName=" + this.lastName + ", email=" + this.email + ", companyName=" + this.companyName + ", notes=" + this.notes + ", timestamp=" + this.timestamp + ", status=" + this.status + ")";
    }

    public Booking(java.lang.String id, int i, java.lang.String serviceName, java.lang.String firstName, java.lang.String lastName, java.lang.String email, java.lang.String str, java.lang.String str2, long j, java.lang.String status) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(id, "id");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(serviceName, "serviceName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(firstName, "firstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(lastName, "lastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(email, "email");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(status, "status");
        this.id = id;
        this.serviceId = i;
        this.serviceName = serviceName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.companyName = str;
        this.notes = str2;
        this.timestamp = j;
        this.status = status;
    }

    public final java.lang.String getId() {
        return this.id;
    }

    public final int getServiceId() {
        return this.serviceId;
    }

    public final java.lang.String getServiceName() {
        return this.serviceName;
    }

    public final java.lang.String getFirstName() {
        return this.firstName;
    }

    public final java.lang.String getLastName() {
        return this.lastName;
    }

    public final java.lang.String getEmail() {
        return this.email;
    }

    public final java.lang.String getCompanyName() {
        return this.companyName;
    }

    public final java.lang.String getNotes() {
        return this.notes;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final java.lang.String getStatus() {
        return this.status;
    }
}
