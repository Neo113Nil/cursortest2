package com.app.a1bat.domain.repository;

/* compiled from: AppRepository.kt */
@kotlin.Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H&J\u001c\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u00032\u0006\u0010\u0007\u001a\u00020\bH&J\u0018\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00032\u0006\u0010\n\u001a\u00020\u000bH&J\u0014\u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u00040\u0003H&J\u0016\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\rH¦@¢\u0006\u0002\u0010\u0011J\u0016\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0013\u001a\u00020\bH¦@¢\u0006\u0002\u0010\u0014J\u0014\u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00160\u00040\u0003H&J\u0014\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00180\u00040\u0003H&J\u0018\u0010\u0019\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00180\u00032\u0006\u0010\n\u001a\u00020\u000bH&J\u0016\u0010\u001d\u001a\u00020\u000f2\u0006\u0010\u001e\u001a\u00020\u001bH¦@¢\u0006\u0002\u0010\u001fR\u0018\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001b0\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001c¨\u0006 "}, d2 = {"Lcom/app/a1bat/domain/repository/AppRepository;", "", "getAllServices", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/app/a1bat/domain/model/ConsultingService;", "getServicesByCategory", "category", "", "getServiceById", "id", "", "getAllBookings", "Lcom/app/a1bat/domain/model/Booking;", "addBooking", "", "booking", "(Lcom/app/a1bat/domain/model/Booking;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteBooking", "bookingId", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getAllProjects", "Lcom/app/a1bat/domain/model/Project;", "getAllArticles", "Lcom/app/a1bat/domain/model/Article;", "getArticleById", "isOnboardingCompleted", "", "()Lkotlinx/coroutines/flow/Flow;", "setOnboardingCompleted", "completed", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface AppRepository {
    java.lang.Object addBooking(com.app.a1bat.domain.model.Booking booking, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object deleteBooking(java.lang.String str, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Article>> getAllArticles();

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Booking>> getAllBookings();

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Project>> getAllProjects();

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> getAllServices();

    kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.Article> getArticleById(int id);

    kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.ConsultingService> getServiceById(int id);

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> getServicesByCategory(java.lang.String category);

    kotlinx.coroutines.flow.Flow<java.lang.Boolean> isOnboardingCompleted();

    java.lang.Object setOnboardingCompleted(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);
}
