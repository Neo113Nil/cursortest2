package com.app.a1bat.network;

/* compiled from: HttpClientProvider.kt */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/app/a1bat/network/HttpClientProvider;", "", "<init>", "()V", "client", "Lio/ktor/client/HttpClient;", "getClient", "()Lio/ktor/client/HttpClient;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class HttpClientProvider {
    public static final com.app.a1bat.network.HttpClientProvider INSTANCE = new com.app.a1bat.network.HttpClientProvider();
    private static final io.ktor.client.HttpClient client = io.ktor.client.HttpClientKt.HttpClient(com.app.a1bat.network.HttpClientProviderKt.createPlatformEngine(), new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.network.HttpClientProvider$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            kotlin.Unit client$lambda$2;
            client$lambda$2 = com.app.a1bat.network.HttpClientProvider.client$lambda$2((io.ktor.client.HttpClientConfig) obj);
            return client$lambda$2;
        }
    });
    public static final int $stable = 8;

    private HttpClientProvider() {
    }

    public final io.ktor.client.HttpClient getClient() {
        return client;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit client$lambda$2(io.ktor.client.HttpClientConfig HttpClient) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(HttpClient, "$this$HttpClient");
        HttpClient.install(io.ktor.client.plugins.contentnegotiation.ContentNegotiation.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.network.HttpClientProvider$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit client$lambda$2$lambda$1;
                client$lambda$2$lambda$1 = com.app.a1bat.network.HttpClientProvider.client$lambda$2$lambda$1((io.ktor.client.plugins.contentnegotiation.ContentNegotiation.Config) obj);
                return client$lambda$2$lambda$1;
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit client$lambda$2$lambda$1(io.ktor.client.plugins.contentnegotiation.ContentNegotiation.Config install) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(install, "$this$install");
        io.ktor.serialization.kotlinx.json.JsonSupportKt.json$default(install, kotlinx.serialization.json.JsonKt.Json$default(null, new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.network.HttpClientProvider$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit client$lambda$2$lambda$1$lambda$0;
                client$lambda$2$lambda$1$lambda$0 = com.app.a1bat.network.HttpClientProvider.client$lambda$2$lambda$1$lambda$0((kotlinx.serialization.json.JsonBuilder) obj);
                return client$lambda$2$lambda$1$lambda$0;
            }
        }, 1, null), null, 2, null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit client$lambda$2$lambda$1$lambda$0(kotlinx.serialization.json.JsonBuilder Json) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Json, "$this$Json");
        Json.setIgnoreUnknownKeys(true);
        Json.setLenient(true);
        return kotlin.Unit.INSTANCE;
    }
}
