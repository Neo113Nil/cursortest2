package com.app.a1bat.network;

/* compiled from: NetworkMonitor.kt */
@kotlin.Metadata(d1 = {"\u00009\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002*\u0001\u000f\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u0013\u001a\u00020\u0012H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\fX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\rR\u0010\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0010¨\u0006\u0014"}, d2 = {"Lcom/app/a1bat/network/NetworkMonitorAndroid;", "Lcom/app/a1bat/network/NetworkMonitor;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "connectivityManager", "Landroid/net/ConnectivityManager;", "_isConnected", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "isConnected", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "callback", "com/app/a1bat/network/NetworkMonitorAndroid$callback$1", "Lcom/app/a1bat/network/NetworkMonitorAndroid$callback$1;", "start", "", "stop", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class NetworkMonitorAndroid implements com.app.a1bat.network.NetworkMonitor {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isConnected;
    private final com.app.a1bat.network.NetworkMonitorAndroid$callback$1 callback;
    private final android.net.ConnectivityManager connectivityManager;
    private final android.content.Context context;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isConnected;

    /* JADX WARN: Type inference failed for: r2v7, types: [com.app.a1bat.network.NetworkMonitorAndroid$callback$1] */
    public NetworkMonitorAndroid(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        java.lang.Object systemService = context.getSystemService("connectivity");
        kotlin.jvm.internal.Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        this.connectivityManager = (android.net.ConnectivityManager) systemService;
        kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> MutableStateFlow = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(true);
        this._isConnected = MutableStateFlow;
        this.isConnected = MutableStateFlow;
        this.callback = new android.net.ConnectivityManager.NetworkCallback() { // from class: com.app.a1bat.network.NetworkMonitorAndroid$callback$1
            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onAvailable(android.net.Network network) {
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(network, "network");
                mutableStateFlow = com.app.a1bat.network.NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(true);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onLost(android.net.Network network) {
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(network, "network");
                mutableStateFlow = com.app.a1bat.network.NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(false);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onUnavailable() {
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
                mutableStateFlow = com.app.a1bat.network.NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(false);
            }
        };
    }

    @Override // com.app.a1bat.network.NetworkMonitor
    public kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isConnected() {
        return this.isConnected;
    }

    @Override // com.app.a1bat.network.NetworkMonitor
    public void start() {
        boolean z;
        try {
            this.connectivityManager.registerNetworkCallback(new android.net.NetworkRequest.Builder().addCapability(12).build(), this.callback);
            android.net.NetworkInfo activeNetworkInfo = this.connectivityManager.getActiveNetworkInfo();
            kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> mutableStateFlow = this._isConnected;
            if (activeNetworkInfo != null) {
                z = true;
                if (activeNetworkInfo.isConnected()) {
                    mutableStateFlow.setValue(java.lang.Boolean.valueOf(z));
                }
            }
            z = false;
            mutableStateFlow.setValue(java.lang.Boolean.valueOf(z));
        } catch (java.lang.Exception unused) {
            this._isConnected.setValue(false);
        }
    }

    @Override // com.app.a1bat.network.NetworkMonitor
    public void stop() {
        try {
            this.connectivityManager.unregisterNetworkCallback(this.callback);
        } catch (java.lang.Exception unused) {
        }
    }
}
