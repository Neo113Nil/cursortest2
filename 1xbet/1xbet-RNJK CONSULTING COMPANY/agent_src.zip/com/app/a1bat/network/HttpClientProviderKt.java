package com.app.a1bat.network;

/* compiled from: HttpClientProvider.kt */
@kotlin.Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u0006\u0012\u0002\b\u00030\u0001¨\u0006\u0002"}, d2 = {"createPlatformEngine", "Lio/ktor/client/engine/HttpClientEngineFactory;", "app_release"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class HttpClientProviderKt {
    public static final io.ktor.client.engine.HttpClientEngineFactory<?> createPlatformEngine() {
        return io.ktor.client.engine.okhttp.OkHttp.INSTANCE;
    }
}
