package com.app.a1bat.network;

/* compiled from: NetworkMonitor.kt */
@kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\t¨\u0006\f"}, d2 = {"Lcom/app/a1bat/network/NetworkViewModel;", "Landroidx/lifecycle/ViewModel;", "monitor", "Lcom/app/a1bat/network/NetworkMonitor;", "<init>", "(Lcom/app/a1bat/network/NetworkMonitor;)V", "isConnected", "Lkotlinx/coroutines/flow/StateFlow;", "", "()Lkotlinx/coroutines/flow/StateFlow;", "onCleared", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class NetworkViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isConnected;
    private final com.app.a1bat.network.NetworkMonitor monitor;

    /* JADX WARN: Multi-variable type inference failed */
    public NetworkViewModel() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    public /* synthetic */ NetworkViewModel(com.app.a1bat.network.NetworkMonitor networkMonitor, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? com.app.a1bat.network.NetworkMonitorKt.createNetworkMonitor() : networkMonitor);
    }

    public NetworkViewModel(com.app.a1bat.network.NetworkMonitor monitor) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(monitor, "monitor");
        this.monitor = monitor;
        this.isConnected = monitor.isConnected();
        monitor.start();
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isConnected() {
        return this.isConnected;
    }

    @Override // androidx.lifecycle.ViewModel
    protected void onCleared() {
        this.monitor.stop();
        super.onCleared();
    }
}
