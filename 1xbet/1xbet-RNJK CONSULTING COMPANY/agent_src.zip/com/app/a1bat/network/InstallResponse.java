package com.app.a1bat.network;

/* compiled from: InstallResponse.kt */
@kotlin.Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 #2\u00020\u0001:\u0002\"#B\u001f\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007B/\b\u0010\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u0006\u0010\u000bJ\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\u000fJ&\u0010\u0013\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u0014J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001J%\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 H\u0001¢\u0006\u0002\b!R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0015\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\n\n\u0002\u0010\u0010\u001a\u0004\b\u000e\u0010\u000f¨\u0006$"}, d2 = {"Lcom/app/a1bat/network/InstallResponse;", "", com.google.android.gms.common.internal.ImagesContract.URL, "", "id", "", "<init>", "(Ljava/lang/String;Ljava/lang/Integer;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/lang/Integer;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getUrl", "()Ljava/lang/String;", "getId", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "component1", "component2", "copy", "(Ljava/lang/String;Ljava/lang/Integer;)Lcom/app/a1bat/network/InstallResponse;", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
@kotlinx.serialization.InternalSerializationApi
@kotlinx.serialization.Serializable
/* loaded from: classes3.dex */
public final /* data */ class InstallResponse {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final com.app.a1bat.network.InstallResponse.Companion INSTANCE = new com.app.a1bat.network.InstallResponse.Companion(null);
    private final java.lang.Integer id;
    private final java.lang.String url;

    /* JADX WARN: Multi-variable type inference failed */
    public InstallResponse() {
        this((java.lang.String) null, (java.lang.Integer) (0 == true ? 1 : 0), 3, (kotlin.jvm.internal.DefaultConstructorMarker) (0 == true ? 1 : 0));
    }

    public static /* synthetic */ com.app.a1bat.network.InstallResponse copy$default(com.app.a1bat.network.InstallResponse installResponse, java.lang.String str, java.lang.Integer num, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            str = installResponse.url;
        }
        if ((i & 2) != 0) {
            num = installResponse.id;
        }
        return installResponse.copy(str, num);
    }

    /* renamed from: component1, reason: from getter */
    public final java.lang.String getUrl() {
        return this.url;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.Integer getId() {
        return this.id;
    }

    public final com.app.a1bat.network.InstallResponse copy(java.lang.String url, java.lang.Integer id) {
        return new com.app.a1bat.network.InstallResponse(url, id);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.network.InstallResponse)) {
            return false;
        }
        com.app.a1bat.network.InstallResponse installResponse = (com.app.a1bat.network.InstallResponse) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.url, installResponse.url) && kotlin.jvm.internal.Intrinsics.areEqual(this.id, installResponse.id);
    }

    public int hashCode() {
        java.lang.String str = this.url;
        int hashCode = (str == null ? 0 : str.hashCode()) * 31;
        java.lang.Integer num = this.id;
        return hashCode + (num != null ? num.hashCode() : 0);
    }

    public java.lang.String toString() {
        return "InstallResponse(url=" + this.url + ", id=" + this.id + ")";
    }

    /* compiled from: InstallResponse.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/app/a1bat/network/InstallResponse$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/app/a1bat/network/InstallResponse;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final kotlinx.serialization.KSerializer<com.app.a1bat.network.InstallResponse> serializer() {
            return com.app.a1bat.network.InstallResponse$$serializer.INSTANCE;
        }
    }

    public /* synthetic */ InstallResponse(int i, java.lang.String str, java.lang.Integer num, kotlinx.serialization.internal.SerializationConstructorMarker serializationConstructorMarker) {
        if ((i & 1) == 0) {
            this.url = null;
        } else {
            this.url = str;
        }
        if ((i & 2) == 0) {
            this.id = null;
        } else {
            this.id = num;
        }
    }

    @kotlin.jvm.JvmStatic
    public static final /* synthetic */ void write$Self$app_release(com.app.a1bat.network.InstallResponse self, kotlinx.serialization.encoding.CompositeEncoder output, kotlinx.serialization.descriptors.SerialDescriptor serialDesc) {
        if (output.shouldEncodeElementDefault(serialDesc, 0) || self.url != null) {
            output.encodeNullableSerializableElement(serialDesc, 0, kotlinx.serialization.internal.StringSerializer.INSTANCE, self.url);
        }
        if (!output.shouldEncodeElementDefault(serialDesc, 1) && self.id == null) {
            return;
        }
        output.encodeNullableSerializableElement(serialDesc, 1, kotlinx.serialization.internal.IntSerializer.INSTANCE, self.id);
    }

    public InstallResponse(java.lang.String str, java.lang.Integer num) {
        this.url = str;
        this.id = num;
    }

    public /* synthetic */ InstallResponse(java.lang.String str, java.lang.Integer num, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? null : str, (i & 2) != 0 ? null : num);
    }

    public final java.lang.String getUrl() {
        return this.url;
    }

    public final java.lang.Integer getId() {
        return this.id;
    }
}
