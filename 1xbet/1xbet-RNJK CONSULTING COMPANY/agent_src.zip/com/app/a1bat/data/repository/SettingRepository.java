package com.app.a1bat.data.repository;

/* compiled from: SettingRepository.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0006\bf\u0018\u00002\u00020\u0001J\u000e\u0010\u0002\u001a\u00020\u0003H¦@¢\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0003H¦@¢\u0006\u0002\u0010\bJ\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH¦@¢\u0006\u0002\u0010\u0004J\u001c\u0010\f\u001a\u00020\u00062\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH¦@¢\u0006\u0002\u0010\u000eJ\u0016\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0003H¦@¢\u0006\u0002\u0010\bJ\u000e\u0010\u0010\u001a\u00020\u0003H¦@¢\u0006\u0002\u0010\u0004¨\u0006\u0011"}, d2 = {"Lcom/app/a1bat/data/repository/SettingRepository;", "", "isFirstLaunch", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setFirstLaunch", "", "value", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRecentSearches", "", "", "saveRecentSearches", "list", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setInstallDone", "isInstallDone", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface SettingRepository {
    java.lang.Object getRecentSearches(kotlin.coroutines.Continuation<? super java.util.List<java.lang.String>> continuation);

    java.lang.Object isFirstLaunch(kotlin.coroutines.Continuation<? super java.lang.Boolean> continuation);

    java.lang.Object isInstallDone(kotlin.coroutines.Continuation<? super java.lang.Boolean> continuation);

    java.lang.Object saveRecentSearches(java.util.List<java.lang.String> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object setFirstLaunch(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object setInstallDone(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);
}
