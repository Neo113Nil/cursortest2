package com.app.a1bat.data.repository;

/* compiled from: SettingRepository.kt */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "prefs", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2", f = "SettingRepository.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class SettingRepositoryImpl$saveRecentSearches$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ java.util.List<java.lang.String> $list;
    /* synthetic */ java.lang.Object L$0;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    SettingRepositoryImpl$saveRecentSearches$2(java.util.List<java.lang.String> list, kotlin.coroutines.Continuation<? super com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2> continuation) {
        super(2, continuation);
        this.$list = list;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2 settingRepositoryImpl$saveRecentSearches$2 = new com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2(this.$list, continuation);
        settingRepositoryImpl$saveRecentSearches$2.L$0 = obj;
        return settingRepositoryImpl$saveRecentSearches$2;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(androidx.datastore.preferences.core.MutablePreferences mutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2) create(mutablePreferences, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        com.app.a1bat.data.repository.SettingRepositoryImpl.Companion companion;
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.L$0;
            companion = com.app.a1bat.data.repository.SettingRepositoryImpl.Companion;
            mutablePreferences.set(companion.getRECENT_SEARCHES_KEY(), kotlin.collections.CollectionsKt.joinToString$default(this.$list, com.app.a1bat.data.repository.SettingRepositoryImpl.SEPARATOR, null, null, 0, null, null, 62, null));
            return kotlin.Unit.INSTANCE;
        }
        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
