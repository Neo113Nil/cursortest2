package com.app.a1bat.data.repository;

/* compiled from: AppRepositoryImpl.kt */
@kotlin.Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\u0014\u0010\u000e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00110\u00100\u000fH\u0016J\u001c\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00110\u00100\u000f2\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0018\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u000f2\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\u0014\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\u00100\u000fH\u0016J\u0016\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010\u001dJ\u0016\u0010\u001e\u001a\u00020\u001b2\u0006\u0010\u001f\u001a\u00020\u0014H\u0096@¢\u0006\u0002\u0010 J\u0014\u0010!\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\"0\u00100\u000fH\u0016J\u0014\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020$0\u00100\u000fH\u0016J\u0018\u0010%\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010$0\u000f2\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\u0016\u0010)\u001a\u00020\u001b2\u0006\u0010*\u001a\u00020'H\u0096@¢\u0006\u0002\u0010+R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010&\u001a\b\u0012\u0004\u0012\u00020'0\u000f8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b&\u0010(¨\u0006,"}, d2 = {"Lcom/app/a1bat/data/repository/AppRepositoryImpl;", "Lcom/app/a1bat/domain/repository/AppRepository;", "serviceDao", "Lcom/app/a1bat/data/local/dao/ServiceDao;", "bookingDao", "Lcom/app/a1bat/data/local/dao/BookingDao;", "projectDao", "Lcom/app/a1bat/data/local/dao/ProjectDao;", "articleDao", "Lcom/app/a1bat/data/local/dao/ArticleDao;", "preferences", "Lcom/app/a1bat/data/local/preferences/AppPreferences;", "<init>", "(Lcom/app/a1bat/data/local/dao/ServiceDao;Lcom/app/a1bat/data/local/dao/BookingDao;Lcom/app/a1bat/data/local/dao/ProjectDao;Lcom/app/a1bat/data/local/dao/ArticleDao;Lcom/app/a1bat/data/local/preferences/AppPreferences;)V", "getAllServices", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/app/a1bat/domain/model/ConsultingService;", "getServicesByCategory", "category", "", "getServiceById", "id", "", "getAllBookings", "Lcom/app/a1bat/domain/model/Booking;", "addBooking", "", "booking", "(Lcom/app/a1bat/domain/model/Booking;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteBooking", "bookingId", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getAllProjects", "Lcom/app/a1bat/domain/model/Project;", "getAllArticles", "Lcom/app/a1bat/domain/model/Article;", "getArticleById", "isOnboardingCompleted", "", "()Lkotlinx/coroutines/flow/Flow;", "setOnboardingCompleted", "completed", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class AppRepositoryImpl implements com.app.a1bat.domain.repository.AppRepository {
    public static final int $stable = 8;
    private final com.app.a1bat.data.local.dao.ArticleDao articleDao;
    private final com.app.a1bat.data.local.dao.BookingDao bookingDao;
    private final com.app.a1bat.data.local.preferences.AppPreferences preferences;
    private final com.app.a1bat.data.local.dao.ProjectDao projectDao;
    private final com.app.a1bat.data.local.dao.ServiceDao serviceDao;

    public AppRepositoryImpl(com.app.a1bat.data.local.dao.ServiceDao serviceDao, com.app.a1bat.data.local.dao.BookingDao bookingDao, com.app.a1bat.data.local.dao.ProjectDao projectDao, com.app.a1bat.data.local.dao.ArticleDao articleDao, com.app.a1bat.data.local.preferences.AppPreferences preferences) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(serviceDao, "serviceDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bookingDao, "bookingDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(projectDao, "projectDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(articleDao, "articleDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(preferences, "preferences");
        this.serviceDao = serviceDao;
        this.bookingDao = bookingDao;
        this.projectDao = projectDao;
        this.articleDao = articleDao;
        this.preferences = preferences;
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> getAllServices() {
        final kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> allServices = this.serviceDao.getAllServices();
        return (kotlinx.coroutines.flow.Flow) new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                java.util.List list = (java.util.List) obj;
                                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
                                java.util.Iterator<T> it = list.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(((com.app.a1bat.data.local.entity.ServiceEntity) it.next()).toDomainModel());
                                }
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getAllServices$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.ConsultingService>> getServicesByCategory(java.lang.String category) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(category, "category");
        final kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> servicesByCategory = this.serviceDao.getServicesByCategory(category);
        return (kotlinx.coroutines.flow.Flow) new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                java.util.List list = (java.util.List) obj;
                                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
                                java.util.Iterator<T> it = list.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(((com.app.a1bat.data.local.entity.ServiceEntity) it.next()).toDomainModel());
                                }
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends com.app.a1bat.domain.model.ConsultingService>> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getServicesByCategory$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.ConsultingService> getServiceById(int id) {
        final kotlinx.coroutines.flow.Flow<com.app.a1bat.data.local.entity.ServiceEntity> serviceById = this.serviceDao.getServiceById(id);
        return new kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.ConsultingService>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                com.app.a1bat.data.local.entity.ServiceEntity serviceEntity = (com.app.a1bat.data.local.entity.ServiceEntity) obj;
                                com.app.a1bat.domain.model.ConsultingService domainModel = serviceEntity != null ? serviceEntity.toDomainModel() : null;
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(domainModel, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super com.app.a1bat.domain.model.ConsultingService> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getServiceById$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Booking>> getAllBookings() {
        final kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.BookingEntity>> allBookings = this.bookingDao.getAllBookings();
        return (kotlinx.coroutines.flow.Flow) new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.app.a1bat.domain.model.Booking>>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                java.util.List list = (java.util.List) obj;
                                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
                                java.util.Iterator<T> it = list.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(((com.app.a1bat.data.local.entity.BookingEntity) it.next()).toDomainModel());
                                }
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends com.app.a1bat.domain.model.Booking>> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getAllBookings$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public java.lang.Object addBooking(com.app.a1bat.domain.model.Booking booking, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object insertBooking = this.bookingDao.insertBooking(com.app.a1bat.data.local.entity.BookingEntity.INSTANCE.fromDomainModel(booking), continuation);
        return insertBooking == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? insertBooking : kotlin.Unit.INSTANCE;
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public java.lang.Object deleteBooking(java.lang.String str, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object deleteBooking = this.bookingDao.deleteBooking(str, continuation);
        return deleteBooking == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? deleteBooking : kotlin.Unit.INSTANCE;
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Project>> getAllProjects() {
        final kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ProjectEntity>> allProjects = this.projectDao.getAllProjects();
        return (kotlinx.coroutines.flow.Flow) new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.app.a1bat.domain.model.Project>>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                java.util.List list = (java.util.List) obj;
                                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
                                java.util.Iterator<T> it = list.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(((com.app.a1bat.data.local.entity.ProjectEntity) it.next()).toDomainModel());
                                }
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends com.app.a1bat.domain.model.Project>> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getAllProjects$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.domain.model.Article>> getAllArticles() {
        final kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ArticleEntity>> allArticles = this.articleDao.getAllArticles();
        return (kotlinx.coroutines.flow.Flow) new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.app.a1bat.domain.model.Article>>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                java.util.List list = (java.util.List) obj;
                                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
                                java.util.Iterator<T> it = list.iterator();
                                while (it.hasNext()) {
                                    arrayList.add(((com.app.a1bat.data.local.entity.ArticleEntity) it.next()).toDomainModel());
                                }
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(arrayList, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends com.app.a1bat.domain.model.Article>> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getAllArticles$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.Article> getArticleById(int id) {
        final kotlinx.coroutines.flow.Flow<com.app.a1bat.data.local.entity.ArticleEntity> articleById = this.articleDao.getArticleById(id);
        return new kotlinx.coroutines.flow.Flow<com.app.a1bat.domain.model.Article>() { // from class: com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1$2", f = "AppRepositoryImpl.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    if (continuation instanceof com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                com.app.a1bat.data.local.entity.ArticleEntity articleEntity = (com.app.a1bat.data.local.entity.ArticleEntity) obj;
                                com.app.a1bat.domain.model.Article domainModel = articleEntity != null ? articleEntity.toDomainModel() : null;
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(domainModel, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super com.app.a1bat.domain.model.Article> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.repository.AppRepositoryImpl$getArticleById$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public kotlinx.coroutines.flow.Flow<java.lang.Boolean> isOnboardingCompleted() {
        return this.preferences.isOnboardingCompleted();
    }

    @Override // com.app.a1bat.domain.repository.AppRepository
    public java.lang.Object setOnboardingCompleted(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object onboardingCompleted = this.preferences.setOnboardingCompleted(z, continuation);
        return onboardingCompleted == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? onboardingCompleted : kotlin.Unit.INSTANCE;
    }
}
