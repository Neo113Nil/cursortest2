package com.app.a1bat.data.repository;

/* compiled from: RemoteConfigRepository.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.RemoteConfigRepositoryImpl", f = "RemoteConfigRepository.kt", i = {}, l = {132}, m = "getSavedUrl", n = {}, s = {})
/* loaded from: classes3.dex */
final class RemoteConfigRepositoryImpl$getSavedUrl$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    int label;
    /* synthetic */ java.lang.Object result;
    final /* synthetic */ com.app.a1bat.data.repository.RemoteConfigRepositoryImpl this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    RemoteConfigRepositoryImpl$getSavedUrl$1(com.app.a1bat.data.repository.RemoteConfigRepositoryImpl remoteConfigRepositoryImpl, kotlin.coroutines.Continuation<? super com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$getSavedUrl$1> continuation) {
        super(continuation);
        this.this$0 = remoteConfigRepositoryImpl;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.getSavedUrl(this);
    }
}
