package com.app.a1bat.data.repository;

/* compiled from: RemoteConfigRepository.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.repository.RemoteConfigRepositoryImpl", f = "RemoteConfigRepository.kt", i = {1}, l = {224, 81}, m = "fetchUrl", n = {androidx.core.app.NotificationCompat.CATEGORY_STATUS}, s = {"I$0"})
/* loaded from: classes3.dex */
final class RemoteConfigRepositoryImpl$fetchUrl$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    int I$0;
    int label;
    /* synthetic */ java.lang.Object result;
    final /* synthetic */ com.app.a1bat.data.repository.RemoteConfigRepositoryImpl this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    RemoteConfigRepositoryImpl$fetchUrl$1(com.app.a1bat.data.repository.RemoteConfigRepositoryImpl remoteConfigRepositoryImpl, kotlin.coroutines.Continuation<? super com.app.a1bat.data.repository.RemoteConfigRepositoryImpl$fetchUrl$1> continuation) {
        super(continuation);
        this.this$0 = remoteConfigRepositoryImpl;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.fetchUrl(this);
    }
}
