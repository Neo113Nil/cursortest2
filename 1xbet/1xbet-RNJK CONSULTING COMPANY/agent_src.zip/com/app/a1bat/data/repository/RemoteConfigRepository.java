package com.app.a1bat.data.repository;

/* compiled from: RemoteConfigRepository.kt */
@kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003H¦@¢\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0003H¦@¢\u0006\u0002\u0010\bJ\u0010\u0010\t\u001a\u0004\u0018\u00010\u0003H¦@¢\u0006\u0002\u0010\u0004¨\u0006\n"}, d2 = {"Lcom/app/a1bat/data/repository/RemoteConfigRepository;", "", "fetchUrl", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "saveUrl", "", com.google.android.gms.common.internal.ImagesContract.URL, "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getSavedUrl", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface RemoteConfigRepository {
    java.lang.Object fetchUrl(kotlin.coroutines.Continuation<? super java.lang.String> continuation);

    java.lang.Object getSavedUrl(kotlin.coroutines.Continuation<? super java.lang.String> continuation);

    java.lang.Object saveUrl(java.lang.String str, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);
}
