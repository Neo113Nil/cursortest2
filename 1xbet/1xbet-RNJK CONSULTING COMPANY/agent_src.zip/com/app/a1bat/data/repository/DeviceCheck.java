package com.app.a1bat.data.repository;

/* compiled from: RemoteConfigRepository.kt */
@kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\b\u0010\b\u001a\u00020\u0005H\u0002J\u0010\u0010\t\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0002J\u0010\u0010\n\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0002J\b\u0010\u000b\u001a\u00020\u0005H\u0002¨\u0006\f"}, d2 = {"Lcom/app/a1bat/data/repository/DeviceCheck;", "", "<init>", "()V", "isRealDevice", "", "context", "Landroid/content/Context;", "isBuildEmulator", "hasTelephony", "hasSensors", "isProbablyX86", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class DeviceCheck {
    public static final int $stable = 0;
    public static final com.app.a1bat.data.repository.DeviceCheck INSTANCE = new com.app.a1bat.data.repository.DeviceCheck();

    private DeviceCheck() {
    }

    public final boolean isRealDevice(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        return !isBuildEmulator() && hasTelephony(context) && hasSensors(context) && !isProbablyX86();
    }

    private final boolean isBuildEmulator() {
        java.lang.String FINGERPRINT = android.os.Build.FINGERPRINT;
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(FINGERPRINT, "FINGERPRINT");
        if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) FINGERPRINT, (java.lang.CharSequence) "generic", true)) {
            java.lang.String FINGERPRINT2 = android.os.Build.FINGERPRINT;
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(FINGERPRINT2, "FINGERPRINT");
            if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) FINGERPRINT2, (java.lang.CharSequence) androidx.core.os.EnvironmentCompat.MEDIA_UNKNOWN, true)) {
                java.lang.String MODEL = android.os.Build.MODEL;
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(MODEL, "MODEL");
                if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) MODEL, (java.lang.CharSequence) "google_sdk", true)) {
                    java.lang.String MODEL2 = android.os.Build.MODEL;
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(MODEL2, "MODEL");
                    if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) MODEL2, (java.lang.CharSequence) "Emulator", true)) {
                        java.lang.String MODEL3 = android.os.Build.MODEL;
                        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(MODEL3, "MODEL");
                        if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) MODEL3, (java.lang.CharSequence) "sdk_gphone", true)) {
                            java.lang.String MANUFACTURER = android.os.Build.MANUFACTURER;
                            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(MANUFACTURER, "MANUFACTURER");
                            if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) MANUFACTURER, (java.lang.CharSequence) "Genymotion", true)) {
                                java.lang.String HARDWARE = android.os.Build.HARDWARE;
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(HARDWARE, "HARDWARE");
                                if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) HARDWARE, (java.lang.CharSequence) "goldfish", true)) {
                                    java.lang.String HARDWARE2 = android.os.Build.HARDWARE;
                                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(HARDWARE2, "HARDWARE");
                                    if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) HARDWARE2, (java.lang.CharSequence) "ranchu", true)) {
                                        java.lang.String HARDWARE3 = android.os.Build.HARDWARE;
                                        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(HARDWARE3, "HARDWARE");
                                        if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) HARDWARE3, (java.lang.CharSequence) "intel", true)) {
                                            java.lang.String PRODUCT = android.os.Build.PRODUCT;
                                            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(PRODUCT, "PRODUCT");
                                            if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) PRODUCT, (java.lang.CharSequence) "sdk", true)) {
                                                java.lang.String PRODUCT2 = android.os.Build.PRODUCT;
                                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(PRODUCT2, "PRODUCT");
                                                if (!kotlin.text.StringsKt.contains((java.lang.CharSequence) PRODUCT2, (java.lang.CharSequence) "emulator", true)) {
                                                    return false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    private final boolean hasTelephony(android.content.Context context) {
        return context.getPackageManager().hasSystemFeature("android.hardware.telephony");
    }

    private final boolean hasSensors(android.content.Context context) {
        java.lang.Object systemService = context.getSystemService("sensor");
        kotlin.jvm.internal.Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.SensorManager");
        android.hardware.SensorManager sensorManager = (android.hardware.SensorManager) systemService;
        return (sensorManager.getDefaultSensor(1) == null || sensorManager.getDefaultSensor(4) == null) ? false : true;
    }

    private final boolean isProbablyX86() {
        java.lang.String[] SUPPORTED_ABIS = android.os.Build.SUPPORTED_ABIS;
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(SUPPORTED_ABIS, "SUPPORTED_ABIS");
        return kotlin.text.StringsKt.contains((java.lang.CharSequence) kotlin.collections.ArraysKt.joinToString$default(SUPPORTED_ABIS, (java.lang.CharSequence) null, (java.lang.CharSequence) null, (java.lang.CharSequence) null, 0, (java.lang.CharSequence) null, (kotlin.jvm.functions.Function1) null, 63, (java.lang.Object) null), (java.lang.CharSequence) "x86", true);
    }
}
