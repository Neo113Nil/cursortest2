package com.app.a1bat.data.repository;

/* compiled from: SettingRepository.kt */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0007\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u0015\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u000e\u0010\u0007\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\tJ\u0016\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\rJ\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fH\u0096@¢\u0006\u0002\u0010\tJ\u0016\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\rJ\u000e\u0010\u0012\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\tJ\u001c\u0010\u0013\u001a\u00020\u000b2\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fH\u0096@¢\u0006\u0002\u0010\u0015R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/app/a1bat/data/repository/SettingRepositoryImpl;", "Lcom/app/a1bat/data/repository/SettingRepository;", "dataStore", "Landroidx/datastore/core/DataStore;", "Landroidx/datastore/preferences/core/Preferences;", "<init>", "(Landroidx/datastore/core/DataStore;)V", "isFirstLaunch", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setFirstLaunch", "", "value", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRecentSearches", "", "", "setInstallDone", "isInstallDone", "saveRecentSearches", "list", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SettingRepositoryImpl implements com.app.a1bat.data.repository.SettingRepository {

    @java.lang.Deprecated
    public static final java.lang.String SEPARATOR = "|||";
    private final androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> dataStore;
    private static final com.app.a1bat.data.repository.SettingRepositoryImpl.Companion Companion = new com.app.a1bat.data.repository.SettingRepositoryImpl.Companion(null);
    public static final int $stable = 8;
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> FIRST_LAUNCH_KEY = androidx.datastore.preferences.core.PreferencesKeys.booleanKey("first_launch");
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> RECENT_SEARCHES_KEY = androidx.datastore.preferences.core.PreferencesKeys.stringKey("recent_searches");
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> FCM_TOKEN_KEY = androidx.datastore.preferences.core.PreferencesKeys.stringKey("fcm_token");
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> INSTALL_DONE_KEY = androidx.datastore.preferences.core.PreferencesKeys.booleanKey("install_done");

    public SettingRepositoryImpl(androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> dataStore) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataStore, "dataStore");
        this.dataStore = dataStore;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: SettingRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\bR\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\n0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\bR\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\bR\u000e\u0010\u0010\u001a\u00020\nX\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/app/a1bat/data/repository/SettingRepositoryImpl$Companion;", "", "<init>", "()V", "FIRST_LAUNCH_KEY", "Landroidx/datastore/preferences/core/Preferences$Key;", "", "getFIRST_LAUNCH_KEY", "()Landroidx/datastore/preferences/core/Preferences$Key;", "RECENT_SEARCHES_KEY", "", "getRECENT_SEARCHES_KEY", "FCM_TOKEN_KEY", "getFCM_TOKEN_KEY", "INSTALL_DONE_KEY", "getINSTALL_DONE_KEY", "SEPARATOR", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> getFIRST_LAUNCH_KEY() {
            return com.app.a1bat.data.repository.SettingRepositoryImpl.FIRST_LAUNCH_KEY;
        }

        public final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> getRECENT_SEARCHES_KEY() {
            return com.app.a1bat.data.repository.SettingRepositoryImpl.RECENT_SEARCHES_KEY;
        }

        public final androidx.datastore.preferences.core.Preferences.Key<java.lang.String> getFCM_TOKEN_KEY() {
            return com.app.a1bat.data.repository.SettingRepositoryImpl.FCM_TOKEN_KEY;
        }

        public final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> getINSTALL_DONE_KEY() {
            return com.app.a1bat.data.repository.SettingRepositoryImpl.INSTALL_DONE_KEY;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // com.app.a1bat.data.repository.SettingRepository
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public java.lang.Object isFirstLaunch(kotlin.coroutines.Continuation<? super java.lang.Boolean> continuation) {
        com.app.a1bat.data.repository.SettingRepositoryImpl$isFirstLaunch$1 settingRepositoryImpl$isFirstLaunch$1;
        int i;
        if (continuation instanceof com.app.a1bat.data.repository.SettingRepositoryImpl$isFirstLaunch$1) {
            settingRepositoryImpl$isFirstLaunch$1 = (com.app.a1bat.data.repository.SettingRepositoryImpl$isFirstLaunch$1) continuation;
            if ((settingRepositoryImpl$isFirstLaunch$1.label & Integer.MIN_VALUE) != 0) {
                settingRepositoryImpl$isFirstLaunch$1.label -= Integer.MIN_VALUE;
                java.lang.Object obj = settingRepositoryImpl$isFirstLaunch$1.result;
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                i = settingRepositoryImpl$isFirstLaunch$1.label;
                if (i != 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = this.dataStore.getData();
                    settingRepositoryImpl$isFirstLaunch$1.label = 1;
                    obj = kotlinx.coroutines.flow.FlowKt.first(data, settingRepositoryImpl$isFirstLaunch$1);
                    if (obj == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                }
                java.lang.Boolean bool = (java.lang.Boolean) ((androidx.datastore.preferences.core.Preferences) obj).get(FIRST_LAUNCH_KEY);
                return kotlin.coroutines.jvm.internal.Boxing.boxBoolean(bool != null ? bool.booleanValue() : true);
            }
        }
        settingRepositoryImpl$isFirstLaunch$1 = new com.app.a1bat.data.repository.SettingRepositoryImpl$isFirstLaunch$1(this, continuation);
        java.lang.Object obj2 = settingRepositoryImpl$isFirstLaunch$1.result;
        java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        i = settingRepositoryImpl$isFirstLaunch$1.label;
        if (i != 0) {
        }
        java.lang.Boolean bool2 = (java.lang.Boolean) ((androidx.datastore.preferences.core.Preferences) obj2).get(FIRST_LAUNCH_KEY);
        return kotlin.coroutines.jvm.internal.Boxing.boxBoolean(bool2 != null ? bool2.booleanValue() : true);
    }

    @Override // com.app.a1bat.data.repository.SettingRepository
    public java.lang.Object setFirstLaunch(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object edit = androidx.datastore.preferences.core.PreferencesKt.edit(this.dataStore, new com.app.a1bat.data.repository.SettingRepositoryImpl$setFirstLaunch$2(z, null), continuation);
        return edit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? edit : kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // com.app.a1bat.data.repository.SettingRepository
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public java.lang.Object getRecentSearches(kotlin.coroutines.Continuation<? super java.util.List<java.lang.String>> continuation) {
        com.app.a1bat.data.repository.SettingRepositoryImpl$getRecentSearches$1 settingRepositoryImpl$getRecentSearches$1;
        int i;
        if (continuation instanceof com.app.a1bat.data.repository.SettingRepositoryImpl$getRecentSearches$1) {
            settingRepositoryImpl$getRecentSearches$1 = (com.app.a1bat.data.repository.SettingRepositoryImpl$getRecentSearches$1) continuation;
            if ((settingRepositoryImpl$getRecentSearches$1.label & Integer.MIN_VALUE) != 0) {
                settingRepositoryImpl$getRecentSearches$1.label -= Integer.MIN_VALUE;
                java.lang.Object obj = settingRepositoryImpl$getRecentSearches$1.result;
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                i = settingRepositoryImpl$getRecentSearches$1.label;
                if (i != 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = this.dataStore.getData();
                    settingRepositoryImpl$getRecentSearches$1.label = 1;
                    obj = kotlinx.coroutines.flow.FlowKt.first(data, settingRepositoryImpl$getRecentSearches$1);
                    if (obj == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                }
                java.lang.String str = (java.lang.String) ((androidx.datastore.preferences.core.Preferences) obj).get(RECENT_SEARCHES_KEY);
                return str != null ? kotlin.collections.CollectionsKt.emptyList() : kotlin.text.StringsKt.split$default((java.lang.CharSequence) str, new java.lang.String[]{SEPARATOR}, false, 0, 6, (java.lang.Object) null);
            }
        }
        settingRepositoryImpl$getRecentSearches$1 = new com.app.a1bat.data.repository.SettingRepositoryImpl$getRecentSearches$1(this, continuation);
        java.lang.Object obj2 = settingRepositoryImpl$getRecentSearches$1.result;
        java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        i = settingRepositoryImpl$getRecentSearches$1.label;
        if (i != 0) {
        }
        java.lang.String str2 = (java.lang.String) ((androidx.datastore.preferences.core.Preferences) obj2).get(RECENT_SEARCHES_KEY);
        if (str2 != null) {
        }
    }

    @Override // com.app.a1bat.data.repository.SettingRepository
    public java.lang.Object setInstallDone(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object edit = androidx.datastore.preferences.core.PreferencesKt.edit(this.dataStore, new com.app.a1bat.data.repository.SettingRepositoryImpl$setInstallDone$2(z, null), continuation);
        return edit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? edit : kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // com.app.a1bat.data.repository.SettingRepository
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public java.lang.Object isInstallDone(kotlin.coroutines.Continuation<? super java.lang.Boolean> continuation) {
        com.app.a1bat.data.repository.SettingRepositoryImpl$isInstallDone$1 settingRepositoryImpl$isInstallDone$1;
        int i;
        if (continuation instanceof com.app.a1bat.data.repository.SettingRepositoryImpl$isInstallDone$1) {
            settingRepositoryImpl$isInstallDone$1 = (com.app.a1bat.data.repository.SettingRepositoryImpl$isInstallDone$1) continuation;
            if ((settingRepositoryImpl$isInstallDone$1.label & Integer.MIN_VALUE) != 0) {
                settingRepositoryImpl$isInstallDone$1.label -= Integer.MIN_VALUE;
                java.lang.Object obj = settingRepositoryImpl$isInstallDone$1.result;
                java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                i = settingRepositoryImpl$isInstallDone$1.label;
                if (i != 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = this.dataStore.getData();
                    settingRepositoryImpl$isInstallDone$1.label = 1;
                    obj = kotlinx.coroutines.flow.FlowKt.first(data, settingRepositoryImpl$isInstallDone$1);
                    if (obj == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.throwOnFailure(obj);
                }
                java.lang.Boolean bool = (java.lang.Boolean) ((androidx.datastore.preferences.core.Preferences) obj).get(INSTALL_DONE_KEY);
                return kotlin.coroutines.jvm.internal.Boxing.boxBoolean(bool == null ? bool.booleanValue() : false);
            }
        }
        settingRepositoryImpl$isInstallDone$1 = new com.app.a1bat.data.repository.SettingRepositoryImpl$isInstallDone$1(this, continuation);
        java.lang.Object obj2 = settingRepositoryImpl$isInstallDone$1.result;
        java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        i = settingRepositoryImpl$isInstallDone$1.label;
        if (i != 0) {
        }
        java.lang.Boolean bool2 = (java.lang.Boolean) ((androidx.datastore.preferences.core.Preferences) obj2).get(INSTALL_DONE_KEY);
        return kotlin.coroutines.jvm.internal.Boxing.boxBoolean(bool2 == null ? bool2.booleanValue() : false);
    }

    @Override // com.app.a1bat.data.repository.SettingRepository
    public java.lang.Object saveRecentSearches(java.util.List<java.lang.String> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object edit = androidx.datastore.preferences.core.PreferencesKt.edit(this.dataStore, new com.app.a1bat.data.repository.SettingRepositoryImpl$saveRecentSearches$2(list, null), continuation);
        return edit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? edit : kotlin.Unit.INSTANCE;
    }
}
