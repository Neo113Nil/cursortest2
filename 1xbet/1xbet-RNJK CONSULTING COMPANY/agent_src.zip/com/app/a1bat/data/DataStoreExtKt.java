package com.app.a1bat.data;

/* compiled from: DataStoreExt.kt */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\"%\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u00038FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0004\u0010\u0005¨\u0006\b"}, d2 = {"settingsDataStore", "Landroidx/datastore/core/DataStore;", "Landroidx/datastore/preferences/core/Preferences;", "Landroid/content/Context;", "getSettingsDataStore", "(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", "settingsDataStore$delegate", "Lkotlin/properties/ReadOnlyProperty;", "app_release"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class DataStoreExtKt {
    static final /* synthetic */ kotlin.reflect.KProperty<java.lang.Object>[] $$delegatedProperties = {kotlin.jvm.internal.Reflection.property1(new kotlin.jvm.internal.PropertyReference1Impl(com.app.a1bat.data.DataStoreExtKt.class, "settingsDataStore", "getSettingsDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", 1))};
    private static final kotlin.properties.ReadOnlyProperty settingsDataStore$delegate = androidx.datastore.preferences.PreferenceDataStoreDelegateKt.preferencesDataStore$default("1Bat_settings", null, null, null, 14, null);

    public static final androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> getSettingsDataStore(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "<this>");
        return (androidx.datastore.core.DataStore) settingsDataStore$delegate.getValue(context, $$delegatedProperties[0]);
    }
}
