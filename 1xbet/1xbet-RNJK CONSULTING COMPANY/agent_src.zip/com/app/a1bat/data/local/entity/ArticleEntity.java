package com.app.a1bat.data.local.entity;

/* compiled from: ArticleEntity.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\n\u0010\u000bJ\u0006\u0010\u0014\u001a\u00020\u0015J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003JE\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020\u0003HÖ\u0001J\t\u0010!\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000f¨\u0006\""}, d2 = {"Lcom/app/a1bat/data/local/entity/ArticleEntity;", "", "id", "", io.ktor.http.LinkHeader.Parameters.Title, "", "category", "content", "readTimeMinutes", "imageUrl", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V", "getId", "()I", "getTitle", "()Ljava/lang/String;", "getCategory", "getContent", "getReadTimeMinutes", "getImageUrl", "toDomainModel", "Lcom/app/a1bat/domain/model/Article;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class ArticleEntity {
    public static final int $stable = 0;
    private final java.lang.String category;
    private final java.lang.String content;
    private final int id;
    private final java.lang.String imageUrl;
    private final int readTimeMinutes;
    private final java.lang.String title;

    public static /* synthetic */ com.app.a1bat.data.local.entity.ArticleEntity copy$default(com.app.a1bat.data.local.entity.ArticleEntity articleEntity, int i, java.lang.String str, java.lang.String str2, java.lang.String str3, int i2, java.lang.String str4, int i3, java.lang.Object obj) {
        if ((i3 & 1) != 0) {
            i = articleEntity.id;
        }
        if ((i3 & 2) != 0) {
            str = articleEntity.title;
        }
        if ((i3 & 4) != 0) {
            str2 = articleEntity.category;
        }
        if ((i3 & 8) != 0) {
            str3 = articleEntity.content;
        }
        if ((i3 & 16) != 0) {
            i2 = articleEntity.readTimeMinutes;
        }
        if ((i3 & 32) != 0) {
            str4 = articleEntity.imageUrl;
        }
        int i4 = i2;
        java.lang.String str5 = str4;
        return articleEntity.copy(i, str, str2, str3, i4, str5);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getTitle() {
        return this.title;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getCategory() {
        return this.category;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getContent() {
        return this.content;
    }

    /* renamed from: component5, reason: from getter */
    public final int getReadTimeMinutes() {
        return this.readTimeMinutes;
    }

    /* renamed from: component6, reason: from getter */
    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final com.app.a1bat.data.local.entity.ArticleEntity copy(int id, java.lang.String title, java.lang.String category, java.lang.String content, int readTimeMinutes, java.lang.String imageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(category, "category");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(content, "content");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        return new com.app.a1bat.data.local.entity.ArticleEntity(id, title, category, content, readTimeMinutes, imageUrl);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.data.local.entity.ArticleEntity)) {
            return false;
        }
        com.app.a1bat.data.local.entity.ArticleEntity articleEntity = (com.app.a1bat.data.local.entity.ArticleEntity) other;
        return this.id == articleEntity.id && kotlin.jvm.internal.Intrinsics.areEqual(this.title, articleEntity.title) && kotlin.jvm.internal.Intrinsics.areEqual(this.category, articleEntity.category) && kotlin.jvm.internal.Intrinsics.areEqual(this.content, articleEntity.content) && this.readTimeMinutes == articleEntity.readTimeMinutes && kotlin.jvm.internal.Intrinsics.areEqual(this.imageUrl, articleEntity.imageUrl);
    }

    public int hashCode() {
        return (((((((((java.lang.Integer.hashCode(this.id) * 31) + this.title.hashCode()) * 31) + this.category.hashCode()) * 31) + this.content.hashCode()) * 31) + java.lang.Integer.hashCode(this.readTimeMinutes)) * 31) + this.imageUrl.hashCode();
    }

    public java.lang.String toString() {
        return "ArticleEntity(id=" + this.id + ", title=" + this.title + ", category=" + this.category + ", content=" + this.content + ", readTimeMinutes=" + this.readTimeMinutes + ", imageUrl=" + this.imageUrl + ")";
    }

    public ArticleEntity(int i, java.lang.String title, java.lang.String category, java.lang.String content, int i2, java.lang.String imageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(category, "category");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(content, "content");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        this.id = i;
        this.title = title;
        this.category = category;
        this.content = content;
        this.readTimeMinutes = i2;
        this.imageUrl = imageUrl;
    }

    public final int getId() {
        return this.id;
    }

    public final java.lang.String getTitle() {
        return this.title;
    }

    public final java.lang.String getCategory() {
        return this.category;
    }

    public final java.lang.String getContent() {
        return this.content;
    }

    public final int getReadTimeMinutes() {
        return this.readTimeMinutes;
    }

    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final com.app.a1bat.domain.model.Article toDomainModel() {
        return new com.app.a1bat.domain.model.Article(this.id, this.title, this.category, this.content, this.readTimeMinutes, this.imageUrl);
    }
}
