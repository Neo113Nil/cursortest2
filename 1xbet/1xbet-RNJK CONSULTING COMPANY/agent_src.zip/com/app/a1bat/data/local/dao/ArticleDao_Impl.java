package com.app.a1bat.data.local.dao;

/* loaded from: classes3.dex */
public final class ArticleDao_Impl implements com.app.a1bat.data.local.dao.ArticleDao {
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ArticleEntity> __insertionAdapterOfArticleEntity;

    public ArticleDao_Impl(final androidx.room.RoomDatabase __db) {
        this.__db = __db;
        this.__insertionAdapterOfArticleEntity = new androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ArticleEntity>(__db) { // from class: com.app.a1bat.data.local.dao.ArticleDao_Impl.1
            @Override // androidx.room.SharedSQLiteStatement
            protected java.lang.String createQuery() {
                return "INSERT OR REPLACE INTO `articles` (`id`,`title`,`category`,`content`,`readTimeMinutes`,`imageUrl`) VALUES (?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertionAdapter
            public void bind(final androidx.sqlite.db.SupportSQLiteStatement statement, final com.app.a1bat.data.local.entity.ArticleEntity entity) {
                statement.bindLong(1, entity.getId());
                statement.bindString(2, entity.getTitle());
                statement.bindString(3, entity.getCategory());
                statement.bindString(4, entity.getContent());
                statement.bindLong(5, entity.getReadTimeMinutes());
                statement.bindString(6, entity.getImageUrl());
            }
        };
    }

    @Override // com.app.a1bat.data.local.dao.ArticleDao
    public java.lang.Object insertAll(final java.util.List<com.app.a1bat.data.local.entity.ArticleEntity> articles, final kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return androidx.room.CoroutinesRoom.execute(this.__db, true, new java.util.concurrent.Callable<kotlin.Unit>() { // from class: com.app.a1bat.data.local.dao.ArticleDao_Impl.2
            @Override // java.util.concurrent.Callable
            public kotlin.Unit call() throws java.lang.Exception {
                com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__db.beginTransaction();
                try {
                    com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__insertionAdapterOfArticleEntity.insert((java.lang.Iterable) articles);
                    com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__db.setTransactionSuccessful();
                    return kotlin.Unit.INSTANCE;
                } finally {
                    com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__db.endTransaction();
                }
            }
        }, $completion);
    }

    @Override // com.app.a1bat.data.local.dao.ArticleDao
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ArticleEntity>> getAllArticles() {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM articles", 0);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"articles"}, new java.util.concurrent.Callable<java.util.List<com.app.a1bat.data.local.entity.ArticleEntity>>() { // from class: com.app.a1bat.data.local.dao.ArticleDao_Impl.3
            @Override // java.util.concurrent.Callable
            public java.util.List<com.app.a1bat.data.local.entity.ArticleEntity> call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__db, acquire, false, null);
                try {
                    int columnIndexOrThrow = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id");
                    int columnIndexOrThrow2 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title);
                    int columnIndexOrThrow3 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "category");
                    int columnIndexOrThrow4 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "content");
                    int columnIndexOrThrow5 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "readTimeMinutes");
                    int columnIndexOrThrow6 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl");
                    java.util.ArrayList arrayList = new java.util.ArrayList(query.getCount());
                    while (query.moveToNext()) {
                        arrayList.add(new com.app.a1bat.data.local.entity.ArticleEntity(query.getInt(columnIndexOrThrow), query.getString(columnIndexOrThrow2), query.getString(columnIndexOrThrow3), query.getString(columnIndexOrThrow4), query.getInt(columnIndexOrThrow5), query.getString(columnIndexOrThrow6)));
                    }
                    return arrayList;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    @Override // com.app.a1bat.data.local.dao.ArticleDao
    public kotlinx.coroutines.flow.Flow<com.app.a1bat.data.local.entity.ArticleEntity> getArticleById(final int id) {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM articles WHERE id = ?", 1);
        acquire.bindLong(1, id);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"articles"}, new java.util.concurrent.Callable<com.app.a1bat.data.local.entity.ArticleEntity>() { // from class: com.app.a1bat.data.local.dao.ArticleDao_Impl.4
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // java.util.concurrent.Callable
            public com.app.a1bat.data.local.entity.ArticleEntity call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ArticleDao_Impl.this.__db, acquire, false, null);
                try {
                    return query.moveToFirst() ? new com.app.a1bat.data.local.entity.ArticleEntity(query.getInt(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title)), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "category")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "content")), query.getInt(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "readTimeMinutes")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl"))) : null;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    public static java.util.List<java.lang.Class<?>> getRequiredConverters() {
        return java.util.Collections.emptyList();
    }
}
