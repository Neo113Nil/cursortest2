package com.app.a1bat.data.local.dao;

/* compiled from: BookingDao.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0016\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\tJ\u0016\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fH§@¢\u0006\u0002\u0010\r¨\u0006\u000e"}, d2 = {"Lcom/app/a1bat/data/local/dao/BookingDao;", "", "getAllBookings", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/app/a1bat/data/local/entity/BookingEntity;", "insertBooking", "", "booking", "(Lcom/app/a1bat/data/local/entity/BookingEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteBooking", "bookingId", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface BookingDao {
    java.lang.Object deleteBooking(java.lang.String str, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.BookingEntity>> getAllBookings();

    java.lang.Object insertBooking(com.app.a1bat.data.local.entity.BookingEntity bookingEntity, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);
}
