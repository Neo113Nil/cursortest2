package com.app.a1bat.data.local.dao;

/* compiled from: ServiceDao.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u001c\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u00032\u0006\u0010\u0007\u001a\u00020\bH'J\u0018\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00032\u0006\u0010\n\u001a\u00020\u000bH'J\u001c\u0010\f\u001a\u00020\r2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H§@¢\u0006\u0002\u0010\u000f¨\u0006\u0010"}, d2 = {"Lcom/app/a1bat/data/local/dao/ServiceDao;", "", "getAllServices", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/app/a1bat/data/local/entity/ServiceEntity;", "getServicesByCategory", "category", "", "getServiceById", "id", "", "insertAll", "", "services", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface ServiceDao {
    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> getAllServices();

    kotlinx.coroutines.flow.Flow<com.app.a1bat.data.local.entity.ServiceEntity> getServiceById(int id);

    kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> getServicesByCategory(java.lang.String category);

    java.lang.Object insertAll(java.util.List<com.app.a1bat.data.local.entity.ServiceEntity> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);
}
