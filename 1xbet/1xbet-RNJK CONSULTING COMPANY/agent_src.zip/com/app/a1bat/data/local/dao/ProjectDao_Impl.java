package com.app.a1bat.data.local.dao;

/* loaded from: classes3.dex */
public final class ProjectDao_Impl implements com.app.a1bat.data.local.dao.ProjectDao {
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ProjectEntity> __insertionAdapterOfProjectEntity;

    public ProjectDao_Impl(final androidx.room.RoomDatabase __db) {
        this.__db = __db;
        this.__insertionAdapterOfProjectEntity = new androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ProjectEntity>(__db) { // from class: com.app.a1bat.data.local.dao.ProjectDao_Impl.1
            @Override // androidx.room.SharedSQLiteStatement
            protected java.lang.String createQuery() {
                return "INSERT OR REPLACE INTO `projects` (`id`,`title`,`industry`,`description`,`results`,`imageUrl`) VALUES (?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertionAdapter
            public void bind(final androidx.sqlite.db.SupportSQLiteStatement statement, final com.app.a1bat.data.local.entity.ProjectEntity entity) {
                statement.bindLong(1, entity.getId());
                statement.bindString(2, entity.getTitle());
                statement.bindString(3, entity.getIndustry());
                statement.bindString(4, entity.getDescription());
                statement.bindString(5, entity.getResults());
                statement.bindString(6, entity.getImageUrl());
            }
        };
    }

    @Override // com.app.a1bat.data.local.dao.ProjectDao
    public java.lang.Object insertAll(final java.util.List<com.app.a1bat.data.local.entity.ProjectEntity> projects, final kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return androidx.room.CoroutinesRoom.execute(this.__db, true, new java.util.concurrent.Callable<kotlin.Unit>() { // from class: com.app.a1bat.data.local.dao.ProjectDao_Impl.2
            @Override // java.util.concurrent.Callable
            public kotlin.Unit call() throws java.lang.Exception {
                com.app.a1bat.data.local.dao.ProjectDao_Impl.this.__db.beginTransaction();
                try {
                    com.app.a1bat.data.local.dao.ProjectDao_Impl.this.__insertionAdapterOfProjectEntity.insert((java.lang.Iterable) projects);
                    com.app.a1bat.data.local.dao.ProjectDao_Impl.this.__db.setTransactionSuccessful();
                    return kotlin.Unit.INSTANCE;
                } finally {
                    com.app.a1bat.data.local.dao.ProjectDao_Impl.this.__db.endTransaction();
                }
            }
        }, $completion);
    }

    @Override // com.app.a1bat.data.local.dao.ProjectDao
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ProjectEntity>> getAllProjects() {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM projects", 0);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"projects"}, new java.util.concurrent.Callable<java.util.List<com.app.a1bat.data.local.entity.ProjectEntity>>() { // from class: com.app.a1bat.data.local.dao.ProjectDao_Impl.3
            @Override // java.util.concurrent.Callable
            public java.util.List<com.app.a1bat.data.local.entity.ProjectEntity> call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ProjectDao_Impl.this.__db, acquire, false, null);
                try {
                    int columnIndexOrThrow = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id");
                    int columnIndexOrThrow2 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title);
                    int columnIndexOrThrow3 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "industry");
                    int columnIndexOrThrow4 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "description");
                    int columnIndexOrThrow5 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "results");
                    int columnIndexOrThrow6 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl");
                    java.util.ArrayList arrayList = new java.util.ArrayList(query.getCount());
                    while (query.moveToNext()) {
                        arrayList.add(new com.app.a1bat.data.local.entity.ProjectEntity(query.getInt(columnIndexOrThrow), query.getString(columnIndexOrThrow2), query.getString(columnIndexOrThrow3), query.getString(columnIndexOrThrow4), query.getString(columnIndexOrThrow5), query.getString(columnIndexOrThrow6)));
                    }
                    return arrayList;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    public static java.util.List<java.lang.Class<?>> getRequiredConverters() {
        return java.util.Collections.emptyList();
    }
}
