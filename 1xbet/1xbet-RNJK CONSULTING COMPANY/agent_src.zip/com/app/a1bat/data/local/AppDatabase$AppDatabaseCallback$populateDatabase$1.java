package com.app.a1bat.data.local;

/* compiled from: AppDatabase.kt */
@kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback", f = "AppDatabase.kt", i = {0, 0, 1}, l = {112, 132, 238}, m = "populateDatabase", n = {"projectDao", "articleDao", "articleDao"}, s = {"L$0", "L$1", "L$0"})
/* loaded from: classes3.dex */
final class AppDatabase$AppDatabaseCallback$populateDatabase$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    java.lang.Object L$0;
    java.lang.Object L$1;
    int label;
    /* synthetic */ java.lang.Object result;
    final /* synthetic */ com.app.a1bat.data.local.AppDatabase.AppDatabaseCallback this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppDatabase$AppDatabaseCallback$populateDatabase$1(com.app.a1bat.data.local.AppDatabase.AppDatabaseCallback appDatabaseCallback, kotlin.coroutines.Continuation<? super com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$populateDatabase$1> continuation) {
        super(continuation);
        this.this$0 = appDatabaseCallback;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.populateDatabase(null, this);
    }
}
