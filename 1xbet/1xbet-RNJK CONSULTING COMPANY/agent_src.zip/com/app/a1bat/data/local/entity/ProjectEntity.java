package com.app.a1bat.data.local.entity;

/* compiled from: ProjectEntity.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\n\u0010\u000bJ\u0006\u0010\u0014\u001a\u00020\u0015J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003JE\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020\u0003HÖ\u0001J\t\u0010!\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000f¨\u0006\""}, d2 = {"Lcom/app/a1bat/data/local/entity/ProjectEntity;", "", "id", "", io.ktor.http.LinkHeader.Parameters.Title, "", "industry", "description", "results", "imageUrl", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getId", "()I", "getTitle", "()Ljava/lang/String;", "getIndustry", "getDescription", "getResults", "getImageUrl", "toDomainModel", "Lcom/app/a1bat/domain/model/Project;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class ProjectEntity {
    public static final int $stable = 0;
    private final java.lang.String description;
    private final int id;
    private final java.lang.String imageUrl;
    private final java.lang.String industry;
    private final java.lang.String results;
    private final java.lang.String title;

    public static /* synthetic */ com.app.a1bat.data.local.entity.ProjectEntity copy$default(com.app.a1bat.data.local.entity.ProjectEntity projectEntity, int i, java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, java.lang.String str5, int i2, java.lang.Object obj) {
        if ((i2 & 1) != 0) {
            i = projectEntity.id;
        }
        if ((i2 & 2) != 0) {
            str = projectEntity.title;
        }
        if ((i2 & 4) != 0) {
            str2 = projectEntity.industry;
        }
        if ((i2 & 8) != 0) {
            str3 = projectEntity.description;
        }
        if ((i2 & 16) != 0) {
            str4 = projectEntity.results;
        }
        if ((i2 & 32) != 0) {
            str5 = projectEntity.imageUrl;
        }
        java.lang.String str6 = str4;
        java.lang.String str7 = str5;
        return projectEntity.copy(i, str, str2, str3, str6, str7);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getTitle() {
        return this.title;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getIndustry() {
        return this.industry;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getDescription() {
        return this.description;
    }

    /* renamed from: component5, reason: from getter */
    public final java.lang.String getResults() {
        return this.results;
    }

    /* renamed from: component6, reason: from getter */
    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final com.app.a1bat.data.local.entity.ProjectEntity copy(int id, java.lang.String title, java.lang.String industry, java.lang.String description, java.lang.String results, java.lang.String imageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(industry, "industry");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(results, "results");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        return new com.app.a1bat.data.local.entity.ProjectEntity(id, title, industry, description, results, imageUrl);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof com.app.a1bat.data.local.entity.ProjectEntity)) {
            return false;
        }
        com.app.a1bat.data.local.entity.ProjectEntity projectEntity = (com.app.a1bat.data.local.entity.ProjectEntity) other;
        return this.id == projectEntity.id && kotlin.jvm.internal.Intrinsics.areEqual(this.title, projectEntity.title) && kotlin.jvm.internal.Intrinsics.areEqual(this.industry, projectEntity.industry) && kotlin.jvm.internal.Intrinsics.areEqual(this.description, projectEntity.description) && kotlin.jvm.internal.Intrinsics.areEqual(this.results, projectEntity.results) && kotlin.jvm.internal.Intrinsics.areEqual(this.imageUrl, projectEntity.imageUrl);
    }

    public int hashCode() {
        return (((((((((java.lang.Integer.hashCode(this.id) * 31) + this.title.hashCode()) * 31) + this.industry.hashCode()) * 31) + this.description.hashCode()) * 31) + this.results.hashCode()) * 31) + this.imageUrl.hashCode();
    }

    public java.lang.String toString() {
        return "ProjectEntity(id=" + this.id + ", title=" + this.title + ", industry=" + this.industry + ", description=" + this.description + ", results=" + this.results + ", imageUrl=" + this.imageUrl + ")";
    }

    public ProjectEntity(int i, java.lang.String title, java.lang.String industry, java.lang.String description, java.lang.String results, java.lang.String imageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(title, "title");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(industry, "industry");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(results, "results");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        this.id = i;
        this.title = title;
        this.industry = industry;
        this.description = description;
        this.results = results;
        this.imageUrl = imageUrl;
    }

    public final int getId() {
        return this.id;
    }

    public final java.lang.String getTitle() {
        return this.title;
    }

    public final java.lang.String getIndustry() {
        return this.industry;
    }

    public final java.lang.String getDescription() {
        return this.description;
    }

    public final java.lang.String getResults() {
        return this.results;
    }

    public final java.lang.String getImageUrl() {
        return this.imageUrl;
    }

    public final com.app.a1bat.domain.model.Project toDomainModel() {
        return new com.app.a1bat.domain.model.Project(this.id, this.title, this.industry, this.description, this.results, this.imageUrl);
    }
}
