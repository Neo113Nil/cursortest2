package com.app.a1bat.data.local.preferences;

/* compiled from: AppPreferences.kt */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "preferences", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2", f = "AppPreferences.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class AppPreferences$setOnboardingCompleted$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ boolean $completed;
    /* synthetic */ java.lang.Object L$0;
    int label;
    final /* synthetic */ com.app.a1bat.data.local.preferences.AppPreferences this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    AppPreferences$setOnboardingCompleted$2(com.app.a1bat.data.local.preferences.AppPreferences appPreferences, boolean z, kotlin.coroutines.Continuation<? super com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2> continuation) {
        super(2, continuation);
        this.this$0 = appPreferences;
        this.$completed = z;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2 appPreferences$setOnboardingCompleted$2 = new com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2(this.this$0, this.$completed, continuation);
        appPreferences$setOnboardingCompleted$2.L$0 = obj;
        return appPreferences$setOnboardingCompleted$2;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(androidx.datastore.preferences.core.MutablePreferences mutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2) create(mutablePreferences, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        androidx.datastore.preferences.core.Preferences.Key key;
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.L$0;
            key = this.this$0.ONBOARDING_COMPLETED_KEY;
            mutablePreferences.set(key, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(this.$completed));
            return kotlin.Unit.INSTANCE;
        }
        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
