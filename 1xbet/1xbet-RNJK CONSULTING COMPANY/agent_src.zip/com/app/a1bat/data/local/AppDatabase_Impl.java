package com.app.a1bat.data.local;

/* loaded from: classes3.dex */
public final class AppDatabase_Impl extends com.app.a1bat.data.local.AppDatabase {
    private volatile com.app.a1bat.data.local.dao.ArticleDao _articleDao;
    private volatile com.app.a1bat.data.local.dao.BookingDao _bookingDao;
    private volatile com.app.a1bat.data.local.dao.ProjectDao _projectDao;
    private volatile com.app.a1bat.data.local.dao.ServiceDao _serviceDao;

    @Override // androidx.room.RoomDatabase
    protected androidx.sqlite.db.SupportSQLiteOpenHelper createOpenHelper(final androidx.room.DatabaseConfiguration config) {
        return config.sqliteOpenHelperFactory.create(androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(new androidx.room.RoomOpenHelper(config, new androidx.room.RoomOpenHelper.Delegate(1) { // from class: com.app.a1bat.data.local.AppDatabase_Impl.1
            @Override // androidx.room.RoomOpenHelper.Delegate
            public void onPostMigrate(final androidx.sqlite.db.SupportSQLiteDatabase db) {
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public void createAllTables(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `services` (`id` INTEGER NOT NULL, `title` TEXT NOT NULL, `shortDescription` TEXT NOT NULL, `fullDescription` TEXT NOT NULL, `startingPrice` REAL NOT NULL, `engagementType` TEXT NOT NULL, `category` TEXT NOT NULL, `imageUrl` TEXT NOT NULL, `whatsIncluded` TEXT NOT NULL, PRIMARY KEY(`id`))");
                db.execSQL("CREATE TABLE IF NOT EXISTS `bookings` (`id` TEXT NOT NULL, `serviceId` INTEGER NOT NULL, `serviceName` TEXT NOT NULL, `firstName` TEXT NOT NULL, `lastName` TEXT NOT NULL, `email` TEXT NOT NULL, `companyName` TEXT, `notes` TEXT, `timestamp` INTEGER NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`id`))");
                db.execSQL("CREATE TABLE IF NOT EXISTS `projects` (`id` INTEGER NOT NULL, `title` TEXT NOT NULL, `industry` TEXT NOT NULL, `description` TEXT NOT NULL, `results` TEXT NOT NULL, `imageUrl` TEXT NOT NULL, PRIMARY KEY(`id`))");
                db.execSQL("CREATE TABLE IF NOT EXISTS `articles` (`id` INTEGER NOT NULL, `title` TEXT NOT NULL, `category` TEXT NOT NULL, `content` TEXT NOT NULL, `readTimeMinutes` INTEGER NOT NULL, `imageUrl` TEXT NOT NULL, PRIMARY KEY(`id`))");
                db.execSQL(androidx.room.RoomMasterTable.CREATE_QUERY);
                db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '33125373652e41858fa0231d64332d1f')");
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public void dropAllTables(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                db.execSQL("DROP TABLE IF EXISTS `services`");
                db.execSQL("DROP TABLE IF EXISTS `bookings`");
                db.execSQL("DROP TABLE IF EXISTS `projects`");
                db.execSQL("DROP TABLE IF EXISTS `articles`");
                java.util.List list = com.app.a1bat.data.local.AppDatabase_Impl.this.mCallbacks;
                if (list != null) {
                    java.util.Iterator it = list.iterator();
                    while (it.hasNext()) {
                        ((androidx.room.RoomDatabase.Callback) it.next()).onDestructiveMigration(db);
                    }
                }
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public void onCreate(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                java.util.List list = com.app.a1bat.data.local.AppDatabase_Impl.this.mCallbacks;
                if (list != null) {
                    java.util.Iterator it = list.iterator();
                    while (it.hasNext()) {
                        ((androidx.room.RoomDatabase.Callback) it.next()).onCreate(db);
                    }
                }
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public void onOpen(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                com.app.a1bat.data.local.AppDatabase_Impl.this.mDatabase = db;
                com.app.a1bat.data.local.AppDatabase_Impl.this.internalInitInvalidationTracker(db);
                java.util.List list = com.app.a1bat.data.local.AppDatabase_Impl.this.mCallbacks;
                if (list != null) {
                    java.util.Iterator it = list.iterator();
                    while (it.hasNext()) {
                        ((androidx.room.RoomDatabase.Callback) it.next()).onOpen(db);
                    }
                }
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public void onPreMigrate(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                androidx.room.util.DBUtil.dropFtsSyncTriggers(db);
            }

            @Override // androidx.room.RoomOpenHelper.Delegate
            public androidx.room.RoomOpenHelper.ValidationResult onValidateSchema(final androidx.sqlite.db.SupportSQLiteDatabase db) {
                java.util.HashMap hashMap = new java.util.HashMap(9);
                hashMap.put("id", new androidx.room.util.TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                hashMap.put(io.ktor.http.LinkHeader.Parameters.Title, new androidx.room.util.TableInfo.Column(io.ktor.http.LinkHeader.Parameters.Title, "TEXT", true, 0, null, 1));
                hashMap.put("shortDescription", new androidx.room.util.TableInfo.Column("shortDescription", "TEXT", true, 0, null, 1));
                hashMap.put("fullDescription", new androidx.room.util.TableInfo.Column("fullDescription", "TEXT", true, 0, null, 1));
                hashMap.put("startingPrice", new androidx.room.util.TableInfo.Column("startingPrice", "REAL", true, 0, null, 1));
                hashMap.put("engagementType", new androidx.room.util.TableInfo.Column("engagementType", "TEXT", true, 0, null, 1));
                hashMap.put("category", new androidx.room.util.TableInfo.Column("category", "TEXT", true, 0, null, 1));
                hashMap.put("imageUrl", new androidx.room.util.TableInfo.Column("imageUrl", "TEXT", true, 0, null, 1));
                hashMap.put("whatsIncluded", new androidx.room.util.TableInfo.Column("whatsIncluded", "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo = new androidx.room.util.TableInfo("services", hashMap, new java.util.HashSet(0), new java.util.HashSet(0));
                androidx.room.util.TableInfo read = androidx.room.util.TableInfo.read(db, "services");
                if (!tableInfo.equals(read)) {
                    return new androidx.room.RoomOpenHelper.ValidationResult(false, "services(com.app.a1bat.data.local.entity.ServiceEntity).\n Expected:\n" + tableInfo + "\n Found:\n" + read);
                }
                java.util.HashMap hashMap2 = new java.util.HashMap(10);
                hashMap2.put("id", new androidx.room.util.TableInfo.Column("id", "TEXT", true, 1, null, 1));
                hashMap2.put("serviceId", new androidx.room.util.TableInfo.Column("serviceId", "INTEGER", true, 0, null, 1));
                hashMap2.put("serviceName", new androidx.room.util.TableInfo.Column("serviceName", "TEXT", true, 0, null, 1));
                hashMap2.put("firstName", new androidx.room.util.TableInfo.Column("firstName", "TEXT", true, 0, null, 1));
                hashMap2.put("lastName", new androidx.room.util.TableInfo.Column("lastName", "TEXT", true, 0, null, 1));
                hashMap2.put("email", new androidx.room.util.TableInfo.Column("email", "TEXT", true, 0, null, 1));
                hashMap2.put("companyName", new androidx.room.util.TableInfo.Column("companyName", "TEXT", false, 0, null, 1));
                hashMap2.put("notes", new androidx.room.util.TableInfo.Column("notes", "TEXT", false, 0, null, 1));
                hashMap2.put("timestamp", new androidx.room.util.TableInfo.Column("timestamp", "INTEGER", true, 0, null, 1));
                hashMap2.put(androidx.core.app.NotificationCompat.CATEGORY_STATUS, new androidx.room.util.TableInfo.Column(androidx.core.app.NotificationCompat.CATEGORY_STATUS, "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo2 = new androidx.room.util.TableInfo("bookings", hashMap2, new java.util.HashSet(0), new java.util.HashSet(0));
                androidx.room.util.TableInfo read2 = androidx.room.util.TableInfo.read(db, "bookings");
                if (!tableInfo2.equals(read2)) {
                    return new androidx.room.RoomOpenHelper.ValidationResult(false, "bookings(com.app.a1bat.data.local.entity.BookingEntity).\n Expected:\n" + tableInfo2 + "\n Found:\n" + read2);
                }
                java.util.HashMap hashMap3 = new java.util.HashMap(6);
                hashMap3.put("id", new androidx.room.util.TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                hashMap3.put(io.ktor.http.LinkHeader.Parameters.Title, new androidx.room.util.TableInfo.Column(io.ktor.http.LinkHeader.Parameters.Title, "TEXT", true, 0, null, 1));
                hashMap3.put("industry", new androidx.room.util.TableInfo.Column("industry", "TEXT", true, 0, null, 1));
                hashMap3.put("description", new androidx.room.util.TableInfo.Column("description", "TEXT", true, 0, null, 1));
                hashMap3.put("results", new androidx.room.util.TableInfo.Column("results", "TEXT", true, 0, null, 1));
                hashMap3.put("imageUrl", new androidx.room.util.TableInfo.Column("imageUrl", "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo3 = new androidx.room.util.TableInfo("projects", hashMap3, new java.util.HashSet(0), new java.util.HashSet(0));
                androidx.room.util.TableInfo read3 = androidx.room.util.TableInfo.read(db, "projects");
                if (!tableInfo3.equals(read3)) {
                    return new androidx.room.RoomOpenHelper.ValidationResult(false, "projects(com.app.a1bat.data.local.entity.ProjectEntity).\n Expected:\n" + tableInfo3 + "\n Found:\n" + read3);
                }
                java.util.HashMap hashMap4 = new java.util.HashMap(6);
                hashMap4.put("id", new androidx.room.util.TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                hashMap4.put(io.ktor.http.LinkHeader.Parameters.Title, new androidx.room.util.TableInfo.Column(io.ktor.http.LinkHeader.Parameters.Title, "TEXT", true, 0, null, 1));
                hashMap4.put("category", new androidx.room.util.TableInfo.Column("category", "TEXT", true, 0, null, 1));
                hashMap4.put("content", new androidx.room.util.TableInfo.Column("content", "TEXT", true, 0, null, 1));
                hashMap4.put("readTimeMinutes", new androidx.room.util.TableInfo.Column("readTimeMinutes", "INTEGER", true, 0, null, 1));
                hashMap4.put("imageUrl", new androidx.room.util.TableInfo.Column("imageUrl", "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo4 = new androidx.room.util.TableInfo("articles", hashMap4, new java.util.HashSet(0), new java.util.HashSet(0));
                androidx.room.util.TableInfo read4 = androidx.room.util.TableInfo.read(db, "articles");
                if (!tableInfo4.equals(read4)) {
                    return new androidx.room.RoomOpenHelper.ValidationResult(false, "articles(com.app.a1bat.data.local.entity.ArticleEntity).\n Expected:\n" + tableInfo4 + "\n Found:\n" + read4);
                }
                return new androidx.room.RoomOpenHelper.ValidationResult(true, null);
            }
        }, "33125373652e41858fa0231d64332d1f", "bcf44af062c87ed47894c744a62cbe0e")).build());
    }

    @Override // androidx.room.RoomDatabase
    protected androidx.room.InvalidationTracker createInvalidationTracker() {
        return new androidx.room.InvalidationTracker(this, new java.util.HashMap(0), new java.util.HashMap(0), "services", "bookings", "projects", "articles");
    }

    @Override // androidx.room.RoomDatabase
    public void clearAllTables() {
        super.assertNotMainThread();
        androidx.sqlite.db.SupportSQLiteDatabase writableDatabase = super.getOpenHelper().getWritableDatabase();
        try {
            super.beginTransaction();
            writableDatabase.execSQL("DELETE FROM `services`");
            writableDatabase.execSQL("DELETE FROM `bookings`");
            writableDatabase.execSQL("DELETE FROM `projects`");
            writableDatabase.execSQL("DELETE FROM `articles`");
            super.setTransactionSuccessful();
        } finally {
            super.endTransaction();
            writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close();
            if (!writableDatabase.inTransaction()) {
                writableDatabase.execSQL("VACUUM");
            }
        }
    }

    @Override // androidx.room.RoomDatabase
    protected java.util.Map<java.lang.Class<?>, java.util.List<java.lang.Class<?>>> getRequiredTypeConverters() {
        java.util.HashMap hashMap = new java.util.HashMap();
        hashMap.put(com.app.a1bat.data.local.dao.ServiceDao.class, com.app.a1bat.data.local.dao.ServiceDao_Impl.getRequiredConverters());
        hashMap.put(com.app.a1bat.data.local.dao.BookingDao.class, com.app.a1bat.data.local.dao.BookingDao_Impl.getRequiredConverters());
        hashMap.put(com.app.a1bat.data.local.dao.ProjectDao.class, com.app.a1bat.data.local.dao.ProjectDao_Impl.getRequiredConverters());
        hashMap.put(com.app.a1bat.data.local.dao.ArticleDao.class, com.app.a1bat.data.local.dao.ArticleDao_Impl.getRequiredConverters());
        return hashMap;
    }

    @Override // androidx.room.RoomDatabase
    public java.util.Set<java.lang.Class<? extends androidx.room.migration.AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
        return new java.util.HashSet();
    }

    @Override // androidx.room.RoomDatabase
    public java.util.List<androidx.room.migration.Migration> getAutoMigrations(final java.util.Map<java.lang.Class<? extends androidx.room.migration.AutoMigrationSpec>, androidx.room.migration.AutoMigrationSpec> autoMigrationSpecs) {
        return new java.util.ArrayList();
    }

    @Override // com.app.a1bat.data.local.AppDatabase
    public com.app.a1bat.data.local.dao.ServiceDao serviceDao() {
        com.app.a1bat.data.local.dao.ServiceDao serviceDao;
        if (this._serviceDao != null) {
            return this._serviceDao;
        }
        synchronized (this) {
            if (this._serviceDao == null) {
                this._serviceDao = new com.app.a1bat.data.local.dao.ServiceDao_Impl(this);
            }
            serviceDao = this._serviceDao;
        }
        return serviceDao;
    }

    @Override // com.app.a1bat.data.local.AppDatabase
    public com.app.a1bat.data.local.dao.BookingDao bookingDao() {
        com.app.a1bat.data.local.dao.BookingDao bookingDao;
        if (this._bookingDao != null) {
            return this._bookingDao;
        }
        synchronized (this) {
            if (this._bookingDao == null) {
                this._bookingDao = new com.app.a1bat.data.local.dao.BookingDao_Impl(this);
            }
            bookingDao = this._bookingDao;
        }
        return bookingDao;
    }

    @Override // com.app.a1bat.data.local.AppDatabase
    public com.app.a1bat.data.local.dao.ProjectDao projectDao() {
        com.app.a1bat.data.local.dao.ProjectDao projectDao;
        if (this._projectDao != null) {
            return this._projectDao;
        }
        synchronized (this) {
            if (this._projectDao == null) {
                this._projectDao = new com.app.a1bat.data.local.dao.ProjectDao_Impl(this);
            }
            projectDao = this._projectDao;
        }
        return projectDao;
    }

    @Override // com.app.a1bat.data.local.AppDatabase
    public com.app.a1bat.data.local.dao.ArticleDao articleDao() {
        com.app.a1bat.data.local.dao.ArticleDao articleDao;
        if (this._articleDao != null) {
            return this._articleDao;
        }
        synchronized (this) {
            if (this._articleDao == null) {
                this._articleDao = new com.app.a1bat.data.local.dao.ArticleDao_Impl(this);
            }
            articleDao = this._articleDao;
        }
        return articleDao;
    }
}
