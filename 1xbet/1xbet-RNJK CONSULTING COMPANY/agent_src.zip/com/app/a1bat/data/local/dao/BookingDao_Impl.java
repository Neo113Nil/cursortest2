package com.app.a1bat.data.local.dao;

/* loaded from: classes3.dex */
public final class BookingDao_Impl implements com.app.a1bat.data.local.dao.BookingDao {
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.BookingEntity> __insertionAdapterOfBookingEntity;
    private final androidx.room.SharedSQLiteStatement __preparedStmtOfDeleteBooking;

    public BookingDao_Impl(final androidx.room.RoomDatabase __db) {
        this.__db = __db;
        this.__insertionAdapterOfBookingEntity = new androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.BookingEntity>(__db) { // from class: com.app.a1bat.data.local.dao.BookingDao_Impl.1
            @Override // androidx.room.SharedSQLiteStatement
            protected java.lang.String createQuery() {
                return "INSERT OR REPLACE INTO `bookings` (`id`,`serviceId`,`serviceName`,`firstName`,`lastName`,`email`,`companyName`,`notes`,`timestamp`,`status`) VALUES (?,?,?,?,?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertionAdapter
            public void bind(final androidx.sqlite.db.SupportSQLiteStatement statement, final com.app.a1bat.data.local.entity.BookingEntity entity) {
                statement.bindString(1, entity.getId());
                statement.bindLong(2, entity.getServiceId());
                statement.bindString(3, entity.getServiceName());
                statement.bindString(4, entity.getFirstName());
                statement.bindString(5, entity.getLastName());
                statement.bindString(6, entity.getEmail());
                if (entity.getCompanyName() == null) {
                    statement.bindNull(7);
                } else {
                    statement.bindString(7, entity.getCompanyName());
                }
                if (entity.getNotes() == null) {
                    statement.bindNull(8);
                } else {
                    statement.bindString(8, entity.getNotes());
                }
                statement.bindLong(9, entity.getTimestamp());
                statement.bindString(10, entity.getStatus());
            }
        };
        this.__preparedStmtOfDeleteBooking = new androidx.room.SharedSQLiteStatement(__db) { // from class: com.app.a1bat.data.local.dao.BookingDao_Impl.2
            @Override // androidx.room.SharedSQLiteStatement
            public java.lang.String createQuery() {
                return "DELETE FROM bookings WHERE id = ?";
            }
        };
    }

    @Override // com.app.a1bat.data.local.dao.BookingDao
    public java.lang.Object insertBooking(final com.app.a1bat.data.local.entity.BookingEntity booking, final kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return androidx.room.CoroutinesRoom.execute(this.__db, true, new java.util.concurrent.Callable<kotlin.Unit>() { // from class: com.app.a1bat.data.local.dao.BookingDao_Impl.3
            @Override // java.util.concurrent.Callable
            public kotlin.Unit call() throws java.lang.Exception {
                com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.beginTransaction();
                try {
                    com.app.a1bat.data.local.dao.BookingDao_Impl.this.__insertionAdapterOfBookingEntity.insert((androidx.room.EntityInsertionAdapter) booking);
                    com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.setTransactionSuccessful();
                    return kotlin.Unit.INSTANCE;
                } finally {
                    com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.endTransaction();
                }
            }
        }, $completion);
    }

    @Override // com.app.a1bat.data.local.dao.BookingDao
    public java.lang.Object deleteBooking(final java.lang.String bookingId, final kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return androidx.room.CoroutinesRoom.execute(this.__db, true, new java.util.concurrent.Callable<kotlin.Unit>() { // from class: com.app.a1bat.data.local.dao.BookingDao_Impl.4
            @Override // java.util.concurrent.Callable
            public kotlin.Unit call() throws java.lang.Exception {
                androidx.sqlite.db.SupportSQLiteStatement acquire = com.app.a1bat.data.local.dao.BookingDao_Impl.this.__preparedStmtOfDeleteBooking.acquire();
                acquire.bindString(1, bookingId);
                try {
                    com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.beginTransaction();
                    try {
                        acquire.executeUpdateDelete();
                        com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.setTransactionSuccessful();
                        return kotlin.Unit.INSTANCE;
                    } finally {
                        com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db.endTransaction();
                    }
                } finally {
                    com.app.a1bat.data.local.dao.BookingDao_Impl.this.__preparedStmtOfDeleteBooking.release(acquire);
                }
            }
        }, $completion);
    }

    @Override // com.app.a1bat.data.local.dao.BookingDao
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.BookingEntity>> getAllBookings() {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM bookings ORDER BY timestamp DESC", 0);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"bookings"}, new java.util.concurrent.Callable<java.util.List<com.app.a1bat.data.local.entity.BookingEntity>>() { // from class: com.app.a1bat.data.local.dao.BookingDao_Impl.5
            @Override // java.util.concurrent.Callable
            public java.util.List<com.app.a1bat.data.local.entity.BookingEntity> call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.BookingDao_Impl.this.__db, acquire, false, null);
                try {
                    int columnIndexOrThrow = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id");
                    int columnIndexOrThrow2 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "serviceId");
                    int columnIndexOrThrow3 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "serviceName");
                    int columnIndexOrThrow4 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "firstName");
                    int columnIndexOrThrow5 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "lastName");
                    int columnIndexOrThrow6 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "email");
                    int columnIndexOrThrow7 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "companyName");
                    int columnIndexOrThrow8 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "notes");
                    int columnIndexOrThrow9 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "timestamp");
                    int columnIndexOrThrow10 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, androidx.core.app.NotificationCompat.CATEGORY_STATUS);
                    java.util.ArrayList arrayList = new java.util.ArrayList(query.getCount());
                    while (query.moveToNext()) {
                        arrayList.add(new com.app.a1bat.data.local.entity.BookingEntity(query.getString(columnIndexOrThrow), query.getInt(columnIndexOrThrow2), query.getString(columnIndexOrThrow3), query.getString(columnIndexOrThrow4), query.getString(columnIndexOrThrow5), query.getString(columnIndexOrThrow6), query.isNull(columnIndexOrThrow7) ? null : query.getString(columnIndexOrThrow7), query.isNull(columnIndexOrThrow8) ? null : query.getString(columnIndexOrThrow8), query.getLong(columnIndexOrThrow9), query.getString(columnIndexOrThrow10)));
                    }
                    return arrayList;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    public static java.util.List<java.lang.Class<?>> getRequiredConverters() {
        return java.util.Collections.emptyList();
    }
}
