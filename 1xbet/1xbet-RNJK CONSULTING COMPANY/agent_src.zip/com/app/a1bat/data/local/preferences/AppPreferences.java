package com.app.a1bat.data.local.preferences;

/* compiled from: AppPreferences.kt */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\bH\u0086@¢\u0006\u0002\u0010\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\n¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u000b¨\u0006\u0010"}, d2 = {"Lcom/app/a1bat/data/local/preferences/AppPreferences;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "ONBOARDING_COMPLETED_KEY", "Landroidx/datastore/preferences/core/Preferences$Key;", "", "isOnboardingCompleted", "Lkotlinx/coroutines/flow/Flow;", "()Lkotlinx/coroutines/flow/Flow;", "setOnboardingCompleted", "", "completed", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class AppPreferences {
    public static final int $stable = 8;
    private final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> ONBOARDING_COMPLETED_KEY;
    private final android.content.Context context;
    private final kotlinx.coroutines.flow.Flow<java.lang.Boolean> isOnboardingCompleted;

    public AppPreferences(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.ONBOARDING_COMPLETED_KEY = androidx.datastore.preferences.core.PreferencesKeys.booleanKey("onboarding_completed");
        final kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = com.app.a1bat.data.local.preferences.AppPreferencesKt.getDataStore(context).getData();
        this.isOnboardingCompleted = new kotlinx.coroutines.flow.Flow<java.lang.Boolean>() { // from class: com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;
                final /* synthetic */ com.app.a1bat.data.local.preferences.AppPreferences this$0;

                @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1$2", f = "AppPreferences.kt", i = {}, l = {50}, m = "emit", n = {}, s = {})
                /* renamed from: com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    java.lang.Object L$0;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector, com.app.a1bat.data.local.preferences.AppPreferences appPreferences) {
                    this.$this_unsafeFlow = flowCollector;
                    this.this$0 = appPreferences;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    int i;
                    androidx.datastore.preferences.core.Preferences.Key<T> key;
                    if (continuation instanceof com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            java.lang.Object obj2 = anonymousClass1.result;
                            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            i = anonymousClass1.label;
                            if (i != 0) {
                                kotlin.ResultKt.throwOnFailure(obj2);
                                kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                                key = this.this$0.ONBOARDING_COMPLETED_KEY;
                                java.lang.Boolean bool = (java.lang.Boolean) ((androidx.datastore.preferences.core.Preferences) obj).get(key);
                                java.lang.Boolean boxBoolean = kotlin.coroutines.jvm.internal.Boxing.boxBoolean(bool != null ? bool.booleanValue() : false);
                                anonymousClass1.label = 1;
                                if (flowCollector.emit(boxBoolean, anonymousClass1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            } else {
                                if (i != 1) {
                                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                kotlin.ResultKt.throwOnFailure(obj2);
                            }
                            return kotlin.Unit.INSTANCE;
                        }
                    }
                    anonymousClass1 = new com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                    java.lang.Object obj22 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = anonymousClass1.label;
                    if (i != 0) {
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.lang.Boolean> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object collect = kotlinx.coroutines.flow.Flow.this.collect(new com.app.a1bat.data.local.preferences.AppPreferences$special$$inlined$map$1.AnonymousClass2(flowCollector, this), continuation);
                return collect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : kotlin.Unit.INSTANCE;
            }
        };
    }

    public final kotlinx.coroutines.flow.Flow<java.lang.Boolean> isOnboardingCompleted() {
        return this.isOnboardingCompleted;
    }

    public final java.lang.Object setOnboardingCompleted(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object edit = androidx.datastore.preferences.core.PreferencesKt.edit(com.app.a1bat.data.local.preferences.AppPreferencesKt.getDataStore(this.context), new com.app.a1bat.data.local.preferences.AppPreferences$setOnboardingCompleted$2(this, z, null), continuation);
        return edit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? edit : kotlin.Unit.INSTANCE;
    }
}
