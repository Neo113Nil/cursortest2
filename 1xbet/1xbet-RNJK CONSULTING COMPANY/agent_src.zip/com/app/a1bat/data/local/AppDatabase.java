package com.app.a1bat.data.local;

/* compiled from: AppDatabase.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u0000 \f2\u00020\u0001:\u0002\f\rB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0007H&J\b\u0010\b\u001a\u00020\tH&J\b\u0010\n\u001a\u00020\u000bH&¨\u0006\u000e"}, d2 = {"Lcom/app/a1bat/data/local/AppDatabase;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "serviceDao", "Lcom/app/a1bat/data/local/dao/ServiceDao;", "bookingDao", "Lcom/app/a1bat/data/local/dao/BookingDao;", "projectDao", "Lcom/app/a1bat/data/local/dao/ProjectDao;", "articleDao", "Lcom/app/a1bat/data/local/dao/ArticleDao;", "Companion", "AppDatabaseCallback", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public abstract class AppDatabase extends androidx.room.RoomDatabase {
    public static final int $stable = 0;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final com.app.a1bat.data.local.AppDatabase.Companion INSTANCE = new com.app.a1bat.data.local.AppDatabase.Companion(null);
    private static volatile com.app.a1bat.data.local.AppDatabase INSTANCE;

    public abstract com.app.a1bat.data.local.dao.ArticleDao articleDao();

    public abstract com.app.a1bat.data.local.dao.BookingDao bookingDao();

    public abstract com.app.a1bat.data.local.dao.ProjectDao projectDao();

    public abstract com.app.a1bat.data.local.dao.ServiceDao serviceDao();

    /* compiled from: AppDatabase.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lcom/app/a1bat/data/local/AppDatabase$Companion;", "", "<init>", "()V", "INSTANCE", "Lcom/app/a1bat/data/local/AppDatabase;", "getDatabase", "context", "Landroid/content/Context;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final com.app.a1bat.data.local.AppDatabase getDatabase(android.content.Context context) {
            com.app.a1bat.data.local.AppDatabase appDatabase;
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
            com.app.a1bat.data.local.AppDatabase appDatabase2 = com.app.a1bat.data.local.AppDatabase.INSTANCE;
            if (appDatabase2 != null) {
                return appDatabase2;
            }
            synchronized (this) {
                android.content.Context applicationContext = context.getApplicationContext();
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                appDatabase = (com.app.a1bat.data.local.AppDatabase) androidx.room.Room.databaseBuilder(applicationContext, com.app.a1bat.data.local.AppDatabase.class, "bat_database").addCallback(new com.app.a1bat.data.local.AppDatabase.AppDatabaseCallback()).build();
                com.app.a1bat.data.local.AppDatabase.Companion companion = com.app.a1bat.data.local.AppDatabase.INSTANCE;
                com.app.a1bat.data.local.AppDatabase.INSTANCE = appDatabase;
            }
            return appDatabase;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: AppDatabase.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0016\u0010\b\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\tH\u0086@¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"Lcom/app/a1bat/data/local/AppDatabase$AppDatabaseCallback;", "Landroidx/room/RoomDatabase$Callback;", "<init>", "()V", "onCreate", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "populateDatabase", "Lcom/app/a1bat/data/local/AppDatabase;", "(Lcom/app/a1bat/data/local/AppDatabase;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    static final class AppDatabaseCallback extends androidx.room.RoomDatabase.Callback {
        @Override // androidx.room.RoomDatabase.Callback
        public void onCreate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(db, "db");
            super.onCreate(db);
            com.app.a1bat.data.local.AppDatabase appDatabase = com.app.a1bat.data.local.AppDatabase.INSTANCE;
            if (appDatabase != null) {
                kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(kotlinx.coroutines.CoroutineScopeKt.CoroutineScope(kotlinx.coroutines.Dispatchers.getIO()), null, null, new com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$onCreate$1$1(this, appDatabase, null), 3, null);
            }
        }

        /* JADX WARN: Code restructure failed: missing block: B:19:0x0162, code lost:
        
            if (r4.insertAll(r0, r1) == r3) goto L26;
         */
        /* JADX WARN: Code restructure failed: missing block: B:20:0x0164, code lost:
        
            return r3;
         */
        /* JADX WARN: Code restructure failed: missing block: B:23:0x011c, code lost:
        
            if (r10.insertAll(r0, r1) != r3) goto L24;
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x00e4, code lost:
        
            if (r0.insertAll(r11, r1) == r3) goto L26;
         */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0057  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x002e  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object populateDatabase(com.app.a1bat.data.local.AppDatabase appDatabase, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$populateDatabase$1 appDatabase$AppDatabaseCallback$populateDatabase$1;
            int i;
            com.app.a1bat.data.local.dao.ProjectDao projectDao;
            com.app.a1bat.data.local.dao.ArticleDao articleDao;
            if (continuation instanceof com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$populateDatabase$1) {
                appDatabase$AppDatabaseCallback$populateDatabase$1 = (com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$populateDatabase$1) continuation;
                if ((appDatabase$AppDatabaseCallback$populateDatabase$1.label & Integer.MIN_VALUE) != 0) {
                    appDatabase$AppDatabaseCallback$populateDatabase$1.label -= Integer.MIN_VALUE;
                    java.lang.Object obj = appDatabase$AppDatabaseCallback$populateDatabase$1.result;
                    java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    i = appDatabase$AppDatabaseCallback$populateDatabase$1.label;
                    if (i != 0) {
                        kotlin.ResultKt.throwOnFailure(obj);
                        com.app.a1bat.data.local.dao.ServiceDao serviceDao = appDatabase.serviceDao();
                        projectDao = appDatabase.projectDao();
                        articleDao = appDatabase.articleDao();
                        java.util.List<com.app.a1bat.data.local.entity.ServiceEntity> listOf = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.data.local.entity.ServiceEntity[]{new com.app.a1bat.data.local.entity.ServiceEntity(1, "Strategic Audit", "Comprehensive analysis of your organisation's strategic position", "Comprehensive analysis of your organisation's strategic position, competitive landscape, and internal capabilities. We produce an honest, data-driven report with prioritised recommendations for sustainable growth.", 4500.0d, "Per engagement", "Strategic Audit", "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80", "Senior partners with 15+ years industry experience|Flexible engagement: project-based or retainer model|Structured deliverables with executive-level reporting|Dedicated 1 Bat partner throughout the engagement|ISO 9001 certified quality management processes"), new com.app.a1bat.data.local.entity.ServiceEntity(2, "Business Process Optimisation", "End-to-end mapping and redesign of core business workflows.", "End-to-end mapping and redesign of core business workflows. We identify bottlenecks and implement lean methodologies to significantly increase operational efficiency.", 3800.0d, "Per project", "Business Process Optimization", "https://decisioninc.com/wp-content/uploads/2023/04/hands-with-support-gtears-isolated-white-background.jpg", "Process mapping and bottleneck identification|Lean methodology implementation|Technology stack audit|Change management strategy|Performance metrics definition"), new com.app.a1bat.data.local.entity.ServiceEntity(3, "Management Development", "Structured programmes to accelerate leadership capabilities.", "Structured programmes to accelerate leadership capabilities. We provide one-on-one coaching and executive training to build resilient management teams.", 2500.0d, "Per month", "Management Development", "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80", "Executive coaching sessions|Leadership capability assessment|Team dynamics workshops|Strategic decision-making frameworks|Performance review strategies"), new com.app.a1bat.data.local.entity.ServiceEntity(4, "Corporate Leadership", "Advisory services for board members and C-suite executives.", "Advisory services for board members and C-suite executives. We help align corporate governance with long-term strategic objectives and stakeholder expectations.", 6000.0d, "Retainer", "Corporate Leadership", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80", "Board advisory services|Corporate governance review|Stakeholder management strategy|Succession planning|Crisis management preparedness")});
                        appDatabase$AppDatabaseCallback$populateDatabase$1.L$0 = projectDao;
                        appDatabase$AppDatabaseCallback$populateDatabase$1.L$1 = articleDao;
                        appDatabase$AppDatabaseCallback$populateDatabase$1.label = 1;
                    } else if (i == 1) {
                        articleDao = (com.app.a1bat.data.local.dao.ArticleDao) appDatabase$AppDatabaseCallback$populateDatabase$1.L$1;
                        projectDao = (com.app.a1bat.data.local.dao.ProjectDao) appDatabase$AppDatabaseCallback$populateDatabase$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                    } else {
                        if (i != 2) {
                            if (i != 3) {
                                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            kotlin.ResultKt.throwOnFailure(obj);
                            return kotlin.Unit.INSTANCE;
                        }
                        articleDao = (com.app.a1bat.data.local.dao.ArticleDao) appDatabase$AppDatabaseCallback$populateDatabase$1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj);
                        java.util.List<com.app.a1bat.data.local.entity.ArticleEntity> listOf2 = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.data.local.entity.ArticleEntity[]{new com.app.a1bat.data.local.entity.ArticleEntity(1, "Navigating Uncertainty: Strategic Management in 2026", "Strategic Management", "In today's fast-paced environment, agility is no longer a buzzword — it is the foundation of sustainable competitive advantage. Organizations that thrive in 2026 are those that have mastered the art of strategic flexibility without sacrificing long-term direction.\n\nThe Paradox of Planning\n\nTraditional five-year plans are becoming increasingly obsolete. Markets shift in quarters, not decades. Consumer preferences evolve overnight, and geopolitical events can reshape entire industries within weeks. Yet abandoning structured planning altogether is equally dangerous.\n\nThe solution lies in what leading strategists call \"dynamic planning\" — a framework that combines clear long-term vision with adaptive short-term execution. Think of it as a compass rather than a map: you always know where north is, but your path can change with the terrain.\n\nThree Pillars of Strategic Agility\n\n1. Scenario Intelligence. Rather than predicting a single future, high-performing organizations develop multiple plausible scenarios. For each scenario, they pre-define strategic responses. When reality resembles one of these scenarios, execution is immediate rather than reactive.\n\n2. Decision Velocity. The speed at which an organization can make quality decisions is increasingly a competitive differentiator. This requires pushing decision authority closer to where information exists — front-line managers and specialized teams. Centralized, committee-based decision-making slows organizations to the pace of their bureaucracy.\n\n3. Resource Fluidity. Capital, talent, and attention must flow toward the highest-value opportunities rapidly. Organizations that maintain rigid budget cycles and department-siloed resources struggle to respond when conditions shift.\n\nImplementing Strategic Agility\n\nStart with a strategic audit of your current decision-making processes. Identify the three to five decisions in the past 12 months where slow or poor choices cost the organization measurably. Map the process that led to each decision. You will find patterns: missing data, unclear ownership, excessive approval layers, or cultural risk aversion.\n\nThe most impactful immediate step is establishing a strategic review cadence — monthly at the executive level, weekly at the operational level. These reviews should not be status reports. They should be active evaluations: Has our environment changed? Do our assumptions still hold? What must we adjust?\n\nLooking Forward\n\nOrganizations that embed strategic agility into their culture — not just their processes — will define their industries in the years ahead. The goal is not to move fast and break things, but to move thoughtfully and adapt decisively. In a world of increasing uncertainty, that is the only durable competitive advantage.", 5, "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80"), new com.app.a1bat.data.local.entity.ArticleEntity(2, "The ROI of Leadership Development", "Leadership Development", "Investing in your management team yields compound returns. The challenge has always been measurement — how do you put a number on better decisions, stronger team cohesion, and improved strategic thinking? This article lays out a practical framework for quantifying leadership development ROI.\n\nWhy Leadership Development Often Fails\n\nMost organizations invest in leadership training — workshops, executive coaching, 360-degree feedback programs. Yet study after study shows that 70% of training programs fail to produce measurable behavioral change. The reasons are predictable: training is disconnected from real work, there is no follow-through mechanism, and line managers do not reinforce new behaviors.\n\nThe ROI Framework\n\nMeasuring leadership development requires looking at three distinct levels of return.\n\nLevel 1 — Direct Performance Impact. The most immediate returns appear in team performance metrics. Leaders who develop better coaching skills typically see 15-25% improvements in their team's productivity within six months. Measure this by tracking output per person before and after leadership interventions within specific teams.\n\nLevel 2 — Retention and Talent Cost. Poor leadership is the primary driver of voluntary turnover. The average cost of replacing a skilled employee is 1.5 to 2 times their annual salary when you account for recruitment, onboarding, and productivity ramp-up. Organizations with strong leadership development programs report 30-40% lower voluntary turnover rates among high performers.\n\nLevel 3 — Strategic Decision Quality. This is the hardest to measure but often the most valuable. Better leaders make better decisions, particularly under uncertainty and in novel situations. Proxy measures include: speed to market for new initiatives, success rate of strategic projects, and the ratio of proactive to reactive management interventions.\n\nA Practical Starting Point\n\nBefore investing in leadership development, establish your baseline metrics across all three levels. Conduct a leadership effectiveness survey — not a 360 that gathers dust, but a focused assessment tied to specific business outcomes your leaders are responsible for.\n\nDesign interventions that address identified gaps with real business problems as the learning vehicle. The best leadership development happens through solving actual challenges, not simulated case studies.\n\nBuild in structured reflection and peer accountability mechanisms. Leaders who discuss their development goals with peers and have explicit accountability check-ins are three times more likely to sustain behavioral change than those who attend training alone.\n\nThe Compound Effect\n\nLike financial investment, leadership development compounds. A manager who improves their coaching effectiveness develops stronger team members who, over time, become stronger leaders themselves. The organizations that take this long view — investing consistently in leadership quality rather than in one-off training events — build a durable talent advantage that is extraordinarily difficult for competitors to replicate.", 4, "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=800&q=80"), new com.app.a1bat.data.local.entity.ArticleEntity(3, "Lean Operations: Beyond the Buzzword", "Operational Excellence", "Lean operations has been a management philosophy for decades, yet most implementations fail to deliver lasting results. Organizations embrace the terminology, run improvement workshops, and post value stream maps on conference room walls — then return to their old habits within months. Here is how to implement lean meaningfully.\n\nThe Core Misunderstanding\n\nLean is not a set of tools. It is a management system built on a foundational belief: the people closest to the work know best how to improve it. When organizations implement lean as a top-down efficiency drive — using it to cut headcount or impose standardization — they violate this principle and guarantee failure.\n\nTrue lean creates an environment where every person, at every level, is continuously looking for ways to deliver more value with less waste. This requires psychological safety, clear problem-solving frameworks, and managers who coach rather than direct.\n\nIdentifying Your Actual Waste\n\nMost operational waste is invisible because it is normalized. In manufacturing environments, the seven classic wastes (transportation, inventory, motion, waiting, overproduction, over-processing, defects) are relatively straightforward to observe. In knowledge work and service environments, waste takes subtler forms.\n\nConduct a \"day in the life\" observation across your key workflows. Have leaders spend a full day following a transaction, a customer request, or a service delivery from end to end. You will find handoffs where information is lost and re-created, approval steps that add no value, rework cycles driven by unclear requirements, and waiting time that dramatically extends cycle time without adding customer value.\n\nIn our experience working across industries, knowledge-work processes typically contain 60-80% non-value-added time. This is not because people are lazy — it is because systems were not designed with flow in mind.\n\nImplementation Steps That Actually Work\n\nStart small and visible. Choose a single process that is important, painful, and bounded. A customer onboarding journey, an invoice approval cycle, a product development handoff. Map the current state in detail, measure cycle time and defect rates, then redesign with a cross-functional team.\n\nImplement daily management systems before large-scale process changes. Visual management boards, daily stand-up meetings focused on problems rather than status, and clear escalation paths for when processes break down — these create the management infrastructure that sustains improvement.\n\nBuild problem-solving capability broadly. Teach structured problem-solving (A3 thinking, 5 Whys, root cause analysis) to team leaders and frontline supervisors. The goal is an organization where problems are solved quickly at the lowest appropriate level, rather than escalating indefinitely.\n\nMeasure what matters to customers. Lean implementations often over-index on internal efficiency metrics. Ground your measurement in customer-visible outcomes: delivery reliability, quality at point of receipt, response time to requests. Internal efficiency improvements that do not improve these outcomes are solving the wrong problems.\n\nSustaining the Gains\n\nThe most common lean failure mode is the \"improvement event\" approach — intense bursts of activity that produce initial results, then fade. Sustained operational excellence requires ongoing management attention, regular measurement reviews, and a leadership team that models the behaviors they want to see: going to the gemba (the place where work happens), asking questions rather than giving answers, and treating problems as learning opportunities rather than failures to be blamed.", 6, "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80")});
                        appDatabase$AppDatabaseCallback$populateDatabase$1.L$0 = null;
                        appDatabase$AppDatabaseCallback$populateDatabase$1.label = 3;
                    }
                    java.util.List<com.app.a1bat.data.local.entity.ProjectEntity> listOf3 = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.data.local.entity.ProjectEntity[]{new com.app.a1bat.data.local.entity.ProjectEntity(1, "Global Supply Chain Overhaul", "Manufacturing", "Restructured the entire supply chain network for a multinational manufacturer.", "Reduced logistics costs by 18% and improved delivery times by 25%.", "https://scw-mag.com/wp-content/uploads/sites/7/2023/05/AI-supply-chain-tool-800x445.jpg"), new com.app.a1bat.data.local.entity.ProjectEntity(2, "Digital Transformation Strategy", "Financial Services", "Guided a legacy bank through a comprehensive digital pivot.", "Increased mobile banking adoption by 40% in first year.", "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80")});
                    appDatabase$AppDatabaseCallback$populateDatabase$1.L$0 = articleDao;
                    appDatabase$AppDatabaseCallback$populateDatabase$1.L$1 = null;
                    appDatabase$AppDatabaseCallback$populateDatabase$1.label = 2;
                }
            }
            appDatabase$AppDatabaseCallback$populateDatabase$1 = new com.app.a1bat.data.local.AppDatabase$AppDatabaseCallback$populateDatabase$1(this, continuation);
            java.lang.Object obj2 = appDatabase$AppDatabaseCallback$populateDatabase$1.result;
            java.lang.Object coroutine_suspended2 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            i = appDatabase$AppDatabaseCallback$populateDatabase$1.label;
            if (i != 0) {
            }
            java.util.List<com.app.a1bat.data.local.entity.ProjectEntity> listOf32 = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new com.app.a1bat.data.local.entity.ProjectEntity[]{new com.app.a1bat.data.local.entity.ProjectEntity(1, "Global Supply Chain Overhaul", "Manufacturing", "Restructured the entire supply chain network for a multinational manufacturer.", "Reduced logistics costs by 18% and improved delivery times by 25%.", "https://scw-mag.com/wp-content/uploads/sites/7/2023/05/AI-supply-chain-tool-800x445.jpg"), new com.app.a1bat.data.local.entity.ProjectEntity(2, "Digital Transformation Strategy", "Financial Services", "Guided a legacy bank through a comprehensive digital pivot.", "Increased mobile banking adoption by 40% in first year.", "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80")});
            appDatabase$AppDatabaseCallback$populateDatabase$1.L$0 = articleDao;
            appDatabase$AppDatabaseCallback$populateDatabase$1.L$1 = null;
            appDatabase$AppDatabaseCallback$populateDatabase$1.label = 2;
        }
    }
}
