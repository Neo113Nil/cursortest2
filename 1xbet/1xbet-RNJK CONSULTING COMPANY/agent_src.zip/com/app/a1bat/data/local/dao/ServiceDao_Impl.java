package com.app.a1bat.data.local.dao;

/* loaded from: classes3.dex */
public final class ServiceDao_Impl implements com.app.a1bat.data.local.dao.ServiceDao {
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ServiceEntity> __insertionAdapterOfServiceEntity;

    public ServiceDao_Impl(final androidx.room.RoomDatabase __db) {
        this.__db = __db;
        this.__insertionAdapterOfServiceEntity = new androidx.room.EntityInsertionAdapter<com.app.a1bat.data.local.entity.ServiceEntity>(__db) { // from class: com.app.a1bat.data.local.dao.ServiceDao_Impl.1
            @Override // androidx.room.SharedSQLiteStatement
            protected java.lang.String createQuery() {
                return "INSERT OR REPLACE INTO `services` (`id`,`title`,`shortDescription`,`fullDescription`,`startingPrice`,`engagementType`,`category`,`imageUrl`,`whatsIncluded`) VALUES (?,?,?,?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertionAdapter
            public void bind(final androidx.sqlite.db.SupportSQLiteStatement statement, final com.app.a1bat.data.local.entity.ServiceEntity entity) {
                statement.bindLong(1, entity.getId());
                statement.bindString(2, entity.getTitle());
                statement.bindString(3, entity.getShortDescription());
                statement.bindString(4, entity.getFullDescription());
                statement.bindDouble(5, entity.getStartingPrice());
                statement.bindString(6, entity.getEngagementType());
                statement.bindString(7, entity.getCategory());
                statement.bindString(8, entity.getImageUrl());
                statement.bindString(9, entity.getWhatsIncluded());
            }
        };
    }

    @Override // com.app.a1bat.data.local.dao.ServiceDao
    public java.lang.Object insertAll(final java.util.List<com.app.a1bat.data.local.entity.ServiceEntity> services, final kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return androidx.room.CoroutinesRoom.execute(this.__db, true, new java.util.concurrent.Callable<kotlin.Unit>() { // from class: com.app.a1bat.data.local.dao.ServiceDao_Impl.2
            @Override // java.util.concurrent.Callable
            public kotlin.Unit call() throws java.lang.Exception {
                com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db.beginTransaction();
                try {
                    com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__insertionAdapterOfServiceEntity.insert((java.lang.Iterable) services);
                    com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db.setTransactionSuccessful();
                    return kotlin.Unit.INSTANCE;
                } finally {
                    com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db.endTransaction();
                }
            }
        }, $completion);
    }

    @Override // com.app.a1bat.data.local.dao.ServiceDao
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> getAllServices() {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM services", 0);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"services"}, new java.util.concurrent.Callable<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>>() { // from class: com.app.a1bat.data.local.dao.ServiceDao_Impl.3
            @Override // java.util.concurrent.Callable
            public java.util.List<com.app.a1bat.data.local.entity.ServiceEntity> call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db, acquire, false, null);
                try {
                    int columnIndexOrThrow = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id");
                    int columnIndexOrThrow2 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title);
                    int columnIndexOrThrow3 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "shortDescription");
                    int columnIndexOrThrow4 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "fullDescription");
                    int columnIndexOrThrow5 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "startingPrice");
                    int columnIndexOrThrow6 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "engagementType");
                    int columnIndexOrThrow7 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "category");
                    int columnIndexOrThrow8 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl");
                    int columnIndexOrThrow9 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "whatsIncluded");
                    java.util.ArrayList arrayList = new java.util.ArrayList(query.getCount());
                    while (query.moveToNext()) {
                        arrayList.add(new com.app.a1bat.data.local.entity.ServiceEntity(query.getInt(columnIndexOrThrow), query.getString(columnIndexOrThrow2), query.getString(columnIndexOrThrow3), query.getString(columnIndexOrThrow4), query.getDouble(columnIndexOrThrow5), query.getString(columnIndexOrThrow6), query.getString(columnIndexOrThrow7), query.getString(columnIndexOrThrow8), query.getString(columnIndexOrThrow9)));
                    }
                    return arrayList;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    @Override // com.app.a1bat.data.local.dao.ServiceDao
    public kotlinx.coroutines.flow.Flow<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>> getServicesByCategory(final java.lang.String category) {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM services WHERE category = ?", 1);
        acquire.bindString(1, category);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"services"}, new java.util.concurrent.Callable<java.util.List<com.app.a1bat.data.local.entity.ServiceEntity>>() { // from class: com.app.a1bat.data.local.dao.ServiceDao_Impl.4
            @Override // java.util.concurrent.Callable
            public java.util.List<com.app.a1bat.data.local.entity.ServiceEntity> call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db, acquire, false, null);
                try {
                    int columnIndexOrThrow = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id");
                    int columnIndexOrThrow2 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title);
                    int columnIndexOrThrow3 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "shortDescription");
                    int columnIndexOrThrow4 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "fullDescription");
                    int columnIndexOrThrow5 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "startingPrice");
                    int columnIndexOrThrow6 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "engagementType");
                    int columnIndexOrThrow7 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "category");
                    int columnIndexOrThrow8 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl");
                    int columnIndexOrThrow9 = androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "whatsIncluded");
                    java.util.ArrayList arrayList = new java.util.ArrayList(query.getCount());
                    while (query.moveToNext()) {
                        arrayList.add(new com.app.a1bat.data.local.entity.ServiceEntity(query.getInt(columnIndexOrThrow), query.getString(columnIndexOrThrow2), query.getString(columnIndexOrThrow3), query.getString(columnIndexOrThrow4), query.getDouble(columnIndexOrThrow5), query.getString(columnIndexOrThrow6), query.getString(columnIndexOrThrow7), query.getString(columnIndexOrThrow8), query.getString(columnIndexOrThrow9)));
                    }
                    return arrayList;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    @Override // com.app.a1bat.data.local.dao.ServiceDao
    public kotlinx.coroutines.flow.Flow<com.app.a1bat.data.local.entity.ServiceEntity> getServiceById(final int id) {
        final androidx.room.RoomSQLiteQuery acquire = androidx.room.RoomSQLiteQuery.acquire("SELECT * FROM services WHERE id = ?", 1);
        acquire.bindLong(1, id);
        return androidx.room.CoroutinesRoom.createFlow(this.__db, false, new java.lang.String[]{"services"}, new java.util.concurrent.Callable<com.app.a1bat.data.local.entity.ServiceEntity>() { // from class: com.app.a1bat.data.local.dao.ServiceDao_Impl.5
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // java.util.concurrent.Callable
            public com.app.a1bat.data.local.entity.ServiceEntity call() throws java.lang.Exception {
                android.database.Cursor query = androidx.room.util.DBUtil.query(com.app.a1bat.data.local.dao.ServiceDao_Impl.this.__db, acquire, false, null);
                try {
                    return query.moveToFirst() ? new com.app.a1bat.data.local.entity.ServiceEntity(query.getInt(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "id")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, io.ktor.http.LinkHeader.Parameters.Title)), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "shortDescription")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "fullDescription")), query.getDouble(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "startingPrice")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "engagementType")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "category")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "imageUrl")), query.getString(androidx.room.util.CursorUtil.getColumnIndexOrThrow(query, "whatsIncluded"))) : null;
                } finally {
                    query.close();
                }
            }

            protected void finalize() {
                acquire.release();
            }
        });
    }

    public static java.util.List<java.lang.Class<?>> getRequiredConverters() {
        return java.util.Collections.emptyList();
    }
}
