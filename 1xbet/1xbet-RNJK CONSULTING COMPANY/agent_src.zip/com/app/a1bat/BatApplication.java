package com.app.a1bat;

/* compiled from: BatApplication.kt */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"Lcom/app/a1bat/BatApplication;", "Landroid/app/Application;", "<init>", "()V", "onCreate", "", "app_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public class BatApplication extends android.app.Application {
    public static final int $stable = 0;

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        com.app.a1bat.network.NetworkMonitorKt.setAppContext(this);
        org.koin.core.context.DefaultContextExtKt.startKoin((kotlin.jvm.functions.Function1<? super org.koin.core.KoinApplication, kotlin.Unit>) new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.BatApplication$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                kotlin.Unit onCreate$lambda$0;
                onCreate$lambda$0 = com.app.a1bat.BatApplication.onCreate$lambda$0(com.app.a1bat.BatApplication.this, (org.koin.core.KoinApplication) obj);
                return onCreate$lambda$0;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit onCreate$lambda$0(com.app.a1bat.BatApplication batApplication, org.koin.core.KoinApplication startKoin) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(startKoin, "$this$startKoin");
        org.koin.android.ext.koin.KoinExtKt.androidLogger$default(startKoin, null, 1, null);
        org.koin.android.ext.koin.KoinExtKt.androidContext(startKoin, batApplication);
        startKoin.modules(com.app.a1bat.di.AppModuleKt.getAppModule());
        return kotlin.Unit.INSTANCE;
    }
}
