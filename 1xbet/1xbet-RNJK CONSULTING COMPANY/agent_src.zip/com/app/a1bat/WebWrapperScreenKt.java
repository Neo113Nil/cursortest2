package com.app.a1bat;

/* compiled from: WebWrapperScreen.kt */
@kotlin.Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007²\u0006\f\u0010\b\u001a\u0004\u0018\u00010\tX\u008a\u0084\u0002²\u0006\n\u0010\n\u001a\u00020\u000bX\u008a\u0084\u0002"}, d2 = {"WebWrapperScreen", "", com.google.android.gms.common.internal.ImagesContract.URL, "", "viewModel", "Lcom/app/a1bat/WebLoaderViewModel;", "(Ljava/lang/String;Lcom/app/a1bat/WebLoaderViewModel;Landroidx/compose/runtime/Composer;II)V", "app_release", "webScreenMethod", "Ljava/lang/reflect/Method;", "isConnected", ""}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class WebWrapperScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit WebWrapperScreen$lambda$4(java.lang.String str, com.app.a1bat.WebLoaderViewModel webLoaderViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        WebWrapperScreen(str, webLoaderViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:28:0x007e, code lost:
    
        if ((r26 & 2) != 0) goto L43;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void WebWrapperScreen(final java.lang.String url, com.app.a1bat.WebLoaderViewModel webLoaderViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        com.app.a1bat.WebLoaderViewModel webLoaderViewModel2;
        final com.app.a1bat.WebLoaderViewModel webLoaderViewModel3;
        int i4;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
        androidx.compose.runtime.Composer startRestartGroup = composer.startRestartGroup(1987166091);
        androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "C(WebWrapperScreen)22@784L7,23@845L16,24@900L15,25@961L16,27@1004L48,27@983L69,31@1058L405:WebWrapperScreen.kt#2o83kl");
        if ((i2 & 1) != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = (startRestartGroup.changed(url) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                webLoaderViewModel2 = webLoaderViewModel;
                if (startRestartGroup.changedInstance(webLoaderViewModel2)) {
                    i4 = 32;
                    i3 |= i4;
                }
            } else {
                webLoaderViewModel2 = webLoaderViewModel;
            }
            i4 = 16;
            i3 |= i4;
        } else {
            webLoaderViewModel2 = webLoaderViewModel;
        }
        if ((i3 & 19) != 18 || !startRestartGroup.getSkipping()) {
            startRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "20@733L15");
            if ((i & 1) == 0 || startRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 2) != 0) {
                    startRestartGroup.startReplaceableGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel resolveViewModel = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.WebLoaderViewModel.class), current.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                    startRestartGroup.endReplaceableGroup();
                    webLoaderViewModel2 = (com.app.a1bat.WebLoaderViewModel) resolveViewModel;
                    i3 &= -113;
                }
                webLoaderViewModel3 = webLoaderViewModel2;
                startRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1987166091, i3, -1, "com.app.a1bat.WebWrapperScreen (WebWrapperScreen.kt:21)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<android.content.Context> localContext = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalContext();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object consume = startRestartGroup.consume(localContext);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                android.content.Context context = (android.content.Context) consume;
                androidx.compose.runtime.State collectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(webLoaderViewModel3.getWebScreenMethod(), null, startRestartGroup, 0, 1);
                startRestartGroup.startReplaceableGroup(-1614864554);
                androidx.lifecycle.ViewModelStoreOwner current2 = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(startRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                if (current2 == null) {
                    throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                }
                androidx.lifecycle.ViewModel resolveViewModel2 = org.koin.androidx.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.network.NetworkViewModel.class), current2.getViewModelStore(), null, org.koin.androidx.compose.ViewModelInternalsKt.defaultExtras(current2, startRestartGroup, 8), null, org.koin.compose.KoinApplicationKt.currentKoinScope(startRestartGroup, 0), null);
                startRestartGroup.endReplaceableGroup();
                androidx.compose.runtime.State collectAsState2 = androidx.compose.runtime.SnapshotStateKt.collectAsState(((com.app.a1bat.network.NetworkViewModel) resolveViewModel2).isConnected(), null, startRestartGroup, 0, 1);
                kotlin.Unit unit = kotlin.Unit.INSTANCE;
                startRestartGroup.startReplaceGroup(-2146882082);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "CC(remember):WebWrapperScreen.kt#9igjgp");
                boolean changedInstance = startRestartGroup.changedInstance(webLoaderViewModel3) | startRestartGroup.changedInstance(context);
                com.app.a1bat.WebWrapperScreenKt$WebWrapperScreen$1$1 rememberedValue = startRestartGroup.rememberedValue();
                if (changedInstance || rememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    rememberedValue = new com.app.a1bat.WebWrapperScreenKt$WebWrapperScreen$1$1(webLoaderViewModel3, context, null);
                    startRestartGroup.updateRememberedValue(rememberedValue);
                }
                startRestartGroup.endReplaceGroup();
                androidx.compose.runtime.EffectsKt.LaunchedEffect(unit, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) rememberedValue, startRestartGroup, 6);
                androidx.compose.ui.Modifier fillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy maybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -1323940314, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier materializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(startRestartGroup, fillMaxSize$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(startRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                startRestartGroup.startReusableNode();
                if (startRestartGroup.getInserting()) {
                    startRestartGroup.createNode(constructor);
                } else {
                    startRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer m3405constructorimpl = androidx.compose.runtime.Updater.m3405constructorimpl(startRestartGroup);
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, maybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                kotlin.jvm.functions.Function2<androidx.compose.ui.node.ComposeUiNode, java.lang.Integer, kotlin.Unit> setCompositeKeyHash = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (m3405constructorimpl.getInserting() || !kotlin.jvm.internal.Intrinsics.areEqual(m3405constructorimpl.rememberedValue(), java.lang.Integer.valueOf(currentCompositeKeyHash))) {
                    m3405constructorimpl.updateRememberedValue(java.lang.Integer.valueOf(currentCompositeKeyHash));
                    m3405constructorimpl.apply(java.lang.Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
                }
                androidx.compose.runtime.Updater.m3412setimpl(m3405constructorimpl, materializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(startRestartGroup, 885019123, "C:WebWrapperScreen.kt#2o83kl");
                startRestartGroup.startReplaceGroup(167096336);
                androidx.compose.runtime.ComposerKt.sourceInformation(startRestartGroup, "45@1420L27");
                if (WebWrapperScreen$lambda$0(collectAsState) != null) {
                    java.lang.reflect.Method WebWrapperScreen$lambda$0 = WebWrapperScreen$lambda$0(collectAsState);
                    kotlin.jvm.internal.Intrinsics.checkNotNull(WebWrapperScreen$lambda$0);
                    WebWrapperScreen$lambda$0.invoke(null, url, java.lang.Boolean.valueOf(WebWrapperScreen$lambda$1(collectAsState2)), startRestartGroup, 0, 0);
                } else {
                    androidx.compose.material3.ProgressIndicatorKt.m2060CircularProgressIndicatorLxG7B9w(null, 0L, 0.0f, 0L, 0, startRestartGroup, 0, 31);
                }
                startRestartGroup.endReplaceGroup();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                startRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(startRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            } else {
                startRestartGroup.skipToGroupEnd();
            }
        } else {
            startRestartGroup.skipToGroupEnd();
            webLoaderViewModel3 = webLoaderViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.WebWrapperScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    kotlin.Unit WebWrapperScreen$lambda$4;
                    WebWrapperScreen$lambda$4 = com.app.a1bat.WebWrapperScreenKt.WebWrapperScreen$lambda$4(url, webLoaderViewModel3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    return WebWrapperScreen$lambda$4;
                }
            });
        }
    }

    private static final java.lang.reflect.Method WebWrapperScreen$lambda$0(androidx.compose.runtime.State<java.lang.reflect.Method> state) {
        return state.getValue();
    }

    private static final boolean WebWrapperScreen$lambda$1(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue().booleanValue();
    }
}
