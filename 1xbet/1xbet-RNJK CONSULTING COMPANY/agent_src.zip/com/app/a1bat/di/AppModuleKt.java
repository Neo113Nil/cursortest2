package com.app.a1bat.di;

/* compiled from: AppModule.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"appModule", "Lorg/koin/core/module/Module;", "getAppModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class AppModuleKt {
    private static final org.koin.core.module.Module appModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            kotlin.Unit appModule$lambda$22;
            appModule$lambda$22 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22((org.koin.core.module.Module) obj);
            return appModule$lambda$22;
        }
    }, 1, null);

    public static final org.koin.core.module.Module getAppModule() {
        return appModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.AppDatabase appModule$lambda$22$lambda$0(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return com.app.a1bat.data.local.AppDatabase.INSTANCE.getDatabase(org.koin.android.ext.koin.ModuleExtKt.androidContext(single));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.datastore.core.DataStore appModule$lambda$22$lambda$5(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return com.app.a1bat.data.DataStoreExtKt.getSettingsDataStore(org.koin.android.ext.koin.ModuleExtKt.androidContext(single));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.preferences.AppPreferences appModule$lambda$22$lambda$6(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.data.local.preferences.AppPreferences(org.koin.android.ext.koin.ModuleExtKt.androidContext(single));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.domain.repository.AppRepository appModule$lambda$22$lambda$7(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.data.repository.AppRepositoryImpl((com.app.a1bat.data.local.dao.ServiceDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ServiceDao.class), null, null), (com.app.a1bat.data.local.dao.BookingDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.BookingDao.class), null, null), (com.app.a1bat.data.local.dao.ProjectDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ProjectDao.class), null, null), (com.app.a1bat.data.local.dao.ArticleDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ArticleDao.class), null, null), (com.app.a1bat.data.local.preferences.AppPreferences) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.preferences.AppPreferences.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.repository.SettingRepository appModule$lambda$22$lambda$8(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.data.repository.SettingRepositoryImpl((androidx.datastore.core.DataStore) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(androidx.datastore.core.DataStore.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.repository.RemoteConfigRepository appModule$lambda$22$lambda$9(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.data.repository.RemoteConfigRepositoryImpl((androidx.datastore.core.DataStore) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(androidx.datastore.core.DataStore.class), null, null), org.koin.android.ext.koin.ModuleExtKt.androidContext(single));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.splash.SplashViewModel appModule$lambda$22$lambda$10(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.splash.SplashViewModel((com.app.a1bat.data.repository.RemoteConfigRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.repository.RemoteConfigRepository.class), null, null), (com.app.a1bat.data.repository.SettingRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.repository.SettingRepository.class), null, null), (com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.main.MainViewModel appModule$lambda$22$lambda$11(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.main.MainViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.onboarding.OnboardingViewModel appModule$lambda$22$lambda$12(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.onboarding.OnboardingViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.home.HomeViewModel appModule$lambda$22$lambda$13(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.home.HomeViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.home.ServiceDetailsViewModel appModule$lambda$22$lambda$14(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.home.ServiceDetailsViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.booking.BookingViewModel appModule$lambda$22$lambda$15(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.booking.BookingViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel appModule$lambda$22$lambda$16(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.portfolio.PortfolioViewModel appModule$lambda$22$lambda$17(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.portfolio.PortfolioViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel appModule$lambda$22$lambda$18(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel appModule$lambda$22$lambda$19(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel((com.app.a1bat.domain.repository.AppRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static final com.app.a1bat.network.NetworkViewModel appModule$lambda$22$lambda$20(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.network.NetworkViewModel(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.WebLoaderViewModel appModule$lambda$22$lambda$21(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new com.app.a1bat.WebLoaderViewModel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.dao.ServiceDao appModule$lambda$22$lambda$1(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((com.app.a1bat.data.local.AppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.AppDatabase.class), null, null)).serviceDao();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.dao.BookingDao appModule$lambda$22$lambda$2(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((com.app.a1bat.data.local.AppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.AppDatabase.class), null, null)).bookingDao();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.dao.ProjectDao appModule$lambda$22$lambda$3(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((com.app.a1bat.data.local.AppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.AppDatabase.class), null, null)).projectDao();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.app.a1bat.data.local.dao.ArticleDao appModule$lambda$22$lambda$4(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((com.app.a1bat.data.local.AppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.AppDatabase.class), null, null)).articleDao();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit appModule$lambda$22(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        kotlin.jvm.functions.Function2 function2 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.AppDatabase appModule$lambda$22$lambda$0;
                appModule$lambda$22$lambda$0 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$0;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.AppDatabase.class), null, function2, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory2 = singleInstanceFactory;
        module.indexPrimaryType(singleInstanceFactory2);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory2);
        kotlin.jvm.functions.Function2 function22 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.dao.ServiceDao appModule$lambda$22$lambda$1;
                appModule$lambda$22$lambda$1 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$1((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$1;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory3 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ServiceDao.class), null, function22, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory4 = singleInstanceFactory3;
        module.indexPrimaryType(singleInstanceFactory4);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory3);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory4);
        kotlin.jvm.functions.Function2 function23 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.dao.BookingDao appModule$lambda$22$lambda$2;
                appModule$lambda$22$lambda$2 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$2((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$2;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory5 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.BookingDao.class), null, function23, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory6 = singleInstanceFactory5;
        module.indexPrimaryType(singleInstanceFactory6);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory5);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory6);
        kotlin.jvm.functions.Function2 function24 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.dao.ProjectDao appModule$lambda$22$lambda$3;
                appModule$lambda$22$lambda$3 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$3((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$3;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory7 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ProjectDao.class), null, function24, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory8 = singleInstanceFactory7;
        module.indexPrimaryType(singleInstanceFactory8);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory7);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory8);
        kotlin.jvm.functions.Function2 function25 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.dao.ArticleDao appModule$lambda$22$lambda$4;
                appModule$lambda$22$lambda$4 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$4((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$4;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory9 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.dao.ArticleDao.class), null, function25, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory10 = singleInstanceFactory9;
        module.indexPrimaryType(singleInstanceFactory10);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory9);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory10);
        kotlin.jvm.functions.Function2 function26 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                androidx.datastore.core.DataStore appModule$lambda$22$lambda$5;
                appModule$lambda$22$lambda$5 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$5((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$5;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory11 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(androidx.datastore.core.DataStore.class), null, function26, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory12 = singleInstanceFactory11;
        module.indexPrimaryType(singleInstanceFactory12);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory11);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory12);
        kotlin.jvm.functions.Function2 function27 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda10
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.local.preferences.AppPreferences appModule$lambda$22$lambda$6;
                appModule$lambda$22$lambda$6 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$6((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$6;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory13 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.local.preferences.AppPreferences.class), null, function27, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory14 = singleInstanceFactory13;
        module.indexPrimaryType(singleInstanceFactory14);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory13);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory14);
        kotlin.jvm.functions.Function2 function28 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.domain.repository.AppRepository appModule$lambda$22$lambda$7;
                appModule$lambda$22$lambda$7 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$7((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$7;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory15 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.domain.repository.AppRepository.class), null, function28, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory16 = singleInstanceFactory15;
        module.indexPrimaryType(singleInstanceFactory16);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory15);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory16);
        kotlin.jvm.functions.Function2 function29 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.repository.SettingRepository appModule$lambda$22$lambda$8;
                appModule$lambda$22$lambda$8 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$8((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$8;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory17 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.repository.SettingRepository.class), null, function29, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory18 = singleInstanceFactory17;
        module.indexPrimaryType(singleInstanceFactory18);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory17);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory18);
        kotlin.jvm.functions.Function2 function210 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.data.repository.RemoteConfigRepository appModule$lambda$22$lambda$9;
                appModule$lambda$22$lambda$9 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$9((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$9;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory19 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.data.repository.RemoteConfigRepository.class), null, function210, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory20 = singleInstanceFactory19;
        module.indexPrimaryType(singleInstanceFactory20);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory19);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory20);
        kotlin.jvm.functions.Function2 function211 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.splash.SplashViewModel appModule$lambda$22$lambda$10;
                appModule$lambda$22$lambda$10 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$10((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$10;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.splash.SplashViewModel.class), null, function211, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory);
        kotlin.jvm.functions.Function2 function212 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.main.MainViewModel appModule$lambda$22$lambda$11;
                appModule$lambda$22$lambda$11 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$11((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$11;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory2 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.main.MainViewModel.class), null, function212, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory2);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory2);
        kotlin.jvm.functions.Function2 function213 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda17
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.onboarding.OnboardingViewModel appModule$lambda$22$lambda$12;
                appModule$lambda$22$lambda$12 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$12((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$12;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory3 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.onboarding.OnboardingViewModel.class), null, function213, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory3);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory3);
        kotlin.jvm.functions.Function2 function214 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda18
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.home.HomeViewModel appModule$lambda$22$lambda$13;
                appModule$lambda$22$lambda$13 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$13((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$13;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory4 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.home.HomeViewModel.class), null, function214, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory4);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory4);
        kotlin.jvm.functions.Function2 function215 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.home.ServiceDetailsViewModel appModule$lambda$22$lambda$14;
                appModule$lambda$22$lambda$14 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$14((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$14;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory5 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.home.ServiceDetailsViewModel.class), null, function215, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory5);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory5);
        kotlin.jvm.functions.Function2 function216 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda20
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.booking.BookingViewModel appModule$lambda$22$lambda$15;
                appModule$lambda$22$lambda$15 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$15((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$15;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory6 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.booking.BookingViewModel.class), null, function216, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory6);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory6);
        kotlin.jvm.functions.Function2 function217 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda21
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel appModule$lambda$22$lambda$16;
                appModule$lambda$22$lambda$16 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$16((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$16;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory7 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.booking.BookingsHistoryViewModel.class), null, function217, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory7);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory7);
        kotlin.jvm.functions.Function2 function218 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda22
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.portfolio.PortfolioViewModel appModule$lambda$22$lambda$17;
                appModule$lambda$22$lambda$17 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$17((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$17;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory8 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.portfolio.PortfolioViewModel.class), null, function218, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory8);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory8);
        kotlin.jvm.functions.Function2 function219 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel appModule$lambda$22$lambda$18;
                appModule$lambda$22$lambda$18 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$18((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$18;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory9 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.knowledge.KnowledgeBaseViewModel.class), null, function219, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory9);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory9);
        kotlin.jvm.functions.Function2 function220 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel appModule$lambda$22$lambda$19;
                appModule$lambda$22$lambda$19 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$19((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$19;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory10 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.ui.screens.knowledge.ArticleDetailsViewModel.class), null, function220, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory10);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory10);
        kotlin.jvm.functions.Function2 function221 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.network.NetworkViewModel appModule$lambda$22$lambda$20;
                appModule$lambda$22$lambda$20 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$20((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$20;
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory21 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.network.NetworkViewModel.class), null, function221, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory22 = singleInstanceFactory21;
        module.indexPrimaryType(singleInstanceFactory22);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory21);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory22);
        kotlin.jvm.functions.Function2 function222 = new kotlin.jvm.functions.Function2() { // from class: com.app.a1bat.di.AppModuleKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                com.app.a1bat.WebLoaderViewModel appModule$lambda$22$lambda$21;
                appModule$lambda$22$lambda$21 = com.app.a1bat.di.AppModuleKt.appModule$lambda$22$lambda$21((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
                return appModule$lambda$22$lambda$21;
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory11 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.app.a1bat.WebLoaderViewModel.class), null, function222, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory11);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory11);
        return kotlin.Unit.INSTANCE;
    }
}
