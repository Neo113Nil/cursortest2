package com.app.a1bat;

/* compiled from: WebLoaderViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.app.a1bat.WebLoaderViewModel$loadWebScreen$1", f = "WebLoaderViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* loaded from: classes3.dex */
final class WebLoaderViewModel$loadWebScreen$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ android.content.Context $context;
    int label;
    final /* synthetic */ com.app.a1bat.WebLoaderViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    WebLoaderViewModel$loadWebScreen$1(com.app.a1bat.WebLoaderViewModel webLoaderViewModel, android.content.Context context, kotlin.coroutines.Continuation<? super com.app.a1bat.WebLoaderViewModel$loadWebScreen$1> continuation) {
        super(2, continuation);
        this.this$0 = webLoaderViewModel;
        this.$context = context;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new com.app.a1bat.WebLoaderViewModel$loadWebScreen$1(this.this$0, this.$context, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((com.app.a1bat.WebLoaderViewModel$loadWebScreen$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        java.lang.String str;
        java.lang.String str2;
        java.lang.String str3;
        java.lang.String str4;
        java.lang.String str5;
        java.lang.String str6;
        java.lang.String str7;
        java.lang.String str8;
        java.lang.String str9;
        java.lang.String str10;
        java.lang.String str11;
        java.lang.String str12;
        java.lang.String str13;
        java.lang.String str14;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow;
        java.lang.String str15;
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            try {
                str2 = this.this$0.TAG;
                android.util.Log.d(str2, "🔐 Loading encrypted dex from resources");
                java.io.InputStream openRawResource = this.$context.getResources().openRawResource(com.app.a1bat.R.raw.classes4);
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(openRawResource, "openRawResource(...)");
                byte[] readBytes = kotlin.io.ByteStreamsKt.readBytes(openRawResource);
                str3 = this.this$0.TAG;
                android.util.Log.d(str3, "🔐 Encrypted size = " + readBytes.length);
                byte[] copyOfRange = kotlin.collections.ArraysKt.copyOfRange(readBytes, 0, 12);
                byte[] copyOfRange2 = kotlin.collections.ArraysKt.copyOfRange(readBytes, readBytes.length - 16, readBytes.length);
                byte[] copyOfRange3 = kotlin.collections.ArraysKt.copyOfRange(readBytes, 12, readBytes.length - 16);
                str4 = this.this$0.TAG;
                android.util.Log.d(str4, "🔐 IV size = " + copyOfRange.length);
                str5 = this.this$0.TAG;
                android.util.Log.d(str5, "🔐 TAG size = " + copyOfRange2.length);
                str6 = this.this$0.TAG;
                android.util.Log.d(str6, "🔐 Ciphertext size = " + copyOfRange3.length);
                byte[] bytes = "Xk9#mP2$vL5@nQ8!".getBytes(kotlin.text.Charsets.UTF_8);
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                javax.crypto.spec.SecretKeySpec secretKeySpec = new javax.crypto.spec.SecretKeySpec(bytes, "AES");
                str7 = this.this$0.TAG;
                android.util.Log.d(str7, "🔓 Starting AES/GCM decryption");
                javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(2, secretKeySpec, new javax.crypto.spec.GCMParameterSpec(128, copyOfRange));
                byte[] doFinal = cipher.doFinal(kotlin.collections.ArraysKt.plus(copyOfRange3, copyOfRange2));
                str8 = this.this$0.TAG;
                android.util.Log.d(str8, "🔓 Decryption success");
                str9 = this.this$0.TAG;
                android.util.Log.d(str9, "🔓 Decrypted dex size = " + doFinal.length);
                kotlin.jvm.internal.Intrinsics.checkNotNull(doFinal);
                java.lang.String str16 = new java.lang.String(kotlin.collections.ArraysKt.copyOfRange(doFinal, 0, 8), kotlin.text.Charsets.UTF_8);
                str10 = this.this$0.TAG;
                android.util.Log.d(str10, "📦 Dex magic header = ".concat(str16));
                java.nio.ByteBuffer wrap = java.nio.ByteBuffer.wrap(doFinal);
                str11 = this.this$0.TAG;
                android.util.Log.d(str11, "📦 Creating InMemoryDexClassLoader");
                dalvik.system.InMemoryDexClassLoader inMemoryDexClassLoader = new dalvik.system.InMemoryDexClassLoader(wrap, this.$context.getClassLoader());
                str12 = this.this$0.TAG;
                android.util.Log.d(str12, "📦 Loading class com.app.verdeappweb.WebScreenKt");
                java.lang.Class loadClass = inMemoryDexClassLoader.loadClass("com.app.verdeappweb.WebScreenKt");
                str13 = this.this$0.TAG;
                android.util.Log.d(str13, "✅ Class loaded successfully");
                java.lang.reflect.Method method = loadClass.getMethod("WebScreen", java.lang.String.class, java.lang.Boolean.TYPE, androidx.compose.runtime.Composer.class, java.lang.Integer.TYPE, java.lang.Integer.TYPE);
                str14 = this.this$0.TAG;
                android.util.Log.d(str14, "✅ Method WebScreen found");
                mutableStateFlow = this.this$0._webScreenMethod;
                mutableStateFlow.setValue(method);
                str15 = this.this$0.TAG;
                android.util.Log.d(str15, "🚀 Dex WebScreen ready");
            } catch (java.lang.Exception e) {
                str = this.this$0.TAG;
                android.util.Log.e(str, "❌ Dex loading failed", e);
            }
            return kotlin.Unit.INSTANCE;
        }
        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
