package com.app.verdeappweb;

import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import com.app.verdeappweb.ui.theme.ThemeKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MainActivity.kt */
@Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class ComposableSingletons$MainActivityKt {
    public static final ComposableSingletons$MainActivityKt INSTANCE = new ComposableSingletons$MainActivityKt();

    /* renamed from: lambda-1, reason: not valid java name */
    public static Function3<PaddingValues, Composer, Integer, Unit> f0lambda1 = ComposableLambdaKt.composableLambdaInstance(-2038424309, false, new Function3<PaddingValues, Composer, Integer, Unit>() { // from class: com.app.verdeappweb.ComposableSingletons$MainActivityKt$lambda-1$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2, Object p3) {
            invoke((PaddingValues) p1, (Composer) p2, ((Number) p3).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(PaddingValues innerPadding, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
            ComposerKt.sourceInformation($composer, "C22@873L139:MainActivity.kt#rxc5dp");
            int $dirty = $changed;
            if (($changed & 6) == 0) {
                $dirty |= $composer.changed(innerPadding) ? 4 : 2;
            }
            if (($dirty & 19) != 18 || !$composer.getSkipping()) {
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-2038424309, $dirty, -1, "com.app.verdeappweb.ComposableSingletons$MainActivityKt.lambda-1.<anonymous> (MainActivity.kt:22)");
                }
                MainActivityKt.Greeting("Android", PaddingKt.padding(Modifier.Companion, innerPadding), $composer, 6, 0);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            $composer.skipToGroupEnd();
        }
    });

    /* renamed from: lambda-2, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f1lambda2 = ComposableLambdaKt.composableLambdaInstance(327136570, false, new Function2<Composer, Integer, Unit>() { // from class: com.app.verdeappweb.ComposableSingletons$MainActivityKt$lambda-2$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
            invoke((Composer) p1, ((Number) p2).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C21@791L239:MainActivity.kt#rxc5dp");
            if (($changed & 3) != 2 || !$composer.getSkipping()) {
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(327136570, $changed, -1, "com.app.verdeappweb.ComposableSingletons$MainActivityKt.lambda-2.<anonymous> (MainActivity.kt:21)");
                }
                ScaffoldKt.Scaffold-TvnljyQ(SizeKt.fillMaxSize$default(Modifier.Companion, 0.0f, 1, (Object) null), (Function2) null, (Function2) null, (Function2) null, (Function2) null, 0, 0L, 0L, (WindowInsets) null, ComposableSingletons$MainActivityKt.INSTANCE.m1getLambda1$app_debug(), $composer, 805306374, 510);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            $composer.skipToGroupEnd();
        }
    });

    /* renamed from: lambda-3, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f2lambda3 = ComposableLambdaKt.composableLambdaInstance(-1676422981, false, new Function2<Composer, Integer, Unit>() { // from class: com.app.verdeappweb.ComposableSingletons$MainActivityKt$lambda-3$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
            invoke((Composer) p1, ((Number) p2).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C20@756L288:MainActivity.kt#rxc5dp");
            if (($changed & 3) != 2 || !$composer.getSkipping()) {
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-1676422981, $changed, -1, "com.app.verdeappweb.ComposableSingletons$MainActivityKt.lambda-3.<anonymous> (MainActivity.kt:20)");
                }
                ThemeKt.VerdeAppWebTheme(false, false, ComposableSingletons$MainActivityKt.INSTANCE.m2getLambda2$app_debug(), $composer, 384, 3);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            $composer.skipToGroupEnd();
        }
    });

    /* renamed from: lambda-4, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f3lambda4 = ComposableLambdaKt.composableLambdaInstance(493029145, false, new Function2<Composer, Integer, Unit>() { // from class: com.app.verdeappweb.ComposableSingletons$MainActivityKt$lambda-4$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
            invoke((Composer) p1, ((Number) p2).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C44@1313L19:MainActivity.kt#rxc5dp");
            if (($changed & 3) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(493029145, $changed, -1, "com.app.verdeappweb.ComposableSingletons$MainActivityKt.lambda-4.<anonymous> (MainActivity.kt:44)");
            }
            MainActivityKt.Greeting("Android", null, $composer, 6, 2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function3<PaddingValues, Composer, Integer, Unit> m1getLambda1$app_debug() {
        return f0lambda1;
    }

    /* renamed from: getLambda-2$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m2getLambda2$app_debug() {
        return f1lambda2;
    }

    /* renamed from: getLambda-3$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m3getLambda3$app_debug() {
        return f2lambda3;
    }

    /* renamed from: getLambda-4$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m4getLambda4$app_debug() {
        return f3lambda4;
    }
}
