package com.app.verdeappweb;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: NetworkMonitorWeb.kt */
@Metadata(d1 = {"\u00009\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002*\u0001\u000f\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0011\u001a\u00020\u0012H\u0017J\b\u0010\u0013\u001a\u00020\u0012H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\fX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\rR\u0010\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0010¨\u0006\u0014"}, d2 = {"Lcom/app/verdeappweb/NetworkMonitorAndroid;", "Lcom/app/verdeappweb/NetworkMonitor;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "connectivityManager", "Landroid/net/ConnectivityManager;", "_isConnected", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "isConnected", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "callback", "com/app/verdeappweb/NetworkMonitorAndroid$callback$1", "Lcom/app/verdeappweb/NetworkMonitorAndroid$callback$1;", "start", "", "stop", "app_debug"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class NetworkMonitorAndroid implements NetworkMonitor {
    public static final int $stable = 8;
    private final MutableStateFlow<Boolean> _isConnected;
    private final NetworkMonitorAndroid$callback$1 callback;
    private final ConnectivityManager connectivityManager;
    private final Context context;
    private final StateFlow<Boolean> isConnected;

    /* JADX WARN: Type inference failed for: r0v9, types: [com.app.verdeappweb.NetworkMonitorAndroid$callback$1] */
    public NetworkMonitorAndroid(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        Object systemService = this.context.getSystemService("connectivity");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        this.connectivityManager = (ConnectivityManager) systemService;
        this._isConnected = StateFlowKt.MutableStateFlow(true);
        this.isConnected = this._isConnected;
        this.callback = new ConnectivityManager.NetworkCallback() { // from class: com.app.verdeappweb.NetworkMonitorAndroid$callback$1
            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onAvailable(Network network) {
                MutableStateFlow mutableStateFlow;
                Intrinsics.checkNotNullParameter(network, "network");
                mutableStateFlow = NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(true);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onLost(Network network) {
                MutableStateFlow mutableStateFlow;
                Intrinsics.checkNotNullParameter(network, "network");
                mutableStateFlow = NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(false);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onUnavailable() {
                MutableStateFlow mutableStateFlow;
                mutableStateFlow = NetworkMonitorAndroid.this._isConnected;
                mutableStateFlow.setValue(false);
            }
        };
    }

    @Override // com.app.verdeappweb.NetworkMonitor
    public StateFlow<Boolean> isConnected() {
        return this.isConnected;
    }

    @Override // com.app.verdeappweb.NetworkMonitor
    public void start() {
        boolean z;
        try {
            NetworkRequest request = new NetworkRequest.Builder().addCapability(12).build();
            this.connectivityManager.registerNetworkCallback(request, this.callback);
            NetworkInfo active = this.connectivityManager.getActiveNetworkInfo();
            MutableStateFlow<Boolean> mutableStateFlow = this._isConnected;
            if (active != null) {
                z = true;
                if (active.isConnected()) {
                    mutableStateFlow.setValue(Boolean.valueOf(z));
                }
            }
            z = false;
            mutableStateFlow.setValue(Boolean.valueOf(z));
        } catch (Exception e) {
            this._isConnected.setValue(false);
        }
    }

    @Override // com.app.verdeappweb.NetworkMonitor
    public void stop() {
        try {
            this.connectivityManager.unregisterNetworkCallback(this.callback);
        } catch (Exception e) {
        }
    }
}
