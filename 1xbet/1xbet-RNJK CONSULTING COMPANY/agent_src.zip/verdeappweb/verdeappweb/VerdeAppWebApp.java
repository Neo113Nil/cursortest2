package com.app.verdeappweb;

import android.app.Application;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.koin.android.ext.koin.KoinExtKt;
import org.koin.core.KoinApplication;
import org.koin.core.context.DefaultContextExtKt;
import org.koin.core.logger.Level;

/* compiled from: VerdeAppWebApp.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"Lcom/app/verdeappweb/VerdeAppWebApp;", "Landroid/app/Application;", "<init>", "()V", "onCreate", "", "app_debug"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class VerdeAppWebApp extends Application {
    public static final int $stable = 0;

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        DefaultContextExtKt.startKoin(new Function1() { // from class: com.app.verdeappweb.VerdeAppWebApp$$ExternalSyntheticLambda0
            public final Object invoke(Object obj) {
                Unit onCreate$lambda$0;
                onCreate$lambda$0 = VerdeAppWebApp.onCreate$lambda$0(VerdeAppWebApp.this, (KoinApplication) obj);
                return onCreate$lambda$0;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$0(VerdeAppWebApp this$0, KoinApplication $this$startKoin) {
        Intrinsics.checkNotNullParameter($this$startKoin, "$this$startKoin");
        KoinExtKt.androidLogger($this$startKoin, Level.ERROR);
        KoinExtKt.androidContext($this$startKoin, this$0);
        $this$startKoin.modules(AppModuleKt.getAppModule());
        return Unit.INSTANCE;
    }
}
