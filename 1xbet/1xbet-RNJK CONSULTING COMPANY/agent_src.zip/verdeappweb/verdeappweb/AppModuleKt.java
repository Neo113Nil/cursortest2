package com.app.verdeappweb;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import org.koin.core.definition.BeanDefinition;
import org.koin.core.definition.Kind;
import org.koin.core.definition.KoinDefinition;
import org.koin.core.instance.InstanceFactory;
import org.koin.core.instance.SingleInstanceFactory;
import org.koin.core.module.Module;
import org.koin.core.parameter.ParametersHolder;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.registry.ScopeRegistry;
import org.koin.core.scope.Scope;
import org.koin.dsl.ModuleDSLKt;

/* compiled from: AppModule.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"appModule", "Lorg/koin/core/module/Module;", "getAppModule", "()Lorg/koin/core/module/Module;", "app_debug"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class AppModuleKt {
    private static final Module appModule = ModuleDSLKt.module$default(false, new Function1() { // from class: com.app.verdeappweb.AppModuleKt$$ExternalSyntheticLambda0
        public final Object invoke(Object obj) {
            Unit appModule$lambda$1;
            appModule$lambda$1 = AppModuleKt.appModule$lambda$1((Module) obj);
            return appModule$lambda$1;
        }
    }, 1, (Object) null);

    public static final Module getAppModule() {
        return appModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit appModule$lambda$1(Module $this$module) {
        Intrinsics.checkNotNullParameter($this$module, "$this$module");
        Function2 function2 = new Function2() { // from class: com.app.verdeappweb.AppModuleKt$$ExternalSyntheticLambda1
            public final Object invoke(Object obj, Object obj2) {
                NetworkViewModel appModule$lambda$1$lambda$0;
                appModule$lambda$1$lambda$0 = AppModuleKt.appModule$lambda$1$lambda$0((Scope) obj, (ParametersHolder) obj2);
                return appModule$lambda$1$lambda$0;
            }
        };
        InstanceFactory singleInstanceFactory = new SingleInstanceFactory(new BeanDefinition(ScopeRegistry.Companion.getRootScopeQualifier(), Reflection.getOrCreateKotlinClass(NetworkViewModel.class), (Qualifier) null, function2, Kind.Singleton, CollectionsKt.emptyList()));
        $this$module.indexPrimaryType(singleInstanceFactory);
        if ($this$module.get_createdAtStart()) {
            $this$module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new KoinDefinition($this$module, singleInstanceFactory);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final NetworkViewModel appModule$lambda$1$lambda$0(Scope $this$single, ParametersHolder it) {
        Intrinsics.checkNotNullParameter($this$single, "$this$single");
        Intrinsics.checkNotNullParameter(it, "it");
        return new NetworkViewModel(null, 1, null);
    }
}
