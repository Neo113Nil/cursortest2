package com.app.verdeappweb;

import android.content.Context;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScope;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: NetworkMonitorWeb.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u001a\u0006\u0010\u0006\u001a\u00020\u0007\u001a\r\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\u0010\n\"\u001a\u0010\u0000\u001a\u00020\u0001X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0004\b\u0004\u0010\u0005¨\u0006\u000b"}, d2 = {"appContext", "Landroid/content/Context;", "getAppContext", "()Landroid/content/Context;", "setAppContext", "(Landroid/content/Context;)V", "createNetworkMonitor", "Lcom/app/verdeappweb/NetworkMonitor;", "NoInternetOverlay", "", "(Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class NetworkMonitorWebKt {
    public static Context appContext;

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit NoInternetOverlay$lambda$2(int i, Composer composer, int i2) {
        NoInternetOverlay(composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final Context getAppContext() {
        Context context = appContext;
        if (context != null) {
            return context;
        }
        Intrinsics.throwUninitializedPropertyAccessException("appContext");
        return null;
    }

    public static final void setAppContext(Context context) {
        Intrinsics.checkNotNullParameter(context, "<set-?>");
        appContext = context;
    }

    public static final NetworkMonitor createNetworkMonitor() {
        return new NetworkMonitorAndroid(getAppContext());
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x01d3  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x01df  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0216  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0315  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x022c  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x01e5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void NoInternetOverlay(Composer $composer, final int $changed) {
        Function0 function0;
        Composer $composer2;
        int i;
        Function0 function02;
        Composer composer;
        Composer composer2;
        Composer $composer3 = $composer.startRestartGroup(-1875605149);
        ComposerKt.sourceInformation($composer3, "C(NoInternetOverlay)106@2968L513:NetworkMonitorWeb.kt#rxc5dp");
        if ($changed != 0 || !$composer3.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1875605149, $changed, -1, "com.app.verdeappweb.NoInternetOverlay (NetworkMonitorWeb.kt:105)");
            }
            Modifier modifier = BackgroundKt.background-bw27NRU$default(SizeKt.fillMaxSize$default(Modifier.Companion, 0.0f, 1, (Object) null), Color.copy-wmQWz5c$default(Color.Companion.getBlack-0d7_KjU(), 0.5f, 0.0f, 0.0f, 0.0f, 14, (Object) null), (Shape) null, 2, (Object) null);
            Alignment center = Alignment.Companion.getCenter();
            ComposerKt.sourceInformationMarkerStart($composer3, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
            ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int hashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
            CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
            Modifier materializeModifier = ComposedModifierKt.materializeModifier($composer3, modifier);
            Function0 constructor = ComposeUiNode.Companion.getConstructor();
            int i2 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!($composer3.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer3.startReusableNode();
            if ($composer3.getInserting()) {
                function0 = constructor;
                $composer3.createNode(function0);
            } else {
                function0 = constructor;
                $composer3.useNode();
            }
            Composer composer3 = Updater.constructor-impl($composer3);
            $composer2 = $composer3;
            Updater.set-impl(composer3, maybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.getSetMeasurePolicy());
            Updater.set-impl(composer3, currentCompositionLocalMap, ComposeUiNode.Companion.getSetResolvedCompositionLocals());
            Function2 setCompositeKeyHash = ComposeUiNode.Companion.getSetCompositeKeyHash();
            if (composer3.getInserting()) {
                i = 54;
            } else {
                i = 54;
                if (Intrinsics.areEqual(composer3.rememberedValue(), Integer.valueOf(hashCode))) {
                    Updater.set-impl(composer3, materializeModifier, ComposeUiNode.Companion.getSetModifier());
                    int i3 = (i2 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart($composer2, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                    BoxScope boxScope = BoxScopeInstance.INSTANCE;
                    int i4 = ((i >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart($composer2, -1933609507, "C112@3145L330:NetworkMonitorWeb.kt#rxc5dp");
                    Alignment.Horizontal centerHorizontally = Alignment.Companion.getCenterHorizontally();
                    ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                    Modifier modifier2 = Modifier.Companion;
                    MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally, $composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
                    int hashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
                    CompositionLocalMap currentCompositionLocalMap2 = $composer2.getCurrentCompositionLocalMap();
                    Modifier materializeModifier2 = ComposedModifierKt.materializeModifier($composer2, modifier2);
                    Function0 constructor2 = ComposeUiNode.Companion.getConstructor();
                    int i5 = ((((384 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
                    if (!($composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    $composer2.startReusableNode();
                    if (!$composer2.getInserting()) {
                        function02 = constructor2;
                        $composer2.createNode(function02);
                    } else {
                        function02 = constructor2;
                        $composer2.useNode();
                    }
                    composer = Updater.constructor-impl($composer2);
                    Updater.set-impl(composer, columnMeasurePolicy, ComposeUiNode.Companion.getSetMeasurePolicy());
                    Updater.set-impl(composer, currentCompositionLocalMap2, ComposeUiNode.Companion.getSetResolvedCompositionLocals());
                    Function2 setCompositeKeyHash2 = ComposeUiNode.Companion.getSetCompositeKeyHash();
                    if (composer.getInserting()) {
                        composer2 = $composer2;
                        if (Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(hashCode2))) {
                            Updater.set-impl(composer, materializeModifier2, ComposeUiNode.Companion.getSetModifier());
                            int i6 = (i5 >> 6) & 14;
                            Composer composer4 = composer2;
                            ComposerKt.sourceInformationMarkerStart(composer4, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
                            int i7 = ((384 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer4, -585686446, "C114@3219L131,120@3364L41,122@3419L46:NetworkMonitorWeb.kt#rxc5dp");
                            TextKt.Text--4IGK_g("No Internet connection", (Modifier) null, Color.Companion.getWhite-0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, (TextStyle) null, composer4, 3462, 0, 131058);
                            SpacerKt.Spacer(SizeKt.height-3ABfNKs(Modifier.Companion, Dp.constructor-impl(12)), composer4, 6);
                            ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w((Modifier) null, Color.Companion.getWhite-0d7_KjU(), 0.0f, 0L, 0, composer4, 48, 29);
                            ComposerKt.sourceInformationMarkerEnd(composer4);
                            ComposerKt.sourceInformationMarkerEnd(composer4);
                            composer2.endNode();
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            $composer2.endNode();
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                    } else {
                        composer2 = $composer2;
                    }
                    composer.updateRememberedValue(Integer.valueOf(hashCode2));
                    composer.apply(Integer.valueOf(hashCode2), setCompositeKeyHash2);
                    Updater.set-impl(composer, materializeModifier2, ComposeUiNode.Companion.getSetModifier());
                    int i62 = (i5 >> 6) & 14;
                    Composer composer42 = composer2;
                    ComposerKt.sourceInformationMarkerStart(composer42, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                    ColumnScope columnScope2 = ColumnScopeInstance.INSTANCE;
                    int i72 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer42, -585686446, "C114@3219L131,120@3364L41,122@3419L46:NetworkMonitorWeb.kt#rxc5dp");
                    TextKt.Text--4IGK_g("No Internet connection", (Modifier) null, Color.Companion.getWhite-0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, (TextStyle) null, composer42, 3462, 0, 131058);
                    SpacerKt.Spacer(SizeKt.height-3ABfNKs(Modifier.Companion, Dp.constructor-impl(12)), composer42, 6);
                    ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w((Modifier) null, Color.Companion.getWhite-0d7_KjU(), 0.0f, 0L, 0, composer42, 48, 29);
                    ComposerKt.sourceInformationMarkerEnd(composer42);
                    ComposerKt.sourceInformationMarkerEnd(composer42);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    $composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    if (ComposerKt.isTraceInProgress()) {
                    }
                }
            }
            composer3.updateRememberedValue(Integer.valueOf(hashCode));
            composer3.apply(Integer.valueOf(hashCode), setCompositeKeyHash);
            Updater.set-impl(composer3, materializeModifier, ComposeUiNode.Companion.getSetModifier());
            int i32 = (i2 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer2, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScope boxScope2 = BoxScopeInstance.INSTANCE;
            int i42 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, -1933609507, "C112@3145L330:NetworkMonitorWeb.kt#rxc5dp");
            Alignment.Horizontal centerHorizontally2 = Alignment.Companion.getCenterHorizontally();
            ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier modifier22 = Modifier.Companion;
            MeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally2, $composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int hashCode22 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
            CompositionLocalMap currentCompositionLocalMap22 = $composer2.getCurrentCompositionLocalMap();
            Modifier materializeModifier22 = ComposedModifierKt.materializeModifier($composer2, modifier22);
            Function0 constructor22 = ComposeUiNode.Companion.getConstructor();
            int i52 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!($composer2.getApplier() instanceof Applier)) {
            }
            $composer2.startReusableNode();
            if (!$composer2.getInserting()) {
            }
            composer = Updater.constructor-impl($composer2);
            Updater.set-impl(composer, columnMeasurePolicy2, ComposeUiNode.Companion.getSetMeasurePolicy());
            Updater.set-impl(composer, currentCompositionLocalMap22, ComposeUiNode.Companion.getSetResolvedCompositionLocals());
            Function2 setCompositeKeyHash22 = ComposeUiNode.Companion.getSetCompositeKeyHash();
            if (composer.getInserting()) {
            }
            composer.updateRememberedValue(Integer.valueOf(hashCode22));
            composer.apply(Integer.valueOf(hashCode22), setCompositeKeyHash22);
            Updater.set-impl(composer, materializeModifier22, ComposeUiNode.Companion.getSetModifier());
            int i622 = (i52 >> 6) & 14;
            Composer composer422 = composer2;
            ComposerKt.sourceInformationMarkerStart(composer422, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScope columnScope22 = ColumnScopeInstance.INSTANCE;
            int i722 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer422, -585686446, "C114@3219L131,120@3364L41,122@3419L46:NetworkMonitorWeb.kt#rxc5dp");
            TextKt.Text--4IGK_g("No Internet connection", (Modifier) null, Color.Companion.getWhite-0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, (TextStyle) null, composer422, 3462, 0, 131058);
            SpacerKt.Spacer(SizeKt.height-3ABfNKs(Modifier.Companion, Dp.constructor-impl(12)), composer422, 6);
            ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w((Modifier) null, Color.Companion.getWhite-0d7_KjU(), 0.0f, 0L, 0, composer422, 48, 29);
            ComposerKt.sourceInformationMarkerEnd(composer422);
            ComposerKt.sourceInformationMarkerEnd(composer422);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            $composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            if (ComposerKt.isTraceInProgress()) {
            }
        } else {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
        }
        ScopeUpdateScope endRestartGroup = $composer2.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: com.app.verdeappweb.NetworkMonitorWebKt$$ExternalSyntheticLambda0
                public final Object invoke(Object obj, Object obj2) {
                    Unit NoInternetOverlay$lambda$2;
                    NoInternetOverlay$lambda$2 = NetworkMonitorWebKt.NoInternetOverlay$lambda$2($changed, (Composer) obj, ((Integer) obj2).intValue());
                    return NoInternetOverlay$lambda$2;
                }
            });
        }
    }
}
