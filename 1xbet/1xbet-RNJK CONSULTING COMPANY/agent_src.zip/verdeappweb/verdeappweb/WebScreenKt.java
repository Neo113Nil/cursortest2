package com.app.verdeappweb;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.compose.BackHandlerKt;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScope;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.foundation.layout.WindowInsetsPaddingKt;
import androidx.compose.foundation.layout.WindowInsets_androidKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocal;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotMutationPolicy;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.viewinterop.AndroidView_androidKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: WebScreen.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007²\u0006\f\u0010\b\u001a\u0004\u0018\u00010\tX\u008a\u008e\u0002²\u0006\n\u0010\n\u001a\u00020\u0005X\u008a\u008e\u0002"}, d2 = {"WebScreen", "", "url", "", "isConnected", "", "(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V", "app_debug", "webView", "Landroid/webkit/WebView;", "canGoBack"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class WebScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit WebScreen$lambda$14(String str, boolean z, int i, int i2, Composer composer, int i3) {
        WebScreen(str, z, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code restructure failed: missing block: B:49:0x028a, code lost:
    
        if (r12 == androidx.compose.runtime.Composer.Companion.getEmpty()) goto L73;
     */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0275  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0282  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x02bf  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x02f1  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0315  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x028e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void WebScreen(final String url, boolean isConnected, Composer $composer, final int $changed, final int i) {
        final boolean isConnected2;
        int $dirty;
        boolean isConnected3;
        Function0 function0;
        boolean changedInstance;
        Composer $composer2;
        Object rememberedValue;
        Intrinsics.checkNotNullParameter(url, "url");
        Composer $composer3 = $composer.startRestartGroup(-2106526640);
        ComposerKt.sourceInformation($composer3, "C(WebScreen)P(1)39@1377L7,40@1404L43,41@1469L34,43@1542L33,43@1509L66,50@1687L10,47@1581L4079:WebScreen.kt#rxc5dp");
        int $dirty2 = $changed;
        if ((i & 1) != 0) {
            $dirty2 |= 6;
        } else if (($changed & 6) == 0) {
            $dirty2 |= $composer3.changed(url) ? 4 : 2;
        }
        int i2 = i & 2;
        if (i2 != 0) {
            $dirty2 |= 48;
            isConnected2 = isConnected;
        } else if (($changed & 48) == 0) {
            isConnected2 = isConnected;
            $dirty2 |= $composer3.changed(isConnected2) ? 32 : 16;
        } else {
            isConnected2 = isConnected;
        }
        if (($dirty2 & 19) == 18 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
        } else {
            boolean isConnected4 = i2 != 0 ? true : isConnected2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2106526640, $dirty2, -1, "com.app.verdeappweb.WebScreen (WebScreen.kt:37)");
            }
            CompositionLocal localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            Object consume = $composer3.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            final Context context = (Context) consume;
            $composer3.startReplaceGroup(302825274);
            ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
            Object rememberedValue2 = $composer3.rememberedValue();
            if (rememberedValue2 == Composer.Companion.getEmpty()) {
                Object mutableStateOf$default = SnapshotStateKt.mutableStateOf$default((Object) null, (SnapshotMutationPolicy) null, 2, (Object) null);
                $composer3.updateRememberedValue(mutableStateOf$default);
                rememberedValue2 = mutableStateOf$default;
            }
            final MutableState webView$delegate = (MutableState) rememberedValue2;
            $composer3.endReplaceGroup();
            $composer3.startReplaceGroup(302827345);
            ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
            Object rememberedValue3 = $composer3.rememberedValue();
            if (rememberedValue3 == Composer.Companion.getEmpty()) {
                $dirty = $dirty2;
                isConnected3 = isConnected4;
                Object mutableStateOf$default2 = SnapshotStateKt.mutableStateOf$default(false, (SnapshotMutationPolicy) null, 2, (Object) null);
                $composer3.updateRememberedValue(mutableStateOf$default2);
                rememberedValue3 = mutableStateOf$default2;
            } else {
                $dirty = $dirty2;
                isConnected3 = isConnected4;
            }
            final MutableState canGoBack$delegate = (MutableState) rememberedValue3;
            $composer3.endReplaceGroup();
            boolean WebScreen$lambda$4 = WebScreen$lambda$4(canGoBack$delegate);
            $composer3.startReplaceGroup(302829680);
            ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
            Object rememberedValue4 = $composer3.rememberedValue();
            if (rememberedValue4 == Composer.Companion.getEmpty()) {
                Object obj = new Function0() { // from class: com.app.verdeappweb.WebScreenKt$$ExternalSyntheticLambda0
                    public final Object invoke() {
                        Unit WebScreen$lambda$7$lambda$6;
                        WebScreen$lambda$7$lambda$6 = WebScreenKt.WebScreen$lambda$7$lambda$6(webView$delegate);
                        return WebScreen$lambda$7$lambda$6;
                    }
                };
                $composer3.updateRememberedValue(obj);
                rememberedValue4 = obj;
            }
            $composer3.endReplaceGroup();
            BackHandlerKt.BackHandler(WebScreen$lambda$4, (Function0) rememberedValue4, $composer3, 48, 0);
            Modifier windowInsetsPadding = WindowInsetsPaddingKt.windowInsetsPadding(SizeKt.fillMaxSize$default(Modifier.Companion, 0.0f, 1, (Object) null), WindowInsets_androidKt.getSystemBars(WindowInsets.Companion, $composer3, 6));
            ComposerKt.sourceInformationMarkerStart($composer3, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
            int hashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
            CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
            Modifier materializeModifier = ComposedModifierKt.materializeModifier($composer3, windowInsetsPadding);
            Function0 constructor = ComposeUiNode.Companion.getConstructor();
            int i3 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
            if (!($composer3.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer3.startReusableNode();
            if ($composer3.getInserting()) {
                function0 = constructor;
                $composer3.createNode(function0);
            } else {
                function0 = constructor;
                $composer3.useNode();
            }
            Composer composer = Updater.constructor-impl($composer3);
            Updater.set-impl(composer, maybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.getSetMeasurePolicy());
            Updater.set-impl(composer, currentCompositionLocalMap, ComposeUiNode.Companion.getSetResolvedCompositionLocals());
            Function2 setCompositeKeyHash = ComposeUiNode.Companion.getSetCompositeKeyHash();
            if (!composer.getInserting() && Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(hashCode))) {
                Updater.set-impl(composer, materializeModifier, ComposeUiNode.Companion.getSetModifier());
                int i4 = (i3 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                BoxScope boxScope = BoxScopeInstance.INSTANCE;
                int i5 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer3, 578995475, "C57@1800L3700,152@5527L46,53@1716L3867:WebScreen.kt#rxc5dp");
                Modifier fillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.Companion, 0.0f, 1, (Object) null);
                $composer3.startReplaceGroup(-1366793598);
                ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
                changedInstance = $composer3.changedInstance(context) | (($dirty & 14) == 4);
                Object rememberedValue5 = $composer3.rememberedValue();
                if (changedInstance) {
                    $composer2 = $composer3;
                } else {
                    $composer2 = $composer3;
                }
                Object obj2 = new Function1() { // from class: com.app.verdeappweb.WebScreenKt$$ExternalSyntheticLambda1
                    public final Object invoke(Object obj3) {
                        WebView WebScreen$lambda$13$lambda$10$lambda$9;
                        WebScreen$lambda$13$lambda$10$lambda$9 = WebScreenKt.WebScreen$lambda$13$lambda$10$lambda$9(context, url, canGoBack$delegate, webView$delegate, (Context) obj3);
                        return WebScreen$lambda$13$lambda$10$lambda$9;
                    }
                };
                $composer3.updateRememberedValue(obj2);
                rememberedValue5 = obj2;
                Function1 function1 = (Function1) rememberedValue5;
                $composer3.endReplaceGroup();
                $composer3.startReplaceGroup(-1366677988);
                ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
                rememberedValue = $composer3.rememberedValue();
                if (rememberedValue != Composer.Companion.getEmpty()) {
                    Object obj3 = new Function1() { // from class: com.app.verdeappweb.WebScreenKt$$ExternalSyntheticLambda2
                        public final Object invoke(Object obj4) {
                            Unit WebScreen$lambda$13$lambda$12$lambda$11;
                            WebScreen$lambda$13$lambda$12$lambda$11 = WebScreenKt.WebScreen$lambda$13$lambda$12$lambda$11(webView$delegate, (WebView) obj4);
                            return WebScreen$lambda$13$lambda$12$lambda$11;
                        }
                    };
                    $composer3.updateRememberedValue(obj3);
                    rememberedValue = obj3;
                }
                $composer3.endReplaceGroup();
                AndroidView_androidKt.AndroidView(function1, fillMaxSize$default, (Function1) null, (Function1) rememberedValue, (Function1) null, $composer3, 3120, 20);
                $composer3.startReplaceGroup(-1366675861);
                ComposerKt.sourceInformation($composer3, "158@5625L19");
                if (!isConnected3) {
                    NetworkMonitorWebKt.NoInternetOverlay($composer3, 0);
                }
                $composer3.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                $composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer2);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                isConnected2 = isConnected3;
            }
            composer.updateRememberedValue(Integer.valueOf(hashCode));
            composer.apply(Integer.valueOf(hashCode), setCompositeKeyHash);
            Updater.set-impl(composer, materializeModifier, ComposeUiNode.Companion.getSetModifier());
            int i42 = (i3 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScope boxScope2 = BoxScopeInstance.INSTANCE;
            int i52 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, 578995475, "C57@1800L3700,152@5527L46,53@1716L3867:WebScreen.kt#rxc5dp");
            Modifier fillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.Companion, 0.0f, 1, (Object) null);
            $composer3.startReplaceGroup(-1366793598);
            ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
            changedInstance = $composer3.changedInstance(context) | (($dirty & 14) == 4);
            Object rememberedValue52 = $composer3.rememberedValue();
            if (changedInstance) {
            }
            Object obj22 = new Function1() { // from class: com.app.verdeappweb.WebScreenKt$$ExternalSyntheticLambda1
                public final Object invoke(Object obj32) {
                    WebView WebScreen$lambda$13$lambda$10$lambda$9;
                    WebScreen$lambda$13$lambda$10$lambda$9 = WebScreenKt.WebScreen$lambda$13$lambda$10$lambda$9(context, url, canGoBack$delegate, webView$delegate, (Context) obj32);
                    return WebScreen$lambda$13$lambda$10$lambda$9;
                }
            };
            $composer3.updateRememberedValue(obj22);
            rememberedValue52 = obj22;
            Function1 function12 = (Function1) rememberedValue52;
            $composer3.endReplaceGroup();
            $composer3.startReplaceGroup(-1366677988);
            ComposerKt.sourceInformation($composer3, "CC(remember):WebScreen.kt#9igjgp");
            rememberedValue = $composer3.rememberedValue();
            if (rememberedValue != Composer.Companion.getEmpty()) {
            }
            $composer3.endReplaceGroup();
            AndroidView_androidKt.AndroidView(function12, fillMaxSize$default2, (Function1) null, (Function1) rememberedValue, (Function1) null, $composer3, 3120, 20);
            $composer3.startReplaceGroup(-1366675861);
            ComposerKt.sourceInformation($composer3, "158@5625L19");
            if (!isConnected3) {
            }
            $composer3.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            $composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            if (ComposerKt.isTraceInProgress()) {
            }
            isConnected2 = isConnected3;
        }
        ScopeUpdateScope endRestartGroup = $composer2.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: com.app.verdeappweb.WebScreenKt$$ExternalSyntheticLambda3
                public final Object invoke(Object obj4, Object obj5) {
                    Unit WebScreen$lambda$14;
                    WebScreen$lambda$14 = WebScreenKt.WebScreen$lambda$14(url, isConnected2, $changed, i, (Composer) obj4, ((Integer) obj5).intValue());
                    return WebScreen$lambda$14;
                }
            });
        }
    }

    private static final WebView WebScreen$lambda$1(MutableState<WebView> mutableState) {
        return (WebView) ((State) mutableState).getValue();
    }

    private static final boolean WebScreen$lambda$4(MutableState<Boolean> mutableState) {
        return ((Boolean) ((State) mutableState).getValue()).booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void WebScreen$lambda$5(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit WebScreen$lambda$7$lambda$6(MutableState $webView$delegate) {
        WebView WebScreen$lambda$1 = WebScreen$lambda$1($webView$delegate);
        if (WebScreen$lambda$1 != null) {
            WebScreen$lambda$1.goBack();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final WebView WebScreen$lambda$13$lambda$10$lambda$9(Context $context, String $url, final MutableState $canGoBack$delegate, MutableState $webView$delegate, Context it) {
        Intrinsics.checkNotNullParameter(it, "it");
        WebView webView = new WebView($context);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setCacheMode(-1);
        webView.getSettings().setUserAgentString("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1");
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() { // from class: com.app.verdeappweb.WebScreenKt$WebScreen$2$1$1$1$1
            @Override // android.webkit.WebViewClient
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d("WEBVIEW", "Started = " + url);
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d("WEBVIEW", "Finished = " + url);
                MutableState<Boolean> mutableState = $canGoBack$delegate;
                boolean z = false;
                if (view != null && view.canGoBack()) {
                    z = true;
                }
                WebScreenKt.WebScreen$lambda$5(mutableState, z);
                CookieManager.getInstance().flush();
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Log.e("WEBVIEW", "Error " + (error != null ? Integer.valueOf(error.getErrorCode()) : null) + " " + ((Object) (error != null ? error.getDescription() : null)));
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                Log.e("WEBVIEW", "HTTP " + (errorResponse != null ? Integer.valueOf(errorResponse.getStatusCode()) : null));
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                Log.e("WEBVIEW", "SSL " + (error != null ? Integer.valueOf(error.getPrimaryError()) : null));
                if (handler != null) {
                    handler.proceed();
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() { // from class: com.app.verdeappweb.WebScreenKt$WebScreen$2$1$1$1$2
            @Override // android.webkit.WebChromeClient
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Intrinsics.checkNotNullParameter(consoleMessage, "consoleMessage");
                Log.d("JS", consoleMessage.message() + " @ " + consoleMessage.lineNumber());
                return true;
            }
        });
        webView.loadUrl($url);
        $webView$delegate.setValue(webView);
        return webView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit WebScreen$lambda$13$lambda$12$lambda$11(MutableState $webView$delegate, WebView it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $webView$delegate.setValue(null);
        return Unit.INSTANCE;
    }
}
