package com.app.verdeappweb;

import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.StateFlow;

/* compiled from: NetworkMonitorWeb.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\t¨\u0006\f"}, d2 = {"Lcom/app/verdeappweb/NetworkViewModel;", "Landroidx/lifecycle/ViewModel;", "monitor", "Lcom/app/verdeappweb/NetworkMonitor;", "<init>", "(Lcom/app/verdeappweb/NetworkMonitor;)V", "isConnected", "Lkotlinx/coroutines/flow/StateFlow;", "", "()Lkotlinx/coroutines/flow/StateFlow;", "onCleared", "", "app_debug"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class NetworkViewModel extends ViewModel {
    public static final int $stable = 8;
    private final StateFlow<Boolean> isConnected;
    private final NetworkMonitor monitor;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public NetworkViewModel() {
        this(r0, 1, r0);
        NetworkMonitor networkMonitor = null;
    }

    public /* synthetic */ NetworkViewModel(NetworkMonitor networkMonitor, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? NetworkMonitorWebKt.createNetworkMonitor() : networkMonitor);
    }

    public NetworkViewModel(NetworkMonitor monitor) {
        Intrinsics.checkNotNullParameter(monitor, "monitor");
        this.monitor = monitor;
        this.isConnected = this.monitor.isConnected();
        this.monitor.start();
    }

    public final StateFlow<Boolean> isConnected() {
        return this.isConnected;
    }

    protected void onCleared() {
        this.monitor.stop();
        super.onCleared();
    }
}
