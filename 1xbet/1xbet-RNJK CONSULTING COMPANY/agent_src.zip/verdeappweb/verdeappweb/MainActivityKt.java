package com.app.verdeappweb;

import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import com.app.verdeappweb.ui.theme.ThemeKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: MainActivity.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a\r\u0010\u0007\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\b¨\u0006\t"}, d2 = {"Greeting", "", "name", "", "modifier", "Landroidx/compose/ui/Modifier;", "(Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "GreetingPreview", "(Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: /tmp/webscreen.dex */
public final class MainActivityKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit Greeting$lambda$0(String str, Modifier modifier, int i, int i2, Composer composer, int i3) {
        Greeting(str, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit GreetingPreview$lambda$1(int i, Composer composer, int i2) {
        GreetingPreview(composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void Greeting(final String name, Modifier modifier, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        final Modifier modifier3;
        Composer $composer2;
        Intrinsics.checkNotNullParameter(name, "name");
        Composer $composer3 = $composer.startRestartGroup(-1882566588);
        ComposerKt.sourceInformation($composer3, "C(Greeting)P(1)34@1140L70:MainActivity.kt#rxc5dp");
        int $dirty = $changed;
        if ((i & 1) != 0) {
            $dirty |= 6;
        } else if (($changed & 6) == 0) {
            $dirty |= $composer3.changed(name) ? 4 : 2;
        }
        int i2 = i & 2;
        if (i2 != 0) {
            $dirty |= 48;
            modifier2 = modifier;
        } else if (($changed & 48) == 0) {
            modifier2 = modifier;
            $dirty |= $composer3.changed(modifier2) ? 32 : 16;
        } else {
            modifier2 = modifier;
        }
        if (($dirty & 19) != 18 || !$composer3.getSkipping()) {
            Modifier modifier4 = i2 != 0 ? (Modifier) Modifier.Companion : modifier2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1882566588, $dirty, -1, "com.app.verdeappweb.Greeting (MainActivity.kt:33)");
            }
            int i3 = $dirty & 112;
            modifier3 = modifier4;
            $composer2 = $composer3;
            TextKt.Text--4IGK_g("Hello " + name + "!", modifier3, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, (TextStyle) null, $composer2, i3, 0, 131068);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
            modifier3 = modifier2;
        }
        ScopeUpdateScope endRestartGroup = $composer2.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: com.app.verdeappweb.MainActivityKt$$ExternalSyntheticLambda0
                public final Object invoke(Object obj, Object obj2) {
                    Unit Greeting$lambda$0;
                    Greeting$lambda$0 = MainActivityKt.Greeting$lambda$0(name, modifier3, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                    return Greeting$lambda$0;
                }
            });
        }
    }

    public static final void GreetingPreview(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(1702415962);
        ComposerKt.sourceInformation($composer2, "C(GreetingPreview)43@1286L52:MainActivity.kt#rxc5dp");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1702415962, $changed, -1, "com.app.verdeappweb.GreetingPreview (MainActivity.kt:42)");
            }
            ThemeKt.VerdeAppWebTheme(false, false, ComposableSingletons$MainActivityKt.INSTANCE.m4getLambda4$app_debug(), $composer2, 384, 3);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope endRestartGroup = $composer2.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: com.app.verdeappweb.MainActivityKt$$ExternalSyntheticLambda1
                public final Object invoke(Object obj, Object obj2) {
                    Unit GreetingPreview$lambda$1;
                    GreetingPreview$lambda$1 = MainActivityKt.GreetingPreview$lambda$1($changed, (Composer) obj, ((Integer) obj2).intValue());
                    return GreetingPreview$lambda$1;
                }
            });
        }
    }
}
