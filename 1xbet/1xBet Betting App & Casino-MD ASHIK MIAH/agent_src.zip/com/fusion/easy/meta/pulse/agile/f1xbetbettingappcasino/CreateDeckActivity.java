package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.CreateDeckActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.R;
import com.google.android.material.appbar.MaterialToolbar;
import defpackage.a6;
import defpackage.b0;
import defpackage.dc;
import defpackage.h9;
import defpackage.i;
import defpackage.i7;
import defpackage.ii;
import defpackage.j0;
import defpackage.l9;
import defpackage.md;
import defpackage.qd;
import defpackage.rd;
import defpackage.x9;
import defpackage.y1;
import defpackage.zc;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class CreateDeckActivity extends y1 {
    public static final /* synthetic */ int I = 0;
    public j0 B;
    public rd C;
    public int D = -1;
    public String E = "📚";
    public x9 F = x9.c;
    public final ArrayList G = new ArrayList();
    public final ArrayList H = new ArrayList();

    public CreateDeckActivity() {
        Math.abs(-24);
        Math.abs(13);
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x006d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void A() {
        zc zcVar = x9.l;
        zcVar.getClass();
        i.b bVar = new i.b();
        int i = 0;
        while (bVar.hasNext()) {
            Object next = bVar.next();
            int i2 = i + 1;
            if (i < 0) {
                i7.F();
                throw null;
            }
            x9 x9Var = (x9) next;
            View view = (View) this.H.get(i);
            boolean z = x9Var == this.F;
            view.setBackground(z(Color.parseColor(x9Var.a), z));
            if (z) {
                rd rdVar = this.C;
                if (rdVar == null) {
                    ii.d("prefs");
                    throw null;
                }
                if (rdVar.a()) {
                    view.animate().scaleX(1.3f).scaleY(1.3f).setDuration(160L).withEndAction(new h9(view, 0)).start();
                }
            } else {
                view.setScaleX(1.0f);
                view.setScaleY(1.0f);
            }
            i = i2;
        }
    }

    public final void B() {
        ArrayList arrayList = this.G;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            TextView textView = (TextView) obj;
            boolean zA = ii.a(textView.getText().toString(), this.E);
            textView.setBackground(getDrawable(zA ? R.drawable.chip_active : R.drawable.chip_inactive));
            if (zA) {
                rd rdVar = this.C;
                if (rdVar == null) {
                    ii.d("prefs");
                    throw null;
                }
                if (rdVar.a()) {
                    textView.animate().scaleX(1.2f).scaleY(1.2f).setDuration(180L).start();
                }
            }
            textView.setScaleX(1.0f);
            textView.setScaleY(1.0f);
        }
    }

    public final void C() {
        j0 j0Var = this.B;
        if (j0Var == null) {
            ii.d("binding");
            throw null;
        }
        j0Var.h.setText(this.E);
        j0 j0Var2 = this.B;
        if (j0Var2 == null) {
            ii.d("binding");
            throw null;
        }
        Editable text = j0Var2.e.getText();
        String string = text != null ? text.toString() : null;
        if (string == null) {
            string = "";
        }
        j0 j0Var3 = this.B;
        if (j0Var3 == null) {
            ii.d("binding");
            throw null;
        }
        TextView textView = j0Var3.i;
        if (string.length() == 0) {
            string = getString(R.string.deck_preview_placeholder);
            string.getClass();
        }
        textView.setText(string);
        j0 j0Var4 = this.B;
        if (j0Var4 != null) {
            j0Var4.f.setCardBackgroundColor(Color.parseColor(this.F.a));
        } else {
            ii.d("binding");
            throw null;
        }
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        Object obj;
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_create_deck, (ViewGroup) null, false);
        int i2 = R.id.btnCreate;
        Button button = (Button) dc.p(viewInflate, R.id.btnCreate);
        if (button != null) {
            i2 = R.id.colorRow;
            LinearLayout linearLayout = (LinearLayout) dc.p(viewInflate, R.id.colorRow);
            if (linearLayout != null) {
                i2 = R.id.emojiGrid;
                GridLayout gridLayout = (GridLayout) dc.p(viewInflate, R.id.emojiGrid);
                if (gridLayout != null) {
                    i2 = R.id.inputDesc;
                    EditText editText = (EditText) dc.p(viewInflate, R.id.inputDesc);
                    if (editText != null) {
                        i2 = R.id.inputName;
                        EditText editText2 = (EditText) dc.p(viewInflate, R.id.inputName);
                        if (editText2 != null) {
                            i2 = R.id.previewCard;
                            CardView cardView = (CardView) dc.p(viewInflate, R.id.previewCard);
                            if (cardView != null) {
                                i2 = R.id.toolbar;
                                MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                if (materialToolbar != null) {
                                    i2 = R.id.txtPreviewEmoji;
                                    TextView textView = (TextView) dc.p(viewInflate, R.id.txtPreviewEmoji);
                                    if (textView != null) {
                                        i2 = R.id.txtPreviewName;
                                        TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtPreviewName);
                                        if (textView2 != null) {
                                            LinearLayout linearLayout2 = (LinearLayout) viewInflate;
                                            this.B = new j0(linearLayout2, button, linearLayout, gridLayout, editText, editText2, cardView, materialToolbar, textView, textView2);
                                            setContentView(linearLayout2);
                                            this.C = new rd(this);
                                            this.D = getIntent().getIntExtra(qd.a, -1);
                                            j0 j0Var = this.B;
                                            if (j0Var == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            y(j0Var.g);
                                            b0 b0VarX = x();
                                            final int i3 = 1;
                                            if (b0VarX != null) {
                                                b0VarX.m(true);
                                            }
                                            j0 j0Var2 = this.B;
                                            if (j0Var2 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            j0Var2.g.setNavigationOnClickListener(new View.OnClickListener(this) { // from class: g9
                                                public final /* synthetic */ CreateDeckActivity b;

                                                {
                                                    this.b = this;
                                                }

                                                @Override // android.view.View.OnClickListener
                                                public final void onClick(View view) {
                                                    String string;
                                                    String string2;
                                                    int i4 = i;
                                                    CreateDeckActivity createDeckActivity = this.b;
                                                    switch (i4) {
                                                        case 0:
                                                            int i5 = CreateDeckActivity.I;
                                                            createDeckActivity.finish();
                                                            return;
                                                        default:
                                                            j0 j0Var3 = createDeckActivity.B;
                                                            if (j0Var3 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            Editable text = j0Var3.e.getText();
                                                            String string3 = (text == null || (string2 = text.toString()) == null) ? null : ws.c0(string2).toString();
                                                            if (string3 == null) {
                                                                string3 = "";
                                                            }
                                                            if (string3.length() == 0) {
                                                                Toast.makeText(createDeckActivity, createDeckActivity.getString(R.string.error_deck_name), 0).show();
                                                                return;
                                                            }
                                                            j0 j0Var4 = createDeckActivity.B;
                                                            if (j0Var4 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            Editable text2 = j0Var4.d.getText();
                                                            String string4 = (text2 == null || (string = text2.toString()) == null) ? null : ws.c0(string).toString();
                                                            if (string4 == null) {
                                                                string4 = "";
                                                            }
                                                            int iIntValue = createDeckActivity.D;
                                                            if (iIntValue == -1) {
                                                                rd rdVar = createDeckActivity.C;
                                                                if (rdVar == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                String string5 = rdVar.a.getString("custom_deck_ids", null);
                                                                if (string5 == null) {
                                                                    string5 = "";
                                                                }
                                                                List listK = rd.k(string5);
                                                                if (listK.isEmpty()) {
                                                                    iIntValue = 1001;
                                                                } else {
                                                                    Integer num = (Integer) o7.L(listK);
                                                                    iIntValue = (num != null ? num.intValue() : 1000) + 1;
                                                                }
                                                            }
                                                            rd rdVar2 = createDeckActivity.C;
                                                            if (rdVar2 == null) {
                                                                ii.d("prefs");
                                                                throw null;
                                                            }
                                                            String str = createDeckActivity.E;
                                                            String str2 = createDeckActivity.F.a;
                                                            str.getClass();
                                                            SharedPreferences sharedPreferences = rdVar2.a;
                                                            String string6 = sharedPreferences.getString("custom_deck_ids", null);
                                                            ArrayList arrayList = new ArrayList(rd.k(string6 != null ? string6 : ""));
                                                            if (!arrayList.contains(Integer.valueOf(iIntValue))) {
                                                                arrayList.add(Integer.valueOf(iIntValue));
                                                            }
                                                            sharedPreferences.edit().putString("custom_deck_ids", o7.K(arrayList, ",", null, 62)).putString("deck_name_" + iIntValue, string3).putString("deck_emoji_" + iIntValue, str).putString("deck_color_" + iIntValue, str2).putString("deck_desc_" + iIntValue, string4).apply();
                                                            createDeckActivity.setResult(-1);
                                                            createDeckActivity.finish();
                                                            return;
                                                    }
                                                }
                                            });
                                            j0 j0Var3 = this.B;
                                            if (j0Var3 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            j0Var3.g.setTitle(this.D == -1 ? getString(R.string.title_new_deck) : getString(R.string.title_edit_deck));
                                            int i4 = this.D;
                                            j0 j0Var4 = this.B;
                                            if (i4 == -1) {
                                                if (j0Var4 == null) {
                                                    ii.d("binding");
                                                    throw null;
                                                }
                                                j0Var4.a.setText(getString(R.string.btn_create_deck));
                                            } else {
                                                if (j0Var4 == null) {
                                                    ii.d("binding");
                                                    throw null;
                                                }
                                                j0Var4.a.setText(getString(R.string.btn_save));
                                            }
                                            for (String str : i7.E("📚", "🧠", "🔤", "🌍", "✈", "🔬", "🎵", "🏋", "🍔", "🎨", "🐾", "🌿", "🔢", "💡", "🗺", "🎸", "🧩", "🚀", "🌊", "🔮", "🃏", "📝", "🎯", "🧪", "🦋", "🏛", "🎭", "🔑", "🌙", "⭐")) {
                                                TextView textView3 = new TextView(this);
                                                GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                                                layoutParams.width = 0;
                                                layoutParams.height = (int) (48.0f * getResources().getDisplayMetrics().density);
                                                layoutParams.columnSpec = GridLayout.spec(Integer.MIN_VALUE, 1.0f);
                                                layoutParams.setMargins(4, 4, 4, 4);
                                                textView3.setLayoutParams(layoutParams);
                                                textView3.setText(str);
                                                textView3.setTextSize(22.0f);
                                                textView3.setGravity(17);
                                                textView3.setBackground(getDrawable(R.drawable.chip_inactive));
                                                textView3.setOnClickListener(new a6(this, str, i3));
                                                this.G.add(textView3);
                                                j0 j0Var5 = this.B;
                                                if (j0Var5 == null) {
                                                    ii.d("binding");
                                                    throw null;
                                                }
                                                j0Var5.c.addView(textView3);
                                            }
                                            B();
                                            zc zcVar = x9.l;
                                            zcVar.getClass();
                                            i.b bVar = new i.b();
                                            while (bVar.hasNext()) {
                                                x9 x9Var = (x9) bVar.next();
                                                View view = new View(this);
                                                int i5 = (int) (36.0f * getResources().getDisplayMetrics().density);
                                                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i5, i5);
                                                layoutParams2.setMarginStart(6);
                                                layoutParams2.setMarginEnd(6);
                                                view.setLayoutParams(layoutParams2);
                                                view.setBackground(z(Color.parseColor(x9Var.a), false));
                                                view.setOnClickListener(new a6(this, x9Var, 2));
                                                this.H.add(view);
                                                j0 j0Var6 = this.B;
                                                if (j0Var6 == null) {
                                                    ii.d("binding");
                                                    throw null;
                                                }
                                                j0Var6.b.addView(view);
                                            }
                                            A();
                                            if (this.D != -1) {
                                                rd rdVar = this.C;
                                                if (rdVar == null) {
                                                    ii.d("prefs");
                                                    throw null;
                                                }
                                                ArrayList arrayListF = rdVar.f();
                                                int size = arrayListF.size();
                                                while (true) {
                                                    if (i >= size) {
                                                        obj = null;
                                                        break;
                                                    }
                                                    obj = arrayListF.get(i);
                                                    i++;
                                                    if (((l9) obj).a == this.D) {
                                                        break;
                                                    }
                                                }
                                                l9 l9Var = (l9) obj;
                                                if (l9Var != null) {
                                                    j0 j0Var7 = this.B;
                                                    if (j0Var7 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    j0Var7.e.setText(l9Var.b);
                                                    j0 j0Var8 = this.B;
                                                    if (j0Var8 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    j0Var8.d.setText(l9Var.e);
                                                    this.E = l9Var.c;
                                                    String str2 = l9Var.d;
                                                    x9.b.getClass();
                                                    this.F = x9.a.a(str2);
                                                    C();
                                                    B();
                                                    A();
                                                }
                                            }
                                            j0 j0Var9 = this.B;
                                            if (j0Var9 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            j0Var9.e.addTextChangedListener(new a());
                                            j0 j0Var10 = this.B;
                                            if (j0Var10 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            j0Var10.a.setOnClickListener(new View.OnClickListener(this) { // from class: g9
                                                public final /* synthetic */ CreateDeckActivity b;

                                                {
                                                    this.b = this;
                                                }

                                                @Override // android.view.View.OnClickListener
                                                public final void onClick(View view2) {
                                                    String string;
                                                    String string2;
                                                    int i42 = i3;
                                                    CreateDeckActivity createDeckActivity = this.b;
                                                    switch (i42) {
                                                        case 0:
                                                            int i52 = CreateDeckActivity.I;
                                                            createDeckActivity.finish();
                                                            return;
                                                        default:
                                                            j0 j0Var32 = createDeckActivity.B;
                                                            if (j0Var32 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            Editable text = j0Var32.e.getText();
                                                            String string3 = (text == null || (string2 = text.toString()) == null) ? null : ws.c0(string2).toString();
                                                            if (string3 == null) {
                                                                string3 = "";
                                                            }
                                                            if (string3.length() == 0) {
                                                                Toast.makeText(createDeckActivity, createDeckActivity.getString(R.string.error_deck_name), 0).show();
                                                                return;
                                                            }
                                                            j0 j0Var42 = createDeckActivity.B;
                                                            if (j0Var42 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            Editable text2 = j0Var42.d.getText();
                                                            String string4 = (text2 == null || (string = text2.toString()) == null) ? null : ws.c0(string).toString();
                                                            if (string4 == null) {
                                                                string4 = "";
                                                            }
                                                            int iIntValue = createDeckActivity.D;
                                                            if (iIntValue == -1) {
                                                                rd rdVar2 = createDeckActivity.C;
                                                                if (rdVar2 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                String string5 = rdVar2.a.getString("custom_deck_ids", null);
                                                                if (string5 == null) {
                                                                    string5 = "";
                                                                }
                                                                List listK = rd.k(string5);
                                                                if (listK.isEmpty()) {
                                                                    iIntValue = 1001;
                                                                } else {
                                                                    Integer num = (Integer) o7.L(listK);
                                                                    iIntValue = (num != null ? num.intValue() : 1000) + 1;
                                                                }
                                                            }
                                                            rd rdVar22 = createDeckActivity.C;
                                                            if (rdVar22 == null) {
                                                                ii.d("prefs");
                                                                throw null;
                                                            }
                                                            String str3 = createDeckActivity.E;
                                                            String str22 = createDeckActivity.F.a;
                                                            str3.getClass();
                                                            SharedPreferences sharedPreferences = rdVar22.a;
                                                            String string6 = sharedPreferences.getString("custom_deck_ids", null);
                                                            ArrayList arrayList = new ArrayList(rd.k(string6 != null ? string6 : ""));
                                                            if (!arrayList.contains(Integer.valueOf(iIntValue))) {
                                                                arrayList.add(Integer.valueOf(iIntValue));
                                                            }
                                                            sharedPreferences.edit().putString("custom_deck_ids", o7.K(arrayList, ",", null, 62)).putString("deck_name_" + iIntValue, string3).putString("deck_emoji_" + iIntValue, str3).putString("deck_color_" + iIntValue, str22).putString("deck_desc_" + iIntValue, string4).apply();
                                                            createDeckActivity.setResult(-1);
                                                            createDeckActivity.finish();
                                                            return;
                                                    }
                                                }
                                            });
                                            C();
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    public final GradientDrawable z(int i, boolean z) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(i);
        if (z) {
            gradientDrawable.setStroke((int) (3.0f * getResources().getDisplayMetrics().density), -1);
        }
        return gradientDrawable;
    }

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a implements TextWatcher {
        public a() {
        }

        @Override // android.text.TextWatcher
        public final void afterTextChanged(Editable editable) {
            String string = editable != null ? editable.toString() : null;
            if (string == null) {
                string = "";
            }
            CreateDeckActivity createDeckActivity = CreateDeckActivity.this;
            j0 j0Var = createDeckActivity.B;
            if (j0Var == null) {
                ii.d("binding");
                throw null;
            }
            TextView textView = j0Var.i;
            if (string.length() == 0) {
                string = createDeckActivity.getString(R.string.deck_preview_placeholder);
                string.getClass();
            }
            textView.setText(string);
        }

        @Override // android.text.TextWatcher
        public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }
}
