package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.R;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.SettingsActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.switchmaterial.SwitchMaterial;
import defpackage.b0;
import defpackage.d4;
import defpackage.dc;
import defpackage.fr;
import defpackage.i0;
import defpackage.i7;
import defpackage.ii;
import defpackage.md;
import defpackage.rd;
import defpackage.ws;
import defpackage.y1;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class SettingsActivity extends y1 {
    public static final /* synthetic */ int E = 0;
    public i0 B;
    public rd C;
    public final List<Integer> D = i7.E(10, 20, 30, 50, 100);

    public SettingsActivity() {
        ws.c0("sample").toString();
        ws.c0("sample").toString();
        System.currentTimeMillis();
        Math.max(49, 32);
        ws.c0("sample").toString();
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) throws Resources.NotFoundException {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_settings, (ViewGroup) null, false);
        int i2 = R.id.btnAbout;
        Button button = (Button) dc.p(viewInflate, R.id.btnAbout);
        if (button != null) {
            i2 = R.id.btnDeleteCustom;
            Button button2 = (Button) dc.p(viewInflate, R.id.btnDeleteCustom);
            if (button2 != null) {
                i2 = R.id.btnResetAchievements;
                Button button3 = (Button) dc.p(viewInflate, R.id.btnResetAchievements);
                if (button3 != null) {
                    i2 = R.id.btnResetProgress;
                    Button button4 = (Button) dc.p(viewInflate, R.id.btnResetProgress);
                    if (button4 != null) {
                        i2 = R.id.spinnerGoal;
                        Spinner spinner = (Spinner) dc.p(viewInflate, R.id.spinnerGoal);
                        if (spinner != null) {
                            i2 = R.id.switchAnimations;
                            SwitchMaterial switchMaterial = (SwitchMaterial) dc.p(viewInflate, R.id.switchAnimations);
                            if (switchMaterial != null) {
                                i2 = R.id.switchFlip;
                                SwitchMaterial switchMaterial2 = (SwitchMaterial) dc.p(viewInflate, R.id.switchFlip);
                                if (switchMaterial2 != null) {
                                    i2 = R.id.switchHints;
                                    SwitchMaterial switchMaterial3 = (SwitchMaterial) dc.p(viewInflate, R.id.switchHints);
                                    if (switchMaterial3 != null) {
                                        i2 = R.id.switchLevel;
                                        SwitchMaterial switchMaterial4 = (SwitchMaterial) dc.p(viewInflate, R.id.switchLevel);
                                        if (switchMaterial4 != null) {
                                            i2 = R.id.switchShuffle;
                                            SwitchMaterial switchMaterial5 = (SwitchMaterial) dc.p(viewInflate, R.id.switchShuffle);
                                            if (switchMaterial5 != null) {
                                                i2 = R.id.toolbar;
                                                MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                                if (materialToolbar != null) {
                                                    LinearLayout linearLayout = (LinearLayout) viewInflate;
                                                    this.B = new i0(linearLayout, button, button2, button3, button4, spinner, switchMaterial, switchMaterial2, switchMaterial3, switchMaterial4, switchMaterial5, materialToolbar);
                                                    setContentView(linearLayout);
                                                    this.C = new rd(this);
                                                    i0 i0Var = this.B;
                                                    if (i0Var == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    y(i0Var.c);
                                                    b0 b0VarX = x();
                                                    final int i3 = 1;
                                                    if (b0VarX != null) {
                                                        b0VarX.m(true);
                                                    }
                                                    i0 i0Var2 = this.B;
                                                    if (i0Var2 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    i0Var2.c.setNavigationOnClickListener(new View.OnClickListener(this) { // from class: dr
                                                        public final /* synthetic */ SettingsActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i4 = i;
                                                            SettingsActivity settingsActivity = this.b;
                                                            switch (i4) {
                                                                case 0:
                                                                    int i5 = SettingsActivity.E;
                                                                    settingsActivity.finish();
                                                                    break;
                                                                case 1:
                                                                    int i6 = SettingsActivity.E;
                                                                    b.a aVar = new b.a(settingsActivity);
                                                                    aVar.d(R.string.dialog_reset_progress_title);
                                                                    AlertController.b bVar = aVar.a;
                                                                    bVar.f = bVar.a.getText(R.string.dialog_reset_progress_msg);
                                                                    aVar.c(new er(settingsActivity, 2));
                                                                    aVar.b();
                                                                    aVar.e();
                                                                    break;
                                                                case 2:
                                                                    int i7 = SettingsActivity.E;
                                                                    b.a aVar2 = new b.a(settingsActivity);
                                                                    aVar2.d(R.string.dialog_delete_decks_title);
                                                                    AlertController.b bVar2 = aVar2.a;
                                                                    bVar2.f = bVar2.a.getText(R.string.dialog_delete_decks_msg);
                                                                    aVar2.c(new er(settingsActivity, 0));
                                                                    aVar2.b();
                                                                    aVar2.e();
                                                                    break;
                                                                case 3:
                                                                    int i8 = SettingsActivity.E;
                                                                    b.a aVar3 = new b.a(settingsActivity);
                                                                    aVar3.d(R.string.dialog_reset_ach_title);
                                                                    AlertController.b bVar3 = aVar3.a;
                                                                    bVar3.f = bVar3.a.getText(R.string.dialog_reset_ach_msg);
                                                                    aVar3.c(new er(settingsActivity, 1));
                                                                    aVar3.b();
                                                                    aVar3.e();
                                                                    break;
                                                                default:
                                                                    int i9 = SettingsActivity.E;
                                                                    b.a aVar4 = new b.a(settingsActivity);
                                                                    aVar4.d(R.string.about_title);
                                                                    aVar4.a.f = settingsActivity.getString(R.string.about_message, "1.0");
                                                                    aVar4.c(null);
                                                                    aVar4.e();
                                                                    break;
                                                            }
                                                        }
                                                    });
                                                    String[] stringArray = getResources().getStringArray(R.array.daily_goal_labels);
                                                    stringArray.getClass();
                                                    List listG = d4.G(stringArray);
                                                    i0 i0Var3 = this.B;
                                                    if (i0Var3 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((Spinner) i0Var3.k).setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listG));
                                                    rd rdVar = this.C;
                                                    if (rdVar == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    int iIndexOf = this.D.indexOf(Integer.valueOf(rdVar.a.getInt("daily_goal", 20)));
                                                    if (iIndexOf < 0) {
                                                        iIndexOf = 0;
                                                    }
                                                    i0 i0Var4 = this.B;
                                                    if (i0Var4 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((Spinner) i0Var4.k).setSelection(iIndexOf);
                                                    i0 i0Var5 = this.B;
                                                    if (i0Var5 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((Spinner) i0Var5.k).setOnItemSelectedListener(new a());
                                                    i0 i0Var6 = this.B;
                                                    if (i0Var6 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    SwitchMaterial switchMaterial6 = (SwitchMaterial) i0Var6.j;
                                                    rd rdVar2 = this.C;
                                                    if (rdVar2 == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    switchMaterial6.setChecked(rdVar2.a.getBoolean("show_hints", true));
                                                    i0 i0Var7 = this.B;
                                                    if (i0Var7 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    SwitchMaterial switchMaterial7 = (SwitchMaterial) i0Var7.e;
                                                    rd rdVar3 = this.C;
                                                    if (rdVar3 == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    switchMaterial7.setChecked(rdVar3.a.getBoolean("shuffle_cards", true));
                                                    i0 i0Var8 = this.B;
                                                    if (i0Var8 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    SwitchMaterial switchMaterial8 = (SwitchMaterial) i0Var8.i;
                                                    rd rdVar4 = this.C;
                                                    if (rdVar4 == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    switchMaterial8.setChecked(rdVar4.a.getBoolean("flip_animation", true));
                                                    i0 i0Var9 = this.B;
                                                    if (i0Var9 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    SwitchMaterial switchMaterial9 = (SwitchMaterial) i0Var9.h;
                                                    rd rdVar5 = this.C;
                                                    if (rdVar5 == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    switchMaterial9.setChecked(rdVar5.a());
                                                    i0 i0Var10 = this.B;
                                                    if (i0Var10 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    SwitchMaterial switchMaterial10 = (SwitchMaterial) i0Var10.d;
                                                    rd rdVar6 = this.C;
                                                    if (rdVar6 == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    switchMaterial10.setChecked(rdVar6.a.getBoolean("show_level", true));
                                                    i0 i0Var11 = this.B;
                                                    if (i0Var11 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((SwitchMaterial) i0Var11.j).setOnCheckedChangeListener(new fr(this, 0));
                                                    i0 i0Var12 = this.B;
                                                    if (i0Var12 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((SwitchMaterial) i0Var12.e).setOnCheckedChangeListener(new fr(this, 1));
                                                    i0 i0Var13 = this.B;
                                                    if (i0Var13 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    final int i4 = 2;
                                                    ((SwitchMaterial) i0Var13.i).setOnCheckedChangeListener(new fr(this, 2));
                                                    i0 i0Var14 = this.B;
                                                    if (i0Var14 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    final int i5 = 3;
                                                    ((SwitchMaterial) i0Var14.h).setOnCheckedChangeListener(new fr(this, 3));
                                                    i0 i0Var15 = this.B;
                                                    if (i0Var15 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    final int i6 = 4;
                                                    ((SwitchMaterial) i0Var15.d).setOnCheckedChangeListener(new fr(this, 4));
                                                    i0 i0Var16 = this.B;
                                                    if (i0Var16 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((Button) i0Var16.g).setOnClickListener(new View.OnClickListener(this) { // from class: dr
                                                        public final /* synthetic */ SettingsActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i42 = i3;
                                                            SettingsActivity settingsActivity = this.b;
                                                            switch (i42) {
                                                                case 0:
                                                                    int i52 = SettingsActivity.E;
                                                                    settingsActivity.finish();
                                                                    break;
                                                                case 1:
                                                                    int i62 = SettingsActivity.E;
                                                                    b.a aVar = new b.a(settingsActivity);
                                                                    aVar.d(R.string.dialog_reset_progress_title);
                                                                    AlertController.b bVar = aVar.a;
                                                                    bVar.f = bVar.a.getText(R.string.dialog_reset_progress_msg);
                                                                    aVar.c(new er(settingsActivity, 2));
                                                                    aVar.b();
                                                                    aVar.e();
                                                                    break;
                                                                case 2:
                                                                    int i7 = SettingsActivity.E;
                                                                    b.a aVar2 = new b.a(settingsActivity);
                                                                    aVar2.d(R.string.dialog_delete_decks_title);
                                                                    AlertController.b bVar2 = aVar2.a;
                                                                    bVar2.f = bVar2.a.getText(R.string.dialog_delete_decks_msg);
                                                                    aVar2.c(new er(settingsActivity, 0));
                                                                    aVar2.b();
                                                                    aVar2.e();
                                                                    break;
                                                                case 3:
                                                                    int i8 = SettingsActivity.E;
                                                                    b.a aVar3 = new b.a(settingsActivity);
                                                                    aVar3.d(R.string.dialog_reset_ach_title);
                                                                    AlertController.b bVar3 = aVar3.a;
                                                                    bVar3.f = bVar3.a.getText(R.string.dialog_reset_ach_msg);
                                                                    aVar3.c(new er(settingsActivity, 1));
                                                                    aVar3.b();
                                                                    aVar3.e();
                                                                    break;
                                                                default:
                                                                    int i9 = SettingsActivity.E;
                                                                    b.a aVar4 = new b.a(settingsActivity);
                                                                    aVar4.d(R.string.about_title);
                                                                    aVar4.a.f = settingsActivity.getString(R.string.about_message, "1.0");
                                                                    aVar4.c(null);
                                                                    aVar4.e();
                                                                    break;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var17 = this.B;
                                                    if (i0Var17 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    i0Var17.b.setOnClickListener(new View.OnClickListener(this) { // from class: dr
                                                        public final /* synthetic */ SettingsActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i42 = i4;
                                                            SettingsActivity settingsActivity = this.b;
                                                            switch (i42) {
                                                                case 0:
                                                                    int i52 = SettingsActivity.E;
                                                                    settingsActivity.finish();
                                                                    break;
                                                                case 1:
                                                                    int i62 = SettingsActivity.E;
                                                                    b.a aVar = new b.a(settingsActivity);
                                                                    aVar.d(R.string.dialog_reset_progress_title);
                                                                    AlertController.b bVar = aVar.a;
                                                                    bVar.f = bVar.a.getText(R.string.dialog_reset_progress_msg);
                                                                    aVar.c(new er(settingsActivity, 2));
                                                                    aVar.b();
                                                                    aVar.e();
                                                                    break;
                                                                case 2:
                                                                    int i7 = SettingsActivity.E;
                                                                    b.a aVar2 = new b.a(settingsActivity);
                                                                    aVar2.d(R.string.dialog_delete_decks_title);
                                                                    AlertController.b bVar2 = aVar2.a;
                                                                    bVar2.f = bVar2.a.getText(R.string.dialog_delete_decks_msg);
                                                                    aVar2.c(new er(settingsActivity, 0));
                                                                    aVar2.b();
                                                                    aVar2.e();
                                                                    break;
                                                                case 3:
                                                                    int i8 = SettingsActivity.E;
                                                                    b.a aVar3 = new b.a(settingsActivity);
                                                                    aVar3.d(R.string.dialog_reset_ach_title);
                                                                    AlertController.b bVar3 = aVar3.a;
                                                                    bVar3.f = bVar3.a.getText(R.string.dialog_reset_ach_msg);
                                                                    aVar3.c(new er(settingsActivity, 1));
                                                                    aVar3.b();
                                                                    aVar3.e();
                                                                    break;
                                                                default:
                                                                    int i9 = SettingsActivity.E;
                                                                    b.a aVar4 = new b.a(settingsActivity);
                                                                    aVar4.d(R.string.about_title);
                                                                    aVar4.a.f = settingsActivity.getString(R.string.about_message, "1.0");
                                                                    aVar4.c(null);
                                                                    aVar4.e();
                                                                    break;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var18 = this.B;
                                                    if (i0Var18 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((Button) i0Var18.f).setOnClickListener(new View.OnClickListener(this) { // from class: dr
                                                        public final /* synthetic */ SettingsActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i42 = i5;
                                                            SettingsActivity settingsActivity = this.b;
                                                            switch (i42) {
                                                                case 0:
                                                                    int i52 = SettingsActivity.E;
                                                                    settingsActivity.finish();
                                                                    break;
                                                                case 1:
                                                                    int i62 = SettingsActivity.E;
                                                                    b.a aVar = new b.a(settingsActivity);
                                                                    aVar.d(R.string.dialog_reset_progress_title);
                                                                    AlertController.b bVar = aVar.a;
                                                                    bVar.f = bVar.a.getText(R.string.dialog_reset_progress_msg);
                                                                    aVar.c(new er(settingsActivity, 2));
                                                                    aVar.b();
                                                                    aVar.e();
                                                                    break;
                                                                case 2:
                                                                    int i7 = SettingsActivity.E;
                                                                    b.a aVar2 = new b.a(settingsActivity);
                                                                    aVar2.d(R.string.dialog_delete_decks_title);
                                                                    AlertController.b bVar2 = aVar2.a;
                                                                    bVar2.f = bVar2.a.getText(R.string.dialog_delete_decks_msg);
                                                                    aVar2.c(new er(settingsActivity, 0));
                                                                    aVar2.b();
                                                                    aVar2.e();
                                                                    break;
                                                                case 3:
                                                                    int i8 = SettingsActivity.E;
                                                                    b.a aVar3 = new b.a(settingsActivity);
                                                                    aVar3.d(R.string.dialog_reset_ach_title);
                                                                    AlertController.b bVar3 = aVar3.a;
                                                                    bVar3.f = bVar3.a.getText(R.string.dialog_reset_ach_msg);
                                                                    aVar3.c(new er(settingsActivity, 1));
                                                                    aVar3.b();
                                                                    aVar3.e();
                                                                    break;
                                                                default:
                                                                    int i9 = SettingsActivity.E;
                                                                    b.a aVar4 = new b.a(settingsActivity);
                                                                    aVar4.d(R.string.about_title);
                                                                    aVar4.a.f = settingsActivity.getString(R.string.about_message, "1.0");
                                                                    aVar4.c(null);
                                                                    aVar4.e();
                                                                    break;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var19 = this.B;
                                                    if (i0Var19 != null) {
                                                        i0Var19.a.setOnClickListener(new View.OnClickListener(this) { // from class: dr
                                                            public final /* synthetic */ SettingsActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i42 = i6;
                                                                SettingsActivity settingsActivity = this.b;
                                                                switch (i42) {
                                                                    case 0:
                                                                        int i52 = SettingsActivity.E;
                                                                        settingsActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i62 = SettingsActivity.E;
                                                                        b.a aVar = new b.a(settingsActivity);
                                                                        aVar.d(R.string.dialog_reset_progress_title);
                                                                        AlertController.b bVar = aVar.a;
                                                                        bVar.f = bVar.a.getText(R.string.dialog_reset_progress_msg);
                                                                        aVar.c(new er(settingsActivity, 2));
                                                                        aVar.b();
                                                                        aVar.e();
                                                                        break;
                                                                    case 2:
                                                                        int i7 = SettingsActivity.E;
                                                                        b.a aVar2 = new b.a(settingsActivity);
                                                                        aVar2.d(R.string.dialog_delete_decks_title);
                                                                        AlertController.b bVar2 = aVar2.a;
                                                                        bVar2.f = bVar2.a.getText(R.string.dialog_delete_decks_msg);
                                                                        aVar2.c(new er(settingsActivity, 0));
                                                                        aVar2.b();
                                                                        aVar2.e();
                                                                        break;
                                                                    case 3:
                                                                        int i8 = SettingsActivity.E;
                                                                        b.a aVar3 = new b.a(settingsActivity);
                                                                        aVar3.d(R.string.dialog_reset_ach_title);
                                                                        AlertController.b bVar3 = aVar3.a;
                                                                        bVar3.f = bVar3.a.getText(R.string.dialog_reset_ach_msg);
                                                                        aVar3.c(new er(settingsActivity, 1));
                                                                        aVar3.b();
                                                                        aVar3.e();
                                                                        break;
                                                                    default:
                                                                        int i9 = SettingsActivity.E;
                                                                        b.a aVar4 = new b.a(settingsActivity);
                                                                        aVar4.d(R.string.about_title);
                                                                        aVar4.a.f = settingsActivity.getString(R.string.about_message, "1.0");
                                                                        aVar4.c(null);
                                                                        aVar4.e();
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        return;
                                                    } else {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a implements AdapterView.OnItemSelectedListener {
        public a() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public final void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SettingsActivity settingsActivity = SettingsActivity.this;
            rd rdVar = settingsActivity.C;
            if (rdVar == null) {
                ii.d("prefs");
                throw null;
            }
            rdVar.a.edit().putInt("daily_goal", settingsActivity.D.get(i).intValue()).apply();
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public final void onNothingSelected(AdapterView<?> adapterView) {
        }
    }
}
