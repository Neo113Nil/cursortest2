package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import com.google.android.material.appbar.MaterialToolbar;
import defpackage.a0;
import defpackage.b0;
import defpackage.ba;
import defpackage.dc;
import defpackage.ea;
import defpackage.i7;
import defpackage.ii;
import defpackage.j7;
import defpackage.md;
import defpackage.n0;
import defpackage.o7;
import defpackage.od;
import defpackage.pd;
import defpackage.qd;
import defpackage.rd;
import defpackage.ws;
import defpackage.y1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class QuizActivity extends y1 {
    public static final /* synthetic */ int L = 0;
    public n0 B;
    public rd C;
    public List<pd> D;
    public ArrayList E;
    public List<? extends Button> F;
    public int H;
    public int I;
    public boolean J;
    public int G = -1;
    public final Handler K = new Handler(Looper.getMainLooper());

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ int a = 0;

        static {
            new LinkedHashMap();
        }
    }

    public QuizActivity() {
        Math.min(22, 71);
        ws.c0("test").toString();
        ws.c0("test").toString();
        System.identityHashCode(this);
        int i = a.a;
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_quiz, (ViewGroup) null, false);
        int i = R.id.answersColumn;
        if (((LinearLayout) dc.p(viewInflate, R.id.answersColumn)) != null) {
            i = R.id.btnAnswer0;
            Button button = (Button) dc.p(viewInflate, R.id.btnAnswer0);
            if (button != null) {
                i = R.id.btnAnswer1;
                Button button2 = (Button) dc.p(viewInflate, R.id.btnAnswer1);
                if (button2 != null) {
                    i = R.id.btnAnswer2;
                    Button button3 = (Button) dc.p(viewInflate, R.id.btnAnswer2);
                    if (button3 != null) {
                        i = R.id.btnAnswer3;
                        Button button4 = (Button) dc.p(viewInflate, R.id.btnAnswer3);
                        if (button4 != null) {
                            i = R.id.progressQuiz;
                            ProgressBar progressBar = (ProgressBar) dc.p(viewInflate, R.id.progressQuiz);
                            if (progressBar != null) {
                                i = R.id.questionCard;
                                if (((CardView) dc.p(viewInflate, R.id.questionCard)) != null) {
                                    i = R.id.toolbar;
                                    MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                    if (materialToolbar != null) {
                                        i = R.id.txtQuestion;
                                        TextView textView = (TextView) dc.p(viewInflate, R.id.txtQuestion);
                                        if (textView != null) {
                                            LinearLayout linearLayout = (LinearLayout) viewInflate;
                                            this.B = new n0(linearLayout, button, button2, button3, button4, progressBar, materialToolbar, textView);
                                            setContentView(linearLayout);
                                            rd rdVar = new rd(this);
                                            this.C = rdVar;
                                            rdVar.m();
                                            rd rdVar2 = this.C;
                                            if (rdVar2 == null) {
                                                ii.d("prefs");
                                                throw null;
                                            }
                                            rdVar2.l();
                                            this.G = getIntent().getIntExtra(qd.a, -1);
                                            rd rdVar3 = this.C;
                                            if (rdVar3 == null) {
                                                ii.d("prefs");
                                                throw null;
                                            }
                                            ArrayList arrayListA = ea.a(rdVar3);
                                            this.E = arrayListA;
                                            List list = arrayListA;
                                            if (this.G != -1) {
                                                ArrayList arrayList = new ArrayList();
                                                int size = arrayListA.size();
                                                int i2 = 0;
                                                while (i2 < size) {
                                                    Object obj = arrayListA.get(i2);
                                                    i2++;
                                                    if (((pd) obj).b == this.G) {
                                                        arrayList.add(obj);
                                                    }
                                                }
                                                list = arrayList;
                                            }
                                            rd rdVar4 = this.C;
                                            if (rdVar4 == null) {
                                                ii.d("prefs");
                                                throw null;
                                            }
                                            List list2 = list;
                                            if (rdVar4.a.getBoolean("shuffle_cards", true)) {
                                                List listT = o7.T(list);
                                                Collections.shuffle(listT);
                                                list2 = listT;
                                            }
                                            List<pd> listP = o7.P(20, list2);
                                            this.D = listP;
                                            if (listP.isEmpty()) {
                                                Toast.makeText(this, getString(R.string.no_cards_for_session), 0).show();
                                                finish();
                                                return;
                                            }
                                            n0 n0Var = this.B;
                                            if (n0Var == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            y((MaterialToolbar) n0Var.f);
                                            b0 b0VarX = x();
                                            if (b0VarX != null) {
                                                b0VarX.m(true);
                                            }
                                            n0 n0Var2 = this.B;
                                            if (n0Var2 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            ((MaterialToolbar) n0Var2.f).setNavigationOnClickListener(new a0(5, this));
                                            n0 n0Var3 = this.B;
                                            if (n0Var3 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            ProgressBar progressBar2 = (ProgressBar) n0Var3.e;
                                            List<pd> list3 = this.D;
                                            if (list3 == null) {
                                                ii.d("questions");
                                                throw null;
                                            }
                                            progressBar2.setMax(list3.size());
                                            n0 n0Var4 = this.B;
                                            if (n0Var4 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            Button button5 = (Button) n0Var4.a;
                                            if (n0Var4 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            Button button6 = (Button) n0Var4.b;
                                            if (n0Var4 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            Button button7 = (Button) n0Var4.c;
                                            if (n0Var4 == null) {
                                                ii.d("binding");
                                                throw null;
                                            }
                                            this.F = i7.E(button5, button6, button7, (Button) n0Var4.d);
                                            z();
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onPause() {
        super.onPause();
        rd rdVar = this.C;
        if (rdVar != null) {
            rdVar.c(ea.b(rdVar));
        } else {
            ii.d("prefs");
            throw null;
        }
    }

    public final void z() {
        int i = this.H;
        List<pd> list = this.D;
        if (list == null) {
            ii.d("questions");
            throw null;
        }
        int i2 = 0;
        int i3 = 1;
        if (i >= list.size()) {
            rd rdVar = this.C;
            if (rdVar == null) {
                ii.d("prefs");
                throw null;
            }
            SharedPreferences sharedPreferences = rdVar.a;
            sharedPreferences.edit().putInt("total_quizzes", sharedPreferences.getInt("total_quizzes", 0) + 1).apply();
            List<pd> list2 = this.D;
            if (list2 == null) {
                ii.d("questions");
                throw null;
            }
            if (list2.size() >= 10) {
                int i4 = this.I;
                List<pd> list3 = this.D;
                if (list3 == null) {
                    ii.d("questions");
                    throw null;
                }
                if (i4 == list3.size()) {
                    rd rdVar2 = this.C;
                    if (rdVar2 == null) {
                        ii.d("prefs");
                        throw null;
                    }
                    rdVar2.a.edit().putBoolean("perfect_quiz", true).apply();
                }
            }
            rd rdVar3 = this.C;
            if (rdVar3 == null) {
                ii.d("prefs");
                throw null;
            }
            List<pd> list4 = this.D;
            if (list4 == null) {
                ii.d("questions");
                throw null;
            }
            int size = list4.size();
            SharedPreferences sharedPreferences2 = rdVar3.a;
            if (size > sharedPreferences2.getInt("max_session", 0)) {
                sharedPreferences2.edit().putInt("max_session", size).apply();
            }
            Intent intent = new Intent(this, (Class<?>) ResultActivity.class);
            intent.putExtra(qd.c, this.I);
            String str = qd.d;
            List<pd> list5 = this.D;
            if (list5 == null) {
                ii.d("questions");
                throw null;
            }
            intent.putExtra(str, list5.size());
            intent.putExtra(qd.e, qd.g);
            intent.putExtra(qd.a, this.G);
            startActivity(intent);
            finish();
            return;
        }
        this.J = false;
        List<pd> list6 = this.D;
        if (list6 == null) {
            ii.d("questions");
            throw null;
        }
        pd pdVar = list6.get(this.H);
        n0 n0Var = this.B;
        if (n0Var == null) {
            ii.d("binding");
            throw null;
        }
        TextView textView = (TextView) n0Var.g;
        String str2 = pdVar.c;
        String str3 = pdVar.d;
        textView.setText(str2);
        n0 n0Var2 = this.B;
        if (n0Var2 == null) {
            ii.d("binding");
            throw null;
        }
        MaterialToolbar materialToolbar = (MaterialToolbar) n0Var2.f;
        Integer numValueOf = Integer.valueOf(this.H + 1);
        List<pd> list7 = this.D;
        if (list7 == null) {
            ii.d("questions");
            throw null;
        }
        materialToolbar.setSubtitle(getString(R.string.counter_format, numValueOf, Integer.valueOf(list7.size())));
        n0 n0Var3 = this.B;
        if (n0Var3 == null) {
            ii.d("binding");
            throw null;
        }
        ((ProgressBar) n0Var3.e).setProgress(this.H);
        ArrayList arrayList = this.E;
        if (arrayList == null) {
            ii.d("pool");
            throw null;
        }
        ArrayList arrayList2 = new ArrayList();
        int size2 = arrayList.size();
        int i5 = 0;
        while (i5 < size2) {
            Object obj = arrayList.get(i5);
            i5++;
            if (!ii.a(((pd) obj).d, str3)) {
                arrayList2.add(obj);
            }
        }
        List listT = o7.T(arrayList2);
        Collections.shuffle(listT);
        List listP = o7.P(3, listT);
        ArrayList arrayList3 = new ArrayList(j7.G(listP));
        Iterator it = listP.iterator();
        while (it.hasNext()) {
            arrayList3.add(((pd) it.next()).d);
        }
        ArrayList arrayList4 = new ArrayList(arrayList3);
        while (arrayList4.size() < 3) {
            arrayList4.add(str3);
        }
        ArrayList arrayList5 = new ArrayList(o7.S(new LinkedHashSet(o7.M(arrayList4, str3))));
        while (arrayList5.size() < 4) {
            arrayList5.add(str3);
        }
        List listT2 = o7.T(o7.P(4, arrayList5));
        Collections.shuffle(listT2);
        List<? extends Button> list8 = this.F;
        if (list8 == null) {
            ii.d("answerButtons");
            throw null;
        }
        for (Object obj2 : list8) {
            int i6 = i2 + 1;
            if (i2 < 0) {
                i7.F();
                throw null;
            }
            Button button = (Button) obj2;
            button.setEnabled(true);
            button.setAlpha(1.0f);
            button.setBackgroundTintList(null);
            button.setBackgroundResource(R.drawable.button_quiz);
            ArrayList arrayList6 = (ArrayList) listT2;
            button.setText((CharSequence) arrayList6.get(i2));
            button.setTag(arrayList6.get(i2));
            button.setOnClickListener(new ba(this, button, pdVar, i3));
            long j = i2 * 60;
            rd rdVar4 = this.C;
            if (rdVar4 == null) {
                ii.d("prefs");
                throw null;
            }
            od.a(button, j, 250L, 20.0f, rdVar4.a());
            i2 = i6;
        }
    }
}
