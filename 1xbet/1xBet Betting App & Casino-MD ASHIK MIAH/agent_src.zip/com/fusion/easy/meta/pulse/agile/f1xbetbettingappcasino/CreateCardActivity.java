package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.animation.ObjectAnimator;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.CreateCardActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.R;
import com.google.android.material.appbar.MaterialToolbar;
import defpackage.b0;
import defpackage.dc;
import defpackage.ea;
import defpackage.f9;
import defpackage.i0;
import defpackage.ii;
import defpackage.j7;
import defpackage.k9;
import defpackage.md;
import defpackage.qd;
import defpackage.rd;
import defpackage.rf;
import defpackage.ts;
import defpackage.uc;
import defpackage.w9;
import defpackage.y1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class CreateCardActivity extends y1 {
    public static final /* synthetic */ int H = 0;
    public i0 B;
    public rd C;
    public boolean F;
    public int D = -1;
    public int E = -1;
    public List<w9> G = uc.a;

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ int a = 0;

        static {
            new LinkedHashMap();
        }
    }

    public CreateCardActivity() {
        System.currentTimeMillis();
        System.currentTimeMillis();
        Math.max(48, 49);
        System.identityHashCode(this);
        System.currentTimeMillis();
        int i = a.a;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x01d8 A[EDGE_INSN: B:178:0x01d8->B:87:0x01d8 BREAK  A[LOOP:1: B:52:0x0141->B:179:?]] */
    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        Integer numK;
        k9 k9Var;
        List<w9> list;
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_create_card, (ViewGroup) null, false);
        int i2 = R.id.btnCancel;
        Button button = (Button) dc.p(viewInflate, R.id.btnCancel);
        if (button != null) {
            i2 = R.id.btnFlipPreview;
            Button button2 = (Button) dc.p(viewInflate, R.id.btnFlipPreview);
            if (button2 != null) {
                i2 = R.id.btnSave;
                Button button3 = (Button) dc.p(viewInflate, R.id.btnSave);
                if (button3 != null) {
                    i2 = R.id.inputBack;
                    EditText editText = (EditText) dc.p(viewInflate, R.id.inputBack);
                    if (editText != null) {
                        i2 = R.id.inputFront;
                        EditText editText2 = (EditText) dc.p(viewInflate, R.id.inputFront);
                        if (editText2 != null) {
                            i2 = R.id.inputHint;
                            EditText editText3 = (EditText) dc.p(viewInflate, R.id.inputHint);
                            if (editText3 != null) {
                                i2 = R.id.previewCard;
                                CardView cardView = (CardView) dc.p(viewInflate, R.id.previewCard);
                                if (cardView != null) {
                                    i2 = R.id.spinnerDeck;
                                    Spinner spinner = (Spinner) dc.p(viewInflate, R.id.spinnerDeck);
                                    if (spinner != null) {
                                        i2 = R.id.toolbar;
                                        MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                        if (materialToolbar != null) {
                                            i2 = R.id.txtPreviewBack;
                                            TextView textView = (TextView) dc.p(viewInflate, R.id.txtPreviewBack);
                                            if (textView != null) {
                                                i2 = R.id.txtPreviewFront;
                                                TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtPreviewFront);
                                                if (textView2 != null) {
                                                    LinearLayout linearLayout = (LinearLayout) viewInflate;
                                                    this.B = new i0(linearLayout, button, button2, button3, editText, editText2, editText3, cardView, spinner, materialToolbar, textView, textView2);
                                                    setContentView(linearLayout);
                                                    this.C = new rd(this);
                                                    this.D = getIntent().getIntExtra(qd.a, -1);
                                                    this.E = getIntent().getIntExtra(qd.b, -1);
                                                    rd rdVar = this.C;
                                                    if (rdVar == null) {
                                                        ii.d("prefs");
                                                        throw null;
                                                    }
                                                    ArrayList arrayListB = ea.b(rdVar);
                                                    ArrayList arrayList = new ArrayList();
                                                    int size = arrayListB.size();
                                                    int i3 = 0;
                                                    while (i3 < size) {
                                                        Object obj = arrayListB.get(i3);
                                                        i3++;
                                                        if (!((w9) obj).f) {
                                                            arrayList.add(obj);
                                                        }
                                                    }
                                                    this.G = arrayList;
                                                    i0 i0Var = this.B;
                                                    if (i0Var == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    y(i0Var.c);
                                                    b0 b0VarX = x();
                                                    final int i4 = 1;
                                                    if (b0VarX != null) {
                                                        b0VarX.m(true);
                                                    }
                                                    i0 i0Var2 = this.B;
                                                    if (i0Var2 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    i0Var2.c.setNavigationOnClickListener(new View.OnClickListener(this) { // from class: d9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i5;
                                                            String string;
                                                            String string2;
                                                            String string3;
                                                            int i6 = i;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            switch (i6) {
                                                                case 0:
                                                                    int i7 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                                case 1:
                                                                    int i8 = CreateCardActivity.H;
                                                                    float f = createCardActivity.getResources().getDisplayMetrics().density;
                                                                    i0 i0Var3 = createCardActivity.B;
                                                                    if (i0Var3 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    ((CardView) i0Var3.j).setCameraDistance(f * 8000.0f);
                                                                    rd rdVar2 = createCardActivity.C;
                                                                    if (rdVar2 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    if (rdVar2.a.getBoolean("flip_animation", true)) {
                                                                        rd rdVar3 = createCardActivity.C;
                                                                        if (rdVar3 == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        if (rdVar3.a()) {
                                                                            i0 i0Var4 = createCardActivity.B;
                                                                            if (i0Var4 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat((CardView) i0Var4.j, (Property<CardView, Float>) View.ROTATION_Y, 0.0f, 90.0f);
                                                                            objectAnimatorOfFloat.setDuration(200L);
                                                                            objectAnimatorOfFloat.addListener(new p1(1, createCardActivity));
                                                                            objectAnimatorOfFloat.start();
                                                                            return;
                                                                        }
                                                                    }
                                                                    boolean z = createCardActivity.F;
                                                                    createCardActivity.F = !z;
                                                                    i0 i0Var5 = createCardActivity.B;
                                                                    if (i0Var5 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    i0Var5.e.setVisibility(!z ? 8 : 0);
                                                                    i0 i0Var6 = createCardActivity.B;
                                                                    if (i0Var6 != null) {
                                                                        i0Var6.d.setVisibility(createCardActivity.F ? 0 : 8);
                                                                        return;
                                                                    } else {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                case 2:
                                                                    i0 i0Var7 = createCardActivity.B;
                                                                    if (i0Var7 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text = ((EditText) i0Var7.h).getText();
                                                                    String string4 = (text == null || (string3 = text.toString()) == null) ? null : ws.c0(string3).toString();
                                                                    if (string4 == null) {
                                                                        string4 = "";
                                                                    }
                                                                    i0 i0Var8 = createCardActivity.B;
                                                                    if (i0Var8 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text2 = ((EditText) i0Var8.g).getText();
                                                                    String string5 = (text2 == null || (string2 = text2.toString()) == null) ? null : ws.c0(string2).toString();
                                                                    if (string5 == null) {
                                                                        string5 = "";
                                                                    }
                                                                    i0 i0Var9 = createCardActivity.B;
                                                                    if (i0Var9 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text3 = ((EditText) i0Var9.i).getText();
                                                                    String string6 = (text3 == null || (string = text3.toString()) == null) ? null : ws.c0(string).toString();
                                                                    if (string6 == null) {
                                                                        string6 = "";
                                                                    }
                                                                    if (string4.length() == 0 || string5.length() == 0) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_front_back), 0).show();
                                                                        return;
                                                                    }
                                                                    i0 i0Var10 = createCardActivity.B;
                                                                    if (i0Var10 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    if (((Spinner) i0Var10.k).getVisibility() != 0 || createCardActivity.G.isEmpty()) {
                                                                        i5 = createCardActivity.D;
                                                                    } else {
                                                                        List<w9> list2 = createCardActivity.G;
                                                                        i0 i0Var11 = createCardActivity.B;
                                                                        if (i0Var11 == null) {
                                                                            ii.d("binding");
                                                                            throw null;
                                                                        }
                                                                        i5 = list2.get(((Spinner) i0Var11.k).getSelectedItemPosition()).a;
                                                                    }
                                                                    if (i5 == -1) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_deck_name), 0).show();
                                                                        return;
                                                                    }
                                                                    int iCurrentTimeMillis = createCardActivity.E;
                                                                    if (iCurrentTimeMillis == -1) {
                                                                        if (createCardActivity.C == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        iCurrentTimeMillis = ((int) (System.currentTimeMillis() % 1000000000)) + 10000;
                                                                    }
                                                                    rd rdVar4 = createCardActivity.C;
                                                                    if (rdVar4 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    SharedPreferences sharedPreferences = rdVar4.a;
                                                                    String string7 = sharedPreferences.getString("deck_card_ids_" + i5, null);
                                                                    ArrayList arrayList2 = new ArrayList(rd.k(string7 != null ? string7 : ""));
                                                                    if (!arrayList2.contains(Integer.valueOf(iCurrentTimeMillis))) {
                                                                        arrayList2.add(Integer.valueOf(iCurrentTimeMillis));
                                                                        sharedPreferences.edit().putInt("custom_cards_count", sharedPreferences.getInt("custom_cards_count", 0) + 1).apply();
                                                                    }
                                                                    sharedPreferences.edit().putString(xs.b("deck_card_ids_", i5), o7.K(arrayList2, ",", null, 62)).putString("card_front_" + iCurrentTimeMillis, string4).putString("card_back_" + iCurrentTimeMillis, string5).putString("card_hint_" + iCurrentTimeMillis, string6).putString(xs.b("card_deck_id_", iCurrentTimeMillis), String.valueOf(i5)).apply();
                                                                    rd rdVar5 = createCardActivity.C;
                                                                    if (rdVar5 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    rdVar5.c(ea.b(rdVar5));
                                                                    createCardActivity.setResult(-1);
                                                                    createCardActivity.finish();
                                                                    return;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var3 = this.B;
                                                    if (i0Var3 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    i0Var3.c.setTitle(this.E == -1 ? getString(R.string.title_new_card) : getString(R.string.title_edit_card));
                                                    if (this.D != -1 && ((list = this.G) == null || !list.isEmpty())) {
                                                        Iterator<T> it = list.iterator();
                                                        while (it.hasNext()) {
                                                            if (((w9) it.next()).a == this.D) {
                                                                break;
                                                            }
                                                        }
                                                        if (this.G.isEmpty()) {
                                                        }
                                                    } else if (this.G.isEmpty()) {
                                                        i0 i0Var4 = this.B;
                                                        if (i0Var4 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        ((Spinner) i0Var4.k).setVisibility(0);
                                                        List<w9> list2 = this.G;
                                                        ArrayList arrayList2 = new ArrayList(j7.G(list2));
                                                        Iterator<T> it2 = list2.iterator();
                                                        while (it2.hasNext()) {
                                                            arrayList2.add(((w9) it2.next()).b);
                                                        }
                                                        i0 i0Var5 = this.B;
                                                        if (i0Var5 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        ((Spinner) i0Var5.k).setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayList2));
                                                        if (this.D != -1) {
                                                            Iterator<w9> it3 = this.G.iterator();
                                                            int i5 = 0;
                                                            while (true) {
                                                                if (!it3.hasNext()) {
                                                                    i5 = -1;
                                                                    break;
                                                                } else if (it3.next().a == this.D) {
                                                                    break;
                                                                } else {
                                                                    i5++;
                                                                }
                                                            }
                                                            if (i5 >= 0) {
                                                                i0 i0Var6 = this.B;
                                                                if (i0Var6 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                ((Spinner) i0Var6.k).setSelection(i5);
                                                            }
                                                        }
                                                    } else {
                                                        i0 i0Var7 = this.B;
                                                        if (i0Var7 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        ((Spinner) i0Var7.k).setVisibility(8);
                                                    }
                                                    int i6 = this.E;
                                                    if (i6 != -1) {
                                                        rd rdVar2 = this.C;
                                                        if (rdVar2 == null) {
                                                            ii.d("prefs");
                                                            throw null;
                                                        }
                                                        SharedPreferences sharedPreferences = rdVar2.a;
                                                        String string = sharedPreferences.getString("card_deck_id_" + i6, null);
                                                        if (string == null || (numK = ts.K(string)) == null) {
                                                            k9Var = null;
                                                        } else {
                                                            int iIntValue = numK.intValue();
                                                            String string2 = sharedPreferences.getString("card_front_" + i6, null);
                                                            String str = string2 == null ? "" : string2;
                                                            String string3 = sharedPreferences.getString("card_back_" + i6, null);
                                                            String str2 = string3 == null ? "" : string3;
                                                            String string4 = sharedPreferences.getString("card_hint_" + i6, null);
                                                            k9Var = new k9(i6, iIntValue, str, str2, string4 == null ? "" : string4);
                                                        }
                                                        if (k9Var != null) {
                                                            String str3 = k9Var.d;
                                                            String str4 = k9Var.c;
                                                            this.D = k9Var.b;
                                                            i0 i0Var8 = this.B;
                                                            if (i0Var8 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            ((EditText) i0Var8.h).setText(str4);
                                                            i0 i0Var9 = this.B;
                                                            if (i0Var9 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            ((EditText) i0Var9.g).setText(str3);
                                                            i0 i0Var10 = this.B;
                                                            if (i0Var10 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            ((EditText) i0Var10.i).setText(k9Var.e);
                                                            i0 i0Var11 = this.B;
                                                            if (i0Var11 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            i0Var11.e.setText(str4);
                                                            i0 i0Var12 = this.B;
                                                            if (i0Var12 == null) {
                                                                ii.d("binding");
                                                                throw null;
                                                            }
                                                            i0Var12.d.setText(str3);
                                                        }
                                                    }
                                                    i0 i0Var13 = this.B;
                                                    if (i0Var13 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((EditText) i0Var13.h).addTextChangedListener(new f9(new rf(this) { // from class: e9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // defpackage.rf
                                                        public final Object f(Object obj2) {
                                                            int i7 = i;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            String string5 = (String) obj2;
                                                            switch (i7) {
                                                                case 0:
                                                                    int i8 = CreateCardActivity.H;
                                                                    string5.getClass();
                                                                    i0 i0Var14 = createCardActivity.B;
                                                                    if (i0Var14 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    TextView textView3 = i0Var14.e;
                                                                    if (string5.length() == 0) {
                                                                        string5 = createCardActivity.getString(R.string.preview_front_placeholder);
                                                                        string5.getClass();
                                                                    }
                                                                    textView3.setText(string5);
                                                                    return c.B;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    string5.getClass();
                                                                    i0 i0Var15 = createCardActivity.B;
                                                                    if (i0Var15 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    TextView textView4 = i0Var15.d;
                                                                    if (string5.length() == 0) {
                                                                        string5 = createCardActivity.getString(R.string.preview_back_placeholder);
                                                                        string5.getClass();
                                                                    }
                                                                    textView4.setText(string5);
                                                                    return c.B;
                                                            }
                                                        }
                                                    }));
                                                    i0 i0Var14 = this.B;
                                                    if (i0Var14 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    ((EditText) i0Var14.g).addTextChangedListener(new f9(new rf(this) { // from class: e9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // defpackage.rf
                                                        public final Object f(Object obj2) {
                                                            int i7 = i4;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            String string5 = (String) obj2;
                                                            switch (i7) {
                                                                case 0:
                                                                    int i8 = CreateCardActivity.H;
                                                                    string5.getClass();
                                                                    i0 i0Var142 = createCardActivity.B;
                                                                    if (i0Var142 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    TextView textView3 = i0Var142.e;
                                                                    if (string5.length() == 0) {
                                                                        string5 = createCardActivity.getString(R.string.preview_front_placeholder);
                                                                        string5.getClass();
                                                                    }
                                                                    textView3.setText(string5);
                                                                    return c.B;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    string5.getClass();
                                                                    i0 i0Var15 = createCardActivity.B;
                                                                    if (i0Var15 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    TextView textView4 = i0Var15.d;
                                                                    if (string5.length() == 0) {
                                                                        string5 = createCardActivity.getString(R.string.preview_back_placeholder);
                                                                        string5.getClass();
                                                                    }
                                                                    textView4.setText(string5);
                                                                    return c.B;
                                                            }
                                                        }
                                                    }));
                                                    i0 i0Var15 = this.B;
                                                    if (i0Var15 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    i0Var15.b.setOnClickListener(new View.OnClickListener(this) { // from class: d9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i52;
                                                            String string5;
                                                            String string22;
                                                            String string32;
                                                            int i62 = i4;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            switch (i62) {
                                                                case 0:
                                                                    int i7 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                                case 1:
                                                                    int i8 = CreateCardActivity.H;
                                                                    float f = createCardActivity.getResources().getDisplayMetrics().density;
                                                                    i0 i0Var32 = createCardActivity.B;
                                                                    if (i0Var32 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    ((CardView) i0Var32.j).setCameraDistance(f * 8000.0f);
                                                                    rd rdVar22 = createCardActivity.C;
                                                                    if (rdVar22 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    if (rdVar22.a.getBoolean("flip_animation", true)) {
                                                                        rd rdVar3 = createCardActivity.C;
                                                                        if (rdVar3 == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        if (rdVar3.a()) {
                                                                            i0 i0Var42 = createCardActivity.B;
                                                                            if (i0Var42 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat((CardView) i0Var42.j, (Property<CardView, Float>) View.ROTATION_Y, 0.0f, 90.0f);
                                                                            objectAnimatorOfFloat.setDuration(200L);
                                                                            objectAnimatorOfFloat.addListener(new p1(1, createCardActivity));
                                                                            objectAnimatorOfFloat.start();
                                                                            return;
                                                                        }
                                                                    }
                                                                    boolean z = createCardActivity.F;
                                                                    createCardActivity.F = !z;
                                                                    i0 i0Var52 = createCardActivity.B;
                                                                    if (i0Var52 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    i0Var52.e.setVisibility(!z ? 8 : 0);
                                                                    i0 i0Var62 = createCardActivity.B;
                                                                    if (i0Var62 != null) {
                                                                        i0Var62.d.setVisibility(createCardActivity.F ? 0 : 8);
                                                                        return;
                                                                    } else {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                case 2:
                                                                    i0 i0Var72 = createCardActivity.B;
                                                                    if (i0Var72 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text = ((EditText) i0Var72.h).getText();
                                                                    String string42 = (text == null || (string32 = text.toString()) == null) ? null : ws.c0(string32).toString();
                                                                    if (string42 == null) {
                                                                        string42 = "";
                                                                    }
                                                                    i0 i0Var82 = createCardActivity.B;
                                                                    if (i0Var82 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text2 = ((EditText) i0Var82.g).getText();
                                                                    String string52 = (text2 == null || (string22 = text2.toString()) == null) ? null : ws.c0(string22).toString();
                                                                    if (string52 == null) {
                                                                        string52 = "";
                                                                    }
                                                                    i0 i0Var92 = createCardActivity.B;
                                                                    if (i0Var92 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text3 = ((EditText) i0Var92.i).getText();
                                                                    String string6 = (text3 == null || (string5 = text3.toString()) == null) ? null : ws.c0(string5).toString();
                                                                    if (string6 == null) {
                                                                        string6 = "";
                                                                    }
                                                                    if (string42.length() == 0 || string52.length() == 0) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_front_back), 0).show();
                                                                        return;
                                                                    }
                                                                    i0 i0Var102 = createCardActivity.B;
                                                                    if (i0Var102 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    if (((Spinner) i0Var102.k).getVisibility() != 0 || createCardActivity.G.isEmpty()) {
                                                                        i52 = createCardActivity.D;
                                                                    } else {
                                                                        List<w9> list22 = createCardActivity.G;
                                                                        i0 i0Var112 = createCardActivity.B;
                                                                        if (i0Var112 == null) {
                                                                            ii.d("binding");
                                                                            throw null;
                                                                        }
                                                                        i52 = list22.get(((Spinner) i0Var112.k).getSelectedItemPosition()).a;
                                                                    }
                                                                    if (i52 == -1) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_deck_name), 0).show();
                                                                        return;
                                                                    }
                                                                    int iCurrentTimeMillis = createCardActivity.E;
                                                                    if (iCurrentTimeMillis == -1) {
                                                                        if (createCardActivity.C == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        iCurrentTimeMillis = ((int) (System.currentTimeMillis() % 1000000000)) + 10000;
                                                                    }
                                                                    rd rdVar4 = createCardActivity.C;
                                                                    if (rdVar4 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    SharedPreferences sharedPreferences2 = rdVar4.a;
                                                                    String string7 = sharedPreferences2.getString("deck_card_ids_" + i52, null);
                                                                    ArrayList arrayList22 = new ArrayList(rd.k(string7 != null ? string7 : ""));
                                                                    if (!arrayList22.contains(Integer.valueOf(iCurrentTimeMillis))) {
                                                                        arrayList22.add(Integer.valueOf(iCurrentTimeMillis));
                                                                        sharedPreferences2.edit().putInt("custom_cards_count", sharedPreferences2.getInt("custom_cards_count", 0) + 1).apply();
                                                                    }
                                                                    sharedPreferences2.edit().putString(xs.b("deck_card_ids_", i52), o7.K(arrayList22, ",", null, 62)).putString("card_front_" + iCurrentTimeMillis, string42).putString("card_back_" + iCurrentTimeMillis, string52).putString("card_hint_" + iCurrentTimeMillis, string6).putString(xs.b("card_deck_id_", iCurrentTimeMillis), String.valueOf(i52)).apply();
                                                                    rd rdVar5 = createCardActivity.C;
                                                                    if (rdVar5 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    rdVar5.c(ea.b(rdVar5));
                                                                    createCardActivity.setResult(-1);
                                                                    createCardActivity.finish();
                                                                    return;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var16 = this.B;
                                                    if (i0Var16 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    final int i7 = 2;
                                                    ((Button) i0Var16.f).setOnClickListener(new View.OnClickListener(this) { // from class: d9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i52;
                                                            String string5;
                                                            String string22;
                                                            String string32;
                                                            int i62 = i7;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            switch (i62) {
                                                                case 0:
                                                                    int i72 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                                case 1:
                                                                    int i8 = CreateCardActivity.H;
                                                                    float f = createCardActivity.getResources().getDisplayMetrics().density;
                                                                    i0 i0Var32 = createCardActivity.B;
                                                                    if (i0Var32 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    ((CardView) i0Var32.j).setCameraDistance(f * 8000.0f);
                                                                    rd rdVar22 = createCardActivity.C;
                                                                    if (rdVar22 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    if (rdVar22.a.getBoolean("flip_animation", true)) {
                                                                        rd rdVar3 = createCardActivity.C;
                                                                        if (rdVar3 == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        if (rdVar3.a()) {
                                                                            i0 i0Var42 = createCardActivity.B;
                                                                            if (i0Var42 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat((CardView) i0Var42.j, (Property<CardView, Float>) View.ROTATION_Y, 0.0f, 90.0f);
                                                                            objectAnimatorOfFloat.setDuration(200L);
                                                                            objectAnimatorOfFloat.addListener(new p1(1, createCardActivity));
                                                                            objectAnimatorOfFloat.start();
                                                                            return;
                                                                        }
                                                                    }
                                                                    boolean z = createCardActivity.F;
                                                                    createCardActivity.F = !z;
                                                                    i0 i0Var52 = createCardActivity.B;
                                                                    if (i0Var52 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    i0Var52.e.setVisibility(!z ? 8 : 0);
                                                                    i0 i0Var62 = createCardActivity.B;
                                                                    if (i0Var62 != null) {
                                                                        i0Var62.d.setVisibility(createCardActivity.F ? 0 : 8);
                                                                        return;
                                                                    } else {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                case 2:
                                                                    i0 i0Var72 = createCardActivity.B;
                                                                    if (i0Var72 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text = ((EditText) i0Var72.h).getText();
                                                                    String string42 = (text == null || (string32 = text.toString()) == null) ? null : ws.c0(string32).toString();
                                                                    if (string42 == null) {
                                                                        string42 = "";
                                                                    }
                                                                    i0 i0Var82 = createCardActivity.B;
                                                                    if (i0Var82 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text2 = ((EditText) i0Var82.g).getText();
                                                                    String string52 = (text2 == null || (string22 = text2.toString()) == null) ? null : ws.c0(string22).toString();
                                                                    if (string52 == null) {
                                                                        string52 = "";
                                                                    }
                                                                    i0 i0Var92 = createCardActivity.B;
                                                                    if (i0Var92 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text3 = ((EditText) i0Var92.i).getText();
                                                                    String string6 = (text3 == null || (string5 = text3.toString()) == null) ? null : ws.c0(string5).toString();
                                                                    if (string6 == null) {
                                                                        string6 = "";
                                                                    }
                                                                    if (string42.length() == 0 || string52.length() == 0) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_front_back), 0).show();
                                                                        return;
                                                                    }
                                                                    i0 i0Var102 = createCardActivity.B;
                                                                    if (i0Var102 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    if (((Spinner) i0Var102.k).getVisibility() != 0 || createCardActivity.G.isEmpty()) {
                                                                        i52 = createCardActivity.D;
                                                                    } else {
                                                                        List<w9> list22 = createCardActivity.G;
                                                                        i0 i0Var112 = createCardActivity.B;
                                                                        if (i0Var112 == null) {
                                                                            ii.d("binding");
                                                                            throw null;
                                                                        }
                                                                        i52 = list22.get(((Spinner) i0Var112.k).getSelectedItemPosition()).a;
                                                                    }
                                                                    if (i52 == -1) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_deck_name), 0).show();
                                                                        return;
                                                                    }
                                                                    int iCurrentTimeMillis = createCardActivity.E;
                                                                    if (iCurrentTimeMillis == -1) {
                                                                        if (createCardActivity.C == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        iCurrentTimeMillis = ((int) (System.currentTimeMillis() % 1000000000)) + 10000;
                                                                    }
                                                                    rd rdVar4 = createCardActivity.C;
                                                                    if (rdVar4 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    SharedPreferences sharedPreferences2 = rdVar4.a;
                                                                    String string7 = sharedPreferences2.getString("deck_card_ids_" + i52, null);
                                                                    ArrayList arrayList22 = new ArrayList(rd.k(string7 != null ? string7 : ""));
                                                                    if (!arrayList22.contains(Integer.valueOf(iCurrentTimeMillis))) {
                                                                        arrayList22.add(Integer.valueOf(iCurrentTimeMillis));
                                                                        sharedPreferences2.edit().putInt("custom_cards_count", sharedPreferences2.getInt("custom_cards_count", 0) + 1).apply();
                                                                    }
                                                                    sharedPreferences2.edit().putString(xs.b("deck_card_ids_", i52), o7.K(arrayList22, ",", null, 62)).putString("card_front_" + iCurrentTimeMillis, string42).putString("card_back_" + iCurrentTimeMillis, string52).putString("card_hint_" + iCurrentTimeMillis, string6).putString(xs.b("card_deck_id_", iCurrentTimeMillis), String.valueOf(i52)).apply();
                                                                    rd rdVar5 = createCardActivity.C;
                                                                    if (rdVar5 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    rdVar5.c(ea.b(rdVar5));
                                                                    createCardActivity.setResult(-1);
                                                                    createCardActivity.finish();
                                                                    return;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                            }
                                                        }
                                                    });
                                                    i0 i0Var17 = this.B;
                                                    if (i0Var17 == null) {
                                                        ii.d("binding");
                                                        throw null;
                                                    }
                                                    final int i8 = 3;
                                                    i0Var17.a.setOnClickListener(new View.OnClickListener(this) { // from class: d9
                                                        public final /* synthetic */ CreateCardActivity b;

                                                        {
                                                            this.b = this;
                                                        }

                                                        @Override // android.view.View.OnClickListener
                                                        public final void onClick(View view) {
                                                            int i52;
                                                            String string5;
                                                            String string22;
                                                            String string32;
                                                            int i62 = i8;
                                                            CreateCardActivity createCardActivity = this.b;
                                                            switch (i62) {
                                                                case 0:
                                                                    int i72 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                                case 1:
                                                                    int i82 = CreateCardActivity.H;
                                                                    float f = createCardActivity.getResources().getDisplayMetrics().density;
                                                                    i0 i0Var32 = createCardActivity.B;
                                                                    if (i0Var32 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    ((CardView) i0Var32.j).setCameraDistance(f * 8000.0f);
                                                                    rd rdVar22 = createCardActivity.C;
                                                                    if (rdVar22 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    if (rdVar22.a.getBoolean("flip_animation", true)) {
                                                                        rd rdVar3 = createCardActivity.C;
                                                                        if (rdVar3 == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        if (rdVar3.a()) {
                                                                            i0 i0Var42 = createCardActivity.B;
                                                                            if (i0Var42 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat((CardView) i0Var42.j, (Property<CardView, Float>) View.ROTATION_Y, 0.0f, 90.0f);
                                                                            objectAnimatorOfFloat.setDuration(200L);
                                                                            objectAnimatorOfFloat.addListener(new p1(1, createCardActivity));
                                                                            objectAnimatorOfFloat.start();
                                                                            return;
                                                                        }
                                                                    }
                                                                    boolean z = createCardActivity.F;
                                                                    createCardActivity.F = !z;
                                                                    i0 i0Var52 = createCardActivity.B;
                                                                    if (i0Var52 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    i0Var52.e.setVisibility(!z ? 8 : 0);
                                                                    i0 i0Var62 = createCardActivity.B;
                                                                    if (i0Var62 != null) {
                                                                        i0Var62.d.setVisibility(createCardActivity.F ? 0 : 8);
                                                                        return;
                                                                    } else {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                case 2:
                                                                    i0 i0Var72 = createCardActivity.B;
                                                                    if (i0Var72 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text = ((EditText) i0Var72.h).getText();
                                                                    String string42 = (text == null || (string32 = text.toString()) == null) ? null : ws.c0(string32).toString();
                                                                    if (string42 == null) {
                                                                        string42 = "";
                                                                    }
                                                                    i0 i0Var82 = createCardActivity.B;
                                                                    if (i0Var82 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text2 = ((EditText) i0Var82.g).getText();
                                                                    String string52 = (text2 == null || (string22 = text2.toString()) == null) ? null : ws.c0(string22).toString();
                                                                    if (string52 == null) {
                                                                        string52 = "";
                                                                    }
                                                                    i0 i0Var92 = createCardActivity.B;
                                                                    if (i0Var92 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    Editable text3 = ((EditText) i0Var92.i).getText();
                                                                    String string6 = (text3 == null || (string5 = text3.toString()) == null) ? null : ws.c0(string5).toString();
                                                                    if (string6 == null) {
                                                                        string6 = "";
                                                                    }
                                                                    if (string42.length() == 0 || string52.length() == 0) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_front_back), 0).show();
                                                                        return;
                                                                    }
                                                                    i0 i0Var102 = createCardActivity.B;
                                                                    if (i0Var102 == null) {
                                                                        ii.d("binding");
                                                                        throw null;
                                                                    }
                                                                    if (((Spinner) i0Var102.k).getVisibility() != 0 || createCardActivity.G.isEmpty()) {
                                                                        i52 = createCardActivity.D;
                                                                    } else {
                                                                        List<w9> list22 = createCardActivity.G;
                                                                        i0 i0Var112 = createCardActivity.B;
                                                                        if (i0Var112 == null) {
                                                                            ii.d("binding");
                                                                            throw null;
                                                                        }
                                                                        i52 = list22.get(((Spinner) i0Var112.k).getSelectedItemPosition()).a;
                                                                    }
                                                                    if (i52 == -1) {
                                                                        Toast.makeText(createCardActivity, createCardActivity.getString(R.string.error_deck_name), 0).show();
                                                                        return;
                                                                    }
                                                                    int iCurrentTimeMillis = createCardActivity.E;
                                                                    if (iCurrentTimeMillis == -1) {
                                                                        if (createCardActivity.C == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        iCurrentTimeMillis = ((int) (System.currentTimeMillis() % 1000000000)) + 10000;
                                                                    }
                                                                    rd rdVar4 = createCardActivity.C;
                                                                    if (rdVar4 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    SharedPreferences sharedPreferences2 = rdVar4.a;
                                                                    String string7 = sharedPreferences2.getString("deck_card_ids_" + i52, null);
                                                                    ArrayList arrayList22 = new ArrayList(rd.k(string7 != null ? string7 : ""));
                                                                    if (!arrayList22.contains(Integer.valueOf(iCurrentTimeMillis))) {
                                                                        arrayList22.add(Integer.valueOf(iCurrentTimeMillis));
                                                                        sharedPreferences2.edit().putInt("custom_cards_count", sharedPreferences2.getInt("custom_cards_count", 0) + 1).apply();
                                                                    }
                                                                    sharedPreferences2.edit().putString(xs.b("deck_card_ids_", i52), o7.K(arrayList22, ",", null, 62)).putString("card_front_" + iCurrentTimeMillis, string42).putString("card_back_" + iCurrentTimeMillis, string52).putString("card_hint_" + iCurrentTimeMillis, string6).putString(xs.b("card_deck_id_", iCurrentTimeMillis), String.valueOf(i52)).apply();
                                                                    rd rdVar5 = createCardActivity.C;
                                                                    if (rdVar5 == null) {
                                                                        ii.d("prefs");
                                                                        throw null;
                                                                    }
                                                                    rdVar5.c(ea.b(rdVar5));
                                                                    createCardActivity.setResult(-1);
                                                                    createCardActivity.finish();
                                                                    return;
                                                                default:
                                                                    int i9 = CreateCardActivity.H;
                                                                    createCardActivity.finish();
                                                                    return;
                                                            }
                                                        }
                                                    });
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
