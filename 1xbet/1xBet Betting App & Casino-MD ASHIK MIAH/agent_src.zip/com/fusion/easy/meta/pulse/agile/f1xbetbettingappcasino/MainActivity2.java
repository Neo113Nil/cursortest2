package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.AchievementsActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.CreateDeckActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.DecksActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity2;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ProgressActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.QuizActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ReviewActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.SettingsActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.StudyActivity;
import defpackage.c;
import defpackage.dc;
import defpackage.i7;
import defpackage.ii;
import defpackage.k0;
import defpackage.md;
import defpackage.n6;
import defpackage.o7;
import defpackage.od;
import defpackage.rd;
import defpackage.y1;
import java.time.LocalDate;
import java.util.ArrayList;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class MainActivity2 extends y1 {
    public static final /* synthetic */ int E = 0;
    public k0 B;
    public rd C;
    public boolean D;

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main2, (ViewGroup) null, false);
        int i2 = R.id.btnAchievements;
        Button button = (Button) dc.p(viewInflate, R.id.btnAchievements);
        if (button != null) {
            i2 = R.id.btnCreate;
            Button button2 = (Button) dc.p(viewInflate, R.id.btnCreate);
            if (button2 != null) {
                i2 = R.id.btnDecks;
                Button button3 = (Button) dc.p(viewInflate, R.id.btnDecks);
                if (button3 != null) {
                    i2 = R.id.btnProgress;
                    Button button4 = (Button) dc.p(viewInflate, R.id.btnProgress);
                    if (button4 != null) {
                        i2 = R.id.btnQuiz;
                        Button button5 = (Button) dc.p(viewInflate, R.id.btnQuiz);
                        if (button5 != null) {
                            i2 = R.id.btnReview;
                            Button button6 = (Button) dc.p(viewInflate, R.id.btnReview);
                            if (button6 != null) {
                                i2 = R.id.btnSettings;
                                Button button7 = (Button) dc.p(viewInflate, R.id.btnSettings);
                                if (button7 != null) {
                                    i2 = R.id.btnStudy;
                                    Button button8 = (Button) dc.p(viewInflate, R.id.btnStudy);
                                    if (button8 != null) {
                                        i2 = R.id.hubContent;
                                        if (((LinearLayout) dc.p(viewInflate, R.id.hubContent)) != null) {
                                            i2 = R.id.imgLogo;
                                            if (((ImageView) dc.p(viewInflate, R.id.imgLogo)) != null) {
                                                i2 = R.id.panelMain;
                                                if (((LinearLayout) dc.p(viewInflate, R.id.panelMain)) != null) {
                                                    i2 = R.id.panelStreak;
                                                    LinearLayout linearLayout = (LinearLayout) dc.p(viewInflate, R.id.panelStreak);
                                                    if (linearLayout != null) {
                                                        i2 = R.id.progressDaily;
                                                        ProgressBar progressBar = (ProgressBar) dc.p(viewInflate, R.id.progressDaily);
                                                        if (progressBar != null) {
                                                            i2 = R.id.txtBrand;
                                                            TextView textView = (TextView) dc.p(viewInflate, R.id.txtBrand);
                                                            if (textView != null) {
                                                                i2 = R.id.txtStreak;
                                                                TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtStreak);
                                                                if (textView2 != null) {
                                                                    i2 = R.id.txtSubtitle;
                                                                    TextView textView3 = (TextView) dc.p(viewInflate, R.id.txtSubtitle);
                                                                    if (textView3 != null) {
                                                                        i2 = R.id.txtToday;
                                                                        TextView textView4 = (TextView) dc.p(viewInflate, R.id.txtToday);
                                                                        if (textView4 != null) {
                                                                            FrameLayout frameLayout = (FrameLayout) viewInflate;
                                                                            this.B = new k0(frameLayout, button, button2, button3, button4, button5, button6, button7, button8, linearLayout, progressBar, textView, textView2, textView3, textView4);
                                                                            setContentView(frameLayout);
                                                                            this.C = new rd(this);
                                                                            k0 k0Var = this.B;
                                                                            if (k0Var == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            k0Var.c.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i3 = i;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i3) {
                                                                                        case 0:
                                                                                            int i4 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i5 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i6 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i7 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var2 = this.B;
                                                                            if (k0Var2 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i3 = 1;
                                                                            k0Var2.h.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i3;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i4 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i5 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i6 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i7 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var3 = this.B;
                                                                            if (k0Var3 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i4 = 2;
                                                                            k0Var3.e.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i4;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i5 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i6 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i7 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var4 = this.B;
                                                                            if (k0Var4 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i5 = 3;
                                                                            k0Var4.f.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i5;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i52 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i6 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i7 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var5 = this.B;
                                                                            if (k0Var5 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i6 = 4;
                                                                            k0Var5.d.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i6;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i52 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i62 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i7 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var6 = this.B;
                                                                            if (k0Var6 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i7 = 5;
                                                                            k0Var6.a.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i7;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i52 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i62 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i72 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i8 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var7 = this.B;
                                                                            if (k0Var7 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i8 = 6;
                                                                            k0Var7.b.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i8;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i52 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i62 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i72 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i82 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i9 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            k0 k0Var8 = this.B;
                                                                            if (k0Var8 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            final int i9 = 7;
                                                                            k0Var8.g.setOnClickListener(new View.OnClickListener(this) { // from class: sj
                                                                                public final /* synthetic */ MainActivity2 b;

                                                                                {
                                                                                    this.b = this;
                                                                                }

                                                                                @Override // android.view.View.OnClickListener
                                                                                public final void onClick(View view) {
                                                                                    int i32 = i9;
                                                                                    MainActivity2 mainActivity2 = this.b;
                                                                                    switch (i32) {
                                                                                        case 0:
                                                                                            int i42 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DecksActivity.class));
                                                                                            break;
                                                                                        case 1:
                                                                                            int i52 = MainActivity2.E;
                                                                                            Intent intent = new Intent(mainActivity2, (Class<?>) StudyActivity.class);
                                                                                            intent.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent);
                                                                                            break;
                                                                                        case 2:
                                                                                            int i62 = MainActivity2.E;
                                                                                            Intent intent2 = new Intent(mainActivity2, (Class<?>) QuizActivity.class);
                                                                                            intent2.putExtra(qd.a, -1);
                                                                                            mainActivity2.startActivity(intent2);
                                                                                            break;
                                                                                        case 3:
                                                                                            int i72 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ReviewActivity.class));
                                                                                            break;
                                                                                        case 4:
                                                                                            int i82 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ProgressActivity.class));
                                                                                            break;
                                                                                        case 5:
                                                                                            int i92 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                            break;
                                                                                        case 6:
                                                                                            int i10 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CreateDeckActivity.class));
                                                                                            break;
                                                                                        default:
                                                                                            int i11 = MainActivity2.E;
                                                                                            mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                            break;
                                                                                    }
                                                                                }
                                                                            });
                                                                            if (this.D) {
                                                                                return;
                                                                            }
                                                                            this.D = true;
                                                                            k0 k0Var9 = this.B;
                                                                            if (k0Var9 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            for (Object obj : i7.E(k0Var9.c, k0Var9.h, k0Var9.e, k0Var9.f, k0Var9.d, k0Var9.a, k0Var9.b, k0Var9.g)) {
                                                                                int i10 = i + 1;
                                                                                if (i < 0) {
                                                                                    i7.F();
                                                                                    throw null;
                                                                                }
                                                                                Button button9 = (Button) obj;
                                                                                button9.getClass();
                                                                                long j = 70 * i;
                                                                                rd rdVar = this.C;
                                                                                if (rdVar == null) {
                                                                                    ii.d("prefs");
                                                                                    throw null;
                                                                                }
                                                                                od.a(button9, j, 350L, 50.0f, rdVar.a());
                                                                                i = i10;
                                                                            }
                                                                            k0 k0Var10 = this.B;
                                                                            if (k0Var10 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            LinearLayout linearLayout2 = k0Var10.i;
                                                                            rd rdVar2 = this.C;
                                                                            if (rdVar2 == null) {
                                                                                ii.d("prefs");
                                                                                throw null;
                                                                            }
                                                                            od.a(linearLayout2, 0L, 350L, 50.0f, rdVar2.a());
                                                                            k0 k0Var11 = this.B;
                                                                            if (k0Var11 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            TextView textView5 = k0Var11.k;
                                                                            rd rdVar3 = this.C;
                                                                            if (rdVar3 == null) {
                                                                                ii.d("prefs");
                                                                                throw null;
                                                                            }
                                                                            od.a(textView5, 40L, 350L, 50.0f, rdVar3.a());
                                                                            k0 k0Var12 = this.B;
                                                                            if (k0Var12 == null) {
                                                                                ii.d("binding");
                                                                                throw null;
                                                                            }
                                                                            TextView textView6 = k0Var12.m;
                                                                            rd rdVar4 = this.C;
                                                                            if (rdVar4 != null) {
                                                                                od.a(textView6, 80L, 350L, 50.0f, rdVar4.a());
                                                                                return;
                                                                            } else {
                                                                                ii.d("prefs");
                                                                                throw null;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onResume() {
        super.onResume();
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        int iG = rdVar.g();
        k0 k0Var = this.B;
        if (k0Var == null) {
            ii.d("binding");
            throw null;
        }
        k0Var.l.setText(getString(R.string.streak_format, Integer.valueOf(iG)));
        rd rdVar2 = this.C;
        if (rdVar2 == null) {
            ii.d("prefs");
            throw null;
        }
        int i = rdVar2.a.getInt("daily_goal", 20);
        rd rdVar3 = this.C;
        if (rdVar3 == null) {
            ii.d("prefs");
            throw null;
        }
        SharedPreferences sharedPreferences = rdVar3.a;
        String string = LocalDate.now().toString();
        string.getClass();
        int i2 = sharedPreferences.getInt("daily_".concat(string), 0);
        k0 k0Var2 = this.B;
        if (k0Var2 == null) {
            ii.d("binding");
            throw null;
        }
        k0Var2.n.setText(getString(R.string.today_progress_format, Integer.valueOf(i2), Integer.valueOf(i)));
        k0 k0Var3 = this.B;
        if (k0Var3 == null) {
            ii.d("binding");
            throw null;
        }
        k0Var3.j.setMax(i);
        if (i2 <= i) {
            i = i2;
        }
        rd rdVar4 = this.C;
        if (rdVar4 == null) {
            ii.d("prefs");
            throw null;
        }
        boolean zA = rdVar4.a();
        k0 k0Var4 = this.B;
        if (!zA) {
            if (k0Var4 != null) {
                k0Var4.j.setProgress(i);
                return;
            } else {
                ii.d("binding");
                throw null;
            }
        }
        if (k0Var4 == null) {
            ii.d("binding");
            throw null;
        }
        ProgressBar progressBar = k0Var4.j;
        byte[] bArr = c.w;
        ArrayList arrayList = new ArrayList(8);
        int i3 = 0;
        int i4 = 0;
        while (i3 < 8) {
            int i5 = i4 + 1;
            arrayList.add(Byte.valueOf((byte) ((i4 % 2 == 0 ? 241 : 222) ^ (bArr[i3] & 255))));
            i3++;
            i4 = i5;
        }
        ObjectAnimator objectAnimatorOfInt = ObjectAnimator.ofInt(progressBar, new String(o7.Q(arrayList), n6.a), 0, i);
        objectAnimatorOfInt.setDuration(500L);
        objectAnimatorOfInt.start();
    }
}
