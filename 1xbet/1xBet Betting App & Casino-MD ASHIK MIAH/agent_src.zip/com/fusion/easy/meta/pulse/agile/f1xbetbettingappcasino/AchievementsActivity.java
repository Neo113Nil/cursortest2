package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.snackbar.SnackbarContentLayout;
import com.google.android.material.snackbar.g;
import defpackage.a0;
import defpackage.b0;
import defpackage.dc;
import defpackage.ea;
import defpackage.g0;
import defpackage.ii;
import defpackage.md;
import defpackage.o7;
import defpackage.rd;
import defpackage.x;
import defpackage.y;
import defpackage.y1;
import defpackage.z;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class AchievementsActivity extends y1 {
    public static final /* synthetic */ int D = 0;
    public g0 B;
    public rd C;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("INIT", 0), new a("READY", 1), new a("RUNNING", 2), new a("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("AUTO", 0), new b("MANUAL", 1), new b("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    public AchievementsActivity() {
        Math.max(82, 15);
        String.valueOf(96);
        System.currentTimeMillis();
        System.currentTimeMillis();
        System.currentTimeMillis();
        System.currentTimeMillis();
        ((3 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) == 0 ? null : "").getClass();
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_achievements, (ViewGroup) null, false);
        int i = R.id.recyclerAchievements;
        RecyclerView recyclerView = (RecyclerView) dc.p(viewInflate, R.id.recyclerAchievements);
        if (recyclerView != null) {
            i = R.id.toolbar;
            MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
            if (materialToolbar != null) {
                LinearLayout linearLayout = (LinearLayout) viewInflate;
                this.B = new g0(linearLayout, recyclerView, materialToolbar);
                setContentView(linearLayout);
                this.C = new rd(this);
                g0 g0Var = this.B;
                if (g0Var == null) {
                    ii.d("binding");
                    throw null;
                }
                y((MaterialToolbar) g0Var.b);
                b0 b0VarX = x();
                if (b0VarX != null) {
                    b0VarX.m(true);
                }
                g0 g0Var2 = this.B;
                if (g0Var2 == null) {
                    ii.d("binding");
                    throw null;
                }
                ((MaterialToolbar) g0Var2.b).setNavigationOnClickListener(new a0(0, this));
                g0 g0Var3 = this.B;
                if (g0Var3 != null) {
                    ((RecyclerView) g0Var3.a).setLayoutManager(new GridLayoutManager());
                    return;
                } else {
                    ii.d("binding");
                    throw null;
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    /* JADX WARN: Removed duplicated region for block: B:104:0x00af A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:107:0x00ad A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:109:? A[LOOP:1: B:27:0x0085->B:109:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00a1  */
    @Override // defpackage.oe, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onResume() {
        Object next;
        ViewGroup viewGroup;
        super.onResume();
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        ArrayList arrayListC = rdVar.c(ea.b(rdVar));
        g0 g0Var = this.B;
        if (g0Var == null) {
            ii.d("binding");
            throw null;
        }
        RecyclerView recyclerView = (RecyclerView) g0Var.a;
        List<z> list = y.a;
        rd rdVar2 = this.C;
        if (rdVar2 == null) {
            ii.d("prefs");
            throw null;
        }
        Set setU = o7.U(arrayListC);
        rd rdVar3 = this.C;
        if (rdVar3 == null) {
            ii.d("prefs");
            throw null;
        }
        recyclerView.setAdapter(new x(list, rdVar2, setU, rdVar3.a()));
        if (arrayListC.isEmpty()) {
            return;
        }
        int iIntValue = ((Number) o7.I(arrayListC)).intValue();
        Iterator<T> it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((z) next).a == iIntValue) {
                    break;
                }
            }
        }
        z zVar = (z) next;
        Integer numValueOf = zVar != null ? Integer.valueOf(zVar.c) : null;
        if (numValueOf != null) {
            g0 g0Var2 = this.B;
            if (g0Var2 == null) {
                ii.d("binding");
                throw null;
            }
            View view = (LinearLayout) g0Var2.c;
            String string = getString(R.string.achievement_snackbar, getString(numValueOf.intValue()));
            int[] iArr = Snackbar.A;
            ViewGroup viewGroup2 = null;
            while (true) {
                if (view instanceof CoordinatorLayout) {
                    viewGroup = (ViewGroup) view;
                    break;
                }
                if (!(view instanceof FrameLayout)) {
                    if (view == null) {
                        Object parent = view.getParent();
                        view = parent instanceof View ? (View) parent : null;
                    }
                    if (view != null) {
                        viewGroup = viewGroup2;
                        break;
                    }
                } else if (view.getId() == 16908290) {
                    viewGroup = (ViewGroup) view;
                    break;
                } else {
                    viewGroup2 = (ViewGroup) view;
                    if (view == null) {
                    }
                    if (view != null) {
                    }
                }
            }
            if (viewGroup == null) {
                md.l("No suitable parent found from the given view. Please provide a valid view.");
                return;
            }
            Context context = viewGroup.getContext();
            LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Snackbar.A);
            boolean z = false;
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, -1);
            int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(1, -1);
            typedArrayObtainStyledAttributes.recycle();
            SnackbarContentLayout snackbarContentLayout = (SnackbarContentLayout) layoutInflaterFrom.inflate((resourceId == -1 || resourceId2 == -1) ? R.layout.design_layout_snackbar_include : R.layout.mtrl_layout_snackbar_include, viewGroup, false);
            Snackbar snackbar = new Snackbar(context, viewGroup, snackbarContentLayout, snackbarContentLayout);
            ((SnackbarContentLayout) snackbar.i.getChildAt(0)).getMessageView().setText(string);
            g gVarB = g.b();
            int recommendedTimeoutMillis = Build.VERSION.SDK_INT >= 29 ? snackbar.z.getRecommendedTimeoutMillis(0, 3) : 0;
            BaseTransientBottomBar.e eVar = snackbar.s;
            synchronized (gVarB.a) {
                try {
                    if (gVarB.c(eVar)) {
                        g.c cVar = gVarB.c;
                        cVar.b = recommendedTimeoutMillis;
                        gVarB.b.removeCallbacksAndMessages(cVar);
                        gVarB.f(gVarB.c);
                        return;
                    }
                    g.c cVar2 = gVarB.d;
                    if (cVar2 != null && cVar2.a.get() == eVar) {
                        z = true;
                    }
                    if (z) {
                        gVarB.d.b = recommendedTimeoutMillis;
                    } else {
                        gVarB.d = new g.c(recommendedTimeoutMillis, eVar);
                    }
                    g.c cVar3 = gVarB.c;
                    if (cVar3 == null || !gVarB.a(cVar3, 4)) {
                        gVarB.c = null;
                        g.c cVar4 = gVarB.d;
                        if (cVar4 != null) {
                            gVarB.c = cVar4;
                            gVarB.d = null;
                            g.b bVar = cVar4.a.get();
                            if (bVar != null) {
                                bVar.a();
                            } else {
                                gVarB.c = null;
                            }
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }
}
