package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Toast;
import defpackage.bt;
import defpackage.ea;
import defpackage.ii;
import defpackage.lo;
import defpackage.m0;
import defpackage.m7;
import defpackage.o7;
import defpackage.pd;
import defpackage.qd;
import defpackage.rd;
import defpackage.uc;
import defpackage.w9;
import defpackage.y1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class StudyActivity extends y1 {
    public m0 B;
    public rd C;

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ int a = 0;

        static {
            new LinkedHashMap();
        }
    }

    public StudyActivity() {
        System.currentTimeMillis();
        System.identityHashCode(this);
        Math.min(61, 53);
        Math.max(41, 20);
        int i = a.a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v13, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r9v14, types: [java.util.AbstractList, java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v3, types: [uc] */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5, types: [java.lang.Iterable] */
    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        Object obj;
        ?? P;
        Object obj2;
        String string;
        super.onCreate(bundle);
        int i = 0;
        m0 m0VarA = m0.a(getLayoutInflater().inflate(R.layout.activity_study, (ViewGroup) null, false));
        this.B = m0VarA;
        setContentView(m0VarA.a);
        rd rdVar = new rd(this);
        this.C = rdVar;
        rdVar.m();
        rd rdVar2 = this.C;
        if (rdVar2 == null) {
            ii.d("prefs");
            throw null;
        }
        rdVar2.l();
        rd rdVar3 = this.C;
        if (rdVar3 == null) {
            ii.d("prefs");
            throw null;
        }
        SharedPreferences sharedPreferences = rdVar3.a;
        sharedPreferences.edit().putInt("total_sessions", sharedPreferences.getInt("total_sessions", 0) + 1).apply();
        int intExtra = getIntent().getIntExtra(qd.a, -1);
        rd rdVar4 = this.C;
        if (rdVar4 == null) {
            ii.d("prefs");
            throw null;
        }
        ArrayList arrayListB = ea.b(rdVar4);
        rd rdVar5 = this.C;
        if (rdVar5 == null) {
            ii.d("prefs");
            throw null;
        }
        ArrayList arrayListB2 = ea.b(rdVar5);
        if (intExtra == -1) {
            ArrayList arrayList = new ArrayList();
            int size = arrayListB2.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj3 = arrayListB2.get(i2);
                i2++;
                m7.H(arrayList, ((w9) obj3).g);
            }
            ArrayList arrayList2 = new ArrayList();
            int size2 = arrayList.size();
            int i3 = 0;
            while (i3 < size2) {
                Object obj4 = arrayList.get(i3);
                i3++;
                pd pdVar = (pd) obj4;
                rd rdVar6 = this.C;
                if (rdVar6 == null) {
                    ii.d("prefs");
                    throw null;
                }
                if (rdVar6.e(pdVar.a) < 5) {
                    arrayList2.add(obj4);
                }
            }
            if (arrayList2.isEmpty()) {
                P = new ArrayList();
                int size3 = arrayListB2.size();
                int i4 = 0;
                while (i4 < size3) {
                    Object obj5 = arrayListB2.get(i4);
                    i4++;
                    m7.H(P, ((w9) obj5).g);
                }
            } else {
                List listO = o7.O(arrayList2, new lo(this, 1));
                rd rdVar7 = this.C;
                if (rdVar7 == null) {
                    ii.d("prefs");
                    throw null;
                }
                P = o7.P(rdVar7.a.getInt("daily_goal", 20), listO);
            }
        } else {
            int size4 = arrayListB2.size();
            int i5 = 0;
            while (true) {
                if (i5 >= size4) {
                    obj = null;
                    break;
                }
                obj = arrayListB2.get(i5);
                i5++;
                if (((w9) obj).a == intExtra) {
                    break;
                }
            }
            w9 w9Var = (w9) obj;
            P = w9Var != null ? w9Var.g : 0;
            if (P == 0) {
                P = uc.a;
            }
        }
        rd rdVar8 = this.C;
        if (rdVar8 == null) {
            ii.d("prefs");
            throw null;
        }
        List list = P;
        if (rdVar8.a.getBoolean("shuffle_cards", true)) {
            List listT = o7.T(P);
            Collections.shuffle(listT);
            list = listT;
        }
        if (list.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_cards_for_session), 0).show();
            finish();
            return;
        }
        if (intExtra == -1) {
            string = getString(R.string.study_all_title);
        } else {
            int size5 = arrayListB.size();
            while (true) {
                if (i >= size5) {
                    obj2 = null;
                    break;
                }
                obj2 = arrayListB.get(i);
                i++;
                if (((w9) obj2).a == intExtra) {
                    break;
                }
            }
            w9 w9Var2 = (w9) obj2;
            if (w9Var2 != null) {
                string = w9Var2.b;
            } else {
                string = getString(R.string.study_all_title);
                string.getClass();
            }
        }
        string.getClass();
        m0 m0Var = this.B;
        if (m0Var == null) {
            ii.d("binding");
            throw null;
        }
        rd rdVar9 = this.C;
        if (rdVar9 == null) {
            ii.d("prefs");
            throw null;
        }
        String str = string;
        ArrayList arrayList3 = new ArrayList(list);
        String str2 = qd.f;
        String string2 = getString(R.string.study_toolbar_format, str);
        string2.getClass();
        new bt(this, m0Var, rdVar9, arrayList3, str2, intExtra, string2, false).d();
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onPause() {
        super.onPause();
        rd rdVar = this.C;
        if (rdVar != null) {
            rdVar.c(ea.b(rdVar));
        } else {
            ii.d("prefs");
            throw null;
        }
    }
}
