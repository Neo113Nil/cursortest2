package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.DecksActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ProgressActivity;
import com.google.android.material.appbar.MaterialToolbar;
import defpackage.b0;
import defpackage.da;
import defpackage.dc;
import defpackage.ea;
import defpackage.ei;
import defpackage.fi;
import defpackage.i7;
import defpackage.ii;
import defpackage.j7;
import defpackage.lo;
import defpackage.m0;
import defpackage.m2;
import defpackage.m7;
import defpackage.md;
import defpackage.mi;
import defpackage.o7;
import defpackage.pd;
import defpackage.rd;
import defpackage.v1;
import defpackage.w9;
import defpackage.y1;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class ProgressActivity extends y1 {
    public static final /* synthetic */ int D = 0;
    public m0 B;
    public rd C;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("AUTO", 0), new a("MANUAL", 1), new a("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("AUTO", 0), new b("MANUAL", 1), new b("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class c {
        public static final /* synthetic */ c[] a = {new c("NONE", 0), new c("DEFAULT", 1), new c("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        c EF5;

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) a.clone();
        }
    }

    public ProgressActivity() {
        System.currentTimeMillis();
        System.currentTimeMillis();
        String.valueOf(15);
        Math.max(39, 92);
        ((7 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) == 0 ? null : "").getClass();
    }

    public final void A(TextView textView, int i) {
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        if (!rdVar.a()) {
            textView.setText(getString(R.string.stat_value_format, Integer.valueOf(i)));
            return;
        }
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(0, i);
        valueAnimatorOfInt.setDuration(1200L);
        valueAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfInt.addUpdateListener(new v1(textView, this, 1));
        valueAnimatorOfInt.start();
    }

    public final void B(mi miVar, int i, String str) {
        miVar.a.setText(str);
        A(miVar.b, i);
    }

    /* JADX WARN: Code restructure failed: missing block: B:118:0x0319, code lost:
    
        defpackage.md.w("Missing required view with ID: ".concat(r11.getResources().getResourceName(r10)));
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x0328, code lost:
    
        return;
     */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) throws Throwable {
        int i;
        int i2;
        int i3;
        super.onCreate(bundle);
        Throwable th = null;
        boolean z = false;
        Object[] objArr = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_progress, (ViewGroup) null, false);
        int i4 = R.id.btnAllDecks;
        Button button = (Button) dc.p(viewInflate, R.id.btnAllDecks);
        if (button != null) {
            i4 = R.id.deckProgressColumn;
            LinearLayout linearLayout = (LinearLayout) dc.p(viewInflate, R.id.deckProgressColumn);
            if (linearLayout != null) {
                i4 = R.id.heroCard;
                if (((LinearLayout) dc.p(viewInflate, R.id.heroCard)) != null) {
                    i4 = R.id.levelColumn;
                    LinearLayout linearLayout2 = (LinearLayout) dc.p(viewInflate, R.id.levelColumn);
                    if (linearLayout2 != null) {
                        i4 = R.id.statCards;
                        View viewP = dc.p(viewInflate, R.id.statCards);
                        if (viewP != null) {
                            mi miVarA = mi.a(viewP);
                            i4 = R.id.statDecks;
                            View viewP2 = dc.p(viewInflate, R.id.statDecks);
                            if (viewP2 != null) {
                                mi miVarA2 = mi.a(viewP2);
                                i4 = R.id.statMastered;
                                View viewP3 = dc.p(viewInflate, R.id.statMastered);
                                if (viewP3 != null) {
                                    mi miVarA3 = mi.a(viewP3);
                                    i4 = R.id.statQuizzes;
                                    View viewP4 = dc.p(viewInflate, R.id.statQuizzes);
                                    if (viewP4 != null) {
                                        mi miVarA4 = mi.a(viewP4);
                                        i4 = R.id.statSessions;
                                        View viewP5 = dc.p(viewInflate, R.id.statSessions);
                                        if (viewP5 != null) {
                                            mi miVarA5 = mi.a(viewP5);
                                            i4 = R.id.statStreak;
                                            View viewP6 = dc.p(viewInflate, R.id.statStreak);
                                            if (viewP6 != null) {
                                                mi miVarA6 = mi.a(viewP6);
                                                i4 = R.id.toolbar;
                                                MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                                if (materialToolbar != null) {
                                                    i4 = R.id.txtHeroCount;
                                                    TextView textView = (TextView) dc.p(viewInflate, R.id.txtHeroCount);
                                                    if (textView != null) {
                                                        i4 = R.id.txtHeroPercent;
                                                        TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtHeroPercent);
                                                        if (textView2 != null) {
                                                            i4 = R.id.weekBars;
                                                            LinearLayout linearLayout3 = (LinearLayout) dc.p(viewInflate, R.id.weekBars);
                                                            if (linearLayout3 != null) {
                                                                LinearLayout linearLayout4 = (LinearLayout) viewInflate;
                                                                this.B = new m0(linearLayout4, button, linearLayout, linearLayout2, miVarA, miVarA2, miVarA3, miVarA4, miVarA5, miVarA6, materialToolbar, textView, textView2, linearLayout3);
                                                                setContentView(linearLayout4);
                                                                this.C = new rd(this);
                                                                m0 m0Var = this.B;
                                                                String str = "binding";
                                                                if (m0Var == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                y(m0Var.e);
                                                                b0 b0VarX = x();
                                                                final int i5 = 1;
                                                                if (b0VarX != null) {
                                                                    b0VarX.m(true);
                                                                }
                                                                m0 m0Var2 = this.B;
                                                                if (m0Var2 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                MaterialToolbar materialToolbar2 = m0Var2.e;
                                                                final Object[] objArr2 = objArr == true ? 1 : 0;
                                                                materialToolbar2.setNavigationOnClickListener(new View.OnClickListener(this) { // from class: ko
                                                                    public final /* synthetic */ ProgressActivity b;

                                                                    {
                                                                        this.b = this;
                                                                    }

                                                                    @Override // android.view.View.OnClickListener
                                                                    public final void onClick(View view) {
                                                                        int i6 = objArr2;
                                                                        ProgressActivity progressActivity = this.b;
                                                                        switch (i6) {
                                                                            case 0:
                                                                                int i7 = ProgressActivity.D;
                                                                                progressActivity.finish();
                                                                                break;
                                                                            default:
                                                                                int i8 = ProgressActivity.D;
                                                                                progressActivity.startActivity(new Intent(progressActivity, (Class<?>) DecksActivity.class));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                                m0 m0Var3 = this.B;
                                                                if (m0Var3 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                m0Var3.c.setOnClickListener(new View.OnClickListener(this) { // from class: ko
                                                                    public final /* synthetic */ ProgressActivity b;

                                                                    {
                                                                        this.b = this;
                                                                    }

                                                                    @Override // android.view.View.OnClickListener
                                                                    public final void onClick(View view) {
                                                                        int i6 = i5;
                                                                        ProgressActivity progressActivity = this.b;
                                                                        switch (i6) {
                                                                            case 0:
                                                                                int i7 = ProgressActivity.D;
                                                                                progressActivity.finish();
                                                                                break;
                                                                            default:
                                                                                int i8 = ProgressActivity.D;
                                                                                progressActivity.startActivity(new Intent(progressActivity, (Class<?>) DecksActivity.class));
                                                                                break;
                                                                        }
                                                                    }
                                                                });
                                                                rd rdVar = this.C;
                                                                String str2 = "prefs";
                                                                if (rdVar == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                ArrayList arrayListB = ea.b(rdVar);
                                                                ArrayList arrayList = new ArrayList();
                                                                int size = arrayListB.size();
                                                                int i6 = 0;
                                                                while (i6 < size) {
                                                                    Object obj = arrayListB.get(i6);
                                                                    i6++;
                                                                    m7.H(arrayList, ((w9) obj).g);
                                                                }
                                                                rd rdVar2 = this.C;
                                                                if (rdVar2 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                int i7 = rdVar2.a.getInt("total_studied", 0);
                                                                rd rdVar3 = this.C;
                                                                if (rdVar3 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                SharedPreferences sharedPreferences = rdVar3.a;
                                                                int i8 = sharedPreferences.getInt("total_studied", 0);
                                                                if (i8 < 1) {
                                                                    i8 = 1;
                                                                }
                                                                int i9 = (sharedPreferences.getInt("total_correct", 0) * 100) / i8;
                                                                m0 m0Var4 = this.B;
                                                                if (m0Var4 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                A(m0Var4.f, i7);
                                                                m0 m0Var5 = this.B;
                                                                if (m0Var5 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                m0Var5.g.setText(getString(R.string.correct_percent_format, Integer.valueOf(i9)));
                                                                m0 m0Var6 = this.B;
                                                                if (m0Var6 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar = (mi) m0Var6.m;
                                                                rd rdVar4 = this.C;
                                                                if (rdVar4 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                int iG = rdVar4.g();
                                                                String string = getString(R.string.stat_streak);
                                                                string.getClass();
                                                                B(miVar, iG, string);
                                                                m0 m0Var7 = this.B;
                                                                if (m0Var7 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar2 = (mi) m0Var7.i;
                                                                int size2 = arrayListB.size();
                                                                String string2 = getString(R.string.stat_decks);
                                                                string2.getClass();
                                                                B(miVar2, size2, string2);
                                                                m0 m0Var8 = this.B;
                                                                if (m0Var8 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar3 = (mi) m0Var8.h;
                                                                int size3 = arrayList.size();
                                                                String string3 = getString(R.string.stat_cards);
                                                                string3.getClass();
                                                                B(miVar3, size3, string3);
                                                                if (arrayList.isEmpty()) {
                                                                    i = 0;
                                                                } else {
                                                                    int size4 = arrayList.size();
                                                                    i = 0;
                                                                    int i10 = 0;
                                                                    while (i10 < size4) {
                                                                        Object obj2 = arrayList.get(i10);
                                                                        i10++;
                                                                        pd pdVar = (pd) obj2;
                                                                        rd rdVar5 = this.C;
                                                                        if (rdVar5 == null) {
                                                                            ii.d("prefs");
                                                                            throw null;
                                                                        }
                                                                        if (rdVar5.e(pdVar.a) == 5 && (i = i + 1) < 0) {
                                                                            throw new ArithmeticException("Count overflow has happened.");
                                                                        }
                                                                    }
                                                                }
                                                                m0 m0Var9 = this.B;
                                                                if (m0Var9 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar4 = (mi) m0Var9.j;
                                                                String string4 = getString(R.string.stat_mastered);
                                                                string4.getClass();
                                                                B(miVar4, i, string4);
                                                                m0 m0Var10 = this.B;
                                                                if (m0Var10 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar5 = (mi) m0Var10.k;
                                                                rd rdVar6 = this.C;
                                                                if (rdVar6 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                int i11 = rdVar6.a.getInt("total_quizzes", 0);
                                                                String string5 = getString(R.string.stat_quizzes);
                                                                string5.getClass();
                                                                B(miVar5, i11, string5);
                                                                m0 m0Var11 = this.B;
                                                                if (m0Var11 == null) {
                                                                    ii.d("binding");
                                                                    throw null;
                                                                }
                                                                mi miVar6 = (mi) m0Var11.l;
                                                                rd rdVar7 = this.C;
                                                                if (rdVar7 == null) {
                                                                    ii.d("prefs");
                                                                    throw null;
                                                                }
                                                                int i12 = rdVar7.a.getInt("total_sessions", 0);
                                                                String string6 = getString(R.string.stat_sessions);
                                                                string6.getClass();
                                                                B(miVar6, i12, string6);
                                                                LayoutInflater layoutInflaterFrom = LayoutInflater.from(this);
                                                                ArrayList arrayList2 = new ArrayList();
                                                                int size5 = arrayListB.size();
                                                                int i13 = 0;
                                                                while (i13 < size5) {
                                                                    Object obj3 = arrayListB.get(i13);
                                                                    i13++;
                                                                    Throwable th2 = th;
                                                                    if (!((w9) obj3).g.isEmpty()) {
                                                                        arrayList2.add(obj3);
                                                                    }
                                                                    th = th2;
                                                                }
                                                                Throwable th3 = th;
                                                                Iterator it = o7.P(5, o7.O(arrayList2, new lo(this, 0))).iterator();
                                                                while (true) {
                                                                    boolean zHasNext = it.hasNext();
                                                                    int i14 = R.id.progressBar;
                                                                    if (!zHasNext) {
                                                                        LayoutInflater layoutInflaterFrom2 = LayoutInflater.from(this);
                                                                        rd rdVar8 = this.C;
                                                                        if (rdVar8 == null) {
                                                                            ii.d("prefs");
                                                                            throw th3;
                                                                        }
                                                                        LocalDate localDateNow = LocalDate.now();
                                                                        ei eiVar = new ei(6, 0, -1);
                                                                        ArrayList arrayList3 = new ArrayList(j7.G(eiVar));
                                                                        Iterator<Integer> it2 = eiVar.iterator();
                                                                        while (((fi) it2).c) {
                                                                            LocalDate localDateMinusDays = localDateNow.minusDays(((fi) it2).nextInt());
                                                                            arrayList3.add(Integer.valueOf(rdVar8.a.getInt("activity_" + localDateMinusDays, 0)));
                                                                        }
                                                                        Integer num = (Integer) o7.L(arrayList3);
                                                                        if (num != null) {
                                                                            int iIntValue = num.intValue();
                                                                            if (iIntValue < 1) {
                                                                                iIntValue = 1;
                                                                            }
                                                                            i2 = iIntValue;
                                                                        } else {
                                                                            i2 = 1;
                                                                        }
                                                                        String[] stringArray = getResources().getStringArray(R.array.weekday_short);
                                                                        stringArray.getClass();
                                                                        LocalDate localDateNow2 = LocalDate.now();
                                                                        int size6 = arrayList3.size();
                                                                        int i15 = 0;
                                                                        int i16 = 0;
                                                                        while (i16 < size6) {
                                                                            Object obj4 = arrayList3.get(i16);
                                                                            i16++;
                                                                            int i17 = i15 + 1;
                                                                            if (i15 < 0) {
                                                                                i7.F();
                                                                                throw th3;
                                                                            }
                                                                            int iIntValue2 = ((Number) obj4).intValue();
                                                                            m0 m0Var12 = this.B;
                                                                            if (m0Var12 == null) {
                                                                                ii.d(str);
                                                                                throw th3;
                                                                            }
                                                                            LinearLayout linearLayout5 = m0Var12.d;
                                                                            String str3 = str;
                                                                            View viewInflate2 = layoutInflaterFrom2.inflate(R.layout.item_week_bar, (ViewGroup) linearLayout5, false);
                                                                            linearLayout5.addView(viewInflate2);
                                                                            int i18 = R.id.barView;
                                                                            View viewP7 = dc.p(viewInflate2, R.id.barView);
                                                                            if (viewP7 != null) {
                                                                                TextView textView3 = (TextView) dc.p(viewInflate2, R.id.txtDay);
                                                                                if (textView3 != null) {
                                                                                    LayoutInflater layoutInflater = layoutInflaterFrom2;
                                                                                    TextView textView4 = (TextView) dc.p(viewInflate2, R.id.txtValue);
                                                                                    if (textView4 != null) {
                                                                                        String[] strArr = stringArray;
                                                                                        m2 m2Var = new m2(viewP7, textView3, textView4);
                                                                                        String str4 = str2;
                                                                                        ArrayList arrayList4 = arrayList;
                                                                                        textView3.setText(strArr[localDateNow2.minusDays(6 - i15).getDayOfWeek().getValue() - 1]);
                                                                                        textView4.setText(String.valueOf(iIntValue2));
                                                                                        int i19 = (int) ((iIntValue2 / i2) * ((int) (120.0f * getResources().getDisplayMetrics().density)));
                                                                                        if (i19 < 8) {
                                                                                            i19 = 8;
                                                                                        }
                                                                                        rd rdVar9 = this.C;
                                                                                        if (rdVar9 == null) {
                                                                                            ii.d(str4);
                                                                                            throw th3;
                                                                                        }
                                                                                        if (rdVar9.a()) {
                                                                                            viewP7.getLayoutParams().height = 8;
                                                                                            viewP7.requestLayout();
                                                                                            ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(8, i19);
                                                                                            valueAnimatorOfInt.setDuration(600L);
                                                                                            valueAnimatorOfInt.setStartDelay(i15 * 80);
                                                                                            valueAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
                                                                                            valueAnimatorOfInt.addUpdateListener(new da(2, m2Var));
                                                                                            valueAnimatorOfInt.start();
                                                                                        } else {
                                                                                            viewP7.getLayoutParams().height = i19;
                                                                                        }
                                                                                        i15 = i17;
                                                                                        str = str3;
                                                                                        layoutInflaterFrom2 = layoutInflater;
                                                                                        stringArray = strArr;
                                                                                        str2 = str4;
                                                                                        arrayList = arrayList4;
                                                                                    } else {
                                                                                        i18 = R.id.txtValue;
                                                                                    }
                                                                                } else {
                                                                                    i18 = R.id.txtDay;
                                                                                }
                                                                            }
                                                                            md.w("Missing required view with ID: ".concat(viewInflate2.getResources().getResourceName(i18)));
                                                                            return;
                                                                        }
                                                                        String str5 = str;
                                                                        String str6 = str2;
                                                                        int size7 = arrayList.size();
                                                                        LayoutInflater layoutInflaterFrom3 = LayoutInflater.from(this);
                                                                        rd rdVar10 = this.C;
                                                                        if (rdVar10 == null) {
                                                                            ii.d(str6);
                                                                            throw th3;
                                                                        }
                                                                        ArrayList arrayListA = ea.a(rdVar10);
                                                                        for (int i20 = 1; i20 < 6; i20++) {
                                                                            m0 m0Var13 = this.B;
                                                                            if (m0Var13 == null) {
                                                                                ii.d(str5);
                                                                                throw th3;
                                                                            }
                                                                            View viewInflate3 = layoutInflaterFrom3.inflate(R.layout.item_level_row, (ViewGroup) m0Var13.b, false);
                                                                            ProgressBar progressBar = (ProgressBar) dc.p(viewInflate3, R.id.progressBar);
                                                                            if (progressBar != null) {
                                                                                i3 = R.id.txtCount;
                                                                                TextView textView5 = (TextView) dc.p(viewInflate3, R.id.txtCount);
                                                                                if (textView5 != null) {
                                                                                    i3 = R.id.txtLevel;
                                                                                    TextView textView6 = (TextView) dc.p(viewInflate3, R.id.txtLevel);
                                                                                    if (textView6 != null) {
                                                                                        LinearLayout linearLayout6 = (LinearLayout) viewInflate3;
                                                                                        rd rdVar11 = this.C;
                                                                                        if (rdVar11 == null) {
                                                                                            ii.d(str6);
                                                                                            throw th3;
                                                                                        }
                                                                                        ArrayList arrayList5 = new ArrayList();
                                                                                        int size8 = arrayListA.size();
                                                                                        int i21 = 0;
                                                                                        while (i21 < size8) {
                                                                                            Object obj5 = arrayListA.get(i21);
                                                                                            i21++;
                                                                                            if (rdVar11.e(((pd) obj5).a) == i20) {
                                                                                                arrayList5.add(obj5);
                                                                                            }
                                                                                        }
                                                                                        int size9 = arrayList5.size();
                                                                                        textView6.setText(getString(R.string.level_row_format, Integer.valueOf(i20)));
                                                                                        textView5.setText(getString(R.string.cards_short_format, Integer.valueOf(size9)));
                                                                                        progressBar.setMax(size7 < 1 ? 1 : size7);
                                                                                        m0 m0Var14 = this.B;
                                                                                        if (m0Var14 == null) {
                                                                                            ii.d(str5);
                                                                                            throw th3;
                                                                                        }
                                                                                        m0Var14.b.addView(linearLayout6);
                                                                                        z(progressBar, size9, 700L);
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                i3 = R.id.progressBar;
                                                                            }
                                                                            md.w("Missing required view with ID: ".concat(viewInflate3.getResources().getResourceName(i3)));
                                                                            return;
                                                                        }
                                                                        return;
                                                                    }
                                                                    w9 w9Var = (w9) it.next();
                                                                    m0 m0Var15 = this.B;
                                                                    if (m0Var15 == null) {
                                                                        ii.d("binding");
                                                                        throw th3;
                                                                    }
                                                                    View viewInflate4 = layoutInflaterFrom.inflate(R.layout.item_deck_progress_row, m0Var15.a, z);
                                                                    ProgressBar progressBar2 = (ProgressBar) dc.p(viewInflate4, R.id.progressBar);
                                                                    if (progressBar2 == null) {
                                                                        break;
                                                                    }
                                                                    i14 = R.id.txtEmoji;
                                                                    TextView textView7 = (TextView) dc.p(viewInflate4, R.id.txtEmoji);
                                                                    if (textView7 == null) {
                                                                        break;
                                                                    }
                                                                    i14 = R.id.txtName;
                                                                    TextView textView8 = (TextView) dc.p(viewInflate4, R.id.txtName);
                                                                    if (textView8 == null) {
                                                                        break;
                                                                    }
                                                                    TextView textView9 = (TextView) dc.p(viewInflate4, R.id.txtPercent);
                                                                    if (textView9 == null) {
                                                                        i14 = R.id.txtPercent;
                                                                        break;
                                                                    }
                                                                    LinearLayout linearLayout7 = (LinearLayout) viewInflate4;
                                                                    rd rdVar12 = this.C;
                                                                    if (rdVar12 == null) {
                                                                        ii.d("prefs");
                                                                        throw th3;
                                                                    }
                                                                    int iJ = rdVar12.j(w9Var.g);
                                                                    textView7.setText(w9Var.c);
                                                                    textView8.setText(w9Var.b);
                                                                    textView9.setText(getString(R.string.percent_format, Integer.valueOf(iJ)));
                                                                    progressBar2.setMax(100);
                                                                    m0 m0Var16 = this.B;
                                                                    if (m0Var16 == null) {
                                                                        ii.d("binding");
                                                                        throw th3;
                                                                    }
                                                                    m0Var16.a.addView(linearLayout7);
                                                                    z(progressBar2, iJ, 800L);
                                                                    z = false;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i4)));
    }

    public final void z(ProgressBar progressBar, int i, long j) {
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        if (!rdVar.a()) {
            progressBar.setProgress(i);
            return;
        }
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(0, i);
        valueAnimatorOfInt.setDuration(j);
        valueAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfInt.addUpdateListener(new da(3, progressBar));
        valueAnimatorOfInt.start();
    }
}
