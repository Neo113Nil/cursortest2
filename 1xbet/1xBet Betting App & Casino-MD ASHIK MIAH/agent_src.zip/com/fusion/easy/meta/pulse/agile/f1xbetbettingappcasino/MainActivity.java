package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.R;
import defpackage.ac;
import defpackage.bc;
import defpackage.bx;
import defpackage.ff;
import defpackage.l0;
import defpackage.md;
import defpackage.nt;
import defpackage.nw;
import defpackage.qj;
import defpackage.qt;
import defpackage.rt;
import defpackage.ub;
import defpackage.vb;
import defpackage.wb;
import defpackage.xb;
import defpackage.y1;
import defpackage.yb;
import defpackage.yo;
import defpackage.zb;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class MainActivity extends y1 {
    public static final /* synthetic */ int E = 0;
    public final nt B;
    public String C;
    public final nt D;

    public MainActivity() {
        final int i = 0;
        this.B = new nt(new ff(this) { // from class: pj
            public final /* synthetic */ MainActivity b;

            {
                this.b = this;
            }

            @Override // defpackage.ff
            public final Object a() {
                int i2 = i;
                MainActivity mainActivity = this.b;
                switch (i2) {
                    case 0:
                        int i3 = MainActivity.E;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) dc.p(viewInflate, R.id.progressBar)) != null) {
                            return new l0(constraintLayout);
                        }
                        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                        return null;
                    default:
                        int i4 = MainActivity.E;
                        return mainActivity.getSharedPreferences("store", 0);
                }
            }
        });
        final int i2 = 1;
        this.D = new nt(new ff(this) { // from class: pj
            public final /* synthetic */ MainActivity b;

            {
                this.b = this;
            }

            @Override // defpackage.ff
            public final Object a() {
                int i22 = i2;
                MainActivity mainActivity = this.b;
                switch (i22) {
                    case 0:
                        int i3 = MainActivity.E;
                        View viewInflate = mainActivity.getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        if (((ProgressBar) dc.p(viewInflate, R.id.progressBar)) != null) {
                            return new l0(constraintLayout);
                        }
                        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.progressBar)));
                        return null;
                    default:
                        int i4 = MainActivity.E;
                        return mainActivity.getSharedPreferences("store", 0);
                }
            }
        });
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = 0;
        rt rtVar = new rt(0, 0, new qt());
        rt rtVar2 = new rt(wb.a, wb.b, new qt());
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        xb bcVar = wb.c;
        if (bcVar == null) {
            int i2 = Build.VERSION.SDK_INT;
            bcVar = i2 >= 35 ? new bc() : i2 >= 30 ? new ac() : i2 >= 29 ? new zb() : i2 >= 28 ? new yb() : new xb();
            wb.c = bcVar;
        }
        xb xbVar = bcVar;
        ub ubVar = new ub(xbVar, rtVar, rtVar2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                vb vbVar = new vb(ubVar, viewGroup.getContext());
                vbVar.setTag(xbVar);
                vbVar.setVisibility(8);
                vbVar.setWillNotDraw(true);
                viewGroup.addView(vbVar);
                break;
            }
            int i4 = i3 + 1;
            View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof xb) {
                break;
            } else {
                i3 = i4;
            }
        }
        ubVar.run();
        Window window = getWindow();
        window.getClass();
        xbVar.a(window);
        setContentView(((l0) this.B.a()).a);
        View viewFindViewById = findViewById(R.id.main);
        md mdVar = new md();
        WeakHashMap<View, bx> weakHashMap = nw.a;
        nw.d.c(viewFindViewById, mdVar);
        getWindow().setFlags(1024, 1024);
        Handler handler = new Handler(Looper.getMainLooper());
        qj qjVar = new qj(this, i);
        yo.a.getClass();
        handler.postDelayed(qjVar, yo.b.b());
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onResume() {
        super.onResume();
        String str = this.C;
        if (str != null) {
            z(str);
        }
    }

    public final void z(String str) {
        str.getClass();
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Exception unused) {
            startActivity(new Intent(this, (Class<?>) MainActivity2.class));
        }
    }
}
