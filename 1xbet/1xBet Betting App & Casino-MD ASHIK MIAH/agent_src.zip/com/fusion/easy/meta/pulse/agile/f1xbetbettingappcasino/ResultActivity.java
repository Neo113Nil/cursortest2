package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.DecksActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.QuizActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ResultActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ReviewActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.StudyActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ui.DeckProgressView;
import defpackage.da;
import defpackage.dc;
import defpackage.i7;
import defpackage.ii;
import defpackage.md;
import defpackage.od;
import defpackage.qd;
import defpackage.t0;
import defpackage.ua;
import defpackage.y1;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class ResultActivity extends y1 {
    public static final /* synthetic */ int G = 0;
    public t0 B;
    public int C;
    public int D;
    public String E;
    public int F;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("IDLE", 0), new a("LOADING", 1), new a("SUCCESS", 2), new a("ERROR", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("AUTO", 0), new b("MANUAL", 1), new b("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class c {
        public static final /* synthetic */ c[] a = {new c("NONE", 0), new c("DEFAULT", 1), new c("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        c EF5;

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) a.clone();
        }
    }

    public ResultActivity() {
        String str = qd.a;
        this.E = qd.f;
        this.F = -1;
        Math.abs(-53);
        Math.min(11, 30);
        System.currentTimeMillis();
        ((3 & 1) != 0 ? "" : null).getClass();
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_result, (ViewGroup) null, false);
        int i2 = R.id.btnAgain;
        Button button = (Button) dc.p(viewInflate, R.id.btnAgain);
        if (button != null) {
            i2 = R.id.btnToDecks;
            Button button2 = (Button) dc.p(viewInflate, R.id.btnToDecks);
            if (button2 != null) {
                i2 = R.id.progressView;
                DeckProgressView deckProgressView = (DeckProgressView) dc.p(viewInflate, R.id.progressView);
                if (deckProgressView != null) {
                    FrameLayout frameLayout = (FrameLayout) viewInflate;
                    i2 = R.id.txtEmoji;
                    TextView textView = (TextView) dc.p(viewInflate, R.id.txtEmoji);
                    if (textView != null) {
                        i2 = R.id.txtPercent;
                        TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtPercent);
                        if (textView2 != null) {
                            i2 = R.id.txtScore;
                            TextView textView3 = (TextView) dc.p(viewInflate, R.id.txtScore);
                            if (textView3 != null) {
                                i2 = R.id.txtTitle;
                                TextView textView4 = (TextView) dc.p(viewInflate, R.id.txtTitle);
                                if (textView4 != null) {
                                    this.B = new t0(frameLayout, button, button2, deckProgressView, frameLayout, textView, textView2, textView3, textView4);
                                    setContentView(frameLayout);
                                    SharedPreferences sharedPreferences = getSharedPreferences("wordflash_prefs", 0);
                                    sharedPreferences.getClass();
                                    this.C = getIntent().getIntExtra(qd.c, 0);
                                    int intExtra = getIntent().getIntExtra(qd.d, 0);
                                    final int i3 = 1;
                                    if (intExtra < 1) {
                                        intExtra = 1;
                                    }
                                    this.D = intExtra;
                                    String stringExtra = getIntent().getStringExtra(qd.e);
                                    if (stringExtra == null) {
                                        stringExtra = "";
                                    }
                                    if (stringExtra.length() == 0) {
                                        stringExtra = qd.f;
                                    }
                                    this.E = stringExtra;
                                    this.F = getIntent().getIntExtra(qd.a, -1);
                                    int i4 = (this.C * 100) / this.D;
                                    String str = i4 >= 80 ? "🎉" : i4 >= 60 ? "👍" : "💪";
                                    int i5 = i4 >= 80 ? R.string.result_excellent : i4 >= 60 ? R.string.result_good : R.string.result_keep;
                                    t0 t0Var = this.B;
                                    if (t0Var == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    t0Var.b.setText(str);
                                    t0 t0Var2 = this.B;
                                    if (t0Var2 == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    t0Var2.e.setText(getString(i5));
                                    t0 t0Var3 = this.B;
                                    if (t0Var3 == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    od.b(t0Var3.b, sharedPreferences.getBoolean("animations_enabled", true));
                                    if (sharedPreferences.getBoolean("animations_enabled", true)) {
                                        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(0, this.C);
                                        valueAnimatorOfInt.setDuration(800L);
                                        valueAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
                                        valueAnimatorOfInt.addUpdateListener(new da(4, this));
                                        valueAnimatorOfInt.start();
                                    } else {
                                        t0 t0Var4 = this.B;
                                        if (t0Var4 == null) {
                                            ii.d("binding");
                                            throw null;
                                        }
                                        t0Var4.d.setText(getString(R.string.result_correct_format, Integer.valueOf(this.C), Integer.valueOf(this.D)));
                                    }
                                    t0 t0Var5 = this.B;
                                    if (t0Var5 == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    t0Var5.c.setText(getString(R.string.percent_format, Integer.valueOf(i4)));
                                    t0 t0Var6 = this.B;
                                    if (t0Var6 == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    ((DeckProgressView) t0Var6.h).a(this.C / this.D, sharedPreferences.getBoolean("animations_enabled", true) ? 800L : 0L);
                                    if (i4 >= 80) {
                                        t0 t0Var7 = this.B;
                                        if (t0Var7 == null) {
                                            ii.d("binding");
                                            throw null;
                                        }
                                        FrameLayout frameLayout2 = t0Var7.a;
                                        frameLayout2.getClass();
                                        List listE = i7.E("⭐", "🌟", "✨", "🎊");
                                        if (sharedPreferences.getBoolean("animations_enabled", true)) {
                                            frameLayout2.post(new ua(frameLayout2, 20, listE, 1));
                                        }
                                    }
                                    t0 t0Var8 = this.B;
                                    if (t0Var8 == null) {
                                        ii.d("binding");
                                        throw null;
                                    }
                                    ((Button) t0Var8.f).setOnClickListener(new View.OnClickListener(this) { // from class: aq
                                        public final /* synthetic */ ResultActivity b;

                                        {
                                            this.b = this;
                                        }

                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view) {
                                            int i6 = i;
                                            ResultActivity resultActivity = this.b;
                                            switch (i6) {
                                                case 0:
                                                    String str2 = resultActivity.E;
                                                    Intent intent = new Intent(resultActivity, (Class<?>) (ii.a(str2, qd.g) ? QuizActivity.class : ii.a(str2, qd.h) ? ReviewActivity.class : StudyActivity.class));
                                                    intent.putExtra(qd.a, resultActivity.F);
                                                    resultActivity.startActivity(intent);
                                                    resultActivity.finish();
                                                    break;
                                                default:
                                                    int i7 = ResultActivity.G;
                                                    Intent intent2 = new Intent(resultActivity, (Class<?>) DecksActivity.class);
                                                    intent2.setFlags(268468224);
                                                    resultActivity.startActivity(intent2);
                                                    resultActivity.finish();
                                                    break;
                                            }
                                        }
                                    });
                                    t0 t0Var9 = this.B;
                                    if (t0Var9 != null) {
                                        ((Button) t0Var9.g).setOnClickListener(new View.OnClickListener(this) { // from class: aq
                                            public final /* synthetic */ ResultActivity b;

                                            {
                                                this.b = this;
                                            }

                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view) {
                                                int i6 = i3;
                                                ResultActivity resultActivity = this.b;
                                                switch (i6) {
                                                    case 0:
                                                        String str2 = resultActivity.E;
                                                        Intent intent = new Intent(resultActivity, (Class<?>) (ii.a(str2, qd.g) ? QuizActivity.class : ii.a(str2, qd.h) ? ReviewActivity.class : StudyActivity.class));
                                                        intent.putExtra(qd.a, resultActivity.F);
                                                        resultActivity.startActivity(intent);
                                                        resultActivity.finish();
                                                        break;
                                                    default:
                                                        int i7 = ResultActivity.G;
                                                        Intent intent2 = new Intent(resultActivity, (Class<?>) DecksActivity.class);
                                                        intent2.setFlags(268468224);
                                                        resultActivity.startActivity(intent2);
                                                        resultActivity.finish();
                                                        break;
                                                }
                                            }
                                        });
                                        return;
                                    } else {
                                        ii.d("binding");
                                        throw null;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
