package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import defpackage.bt;
import defpackage.c;
import defpackage.dc;
import defpackage.ea;
import defpackage.i7;
import defpackage.ii;
import defpackage.m0;
import defpackage.md;
import defpackage.o7;
import defpackage.pd;
import defpackage.qd;
import defpackage.rd;
import defpackage.ua;
import defpackage.ws;
import defpackage.y0;
import defpackage.y1;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class ReviewActivity extends y1 {
    public y0 B;
    public rd C;

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a<T> implements Comparator {
        public a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        public final int compare(T t, T t2) {
            pd pdVar = (pd) t;
            ReviewActivity reviewActivity = ReviewActivity.this;
            rd rdVar = reviewActivity.C;
            if (rdVar == null) {
                ii.d("prefs");
                throw null;
            }
            Integer numValueOf = Integer.valueOf(rdVar.e(pdVar.a));
            pd pdVar2 = (pd) t2;
            rd rdVar2 = reviewActivity.C;
            if (rdVar2 != null) {
                return c.h(numValueOf, Integer.valueOf(rdVar2.e(pdVar2.a)));
            }
            ii.d("prefs");
            throw null;
        }
    }

    public ReviewActivity() {
        System.currentTimeMillis();
        ws.c0("sample").toString();
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_review, (ViewGroup) null, false);
        int i = R.id.emptyLayer;
        FrameLayout frameLayout = (FrameLayout) dc.p(viewInflate, R.id.emptyLayer);
        if (frameLayout != null) {
            i = R.id.studyInclude;
            View viewP = dc.p(viewInflate, R.id.studyInclude);
            if (viewP != null) {
                m0 m0VarA = m0.a(viewP);
                if (((TextView) dc.p(viewInflate, R.id.txtEmpty)) != null) {
                    y0 y0Var = new y0();
                    y0Var.a = frameLayout;
                    y0Var.b = m0VarA;
                    this.B = y0Var;
                    setContentView((FrameLayout) viewInflate);
                    rd rdVar = new rd(this);
                    this.C = rdVar;
                    rdVar.m();
                    rd rdVar2 = this.C;
                    if (rdVar2 == null) {
                        ii.d("prefs");
                        throw null;
                    }
                    rdVar2.l();
                    rd rdVar3 = this.C;
                    if (rdVar3 == null) {
                        ii.d("prefs");
                        throw null;
                    }
                    ArrayList arrayListA = ea.a(rdVar3);
                    ArrayList arrayList = new ArrayList();
                    int size = arrayListA.size();
                    int i2 = 0;
                    while (i2 < size) {
                        Object obj = arrayListA.get(i2);
                        i2++;
                        pd pdVar = (pd) obj;
                        rd rdVar4 = this.C;
                        if (rdVar4 == null) {
                            ii.d("prefs");
                            throw null;
                        }
                        int iE = rdVar4.e(pdVar.a);
                        if (iE >= 0 && iE < 4) {
                            arrayList.add(obj);
                        }
                    }
                    List listO = o7.O(arrayList, new a());
                    if (listO.isEmpty()) {
                        y0 y0Var2 = this.B;
                        if (y0Var2 == null) {
                            ii.d("binding");
                            throw null;
                        }
                        ((m0) y0Var2.b).a.setVisibility(8);
                        y0 y0Var3 = this.B;
                        if (y0Var3 == null) {
                            ii.d("binding");
                            throw null;
                        }
                        ((FrameLayout) y0Var3.a).setVisibility(0);
                        y0 y0Var4 = this.B;
                        if (y0Var4 == null) {
                            ii.d("binding");
                            throw null;
                        }
                        FrameLayout frameLayout2 = (FrameLayout) y0Var4.a;
                        List listE = i7.E("🎉", "⭐", "🌟", "✨", "🎊", "🏆");
                        rd rdVar5 = this.C;
                        if (rdVar5 == null) {
                            ii.d("prefs");
                            throw null;
                        }
                        if (rdVar5.a()) {
                            frameLayout2.post(new ua(frameLayout2, 30, listE, 1));
                            return;
                        }
                        return;
                    }
                    rd rdVar6 = this.C;
                    if (rdVar6 == null) {
                        ii.d("prefs");
                        throw null;
                    }
                    SharedPreferences sharedPreferences = rdVar6.a;
                    sharedPreferences.edit().putInt("total_sessions", sharedPreferences.getInt("total_sessions", 0) + 1).apply();
                    y0 y0Var5 = this.B;
                    if (y0Var5 == null) {
                        ii.d("binding");
                        throw null;
                    }
                    ((FrameLayout) y0Var5.a).setVisibility(8);
                    y0 y0Var6 = this.B;
                    if (y0Var6 == null) {
                        ii.d("binding");
                        throw null;
                    }
                    m0 m0Var = (m0) y0Var6.b;
                    rd rdVar7 = this.C;
                    if (rdVar7 == null) {
                        ii.d("prefs");
                        throw null;
                    }
                    ArrayList arrayList2 = new ArrayList(listO);
                    String str = qd.h;
                    String string = getString(R.string.title_review);
                    string.getClass();
                    new bt(this, m0Var, rdVar7, arrayList2, str, -1, string, true).d();
                    m0Var.e.setSubtitle(getString(R.string.review_count_format, Integer.valueOf(listO.size())));
                    return;
                }
                i = R.id.txtEmpty;
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onPause() {
        super.onPause();
        rd rdVar = this.C;
        if (rdVar != null) {
            rdVar.c(ea.b(rdVar));
        } else {
            ii.d("prefs");
            throw null;
        }
    }
}
