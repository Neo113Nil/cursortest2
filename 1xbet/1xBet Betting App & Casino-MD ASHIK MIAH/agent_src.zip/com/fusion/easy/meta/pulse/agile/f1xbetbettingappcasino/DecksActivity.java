package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.CreateDeckActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.DecksActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import defpackage.aa;
import defpackage.b0;
import defpackage.dc;
import defpackage.ea;
import defpackage.fa;
import defpackage.g0;
import defpackage.ha;
import defpackage.ii;
import defpackage.md;
import defpackage.rd;
import defpackage.w9;
import defpackage.y1;
import java.util.ArrayList;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class DecksActivity extends y1 {
    public static final /* synthetic */ int D = 0;
    public g0 B;
    public rd C;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("AUTO", 0), new a("MANUAL", 1), new a("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("INIT", 0), new b("READY", 1), new b("RUNNING", 2), new b("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    public DecksActivity() {
        Math.abs(-47);
        System.currentTimeMillis();
        ((7 & 2) != 0 ? "" : null).getClass();
        ((7 & 2) == 0 ? null : "").getClass();
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_decks, (ViewGroup) null, false);
        int i2 = R.id.fabCreate;
        FloatingActionButton floatingActionButton = (FloatingActionButton) dc.p(viewInflate, R.id.fabCreate);
        if (floatingActionButton != null) {
            i2 = R.id.recyclerDecks;
            RecyclerView recyclerView = (RecyclerView) dc.p(viewInflate, R.id.recyclerDecks);
            if (recyclerView != null) {
                i2 = R.id.toolbar;
                MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                if (materialToolbar != null) {
                    g0 g0Var = new g0();
                    g0Var.c = floatingActionButton;
                    g0Var.a = recyclerView;
                    g0Var.b = materialToolbar;
                    this.B = g0Var;
                    setContentView((CoordinatorLayout) viewInflate);
                    this.C = new rd(this);
                    g0 g0Var2 = this.B;
                    if (g0Var2 == null) {
                        ii.d("binding");
                        throw null;
                    }
                    y((MaterialToolbar) g0Var2.b);
                    b0 b0VarX = x();
                    final int i3 = 1;
                    if (b0VarX != null) {
                        b0VarX.m(true);
                    }
                    g0 g0Var3 = this.B;
                    if (g0Var3 == null) {
                        ii.d("binding");
                        throw null;
                    }
                    ((MaterialToolbar) g0Var3.b).setNavigationOnClickListener(new View.OnClickListener(this) { // from class: ga
                        public final /* synthetic */ DecksActivity b;

                        {
                            this.b = this;
                        }

                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            int i4 = i;
                            DecksActivity decksActivity = this.b;
                            switch (i4) {
                                case 0:
                                    int i5 = DecksActivity.D;
                                    decksActivity.finish();
                                    break;
                                default:
                                    int i6 = DecksActivity.D;
                                    decksActivity.startActivity(new Intent(decksActivity, (Class<?>) CreateDeckActivity.class));
                                    break;
                            }
                        }
                    });
                    g0 g0Var4 = this.B;
                    if (g0Var4 == null) {
                        ii.d("binding");
                        throw null;
                    }
                    ((RecyclerView) g0Var4.a).setLayoutManager(new LinearLayoutManager(1));
                    g0 g0Var5 = this.B;
                    if (g0Var5 != null) {
                        ((FloatingActionButton) g0Var5.c).setOnClickListener(new View.OnClickListener(this) { // from class: ga
                            public final /* synthetic */ DecksActivity b;

                            {
                                this.b = this;
                            }

                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                int i4 = i3;
                                DecksActivity decksActivity = this.b;
                                switch (i4) {
                                    case 0:
                                        int i5 = DecksActivity.D;
                                        decksActivity.finish();
                                        break;
                                    default:
                                        int i6 = DecksActivity.D;
                                        decksActivity.startActivity(new Intent(decksActivity, (Class<?>) CreateDeckActivity.class));
                                        break;
                                }
                            }
                        });
                        return;
                    } else {
                        ii.d("binding");
                        throw null;
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onResume() {
        super.onResume();
        z();
    }

    public final void z() {
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        ArrayList arrayListB = ea.b(rdVar);
        ArrayList arrayList = new ArrayList();
        int size = arrayListB.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListB.get(i);
            i++;
            if (((w9) obj).f) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        int size2 = arrayListB.size();
        int i2 = 0;
        while (i2 < size2) {
            Object obj2 = arrayListB.get(i2);
            i2++;
            if (!((w9) obj2).f) {
                arrayList2.add(obj2);
            }
        }
        ArrayList arrayList3 = new ArrayList();
        String string = getString(R.string.header_builtin);
        string.getClass();
        arrayList3.add(new fa.a(string));
        int size3 = arrayList.size();
        int i3 = 0;
        while (i3 < size3) {
            Object obj3 = arrayList.get(i3);
            i3++;
            w9 w9Var = (w9) obj3;
            int size4 = w9Var.g.size();
            rd rdVar2 = this.C;
            if (rdVar2 == null) {
                ii.d("prefs");
                throw null;
            }
            arrayList3.add(new fa.b(w9Var, size4, rdVar2.j(w9Var.g)));
        }
        String string2 = getString(R.string.header_custom);
        string2.getClass();
        arrayList3.add(new fa.a(string2));
        int size5 = arrayList2.size();
        int i4 = 0;
        while (i4 < size5) {
            Object obj4 = arrayList2.get(i4);
            i4++;
            w9 w9Var2 = (w9) obj4;
            int size6 = w9Var2.g.size();
            rd rdVar3 = this.C;
            if (rdVar3 == null) {
                ii.d("prefs");
                throw null;
            }
            arrayList3.add(new fa.b(w9Var2, size6, rdVar3.j(w9Var2.g)));
        }
        g0 g0Var = this.B;
        if (g0Var == null) {
            ii.d("binding");
            throw null;
        }
        RecyclerView recyclerView = (RecyclerView) g0Var.a;
        rd rdVar4 = this.C;
        if (rdVar4 != null) {
            recyclerView.setAdapter(new aa(arrayList3, rdVar4.a(), new ha(this, 0), new ha(this, 1), new ha(this, 2)));
        } else {
            ii.d("prefs");
            throw null;
        }
    }
}
