package com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.CreateCardActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.DeckDetailActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.QuizActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.StudyActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.ui.DeckProgressView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import defpackage.b0;
import defpackage.b6;
import defpackage.dc;
import defpackage.ea;
import defpackage.g;
import defpackage.i0;
import defpackage.ii;
import defpackage.md;
import defpackage.pd;
import defpackage.qd;
import defpackage.rd;
import defpackage.w9;
import defpackage.y1;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class DeckDetailActivity extends y1 {
    public static final /* synthetic */ int E = 0;
    public i0 B;
    public rd C;
    public int D = -1;

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a {
        public static final /* synthetic */ int a = 0;

        static {
            new LinkedHashMap();
        }
    }

    public DeckDetailActivity() {
        Math.abs(66);
        System.currentTimeMillis();
        System.identityHashCode(this);
        String.valueOf(7);
        int i = a.a;
    }

    @Override // defpackage.oe, androidx.activity.ComponentActivity, defpackage.a8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_deck_detail, (ViewGroup) null, false);
        int i2 = R.id.btnQuizDeck;
        Button button = (Button) dc.p(viewInflate, R.id.btnQuizDeck);
        if (button != null) {
            i2 = R.id.btnStudyDeck;
            Button button2 = (Button) dc.p(viewInflate, R.id.btnStudyDeck);
            if (button2 != null) {
                i2 = R.id.fabAddCard;
                FloatingActionButton floatingActionButton = (FloatingActionButton) dc.p(viewInflate, R.id.fabAddCard);
                if (floatingActionButton != null) {
                    i2 = R.id.headerColor;
                    View viewP = dc.p(viewInflate, R.id.headerColor);
                    if (viewP != null) {
                        i2 = R.id.headerFrame;
                        if (((FrameLayout) dc.p(viewInflate, R.id.headerFrame)) != null) {
                            i2 = R.id.progressView;
                            DeckProgressView deckProgressView = (DeckProgressView) dc.p(viewInflate, R.id.progressView);
                            if (deckProgressView != null) {
                                i2 = R.id.recyclerCards;
                                RecyclerView recyclerView = (RecyclerView) dc.p(viewInflate, R.id.recyclerCards);
                                if (recyclerView != null) {
                                    i2 = R.id.toolbar;
                                    MaterialToolbar materialToolbar = (MaterialToolbar) dc.p(viewInflate, R.id.toolbar);
                                    if (materialToolbar != null) {
                                        i2 = R.id.txtHeaderEmoji;
                                        TextView textView = (TextView) dc.p(viewInflate, R.id.txtHeaderEmoji);
                                        if (textView != null) {
                                            i2 = R.id.txtHeaderName;
                                            TextView textView2 = (TextView) dc.p(viewInflate, R.id.txtHeaderName);
                                            if (textView2 != null) {
                                                i2 = R.id.txtLearnedOf;
                                                TextView textView3 = (TextView) dc.p(viewInflate, R.id.txtLearnedOf);
                                                if (textView3 != null) {
                                                    i2 = R.id.txtProgressPercent;
                                                    TextView textView4 = (TextView) dc.p(viewInflate, R.id.txtProgressPercent);
                                                    if (textView4 != null) {
                                                        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) viewInflate;
                                                        this.B = new i0(coordinatorLayout, button, button2, floatingActionButton, viewP, deckProgressView, recyclerView, materialToolbar, textView, textView2, textView3, textView4);
                                                        setContentView(coordinatorLayout);
                                                        this.C = new rd(this);
                                                        this.D = getIntent().getIntExtra(qd.a, -1);
                                                        i0 i0Var = this.B;
                                                        if (i0Var == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        y(i0Var.c);
                                                        b0 b0VarX = x();
                                                        final int i3 = 1;
                                                        if (b0VarX != null) {
                                                            b0VarX.m(true);
                                                        }
                                                        i0 i0Var2 = this.B;
                                                        if (i0Var2 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        i0Var2.c.setNavigationOnClickListener(new View.OnClickListener(this) { // from class: z9
                                                            public final /* synthetic */ DeckDetailActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i4 = i;
                                                                DeckDetailActivity deckDetailActivity = this.b;
                                                                switch (i4) {
                                                                    case 0:
                                                                        int i5 = DeckDetailActivity.E;
                                                                        deckDetailActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i6 = DeckDetailActivity.E;
                                                                        Intent intent = new Intent(deckDetailActivity, (Class<?>) StudyActivity.class);
                                                                        intent.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent);
                                                                        break;
                                                                    case 2:
                                                                        int i7 = DeckDetailActivity.E;
                                                                        Intent intent2 = new Intent(deckDetailActivity, (Class<?>) QuizActivity.class);
                                                                        intent2.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent2);
                                                                        break;
                                                                    default:
                                                                        int i8 = DeckDetailActivity.E;
                                                                        Intent intent3 = new Intent(deckDetailActivity, (Class<?>) CreateCardActivity.class);
                                                                        intent3.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent3);
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        i0 i0Var3 = this.B;
                                                        if (i0Var3 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        ((RecyclerView) i0Var3.i).setLayoutManager(new LinearLayoutManager(1));
                                                        i0 i0Var4 = this.B;
                                                        if (i0Var4 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        i0Var4.b.setOnClickListener(new View.OnClickListener(this) { // from class: z9
                                                            public final /* synthetic */ DeckDetailActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i4 = i3;
                                                                DeckDetailActivity deckDetailActivity = this.b;
                                                                switch (i4) {
                                                                    case 0:
                                                                        int i5 = DeckDetailActivity.E;
                                                                        deckDetailActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i6 = DeckDetailActivity.E;
                                                                        Intent intent = new Intent(deckDetailActivity, (Class<?>) StudyActivity.class);
                                                                        intent.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent);
                                                                        break;
                                                                    case 2:
                                                                        int i7 = DeckDetailActivity.E;
                                                                        Intent intent2 = new Intent(deckDetailActivity, (Class<?>) QuizActivity.class);
                                                                        intent2.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent2);
                                                                        break;
                                                                    default:
                                                                        int i8 = DeckDetailActivity.E;
                                                                        Intent intent3 = new Intent(deckDetailActivity, (Class<?>) CreateCardActivity.class);
                                                                        intent3.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent3);
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        i0 i0Var5 = this.B;
                                                        if (i0Var5 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        final int i4 = 2;
                                                        i0Var5.a.setOnClickListener(new View.OnClickListener(this) { // from class: z9
                                                            public final /* synthetic */ DeckDetailActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i42 = i4;
                                                                DeckDetailActivity deckDetailActivity = this.b;
                                                                switch (i42) {
                                                                    case 0:
                                                                        int i5 = DeckDetailActivity.E;
                                                                        deckDetailActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i6 = DeckDetailActivity.E;
                                                                        Intent intent = new Intent(deckDetailActivity, (Class<?>) StudyActivity.class);
                                                                        intent.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent);
                                                                        break;
                                                                    case 2:
                                                                        int i7 = DeckDetailActivity.E;
                                                                        Intent intent2 = new Intent(deckDetailActivity, (Class<?>) QuizActivity.class);
                                                                        intent2.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent2);
                                                                        break;
                                                                    default:
                                                                        int i8 = DeckDetailActivity.E;
                                                                        Intent intent3 = new Intent(deckDetailActivity, (Class<?>) CreateCardActivity.class);
                                                                        intent3.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent3);
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        i0 i0Var6 = this.B;
                                                        if (i0Var6 == null) {
                                                            ii.d("binding");
                                                            throw null;
                                                        }
                                                        final int i5 = 3;
                                                        ((FloatingActionButton) i0Var6.f).setOnClickListener(new View.OnClickListener(this) { // from class: z9
                                                            public final /* synthetic */ DeckDetailActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i42 = i5;
                                                                DeckDetailActivity deckDetailActivity = this.b;
                                                                switch (i42) {
                                                                    case 0:
                                                                        int i52 = DeckDetailActivity.E;
                                                                        deckDetailActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i6 = DeckDetailActivity.E;
                                                                        Intent intent = new Intent(deckDetailActivity, (Class<?>) StudyActivity.class);
                                                                        intent.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent);
                                                                        break;
                                                                    case 2:
                                                                        int i7 = DeckDetailActivity.E;
                                                                        Intent intent2 = new Intent(deckDetailActivity, (Class<?>) QuizActivity.class);
                                                                        intent2.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent2);
                                                                        break;
                                                                    default:
                                                                        int i8 = DeckDetailActivity.E;
                                                                        Intent intent3 = new Intent(deckDetailActivity, (Class<?>) CreateCardActivity.class);
                                                                        intent3.putExtra(qd.a, deckDetailActivity.D);
                                                                        deckDetailActivity.startActivity(intent3);
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        md.w("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.oe, android.app.Activity
    public final void onResume() {
        Object obj;
        int i;
        super.onResume();
        int i2 = this.D;
        rd rdVar = this.C;
        if (rdVar == null) {
            ii.d("prefs");
            throw null;
        }
        ArrayList arrayListB = ea.b(rdVar);
        int size = arrayListB.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                obj = null;
                break;
            }
            obj = arrayListB.get(i3);
            i3++;
            if (((w9) obj).a == i2) {
                break;
            }
        }
        w9 w9Var = (w9) obj;
        if (w9Var == null) {
            finish();
            return;
        }
        ArrayList arrayList = w9Var.g;
        boolean z = w9Var.f;
        String str = w9Var.b;
        b0 b0VarX = x();
        if (b0VarX != null) {
            b0VarX.o(str);
        }
        i0 i0Var = this.B;
        if (i0Var == null) {
            ii.d("binding");
            throw null;
        }
        i0Var.g.setBackgroundColor(Color.parseColor(w9Var.d.a));
        i0 i0Var2 = this.B;
        if (i0Var2 == null) {
            ii.d("binding");
            throw null;
        }
        i0Var2.d.setText(w9Var.c);
        i0 i0Var3 = this.B;
        if (i0Var3 == null) {
            ii.d("binding");
            throw null;
        }
        i0Var3.e.setText(str);
        rd rdVar2 = this.C;
        if (rdVar2 == null) {
            ii.d("prefs");
            throw null;
        }
        int iJ = rdVar2.j(arrayList);
        rd rdVar3 = this.C;
        if (rdVar3 == null) {
            ii.d("prefs");
            throw null;
        }
        if (arrayList.isEmpty()) {
            i = 0;
        } else {
            int size2 = arrayList.size();
            i = 0;
            int i4 = 0;
            while (i4 < size2) {
                Object obj2 = arrayList.get(i4);
                i4++;
                if (rdVar3.e(((pd) obj2).a) >= 4 && (i = i + 1) < 0) {
                    throw new ArithmeticException("Count overflow has happened.");
                }
            }
        }
        i0 i0Var4 = this.B;
        if (i0Var4 == null) {
            ii.d("binding");
            throw null;
        }
        ((TextView) i0Var4.k).setText(getString(R.string.percent_format, Integer.valueOf(iJ)));
        i0 i0Var5 = this.B;
        if (i0Var5 == null) {
            ii.d("binding");
            throw null;
        }
        ((TextView) i0Var5.j).setText(getString(R.string.learned_of_format, Integer.valueOf(i), Integer.valueOf(arrayList.size())));
        i0 i0Var6 = this.B;
        if (i0Var6 == null) {
            ii.d("binding");
            throw null;
        }
        DeckProgressView deckProgressView = (DeckProgressView) i0Var6.h;
        float f = iJ / 100.0f;
        rd rdVar4 = this.C;
        if (rdVar4 == null) {
            ii.d("prefs");
            throw null;
        }
        deckProgressView.a(f, rdVar4.a() ? 800L : 0L);
        i0 i0Var7 = this.B;
        if (i0Var7 == null) {
            ii.d("binding");
            throw null;
        }
        ((FloatingActionButton) i0Var7.f).setVisibility(z ? 8 : 0);
        i0 i0Var8 = this.B;
        if (i0Var8 == null) {
            ii.d("binding");
            throw null;
        }
        RecyclerView recyclerView = (RecyclerView) i0Var8.i;
        rd rdVar5 = this.C;
        if (rdVar5 == null) {
            ii.d("prefs");
            throw null;
        }
        boolean zA = rdVar5.a();
        rd rdVar6 = this.C;
        if (rdVar6 != null) {
            recyclerView.setAdapter(new b6(arrayList, rdVar5, zA, rdVar6.a.getBoolean("show_level", true), !z, new g(1, this)));
        } else {
            ii.d("prefs");
            throw null;
        }
    }
}
