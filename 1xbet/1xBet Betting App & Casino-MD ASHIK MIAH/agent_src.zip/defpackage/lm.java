package defpackage;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class lm {
    public static final nt a = new nt(new w0(3));
}
