package defpackage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.widget.LinearLayout;
import androidx.activity.ComponentActivity;
import androidx.activity.b;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity2;
import com.google.android.material.button.MaterialButton;
import defpackage.j2;
import defpackage.p9;
import defpackage.up;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final /* synthetic */ class k2 implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Object c;

    public /* synthetic */ k2(Object obj, Object obj2, int i) {
        this.a = i;
        this.b = obj;
        this.c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = this.a;
        Object obj = this.c;
        Object obj2 = this.b;
        switch (i) {
            case 0:
                j2.b bVar = (j2.b) obj2;
                try {
                    ((Runnable) obj).run();
                    return;
                } finally {
                    bVar.a();
                }
            case 1:
                ComponentActivity componentActivity = (ComponentActivity) obj2;
                int i2 = ComponentActivity.t;
                componentActivity.a.a(new v7((b) obj, componentActivity));
                return;
            case 2:
                p9 p9Var = (p9) obj2;
                MainActivity mainActivity = (MainActivity) obj;
                if (!(p9Var instanceof p9.b)) {
                    if (!(p9Var instanceof p9.a)) {
                        throw new nm();
                    }
                    int i3 = MainActivity.E;
                    mainActivity.startActivity(new Intent(mainActivity, (Class<?>) MainActivity2.class));
                    return;
                }
                int i4 = MainActivity.E;
                SharedPreferences.Editor editorEdit = ((SharedPreferences) mainActivity.D.a()).edit();
                String str = ((p9.b) p9Var).a;
                editorEdit.putString("open_url", str).apply();
                mainActivity.C = str;
                mainActivity.z(str);
                return;
            case 3:
                MaterialButton materialButton = (MaterialButton) obj2;
                int[] iArr = MaterialButton.O;
                ((Runnable) obj).run();
                LinearLayout.LayoutParams layoutParams = materialButton.D;
                if (layoutParams != null) {
                    materialButton.setLayoutParams(layoutParams);
                    materialButton.D = null;
                    materialButton.A = -2.1474836E9f;
                }
                materialButton.requestLayout();
                return;
            default:
                ((up.c) obj2).c((Typeface) obj);
                return;
        }
    }
}
