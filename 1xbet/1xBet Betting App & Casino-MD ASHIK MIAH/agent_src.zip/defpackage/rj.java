package defpackage;

import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity;
import defpackage.p9;
import java.io.IOException;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final class rj {
    public final /* synthetic */ MainActivity a;

    public rj(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    public final void a(s5 s5Var, IOException iOException) {
        MainActivity mainActivity = this.a;
        mainActivity.runOnUiThread(new qj(mainActivity, 1));
    }

    public final void b(s5 s5Var, xp xpVar) {
        String strL;
        int i = xpVar.d;
        Object bVar = (300 > i || i >= 400 || (strL = xp.l(xpVar, "Location")) == null || ws.W(strL)) ? p9.a.a : new p9.b(strL);
        MainActivity mainActivity = this.a;
        mainActivity.runOnUiThread(new k2(bVar, mainActivity, 2));
    }
}
