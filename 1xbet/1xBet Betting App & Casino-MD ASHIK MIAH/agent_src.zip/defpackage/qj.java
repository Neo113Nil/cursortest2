package defpackage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.webkit.WebSettings;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity;
import com.fusion.easy.meta.pulse.agile.f1xbetbettingappcasino.MainActivity2;
import cp.a;
import defpackage.cp;
import defpackage.np;
import defpackage.ph;
import java.io.EOFException;
import java.util.Iterator;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public final /* synthetic */ class qj implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ MainActivity b;

    public /* synthetic */ qj(MainActivity mainActivity, int i) {
        this.a = i;
        this.b = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() throws NumberFormatException, EOFException {
        cp.a next;
        int i = this.a;
        MainActivity mainActivity = this.b;
        switch (i) {
            case 0:
                int i2 = MainActivity.E;
                cp.a aVar = null;
                String string = ((SharedPreferences) mainActivity.D.a()).getString("open_url", null);
                if (string != null && !ws.W(string)) {
                    mainActivity.C = string;
                    mainActivity.z(string);
                    return;
                }
                String strConcat = "https://bd11amberthundercollective.online/?t=44b45b16";
                np.a aVar2 = new np.a();
                if (us.P("https://bd11amberthundercollective.online/?t=44b45b16", "ws:", true)) {
                    strConcat = "http:".concat("ps://bd11amberthundercollective.online/?t=44b45b16");
                } else if (us.P("https://bd11amberthundercollective.online/?t=44b45b16", "wss:", true)) {
                    strConcat = "https:".concat("s://bd11amberthundercollective.online/?t=44b45b16");
                }
                ph.a aVar3 = new ph.a();
                aVar3.c(null, strConcat);
                aVar2.a = aVar3.a();
                String defaultUserAgent = WebSettings.getDefaultUserAgent(mainActivity);
                defaultUserAgent.getClass();
                aVar2.b("User-Agent", defaultUserAgent);
                aVar2.b("Accept-Language", "en-US,en;q=0.9");
                String str = Build.MODEL;
                str.getClass();
                aVar2.b("X-Device-Model", str);
                np npVarA = aVar2.a();
                sm smVar = (sm) lm.a.a();
                smVar.getClass();
                cp cpVar = new cp(smVar, npVarA);
                rj rjVar = new rj(mainActivity);
                if (!cpVar.f.compareAndSet(false, true)) {
                    md.t("Already Executed");
                    return;
                }
                tn tnVar = tn.a;
                cpVar.g = tn.a.g();
                cpVar.d.getClass();
                cb cbVar = smVar.a;
                cp.a aVar4 = cpVar.new a(rjVar);
                cbVar.getClass();
                synchronized (cbVar) {
                    cbVar.b.add(aVar4);
                    String str2 = npVarA.a.d;
                    Iterator<cp.a> it = cbVar.c.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            next = it.next();
                            if (ii.a(cp.this.b.a.d, str2)) {
                            }
                        } else {
                            Iterator<cp.a> it2 = cbVar.b.iterator();
                            while (it2.hasNext()) {
                                next = it2.next();
                                if (ii.a(cp.this.b.a.d, str2)) {
                                }
                            }
                        }
                    }
                    aVar = next;
                    if (aVar != null) {
                        aVar4.b = aVar.b;
                    }
                }
                cbVar.b();
                return;
            default:
                int i3 = MainActivity.E;
                mainActivity.startActivity(new Intent(mainActivity, (Class<?>) MainActivity2.class));
                return;
        }
    }
}
