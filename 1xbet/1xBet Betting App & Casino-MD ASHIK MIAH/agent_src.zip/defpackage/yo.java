package defpackage;

import defpackage.oi;
import java.io.Serializable;

/* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
/* loaded from: classes.dex */
public abstract class yo {
    public static final a a = new a();
    public static final k b;

    /* compiled from: r8-map-id-78e7b8f7f8a243adf136e61feda72e33279b451b163c20567f6ee50fa5632519 */
    public static final class a extends yo implements Serializable {
        @Override // defpackage.yo
        public final long a() {
            return yo.b.a();
        }

        @Override // defpackage.yo
        public final long b() {
            throw null;
        }
    }

    static {
        vn.a.getClass();
        Integer num = oi.a.a;
        b = (num == null || num.intValue() >= 34) ? new wn() : new jd();
    }

    public abstract long a();

    public long b() {
        long jA;
        long j;
        do {
            jA = a() >>> 1;
            j = jA % 1650;
        } while ((jA - j) + 1649 < 0);
        return 985 + j;
    }
}
