package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: MainActivity2.kt */
@kotlin.Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001&B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010 \u001a\u00020\u00142\u0006\u0010!\u001a\u00020\"H\u0014J\u0010\u0010#\u001a\u00020\r2\u0006\u0010$\u001a\u00020%H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u00020\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\u000e\"\u0004\b\u000f\u0010\u0010R(\u0010\u0011\u001a\u0010\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0012X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R(\u0010\u0019\u001a\u0010\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0012X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0016\"\u0004\b\u001b\u0010\u0018R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006'"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/GameEngineView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "blockH", "", "blockPaint", "Landroid/graphics/Paint;", "currVx", "currW", "currX", "isRunning", "", "()Z", "setRunning", "(Z)V", "onGameOver", "Lkotlin/Function1;", "", "", "getOnGameOver", "()Lkotlin/jvm/functions/Function1;", "setOnGameOver", "(Lkotlin/jvm/functions/Function1;)V", "onScoreAdded", "getOnScoreAdded", "setOnScoreAdded", "stack", "", "Lcom/stellar/studio/spark6x3x/lottomatica/GameEngineView$Block;", "stackPaint", "onDraw", "canvas", "Landroid/graphics/Canvas;", "onTouchEvent", androidx.core.app.NotificationCompat.CATEGORY_EVENT, "Landroid/view/MotionEvent;", "Block", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class GameEngineView extends android.view.View {
    private final float blockH;
    private final android.graphics.Paint blockPaint;
    private float currVx;
    private float currW;
    private float currX;
    private boolean isRunning;
    private kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onGameOver;
    private kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onScoreAdded;
    private final java.util.List<com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block> stack;
    private final android.graphics.Paint stackPaint;

    /* compiled from: MainActivity2.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\f\b\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006R\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\b\"\u0004\b\f\u0010\nR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\b\"\u0004\b\u000e\u0010\n¨\u0006\u000f"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/GameEngineView$Block;", "", "x", "", "y", "w", "(FFF)V", "getW", "()F", "setW", "(F)V", "getX", "setX", "getY", "setY", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class Block {
        private float w;
        private float x;
        private float y;

        public Block(float f, float f2, float f3) {
            this.x = f;
            this.y = f2;
            this.w = f3;
        }

        public final float getW() {
            return this.w;
        }

        public final float getX() {
            return this.x;
        }

        public final float getY() {
            return this.y;
        }

        public final void setW(float f) {
            this.w = f;
        }

        public final void setX(float f) {
            this.x = f;
        }

        public final void setY(float f) {
            this.y = f;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GameEngineView(android.content.Context context) {
        super(context);
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        this.isRunning = true;
        android.graphics.Paint paint = new android.graphics.Paint(1);
        paint.setColor(android.graphics.Color.parseColor("#00F5D4"));
        this.blockPaint = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setColor(android.graphics.Color.parseColor("#00F5D4"));
        this.stackPaint = paint2;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        this.stack = arrayList;
        this.currX = 200.0f;
        this.currW = 340.0f;
        this.currVx = 12.0f;
        this.blockH = 50.0f;
        arrayList.add(new com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block(370.0f, 1300.0f, 340.0f));
    }

    public final kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> getOnGameOver() {
        return this.onGameOver;
    }

    public final kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> getOnScoreAdded() {
        return this.onScoreAdded;
    }

    /* renamed from: isRunning, reason: from getter */
    public final boolean getIsRunning() {
        return this.isRunning;
    }

    @Override // android.view.View
    protected void onDraw(android.graphics.Canvas canvas) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(canvas, "canvas");
        super.onDraw(canvas);
        if (this.isRunning) {
            float y = (((com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block) kotlin.collections.CollectionsKt.last((java.util.List) this.stack)).getY() - this.blockH) - 8.0f;
            float f = this.currX + this.currVx;
            this.currX = f;
            if (f < 30.0f || f + this.currW > getWidth() - 30.0f) {
                this.currVx = -this.currVx;
            }
            float f2 = this.currX;
            canvas.drawRoundRect(f2, y, f2 + this.currW, y + this.blockH, 12.0f, 12.0f, this.blockPaint);
            for (com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block block : this.stack) {
                canvas.drawRoundRect(block.getX(), block.getY(), block.getW() + block.getX(), block.getY() + this.blockH, 12.0f, 12.0f, this.stackPaint);
            }
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(android.view.MotionEvent event) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(event, "event");
        if (event.getAction() == 0) {
            com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block block = (com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block) kotlin.collections.CollectionsKt.last((java.util.List) this.stack);
            float fMax = java.lang.Math.max(this.currX, block.getX());
            float fMin = java.lang.Math.min(this.currX + this.currW, block.getX() + block.getW()) - fMax;
            if (fMin > 15.0f) {
                this.currW = fMin;
                this.currX = fMax;
                this.stack.add(new com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block(this.currX, (block.getY() - this.blockH) - 8.0f, this.currW));
                kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1 = this.onScoreAdded;
                if (function1 != null) {
                    function1.invoke(java.lang.Integer.valueOf(androidx.recyclerview.widget.ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION));
                }
                performHapticFeedback(1);
                if (this.stack.size() > 12) {
                    for (com.stellar.studio.spark6x3x.lottomatica.GameEngineView.Block block2 : this.stack) {
                        block2.setY(block2.getY() + this.blockH + 8.0f);
                    }
                }
            } else {
                kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function12 = this.onGameOver;
                if (function12 != null) {
                    function12.invoke(0);
                }
            }
        }
        return true;
    }

    public final void setOnGameOver(kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1) {
        this.onGameOver = function1;
    }

    public final void setOnScoreAdded(kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1) {
        this.onScoreAdded = function1;
    }

    public final void setRunning(boolean z) {
        this.isRunning = z;
    }
}
