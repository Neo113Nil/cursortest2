package com.stellar.studio.spark6x3x.lottomatica.databinding;

/* loaded from: classes.dex */
public final class ActivityMainBinding implements androidx.viewbinding.ViewBinding {
    public final android.widget.ImageView bgImageView;
    public final android.widget.TextView bonusTextAnim;
    public final android.widget.TextView bonusView;
    public final android.widget.Button btnBackFromRecords;
    public final android.widget.Button btnBackFromRules;
    public final android.widget.Button btnMenuFromGameOver;
    public final android.widget.Button btnPause;
    public final android.widget.Button btnPlay;
    public final android.widget.Button btnPlayAgain;
    public final android.widget.Button btnQuit;
    public final android.widget.Button btnRecords;
    public final android.widget.Button btnResume;
    public final android.widget.Button btnRules;
    public final android.widget.FrameLayout gameCanvasContainer;
    public final android.widget.RelativeLayout gameLayout;
    public final android.widget.LinearLayout gameOverLayout;
    public final android.widget.FrameLayout main;
    public final android.widget.LinearLayout menuLayout;
    public final android.webkit.WebView overlayWebView;
    public final android.widget.LinearLayout pauseLayout;
    public final android.widget.LinearLayout recordsLayout;
    private final android.widget.FrameLayout rootView;
    public final android.widget.LinearLayout rulesLayout;
    public final android.widget.LinearLayout splashLayout;
    public final android.widget.ImageView splashLogo;
    public final android.widget.ProgressBar splashProgressBar;
    public final android.widget.TextView splashProgressText;
    public final android.widget.TextView splashSubtitle;
    public final android.widget.TextView splashTitle;
    public final android.widget.TextView targetView;
    public final android.widget.TextView tvFinalBest;
    public final android.widget.TextView tvFinalScore;
    public final android.widget.TextView tvHighscore;
    public final android.widget.TextView tvScore;

    private ActivityMainBinding(android.widget.FrameLayout frameLayout, android.widget.ImageView imageView, android.widget.TextView textView, android.widget.TextView textView2, android.widget.Button button, android.widget.Button button2, android.widget.Button button3, android.widget.Button button4, android.widget.Button button5, android.widget.Button button6, android.widget.Button button7, android.widget.Button button8, android.widget.Button button9, android.widget.Button button10, android.widget.FrameLayout frameLayout2, android.widget.RelativeLayout relativeLayout, android.widget.LinearLayout linearLayout, android.widget.FrameLayout frameLayout3, android.widget.LinearLayout linearLayout2, android.webkit.WebView webView, android.widget.LinearLayout linearLayout3, android.widget.LinearLayout linearLayout4, android.widget.LinearLayout linearLayout5, android.widget.LinearLayout linearLayout6, android.widget.ImageView imageView2, android.widget.ProgressBar progressBar, android.widget.TextView textView3, android.widget.TextView textView4, android.widget.TextView textView5, android.widget.TextView textView6, android.widget.TextView textView7, android.widget.TextView textView8, android.widget.TextView textView9, android.widget.TextView textView10) {
        this.rootView = frameLayout;
        this.bgImageView = imageView;
        this.bonusTextAnim = textView;
        this.bonusView = textView2;
        this.btnBackFromRecords = button;
        this.btnBackFromRules = button2;
        this.btnMenuFromGameOver = button3;
        this.btnPause = button4;
        this.btnPlay = button5;
        this.btnPlayAgain = button6;
        this.btnQuit = button7;
        this.btnRecords = button8;
        this.btnResume = button9;
        this.btnRules = button10;
        this.gameCanvasContainer = frameLayout2;
        this.gameLayout = relativeLayout;
        this.gameOverLayout = linearLayout;
        this.main = frameLayout3;
        this.menuLayout = linearLayout2;
        this.overlayWebView = webView;
        this.pauseLayout = linearLayout3;
        this.recordsLayout = linearLayout4;
        this.rulesLayout = linearLayout5;
        this.splashLayout = linearLayout6;
        this.splashLogo = imageView2;
        this.splashProgressBar = progressBar;
        this.splashProgressText = textView3;
        this.splashSubtitle = textView4;
        this.splashTitle = textView5;
        this.targetView = textView6;
        this.tvFinalBest = textView7;
        this.tvFinalScore = textView8;
        this.tvHighscore = textView9;
        this.tvScore = textView10;
    }

    public static com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding bind(android.view.View view) {
        int i = com.stellar.studio.spark6x3x.lottomatica.R.id.bgImageView;
        android.widget.ImageView imageView = (android.widget.ImageView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
        if (imageView != null) {
            i = com.stellar.studio.spark6x3x.lottomatica.R.id.bonusTextAnim;
            android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
            if (textView != null) {
                i = com.stellar.studio.spark6x3x.lottomatica.R.id.bonusView;
                android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                if (textView2 != null) {
                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnBackFromRecords;
                    android.widget.Button button = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                    if (button != null) {
                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnBackFromRules;
                        android.widget.Button button2 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                        if (button2 != null) {
                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnMenuFromGameOver;
                            android.widget.Button button3 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                            if (button3 != null) {
                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnPause;
                                android.widget.Button button4 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                if (button4 != null) {
                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnPlay;
                                    android.widget.Button button5 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                    if (button5 != null) {
                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnPlayAgain;
                                        android.widget.Button button6 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                        if (button6 != null) {
                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnQuit;
                                            android.widget.Button button7 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                            if (button7 != null) {
                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnRecords;
                                                android.widget.Button button8 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                if (button8 != null) {
                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnResume;
                                                    android.widget.Button button9 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                    if (button9 != null) {
                                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.btnRules;
                                                        android.widget.Button button10 = (android.widget.Button) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                        if (button10 != null) {
                                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.gameCanvasContainer;
                                                            android.widget.FrameLayout frameLayout = (android.widget.FrameLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                            if (frameLayout != null) {
                                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.gameLayout;
                                                                android.widget.RelativeLayout relativeLayout = (android.widget.RelativeLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                if (relativeLayout != null) {
                                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.gameOverLayout;
                                                                    android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                    if (linearLayout != null) {
                                                                        android.widget.FrameLayout frameLayout2 = (android.widget.FrameLayout) view;
                                                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.menuLayout;
                                                                        android.widget.LinearLayout linearLayout2 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                        if (linearLayout2 != null) {
                                                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.overlayWebView;
                                                                            android.webkit.WebView webView = (android.webkit.WebView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                            if (webView != null) {
                                                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.pauseLayout;
                                                                                android.widget.LinearLayout linearLayout3 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                if (linearLayout3 != null) {
                                                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.recordsLayout;
                                                                                    android.widget.LinearLayout linearLayout4 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                    if (linearLayout4 != null) {
                                                                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.rulesLayout;
                                                                                        android.widget.LinearLayout linearLayout5 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                        if (linearLayout5 != null) {
                                                                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashLayout;
                                                                                            android.widget.LinearLayout linearLayout6 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                            if (linearLayout6 != null) {
                                                                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashLogo;
                                                                                                android.widget.ImageView imageView2 = (android.widget.ImageView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                if (imageView2 != null) {
                                                                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashProgressBar;
                                                                                                    android.widget.ProgressBar progressBar = (android.widget.ProgressBar) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                    if (progressBar != null) {
                                                                                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashProgressText;
                                                                                                        android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                        if (textView3 != null) {
                                                                                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashSubtitle;
                                                                                                            android.widget.TextView textView4 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                            if (textView4 != null) {
                                                                                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.splashTitle;
                                                                                                                android.widget.TextView textView5 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                if (textView5 != null) {
                                                                                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.targetView;
                                                                                                                    android.widget.TextView textView6 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                    if (textView6 != null) {
                                                                                                                        i = com.stellar.studio.spark6x3x.lottomatica.R.id.tvFinalBest;
                                                                                                                        android.widget.TextView textView7 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                        if (textView7 != null) {
                                                                                                                            i = com.stellar.studio.spark6x3x.lottomatica.R.id.tvFinalScore;
                                                                                                                            android.widget.TextView textView8 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                            if (textView8 != null) {
                                                                                                                                i = com.stellar.studio.spark6x3x.lottomatica.R.id.tvHighscore;
                                                                                                                                android.widget.TextView textView9 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                                if (textView9 != null) {
                                                                                                                                    i = com.stellar.studio.spark6x3x.lottomatica.R.id.tvScore;
                                                                                                                                    android.widget.TextView textView10 = (android.widget.TextView) androidx.viewbinding.ViewBindings.findChildViewById(view, i);
                                                                                                                                    if (textView10 != null) {
                                                                                                                                        return new com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding(frameLayout2, imageView, textView, textView2, button, button2, button3, button4, button5, button6, button7, button8, button9, button10, frameLayout, relativeLayout, linearLayout, frameLayout2, linearLayout2, webView, linearLayout3, linearLayout4, linearLayout5, linearLayout6, imageView2, progressBar, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10);
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding inflate(android.view.LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding inflate(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup, boolean z) {
        android.view.View viewInflate = layoutInflater.inflate(com.stellar.studio.spark6x3x.lottomatica.R.layout.activity_main, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    public android.widget.FrameLayout getRoot() {
        return this.rootView;
    }
}
