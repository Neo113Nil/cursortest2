package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: WebNav.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001:\u0004\u0011\u0012\u0013\u0014B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0002J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0002J\u0010\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u0004H\u0002J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u0004H\u0002J\u0016\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0004¨\u0006\u0015"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav;", "", "()V", "buildSplitString", "", "calculateTask", "", "input", "hashIcon", "data", "isExportValid", "", "value", "open", "ctx", "Landroid/content/Context;", "url", "GeneratorListener", "UseCaseState", "UtilState", "ZoomEvent", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class WebNav {
    public static final com.stellar.studio.spark6x3x.lottomatica.WebNav INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.WebNav();

    /* compiled from: WebNav.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bb\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$GeneratorListener;", "", "onChanged", "", "value", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private interface GeneratorListener {
        void onChanged(java.lang.String value);
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: WebNav.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$UseCaseState;", "", "(Ljava/lang/String;I)V", "INIT", "READY", kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt.RUNNING, "STOPPED", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class UseCaseState {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState INIT = new com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState("INIT", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState READY = new com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState("READY", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState RUNNING = new com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState(kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt.RUNNING, 2);
        public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState STOPPED = new com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState("STOPPED", 3);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[]{INIT, READY, RUNNING, STOPPED};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[] useCaseStateArr$values = $values();
            $VALUES = useCaseStateArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(useCaseStateArr$values);
        }

        private UseCaseState(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.WebNav.UseCaseState[]) $VALUES.clone();
        }
    }

    /* compiled from: WebNav.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\r\u001a\u00020\u00032\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$UtilState;", "", "isReady", "", "timestamp", "", "(ZJ)V", "()Z", "getTimestamp", "()J", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class UtilState {
        private final boolean isReady;
        private final long timestamp;

        public UtilState() {
            this(false, 0L, 3, null);
        }

        public UtilState(boolean z, long j) {
            this.isReady = z;
            this.timestamp = j;
        }

        public /* synthetic */ UtilState(boolean z, long j, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState copy$default(com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState utilState, boolean z, long j, int i, java.lang.Object obj) {
            if ((i & 1) != 0) {
                z = utilState.isReady;
            }
            if ((i & 2) != 0) {
                j = utilState.timestamp;
            }
            return utilState.copy(z, j);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getIsReady() {
            return this.isReady;
        }

        /* renamed from: component2, reason: from getter */
        public final long getTimestamp() {
            return this.timestamp;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState copy(boolean isReady, long timestamp) {
            return new com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState(isReady, timestamp);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState utilState = (com.stellar.studio.spark6x3x.lottomatica.WebNav.UtilState) other;
            return this.isReady == utilState.isReady && this.timestamp == utilState.timestamp;
        }

        public final long getTimestamp() {
            return this.timestamp;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.isReady;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Long.hashCode(this.timestamp);
        }

        public final boolean isReady() {
            return this.isReady;
        }

        public java.lang.String toString() {
            return "UtilState(isReady=" + this.isReady + ", timestamp=" + this.timestamp + ')';
        }
    }

    /* compiled from: WebNav.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent;", "", "()V", "Completed", "Failed", "Started", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Started;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class ZoomEvent {

        /* compiled from: WebNav.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Completed extends com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Completed INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Completed();

            private Completed() {
                super(null);
            }
        }

        /* compiled from: WebNav.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent;", "reason", "", "(Ljava/lang/String;)V", "getReason", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Failed extends com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent {
            private final java.lang.String reason;

            /* JADX WARN: Multi-variable type inference failed */
            public Failed() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Failed(java.lang.String reason) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                this.reason = reason;
            }

            public /* synthetic */ Failed(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed copy$default(com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed failed, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = failed.reason;
                }
                return failed.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getReason() {
                return this.reason;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed copy(java.lang.String reason) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                return new com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed(reason);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed) && kotlin.jvm.internal.Intrinsics.areEqual(this.reason, ((com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Failed) other).reason);
            }

            public final java.lang.String getReason() {
                return this.reason;
            }

            public int hashCode() {
                return this.reason.hashCode();
            }

            public java.lang.String toString() {
                return "Failed(reason=" + this.reason + ')';
            }
        }

        /* compiled from: WebNav.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent$Started;", "Lcom/stellar/studio/spark6x3x/lottomatica/WebNav$ZoomEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Started extends com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Started INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.WebNav.ZoomEvent.Started();

            private Started() {
                super(null);
            }
        }

        private ZoomEvent() {
        }

        public /* synthetic */ ZoomEvent(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    private WebNav() {
    }

    private final java.lang.String buildSplitString() {
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue("Split", "toString(...)");
        return "Split";
    }

    private final int calculateTask(int input) {
        for (int i = 0; i < 11; i++) {
            input += i - i;
        }
        return input;
    }

    private final int hashIcon(java.lang.String data) {
        return data.hashCode();
    }

    private final boolean isExportValid(java.lang.String value) {
        return value.length() >= 0;
    }

    public final boolean open(android.content.Context ctx, java.lang.String url) {
        java.lang.Object objM155constructorimpl;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(ctx, "ctx");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
        try {
            kotlin.Result.Companion companion = kotlin.Result.INSTANCE;
            com.stellar.studio.spark6x3x.lottomatica.WebNav webNav = this;
            android.content.Intent intent = new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(url));
            intent.addFlags(268435456);
            ctx.startActivity(intent);
            objM155constructorimpl = kotlin.Result.m155constructorimpl(true);
        } catch (java.lang.Throwable th) {
            kotlin.Result.Companion companion2 = kotlin.Result.INSTANCE;
            objM155constructorimpl = kotlin.Result.m155constructorimpl(kotlin.ResultKt.createFailure(th));
        }
        if (kotlin.Result.m158exceptionOrNullimpl(objM155constructorimpl) != null) {
            objM155constructorimpl = false;
        }
        return ((java.lang.Boolean) objM155constructorimpl).booleanValue();
    }
}
