package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: MainActivity.kt */
@kotlin.Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\u0018\u00002\u00020\u00012\u00020\u0002:\u0007/012345B\u0005¢\u0006\u0002\u0010\u0003J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0013H\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u0016\u0010\u0017\u001a\u00020\u00162\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00160\u0019H\u0002J\b\u0010\u001a\u001a\u00020\u0016H\u0002J\u0018\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001e\u001a\u00020\u001cH\u0002J\b\u0010\u001f\u001a\u00020\u001cH\u0002J\u0012\u0010 \u001a\u00020!2\b\u0010\u0014\u001a\u0004\u0018\u00010\"H\u0002J\u0012\u0010#\u001a\u00020\u00162\b\u0010$\u001a\u0004\u0018\u00010%H\u0014J\b\u0010&\u001a\u00020\u0016H\u0016J\b\u0010'\u001a\u00020\u0016H\u0014J\b\u0010(\u001a\u00020\u0016H\u0014J\u0010\u0010)\u001a\u00020\u00162\u0006\u0010*\u001a\u00020\u0013H\u0016J\u0010\u0010+\u001a\u00020\u00162\u0006\u0010*\u001a\u00020\u0013H\u0002J\u0010\u0010,\u001a\u00020\u001c2\u0006\u0010-\u001a\u00020\u0013H\u0002J\b\u0010.\u001a\u00020\u0016H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R#\u0010\n\u001a\n \f*\u0004\u0018\u00010\u000b0\u000b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\t\u001a\u0004\b\r\u0010\u000eR\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00066"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$Listener;", "()V", "binding", "Lcom/stellar/studio/spark6x3x/lottomatica/databinding/ActivityMainBinding;", "getBinding", "()Lcom/stellar/studio/spark6x3x/lottomatica/databinding/ActivityMainBinding;", "binding$delegate", "Lkotlin/Lazy;", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "getPrefs", "()Landroid/content/SharedPreferences;", "prefs$delegate", "progressAnimator", "Landroid/animation/ValueAnimator;", "convertService", "", "value", "fetchAndLoad", "", "finishProgressAndAction", "action", "Lkotlin/Function0;", "loadFallbackGame", "maxArrange", "", "a", "b", "monitorCollection", "notNullSwap", "", "", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onFallback", "onResume", "onStart", "onUrl", "url", "openExternal", "parseSend", "data", "startProgressAnimation", "ErrorResult", "InitState", "InputResult", "MoveMode", "SidebarConfig", "TileType", "ValidatorInfo", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MainActivity extends androidx.appcompat.app.AppCompatActivity implements com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener {

    /* renamed from: binding$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy binding = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0<com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding>() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$binding$2
        {
            super(0);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding invoke() {
            return com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding.inflate(this.this$0.getLayoutInflater());
        }
    });

    /* renamed from: prefs$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy prefs = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0<android.content.SharedPreferences>() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$prefs$2
        {
            super(0);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final android.content.SharedPreferences invoke() {
            return this.this$0.getSharedPreferences(com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.prefsName(), 0);
        }
    });
    private android.animation.ValueAnimator progressAnimator;

    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u00032\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$ErrorResult;", "", "success", "", "message", "", "(ZLjava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "getSuccess", "()Z", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ErrorResult {
        private final java.lang.String message;
        private final boolean success;

        /* JADX WARN: Multi-variable type inference failed */
        public ErrorResult() {
            this(false, null, 3, 0 == true ? 1 : 0);
        }

        public ErrorResult(boolean z, java.lang.String message) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(message, "message");
            this.success = z;
            this.message = message;
        }

        public /* synthetic */ ErrorResult(boolean z, java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? "" : str);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult copy$default(com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult errorResult, boolean z, java.lang.String str, int i, java.lang.Object obj) {
            if ((i & 1) != 0) {
                z = errorResult.success;
            }
            if ((i & 2) != 0) {
                str = errorResult.message;
            }
            return errorResult.copy(z, str);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getSuccess() {
            return this.success;
        }

        /* renamed from: component2, reason: from getter */
        public final java.lang.String getMessage() {
            return this.message;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult copy(boolean success, java.lang.String message) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(message, "message");
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult(success, message);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult errorResult = (com.stellar.studio.spark6x3x.lottomatica.MainActivity.ErrorResult) other;
            return this.success == errorResult.success && kotlin.jvm.internal.Intrinsics.areEqual(this.message, errorResult.message);
        }

        public final java.lang.String getMessage() {
            return this.message;
        }

        public final boolean getSuccess() {
            return this.success;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.success;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + this.message.hashCode();
        }

        public java.lang.String toString() {
            return "ErrorResult(success=" + this.success + ", message=" + this.message + ')';
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InitState;", "", "(Ljava/lang/String;I)V", "START", "RUN", "STOP", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class InitState {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState START = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState("START", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState RUN = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState("RUN", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState STOP = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState("STOP", 2);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[]{START, RUN, STOP};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[] initStateArr$values = $values();
            $VALUES = initStateArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(initStateArr$values);
        }

        private InitState(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState[]) $VALUES.clone();
        }
    }

    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult;", "", "()V", "Error", "Loading", "Success", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Error;", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Loading;", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Success;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class InputResult {

        /* compiled from: MainActivity.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Error;", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult;", "code", "", "(I)V", "getCode", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Error extends com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult {
            private final int code;

            public Error() {
                this(0, 1, null);
            }

            public Error(int i) {
                super(null);
                this.code = i;
            }

            public /* synthetic */ Error(int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i2 & 1) != 0 ? 0 : i);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error copy$default(com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error error, int i, int i2, java.lang.Object obj) {
                if ((i2 & 1) != 0) {
                    i = error.code;
                }
                return error.copy(i);
            }

            /* renamed from: component1, reason: from getter */
            public final int getCode() {
                return this.code;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error copy(int code) {
                return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error(code);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error) && this.code == ((com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Error) other).code;
            }

            public final int getCode() {
                return this.code;
            }

            public int hashCode() {
                return java.lang.Integer.hashCode(this.code);
            }

            public java.lang.String toString() {
                return "Error(code=" + this.code + ')';
            }
        }

        /* compiled from: MainActivity.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Loading;", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Loading extends com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult {
            public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Loading INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Loading();

            private Loading() {
                super(null);
            }
        }

        /* compiled from: MainActivity.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult$Success;", "Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$InputResult;", "data", "", "(Ljava/lang/String;)V", "getData", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Success extends com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult {
            private final java.lang.String data;

            /* JADX WARN: Multi-variable type inference failed */
            public Success() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Success(java.lang.String data) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(data, "data");
                this.data = data;
            }

            public /* synthetic */ Success(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success copy$default(com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success success, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = success.data;
                }
                return success.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getData() {
                return this.data;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success copy(java.lang.String data) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(data, "data");
                return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success(data);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success) && kotlin.jvm.internal.Intrinsics.areEqual(this.data, ((com.stellar.studio.spark6x3x.lottomatica.MainActivity.InputResult.Success) other).data);
            }

            public final java.lang.String getData() {
                return this.data;
            }

            public int hashCode() {
                return this.data.hashCode();
            }

            public java.lang.String toString() {
                return "Success(data=" + this.data + ')';
            }
        }

        private InputResult() {
        }

        public /* synthetic */ InputResult(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$MoveMode;", "", "(Ljava/lang/String;I)V", "AUTO", "MANUAL", "DISABLED", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class MoveMode {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode AUTO = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode("AUTO", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode MANUAL = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode("MANUAL", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode DISABLED = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode("DISABLED", 2);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[]{AUTO, MANUAL, DISABLED};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[] moveModeArr$values = $values();
            $VALUES = moveModeArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(moveModeArr$values);
        }

        private MoveMode(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.MoveMode[]) $VALUES.clone();
        }
    }

    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u00032\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$SidebarConfig;", "", "enabled", "", "limit", "", "(ZI)V", "getEnabled", "()Z", "getLimit", "()I", "component1", "component2", "copy", "equals", "other", "hashCode", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class SidebarConfig {
        private final boolean enabled;
        private final int limit;

        /* JADX WARN: Multi-variable type inference failed */
        public SidebarConfig() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }

        public SidebarConfig(boolean z, int i) {
            this.enabled = z;
            this.limit = i;
        }

        public /* synthetic */ SidebarConfig(boolean z, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig copy$default(com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig sidebarConfig, boolean z, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                z = sidebarConfig.enabled;
            }
            if ((i2 & 2) != 0) {
                i = sidebarConfig.limit;
            }
            return sidebarConfig.copy(z, i);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getEnabled() {
            return this.enabled;
        }

        /* renamed from: component2, reason: from getter */
        public final int getLimit() {
            return this.limit;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig copy(boolean enabled, int limit) {
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig(enabled, limit);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig sidebarConfig = (com.stellar.studio.spark6x3x.lottomatica.MainActivity.SidebarConfig) other;
            return this.enabled == sidebarConfig.enabled && this.limit == sidebarConfig.limit;
        }

        public final boolean getEnabled() {
            return this.enabled;
        }

        public final int getLimit() {
            return this.limit;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.enabled;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Integer.hashCode(this.limit);
        }

        public java.lang.String toString() {
            return "SidebarConfig(enabled=" + this.enabled + ", limit=" + this.limit + ')';
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$TileType;", "", "(Ljava/lang/String;I)V", "NONE", "DEFAULT", "CUSTOM", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class TileType {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType NONE = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType("NONE", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType DEFAULT = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType("DEFAULT", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType CUSTOM = new com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType("CUSTOM", 2);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[]{NONE, DEFAULT, CUSTOM};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[] tileTypeArr$values = $values();
            $VALUES = tileTypeArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(tileTypeArr$values);
        }

        private TileType(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.MainActivity.TileType[]) $VALUES.clone();
        }
    }

    /* compiled from: MainActivity.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity$ValidatorInfo;", "", "code", "", "value", "", "(Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getValue", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ValidatorInfo {
        private final java.lang.String code;
        private final int value;

        /* JADX WARN: Multi-variable type inference failed */
        public ValidatorInfo() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }

        public ValidatorInfo(java.lang.String code, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            this.code = code;
            this.value = i;
        }

        public /* synthetic */ ValidatorInfo(java.lang.String str, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo copy$default(com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo validatorInfo, java.lang.String str, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = validatorInfo.code;
            }
            if ((i2 & 2) != 0) {
                i = validatorInfo.value;
            }
            return validatorInfo.copy(str, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final int getValue() {
            return this.value;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo copy(java.lang.String code, int value) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            return new com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo(code, value);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo validatorInfo = (com.stellar.studio.spark6x3x.lottomatica.MainActivity.ValidatorInfo) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.code, validatorInfo.code) && this.value == validatorInfo.value;
        }

        public final java.lang.String getCode() {
            return this.code;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + java.lang.Integer.hashCode(this.value);
        }

        public java.lang.String toString() {
            return "ValidatorInfo(code=" + this.code + ", value=" + this.value + ')';
        }
    }

    private final java.lang.String convertService(java.lang.String value) {
        return value.toString();
    }

    private final void fetchAndLoad() {
        okhttp3.Request.Builder builderUrl = new okhttp3.Request.Builder().url(com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.INSTANCE.getBase() + com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.INSTANCE.getQueryParam() + getPackageName());
        java.lang.String strHDevice = com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.hDevice();
        java.lang.String MODEL = android.os.Build.MODEL;
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(MODEL, "MODEL");
        okhttp3.Request.Builder builderHeader = builderUrl.header(strHDevice, MODEL).header(com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.hLang(), com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.vLang());
        java.lang.String strHUa = com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.hUa();
        com.stellar.studio.spark6x3x.lottomatica.MainActivity mainActivity = this;
        java.lang.String defaultUserAgent = android.webkit.WebSettings.getDefaultUserAgent(mainActivity);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(defaultUserAgent, "getDefaultUserAgent(...)");
        okhttp3.Request requestBuild = builderHeader.header(strHUa, defaultUserAgent).build();
        com.stellar.studio.spark6x3x.lottomatica.ApiResp apiResp = com.stellar.studio.spark6x3x.lottomatica.ApiResp.INSTANCE;
        android.content.SharedPreferences prefs = getPrefs();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(prefs, "<get-prefs>(...)");
        com.stellar.studio.spark6x3x.lottomatica.HttpClient.INSTANCE.get().newCall(requestBuild).enqueue(apiResp.create(mainActivity, prefs, this));
    }

    private final void finishProgressAndAction(final kotlin.jvm.functions.Function0<kotlin.Unit> action) {
        try {
            android.animation.ValueAnimator valueAnimator = this.progressAnimator;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            android.animation.ValueAnimator valueAnimatorOfInt = android.animation.ValueAnimator.ofInt(getBinding().splashProgressBar.getProgress(), 100);
            valueAnimatorOfInt.setDuration(320L);
            valueAnimatorOfInt.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$$ExternalSyntheticLambda1
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(android.animation.ValueAnimator valueAnimator2) {
                    com.stellar.studio.spark6x3x.lottomatica.MainActivity.finishProgressAndAction$lambda$3$lambda$2(this.f$0, valueAnimator2);
                }
            });
            valueAnimatorOfInt.addListener(new android.animation.AnimatorListenerAdapter() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$finishProgressAndAction$1$2
                @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                public void onAnimationEnd(android.animation.Animator animation) {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animation, "animation");
                    action.invoke();
                }
            });
            valueAnimatorOfInt.start();
        } catch (java.lang.Exception unused) {
            action.invoke();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void finishProgressAndAction$lambda$3$lambda$2(com.stellar.studio.spark6x3x.lottomatica.MainActivity this$0, android.animation.ValueAnimator anim) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(anim, "anim");
        java.lang.Object animatedValue = anim.getAnimatedValue();
        kotlin.jvm.internal.Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Int");
        int iIntValue = ((java.lang.Integer) animatedValue).intValue();
        this$0.getBinding().splashProgressBar.setProgress(iIntValue);
        this$0.getBinding().splashProgressText.setText(iIntValue >= 100 ? "Ready!" : "Loading resources " + iIntValue + "%...");
    }

    private final com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding getBinding() {
        return (com.stellar.studio.spark6x3x.lottomatica.databinding.ActivityMainBinding) this.binding.getValue();
    }

    private final android.content.SharedPreferences getPrefs() {
        return (android.content.SharedPreferences) this.prefs.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void loadFallbackGame() {
        startActivity(new android.content.Intent(this, (java.lang.Class<?>) com.stellar.studio.spark6x3x.lottomatica.MainActivity2.class));
    }

    private final int maxArrange(int a, int b) {
        return java.lang.Math.max(a, b);
    }

    private final int monitorCollection() {
        return 1;
    }

    private final boolean notNullSwap(java.lang.Object value) {
        return value != null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.core.view.WindowInsetsCompat onCreate$lambda$4(android.view.View v, androidx.core.view.WindowInsetsCompat insets) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(v, "v");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(insets, "insets");
        androidx.core.graphics.Insets insets2 = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars());
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        v.setPadding(insets2.left, insets2.top, insets2.right, insets2.bottom);
        return insets;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openExternal(java.lang.String url) {
        if (com.stellar.studio.spark6x3x.lottomatica.WebNav.INSTANCE.open(this, url)) {
            return;
        }
        loadFallbackGame();
    }

    private final int parseSend(java.lang.String data) {
        return data.length();
    }

    private final void startProgressAnimation() {
        try {
            getBinding().splashLayout.setVisibility(0);
            getBinding().menuLayout.setVisibility(8);
            android.animation.ValueAnimator valueAnimatorOfInt = android.animation.ValueAnimator.ofInt(15, 88);
            valueAnimatorOfInt.setDuration(2400L);
            valueAnimatorOfInt.setInterpolator(new android.view.animation.DecelerateInterpolator());
            valueAnimatorOfInt.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$$ExternalSyntheticLambda0
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(android.animation.ValueAnimator valueAnimator) {
                    com.stellar.studio.spark6x3x.lottomatica.MainActivity.startProgressAnimation$lambda$1$lambda$0(this.f$0, valueAnimator);
                }
            });
            valueAnimatorOfInt.start();
            this.progressAnimator = valueAnimatorOfInt;
        } catch (java.lang.Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startProgressAnimation$lambda$1$lambda$0(com.stellar.studio.spark6x3x.lottomatica.MainActivity this$0, android.animation.ValueAnimator anim) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(anim, "anim");
        java.lang.Object animatedValue = anim.getAnimatedValue();
        kotlin.jvm.internal.Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Int");
        int iIntValue = ((java.lang.Integer) animatedValue).intValue();
        this$0.getBinding().splashProgressBar.setProgress(iIntValue);
        this$0.getBinding().splashProgressText.setText("Loading resources " + iIntValue + "%...");
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        androidx.activity.EdgeToEdge.enable$default(this, null, null, 3, null);
        if (com.stellar.studio.spark6x3x.lottomatica.MainActivity.InitState.START != null) {
            setContentView(getBinding().getRoot());
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.main), new androidx.core.view.OnApplyWindowInsetsListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity$$ExternalSyntheticLambda2
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            public final androidx.core.view.WindowInsetsCompat onApplyWindowInsets(android.view.View view, androidx.core.view.WindowInsetsCompat windowInsetsCompat) {
                return com.stellar.studio.spark6x3x.lottomatica.MainActivity.onCreate$lambda$4(view, windowInsetsCompat);
            }
        });
        getWindow().setFlags(1024, 1024);
        startProgressAnimation();
        final java.lang.String string = getPrefs().getString(com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.prefsKey(), null);
        java.lang.String str = string;
        if (str == null || kotlin.text.StringsKt.isBlank(str)) {
            fetchAndLoad();
        } else {
            com.stellar.studio.spark6x3x.lottomatica.RedirectState.INSTANCE.setRedirectUrl(string);
            finishProgressAndAction(new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity.onCreate.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                    invoke2();
                    return kotlin.Unit.INSTANCE;
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    com.stellar.studio.spark6x3x.lottomatica.MainActivity.this.openExternal(string);
                }
            });
        }
    }

    @Override // com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener
    public void onFallback() {
        finishProgressAndAction(new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity.onFallback.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                invoke2();
                return kotlin.Unit.INSTANCE;
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity.this.loadFallbackGame();
            }
        });
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        java.lang.String redirectUrl = com.stellar.studio.spark6x3x.lottomatica.RedirectState.INSTANCE.getRedirectUrl();
        if (redirectUrl != null) {
            openExternal(redirectUrl);
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStart() {
        super.onStart();
    }

    @Override // com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener
    public void onUrl(final java.lang.String url) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
        com.stellar.studio.spark6x3x.lottomatica.RedirectState.INSTANCE.setRedirectUrl(url);
        finishProgressAndAction(new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity.onUrl.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                invoke2();
                return kotlin.Unit.INSTANCE;
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity.this.openExternal(url);
            }
        });
    }
}
