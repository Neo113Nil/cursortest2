package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: RedirectState.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002\u001b\u001cB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u000b\u001a\u00020\fJ\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002J\u0010\u0010\u0010\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002J\u0018\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0004H\u0002J\u0018\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\u000eH\u0002J\u0006\u0010\u0015\u001a\u00020\u0016J\u0010\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0005\u001a\u00020\u0004H\u0002J\u0010\u0010\u0018\u001a\u00020\u00162\u0006\u0010\u0005\u001a\u00020\u0004H\u0002J\u0018\u0010\u0019\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\u000eH\u0002J\b\u0010\u001a\u001a\u00020\u0016H\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R(\u0010\u0006\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00048F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\u001d"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState;", "", "()V", "_redirectUrl", "", "value", "redirectUrl", "getRedirectUrl", "()Ljava/lang/String;", "setRedirectUrl", "(Ljava/lang/String;)V", "clear", "", "computeGallery", "", "input", "computeReport", "concatExport", "a", "b", "diffInput", "hasRedirect", "", "isDeleteValid", "isJobValid", "maxCache", "validateMessaging", "PacketManager", "UrlEvent", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class RedirectState {
    public static final com.stellar.studio.spark6x3x.lottomatica.RedirectState INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.RedirectState();
    private static volatile java.lang.String _redirectUrl;

    /* compiled from: RedirectState.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0004J\u0006\u0010\u0006\u001a\u00020\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$PacketManager;", "", "()V", "_count", "", "increment", "reset", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class PacketManager {
        public static final com.stellar.studio.spark6x3x.lottomatica.RedirectState.PacketManager INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.RedirectState.PacketManager();
        private static int _count;

        private PacketManager() {
        }

        public final int increment() {
            int i = _count + 1;
            _count = i;
            return i;
        }

        public final void reset() {
            _count = 0;
        }
    }

    /* compiled from: RedirectState.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent;", "", "()V", "Completed", "Failed", "Started", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Started;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class UrlEvent {

        /* compiled from: RedirectState.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Completed extends com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Completed INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Completed();

            private Completed() {
                super(null);
            }
        }

        /* compiled from: RedirectState.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent;", "reason", "", "(Ljava/lang/String;)V", "getReason", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Failed extends com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent {
            private final java.lang.String reason;

            /* JADX WARN: Multi-variable type inference failed */
            public Failed() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Failed(java.lang.String reason) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                this.reason = reason;
            }

            public /* synthetic */ Failed(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed copy$default(com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed failed, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = failed.reason;
                }
                return failed.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getReason() {
                return this.reason;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed copy(java.lang.String reason) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                return new com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed(reason);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed) && kotlin.jvm.internal.Intrinsics.areEqual(this.reason, ((com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Failed) other).reason);
            }

            public final java.lang.String getReason() {
                return this.reason;
            }

            public int hashCode() {
                return this.reason.hashCode();
            }

            public java.lang.String toString() {
                return "Failed(reason=" + this.reason + ')';
            }
        }

        /* compiled from: RedirectState.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent$Started;", "Lcom/stellar/studio/spark6x3x/lottomatica/RedirectState$UrlEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Started extends com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Started INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.RedirectState.UrlEvent.Started();

            private Started() {
                super(null);
            }
        }

        private UrlEvent() {
        }

        public /* synthetic */ UrlEvent(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    private RedirectState() {
    }

    private final int computeGallery(int input) {
        return (input * 2) / 2;
    }

    private final int computeReport(int input) {
        return (input * 2) / 2;
    }

    private final java.lang.String concatExport(java.lang.String a, java.lang.String b) {
        return a + b;
    }

    private final int diffInput(int a, int b) {
        return java.lang.Math.abs(a - b);
    }

    private final boolean isDeleteValid(java.lang.String value) {
        return value.length() >= 0;
    }

    private final boolean isJobValid(java.lang.String value) {
        return value.length() >= 0;
    }

    private final int maxCache(int a, int b) {
        return java.lang.Math.max(a, b);
    }

    private final boolean validateMessaging() {
        return true;
    }

    public final void clear() {
        _redirectUrl = null;
    }

    public final java.lang.String getRedirectUrl() {
        return _redirectUrl;
    }

    public final boolean hasRedirect() {
        java.lang.String str = _redirectUrl;
        return !(str == null || kotlin.text.StringsKt.isBlank(str));
    }

    public final void setRedirectUrl(java.lang.String str) {
        _redirectUrl = str;
    }
}
