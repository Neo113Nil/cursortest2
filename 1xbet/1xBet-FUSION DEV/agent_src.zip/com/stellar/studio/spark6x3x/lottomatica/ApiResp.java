package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: ApiResp.kt */
@kotlin.Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001:\b\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001fB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0002J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bH\u0002J\u0018\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u000b2\u0006\u0010\u0006\u001a\u00020\u000bH\u0002J\u001e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013J\b\u0010\u0014\u001a\u00020\u0004H\u0002J\u0018\u0010\u0015\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\b2\u0006\u0010\u0006\u001a\u00020\bH\u0002J\b\u0010\u0016\u001a\u00020\u0004H\u0002J\b\u0010\u0017\u001a\u00020\u0004H\u0002¨\u0006 "}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp;", "", "()V", "andMessage", "", "a", "b", "calculateModify", "", "input", "concatHotfix", "", "create", "Lokhttp3/Callback;", "ctx", "Landroid/content/Context;", "prefs", "Landroid/content/SharedPreferences;", "listener", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$Listener;", "ensureVerifier", "sumInvoice", "verifyReleaseState", "verifySetupState", "CheckType", "CloseState", "GraphState", "LinkCallback", "Listener", "MirrorConfig", "PackageManager", "TransmitEvent", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ApiResp {
    public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ApiResp();

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$CheckType;", "", "(Ljava/lang/String;I)V", "NONE", "DEFAULT", "CUSTOM", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class CheckType {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType NONE = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType("NONE", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType DEFAULT = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType("DEFAULT", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType CUSTOM = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType("CUSTOM", 2);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[]{NONE, DEFAULT, CUSTOM};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[] checkTypeArr$values = $values();
            $VALUES = checkTypeArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(checkTypeArr$values);
        }

        private CheckType(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.ApiResp.CheckType[]) $VALUES.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$CloseState;", "", "(Ljava/lang/String;I)V", "INIT", "READY", kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt.RUNNING, "STOPPED", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class CloseState {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[] $VALUES;
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState INIT = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState("INIT", 0);
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState READY = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState("READY", 1);
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState RUNNING = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState(kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt.RUNNING, 2);
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState STOPPED = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState("STOPPED", 3);

        private static final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[] $values() {
            return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[]{INIT, READY, RUNNING, STOPPED};
        }

        static {
            com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[] closeStateArr$values = $values();
            $VALUES = closeStateArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(closeStateArr$values);
        }

        private CloseState(java.lang.String str, int i) {
        }

        public static kotlin.enums.EnumEntries<com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState> getEntries() {
            return $ENTRIES;
        }

        public static com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState valueOf(java.lang.String str) {
            return (com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState) java.lang.Enum.valueOf(com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState.class, str);
        }

        public static com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[] values() {
            return (com.stellar.studio.spark6x3x.lottomatica.ApiResp.CloseState[]) $VALUES.clone();
        }
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\r\u001a\u00020\u00032\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$GraphState;", "", "isReady", "", "timestamp", "", "(ZJ)V", "()Z", "getTimestamp", "()J", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class GraphState {
        private final boolean isReady;
        private final long timestamp;

        public GraphState() {
            this(false, 0L, 3, null);
        }

        public GraphState(boolean z, long j) {
            this.isReady = z;
            this.timestamp = j;
        }

        public /* synthetic */ GraphState(boolean z, long j, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState copy$default(com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState graphState, boolean z, long j, int i, java.lang.Object obj) {
            if ((i & 1) != 0) {
                z = graphState.isReady;
            }
            if ((i & 2) != 0) {
                j = graphState.timestamp;
            }
            return graphState.copy(z, j);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getIsReady() {
            return this.isReady;
        }

        /* renamed from: component2, reason: from getter */
        public final long getTimestamp() {
            return this.timestamp;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState copy(boolean isReady, long timestamp) {
            return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState(isReady, timestamp);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState graphState = (com.stellar.studio.spark6x3x.lottomatica.ApiResp.GraphState) other;
            return this.isReady == graphState.isReady && this.timestamp == graphState.timestamp;
        }

        public final long getTimestamp() {
            return this.timestamp;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.isReady;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Long.hashCode(this.timestamp);
        }

        public final boolean isReady() {
            return this.isReady;
        }

        public java.lang.String toString() {
            return "GraphState(isReady=" + this.isReady + ", timestamp=" + this.timestamp + ')';
        }
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\bb\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0003H&¨\u0006\u0007"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$LinkCallback;", "", "onError", "", "code", "", "onSuccess", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private interface LinkCallback {
        void onError(int code);

        void onSuccess();
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H&¨\u0006\u0007"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$Listener;", "", "onFallback", "", "onUrl", "url", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public interface Listener {
        void onFallback();

        void onUrl(java.lang.String url);
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u00032\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$MirrorConfig;", "", "enabled", "", "limit", "", "(ZI)V", "getEnabled", "()Z", "getLimit", "()I", "component1", "component2", "copy", "equals", "other", "hashCode", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class MirrorConfig {
        private final boolean enabled;
        private final int limit;

        /* JADX WARN: Multi-variable type inference failed */
        public MirrorConfig() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }

        public MirrorConfig(boolean z, int i) {
            this.enabled = z;
            this.limit = i;
        }

        public /* synthetic */ MirrorConfig(boolean z, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig copy$default(com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig mirrorConfig, boolean z, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                z = mirrorConfig.enabled;
            }
            if ((i2 & 2) != 0) {
                i = mirrorConfig.limit;
            }
            return mirrorConfig.copy(z, i);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getEnabled() {
            return this.enabled;
        }

        /* renamed from: component2, reason: from getter */
        public final int getLimit() {
            return this.limit;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig copy(boolean enabled, int limit) {
            return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig(enabled, limit);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig mirrorConfig = (com.stellar.studio.spark6x3x.lottomatica.ApiResp.MirrorConfig) other;
            return this.enabled == mirrorConfig.enabled && this.limit == mirrorConfig.limit;
        }

        public final boolean getEnabled() {
            return this.enabled;
        }

        public final int getLimit() {
            return this.limit;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.enabled;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Integer.hashCode(this.limit);
        }

        public java.lang.String toString() {
            return "MirrorConfig(enabled=" + this.enabled + ", limit=" + this.limit + ')';
        }
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0004J\u0006\u0010\u0006\u001a\u00020\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$PackageManager;", "", "()V", "_count", "", "increment", "reset", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class PackageManager {
        public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.PackageManager INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.PackageManager();
        private static int _count;

        private PackageManager() {
        }

        public final int increment() {
            int i = _count + 1;
            _count = i;
            return i;
        }

        public final void reset() {
            _count = 0;
        }
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent;", "", "()V", "Completed", "Failed", "Started", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Started;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class TransmitEvent {

        /* compiled from: ApiResp.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Completed extends com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Completed INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Completed();

            private Completed() {
                super(null);
            }
        }

        /* compiled from: ApiResp.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent;", "reason", "", "(Ljava/lang/String;)V", "getReason", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Failed extends com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent {
            private final java.lang.String reason;

            /* JADX WARN: Multi-variable type inference failed */
            public Failed() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Failed(java.lang.String reason) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                this.reason = reason;
            }

            public /* synthetic */ Failed(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed copy$default(com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed failed, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = failed.reason;
                }
                return failed.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getReason() {
                return this.reason;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed copy(java.lang.String reason) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed(reason);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed) && kotlin.jvm.internal.Intrinsics.areEqual(this.reason, ((com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Failed) other).reason);
            }

            public final java.lang.String getReason() {
                return this.reason;
            }

            public int hashCode() {
                return this.reason.hashCode();
            }

            public java.lang.String toString() {
                return "Failed(reason=" + this.reason + ')';
            }
        }

        /* compiled from: ApiResp.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent$Started;", "Lcom/stellar/studio/spark6x3x/lottomatica/ApiResp$TransmitEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Started extends com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Started INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ApiResp.TransmitEvent.Started();

            private Started() {
                super(null);
            }
        }

        private TransmitEvent() {
        }

        public /* synthetic */ TransmitEvent(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    /* compiled from: ApiResp.kt */
    @kotlin.Metadata(d1 = {"\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0018\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nH\u0016¨\u0006\u000b"}, d2 = {"com/stellar/studio/spark6x3x/lottomatica/ApiResp$create$1", "Lokhttp3/Callback;", "onFailure", "", androidx.core.app.NotificationCompat.CATEGORY_CALL, "Lokhttp3/Call;", "e", "Ljava/io/IOException;", "onResponse", "response", "Lokhttp3/Response;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    /* renamed from: com.stellar.studio.spark6x3x.lottomatica.ApiResp$create$1, reason: invalid class name */
    public static final class AnonymousClass1 implements okhttp3.Callback {
        final /* synthetic */ android.content.Context $ctx;
        final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener $listener;
        final /* synthetic */ android.content.SharedPreferences $prefs;

        AnonymousClass1(android.content.Context context, com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener, android.content.SharedPreferences sharedPreferences) {
            this.$ctx = context;
            this.$listener = listener;
            this.$prefs = sharedPreferences;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onFailure$lambda$0(com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(listener, "$listener");
            listener.onFallback();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onResponse$lambda$1(com.stellar.studio.spark6x3x.lottomatica.DataParser.Result result, android.content.SharedPreferences prefs, com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(result, "$result");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(prefs, "$prefs");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(listener, "$listener");
            if (result instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect) {
                com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect redirect = (com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect) result;
                prefs.edit().putString(com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.prefsKey(), redirect.getUrl()).apply();
                listener.onUrl(redirect.getUrl());
            } else if (result instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Fallback) {
                listener.onFallback();
            }
        }

        @Override // okhttp3.Callback
        public void onFailure(okhttp3.Call call, java.io.IOException e) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(call, "call");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(e, "e");
            android.content.Context context = this.$ctx;
            android.app.Activity activity = context instanceof android.app.Activity ? (android.app.Activity) context : null;
            if (activity != null) {
                final com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener = this.$listener;
                activity.runOnUiThread(new java.lang.Runnable() { // from class: com.stellar.studio.spark6x3x.lottomatica.ApiResp$create$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        com.stellar.studio.spark6x3x.lottomatica.ApiResp.AnonymousClass1.onFailure$lambda$0(listener);
                    }
                });
            }
        }

        @Override // okhttp3.Callback
        public void onResponse(okhttp3.Call call, okhttp3.Response response) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(call, "call");
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(response, "response");
            final com.stellar.studio.spark6x3x.lottomatica.DataParser.Result result = com.stellar.studio.spark6x3x.lottomatica.DataParser.INSTANCE.parse(response);
            android.content.Context context = this.$ctx;
            android.app.Activity activity = context instanceof android.app.Activity ? (android.app.Activity) context : null;
            if (activity != null) {
                final android.content.SharedPreferences sharedPreferences = this.$prefs;
                final com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener = this.$listener;
                activity.runOnUiThread(new java.lang.Runnable() { // from class: com.stellar.studio.spark6x3x.lottomatica.ApiResp$create$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        com.stellar.studio.spark6x3x.lottomatica.ApiResp.AnonymousClass1.onResponse$lambda$1(result, sharedPreferences, listener);
                    }
                });
            }
        }
    }

    private ApiResp() {
    }

    private final boolean andMessage(boolean a, boolean b) {
        return a && b;
    }

    private final int calculateModify(int input) {
        for (int i = 0; i < 11; i++) {
            input += i - i;
        }
        return input;
    }

    private final java.lang.String concatHotfix(java.lang.String a, java.lang.String b) {
        return a + b;
    }

    private final boolean ensureVerifier() {
        return true;
    }

    private final int sumInvoice(int a, int b) {
        return a + b;
    }

    private final boolean verifyReleaseState() {
        return java.lang.System.currentTimeMillis() > 0;
    }

    private final boolean verifySetupState() {
        return java.lang.System.currentTimeMillis() > 0;
    }

    public final okhttp3.Callback create(android.content.Context ctx, android.content.SharedPreferences prefs, com.stellar.studio.spark6x3x.lottomatica.ApiResp.Listener listener) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(ctx, "ctx");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(prefs, "prefs");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(listener, "listener");
        return new com.stellar.studio.spark6x3x.lottomatica.ApiResp.AnonymousClass1(ctx, listener, prefs);
    }
}
