package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: ConfigUrl.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002\u0010\u0011B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0002J\u0006\u0010\u0005\u001a\u00020\u0006J\u0006\u0010\u0007\u001a\u00020\u0006J\u000e\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0006J\b\u0010\n\u001a\u00020\u000bH\u0002J\u0012\u0010\f\u001a\u00020\u00062\b\u0010\r\u001a\u0004\u0018\u00010\u0006H\u0002J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0006H\u0002¨\u0006\u0012"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ConfigUrl;", "", "()V", "checkStream", "", "getBase", "", "getQueryParam", "isWorkerUrl", "url", "monitorRefresh", "", "safeAction", "value", "trackCache", "action", "AuthInfo", "DragManager", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class ConfigUrl {
    public static final com.stellar.studio.spark6x3x.lottomatica.ConfigUrl INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ConfigUrl();

    /* compiled from: ConfigUrl.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ConfigUrl$AuthInfo;", "", "code", "", "value", "", "(Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getValue", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class AuthInfo {
        private final java.lang.String code;
        private final int value;

        /* JADX WARN: Multi-variable type inference failed */
        public AuthInfo() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }

        public AuthInfo(java.lang.String code, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            this.code = code;
            this.value = i;
        }

        public /* synthetic */ AuthInfo(java.lang.String str, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo copy$default(com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo authInfo, java.lang.String str, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = authInfo.code;
            }
            if ((i2 & 2) != 0) {
                i = authInfo.value;
            }
            return authInfo.copy(str, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final int getValue() {
            return this.value;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo copy(java.lang.String code, int value) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            return new com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo(code, value);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo authInfo = (com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.AuthInfo) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.code, authInfo.code) && this.value == authInfo.value;
        }

        public final java.lang.String getCode() {
            return this.code;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + java.lang.Integer.hashCode(this.value);
        }

        public java.lang.String toString() {
            return "AuthInfo(code=" + this.code + ", value=" + this.value + ')';
        }
    }

    /* compiled from: ConfigUrl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0004J\u0006\u0010\u0006\u001a\u00020\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/ConfigUrl$DragManager;", "", "()V", "_count", "", "increment", "reset", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final class DragManager {
        public static final com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.DragManager INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.DragManager();
        private static int _count;

        private DragManager() {
        }

        public final int increment() {
            int i = _count + 1;
            _count = i;
            return i;
        }

        public final void reset() {
            _count = 0;
        }
    }

    private ConfigUrl() {
    }

    private final boolean checkStream() {
        return true;
    }

    private final int monitorRefresh() {
        return 1;
    }

    private final java.lang.String safeAction(java.lang.String value) {
        return value == null ? "" : value;
    }

    private final int trackCache(java.lang.String action) {
        return action.hashCode();
    }

    public final java.lang.String getBase() {
        return com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.cfgUrl();
    }

    public final java.lang.String getQueryParam() {
        return com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.qApp();
    }

    public final boolean isWorkerUrl(java.lang.String url) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
        return kotlin.text.StringsKt.contains$default((java.lang.CharSequence) url, (java.lang.CharSequence) com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.workersDev(), false, 2, (java.lang.Object) null);
    }
}
