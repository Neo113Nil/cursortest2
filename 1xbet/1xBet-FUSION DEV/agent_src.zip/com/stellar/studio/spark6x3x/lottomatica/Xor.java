package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: Xor.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001:\u0003\u001d\u001e\u001fB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\tJ\b\u0010\n\u001a\u00020\u000bH\u0002J\b\u0010\f\u001a\u00020\u0004H\u0002J\u0006\u0010\r\u001a\u00020\u0006J\u0006\u0010\u000e\u001a\u00020\u0006J\u0006\u0010\u000f\u001a\u00020\u0006J\u0010\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0006H\u0002J\b\u0010\u0012\u001a\u00020\u0013H\u0002J\u0012\u0010\u0014\u001a\u00020\u000b2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001H\u0002J\u0010\u0010\u0016\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0006H\u0002J\u0006\u0010\u0017\u001a\u00020\u0006J\u0006\u0010\u0018\u001a\u00020\u0006J\u0006\u0010\u0019\u001a\u00020\u0006J\u0006\u0010\u001a\u001a\u00020\u0006J\u0006\u0010\u001b\u001a\u00020\u0006J\u0006\u0010\u001c\u001a\u00020\u0006R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006 "}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor;", "", "()V", "K", "", "cfgUrl", "", "decode", "b", "", "ensureGallery", "", "getIdScanner", "hDevice", "hLang", "hUa", "hashNode", "data", "measurePresenter", "", "notNullAction", "value", "parseSetup", "prefsKey", "prefsName", "qApp", "statusOk", "vLang", "workersDev", "ConverterListener", "PublisherInfo", "ToastResult", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class Xor {
    public static final com.stellar.studio.spark6x3x.lottomatica.Xor INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.Xor();
    private static final int K = 4120;

    /* compiled from: Xor.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bb\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ConverterListener;", "", "onChanged", "", "value", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private interface ConverterListener {
        void onChanged(java.lang.String value);
    }

    /* compiled from: Xor.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$PublisherInfo;", "", "code", "", "value", "", "(Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getValue", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class PublisherInfo {
        private final java.lang.String code;
        private final int value;

        /* JADX WARN: Multi-variable type inference failed */
        public PublisherInfo() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }

        public PublisherInfo(java.lang.String code, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            this.code = code;
            this.value = i;
        }

        public /* synthetic */ PublisherInfo(java.lang.String str, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo copy$default(com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo publisherInfo, java.lang.String str, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = publisherInfo.code;
            }
            if ((i2 & 2) != 0) {
                i = publisherInfo.value;
            }
            return publisherInfo.copy(str, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final int getValue() {
            return this.value;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo copy(java.lang.String code, int value) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            return new com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo(code, value);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo publisherInfo = (com.stellar.studio.spark6x3x.lottomatica.Xor.PublisherInfo) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.code, publisherInfo.code) && this.value == publisherInfo.value;
        }

        public final java.lang.String getCode() {
            return this.code;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + java.lang.Integer.hashCode(this.value);
        }

        public java.lang.String toString() {
            return "PublisherInfo(code=" + this.code + ", value=" + this.value + ')';
        }
    }

    /* compiled from: Xor.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult;", "", "()V", "Error", "Loading", "Success", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Error;", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Loading;", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Success;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class ToastResult {

        /* compiled from: Xor.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u0003HÖ\u0001J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Error;", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult;", "code", "", "(I)V", "getCode", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Error extends com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult {
            private final int code;

            public Error() {
                this(0, 1, null);
            }

            public Error(int i) {
                super(null);
                this.code = i;
            }

            public /* synthetic */ Error(int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i2 & 1) != 0 ? 0 : i);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error copy$default(com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error error, int i, int i2, java.lang.Object obj) {
                if ((i2 & 1) != 0) {
                    i = error.code;
                }
                return error.copy(i);
            }

            /* renamed from: component1, reason: from getter */
            public final int getCode() {
                return this.code;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error copy(int code) {
                return new com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error(code);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error) && this.code == ((com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Error) other).code;
            }

            public final int getCode() {
                return this.code;
            }

            public int hashCode() {
                return java.lang.Integer.hashCode(this.code);
            }

            public java.lang.String toString() {
                return "Error(code=" + this.code + ')';
            }
        }

        /* compiled from: Xor.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Loading;", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Loading extends com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult {
            public static final com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Loading INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Loading();

            private Loading() {
                super(null);
            }
        }

        /* compiled from: Xor.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult$Success;", "Lcom/stellar/studio/spark6x3x/lottomatica/Xor$ToastResult;", "data", "", "(Ljava/lang/String;)V", "getData", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Success extends com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult {
            private final java.lang.String data;

            /* JADX WARN: Multi-variable type inference failed */
            public Success() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Success(java.lang.String data) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(data, "data");
                this.data = data;
            }

            public /* synthetic */ Success(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success copy$default(com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success success, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = success.data;
                }
                return success.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getData() {
                return this.data;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success copy(java.lang.String data) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(data, "data");
                return new com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success(data);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success) && kotlin.jvm.internal.Intrinsics.areEqual(this.data, ((com.stellar.studio.spark6x3x.lottomatica.Xor.ToastResult.Success) other).data);
            }

            public final java.lang.String getData() {
                return this.data;
            }

            public int hashCode() {
                return this.data.hashCode();
            }

            public java.lang.String toString() {
                return "Success(data=" + this.data + ')';
            }
        }

        private ToastResult() {
        }

        public /* synthetic */ ToastResult(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    private Xor() {
    }

    private final boolean ensureGallery() {
        return true;
    }

    private final int getIdScanner() {
        return java.lang.System.identityHashCode(this);
    }

    private final int hashNode(java.lang.String data) {
        return data.hashCode();
    }

    private final long measurePresenter() {
        return (java.lang.System.currentTimeMillis() - java.lang.System.currentTimeMillis()) + 1;
    }

    private final boolean notNullAction(java.lang.Object value) {
        return value != null;
    }

    private final int parseSetup(java.lang.String data) {
        return data.length();
    }

    public final java.lang.String cfgUrl() {
        return decode(new byte[]{120, 108, 100, 104, 99, 34, okio.Utf8.REPLACEMENT_BYTE, 55, 126, 121, 125, 125, 124, 125, 99, 107, kotlin.io.encoding.Base64.padSymbol, 116, 121, 117, 121, 108, kotlin.io.encoding.Base64.padSymbol, 122, 115, 32, 32, 54, 125, 97, 123, 112, 126, 119, kotlin.io.encoding.Base64.padSymbol, 122, 113, 123, 123, 125, 126, 124, kotlin.io.encoding.Base64.padSymbol, 124, 117, 110, 62, 111, kotlin.jvm.internal.ByteCompanionObject.MAX_VALUE, 106, 123, 125, 98, 107, 62, 124, 117, 110, okio.Utf8.REPLACEMENT_BYTE});
    }

    public final java.lang.String decode(byte[] b) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(b, "b");
        java.util.ArrayList arrayList = new java.util.ArrayList(b.length);
        int length = b.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int i3 = i2 + 1;
            arrayList.add(java.lang.Byte.valueOf((byte) ((i2 % 2 == 0 ? 16 : 24) ^ (b[i] & kotlin.UByte.MAX_VALUE))));
            i++;
            i2 = i3;
        }
        return new java.lang.String(kotlin.collections.CollectionsKt.toByteArray(arrayList), kotlin.text.Charsets.UTF_8);
    }

    public final java.lang.String hDevice() {
        return decode(new byte[]{72, 53, 84, 125, 102, 113, 115, 125, kotlin.io.encoding.Base64.padSymbol, 85, kotlin.jvm.internal.ByteCompanionObject.MAX_VALUE, 124, 117, 116});
    }

    public final java.lang.String hLang() {
        return decode(new byte[]{81, 123, 115, 125, 96, 108, kotlin.io.encoding.Base64.padSymbol, 84, 113, 118, 119, 109, 113, kotlin.jvm.internal.ByteCompanionObject.MAX_VALUE, 117});
    }

    public final java.lang.String hUa() {
        return decode(new byte[]{69, 107, 117, 106, kotlin.io.encoding.Base64.padSymbol, 89, 119, 125, 126, 108});
    }

    public final java.lang.String prefsKey() {
        return decode(new byte[]{126, 121, 102, 71, 101, 106, 124});
    }

    public final java.lang.String prefsName() {
        return decode(new byte[]{113, 104, 96, 71, 115, 126, 119});
    }

    public final java.lang.String qApp() {
        return decode(new byte[]{47, 121, 96, 104, 45});
    }

    public final java.lang.String statusOk() {
        return decode(new byte[]{50, 107, 100, 121, 100, 109, 99, 58, 42, 58, kotlin.jvm.internal.ByteCompanionObject.MAX_VALUE, 115, 50});
    }

    public final java.lang.String vLang() {
        return decode(new byte[]{101, 115, kotlin.io.encoding.Base64.padSymbol, 77, 81, 52, 121, 108, kotlin.io.encoding.Base64.padSymbol, 81, 68, 35, 97, 37, 32, 54, 41, 52, 117, 118, kotlin.io.encoding.Base64.padSymbol, 77, 67, 35, 97, 37, 32, 54, 40});
    }

    public final java.lang.String workersDev() {
        return decode(new byte[]{103, 119, 98, 115, 117, 106, 99, 54, 116, 125, 102});
    }
}
