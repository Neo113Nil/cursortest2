package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: HttpClient.kt */
@kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001:\u0003\u0011\u0012\u0013B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\t\u001a\u00020\u0004J\u0018\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH\u0002J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000fH\u0002R\u001b\u0010\u0003\u001a\u00020\u00048BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0014"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/HttpClient;", "", "()V", "client", "Lokhttp3/OkHttpClient;", "getClient", "()Lokhttp3/OkHttpClient;", "client$delegate", "Lkotlin/Lazy;", "get", "orInput", "", "a", "b", "processReport", "", "data", "CleanupListener", "ComponentState", "ReleaseInfo", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class HttpClient {
    public static final com.stellar.studio.spark6x3x.lottomatica.HttpClient INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.HttpClient();

    /* renamed from: client$delegate, reason: from kotlin metadata */
    private static final kotlin.Lazy client = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0<okhttp3.OkHttpClient>() { // from class: com.stellar.studio.spark6x3x.lottomatica.HttpClient$client$2
        @Override // kotlin.jvm.functions.Function0
        public final okhttp3.OkHttpClient invoke() {
            return new okhttp3.OkHttpClient.Builder().build();
        }
    });

    /* compiled from: HttpClient.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bb\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0006"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/HttpClient$CleanupListener;", "", "onChanged", "", "value", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private interface CleanupListener {
        void onChanged(java.lang.String value);
    }

    /* compiled from: HttpClient.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\r\u001a\u00020\u00032\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/HttpClient$ComponentState;", "", "isReady", "", "timestamp", "", "(ZJ)V", "()Z", "getTimestamp", "()J", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ComponentState {
        private final boolean isReady;
        private final long timestamp;

        public ComponentState() {
            this(false, 0L, 3, null);
        }

        public ComponentState(boolean z, long j) {
            this.isReady = z;
            this.timestamp = j;
        }

        public /* synthetic */ ComponentState(boolean z, long j, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState copy$default(com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState componentState, boolean z, long j, int i, java.lang.Object obj) {
            if ((i & 1) != 0) {
                z = componentState.isReady;
            }
            if ((i & 2) != 0) {
                j = componentState.timestamp;
            }
            return componentState.copy(z, j);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getIsReady() {
            return this.isReady;
        }

        /* renamed from: component2, reason: from getter */
        public final long getTimestamp() {
            return this.timestamp;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState copy(boolean isReady, long timestamp) {
            return new com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState(isReady, timestamp);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState componentState = (com.stellar.studio.spark6x3x.lottomatica.HttpClient.ComponentState) other;
            return this.isReady == componentState.isReady && this.timestamp == componentState.timestamp;
        }

        public final long getTimestamp() {
            return this.timestamp;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.isReady;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Long.hashCode(this.timestamp);
        }

        public final boolean isReady() {
            return this.isReady;
        }

        public java.lang.String toString() {
            return "ComponentState(isReady=" + this.isReady + ", timestamp=" + this.timestamp + ')';
        }
    }

    /* compiled from: HttpClient.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/HttpClient$ReleaseInfo;", "", "code", "", "value", "", "(Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getValue", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ReleaseInfo {
        private final java.lang.String code;
        private final int value;

        /* JADX WARN: Multi-variable type inference failed */
        public ReleaseInfo() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }

        public ReleaseInfo(java.lang.String code, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            this.code = code;
            this.value = i;
        }

        public /* synthetic */ ReleaseInfo(java.lang.String str, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo copy$default(com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo releaseInfo, java.lang.String str, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = releaseInfo.code;
            }
            if ((i2 & 2) != 0) {
                i = releaseInfo.value;
            }
            return releaseInfo.copy(str, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final int getValue() {
            return this.value;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo copy(java.lang.String code, int value) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            return new com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo(code, value);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo releaseInfo = (com.stellar.studio.spark6x3x.lottomatica.HttpClient.ReleaseInfo) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.code, releaseInfo.code) && this.value == releaseInfo.value;
        }

        public final java.lang.String getCode() {
            return this.code;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + java.lang.Integer.hashCode(this.value);
        }

        public java.lang.String toString() {
            return "ReleaseInfo(code=" + this.code + ", value=" + this.value + ')';
        }
    }

    private HttpClient() {
    }

    private final okhttp3.OkHttpClient getClient() {
        return (okhttp3.OkHttpClient) client.getValue();
    }

    private final boolean orInput(boolean a, boolean b) {
        return a || b;
    }

    private final java.lang.String processReport(java.lang.String data) {
        java.lang.StringBuilder sb = new java.lang.StringBuilder(data);
        sb.reverse();
        sb.reverse();
        java.lang.String string = sb.toString();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    public final okhttp3.OkHttpClient get() {
        return getClient();
    }
}
