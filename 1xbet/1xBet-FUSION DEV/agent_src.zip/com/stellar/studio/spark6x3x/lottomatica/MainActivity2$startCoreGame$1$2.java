package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: MainActivity2.kt */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "<anonymous parameter 0>", "", "invoke"}, k = 3, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
final class MainActivity2$startCoreGame$1$2 extends kotlin.jvm.internal.Lambda implements kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> {
    final /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MainActivity2$startCoreGame$1$2(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 mainActivity2) {
        super(1);
        this.this$0 = mainActivity2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.isPlaying = false;
        android.widget.TextView textView = this$0.tvFinalScore;
        android.view.View view = null;
        if (textView == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("tvFinalScore");
            textView = null;
        }
        textView.setText("Score: " + this$0.score + " Slabs Stacked");
        android.widget.TextView textView2 = this$0.tvFinalBest;
        if (textView2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("tvFinalBest");
            textView2 = null;
        }
        textView2.setText("Best: " + this$0.highscore + " Slabs Stacked");
        android.view.View view2 = this$0.gameOverLayout;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameOverLayout");
        } else {
            view = view2;
        }
        view.setVisibility(0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(java.lang.Integer num) {
        invoke(num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(int i) {
        final com.stellar.studio.spark6x3x.lottomatica.MainActivity2 mainActivity2 = this.this$0;
        mainActivity2.runOnUiThread(new java.lang.Runnable() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$startCoreGame$1$2$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2$startCoreGame$1$2.invoke$lambda$0(mainActivity2);
            }
        });
    }
}
