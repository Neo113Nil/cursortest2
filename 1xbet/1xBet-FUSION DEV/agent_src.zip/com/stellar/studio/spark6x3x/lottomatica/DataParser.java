package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: DataParser.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\bÆ\u0002\u0018\u00002\u00020\u0001:\u0005\u0013\u0014\u0015\u0016\u0017B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0002J\b\u0010\u0005\u001a\u00020\u0006H\u0002J\b\u0010\u0007\u001a\u00020\u0006H\u0002J\u000e\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u0004J\b\u0010\n\u001a\u00020\u000bH\u0002J\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fJ\u0012\u0010\u0010\u001a\u00020\u00042\b\u0010\u0011\u001a\u0004\u0018\u00010\u0004H\u0002J\b\u0010\u0012\u001a\u00020\u0006H\u0002¨\u0006\u0018"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser;", "", "()V", "buildSidebarString", "", "ensureNavigation", "", "ensureTransform", "isWorkerResponse", "url", "logVersion", "", "parse", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result;", "response", "Lokhttp3/Response;", "safeToken", "value", "validateButton", "EditEvent", "EntryState", "ProtectData", "ReleaseInfo", "Result", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class DataParser {
    public static final com.stellar.studio.spark6x3x.lottomatica.DataParser INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.DataParser();

    /* compiled from: DataParser.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0003\u0006\u0007\b¨\u0006\t"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent;", "", "()V", "Completed", "Failed", "Started", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Started;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static abstract class EditEvent {

        /* compiled from: DataParser.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Completed;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Completed extends com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Completed INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Completed();

            private Completed() {
                super(null);
            }
        }

        /* compiled from: DataParser.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Failed;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent;", "reason", "", "(Ljava/lang/String;)V", "getReason", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Failed extends com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent {
            private final java.lang.String reason;

            /* JADX WARN: Multi-variable type inference failed */
            public Failed() {
                this(null, 1, 0 == true ? 1 : 0);
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Failed(java.lang.String reason) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                this.reason = reason;
            }

            public /* synthetic */ Failed(java.lang.String str, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this((i & 1) != 0 ? "" : str);
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed copy$default(com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed failed, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = failed.reason;
                }
                return failed.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getReason() {
                return this.reason;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed copy(java.lang.String reason) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reason, "reason");
                return new com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed(reason);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed) && kotlin.jvm.internal.Intrinsics.areEqual(this.reason, ((com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Failed) other).reason);
            }

            public final java.lang.String getReason() {
                return this.reason;
            }

            public int hashCode() {
                return this.reason.hashCode();
            }

            public java.lang.String toString() {
                return "Failed(reason=" + this.reason + ')';
            }
        }

        /* compiled from: DataParser.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent$Started;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EditEvent;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Started extends com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent {
            public static final com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Started INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.DataParser.EditEvent.Started();

            private Started() {
                super(null);
            }
        }

        private EditEvent() {
        }

        public /* synthetic */ EditEvent(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    /* compiled from: DataParser.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\r\u001a\u00020\u00032\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$EntryState;", "", "isReady", "", "timestamp", "", "(ZJ)V", "()Z", "getTimestamp", "()J", "component1", "component2", "copy", "equals", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class EntryState {
        private final boolean isReady;
        private final long timestamp;

        public EntryState() {
            this(false, 0L, 3, null);
        }

        public EntryState(boolean z, long j) {
            this.isReady = z;
            this.timestamp = j;
        }

        public /* synthetic */ EntryState(boolean z, long j, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState copy$default(com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState entryState, boolean z, long j, int i, java.lang.Object obj) {
            if ((i & 1) != 0) {
                z = entryState.isReady;
            }
            if ((i & 2) != 0) {
                j = entryState.timestamp;
            }
            return entryState.copy(z, j);
        }

        /* renamed from: component1, reason: from getter */
        public final boolean getIsReady() {
            return this.isReady;
        }

        /* renamed from: component2, reason: from getter */
        public final long getTimestamp() {
            return this.timestamp;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState copy(boolean isReady, long timestamp) {
            return new com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState(isReady, timestamp);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState entryState = (com.stellar.studio.spark6x3x.lottomatica.DataParser.EntryState) other;
            return this.isReady == entryState.isReady && this.timestamp == entryState.timestamp;
        }

        public final long getTimestamp() {
            return this.timestamp;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v1, types: [int] */
        /* JADX WARN: Type inference failed for: r0v4 */
        /* JADX WARN: Type inference failed for: r0v5 */
        public int hashCode() {
            boolean z = this.isReady;
            ?? r0 = z;
            if (z) {
                r0 = 1;
            }
            return (r0 * 31) + java.lang.Long.hashCode(this.timestamp);
        }

        public final boolean isReady() {
            return this.isReady;
        }

        public java.lang.String toString() {
            return "EntryState(isReady=" + this.isReady + ", timestamp=" + this.timestamp + ')';
        }
    }

    /* compiled from: DataParser.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0010\b\u0082\b\u0018\u00002\u00020\u0001B#\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00072\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0017"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$ProtectData;", "", "id", "", "name", "", "active", "", "(ILjava/lang/String;Z)V", "getActive", "()Z", "getId", "()I", "getName", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ProtectData {
        private final boolean active;
        private final int id;
        private final java.lang.String name;

        public ProtectData() {
            this(0, null, false, 7, null);
        }

        public ProtectData(int i, java.lang.String name, boolean z) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(name, "name");
            this.id = i;
            this.name = name;
            this.active = z;
        }

        public /* synthetic */ ProtectData(int i, java.lang.String str, boolean z, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? false : z);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData copy$default(com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData protectData, int i, java.lang.String str, boolean z, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                i = protectData.id;
            }
            if ((i2 & 2) != 0) {
                str = protectData.name;
            }
            if ((i2 & 4) != 0) {
                z = protectData.active;
            }
            return protectData.copy(i, str, z);
        }

        /* renamed from: component1, reason: from getter */
        public final int getId() {
            return this.id;
        }

        /* renamed from: component2, reason: from getter */
        public final java.lang.String getName() {
            return this.name;
        }

        /* renamed from: component3, reason: from getter */
        public final boolean getActive() {
            return this.active;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData copy(int id, java.lang.String name, boolean active) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(name, "name");
            return new com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData(id, name, active);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData protectData = (com.stellar.studio.spark6x3x.lottomatica.DataParser.ProtectData) other;
            return this.id == protectData.id && kotlin.jvm.internal.Intrinsics.areEqual(this.name, protectData.name) && this.active == protectData.active;
        }

        public final boolean getActive() {
            return this.active;
        }

        public final int getId() {
            return this.id;
        }

        public final java.lang.String getName() {
            return this.name;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public int hashCode() {
            int iHashCode = ((java.lang.Integer.hashCode(this.id) * 31) + this.name.hashCode()) * 31;
            boolean z = this.active;
            int i = z;
            if (z != 0) {
                i = 1;
            }
            return iHashCode + i;
        }

        public java.lang.String toString() {
            return "ProtectData(id=" + this.id + ", name=" + this.name + ", active=" + this.active + ')';
        }
    }

    /* compiled from: DataParser.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$ReleaseInfo;", "", "code", "", "value", "", "(Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getValue", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    private static final /* data */ class ReleaseInfo {
        private final java.lang.String code;
        private final int value;

        /* JADX WARN: Multi-variable type inference failed */
        public ReleaseInfo() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }

        public ReleaseInfo(java.lang.String code, int i) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            this.code = code;
            this.value = i;
        }

        public /* synthetic */ ReleaseInfo(java.lang.String str, int i, int i2, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo copy$default(com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo releaseInfo, java.lang.String str, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                str = releaseInfo.code;
            }
            if ((i2 & 2) != 0) {
                i = releaseInfo.value;
            }
            return releaseInfo.copy(str, i);
        }

        /* renamed from: component1, reason: from getter */
        public final java.lang.String getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final int getValue() {
            return this.value;
        }

        public final com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo copy(java.lang.String code, int value) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(code, "code");
            return new com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo(code, value);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo)) {
                return false;
            }
            com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo releaseInfo = (com.stellar.studio.spark6x3x.lottomatica.DataParser.ReleaseInfo) other;
            return kotlin.jvm.internal.Intrinsics.areEqual(this.code, releaseInfo.code) && this.value == releaseInfo.value;
        }

        public final java.lang.String getCode() {
            return this.code;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + java.lang.Integer.hashCode(this.value);
        }

        public java.lang.String toString() {
            return "ReleaseInfo(code=" + this.code + ", value=" + this.value + ')';
        }
    }

    /* compiled from: DataParser.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0002\u0003\u0004B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0002\u0005\u0006¨\u0006\u0007"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result;", "", "()V", "Fallback", "Redirect", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result$Fallback;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result$Redirect;", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
    public static abstract class Result {

        /* compiled from: DataParser.kt */
        @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result$Fallback;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result;", "()V", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final class Fallback extends com.stellar.studio.spark6x3x.lottomatica.DataParser.Result {
            public static final com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Fallback INSTANCE = new com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Fallback();

            private Fallback() {
                super(null);
            }
        }

        /* compiled from: DataParser.kt */
        @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fHÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0010"}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result$Redirect;", "Lcom/stellar/studio/spark6x3x/lottomatica/DataParser$Result;", "url", "", "(Ljava/lang/String;)V", "getUrl", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
        public static final /* data */ class Redirect extends com.stellar.studio.spark6x3x.lottomatica.DataParser.Result {
            private final java.lang.String url;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Redirect(java.lang.String url) {
                super(null);
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
                this.url = url;
            }

            public static /* synthetic */ com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect copy$default(com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect redirect, java.lang.String str, int i, java.lang.Object obj) {
                if ((i & 1) != 0) {
                    str = redirect.url;
                }
                return redirect.copy(str);
            }

            /* renamed from: component1, reason: from getter */
            public final java.lang.String getUrl() {
                return this.url;
            }

            public final com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect copy(java.lang.String url) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
                return new com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect(url);
            }

            public boolean equals(java.lang.Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect) && kotlin.jvm.internal.Intrinsics.areEqual(this.url, ((com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect) other).url);
            }

            public final java.lang.String getUrl() {
                return this.url;
            }

            public int hashCode() {
                return this.url.hashCode();
            }

            public java.lang.String toString() {
                return "Redirect(url=" + this.url + ')';
            }
        }

        private Result() {
        }

        public /* synthetic */ Result(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    private DataParser() {
    }

    private final java.lang.String buildSidebarString() {
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue("Sidebar", "toString(...)");
        return "Sidebar";
    }

    private final boolean ensureNavigation() {
        return true;
    }

    private final boolean ensureTransform() {
        return true;
    }

    private final long logVersion() {
        return java.lang.System.currentTimeMillis();
    }

    private final java.lang.String safeToken(java.lang.String value) {
        return value == null ? "" : value;
    }

    private final boolean validateButton() {
        return true;
    }

    public final boolean isWorkerResponse(java.lang.String url) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(url, "url");
        return com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.INSTANCE.isWorkerUrl(url);
    }

    public final com.stellar.studio.spark6x3x.lottomatica.DataParser.Result parse(okhttp3.Response response) {
        java.lang.String str;
        java.lang.String str2 = "";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(response, "response");
        java.lang.String strHeader$default = okhttp3.Response.header$default(response, "Location", null, 2, null);
        int iCode = response.code();
        if (300 > iCode || iCode >= 400 || (str = strHeader$default) == null || kotlin.text.StringsKt.isBlank(str)) {
            strHeader$default = response.request().url().getUrl();
        }
        try {
            okhttp3.ResponseBody responseBodyBody = response.body();
            if (responseBodyBody != null) {
                java.lang.String strString = responseBodyBody.string();
                if (strString != null) {
                    str2 = strString;
                }
            }
        } catch (java.lang.Exception unused) {
        }
        return !com.stellar.studio.spark6x3x.lottomatica.ConfigUrl.INSTANCE.isWorkerUrl(strHeader$default) ? new com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Redirect(strHeader$default) : kotlin.text.StringsKt.contains$default((java.lang.CharSequence) str2, (java.lang.CharSequence) com.stellar.studio.spark6x3x.lottomatica.Xor.INSTANCE.statusOk(), false, 2, (java.lang.Object) null) ? com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Fallback.INSTANCE : com.stellar.studio.spark6x3x.lottomatica.DataParser.Result.Fallback.INSTANCE;
    }
}
