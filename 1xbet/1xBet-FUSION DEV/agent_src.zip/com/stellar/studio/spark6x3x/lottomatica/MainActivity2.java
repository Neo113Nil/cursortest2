package com.stellar.studio.spark6x3x.lottomatica;

/* compiled from: MainActivity2.kt */
@kotlin.Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010\u0000\n\u0002\b\u000e\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\r\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u001f\u001a\u00020\u00062\u0006\u0010 \u001a\u00020\u0006H\u0002J\u0010\u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020\u0006H\u0002J\u0010\u0010#\u001a\u00020\u000f2\u0006\u0010$\u001a\u00020\u000fH\u0002J\u0018\u0010%\u001a\u00020\u00062\u0006\u0010&\u001a\u00020\u00062\u0006\u0010'\u001a\u00020\u0006H\u0002J\u0010\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\u000fH\u0002J\u0018\u0010+\u001a\u00020)2\u0006\u0010,\u001a\u00020)2\u0006\u0010-\u001a\u00020\u000fH\u0002J\u0010\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020\u000fH\u0002J\u0010\u00101\u001a\u00020\u00062\u0006\u00102\u001a\u00020\u0006H\u0002J\u0010\u00103\u001a\u00020/2\u0006\u00104\u001a\u00020/H\u0002J\u0018\u00105\u001a\u00020\u000f2\u0006\u00106\u001a\u00020\u000f2\u0006\u00107\u001a\u00020\u000fH\u0002J\u0010\u00108\u001a\u00020\u00062\u0006\u00109\u001a\u00020\u000fH\u0002J\u0010\u0010:\u001a\u00020\u00062\u0006\u0010;\u001a\u00020\u0006H\u0002J\b\u0010<\u001a\u00020=H\u0002J\u0010\u0010>\u001a\u00020)2\u0006\u0010,\u001a\u00020)H\u0002J\u0010\u0010?\u001a\u00020\u00062\u0006\u0010@\u001a\u00020\u0006H\u0002J\b\u0010A\u001a\u00020=H\u0002J\u0018\u0010B\u001a\u00020/2\u0006\u0010C\u001a\u00020/2\u0006\u0010D\u001a\u00020/H\u0002J\b\u0010E\u001a\u00020=H\u0016J\u0012\u0010F\u001a\u00020=2\b\u0010G\u001a\u0004\u0018\u00010HH\u0014J\b\u0010I\u001a\u00020=H\u0014J\b\u0010J\u001a\u00020=H\u0014J\b\u0010K\u001a\u00020=H\u0014J\u0018\u0010L\u001a\u00020\u00062\u0006\u0010M\u001a\u00020N2\u0006\u0010O\u001a\u00020\u0006H\u0002J\b\u0010P\u001a\u00020\u0006H\u0002J\b\u0010Q\u001a\u00020=H\u0002J\b\u0010R\u001a\u00020=H\u0002J\u0010\u0010S\u001a\u00020\u00062\u0006\u0010T\u001a\u00020\u0006H\u0002J\u0018\u0010U\u001a\u00020/2\u0006\u0010V\u001a\u00020/2\u0006\u0010W\u001a\u00020/H\u0002J\b\u0010X\u001a\u00020=H\u0002J\u0010\u0010Y\u001a\u00020\u00112\u0006\u0010Z\u001a\u00020NH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000¨\u0006["}, d2 = {"Lcom/stellar/studio/spark6x3x/lottomatica/MainActivity2;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "bonusView", "Landroid/widget/TextView;", "cacheMatrix", "", "gameEngine", "Lcom/stellar/studio/spark6x3x/lottomatica/GameEngineView;", "gameLayout", "Landroid/view/View;", "gameOverLayout", "handler", "Landroid/os/Handler;", "highscore", "", "isPlaying", "", "menuLayout", "pauseLayout", "recordsLayout", "registerSequence", "rulesLayout", "score", "stateEntropy", "syncLock", "", "tvFinalBest", "tvFinalScore", "tvHighscore", "tvScore", "auditRegisters", "cycle", "auditThread", "tid", "balanceCadence", "rate", "blendEntropy", "a", "b", "calculateSpectral", "", "depth", "calculateVariance", "factor", "steps", "calibrateQuantum", "", "shift", "computeBitmask", "source", "deriveCoefficient", "baseline", "deriveThreshold", "cur", androidx.constraintlayout.core.motion.utils.TypedValues.AttributesType.S_TARGET, "evaluatePulse", "vector", "filterSignal", "raw", "initCommonUi", "", "inspectThermal", "modulateFrequency", "clock", "monitorPressure", "normalizeGradient", "dx", "dy", "onBackPressed", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onDestroy", "onPause", "onResume", "probeChecksum", "tag", "", "value", "queryTelemetry", "saveHighscore", "startCoreGame", "syncLatency", "epoch", "transformVector", "x", "y", "updateScore", "verifyBuffer", "seed", "app_release"}, k = 1, mv = {1, 9, 0}, xi = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes.dex */
public final class MainActivity2 extends androidx.appcompat.app.AppCompatActivity {
    private android.widget.TextView bonusView;
    private com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngine;
    private android.view.View gameLayout;
    private android.view.View gameOverLayout;
    private int highscore;
    private boolean isPlaying;
    private android.view.View menuLayout;
    private android.view.View pauseLayout;
    private android.view.View recordsLayout;
    private android.view.View rulesLayout;
    private int score;
    private android.widget.TextView tvFinalBest;
    private android.widget.TextView tvFinalScore;
    private android.widget.TextView tvHighscore;
    private android.widget.TextView tvScore;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile long stateEntropy = java.lang.System.currentTimeMillis();
    private volatile int registerSequence = androidx.appcompat.app.AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY;
    private volatile long cacheMatrix = 64975;
    private final java.lang.Object syncLock = new java.lang.Object();

    private final long auditRegisters(long cycle) {
        long j = 0;
        for (int i = 0; i < 8; i++) {
            j += (cycle >> (i * 4)) & 15;
        }
        this.stateEntropy += j;
        return j;
    }

    private final long auditThread(long tid) {
        long j = (tid ^ this.stateEntropy) & 2147483647L;
        this.registerSequence ^= (int) j;
        return j;
    }

    private final int balanceCadence(int rate) {
        int i = (rate * 41) % androidx.appcompat.app.AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY;
        this.registerSequence = (this.registerSequence + i) & 16383;
        return i;
    }

    private final long blendEntropy(long a, long b) {
        long j = ((a << 7) ^ (b >>> 5)) ^ 41;
        this.stateEntropy ^= j;
        return j;
    }

    private final double calculateSpectral(int depth) {
        double dCos = 1.0d;
        int i = 1;
        if (1 <= depth) {
            while (true) {
                dCos = java.lang.Math.cos(dCos) * java.lang.Math.sin(i * 1.6127d);
                if (i == depth) {
                    break;
                }
                i++;
            }
        }
        this.cacheMatrix ^= java.lang.Double.doubleToLongBits(dCos) & 16777215;
        return dCos;
    }

    private final double calculateVariance(double factor, int steps) {
        int i = 1;
        if (1 <= steps) {
            while (true) {
                factor = (factor * 0.96d) + (java.lang.Math.cos(i) * 0.04d);
                if (i == steps) {
                    break;
                }
                i++;
            }
        }
        this.cacheMatrix ^= java.lang.Double.doubleToLongBits(factor);
        return factor;
    }

    private final float calibrateQuantum(int shift) {
        float f = (((shift & 63) + 1) * 3.141592f) / 41.0f;
        this.stateEntropy ^= java.lang.Float.floatToRawIntBits(f);
        return f;
    }

    private final long computeBitmask(long source) {
        for (int i = 1; i < 10; i++) {
            source = ((source >>> 61) | (source << 3)) ^ 41;
        }
        this.cacheMatrix ^= source;
        return source;
    }

    private final float deriveCoefficient(float baseline) {
        float fSin = (float) ((java.lang.Math.sin(java.lang.Math.toRadians(baseline)) * 100.0d) + 51.0d);
        this.registerSequence += ((int) fSin) & 127;
        return fSin;
    }

    private final int deriveThreshold(int cur, int target) {
        int iAbs = java.lang.Math.abs(cur - target) * 41;
        this.registerSequence = (this.registerSequence + iAbs) & 65535;
        return iAbs;
    }

    private final long evaluatePulse(int vector) {
        long j;
        synchronized (this.syncLock) {
            long j2 = vector;
            long jCurrentTimeMillis = java.lang.System.currentTimeMillis() ^ (j2 << 13);
            for (int i = 1; i < 16; i++) {
                jCurrentTimeMillis = (jCurrentTimeMillis ^ (i * 41)) + j2;
            }
            this.stateEntropy ^= jCurrentTimeMillis;
            this.registerSequence += (int) (jCurrentTimeMillis & 255);
            j = this.stateEntropy;
        }
        return j;
    }

    private final long filterSignal(long raw) {
        long j = (raw & okhttp3.internal.ws.WebSocketProtocol.PAYLOAD_SHORT_MAX) ^ ((281474976645120L & raw) >>> 16);
        this.registerSequence += (int) (127 & j);
        return j;
    }

    private final void initCommonUi() {
        this.highscore = getSharedPreferences("AppPrefs", 0).getInt("highscore", 0);
        android.view.View viewFindViewById = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.menuLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(...)");
        this.menuLayout = viewFindViewById;
        android.view.View viewFindViewById2 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.rulesLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById2, "findViewById(...)");
        this.rulesLayout = viewFindViewById2;
        android.view.View viewFindViewById3 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.recordsLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById3, "findViewById(...)");
        this.recordsLayout = viewFindViewById3;
        android.view.View viewFindViewById4 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.gameLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById4, "findViewById(...)");
        this.gameLayout = viewFindViewById4;
        android.view.View viewFindViewById5 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.pauseLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById5, "findViewById(...)");
        this.pauseLayout = viewFindViewById5;
        android.view.View viewFindViewById6 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.gameOverLayout);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById6, "findViewById(...)");
        this.gameOverLayout = viewFindViewById6;
        android.view.View viewFindViewById7 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.tvScore);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById7, "findViewById(...)");
        this.tvScore = (android.widget.TextView) viewFindViewById7;
        android.view.View viewFindViewById8 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.tvHighscore);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById8, "findViewById(...)");
        this.tvHighscore = (android.widget.TextView) viewFindViewById8;
        android.view.View viewFindViewById9 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.tvFinalScore);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById9, "findViewById(...)");
        this.tvFinalScore = (android.widget.TextView) viewFindViewById9;
        android.view.View viewFindViewById10 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.tvFinalBest);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById10, "findViewById(...)");
        this.tvFinalBest = (android.widget.TextView) viewFindViewById10;
        android.view.View viewFindViewById11 = findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.bonusView);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(viewFindViewById11, "findViewById(...)");
        this.bonusView = (android.widget.TextView) viewFindViewById11;
        blendEntropy(this.stateEntropy, this.highscore);
        normalizeGradient(10.5f, 20.2f);
        deriveThreshold(this.score, this.highscore);
        queryTelemetry();
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnPlay)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$1(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnRules)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$2(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnBackFromRules)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$3(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnRecords)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$4(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnBackFromRecords)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$5(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnPause)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$6(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnResume)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$7(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnQuit)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$8(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnPlayAgain)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$9(this.f$0, view);
            }
        });
        ((android.widget.Button) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.btnMenuFromGameOver)).setOnClickListener(new android.view.View.OnClickListener() { // from class: com.stellar.studio.spark6x3x.lottomatica.MainActivity2$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view) {
                com.stellar.studio.spark6x3x.lottomatica.MainActivity2.initCommonUi$lambda$10(this.f$0, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$1(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.performHapticFeedback(1);
        android.view.View view2 = this$0.menuLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.gameLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameLayout");
        } else {
            view3 = view4;
        }
        view3.setVisibility(0);
        this$0.startCoreGame();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$10(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.performHapticFeedback(1);
        android.view.View view2 = this$0.gameOverLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameOverLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.gameLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameLayout");
            view4 = null;
        }
        view4.setVisibility(8);
        android.view.View view5 = this$0.menuLayout;
        if (view5 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
        } else {
            view3 = view5;
        }
        view3.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$2(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.performHapticFeedback(1);
        android.view.View view2 = this$0.menuLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.rulesLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("rulesLayout");
        } else {
            view3 = view4;
        }
        view3.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$3(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        android.view.View view2 = this$0.rulesLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("rulesLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.menuLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
        } else {
            view3 = view4;
        }
        view3.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$4(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.performHapticFeedback(1);
        android.view.View view2 = this$0.menuLayout;
        android.widget.TextView textView = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view3 = this$0.recordsLayout;
        if (view3 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("recordsLayout");
            view3 = null;
        }
        view3.setVisibility(0);
        android.widget.TextView textView2 = this$0.tvHighscore;
        if (textView2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("tvHighscore");
        } else {
            textView = textView2;
        }
        textView.setText("Best: " + this$0.highscore + " Slabs Stacked");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$5(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        android.view.View view2 = this$0.recordsLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("recordsLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.menuLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
        } else {
            view3 = view4;
        }
        view3.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$6(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.isPlaying = false;
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this$0.gameEngine;
        if (gameEngineView != null) {
            gameEngineView.setRunning(false);
        }
        android.view.View view2 = this$0.pauseLayout;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
            view2 = null;
        }
        view2.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$7(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        android.view.View view2 = this$0.pauseLayout;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        this$0.isPlaying = true;
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this$0.gameEngine;
        if (gameEngineView == null) {
            return;
        }
        gameEngineView.setRunning(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$8(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.isPlaying = false;
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this$0.gameEngine;
        if (gameEngineView != null) {
            gameEngineView.setRunning(false);
        }
        android.view.View view2 = this$0.pauseLayout;
        android.view.View view3 = null;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        android.view.View view4 = this$0.gameLayout;
        if (view4 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameLayout");
            view4 = null;
        }
        view4.setVisibility(8);
        android.view.View view5 = this$0.menuLayout;
        if (view5 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
        } else {
            view3 = view5;
        }
        view3.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void initCommonUi$lambda$9(com.stellar.studio.spark6x3x.lottomatica.MainActivity2 this$0, android.view.View view) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.performHapticFeedback(1);
        android.view.View view2 = this$0.gameOverLayout;
        if (view2 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameOverLayout");
            view2 = null;
        }
        view2.setVisibility(8);
        this$0.startCoreGame();
    }

    private final double inspectThermal(double factor) {
        double dSqrt = java.lang.Math.sqrt(java.lang.Math.abs(factor) + 1.0d) * 1.6127d;
        this.stateEntropy ^= java.lang.Double.doubleToLongBits(dSqrt);
        return dSqrt;
    }

    private final long modulateFrequency(long clock) {
        long j = (clock >>> 13) ^ (41 * clock);
        this.stateEntropy = (this.stateEntropy + j) ^ 109;
        return j;
    }

    private final void monitorPressure() {
        java.lang.Runtime runtime = java.lang.Runtime.getRuntime();
        this.stateEntropy ^= runtime.totalMemory() - runtime.freeMemory();
    }

    private final float normalizeGradient(float dx, float dy) {
        float fSqrt = (float) java.lang.Math.sqrt((dx * dx) + (dy * dy));
        this.cacheMatrix ^= java.lang.Float.floatToRawIntBits(fSqrt);
        return fSqrt;
    }

    private final long probeChecksum(java.lang.String tag, long value) {
        long jHashCode = value ^ tag.hashCode();
        for (int i = 0; i < tag.length(); i++) {
            jHashCode = (jHashCode * 109) + tag.charAt(i);
        }
        this.cacheMatrix += okhttp3.internal.ws.WebSocketProtocol.PAYLOAD_SHORT_MAX & jHashCode;
        return jHashCode;
    }

    private final long queryTelemetry() {
        return (this.stateEntropy ^ this.cacheMatrix) + this.registerSequence;
    }

    private final void saveHighscore() {
        getSharedPreferences("AppPrefs", 0).edit().putInt("highscore", this.highscore).apply();
    }

    private final void startCoreGame() {
        this.score = 0;
        updateScore();
        this.isPlaying = true;
        android.widget.FrameLayout frameLayout = (android.widget.FrameLayout) findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.gameCanvasContainer);
        frameLayout.removeAllViews();
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = new com.stellar.studio.spark6x3x.lottomatica.GameEngineView(this);
        gameEngineView.setOnScoreAdded(new com.stellar.studio.spark6x3x.lottomatica.MainActivity2$startCoreGame$1$1(this));
        gameEngineView.setOnGameOver(new com.stellar.studio.spark6x3x.lottomatica.MainActivity2$startCoreGame$1$2(this));
        this.gameEngine = gameEngineView;
        frameLayout.addView(gameEngineView);
    }

    private final long syncLatency(long epoch) {
        long jCurrentTimeMillis = okhttp3.internal.ws.WebSocketProtocol.PAYLOAD_SHORT_MAX & (java.lang.System.currentTimeMillis() - epoch);
        this.registerSequence = (this.registerSequence ^ ((int) jCurrentTimeMillis)) + 3;
        return jCurrentTimeMillis;
    }

    private final float transformVector(float x, float y) {
        float fHypot = (((float) java.lang.Math.hypot(x, y)) * 1.6127f) + (x * 0.5f);
        this.registerSequence = (this.registerSequence ^ java.lang.Float.floatToRawIntBits(fHypot)) & 32767;
        return fHypot;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateScore() {
        android.widget.TextView textView = this.tvScore;
        if (textView == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("tvScore");
            textView = null;
        }
        textView.setText("🏢 " + this.score);
        int i = this.score;
        if (i > this.highscore) {
            this.highscore = i;
            saveHighscore();
        }
    }

    private final boolean verifyBuffer(java.lang.String seed) {
        int iHashCode = seed.hashCode();
        boolean z = (Integer.MAX_VALUE & iHashCode) > 0;
        int length = seed.length();
        for (int i = 0; i < length; i++) {
            iHashCode = (iHashCode * 41) ^ seed.charAt(i);
        }
        this.registerSequence ^= iHashCode & 65535;
        return z;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        android.view.View view = this.rulesLayout;
        android.view.View view2 = null;
        if (view == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("rulesLayout");
            view = null;
        }
        if (view.getVisibility() != 0) {
            android.view.View view3 = this.recordsLayout;
            if (view3 == null) {
                kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("recordsLayout");
                view3 = null;
            }
            if (view3.getVisibility() != 0) {
                android.view.View view4 = this.gameOverLayout;
                if (view4 == null) {
                    kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameOverLayout");
                    view4 = null;
                }
                if (view4.getVisibility() == 0) {
                    android.view.View view5 = this.gameOverLayout;
                    if (view5 == null) {
                        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameOverLayout");
                        view5 = null;
                    }
                    view5.setVisibility(8);
                    android.view.View view6 = this.gameLayout;
                    if (view6 == null) {
                        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameLayout");
                        view6 = null;
                    }
                    view6.setVisibility(8);
                    android.view.View view7 = this.menuLayout;
                    if (view7 == null) {
                        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
                    } else {
                        view2 = view7;
                    }
                    view2.setVisibility(0);
                    return;
                }
                android.view.View view8 = this.pauseLayout;
                if (view8 == null) {
                    kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
                    view8 = null;
                }
                if (view8.getVisibility() == 0) {
                    android.view.View view9 = this.pauseLayout;
                    if (view9 == null) {
                        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
                    } else {
                        view2 = view9;
                    }
                    view2.setVisibility(8);
                    this.isPlaying = true;
                    com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this.gameEngine;
                    if (gameEngineView == null) {
                        return;
                    }
                    gameEngineView.setRunning(true);
                    return;
                }
                android.view.View view10 = this.gameLayout;
                if (view10 == null) {
                    kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("gameLayout");
                    view10 = null;
                }
                if (view10.getVisibility() != 0) {
                    java.lang.String packageName = getPackageName();
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(packageName, "getPackageName(...)");
                    probeChecksum(packageName, this.cacheMatrix);
                    transformVector(this.score, this.highscore);
                    super.onBackPressed();
                    return;
                }
                this.isPlaying = false;
                com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView2 = this.gameEngine;
                if (gameEngineView2 != null) {
                    gameEngineView2.setRunning(false);
                }
                android.view.View view11 = this.pauseLayout;
                if (view11 == null) {
                    kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("pauseLayout");
                } else {
                    view2 = view11;
                }
                view2.setVisibility(0);
                return;
            }
        }
        android.view.View view12 = this.rulesLayout;
        if (view12 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("rulesLayout");
            view12 = null;
        }
        view12.setVisibility(8);
        android.view.View view13 = this.recordsLayout;
        if (view13 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("recordsLayout");
            view13 = null;
        }
        view13.setVisibility(8);
        android.view.View view14 = this.menuLayout;
        if (view14 == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
        } else {
            view2 = view14;
        }
        view2.setVisibility(0);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.stellar.studio.spark6x3x.lottomatica.R.layout.activity_main);
        evaluatePulse(this.score + 7);
        java.lang.String packageName = getPackageName();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(packageName, "getPackageName(...)");
        verifyBuffer(packageName);
        calculateSpectral(4);
        monitorPressure();
        calibrateQuantum(this.score);
        calculateVariance(1.25d, 4);
        findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.splashLayout).setVisibility(8);
        findViewById(com.stellar.studio.spark6x3x.lottomatica.R.id.overlayWebView).setVisibility(8);
        initCommonUi();
        android.view.View view = this.menuLayout;
        if (view == null) {
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("menuLayout");
            view = null;
        }
        view.setVisibility(0);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.isPlaying = false;
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this.gameEngine;
        if (gameEngineView != null) {
            gameEngineView.setRunning(false);
        }
        this.handler.removeCallbacksAndMessages(null);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        this.isPlaying = false;
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView = this.gameEngine;
        if (gameEngineView != null) {
            gameEngineView.setRunning(false);
        }
        this.handler.removeCallbacksAndMessages(null);
        deriveCoefficient(this.score);
        computeBitmask(this.stateEntropy);
        balanceCadence(this.score + 1);
        filterSignal(this.cacheMatrix);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        com.stellar.studio.spark6x3x.lottomatica.GameEngineView gameEngineView;
        super.onResume();
        syncLatency(this.stateEntropy);
        auditRegisters(java.lang.System.currentTimeMillis());
        inspectThermal(this.score);
        modulateFrequency(java.lang.System.currentTimeMillis());
        auditThread(java.lang.Thread.currentThread().getId());
        if (!this.isPlaying || (gameEngineView = this.gameEngine) == null) {
            return;
        }
        gameEngineView.setRunning(true);
    }
}
