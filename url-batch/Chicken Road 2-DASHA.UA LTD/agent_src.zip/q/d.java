package q;

/* loaded from: classes.dex */
public interface d {
}
