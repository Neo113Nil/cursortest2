package W;

/* loaded from: classes.dex */
public final class e implements h {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ e f393b = new e();
}
