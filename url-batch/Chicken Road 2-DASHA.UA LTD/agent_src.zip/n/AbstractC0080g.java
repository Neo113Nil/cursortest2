package n;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Executor;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;

/* renamed from: n.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0080g {

    /* renamed from: a, reason: collision with root package name */
    public static final B.b f1055a = new B.b(9);

    /* renamed from: b, reason: collision with root package name */
    public static final byte[] f1056b = {112, 114, 111, 0};

    /* renamed from: c, reason: collision with root package name */
    public static final byte[] f1057c = {112, 114, 109, 0};

    /* renamed from: d, reason: collision with root package name */
    public static final byte[] f1058d = {48, 49, 53, 0};

    /* renamed from: e, reason: collision with root package name */
    public static final byte[] f1059e = {48, 49, 48, 0};

    /* renamed from: f, reason: collision with root package name */
    public static final byte[] f1060f = {48, 48, 57, 0};

    /* renamed from: g, reason: collision with root package name */
    public static final byte[] f1061g = {48, 48, 53, 0};

    /* renamed from: h, reason: collision with root package name */
    public static final byte[] f1062h = {48, 48, 49, 0};

    /* renamed from: i, reason: collision with root package name */
    public static final byte[] f1063i = {48, 48, 49, 0};

    /* renamed from: j, reason: collision with root package name */
    public static final byte[] f1064j = {48, 48, 50, 0};

    public static byte[] a(byte[] bArr) {
        Deflater deflater = new Deflater(1);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, deflater);
            try {
                deflaterOutputStream.write(bArr);
                deflaterOutputStream.close();
                deflater.end();
                return byteArrayOutputStream.toByteArray();
            } finally {
            }
        } catch (Throwable th) {
            deflater.end();
            throw th;
        }
    }

    public static byte[] b(C0076c[] c0076cArr, byte[] bArr) {
        int i2 = 0;
        for (C0076c c0076c : c0076cArr) {
            i2 += ((((c0076c.f1051g * 2) + 7) & (-8)) / 8) + (c0076c.f1049e * 2) + d(c0076c.f1045a, c0076c.f1046b, bArr).getBytes(StandardCharsets.UTF_8).length + 16 + c0076c.f1050f;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(i2);
        if (Arrays.equals(bArr, f1060f)) {
            for (C0076c c0076c2 : c0076cArr) {
                p(byteArrayOutputStream, c0076c2, d(c0076c2.f1045a, c0076c2.f1046b, bArr));
                r(byteArrayOutputStream, c0076c2);
                int[] iArr = c0076c2.f1052h;
                int length = iArr.length;
                int i3 = 0;
                int i4 = 0;
                while (i3 < length) {
                    int i5 = iArr[i3];
                    u(byteArrayOutputStream, i5 - i4);
                    i3++;
                    i4 = i5;
                }
                q(byteArrayOutputStream, c0076c2);
            }
        } else {
            for (C0076c c0076c3 : c0076cArr) {
                p(byteArrayOutputStream, c0076c3, d(c0076c3.f1045a, c0076c3.f1046b, bArr));
            }
            for (C0076c c0076c4 : c0076cArr) {
                r(byteArrayOutputStream, c0076c4);
                int[] iArr2 = c0076c4.f1052h;
                int length2 = iArr2.length;
                int i6 = 0;
                int i7 = 0;
                while (i6 < length2) {
                    int i8 = iArr2[i6];
                    u(byteArrayOutputStream, i8 - i7);
                    i6++;
                    i7 = i8;
                }
                q(byteArrayOutputStream, c0076c4);
            }
        }
        if (byteArrayOutputStream.size() == i2) {
            return byteArrayOutputStream.toByteArray();
        }
        throw new IllegalStateException("The bytes saved do not match expectation. actual=" + byteArrayOutputStream.size() + " expected=" + i2);
    }

    public static boolean c(File file) {
        if (!file.isDirectory()) {
            file.delete();
            return true;
        }
        File[] listFiles = file.listFiles();
        if (listFiles == null) {
            return false;
        }
        boolean z2 = true;
        for (File file2 : listFiles) {
            z2 = c(file2) && z2;
        }
        return z2;
    }

    public static String d(String str, String str2, byte[] bArr) {
        byte[] bArr2 = f1062h;
        boolean equals = Arrays.equals(bArr, bArr2);
        byte[] bArr3 = f1061g;
        String str3 = (equals || Arrays.equals(bArr, bArr3)) ? ":" : "!";
        if (str.length() <= 0) {
            return "!".equals(str3) ? str2.replace(":", "!") : ":".equals(str3) ? str2.replace("!", ":") : str2;
        }
        if (str2.equals("classes.dex")) {
            return str;
        }
        if (str2.contains("!") || str2.contains(":")) {
            return "!".equals(str3) ? str2.replace(":", "!") : ":".equals(str3) ? str2.replace("!", ":") : str2;
        }
        if (str2.endsWith(".apk")) {
            return str2;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append((Arrays.equals(bArr, bArr2) || Arrays.equals(bArr, bArr3)) ? ":" : "!");
        sb.append(str2);
        return sb.toString();
    }

    public static void e(PackageInfo packageInfo, File file) {
        try {
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(new File(file, "profileinstaller_profileWrittenFor_lastUpdateTime.dat")));
            try {
                dataOutputStream.writeLong(packageInfo.lastUpdateTime);
                dataOutputStream.close();
            } finally {
            }
        } catch (IOException unused) {
        }
    }

    public static byte[] f(InputStream inputStream, int i2) {
        byte[] bArr = new byte[i2];
        int i3 = 0;
        while (i3 < i2) {
            int read = inputStream.read(bArr, i3, i2 - i3);
            if (read < 0) {
                throw new IllegalStateException("Not enough bytes to read: " + i2);
            }
            i3 += read;
        }
        return bArr;
    }

    public static int[] g(ByteArrayInputStream byteArrayInputStream, int i2) {
        int[] iArr = new int[i2];
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += (int) m(byteArrayInputStream, 2);
            iArr[i4] = i3;
        }
        return iArr;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x005d, code lost:
    
        if (r0.finished() == false) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0062, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x006a, code lost:
    
        throw new java.lang.IllegalStateException("Inflater did not finish");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static byte[] h(FileInputStream fileInputStream, int i2, int i3) {
        Inflater inflater = new Inflater();
        try {
            byte[] bArr = new byte[i3];
            byte[] bArr2 = new byte[2048];
            int i4 = 0;
            int i5 = 0;
            while (!inflater.finished() && !inflater.needsDictionary() && i4 < i2) {
                int read = fileInputStream.read(bArr2);
                if (read < 0) {
                    throw new IllegalStateException("Invalid zip data. Stream ended after $totalBytesRead bytes. Expected " + i2 + " bytes");
                }
                inflater.setInput(bArr2, 0, read);
                try {
                    i5 += inflater.inflate(bArr, i5, i3 - i5);
                    i4 += read;
                } catch (DataFormatException e2) {
                    throw new IllegalStateException(e2.getMessage());
                }
            }
            throw new IllegalStateException("Didn't read enough bytes during decompression. expected=" + i2 + " actual=" + i4);
        } finally {
            inflater.end();
        }
    }

    public static C0076c[] i(FileInputStream fileInputStream, byte[] bArr, byte[] bArr2, C0076c[] c0076cArr) {
        byte[] bArr3 = f1063i;
        if (!Arrays.equals(bArr, bArr3)) {
            if (!Arrays.equals(bArr, f1064j)) {
                throw new IllegalStateException("Unsupported meta version");
            }
            int m2 = (int) m(fileInputStream, 2);
            byte[] h2 = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
            if (fileInputStream.read() > 0) {
                throw new IllegalStateException("Content found after the end of file");
            }
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(h2);
            try {
                C0076c[] k2 = k(byteArrayInputStream, bArr2, m2, c0076cArr);
                byteArrayInputStream.close();
                return k2;
            } catch (Throwable th) {
                try {
                    byteArrayInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
        if (Arrays.equals(f1058d, bArr2)) {
            throw new IllegalStateException("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
        }
        if (!Arrays.equals(bArr, bArr3)) {
            throw new IllegalStateException("Unsupported meta version");
        }
        int m3 = (int) m(fileInputStream, 1);
        byte[] h3 = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(h3);
        try {
            C0076c[] j2 = j(byteArrayInputStream2, m3, c0076cArr);
            byteArrayInputStream2.close();
            return j2;
        } catch (Throwable th3) {
            try {
                byteArrayInputStream2.close();
            } catch (Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    public static C0076c[] j(ByteArrayInputStream byteArrayInputStream, int i2, C0076c[] c0076cArr) {
        if (byteArrayInputStream.available() == 0) {
            return new C0076c[0];
        }
        if (i2 != c0076cArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        String[] strArr = new String[i2];
        int[] iArr = new int[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            int m2 = (int) m(byteArrayInputStream, 2);
            iArr[i3] = (int) m(byteArrayInputStream, 2);
            strArr[i3] = new String(f(byteArrayInputStream, m2), StandardCharsets.UTF_8);
        }
        for (int i4 = 0; i4 < i2; i4++) {
            C0076c c0076c = c0076cArr[i4];
            if (!c0076c.f1046b.equals(strArr[i4])) {
                throw new IllegalStateException("Order of dexfiles in metadata did not match baseline");
            }
            int i5 = iArr[i4];
            c0076c.f1049e = i5;
            c0076c.f1052h = g(byteArrayInputStream, i5);
        }
        return c0076cArr;
    }

    public static C0076c[] k(ByteArrayInputStream byteArrayInputStream, byte[] bArr, int i2, C0076c[] c0076cArr) {
        if (byteArrayInputStream.available() == 0) {
            return new C0076c[0];
        }
        if (i2 != c0076cArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        for (int i3 = 0; i3 < i2; i3++) {
            m(byteArrayInputStream, 2);
            String str = new String(f(byteArrayInputStream, (int) m(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
            long m2 = m(byteArrayInputStream, 4);
            int m3 = (int) m(byteArrayInputStream, 2);
            C0076c c0076c = null;
            if (c0076cArr.length > 0) {
                int indexOf = str.indexOf("!");
                if (indexOf < 0) {
                    indexOf = str.indexOf(":");
                }
                String substring = indexOf > 0 ? str.substring(indexOf + 1) : str;
                int i4 = 0;
                while (true) {
                    if (i4 >= c0076cArr.length) {
                        break;
                    }
                    if (c0076cArr[i4].f1046b.equals(substring)) {
                        c0076c = c0076cArr[i4];
                        break;
                    }
                    i4++;
                }
            }
            if (c0076c == null) {
                throw new IllegalStateException("Missing profile key: ".concat(str));
            }
            c0076c.f1048d = m2;
            int[] g2 = g(byteArrayInputStream, m3);
            if (Arrays.equals(bArr, f1062h)) {
                c0076c.f1049e = m3;
                c0076c.f1052h = g2;
            }
        }
        return c0076cArr;
    }

    public static C0076c[] l(FileInputStream fileInputStream, byte[] bArr, String str) {
        if (!Arrays.equals(bArr, f1059e)) {
            throw new IllegalStateException("Unsupported version");
        }
        int m2 = (int) m(fileInputStream, 1);
        byte[] h2 = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(h2);
        try {
            C0076c[] n2 = n(byteArrayInputStream, str, m2);
            byteArrayInputStream.close();
            return n2;
        } catch (Throwable th) {
            try {
                byteArrayInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static long m(InputStream inputStream, int i2) {
        byte[] f2 = f(inputStream, i2);
        long j2 = 0;
        for (int i3 = 0; i3 < i2; i3++) {
            j2 += (f2[i3] & 255) << (i3 * 8);
        }
        return j2;
    }

    public static C0076c[] n(ByteArrayInputStream byteArrayInputStream, String str, int i2) {
        TreeMap treeMap;
        if (byteArrayInputStream.available() == 0) {
            return new C0076c[0];
        }
        C0076c[] c0076cArr = new C0076c[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            int m2 = (int) m(byteArrayInputStream, 2);
            int m3 = (int) m(byteArrayInputStream, 2);
            c0076cArr[i3] = new C0076c(str, new String(f(byteArrayInputStream, m2), StandardCharsets.UTF_8), m(byteArrayInputStream, 4), m3, (int) m(byteArrayInputStream, 4), (int) m(byteArrayInputStream, 4), new int[m3], new TreeMap());
        }
        for (int i4 = 0; i4 < i2; i4++) {
            C0076c c0076c = c0076cArr[i4];
            int available = byteArrayInputStream.available() - c0076c.f1050f;
            int i5 = 0;
            while (true) {
                int available2 = byteArrayInputStream.available();
                treeMap = c0076c.f1053i;
                if (available2 <= available) {
                    break;
                }
                i5 += (int) m(byteArrayInputStream, 2);
                treeMap.put(Integer.valueOf(i5), 1);
                for (int m4 = (int) m(byteArrayInputStream, 2); m4 > 0; m4--) {
                    m(byteArrayInputStream, 2);
                    int m5 = (int) m(byteArrayInputStream, 1);
                    if (m5 != 6 && m5 != 7) {
                        while (m5 > 0) {
                            m(byteArrayInputStream, 1);
                            for (int m6 = (int) m(byteArrayInputStream, 1); m6 > 0; m6--) {
                                m(byteArrayInputStream, 2);
                            }
                            m5--;
                        }
                    }
                }
            }
            if (byteArrayInputStream.available() != available) {
                throw new IllegalStateException("Read too much data during profile line parse");
            }
            c0076c.f1052h = g(byteArrayInputStream, c0076c.f1049e);
            int i6 = c0076c.f1051g;
            BitSet valueOf = BitSet.valueOf(f(byteArrayInputStream, (((i6 * 2) + 7) & (-8)) / 8));
            for (int i7 = 0; i7 < i6; i7++) {
                int i8 = valueOf.get(i7) ? 2 : 0;
                if (valueOf.get(i7 + i6)) {
                    i8 |= 4;
                }
                if (i8 != 0) {
                    Integer num = (Integer) treeMap.get(Integer.valueOf(i7));
                    if (num == null) {
                        num = 0;
                    }
                    treeMap.put(Integer.valueOf(i7), Integer.valueOf(i8 | num.intValue()));
                }
            }
        }
        return c0076cArr;
    }

    /* JADX WARN: Finally extract failed */
    public static boolean o(ByteArrayOutputStream byteArrayOutputStream, byte[] bArr, C0076c[] c0076cArr) {
        long j2;
        ArrayList arrayList;
        int length;
        byte[] bArr2 = f1058d;
        int i2 = 0;
        if (!Arrays.equals(bArr, bArr2)) {
            byte[] bArr3 = f1059e;
            if (Arrays.equals(bArr, bArr3)) {
                byte[] b2 = b(c0076cArr, bArr3);
                t(byteArrayOutputStream, c0076cArr.length, 1);
                t(byteArrayOutputStream, b2.length, 4);
                byte[] a2 = a(b2);
                t(byteArrayOutputStream, a2.length, 4);
                byteArrayOutputStream.write(a2);
                return true;
            }
            byte[] bArr4 = f1061g;
            if (Arrays.equals(bArr, bArr4)) {
                t(byteArrayOutputStream, c0076cArr.length, 1);
                for (C0076c c0076c : c0076cArr) {
                    int size = c0076c.f1053i.size() * 4;
                    String d2 = d(c0076c.f1045a, c0076c.f1046b, bArr4);
                    Charset charset = StandardCharsets.UTF_8;
                    u(byteArrayOutputStream, d2.getBytes(charset).length);
                    u(byteArrayOutputStream, c0076c.f1052h.length);
                    t(byteArrayOutputStream, size, 4);
                    t(byteArrayOutputStream, c0076c.f1047c, 4);
                    byteArrayOutputStream.write(d2.getBytes(charset));
                    Iterator it = c0076c.f1053i.keySet().iterator();
                    while (it.hasNext()) {
                        u(byteArrayOutputStream, ((Integer) it.next()).intValue());
                        u(byteArrayOutputStream, 0);
                    }
                    for (int i3 : c0076c.f1052h) {
                        u(byteArrayOutputStream, i3);
                    }
                }
                return true;
            }
            byte[] bArr5 = f1060f;
            if (Arrays.equals(bArr, bArr5)) {
                byte[] b3 = b(c0076cArr, bArr5);
                t(byteArrayOutputStream, c0076cArr.length, 1);
                t(byteArrayOutputStream, b3.length, 4);
                byte[] a3 = a(b3);
                t(byteArrayOutputStream, a3.length, 4);
                byteArrayOutputStream.write(a3);
                return true;
            }
            byte[] bArr6 = f1062h;
            if (!Arrays.equals(bArr, bArr6)) {
                return false;
            }
            u(byteArrayOutputStream, c0076cArr.length);
            for (C0076c c0076c2 : c0076cArr) {
                String d3 = d(c0076c2.f1045a, c0076c2.f1046b, bArr6);
                Charset charset2 = StandardCharsets.UTF_8;
                u(byteArrayOutputStream, d3.getBytes(charset2).length);
                TreeMap treeMap = c0076c2.f1053i;
                u(byteArrayOutputStream, treeMap.size());
                u(byteArrayOutputStream, c0076c2.f1052h.length);
                t(byteArrayOutputStream, c0076c2.f1047c, 4);
                byteArrayOutputStream.write(d3.getBytes(charset2));
                Iterator it2 = treeMap.keySet().iterator();
                while (it2.hasNext()) {
                    u(byteArrayOutputStream, ((Integer) it2.next()).intValue());
                }
                for (int i4 : c0076c2.f1052h) {
                    u(byteArrayOutputStream, i4);
                }
            }
            return true;
        }
        ArrayList arrayList2 = new ArrayList(3);
        ArrayList arrayList3 = new ArrayList(3);
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        try {
            u(byteArrayOutputStream2, c0076cArr.length);
            int i5 = 2;
            int i6 = 2;
            for (C0076c c0076c3 : c0076cArr) {
                t(byteArrayOutputStream2, c0076c3.f1047c, 4);
                t(byteArrayOutputStream2, c0076c3.f1048d, 4);
                t(byteArrayOutputStream2, c0076c3.f1051g, 4);
                String d4 = d(c0076c3.f1045a, c0076c3.f1046b, bArr2);
                Charset charset3 = StandardCharsets.UTF_8;
                int length2 = d4.getBytes(charset3).length;
                u(byteArrayOutputStream2, length2);
                i6 = i6 + 14 + length2;
                byteArrayOutputStream2.write(d4.getBytes(charset3));
            }
            byte[] byteArray = byteArrayOutputStream2.toByteArray();
            if (i6 != byteArray.length) {
                throw new IllegalStateException("Expected size " + i6 + ", does not match actual size " + byteArray.length);
            }
            q qVar = new q(1, byteArray, false);
            byteArrayOutputStream2.close();
            arrayList2.add(qVar);
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            int i7 = 0;
            int i8 = 0;
            while (i7 < c0076cArr.length) {
                try {
                    C0076c c0076c4 = c0076cArr[i7];
                    u(byteArrayOutputStream3, i7);
                    u(byteArrayOutputStream3, c0076c4.f1049e);
                    i8 = i8 + 4 + (c0076c4.f1049e * 2);
                    int[] iArr = c0076c4.f1052h;
                    int length3 = iArr.length;
                    int i9 = i2;
                    while (i2 < length3) {
                        int i10 = iArr[i2];
                        u(byteArrayOutputStream3, i10 - i9);
                        i2++;
                        i9 = i10;
                    }
                    i7++;
                    i2 = 0;
                } catch (Throwable th) {
                }
            }
            byte[] byteArray2 = byteArrayOutputStream3.toByteArray();
            if (i8 != byteArray2.length) {
                throw new IllegalStateException("Expected size " + i8 + ", does not match actual size " + byteArray2.length);
            }
            q qVar2 = new q(3, byteArray2, true);
            byteArrayOutputStream3.close();
            arrayList2.add(qVar2);
            byteArrayOutputStream3 = new ByteArrayOutputStream();
            int i11 = 0;
            int i12 = 0;
            while (i11 < c0076cArr.length) {
                try {
                    C0076c c0076c5 = c0076cArr[i11];
                    Iterator it3 = c0076c5.f1053i.entrySet().iterator();
                    int i13 = 0;
                    while (it3.hasNext()) {
                        i13 |= ((Integer) ((Map.Entry) it3.next()).getValue()).intValue();
                    }
                    ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
                    try {
                        q(byteArrayOutputStream4, c0076c5);
                        byte[] byteArray3 = byteArrayOutputStream4.toByteArray();
                        byteArrayOutputStream4.close();
                        byteArrayOutputStream4 = new ByteArrayOutputStream();
                        try {
                            r(byteArrayOutputStream4, c0076c5);
                            byte[] byteArray4 = byteArrayOutputStream4.toByteArray();
                            byteArrayOutputStream4.close();
                            u(byteArrayOutputStream3, i11);
                            int length4 = byteArray3.length + i5 + byteArray4.length;
                            int i14 = i12 + 6;
                            ArrayList arrayList4 = arrayList3;
                            t(byteArrayOutputStream3, length4, 4);
                            u(byteArrayOutputStream3, i13);
                            byteArrayOutputStream3.write(byteArray3);
                            byteArrayOutputStream3.write(byteArray4);
                            i12 = i14 + length4;
                            i11++;
                            arrayList3 = arrayList4;
                            i5 = 2;
                        } finally {
                        }
                    } finally {
                    }
                } finally {
                    try {
                        byteArrayOutputStream3.close();
                        throw th;
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
            }
            ArrayList arrayList5 = arrayList3;
            byte[] byteArray5 = byteArrayOutputStream3.toByteArray();
            if (i12 != byteArray5.length) {
                throw new IllegalStateException("Expected size " + i12 + ", does not match actual size " + byteArray5.length);
            }
            q qVar3 = new q(4, byteArray5, true);
            byteArrayOutputStream3.close();
            arrayList2.add(qVar3);
            long j3 = 4;
            long size2 = j3 + j3 + 4 + (arrayList2.size() * 16);
            t(byteArrayOutputStream, arrayList2.size(), 4);
            int i15 = 0;
            while (i15 < arrayList2.size()) {
                q qVar4 = (q) arrayList2.get(i15);
                int i16 = qVar4.f1077a;
                if (i16 == 1) {
                    j2 = 0;
                } else if (i16 == 2) {
                    j2 = 1;
                } else if (i16 == 3) {
                    j2 = 2;
                } else if (i16 == 4) {
                    j2 = 3;
                } else {
                    if (i16 != 5) {
                        throw null;
                    }
                    j2 = 4;
                }
                t(byteArrayOutputStream, j2, 4);
                t(byteArrayOutputStream, size2, 4);
                byte[] bArr7 = qVar4.f1078b;
                if (qVar4.f1079c) {
                    long length5 = bArr7.length;
                    byte[] a4 = a(bArr7);
                    arrayList = arrayList5;
                    arrayList.add(a4);
                    t(byteArrayOutputStream, a4.length, 4);
                    t(byteArrayOutputStream, length5, 4);
                    length = a4.length;
                } else {
                    arrayList = arrayList5;
                    arrayList.add(bArr7);
                    t(byteArrayOutputStream, bArr7.length, 4);
                    t(byteArrayOutputStream, 0L, 4);
                    length = bArr7.length;
                }
                size2 += length;
                i15++;
                arrayList5 = arrayList;
            }
            ArrayList arrayList6 = arrayList5;
            for (int i17 = 0; i17 < arrayList6.size(); i17++) {
                byteArrayOutputStream.write((byte[]) arrayList6.get(i17));
            }
            return true;
        } catch (Throwable th3) {
            try {
                byteArrayOutputStream2.close();
                throw th3;
            } catch (Throwable th4) {
                th3.addSuppressed(th4);
                throw th3;
            }
        }
    }

    public static void p(ByteArrayOutputStream byteArrayOutputStream, C0076c c0076c, String str) {
        Charset charset = StandardCharsets.UTF_8;
        u(byteArrayOutputStream, str.getBytes(charset).length);
        u(byteArrayOutputStream, c0076c.f1049e);
        t(byteArrayOutputStream, c0076c.f1050f, 4);
        t(byteArrayOutputStream, c0076c.f1047c, 4);
        t(byteArrayOutputStream, c0076c.f1051g, 4);
        byteArrayOutputStream.write(str.getBytes(charset));
    }

    public static void q(ByteArrayOutputStream byteArrayOutputStream, C0076c c0076c) {
        byte[] bArr = new byte[(((c0076c.f1051g * 2) + 7) & (-8)) / 8];
        for (Map.Entry entry : c0076c.f1053i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            int intValue2 = ((Integer) entry.getValue()).intValue();
            if ((intValue2 & 2) != 0) {
                int i2 = intValue / 8;
                bArr[i2] = (byte) (bArr[i2] | (1 << (intValue % 8)));
            }
            if ((intValue2 & 4) != 0) {
                int i3 = intValue + c0076c.f1051g;
                int i4 = i3 / 8;
                bArr[i4] = (byte) ((1 << (i3 % 8)) | bArr[i4]);
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void r(ByteArrayOutputStream byteArrayOutputStream, C0076c c0076c) {
        int i2 = 0;
        for (Map.Entry entry : c0076c.f1053i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            if ((((Integer) entry.getValue()).intValue() & 1) != 0) {
                u(byteArrayOutputStream, intValue - i2);
                u(byteArrayOutputStream, 0);
                i2 = intValue;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:72:0x01c2, code lost:
    
        if (r5 == null) goto L127;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0222  */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0292  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x0226  */
    /* JADX WARN: Removed duplicated region for block: B:203:0x0102 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x02a8 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:61:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x01ce  */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v14 */
    /* JADX WARN: Type inference failed for: r6v16 */
    /* JADX WARN: Type inference failed for: r6v25 */
    /* JADX WARN: Type inference failed for: r6v26 */
    /* JADX WARN: Type inference failed for: r6v27 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v30 */
    /* JADX WARN: Type inference failed for: r6v34 */
    /* JADX WARN: Type inference failed for: r6v35 */
    /* JADX WARN: Type inference failed for: r6v36 */
    /* JADX WARN: Type inference failed for: r6v37 */
    /* JADX WARN: Type inference failed for: r6v38 */
    /* JADX WARN: Type inference failed for: r6v39 */
    /* JADX WARN: Type inference failed for: r6v43 */
    /* JADX WARN: Type inference failed for: r6v44 */
    /* JADX WARN: Type inference failed for: r6v45 */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.io.FileInputStream, java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void s(Context context, Executor executor, InterfaceC0079f interfaceC0079f, boolean z2) {
        boolean z3;
        ?? r6;
        IOException iOException;
        int i2;
        C0076c[] c0076cArr;
        C0076c[] c0076cArr2;
        C0075b c0075b;
        C0076c[] c0076cArr3;
        byte[] bArr;
        boolean z4;
        boolean z5;
        FileOutputStream fileOutputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        FileInputStream a2;
        boolean z6;
        Context applicationContext = context.getApplicationContext();
        String packageName = applicationContext.getPackageName();
        ApplicationInfo applicationInfo = applicationContext.getApplicationInfo();
        AssetManager assets = applicationContext.getAssets();
        String name = new File(applicationInfo.sourceDir).getName();
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            File filesDir = context.getFilesDir();
            if (!z2) {
                File file = new File(filesDir, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
                if (file.exists()) {
                    try {
                        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                        try {
                            long readLong = dataInputStream.readLong();
                            dataInputStream.close();
                            z6 = readLong == packageInfo.lastUpdateTime;
                            if (z6) {
                                interfaceC0079f.a(2, null);
                            }
                        } finally {
                        }
                    } catch (IOException unused) {
                    }
                    if (z6) {
                        Log.d("ProfileInstaller", "Skipping profile installation for " + context.getPackageName());
                        p.c(context, false);
                        return;
                    }
                }
                z6 = false;
                if (z6) {
                }
            }
            Log.d("ProfileInstaller", "Installing profile for " + context.getPackageName());
            int i3 = Build.VERSION.SDK_INT;
            File file2 = new File(new File("/data/misc/profiles/cur/0", packageName), "primary.prof");
            C0075b c0075b2 = new C0075b(assets, executor, interfaceC0079f, name, file2);
            byte[] bArr2 = c0075b2.f1039c;
            if (bArr2 == null) {
                c0075b2.b(3, Integer.valueOf(i3));
            } else {
                if (!file2.exists()) {
                    try {
                        file2.createNewFile();
                    } catch (IOException unused2) {
                        z3 = true;
                        c0075b2.b(4, null);
                    }
                } else if (!file2.canWrite()) {
                    c0075b2.b(4, null);
                }
                c0075b2.f1042f = true;
                byte[] bArr3 = f1056b;
                try {
                    try {
                        r6 = c0075b2.a(assets, "dexopt/baseline.prof");
                    } catch (FileNotFoundException e2) {
                        interfaceC0079f.a(6, e2);
                        r6 = 0;
                        if (r6 != 0) {
                        }
                        c0076cArr2 = c0075b2.f1043g;
                        if (c0076cArr2 != null) {
                        }
                        c0075b = c0075b2;
                        InterfaceC0079f interfaceC0079f2 = c0075b.f1038b;
                        c0076cArr3 = c0075b.f1043g;
                        ?? r62 = r6;
                        if (c0076cArr3 != null) {
                        }
                        bArr = c0075b.f1044h;
                        if (bArr == null) {
                        }
                        if (z5) {
                        }
                        p.c(context, (z5 || !z2) ? false : z3);
                    } catch (IOException e3) {
                        interfaceC0079f.a(7, e3);
                        r6 = 0;
                        if (r6 != 0) {
                        }
                        c0076cArr2 = c0075b2.f1043g;
                        if (c0076cArr2 != null) {
                        }
                        c0075b = c0075b2;
                        InterfaceC0079f interfaceC0079f22 = c0075b.f1038b;
                        c0076cArr3 = c0075b.f1043g;
                        ?? r622 = r6;
                        if (c0076cArr3 != null) {
                        }
                        bArr = c0075b.f1044h;
                        if (bArr == null) {
                        }
                        if (z5) {
                        }
                        p.c(context, (z5 || !z2) ? false : z3);
                    }
                    if (r6 != 0) {
                        try {
                        } catch (IOException e4) {
                            i2 = 7;
                            interfaceC0079f.a(7, e4);
                            try {
                                r6.close();
                            } catch (IOException e5) {
                                iOException = e5;
                                interfaceC0079f.a(i2, iOException);
                                c0076cArr = null;
                                r6 = r6;
                                c0075b2.f1043g = c0076cArr;
                                c0076cArr2 = c0075b2.f1043g;
                                if (c0076cArr2 != null) {
                                }
                                c0075b = c0075b2;
                                InterfaceC0079f interfaceC0079f222 = c0075b.f1038b;
                                c0076cArr3 = c0075b.f1043g;
                                ?? r6222 = r6;
                                if (c0076cArr3 != null) {
                                }
                                bArr = c0075b.f1044h;
                                if (bArr == null) {
                                }
                                if (z5) {
                                }
                                p.c(context, (z5 || !z2) ? false : z3);
                            }
                            c0076cArr = null;
                            r6 = r6;
                            c0075b2.f1043g = c0076cArr;
                            c0076cArr2 = c0075b2.f1043g;
                            if (c0076cArr2 != null) {
                            }
                            c0075b = c0075b2;
                            InterfaceC0079f interfaceC0079f2222 = c0075b.f1038b;
                            c0076cArr3 = c0075b.f1043g;
                            ?? r62222 = r6;
                            if (c0076cArr3 != null) {
                            }
                            bArr = c0075b.f1044h;
                            if (bArr == null) {
                            }
                            if (z5) {
                            }
                            p.c(context, (z5 || !z2) ? false : z3);
                        } catch (IllegalStateException e6) {
                            try {
                                interfaceC0079f.a(8, e6);
                                try {
                                    r6.close();
                                } catch (IOException e7) {
                                    iOException = e7;
                                    i2 = 7;
                                    interfaceC0079f.a(i2, iOException);
                                    c0076cArr = null;
                                    r6 = r6;
                                    c0075b2.f1043g = c0076cArr;
                                    c0076cArr2 = c0075b2.f1043g;
                                    if (c0076cArr2 != null) {
                                    }
                                    c0075b = c0075b2;
                                    InterfaceC0079f interfaceC0079f22222 = c0075b.f1038b;
                                    c0076cArr3 = c0075b.f1043g;
                                    ?? r622222 = r6;
                                    if (c0076cArr3 != null) {
                                    }
                                    bArr = c0075b.f1044h;
                                    if (bArr == null) {
                                    }
                                    if (z5) {
                                    }
                                    p.c(context, (z5 || !z2) ? false : z3);
                                }
                                c0076cArr = null;
                                r6 = r6;
                                c0075b2.f1043g = c0076cArr;
                                c0076cArr2 = c0075b2.f1043g;
                                if (c0076cArr2 != null) {
                                }
                                c0075b = c0075b2;
                                InterfaceC0079f interfaceC0079f222222 = c0075b.f1038b;
                                c0076cArr3 = c0075b.f1043g;
                                ?? r6222222 = r6;
                                if (c0076cArr3 != null) {
                                }
                                bArr = c0075b.f1044h;
                                if (bArr == null) {
                                }
                                if (z5) {
                                }
                                p.c(context, (z5 || !z2) ? false : z3);
                            } catch (Throwable th) {
                                th = th;
                                Throwable th2 = th;
                                try {
                                    r6.close();
                                    throw th2;
                                } catch (IOException e8) {
                                    interfaceC0079f.a(7, e8);
                                    throw th2;
                                }
                            }
                        }
                        if (!Arrays.equals(bArr3, f(r6, 4))) {
                            throw new IllegalStateException("Invalid magic");
                        }
                        c0076cArr = l(r6, f(r6, 4), c0075b2.f1041e);
                        try {
                            r6.close();
                            r6 = r6;
                        } catch (IOException e9) {
                            IOException iOException2 = e9;
                            interfaceC0079f.a(7, iOException2);
                            r6 = iOException2;
                        }
                        c0075b2.f1043g = c0076cArr;
                    }
                    c0076cArr2 = c0075b2.f1043g;
                    if (c0076cArr2 != null) {
                        int i4 = Build.VERSION.SDK_INT;
                        r6 = 34;
                        if (i4 <= 34) {
                            r6 = 25;
                            r6 = 25;
                            if (i4 != 25) {
                                switch (i4) {
                                }
                            }
                            try {
                                a2 = c0075b2.a(assets, "dexopt/baseline.profm");
                            } catch (FileNotFoundException e10) {
                                interfaceC0079f.a(9, e10);
                            } catch (IOException e11) {
                                interfaceC0079f.a(7, e11);
                            } catch (IllegalStateException e12) {
                                c0075b2.f1043g = null;
                                interfaceC0079f.a(8, e12);
                            }
                            if (a2 != null) {
                                try {
                                    boolean equals = Arrays.equals(f1057c, f(a2, 4));
                                    if (!equals) {
                                        throw new IllegalStateException("Invalid magic");
                                    }
                                    c0075b2.f1043g = i(a2, f(a2, 4), bArr2, c0076cArr2);
                                    a2.close();
                                    c0075b = c0075b2;
                                    r6 = equals;
                                } finally {
                                }
                            } else {
                                if (a2 != null) {
                                    a2.close();
                                }
                                c0075b = null;
                            }
                        }
                    }
                    c0075b = c0075b2;
                    InterfaceC0079f interfaceC0079f2222222 = c0075b.f1038b;
                    c0076cArr3 = c0075b.f1043g;
                    ?? r62222222 = r6;
                    if (c0076cArr3 != null) {
                        byte[] bArr4 = c0075b.f1039c;
                        r62222222 = bArr4;
                        if (bArr4 != null) {
                            if (!c0075b.f1042f) {
                                throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                            }
                            try {
                                byteArrayOutputStream = new ByteArrayOutputStream();
                                try {
                                    byteArrayOutputStream.write(bArr3);
                                    byteArrayOutputStream.write(bArr4);
                                } finally {
                                }
                            } catch (IOException e13) {
                                interfaceC0079f2222222.a(7, e13);
                            } catch (IllegalStateException e14) {
                                interfaceC0079f2222222.a(8, e14);
                            }
                            if (o(byteArrayOutputStream, bArr4, c0076cArr3)) {
                                c0075b.f1044h = byteArrayOutputStream.toByteArray();
                                byteArrayOutputStream.close();
                                c0075b.f1043g = null;
                                r62222222 = bArr4;
                            } else {
                                interfaceC0079f2222222.a(5, null);
                                c0075b.f1043g = null;
                                byteArrayOutputStream.close();
                                r62222222 = bArr4;
                            }
                        }
                    }
                    bArr = c0075b.f1044h;
                    if (bArr == null) {
                        z5 = false;
                        z3 = true;
                    } else {
                        try {
                            if (!c0075b.f1042f) {
                                throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                            }
                            try {
                                try {
                                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
                                    try {
                                        fileOutputStream = new FileOutputStream(c0075b.f1040d);
                                    } catch (Throwable th3) {
                                        th = th3;
                                    }
                                    try {
                                        try {
                                            byte[] bArr5 = new byte[512];
                                            while (true) {
                                                int read = byteArrayInputStream.read(bArr5);
                                                if (read > 0) {
                                                    fileOutputStream.write(bArr5, 0, read);
                                                } else {
                                                    z3 = true;
                                                    try {
                                                        c0075b.b(1, null);
                                                        fileOutputStream.close();
                                                        byteArrayInputStream.close();
                                                        c0075b.f1044h = null;
                                                        c0075b.f1043g = null;
                                                        z5 = true;
                                                    } catch (Throwable th4) {
                                                        th = th4;
                                                        Throwable th5 = th;
                                                        try {
                                                            fileOutputStream.close();
                                                            throw th5;
                                                        } catch (Throwable th6) {
                                                            th5.addSuppressed(th6);
                                                            throw th5;
                                                        }
                                                    }
                                                }
                                            }
                                        } catch (Throwable th7) {
                                            th = th7;
                                        }
                                    } catch (Throwable th8) {
                                        th = th8;
                                        Throwable th9 = th;
                                        try {
                                            byteArrayInputStream.close();
                                            throw th9;
                                        } catch (Throwable th10) {
                                            th9.addSuppressed(th10);
                                            throw th9;
                                        }
                                    }
                                } catch (FileNotFoundException e15) {
                                    e = e15;
                                    c0075b.b(6, e);
                                    z4 = r62222222;
                                    z5 = false;
                                    z3 = z4;
                                    if (z5) {
                                    }
                                    p.c(context, (z5 || !z2) ? false : z3);
                                } catch (IOException e16) {
                                    e = e16;
                                    c0075b.b(7, e);
                                    z4 = r62222222;
                                    z5 = false;
                                    z3 = z4;
                                    if (z5) {
                                    }
                                    p.c(context, (z5 || !z2) ? false : z3);
                                }
                            } catch (FileNotFoundException e17) {
                                e = e17;
                                r62222222 = 1;
                                c0075b.b(6, e);
                                z4 = r62222222;
                                z5 = false;
                                z3 = z4;
                                if (z5) {
                                }
                                p.c(context, (z5 || !z2) ? false : z3);
                            } catch (IOException e18) {
                                e = e18;
                                r62222222 = 1;
                                c0075b.b(7, e);
                                z4 = r62222222;
                                z5 = false;
                                z3 = z4;
                                if (z5) {
                                }
                                p.c(context, (z5 || !z2) ? false : z3);
                            }
                        } finally {
                            c0075b.f1044h = null;
                            c0075b.f1043g = null;
                        }
                    }
                    if (z5) {
                        e(packageInfo, filesDir);
                    }
                    p.c(context, (z5 || !z2) ? false : z3);
                } catch (Throwable th11) {
                    th = th11;
                }
            }
            z3 = true;
            z5 = false;
            p.c(context, (z5 || !z2) ? false : z3);
        } catch (PackageManager.NameNotFoundException e19) {
            interfaceC0079f.a(7, e19);
            p.c(context, false);
        }
    }

    public static void t(ByteArrayOutputStream byteArrayOutputStream, long j2, int i2) {
        byte[] bArr = new byte[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            bArr[i3] = (byte) ((j2 >> (i3 * 8)) & 255);
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void u(ByteArrayOutputStream byteArrayOutputStream, int i2) {
        t(byteArrayOutputStream, i2, 2);
    }
}
