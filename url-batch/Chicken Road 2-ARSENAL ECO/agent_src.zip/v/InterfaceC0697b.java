package v;

/* renamed from: v.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0697b {
}
