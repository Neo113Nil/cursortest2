package B1;

/* loaded from: classes.dex */
public interface e {
}
