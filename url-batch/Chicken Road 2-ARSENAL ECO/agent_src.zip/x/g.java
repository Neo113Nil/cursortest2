package x;

import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public abstract class g extends Drawable implements Drawable.Callback, f {
}
