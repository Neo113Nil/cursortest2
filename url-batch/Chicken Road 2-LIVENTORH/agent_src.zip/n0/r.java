package n0;

/* compiled from: r8-map-id-fb2637cf2a71147074b02d847622f707cfc12821f1b81d08e7915f8e7b9519ab */
/* loaded from: classes.dex */
public interface r {
    void onScrollLimit(int i, int i4, int i5, boolean z3);

    void onScrollProgress(int i, int i4, int i5, int i6);
}
