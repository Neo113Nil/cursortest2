package e0;

import android.content.res.Resources;

/* compiled from: r8-map-id-fb2637cf2a71147074b02d847622f707cfc12821f1b81d08e7915f8e7b9519ab */
/* loaded from: classes.dex */
public abstract class l {
    public static void a(Resources.Theme theme) {
        theme.rebase();
    }
}
