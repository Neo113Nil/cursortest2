package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Dimension$Companion;
import androidx.annotation.VisibleForTesting$Companion;
import com.cell.force.dev.star.cyber.melbet.CategoryActivity;
import defpackage.dc;
import defpackage.i2;
import defpackage.o0;
import defpackage.om;
import defpackage.p90;
import defpackage.pm;
import java.util.LinkedHashMap;

public final class CategoryActivity extends i2 {
    private o0 binding;

    public enum a {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    public enum b {
        NONE,
        DEFAULT,
        CUSTOM
    }

    public static final class e {
        public static final e INSTANCE = new e();

        static {
            new LinkedHashMap();
        }

        private e() {
        }
    }

    public enum f {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CategoryActivity() {
        concatTab("input", "sample");
        convertLoad("sample");
        convertInput("data");
        orMedia(false, true);
        minCompare(68, 58);
        checkWrite();
        monitorDeploy();
        minReceiver(50, 29);
        int i = 3;
        new c(false, 0 == true ? 1 : 0, i, null);
        new d(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        b[] bVarArr = b.d;
        a[] aVarArr = a.d;
        f[] fVarArr = f.d;
        e.INSTANCE.getClass();
    }

    private final boolean checkWrite() {
        return true;
    }

    private final String concatTab(String str, String str2) {
        return str + str2;
    }

    private final String convertInput(String str) {
        return str.toString();
    }

    private final String convertLoad(String str) {
        return str.toString();
    }

    private final int minCompare(int i, int i2) {
        return Math.min(i, i2);
    }

    private final int minReceiver(int i, int i2) {
        return Math.min(i, i2);
    }

    private final int monitorDeploy() {
        return 1;
    }

    public static final void onCreate$lambda$0(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.d);
    }

    public static final void onCreate$lambda$1(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.e);
    }

    public static final void onCreate$lambda$2(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.f);
    }

    public static final void onCreate$lambda$3(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.g);
    }

    public static final void onCreate$lambda$4(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.h);
    }

    public static final void onCreate$lambda$5(CategoryActivity categoryActivity, View view) {
        categoryActivity.openDifficulty(p90.i);
    }

    private final void openDifficulty(p90 p90Var) {
        Intent intent = new Intent(this, (Class<?>) DifficultyActivity.class);
        om.INSTANCE.getClass();
        intent.putExtra(om.a, p90Var.name());
        startActivity(intent);
    }

    private final boolean orMedia(boolean z, boolean z2) {
        return z || z2;
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        o0 o0VarA = o0.a(getLayoutInflater());
        this.binding = o0VarA;
        setContentView(o0VarA.a);
        o0 o0Var = this.binding;
        if (o0Var == null) {
            pm.d("binding");
            throw null;
        }
        final int i = 0;
        o0Var.b.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i2 = i;
                CategoryActivity categoryActivity = this.e;
                switch (i2) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
        o0 o0Var2 = this.binding;
        if (o0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        final int i2 = 1;
        o0Var2.d.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i2;
                CategoryActivity categoryActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
        o0 o0Var3 = this.binding;
        if (o0Var3 == null) {
            pm.d("binding");
            throw null;
        }
        final int i3 = 2;
        o0Var3.c.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i3;
                CategoryActivity categoryActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
        o0 o0Var4 = this.binding;
        if (o0Var4 == null) {
            pm.d("binding");
            throw null;
        }
        final int i4 = 3;
        o0Var4.f.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i4;
                CategoryActivity categoryActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
        o0 o0Var5 = this.binding;
        if (o0Var5 == null) {
            pm.d("binding");
            throw null;
        }
        final int i5 = 4;
        o0Var5.g.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i5;
                CategoryActivity categoryActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
        o0 o0Var6 = this.binding;
        if (o0Var6 == null) {
            pm.d("binding");
            throw null;
        }
        final int i6 = 5;
        o0Var6.e.setOnClickListener(new View.OnClickListener(this) {
            public final CategoryActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i6;
                CategoryActivity categoryActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        CategoryActivity.onCreate$lambda$0(categoryActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        CategoryActivity.onCreate$lambda$1(categoryActivity, view);
                        break;
                    case 2:
                        CategoryActivity.onCreate$lambda$2(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        CategoryActivity.onCreate$lambda$3(categoryActivity, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        CategoryActivity.onCreate$lambda$4(categoryActivity, view);
                        break;
                    default:
                        CategoryActivity.onCreate$lambda$5(categoryActivity, view);
                        break;
                }
            }
        });
    }

    public static final class c {
        public final boolean a;
        public final int b;

        public c(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.a == cVar.a && this.b == cVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "ReminderConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public c(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public c() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }

    public static final class d {
        public final String a;
        public final int b;

        public d(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof d)) {
                return false;
            }
            d dVar = (d) obj;
            return pm.a(this.a, dVar.a) && this.b == dVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "ResponseInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public d(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public d() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }
}
