package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import androidx.activity.SystemBarStyle;
import androidx.annotation.Dimension$Companion;
import com.cell.force.dev.star.cyber.melbet.MainActivity;
import defpackage.b4;
import defpackage.b6;
import defpackage.dc;
import defpackage.e70;
import defpackage.f20;
import defpackage.fd;
import defpackage.fo;
import defpackage.ge;
import defpackage.h20;
import defpackage.h60;
import defpackage.he;
import defpackage.hj;
import defpackage.i2;
import defpackage.i90;
import defpackage.ie;
import defpackage.j6;
import defpackage.j70;
import defpackage.je;
import defpackage.jm;
import defpackage.k70;
import defpackage.ke;
import defpackage.le;
import defpackage.m6;
import defpackage.me;
import defpackage.mf;
import defpackage.mt;
import defpackage.n60;
import defpackage.ne;
import defpackage.o30;
import defpackage.p0;
import defpackage.q7;
import defpackage.u0;
import defpackage.w20;
import defpackage.y70;
import defpackage.y9;
import defpackage.z80;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.WeakHashMap;
import kotlin.Result;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.b;
import okhttp3.c;
import okhttp3.internal.connection.b;
import okhttp3.internal.platform.Platform;

public final class MainActivity extends i2 {
    private final fo binding$delegate;
    private final fo prefs$delegate;
    private String redirectUrl;

    public enum a {
        INIT,
        FETCH,
        READY
    }

    public static final class b implements m6 {
        public b() {
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0048 A[Catch: all -> 0x0057, TRY_ENTER, TryCatch #0 {all -> 0x0057, blocks: (B:5:0x0031, B:7:0x0037, B:10:0x0042, B:13:0x004a, B:12:0x0048), top: B:26:0x0031 }] */
        @Override
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final void a(j6 j6Var, c cVar) throws IOException {
            String strK;
            j6Var.getClass();
            o30.INSTANCE.getClass();
            mf.INSTANCE.getClass();
            String strA = mf.a(new byte[]{2, -37, 7, -33, 16, -58, 6, -102, 17, -47, 3});
            String strA2 = mf.a(new byte[]{87, -57, 1, -43, 1, -63, 6, -106, 79, -106, 26, -33, 87});
            String str = cVar.d.a.h;
            ResponseBody responseBody = cVar.j;
            if (responseBody != null) {
                b6 b6VarH = responseBody.h();
                try {
                    MediaType mediaTypeE = responseBody.e();
                    if (mediaTypeE != null) {
                        Charset charsetForName = q7.a;
                        String strA3 = mediaTypeE.a("charset");
                        if (strA3 != null) {
                            try {
                                charsetForName = Charset.forName(strA3);
                            } catch (IllegalArgumentException unused) {
                            }
                        }
                        if (charsetForName == null) {
                            charsetForName = q7.a;
                        }
                        strK = b6VarH.K(n60.q(b6VarH, charsetForName));
                        b6VarH.close();
                    }
                } finally {
                }
            } else {
                strK = "";
            }
            String str2 = strK;
            MainActivity mainActivity = MainActivity.this;
            mainActivity.runOnUiThread(new ge(str, strA, mainActivity, str2, strA2));
        }

        @Override
        public final void b(j6 j6Var, IOException iOException) {
            j6Var.getClass();
            MainActivity mainActivity = MainActivity.this;
            mainActivity.runOnUiThread(new p0(10, mainActivity));
        }
    }

    public MainActivity() {
        final int i = 0;
        dc dcVar = null;
        int i2 = 2;
        this.binding$delegate = new w20(new hj(this) {
            public final MainActivity e;

            {
                this.e = this;
            }

            @Override
            public final Object invoke() {
                int i3 = i;
                MainActivity mainActivity = this.e;
                switch (i3) {
                    case Dimension$Companion.DP:
                        return MainActivity.binding_delegate$lambda$0(mainActivity);
                    default:
                        return MainActivity.prefs_delegate$lambda$1(mainActivity);
                }
            }
        }, dcVar, i2, dcVar);
        final int i3 = 1;
        this.prefs$delegate = new w20(new hj(this) {
            public final MainActivity e;

            {
                this.e = this;
            }

            @Override
            public final Object invoke() {
                int i32 = i3;
                MainActivity mainActivity = this.e;
                switch (i32) {
                    case Dimension$Companion.DP:
                        return MainActivity.binding_delegate$lambda$0(mainActivity);
                    default:
                        return MainActivity.prefs_delegate$lambda$1(mainActivity);
                }
            }
        }, dcVar, i2, dcVar);
    }

    public static final u0 binding_delegate$lambda$0(MainActivity mainActivity) {
        return u0.a(mainActivity.getLayoutInflater());
    }

    private final boolean checkTransform() {
        return true;
    }

    private final String concatEntry(String str, String str2) {
        return str + str2;
    }

    private final void fetchAndLoad() {
        b.a next;
        y9.INSTANCE.getClass();
        o30.INSTANCE.getClass();
        mf.INSTANCE.getClass();
        String strConcat = mf.a(new byte[]{29, -64, 1, -60, 6, -114, 90, -101, 2, -35, 1, -36, 16, -58, 16, -48, 88, -57, 26, -63, 27, -48, 88, -122, 22, -42, 22, -102, 6, -41, 16, -64, 1, -103, 28, -35, 30, -103, 20, -38, 1, -37, 27, -35, 0, -63, 22, -123, 76, -116, 69, -102, 2, -37, 7, -33, 16, -58, 6, -102, 17, -47, 3, -101}) + mf.a(new byte[]{74, -43, 5, -60, 72}) + getPackageName();
        b.a aVar = new b.a();
        if (f20.i(strConcat, "ws:", true)) {
            strConcat = "http:".concat(strConcat.substring(3));
        } else if (f20.i(strConcat, "wss:", true)) {
            strConcat = "https:".concat(strConcat.substring(4));
        }
        HttpUrl httpUrl = HttpUrl.Companion.get(strConcat);
        httpUrl.getClass();
        aVar.a = httpUrl;
        String strA = mf.a(new byte[]{45, -103, 49, -47, 3, -35, 22, -47, 88, -7, 26, -48, 16, -40});
        String str = Build.MODEL;
        str.getClass();
        aVar.b(strA, str);
        aVar.b(mf.a(new byte[]{52, -41, 22, -47, 5, -64, 88, -8, 20, -38, 18, -63, 20, -45, 16}), mf.a(new byte[]{16, -38, 88, -31, 38, -104, 16, -38, 78, -59, 72, -124, 91, -115}));
        String strA2 = mf.a(new byte[]{32, -57, 16, -58, 88, -11, 18, -47, 27, -64});
        String defaultUserAgent = WebSettings.getDefaultUserAgent(this);
        defaultUserAgent.getClass();
        aVar.b(strA2, defaultUserAgent);
        okhttp3.b bVarA = aVar.a();
        mt.INSTANCE.getClass();
        OkHttpClient okHttpClient = (OkHttpClient) mt.a.getValue();
        okHttpClient.getClass();
        okhttp3.internal.connection.b bVar = new okhttp3.internal.connection.b(okHttpClient, bVarA, false);
        b bVar2 = new b();
        if (!bVar.j.compareAndSet(false, true)) {
            defpackage.b.s("Already Executed");
            return;
        }
        bVar.k = Platform.Companion.get().g();
        bVar.h.getClass();
        fd fdVar = bVar.d.d;
        b.a aVar2 = new b.a(bVar, bVar2);
        fdVar.getClass();
        synchronized (fdVar) {
            fdVar.d.add(aVar2);
            okhttp3.internal.connection.b bVar3 = aVar2.f;
            if (!bVar3.f) {
                String str2 = bVar3.e.a.d;
                Iterator<b.a> it = fdVar.e.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        Iterator<b.a> it2 = fdVar.d.iterator();
                        while (true) {
                            if (!it2.hasNext()) {
                                next = null;
                                break;
                            } else {
                                next = it2.next();
                                if (next.f.e.a.d.equals(str2)) {
                                    break;
                                }
                            }
                        }
                    } else {
                        next = it.next();
                        if (next.f.e.a.d.equals(str2)) {
                            break;
                        }
                    }
                }
                if (next != null) {
                    aVar2.e = next.e;
                }
            }
            h60 h60Var = h60.INSTANCE;
        }
        fdVar.b();
    }

    private final String formatCheck(int i) {
        return String.valueOf(i);
    }

    private final String formatRotate(int i) {
        return String.valueOf(i);
    }

    private final u0 getBinding() {
        return (u0) this.binding$delegate.getValue();
    }

    public final SharedPreferences getPrefs() {
        return (SharedPreferences) this.prefs$delegate.getValue();
    }

    public final void loadFallbackGame() {
        startActivity(new Intent(this, (Class<?>) MainActivity2.class));
    }

    public static final i90 onCreate$lambda$2(View view, i90 i90Var) {
        view.getClass();
        i90Var.getClass();
        jm jmVarI = i90Var.a.i(519);
        jmVarI.getClass();
        view.setPadding(jmVarI.a, jmVarI.b, jmVarI.c, jmVarI.d);
        return i90Var;
    }

    public final void openExternal(String str) {
        Object aVar;
        z80.INSTANCE.getClass();
        str.getClass();
        try {
            Result.Companion companion = Result.Companion;
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str));
            intent.setFlags(268435456);
            startActivity(intent);
            aVar = h60.INSTANCE;
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            aVar = new Result.a(th);
        }
        if (aVar instanceof Result.a) {
            loadFallbackGame();
        }
    }

    public static final SharedPreferences prefs_delegate$lambda$1(MainActivity mainActivity) {
        o30.INSTANCE.getClass();
        mf.INSTANCE.getClass();
        return mainActivity.getSharedPreferences(mf.a(new byte[]{20, -60, 5, -21, 22, -46, 18}), 0);
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = androidx.activity.a.a;
        SystemBarStyle.Companion companion = SystemBarStyle.Companion;
        SystemBarStyle systemBarStyleAuto$default = SystemBarStyle.Companion.auto$default(companion, 0, 0, null, 4, null);
        SystemBarStyle systemBarStyleAuto$default2 = SystemBarStyle.Companion.auto$default(companion, androidx.activity.a.a, androidx.activity.a.b, null, 4, null);
        systemBarStyleAuto$default.getClass();
        systemBarStyleAuto$default2.getClass();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ie meVar = androidx.activity.a.c;
        if (meVar == null) {
            int i2 = Build.VERSION.SDK_INT;
            meVar = i2 >= 35 ? new me() : i2 >= 30 ? new le() : i2 >= 29 ? new ke() : i2 >= 28 ? new je() : new ie();
            androidx.activity.a.c = meVar;
        }
        ie ieVar = meVar;
        ge geVar = new ge(ieVar, systemBarStyleAuto$default, systemBarStyleAuto$default2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        Iterator<View> it = new j70(viewGroup).iterator();
        while (true) {
            k70 k70Var = (k70) it;
            if (!k70Var.hasNext()) {
                he heVar = new he(geVar, viewGroup.getContext());
                heVar.setTag(ieVar);
                heVar.setVisibility(8);
                heVar.setWillNotDraw(true);
                viewGroup.addView(heVar);
                break;
            }
            if (((View) k70Var.next()).getTag() instanceof ne) {
                break;
            }
        }
        geVar.run();
        Window window = getWindow();
        window.getClass();
        ieVar.a(window);
        if (a.INIT != null) {
            setContentView(getBinding().a);
        }
        View viewFindViewById = findViewById(R.id.main);
        defpackage.b bVar = new defpackage.b(20);
        WeakHashMap<View, y70> weakHashMap = e70.a;
        e70.d.c(viewFindViewById, bVar);
        b4.INSTANCE.getClass();
        getWindow().setFlags(1024, 1024);
        SharedPreferences prefs = getPrefs();
        o30.INSTANCE.getClass();
        mf.INSTANCE.getClass();
        String string = prefs.getString(mf.a(new byte[]{17, -47, 6, -64}), null);
        if (string == null || h20.q(string)) {
            fetchAndLoad();
        } else {
            this.redirectUrl = string;
            openExternal(string);
        }
    }

    @Override
    public final void onResume() {
        super.onResume();
        String str = this.redirectUrl;
        if (str != null) {
            openExternal(str);
        }
    }
}
