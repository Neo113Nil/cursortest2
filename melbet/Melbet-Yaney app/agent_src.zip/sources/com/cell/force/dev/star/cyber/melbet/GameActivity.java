package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Dimension$Companion;
import com.cell.force.dev.star.cyber.melbet.GameActivity;
import defpackage.a9;
import defpackage.dc;
import defpackage.f20;
import defpackage.h20;
import defpackage.i2;
import defpackage.jf;
import defpackage.o90;
import defpackage.om;
import defpackage.p0;
import defpackage.p90;
import defpackage.pm;
import defpackage.q90;
import defpackage.qf;
import defpackage.s0;
import defpackage.uc;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.Result;
import kotlin.collections.AbstractList;
import kotlin.random.XorWowRandom;

public final class GameActivity extends i2 {
    public static final Companion Companion = new Companion(null);
    private static final int HINT_PENALTY = 20;
    private static final long NEXT_DELAY_MS = 600;
    private static final int PENALTY_PER_SEC = 2;
    private static final long TIMER_TICK_MS = 100;
    private s0 binding;
    private CountDownTimer countDownTimer;
    private int currentIndex;
    private int guessedCount;
    private boolean hintUsed;
    private boolean isDaily;
    private GamePreferences preferences;
    private boolean roundLocked;
    private int scoreValue;
    private p90 selectedCategory;
    private uc selectedDifficulty;
    private long wordStartMs;
    private List<o90> roundWords = jf.INSTANCE;
    private final ArrayList<String> skippedWords = new ArrayList<>();
    private final Map<p90, Integer> guessedByCategory = new LinkedHashMap();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static final class d {
        public static final d INSTANCE = new d();

        private d() {
        }
    }

    public enum e {
        IDLE,
        LOADING,
        SUCCESS,
        ERROR
    }

    public static final class f {
        public static final f INSTANCE = new f();

        private f() {
        }
    }

    public static final class g extends CountDownTimer {
        public final long a;
        public final GameActivity b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(long j, GameActivity gameActivity) {
            super(j, GameActivity.TIMER_TICK_MS);
            this.a = j;
            this.b = gameActivity;
        }

        @Override
        public final void onFinish() {
            GameActivity gameActivity = this.b;
            s0 s0Var = gameActivity.binding;
            if (s0Var == null) {
                pm.d("binding");
                throw null;
            }
            s0Var.g.setProgress(0);
            gameActivity.applyTimerColor(0.0f);
            gameActivity.skipWord();
        }

        @Override
        public final void onTick(long j) {
            GameActivity gameActivity = this.b;
            s0 s0Var = gameActivity.binding;
            if (s0Var == null) {
                pm.d("binding");
                throw null;
            }
            s0Var.g.setProgress((int) j);
            gameActivity.applyTimerColor(j / this.a);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public GameActivity() {
        logReject();
        isTileValid("data");
        ensureReload();
        minPayload(15, 18);
        safeGrid("input");
        orMetrics(true, false);
        orToken(false, false);
        new c(false, 0L, 3, null);
        int i = 3;
        new a(false, 0 == true ? 1 : 0, i, null);
        new b(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        e[] eVarArr = e.d;
        f.INSTANCE.getClass();
        d.INSTANCE.getClass();
    }

    public final void applyTimerColor(float f2) {
        int color = getColor(f2 > 0.5f ? R.color.colorTimerGreen : f2 > 0.25f ? R.color.colorTimerYellow : R.color.colorTimerRed);
        s0 s0Var = this.binding;
        if (s0Var != null) {
            s0Var.g.setProgressTintList(ColorStateList.valueOf(color));
        } else {
            pm.d("binding");
            throw null;
        }
    }

    public final void checkAnswer() throws Resources.NotFoundException {
        if (this.roundLocked) {
            return;
        }
        o90 o90Var = this.roundWords.get(this.currentIndex);
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        if (f20.e(h20.w(s0Var.e.getText().toString()).toString(), o90Var.a)) {
            onCorrectAnswer(o90Var);
        } else {
            onWrongAnswer();
        }
    }

    private final int dp(int i) {
        return (int) (i * getResources().getDisplayMetrics().density);
    }

    private final boolean ensureReload() {
        return true;
    }

    private final void finishRound() {
        boolean z;
        String str;
        int i;
        GamePreferences gamePreferences = this.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        SharedPreferences sharedPreferences = gamePreferences.a;
        int i2 = this.scoreValue;
        int i3 = this.guessedCount;
        int size = this.skippedWords.size();
        Map<p90, Integer> map = this.guessedByCategory;
        boolean z2 = this.isDaily;
        p90 p90Var = this.selectedCategory;
        uc ucVar = this.selectedDifficulty;
        map.getClass();
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        String str2 = GamePreferences.e;
        boolean z3 = false;
        editorEdit.putInt(str2, sharedPreferences.getInt(str2, 0) + 1);
        String str3 = GamePreferences.f;
        editorEdit.putInt(str3, sharedPreferences.getInt(str3, 0) + i3);
        String str4 = GamePreferences.g;
        editorEdit.putInt(str4, sharedPreferences.getInt(str4, 0) + size);
        String str5 = GamePreferences.h;
        editorEdit.putInt(str5, sharedPreferences.getInt(str5, 0) + i2);
        for (Map.Entry<p90, Integer> entry : map.entrySet()) {
            String str6 = "guessed_" + entry.getKey().name();
            editorEdit.putInt(str6, entry.getValue().intValue() + sharedPreferences.getInt(str6, 0));
        }
        String string = LocalDate.now().toString();
        string.getClass();
        String str7 = GamePreferences.k;
        String string2 = sharedPreferences.getString(str7, null);
        if (string2 == null) {
            string2 = "";
        }
        if (string2.equals(string)) {
            z = true;
            str = "";
        } else {
            if (string2.length() == 0) {
                i = 1;
                z = true;
                str = "";
            } else {
                z = true;
                str = "";
                i = pm.a(LocalDate.parse(string2).plusDays(1L), LocalDate.now()) ? sharedPreferences.getInt(GamePreferences.j, 0) + 1 : 1;
            }
            editorEdit.putInt(GamePreferences.j, i);
            editorEdit.putString(str7, string);
        }
        qf qfVar = p90.k;
        qfVar.getClass();
        AbstractList.a aVar = new AbstractList.a();
        p90 p90Var2 = null;
        int i4 = 0;
        while (aVar.hasNext()) {
            p90 p90Var3 = (p90) aVar.next();
            int i5 = sharedPreferences.getInt("guessed_" + p90Var3.name(), 0);
            Integer num = map.get(p90Var3);
            int iIntValue = i5 + (num != null ? num.intValue() : 0);
            if (iIntValue > i4) {
                i4 = iIntValue;
                p90Var2 = p90Var3;
            }
        }
        String str8 = GamePreferences.i;
        String strName = p90Var2 != null ? p90Var2.name() : null;
        if (strName == null) {
            strName = str;
        }
        editorEdit.putString(str8, strName);
        editorEdit.apply();
        if (z2) {
            String str9 = GamePreferences.m;
            String string3 = LocalDate.now().toString();
            string3.getClass();
            String str10 = GamePreferences.l;
            String string4 = sharedPreferences.getString(str10, null);
            if (string4 == null) {
                string4 = str;
            }
            SharedPreferences.Editor editorEdit2 = sharedPreferences.edit();
            editorEdit2.putString(str10, string3);
            if (string4.equals(string3)) {
                if (i2 > sharedPreferences.getInt(str9, 0)) {
                    editorEdit2.putInt(str9, i2);
                    z3 = z;
                }
                editorEdit2.apply();
            } else {
                editorEdit2.putInt(str9, i2);
                if (i2 > 0) {
                    z3 = z;
                }
                editorEdit2.apply();
            }
        } else if (p90Var != null && ucVar != null) {
            if (i2 > sharedPreferences.getInt("record_" + p90Var.name() + "_" + ucVar.name(), 0)) {
                sharedPreferences.edit().putInt("record_" + p90Var.name() + "_" + ucVar.name(), i2).apply();
                z3 = z;
            }
        }
        Intent intent = new Intent(this, (Class<?>) ResultActivity.class);
        om.INSTANCE.getClass();
        intent.putExtra(om.d, this.guessedCount);
        intent.putExtra(om.e, this.roundWords.size());
        intent.putExtra(om.f, this.scoreValue);
        intent.putExtra(om.g, z3);
        intent.putStringArrayListExtra(om.h, this.skippedWords);
        intent.putExtra(om.c, this.isDaily);
        String str11 = om.a;
        p90 p90Var4 = this.selectedCategory;
        String strName2 = p90Var4 != null ? p90Var4.name() : null;
        if (strName2 == null) {
            strName2 = str;
        }
        intent.putExtra(str11, strName2);
        String str12 = om.b;
        uc ucVar2 = this.selectedDifficulty;
        String strName3 = ucVar2 != null ? ucVar2.name() : null;
        intent.putExtra(str12, strName3 == null ? str : strName3);
        startActivity(intent);
        finish();
    }

    public final void goNext() {
        int i = this.currentIndex + 1;
        this.currentIndex = i;
        if (i >= this.roundWords.size()) {
            finishRound();
        } else {
            showCurrentWord();
        }
    }

    private final boolean isTileValid(String str) {
        return str.length() >= 0;
    }

    private final long logReject() {
        return System.currentTimeMillis();
    }

    private final int minPayload(int i, int i2) {
        return Math.min(i, i2);
    }

    private final void onCorrectAnswer(o90 o90Var) {
        this.roundLocked = true;
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        int iElapsedRealtime = (int) ((SystemClock.elapsedRealtime() - this.wordStartMs) / 1000);
        uc ucVar = o90Var.d;
        p90 p90Var = o90Var.c;
        int i = ucVar.f - (iElapsedRealtime * 2);
        if (i < 0) {
            i = 0;
        }
        this.scoreValue += i;
        this.guessedCount++;
        Integer num = this.guessedByCategory.get(p90Var);
        this.guessedByCategory.put(p90Var, Integer.valueOf((num != null ? num.intValue() : 0) + 1));
        updateScoreLabel();
        playTone(25);
        vibrate(3);
        this.mainHandler.postDelayed(new p0(8, this), NEXT_DELAY_MS);
    }

    public static final boolean onCreate$lambda$3(GameActivity gameActivity, TextView textView, int i, KeyEvent keyEvent) throws Resources.NotFoundException {
        if (i != 6) {
            return false;
        }
        gameActivity.checkAnswer();
        return true;
    }

    private final void onWrongAnswer() throws Resources.NotFoundException {
        playTone(26);
        vibrate(0);
        Animation animationLoadAnimation = AnimationUtils.loadAnimation(this, R.anim.shake_animation);
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        s0Var.e.startAnimation(animationLoadAnimation);
        s0 s0Var2 = this.binding;
        if (s0Var2 != null) {
            s0Var2.e.setText("");
        } else {
            pm.d("binding");
            throw null;
        }
    }

    private final boolean orMetrics(boolean z, boolean z2) {
        return z || z2;
    }

    private final boolean orToken(boolean z, boolean z2) {
        return z || z2;
    }

    private final void playTone(int i) {
        GamePreferences gamePreferences = this.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        if (gamePreferences.a.getBoolean(GamePreferences.c, true)) {
            ToneGenerator toneGenerator = new ToneGenerator(3, 80);
            toneGenerator.startTone(i, 180);
            this.mainHandler.postDelayed(new p0(9, toneGenerator), 250L);
        }
    }

    private final boolean prepareRound() {
        Object aVar;
        Object aVar2;
        boolean zIsEmpty;
        Intent intent = getIntent();
        om.INSTANCE.getClass();
        int i = 0;
        boolean booleanExtra = intent.getBooleanExtra(om.c, false);
        this.isDaily = booleanExtra;
        if (!booleanExtra) {
            String stringExtra = getIntent().getStringExtra(om.a);
            if (stringExtra == null) {
                stringExtra = "";
            }
            String stringExtra2 = getIntent().getStringExtra(om.b);
            String str = stringExtra2 != null ? stringExtra2 : "";
            if (stringExtra.length() != 0 && str.length() != 0) {
                try {
                    Result.Companion companion = Result.Companion;
                    aVar = p90.valueOf(stringExtra);
                } catch (Throwable th) {
                    Result.Companion companion2 = Result.Companion;
                    aVar = new Result.a(th);
                }
                if (aVar instanceof Result.a) {
                    aVar = null;
                }
                this.selectedCategory = (p90) aVar;
                try {
                    aVar2 = uc.valueOf(str);
                } catch (Throwable th2) {
                    Result.Companion companion3 = Result.Companion;
                    aVar2 = new Result.a(th2);
                }
                uc ucVar = (uc) (aVar2 instanceof Result.a ? null : aVar2);
                this.selectedDifficulty = ucVar;
                p90 p90Var = this.selectedCategory;
                if (p90Var != null && ucVar != null) {
                    q90.INSTANCE.getClass();
                    ArrayList arrayList = q90.a;
                    ArrayList arrayList2 = new ArrayList();
                    int size = arrayList.size();
                    while (i < size) {
                        Object obj = arrayList.get(i);
                        i++;
                        o90 o90Var = (o90) obj;
                        if (o90Var.c == p90Var && o90Var.d == ucVar) {
                            arrayList2.add(obj);
                        }
                    }
                    List listQ = a9.q(arrayList2);
                    Collections.shuffle(listQ);
                    List<o90> listN = a9.n(ucVar.e, listQ);
                    this.roundWords = listN;
                    zIsEmpty = listN.isEmpty();
                }
            }
            return false;
        }
        q90.INSTANCE.getClass();
        LocalDate localDateNow = LocalDate.now();
        long monthValue = (localDateNow.getMonthValue() * TIMER_TICK_MS) + (localDateNow.getYear() * 10000) + localDateNow.getDayOfMonth();
        ArrayList arrayList3 = q90.a;
        XorWowRandom xorWowRandom = new XorWowRandom((int) monthValue, (int) (monthValue >> 32));
        arrayList3.getClass();
        List listQ2 = a9.q(arrayList3);
        ArrayList arrayList4 = (ArrayList) listQ2;
        for (int size2 = arrayList4.size() - 1; size2 > 0; size2--) {
            int iC = xorWowRandom.c(size2 + 1);
            arrayList4.set(iC, arrayList4.set(size2, arrayList4.get(iC)));
        }
        List<o90> listN2 = a9.n(15, listQ2);
        this.roundWords = listN2;
        zIsEmpty = listN2.isEmpty();
        return !zIsEmpty;
    }

    private final void renderLetters(String str) {
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        s0Var.f.removeAllViews();
        int iDp = dp(12);
        int iDp2 = dp(4);
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMarginEnd(iDp2);
            textView.setLayoutParams(layoutParams);
            textView.setText(String.valueOf(cCharAt));
            textView.setBackgroundResource(R.drawable.letter_tile_bg);
            textView.setTextSize(2, 28.0f);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setTextColor(getColor(R.color.white));
            textView.setPadding(iDp, iDp, iDp, iDp);
            textView.setGravity(17);
            s0 s0Var2 = this.binding;
            if (s0Var2 == null) {
                pm.d("binding");
                throw null;
            }
            s0Var2.f.addView(textView);
        }
    }

    private final String safeGrid(String str) {
        return str == null ? "" : str;
    }

    private final void showCurrentWord() {
        this.roundLocked = false;
        this.hintUsed = false;
        o90 o90Var = this.roundWords.get(this.currentIndex);
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        s0Var.h.setText(getString(R.string.word_progress, Integer.valueOf(this.currentIndex + 1), Integer.valueOf(this.roundWords.size())));
        updateScoreLabel();
        s0 s0Var2 = this.binding;
        if (s0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        s0Var2.e.setText("");
        q90 q90Var = q90.INSTANCE;
        String str = o90Var.a;
        q90Var.getClass();
        char[] charArray = str.toCharArray();
        charArray.getClass();
        if (charArray.length > 1) {
            String str2 = str;
            for (int i = 0; str2.equals(str) && i < 40; i++) {
                kotlin.random.a.d.getClass();
                for (int length = charArray.length - 1; length > 0; length--) {
                    int iE = kotlin.random.a.e.e(length + 1);
                    char c2 = charArray[length];
                    charArray[length] = charArray[iE];
                    charArray[iE] = c2;
                }
                str2 = new String(charArray);
            }
            str = str2;
        }
        renderLetters(str);
        startTimer(o90Var.d.d * 1000);
        s0 s0Var3 = this.binding;
        if (s0Var3 == null) {
            pm.d("binding");
            throw null;
        }
        s0Var3.e.requestFocus();
    }

    public final void skipWord() {
        if (this.roundLocked) {
            return;
        }
        this.roundLocked = true;
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        this.skippedWords.add(this.roundWords.get(this.currentIndex).a);
        goNext();
    }

    private final void startTimer(long j) {
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        this.wordStartMs = SystemClock.elapsedRealtime();
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        int i = (int) j;
        s0Var.g.setMax(i);
        s0 s0Var2 = this.binding;
        if (s0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        s0Var2.g.setProgress(i);
        applyTimerColor(1.0f);
        this.countDownTimer = new g(j, this).start();
    }

    private final void updateScoreLabel() {
        s0 s0Var = this.binding;
        if (s0Var != null) {
            s0Var.i.setText(getString(R.string.score_label, Integer.valueOf(this.scoreValue)));
        } else {
            pm.d("binding");
            throw null;
        }
    }

    public final void useHint() {
        if (this.roundLocked || this.hintUsed) {
            return;
        }
        this.hintUsed = true;
        int i = this.scoreValue - 20;
        if (i < 0) {
            i = 0;
        }
        this.scoreValue = i;
        updateScoreLabel();
        String str = this.roundWords.get(this.currentIndex).a;
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        EditText editText = s0Var.e;
        if (str.length() == 0) {
            throw new NoSuchElementException("Char sequence is empty.");
        }
        char cCharAt = str.charAt(0);
        if (str.length() == 0) {
            throw new NoSuchElementException("Char sequence is empty.");
        }
        char cCharAt2 = str.charAt(str.length() - 1);
        StringBuilder sb = new StringBuilder();
        sb.append(cCharAt);
        sb.append(cCharAt2);
        editText.setText(sb.toString());
        if (str.length() >= 2) {
            s0 s0Var2 = this.binding;
            if (s0Var2 == null) {
                pm.d("binding");
                throw null;
            }
            s0Var2.e.setSelection(1);
        }
        playTone(24);
        vibrate(3);
    }

    private final void vibrate(int i) {
        GamePreferences gamePreferences = this.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        if (gamePreferences.a.getBoolean(GamePreferences.d, true)) {
            s0 s0Var = this.binding;
            if (s0Var != null) {
                s0Var.a.performHapticFeedback(i);
            } else {
                pm.d("binding");
                throw null;
            }
        }
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        s0 s0VarA = s0.a(getLayoutInflater());
        this.binding = s0VarA;
        setContentView(s0VarA.a);
        this.preferences = new GamePreferences(this);
        if (!prepareRound()) {
            finish();
            return;
        }
        s0 s0Var = this.binding;
        if (s0Var == null) {
            pm.d("binding");
            throw null;
        }
        final int i = 0;
        s0Var.b.setOnClickListener(new View.OnClickListener(this) {
            public final GameActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) throws Resources.NotFoundException {
                int i2 = i;
                GameActivity gameActivity = this.e;
                switch (i2) {
                    case Dimension$Companion.DP:
                        gameActivity.checkAnswer();
                        break;
                    case Dimension$Companion.PX:
                        gameActivity.skipWord();
                        break;
                    default:
                        gameActivity.useHint();
                        break;
                }
            }
        });
        s0 s0Var2 = this.binding;
        if (s0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        final int i2 = 1;
        s0Var2.d.setOnClickListener(new View.OnClickListener(this) {
            public final GameActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i2;
                GameActivity gameActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        gameActivity.checkAnswer();
                        break;
                    case Dimension$Companion.PX:
                        gameActivity.skipWord();
                        break;
                    default:
                        gameActivity.useHint();
                        break;
                }
            }
        });
        s0 s0Var3 = this.binding;
        if (s0Var3 == null) {
            pm.d("binding");
            throw null;
        }
        final int i3 = 2;
        s0Var3.c.setOnClickListener(new View.OnClickListener(this) {
            public final GameActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i3;
                GameActivity gameActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        gameActivity.checkAnswer();
                        break;
                    case Dimension$Companion.PX:
                        gameActivity.skipWord();
                        break;
                    default:
                        gameActivity.useHint();
                        break;
                }
            }
        });
        s0 s0Var4 = this.binding;
        if (s0Var4 == null) {
            pm.d("binding");
            throw null;
        }
        s0Var4.e.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public final boolean onEditorAction(TextView textView, int i4, KeyEvent keyEvent) {
                return GameActivity.onCreate$lambda$3(this.a, textView, i4, keyEvent);
            }
        });
        showCurrentWord();
    }

    @Override
    public final void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.countDownTimer;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        this.mainHandler.removeCallbacksAndMessages(null);
    }

    public static final class Companion {
        public Companion(dc dcVar) {
            this();
        }

        private Companion() {
        }
    }

    public static final class a {
        public final boolean a;
        public final int b;

        public a(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && this.b == aVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "AdapterConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public a(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }

    public static final class b {
        public final boolean a;
        public final String b;

        public b(boolean z, String str, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? "" : str);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.a == bVar.a && pm.a(this.b, bVar.b);
        }

        public final int hashCode() {
            return this.b.hashCode() + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "ConfigureResult(success=" + this.a + ", message=" + this.b + ")";
        }

        public b(boolean z, String str) {
            str.getClass();
            this.a = z;
            this.b = str;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public b() {
            this(false, null, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class c {
        public final boolean a;
        public final long b;

        public c(boolean z, long j, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.a == cVar.a && this.b == cVar.b;
        }

        public final int hashCode() {
            return Long.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "EncodeState(isReady=" + this.a + ", timestamp=" + this.b + ")";
        }

        public c(boolean z, long j) {
            this.a = z;
            this.b = j;
        }

        public c() {
            this(false, 0L, 3, null);
        }
    }
}
