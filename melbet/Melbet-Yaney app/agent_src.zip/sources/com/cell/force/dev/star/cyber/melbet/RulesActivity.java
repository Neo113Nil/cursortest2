package com.cell.force.dev.star.cyber.melbet;

import android.os.Bundle;
import defpackage.dc;
import defpackage.h1;
import defpackage.h20;
import defpackage.i2;
import defpackage.pm;

public final class RulesActivity extends i2 {
    private h1 binding;

    public static final class a {
        public static final a INSTANCE = new a();

        private a() {
        }
    }

    public enum b {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    public enum d {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    public enum f {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    public static final class h {
        public static final h INSTANCE = new h();

        private h() {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public RulesActivity() {
        processLoad("sample");
        convertShare("sample");
        computeSchema(3);
        verifyAddState();
        sumAbort(61, 19);
        trackInvoice("value");
        transformSync("data");
        trackReminder("value");
        validatePaste();
        computeSpace(6);
        notNullClose("");
        new g(false, 0L, 3, null);
        new e(0, null, false, 7, null);
        new c(null, 0, 3, 0 == true ? 1 : 0);
        f[] fVarArr = f.d;
        d[] dVarArr = d.d;
        b[] bVarArr = b.d;
        h.INSTANCE.getClass();
        a.INSTANCE.getClass();
    }

    private final int computeSchema(int i) {
        return (i * 2) / 2;
    }

    private final int computeSpace(int i) {
        return (i * 2) / 2;
    }

    private final String convertShare(String str) {
        return str.toString();
    }

    private final boolean notNullClose(Object obj) {
        return obj != null;
    }

    private final String processLoad(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        sb.reverse();
        return sb.toString();
    }

    private final int sumAbort(int i, int i2) {
        return i + i2;
    }

    private final int trackInvoice(String str) {
        return str.hashCode();
    }

    private final int trackReminder(String str) {
        return str.hashCode();
    }

    private final String transformSync(String str) {
        return h20.w(str).toString();
    }

    private final boolean validatePaste() {
        return true;
    }

    private final boolean verifyAddState() {
        return System.currentTimeMillis() > 0;
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        h1 h1VarA = h1.a(getLayoutInflater());
        this.binding = h1VarA;
        setContentView(h1VarA.a);
    }

    public static final class c {
        public final String a;
        public final int b;

        public c(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return pm.a(this.a, cVar.a) && this.b == cVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "RenderInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public c(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public c() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class g {
        public final boolean a;
        public final long b;

        public g(boolean z, long j, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? 0L : j);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof g)) {
                return false;
            }
            g gVar = (g) obj;
            return this.a == gVar.a && this.b == gVar.b;
        }

        public final int hashCode() {
            return Long.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "StreamState(isReady=" + this.a + ", timestamp=" + this.b + ")";
        }

        public g(boolean z, long j) {
            this.a = z;
            this.b = j;
        }

        public g() {
            this(false, 0L, 3, null);
        }
    }

    public static final class e {
        public final int a;
        public final String b;
        public final boolean c;

        public e(int i, String str, boolean z, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? false : z);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            return this.a == eVar.a && pm.a(this.b, eVar.b) && this.c == eVar.c;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.c) + ((this.b.hashCode() + (Integer.hashCode(this.a) * 31)) * 31);
        }

        public final String toString() {
            return "ShiftData(id=" + this.a + ", name=" + this.b + ", active=" + this.c + ")";
        }

        public e(int i, String str, boolean z) {
            str.getClass();
            this.a = i;
            this.b = str;
            this.c = z;
        }

        public e() {
            this(0, null, false, 7, null);
        }
    }
}
