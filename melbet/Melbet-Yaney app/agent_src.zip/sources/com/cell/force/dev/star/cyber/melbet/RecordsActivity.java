package com.cell.force.dev.star.cyber.melbet;

import android.os.Bundle;
import android.widget.TextView;
import defpackage.c60;
import defpackage.dc;
import defpackage.h20;
import defpackage.i2;
import defpackage.p90;
import defpackage.pm;
import defpackage.pt;
import defpackage.qf;
import defpackage.uc;
import defpackage.v0;
import kotlin.collections.AbstractList;

public final class RecordsActivity extends i2 {
    private v0 binding;

    public static final class c {
        public static final c INSTANCE = new c();

        private c() {
        }
    }

    public enum d {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    /* JADX WARN: Multi-variable type inference failed */
    public RecordsActivity() {
        verifyToastState();
        transformTransform("test");
        formatFormat(42);
        logRepeat();
        ensureCalendar();
        processFooter("sample");
        hashReceiver("input");
        ensureQueue();
        isDuplicateValid("value");
        sumCollection(45, 48);
        andStream(false, true);
        getIdText();
        new a(0, null, false, 7, null);
        new b(null, 0, 3, 0 == true ? 1 : 0);
        d[] dVarArr = d.d;
        c.INSTANCE.getClass();
    }

    private final boolean andStream(boolean z, boolean z2) {
        return z && z2;
    }

    private final int dp(int i) {
        return (int) (i * getResources().getDisplayMetrics().density);
    }

    private final boolean ensureCalendar() {
        return true;
    }

    private final boolean ensureQueue() {
        return true;
    }

    private final String formatFormat(int i) {
        return String.valueOf(i);
    }

    private final int getIdText() {
        return System.identityHashCode(this);
    }

    private final int hashReceiver(String str) {
        return str.hashCode();
    }

    private final boolean isDuplicateValid(String str) {
        return str.length() >= 0;
    }

    private final long logRepeat() {
        return System.currentTimeMillis();
    }

    private final String processFooter(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        sb.reverse();
        return sb.toString();
    }

    private final int sumCollection(int i, int i2) {
        return i + i2;
    }

    private final String transformTransform(String str) {
        return h20.w(str).toString();
    }

    private final boolean verifyToastState() {
        return System.currentTimeMillis() > 0;
    }

    @Override
    public final void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        v0 v0VarA = v0.a(getLayoutInflater());
        this.binding = v0VarA;
        setContentView(v0VarA.a);
        GamePreferences gamePreferences = new GamePreferences(this);
        qf qfVar = p90.k;
        qfVar.getClass();
        AbstractList.a aVar = new AbstractList.a();
        while (aVar.hasNext()) {
            p90 p90Var = (p90) aVar.next();
            qf qfVar2 = uc.k;
            qfVar2.getClass();
            AbstractList.a aVar2 = new AbstractList.a();
            while (aVar2.hasNext()) {
                uc ucVar = (uc) aVar2.next();
                TextView textView = new TextView(this);
                p90Var.getClass();
                ucVar.getClass();
                int i2 = gamePreferences.a.getInt("record_" + p90Var.name() + "_" + ucVar.name(), 0);
                String string = getString(c60.a(p90Var));
                int i3 = c60.a.b[ucVar.ordinal()];
                if (i3 == 1) {
                    i = R.string.difficulty_easy;
                } else if (i3 == 2) {
                    i = R.string.difficulty_medium;
                } else {
                    if (i3 != 3) {
                        throw new pt();
                    }
                    i = R.string.difficulty_hard;
                }
                textView.setText(getString(R.string.record_line, string, getString(i), Integer.valueOf(i2)));
                textView.setTextColor(getColor(R.color.white));
                textView.setTextSize(16.0f);
                textView.setPadding(0, dp(6), 0, dp(6));
                v0 v0Var = this.binding;
                if (v0Var == null) {
                    pm.d("binding");
                    throw null;
                }
                v0Var.b.addView(textView);
            }
        }
    }

    public static final class b {
        public final String a;
        public final int b;

        public b(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return pm.a(this.a, bVar.a) && this.b == bVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "CopyInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public b(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public b() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class a {
        public final int a;
        public final String b;
        public final boolean c;

        public a(int i, String str, boolean z, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? false : z);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && pm.a(this.b, aVar.b) && this.c == aVar.c;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.c) + ((this.b.hashCode() + (Integer.hashCode(this.a) * 31)) * 31);
        }

        public final String toString() {
            return "ActionData(id=" + this.a + ", name=" + this.b + ", active=" + this.c + ")";
        }

        public a(int i, String str, boolean z) {
            str.getClass();
            this.a = i;
            this.b = str;
            this.c = z;
        }

        public a() {
            this(0, null, false, 7, null);
        }
    }
}
