package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Dimension$Companion;
import com.cell.force.dev.star.cyber.melbet.ResultActivity;
import defpackage.a1;
import defpackage.a9;
import defpackage.dc;
import defpackage.h;
import defpackage.h20;
import defpackage.i2;
import defpackage.om;
import defpackage.pm;
import java.util.ArrayList;

public final class ResultActivity extends i2 {
    private a1 binding;
    private String categoryName = "";
    private String difficultyName = "";
    private boolean isDaily;

    public enum c {
        AUTO,
        MANUAL,
        DISABLED
    }

    public enum d {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    /* JADX WARN: Multi-variable type inference failed */
    public ResultActivity() {
        convertTransform("value");
        validateCreate();
        formatContact(57);
        processText("input");
        convertImage("sample");
        concatData("input", "test");
        validateUrl();
        transformPhoto("sample");
        int i = 3;
        new b(false, 0 == true ? 1 : 0, i, null);
        new a(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        d[] dVarArr = d.d;
        c[] cVarArr = c.d;
    }

    private final String concatData(String str, String str2) {
        return str + str2;
    }

    private final String convertImage(String str) {
        return str.toString();
    }

    private final String convertTransform(String str) {
        return str.toString();
    }

    private final String formatContact(int i) {
        return String.valueOf(i);
    }

    public final void goToMenu() {
        Intent intent = new Intent(this, (Class<?>) MainActivity2.class);
        intent.setFlags(603979776);
        startActivity(intent);
        finish();
    }

    public static final CharSequence onCreate$lambda$0(ResultActivity resultActivity, String str) {
        String string = resultActivity.getString(R.string.skipped_item, str);
        string.getClass();
        return string;
    }

    private final String processText(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        sb.reverse();
        return sb.toString();
    }

    public final void replayRound() {
        Intent intent = new Intent(this, (Class<?>) GameActivity.class);
        om omVar = om.INSTANCE;
        omVar.getClass();
        intent.putExtra(om.c, this.isDaily);
        omVar.getClass();
        intent.putExtra(om.a, this.categoryName);
        omVar.getClass();
        intent.putExtra(om.b, this.difficultyName);
        startActivity(intent);
        finish();
    }

    private final String transformPhoto(String str) {
        return h20.w(str).toString();
    }

    private final boolean validateCreate() {
        return true;
    }

    private final boolean validateUrl() {
        return true;
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        a1 a1VarA = a1.a(getLayoutInflater());
        this.binding = a1VarA;
        setContentView(a1VarA.a);
        Intent intent = getIntent();
        om.INSTANCE.getClass();
        final int i = 0;
        int intExtra = intent.getIntExtra(om.d, 0);
        int intExtra2 = getIntent().getIntExtra(om.e, 0);
        int intExtra3 = getIntent().getIntExtra(om.f, 0);
        boolean booleanExtra = getIntent().getBooleanExtra(om.g, false);
        ArrayList<String> stringArrayListExtra = getIntent().getStringArrayListExtra(om.h);
        if (stringArrayListExtra == null) {
            stringArrayListExtra = new ArrayList<>();
        }
        this.isDaily = getIntent().getBooleanExtra(om.c, false);
        String stringExtra = getIntent().getStringExtra(om.a);
        if (stringExtra == null) {
            stringExtra = "";
        }
        this.categoryName = stringExtra;
        String stringExtra2 = getIntent().getStringExtra(om.b);
        this.difficultyName = stringExtra2 != null ? stringExtra2 : "";
        a1 a1Var = this.binding;
        if (a1Var == null) {
            pm.d("binding");
            throw null;
        }
        a1Var.d.setText(getString(R.string.result_guessed, Integer.valueOf(intExtra), Integer.valueOf(intExtra2)));
        a1 a1Var2 = this.binding;
        if (a1Var2 == null) {
            pm.d("binding");
            throw null;
        }
        a1Var2.f.setText(getString(R.string.result_score, Integer.valueOf(intExtra3)));
        a1 a1Var3 = this.binding;
        if (a1Var3 == null) {
            pm.d("binding");
            throw null;
        }
        a1Var3.e.setVisibility(booleanExtra ? 0 : 8);
        final int i2 = 1;
        if (!stringArrayListExtra.isEmpty()) {
            a1 a1Var4 = this.binding;
            if (a1Var4 == null) {
                pm.d("binding");
                throw null;
            }
            a1Var4.h.setVisibility(0);
            a1 a1Var5 = this.binding;
            if (a1Var5 == null) {
                pm.d("binding");
                throw null;
            }
            a1Var5.g.setVisibility(0);
            a1 a1Var6 = this.binding;
            if (a1Var6 == null) {
                pm.d("binding");
                throw null;
            }
            a1Var6.g.setText(a9.k(stringArrayListExtra, "\n", new h(i2, this), 30));
        }
        a1 a1Var7 = this.binding;
        if (a1Var7 == null) {
            pm.d("binding");
            throw null;
        }
        a1Var7.b.setOnClickListener(new View.OnClickListener(this) {
            public final ResultActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i3 = i;
                ResultActivity resultActivity = this.e;
                switch (i3) {
                    case Dimension$Companion.DP:
                        resultActivity.replayRound();
                        break;
                    default:
                        resultActivity.goToMenu();
                        break;
                }
            }
        });
        a1 a1Var8 = this.binding;
        if (a1Var8 != null) {
            a1Var8.c.setOnClickListener(new View.OnClickListener(this) {
                public final ResultActivity e;

                {
                    this.e = this;
                }

                @Override
                public final void onClick(View view) {
                    int i3 = i2;
                    ResultActivity resultActivity = this.e;
                    switch (i3) {
                        case Dimension$Companion.DP:
                            resultActivity.replayRound();
                            break;
                        default:
                            resultActivity.goToMenu();
                            break;
                    }
                }
            });
        } else {
            pm.d("binding");
            throw null;
        }
    }

    public static final class a {
        public final boolean a;
        public final String b;

        public a(boolean z, String str, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? "" : str);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && pm.a(this.b, aVar.b);
        }

        public final int hashCode() {
            return this.b.hashCode() + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "CreatorResult(success=" + this.a + ", message=" + this.b + ")";
        }

        public a(boolean z, String str) {
            str.getClass();
            this.a = z;
            this.b = str;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a() {
            this(false, null, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class b {
        public final boolean a;
        public final int b;

        public b(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.a == bVar.a && this.b == bVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "HelperConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public b(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public b() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }
}
