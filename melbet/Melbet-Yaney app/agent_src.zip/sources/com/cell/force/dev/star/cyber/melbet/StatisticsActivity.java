package com.cell.force.dev.star.cyber.melbet;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import defpackage.c60;
import defpackage.dc;
import defpackage.h20;
import defpackage.h8;
import defpackage.i2;
import defpackage.j1;
import defpackage.p90;
import defpackage.pm;
import defpackage.uz;
import java.util.LinkedHashMap;
import kotlin.Result;

public final class StatisticsActivity extends i2 {
    private j1 binding;
    private GamePreferences preferences;

    public static final class d {
        public static final d INSTANCE = new d();

        private d() {
        }
    }

    public static final class e {
        public static final e INSTANCE = new e();

        static {
            new LinkedHashMap();
        }

        private e() {
        }
    }

    public enum f {
        IDLE,
        LOADING,
        SUCCESS,
        ERROR
    }

    /* JADX WARN: Multi-variable type inference failed */
    public StatisticsActivity() {
        monitorAnalytics();
        isContactValid("data");
        concatFolder("test", "data");
        transformPaint("sample");
        parseDecompress("data");
        measureConverter();
        orMapper(false, true);
        int i = 3;
        new c(false, 0 == true ? 1 : 0, i, null);
        new b(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        new a(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        f[] fVarArr = f.d;
        d.INSTANCE.getClass();
        e.INSTANCE.getClass();
    }

    private final void bindStatistics() {
        j1 j1Var = this.binding;
        if (j1Var == null) {
            pm.d("binding");
            throw null;
        }
        TextView textView = j1Var.f;
        GamePreferences gamePreferences = this.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        SharedPreferences sharedPreferences = gamePreferences.a;
        String str = GamePreferences.e;
        textView.setText(getString(R.string.stat_total_games, Integer.valueOf(sharedPreferences.getInt(str, 0))));
        j1 j1Var2 = this.binding;
        if (j1Var2 == null) {
            pm.d("binding");
            throw null;
        }
        TextView textView2 = j1Var2.g;
        GamePreferences gamePreferences2 = this.preferences;
        if (gamePreferences2 == null) {
            pm.d("preferences");
            throw null;
        }
        textView2.setText(getString(R.string.stat_words_guessed, Integer.valueOf(gamePreferences2.a.getInt(GamePreferences.f, 0))));
        j1 j1Var3 = this.binding;
        if (j1Var3 == null) {
            pm.d("binding");
            throw null;
        }
        TextView textView3 = j1Var3.h;
        GamePreferences gamePreferences3 = this.preferences;
        if (gamePreferences3 == null) {
            pm.d("preferences");
            throw null;
        }
        textView3.setText(getString(R.string.stat_words_skipped, Integer.valueOf(gamePreferences3.a.getInt(GamePreferences.g, 0))));
        j1 j1Var4 = this.binding;
        if (j1Var4 == null) {
            pm.d("binding");
            throw null;
        }
        TextView textView4 = j1Var4.c;
        GamePreferences gamePreferences4 = this.preferences;
        if (gamePreferences4 == null) {
            pm.d("preferences");
            throw null;
        }
        SharedPreferences sharedPreferences2 = gamePreferences4.a;
        int i = sharedPreferences2.getInt(str, 0);
        textView4.setText(getString(R.string.stat_average_score, Integer.valueOf(i == 0 ? 0 : sharedPreferences2.getInt(GamePreferences.h, 0) / i)));
        j1 j1Var5 = this.binding;
        if (j1Var5 == null) {
            pm.d("binding");
            throw null;
        }
        j1Var5.d.setText(getString(R.string.stat_favorite_category, favoriteCategoryTitle()));
        j1 j1Var6 = this.binding;
        if (j1Var6 == null) {
            pm.d("binding");
            throw null;
        }
        TextView textView5 = j1Var6.e;
        GamePreferences gamePreferences5 = this.preferences;
        if (gamePreferences5 != null) {
            textView5.setText(getString(R.string.stat_streak, Integer.valueOf(gamePreferences5.a.getInt(GamePreferences.j, 0))));
        } else {
            pm.d("preferences");
            throw null;
        }
    }

    private final String concatFolder(String str, String str2) {
        return str + str2;
    }

    public final void confirmReset() {
        b.a aVar = new b.a(this);
        AlertController.b bVar = aVar.a;
        bVar.d = bVar.a.getText(R.string.reset_confirm_title);
        bVar.f = bVar.a.getText(R.string.reset_confirm_message);
        uz uzVar = new uz(this, 1);
        bVar.g = bVar.a.getText(R.string.yes);
        bVar.h = uzVar;
        bVar.i = bVar.a.getText(R.string.no);
        aVar.a().show();
    }

    public static final void confirmReset$lambda$2(StatisticsActivity statisticsActivity, DialogInterface dialogInterface, int i) {
        GamePreferences gamePreferences = statisticsActivity.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        SharedPreferences sharedPreferences = gamePreferences.a;
        String str = GamePreferences.c;
        boolean z = sharedPreferences.getBoolean(str, true);
        String str2 = GamePreferences.d;
        boolean z2 = sharedPreferences.getBoolean(str2, true);
        sharedPreferences.edit().clear().apply();
        sharedPreferences.edit().putBoolean(str, z).apply();
        sharedPreferences.edit().putBoolean(str2, z2).apply();
        statisticsActivity.bindStatistics();
        Toast.makeText(statisticsActivity, R.string.reset_done, 0).show();
    }

    private final String favoriteCategoryTitle() {
        Object aVar;
        GamePreferences gamePreferences = this.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        String string = gamePreferences.a.getString(GamePreferences.i, null);
        if (string == null) {
            string = "";
        }
        if (string.length() == 0) {
            String string2 = getString(R.string.stat_favorite_none);
            string2.getClass();
            return string2;
        }
        try {
            Result.Companion companion = Result.Companion;
            aVar = p90.valueOf(string);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            aVar = new Result.a(th);
        }
        p90 p90Var = (p90) (aVar instanceof Result.a ? null : aVar);
        if (p90Var == null) {
            String string3 = getString(R.string.stat_favorite_none);
            string3.getClass();
            return string3;
        }
        String string4 = getString(c60.a(p90Var));
        string4.getClass();
        return string4;
    }

    private final boolean isContactValid(String str) {
        return str.length() >= 0;
    }

    private final long measureConverter() {
        return (System.currentTimeMillis() - System.currentTimeMillis()) + 1;
    }

    private final int monitorAnalytics() {
        return 1;
    }

    private final boolean orMapper(boolean z, boolean z2) {
        return z || z2;
    }

    private final int parseDecompress(String str) {
        return str.length();
    }

    private final String transformPaint(String str) {
        return h20.w(str).toString();
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        j1 j1VarA = j1.a(getLayoutInflater());
        this.binding = j1VarA;
        setContentView(j1VarA.a);
        this.preferences = new GamePreferences(this);
        bindStatistics();
        j1 j1Var = this.binding;
        if (j1Var != null) {
            j1Var.b.setOnClickListener(new h8(5, this));
        } else {
            pm.d("binding");
            throw null;
        }
    }

    public static final class a {
        public final boolean a;
        public final int b;

        public a(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && this.b == aVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "GroupConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public a(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }

    public static final class b {
        public final String a;
        public final int b;

        public b(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return pm.a(this.a, bVar.a) && this.b == bVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "PopupInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public b(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public b() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class c {
        public final boolean a;
        public final int b;

        public c(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.a == cVar.a && this.b == cVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "RepeatConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public c(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public c() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }
}
