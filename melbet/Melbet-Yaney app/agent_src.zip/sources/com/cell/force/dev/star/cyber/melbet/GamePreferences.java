package com.cell.force.dev.star.cyber.melbet;

import android.content.Context;
import android.content.SharedPreferences;
import defpackage.dc;
import defpackage.zb;

public final class GamePreferences {
    public static final Companion Companion = new Companion(null);
    public static final String b = zb.a(zb.f);
    public static final String c = zb.a(zb.g);
    public static final String d = zb.a(zb.h);
    public static final String e = zb.a(zb.i);
    public static final String f = zb.a(zb.j);
    public static final String g = zb.a(zb.k);
    public static final String h = zb.a(zb.l);
    public static final String i = zb.a(zb.m);
    public static final String j = zb.a(zb.n);
    public static final String k = zb.a(zb.o);
    public static final String l = zb.a(zb.p);
    public static final String m = zb.a(zb.q);
    public final SharedPreferences a;

    public GamePreferences(Context context) {
        context.getClass();
        this.a = context.getSharedPreferences(b, 0);
    }

    public static final class Companion {
        public Companion(dc dcVar) {
            this();
        }

        private Companion() {
        }
    }
}
