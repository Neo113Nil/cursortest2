package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Dimension$Companion;
import androidx.annotation.VisibleForTesting$Companion;
import com.cell.force.dev.star.cyber.melbet.MainActivity2;
import defpackage.i2;
import defpackage.om;
import defpackage.pm;
import defpackage.t0;

public final class MainActivity2 extends i2 {
    private t0 binding;

    public static final void onCreate$lambda$0(MainActivity2 mainActivity2, View view) {
        mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) CategoryActivity.class));
    }

    public static final void onCreate$lambda$1(MainActivity2 mainActivity2, View view) {
        Intent intent = new Intent(mainActivity2, (Class<?>) GameActivity.class);
        om.INSTANCE.getClass();
        intent.putExtra(om.c, true);
        mainActivity2.startActivity(intent);
    }

    public static final void onCreate$lambda$2(MainActivity2 mainActivity2, View view) {
        mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) RecordsActivity.class));
    }

    public static final void onCreate$lambda$3(MainActivity2 mainActivity2, View view) {
        mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatisticsActivity.class));
    }

    public static final void onCreate$lambda$4(MainActivity2 mainActivity2, View view) {
        mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) RulesActivity.class));
    }

    public static final void onCreate$lambda$5(MainActivity2 mainActivity2, View view) {
        mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        t0 t0VarA = t0.a(getLayoutInflater());
        this.binding = t0VarA;
        setContentView(t0VarA.a);
        t0 t0Var = this.binding;
        if (t0Var == null) {
            pm.d("binding");
            throw null;
        }
        final int i = 0;
        t0Var.c.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i2 = i;
                MainActivity2 mainActivity2 = this.e;
                switch (i2) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
        t0 t0Var2 = this.binding;
        if (t0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        final int i2 = 1;
        t0Var2.b.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i2;
                MainActivity2 mainActivity2 = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
        t0 t0Var3 = this.binding;
        if (t0Var3 == null) {
            pm.d("binding");
            throw null;
        }
        final int i3 = 2;
        t0Var3.d.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i3;
                MainActivity2 mainActivity2 = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
        t0 t0Var4 = this.binding;
        if (t0Var4 == null) {
            pm.d("binding");
            throw null;
        }
        final int i4 = 3;
        t0Var4.g.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i4;
                MainActivity2 mainActivity2 = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
        t0 t0Var5 = this.binding;
        if (t0Var5 == null) {
            pm.d("binding");
            throw null;
        }
        final int i5 = 4;
        t0Var5.e.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i5;
                MainActivity2 mainActivity2 = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
        t0 t0Var6 = this.binding;
        if (t0Var6 == null) {
            pm.d("binding");
            throw null;
        }
        final int i6 = 5;
        t0Var6.f.setOnClickListener(new View.OnClickListener(this) {
            public final MainActivity2 e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i6;
                MainActivity2 mainActivity2 = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        MainActivity2.onCreate$lambda$0(mainActivity2, view);
                        break;
                    case Dimension$Companion.PX:
                        MainActivity2.onCreate$lambda$1(mainActivity2, view);
                        break;
                    case 2:
                        MainActivity2.onCreate$lambda$2(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PACKAGE_PRIVATE:
                        MainActivity2.onCreate$lambda$3(mainActivity2, view);
                        break;
                    case VisibleForTesting$Companion.PROTECTED:
                        MainActivity2.onCreate$lambda$4(mainActivity2, view);
                        break;
                    default:
                        MainActivity2.onCreate$lambda$5(mainActivity2, view);
                        break;
                }
            }
        });
    }
}
