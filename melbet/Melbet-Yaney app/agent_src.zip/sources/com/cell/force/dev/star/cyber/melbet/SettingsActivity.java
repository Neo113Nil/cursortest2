package com.cell.force.dev.star.cyber.melbet;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Toast;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import androidx.appcompat.widget.SwitchCompat;
import defpackage.dc;
import defpackage.h8;
import defpackage.i1;
import defpackage.i2;
import defpackage.pm;
import defpackage.tz;
import defpackage.uz;

public final class SettingsActivity extends i2 {
    private i1 binding;
    private GamePreferences preferences;

    public enum b {
        NONE,
        DEFAULT,
        CUSTOM
    }

    public static final class c {
        public static final c INSTANCE = new c();

        private c() {
        }
    }

    public static final class f {
        public static final f INSTANCE = new f();

        private f() {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public SettingsActivity() {
        convertJob("test");
        verifyAccountState();
        sumReload(96, 48);
        processUtil("value");
        safeView("value");
        notNullGallery("");
        diffService(89, 70);
        getIdDecode();
        int i = 3;
        new e(null, 0, i, 0 == true ? 1 : 0);
        new d(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        new a(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        b[] bVarArr = b.d;
        c.INSTANCE.getClass();
        f.INSTANCE.getClass();
    }

    public final void confirmReset() {
        b.a aVar = new b.a(this);
        AlertController.b bVar = aVar.a;
        bVar.d = bVar.a.getText(R.string.reset_confirm_title);
        bVar.f = bVar.a.getText(R.string.reset_confirm_message);
        uz uzVar = new uz(this, 0);
        bVar.g = bVar.a.getText(R.string.yes);
        bVar.h = uzVar;
        bVar.i = bVar.a.getText(R.string.no);
        aVar.a().show();
    }

    public static final void confirmReset$lambda$3(SettingsActivity settingsActivity, DialogInterface dialogInterface, int i) {
        GamePreferences gamePreferences = settingsActivity.preferences;
        if (gamePreferences == null) {
            pm.d("preferences");
            throw null;
        }
        SharedPreferences sharedPreferences = gamePreferences.a;
        String str = GamePreferences.c;
        boolean z = sharedPreferences.getBoolean(str, true);
        String str2 = GamePreferences.d;
        boolean z2 = sharedPreferences.getBoolean(str2, true);
        sharedPreferences.edit().clear().apply();
        sharedPreferences.edit().putBoolean(str, z).apply();
        sharedPreferences.edit().putBoolean(str2, z2).apply();
        Toast.makeText(settingsActivity, R.string.reset_done, 0).show();
    }

    private final String convertJob(String str) {
        return str.toString();
    }

    private final int diffService(int i, int i2) {
        return Math.abs(i - i2);
    }

    private final int getIdDecode() {
        return System.identityHashCode(this);
    }

    private final boolean notNullGallery(Object obj) {
        return obj != null;
    }

    public static final void onCreate$lambda$0(SettingsActivity settingsActivity, CompoundButton compoundButton, boolean z) {
        compoundButton.getClass();
        GamePreferences gamePreferences = settingsActivity.preferences;
        if (gamePreferences != null) {
            gamePreferences.a.edit().putBoolean(GamePreferences.c, z).apply();
        } else {
            pm.d("preferences");
            throw null;
        }
    }

    public static final void onCreate$lambda$1(SettingsActivity settingsActivity, CompoundButton compoundButton, boolean z) {
        compoundButton.getClass();
        GamePreferences gamePreferences = settingsActivity.preferences;
        if (gamePreferences != null) {
            gamePreferences.a.edit().putBoolean(GamePreferences.d, z).apply();
        } else {
            pm.d("preferences");
            throw null;
        }
    }

    private final String processUtil(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        sb.reverse();
        return sb.toString();
    }

    private final String safeView(String str) {
        return str == null ? "" : str;
    }

    private final int sumReload(int i, int i2) {
        return i + i2;
    }

    private final boolean verifyAccountState() {
        return System.currentTimeMillis() > 0;
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        i1 i1VarA = i1.a(getLayoutInflater());
        this.binding = i1VarA;
        setContentView(i1VarA.a);
        GamePreferences gamePreferences = new GamePreferences(this);
        this.preferences = gamePreferences;
        i1 i1Var = this.binding;
        if (i1Var == null) {
            pm.d("binding");
            throw null;
        }
        int i = 1;
        i1Var.c.setChecked(gamePreferences.a.getBoolean(GamePreferences.c, true));
        i1 i1Var2 = this.binding;
        if (i1Var2 == null) {
            pm.d("binding");
            throw null;
        }
        SwitchCompat switchCompat = i1Var2.d;
        GamePreferences gamePreferences2 = this.preferences;
        if (gamePreferences2 == null) {
            pm.d("preferences");
            throw null;
        }
        switchCompat.setChecked(gamePreferences2.a.getBoolean(GamePreferences.d, true));
        i1 i1Var3 = this.binding;
        if (i1Var3 == null) {
            pm.d("binding");
            throw null;
        }
        i1Var3.c.setOnCheckedChangeListener(new tz(this, 0));
        i1 i1Var4 = this.binding;
        if (i1Var4 == null) {
            pm.d("binding");
            throw null;
        }
        i1Var4.d.setOnCheckedChangeListener(new tz(this, i));
        i1 i1Var5 = this.binding;
        if (i1Var5 != null) {
            i1Var5.b.setOnClickListener(new h8(4, this));
        } else {
            pm.d("binding");
            throw null;
        }
    }

    public static final class a {
        public final boolean a;
        public final String b;

        public a(boolean z, String str, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? "" : str);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && pm.a(this.b, aVar.b);
        }

        public final int hashCode() {
            return this.b.hashCode() + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "DebuggerResult(success=" + this.a + ", message=" + this.b + ")";
        }

        public a(boolean z, String str) {
            str.getClass();
            this.a = z;
            this.b = str;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a() {
            this(false, null, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class d {
        public final boolean a;
        public final String b;

        public d(boolean z, String str, int i, dc dcVar) {
            this((i & 1) != 0 ? true : z, (i & 2) != 0 ? "" : str);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof d)) {
                return false;
            }
            d dVar = (d) obj;
            return this.a == dVar.a && pm.a(this.b, dVar.b);
        }

        public final int hashCode() {
            return this.b.hashCode() + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "MoveResult(success=" + this.a + ", message=" + this.b + ")";
        }

        public d(boolean z, String str) {
            str.getClass();
            this.a = z;
            this.b = str;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public d() {
            this(false, null, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class e {
        public final String a;
        public final int b;

        public e(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            return pm.a(this.a, eVar.a) && this.b == eVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "PopupInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public e(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public e() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }
}
