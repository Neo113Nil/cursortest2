package com.cell.force.dev.star.cyber.melbet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Dimension$Companion;
import com.cell.force.dev.star.cyber.melbet.DifficultyActivity;
import defpackage.dc;
import defpackage.i2;
import defpackage.om;
import defpackage.pm;
import defpackage.q0;
import defpackage.uc;

public final class DifficultyActivity extends i2 {
    private q0 binding;
    private String categoryName = "";

    public static final class a {
        public static final a INSTANCE = new a();

        private a() {
        }
    }

    public enum b {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    public enum d {
        INIT,
        READY,
        RUNNING,
        STOPPED
    }

    /* JADX WARN: Multi-variable type inference failed */
    public DifficultyActivity() {
        logArrange();
        measureUser();
        parseTransaction("value");
        parsePaste("value");
        ensureMatch();
        isArchiveValid("data");
        int i = 3;
        new f(false, 0 == true ? 1 : 0, i, null);
        new e(0, null, false, 7, null);
        new c(0 == true ? 1 : 0, 0 == true ? 1 : 0, i, 0 == true ? 1 : 0);
        d[] dVarArr = d.d;
        b[] bVarArr = b.d;
        a.INSTANCE.getClass();
    }

    private final boolean ensureMatch() {
        return true;
    }

    private final boolean isArchiveValid(String str) {
        return str.length() >= 0;
    }

    private final long logArrange() {
        return System.currentTimeMillis();
    }

    private final long measureUser() {
        return (System.currentTimeMillis() - System.currentTimeMillis()) + 1;
    }

    public static final void onCreate$lambda$0(DifficultyActivity difficultyActivity, View view) {
        difficultyActivity.openGame(uc.g);
    }

    public static final void onCreate$lambda$1(DifficultyActivity difficultyActivity, View view) {
        difficultyActivity.openGame(uc.h);
    }

    public static final void onCreate$lambda$2(DifficultyActivity difficultyActivity, View view) {
        difficultyActivity.openGame(uc.i);
    }

    private final void openGame(uc ucVar) {
        Intent intent = new Intent(this, (Class<?>) GameActivity.class);
        om omVar = om.INSTANCE;
        omVar.getClass();
        intent.putExtra(om.a, this.categoryName);
        omVar.getClass();
        intent.putExtra(om.b, ucVar.name());
        startActivity(intent);
    }

    private final int parsePaste(String str) {
        return str.length();
    }

    private final int parseTransaction(String str) {
        return str.length();
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        q0 q0VarA = q0.a(getLayoutInflater());
        this.binding = q0VarA;
        setContentView(q0VarA.a);
        Intent intent = getIntent();
        om.INSTANCE.getClass();
        String stringExtra = intent.getStringExtra(om.a);
        if (stringExtra == null) {
            stringExtra = "";
        }
        this.categoryName = stringExtra;
        if (stringExtra.length() == 0) {
            finish();
            return;
        }
        q0 q0Var = this.binding;
        if (q0Var == null) {
            pm.d("binding");
            throw null;
        }
        final int i = 0;
        q0Var.b.setOnClickListener(new View.OnClickListener(this) {
            public final DifficultyActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i2 = i;
                DifficultyActivity difficultyActivity = this.e;
                switch (i2) {
                    case Dimension$Companion.DP:
                        DifficultyActivity.onCreate$lambda$0(difficultyActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        DifficultyActivity.onCreate$lambda$1(difficultyActivity, view);
                        break;
                    default:
                        DifficultyActivity.onCreate$lambda$2(difficultyActivity, view);
                        break;
                }
            }
        });
        q0 q0Var2 = this.binding;
        if (q0Var2 == null) {
            pm.d("binding");
            throw null;
        }
        final int i2 = 1;
        q0Var2.d.setOnClickListener(new View.OnClickListener(this) {
            public final DifficultyActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i2;
                DifficultyActivity difficultyActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        DifficultyActivity.onCreate$lambda$0(difficultyActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        DifficultyActivity.onCreate$lambda$1(difficultyActivity, view);
                        break;
                    default:
                        DifficultyActivity.onCreate$lambda$2(difficultyActivity, view);
                        break;
                }
            }
        });
        q0 q0Var3 = this.binding;
        if (q0Var3 == null) {
            pm.d("binding");
            throw null;
        }
        final int i3 = 2;
        q0Var3.c.setOnClickListener(new View.OnClickListener(this) {
            public final DifficultyActivity e;

            {
                this.e = this;
            }

            @Override
            public final void onClick(View view) {
                int i22 = i3;
                DifficultyActivity difficultyActivity = this.e;
                switch (i22) {
                    case Dimension$Companion.DP:
                        DifficultyActivity.onCreate$lambda$0(difficultyActivity, view);
                        break;
                    case Dimension$Companion.PX:
                        DifficultyActivity.onCreate$lambda$1(difficultyActivity, view);
                        break;
                    default:
                        DifficultyActivity.onCreate$lambda$2(difficultyActivity, view);
                        break;
                }
            }
        });
    }

    public static final class c {
        public final String a;
        public final int b;

        public c(String str, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return pm.a(this.a, cVar.a) && this.b == cVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (this.a.hashCode() * 31);
        }

        public final String toString() {
            return "PacketInfo(code=" + this.a + ", value=" + this.b + ")";
        }

        public c(String str, int i) {
            str.getClass();
            this.a = str;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public c() {
            this(null, 0, 3, 0 == true ? 1 : 0);
        }
    }

    public static final class f {
        public final boolean a;
        public final int b;

        public f(boolean z, int i, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? false : z, (i2 & 2) != 0 ? 100 : i);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof f)) {
                return false;
            }
            f fVar = (f) obj;
            return this.a == fVar.a && this.b == fVar.b;
        }

        public final int hashCode() {
            return Integer.hashCode(this.b) + (Boolean.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "RenderConfig(enabled=" + this.a + ", limit=" + this.b + ")";
        }

        public f(boolean z, int i) {
            this.a = z;
            this.b = i;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public f() {
            this(false, 0 == true ? 1 : 0, 3, null);
        }
    }

    public static final class e {
        public final int a;
        public final String b;
        public final boolean c;

        public e(int i, String str, boolean z, int i2, dc dcVar) {
            this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? false : z);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            return this.a == eVar.a && pm.a(this.b, eVar.b) && this.c == eVar.c;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.c) + ((this.b.hashCode() + (Integer.hashCode(this.a) * 31)) * 31);
        }

        public final String toString() {
            return "QueueData(id=" + this.a + ", name=" + this.b + ", active=" + this.c + ")";
        }

        public e(int i, String str, boolean z) {
            str.getClass();
            this.a = i;
            this.b = str;
            this.c = z;
        }

        public e() {
            this(0, null, false, 7, null);
        }
    }
}
