package com.net.soft.delta.beta.alpha.melbet;

import android.graphics.Canvas;
import android.graphics.Paint;
import defpackage.dp;
import defpackage.jm;
import java.util.ArrayList;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class d {
    public final ArrayList a = new ArrayList();

    public final void a(Canvas canvas, Paint paint) {
        Canvas canvas2;
        Paint paint2;
        paint.getClass();
        ArrayList arrayList = this.a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            c cVar = (c) obj;
            int i2 = cVar.g;
            float f = cVar.f;
            paint.setColor(i2);
            paint.setAlpha(dp.p((int) (cVar.e * 255.0f), 255));
            int iOrdinal = cVar.j.ordinal();
            if (iOrdinal == 0) {
                canvas2 = canvas;
                paint2 = paint;
                canvas2.drawCircle(cVar.a, cVar.b, f, paint2);
            } else {
                if (iOrdinal != 1) {
                    throw new jm();
                }
                canvas.save();
                canvas.rotate(cVar.h, cVar.a, cVar.b);
                float f2 = cVar.a;
                float f3 = cVar.b;
                canvas2 = canvas;
                paint2 = paint;
                canvas2.drawRect(f2 - f, f3 - f, f2 + f, f3 + f, paint2);
                canvas2.restore();
            }
            canvas = canvas2;
            paint = paint2;
        }
    }
}
