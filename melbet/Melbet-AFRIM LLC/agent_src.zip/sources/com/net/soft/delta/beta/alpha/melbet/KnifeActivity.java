package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import defpackage.ai;
import defpackage.d2;
import defpackage.f0;
import defpackage.ko;
import defpackage.qm;
import defpackage.tf;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class KnifeActivity extends d2 {
    public f0 C;
    public com.net.soft.delta.beta.alpha.melbet.b D;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("AUTO", 0), new a("MANUAL", 1), new a("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("NONE", 0), new b("DEFAULT", 1), new b("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c {
        public static final /* synthetic */ c[] a = {new c("NONE", 0), new c("DEFAULT", 1), new c("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        c EF5;

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) a.clone();
        }
    }

    public KnifeActivity() {
        Math.abs(63);
        System.currentTimeMillis();
        ((3 & 1) != 0 ? "" : null).getClass();
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_knife, (ViewGroup) null, false);
        KnifeView knifeView = (KnifeView) ko.i(viewInflate, R.id.knifeView);
        if (knifeView == null) {
            qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.knifeView)));
            return;
        }
        FrameLayout frameLayout = (FrameLayout) viewInflate;
        this.C = new f0(frameLayout, knifeView);
        setContentView(frameLayout);
        f0 f0Var = this.C;
        if (f0Var == null) {
            ai.d("binding");
            throw null;
        }
        KnifeView knifeView2 = (KnifeView) f0Var.a;
        String str = tf.e;
        com.net.soft.delta.beta.alpha.melbet.b bVar = new com.net.soft.delta.beta.alpha.melbet.b(this, knifeView2, str, str);
        this.D = bVar;
        bVar.i();
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar == null) {
            ai.d("binder");
            throw null;
        }
        bVar.b.k();
        bVar.f.f();
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onPause() {
        super.onPause();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar != null) {
            bVar.j();
        } else {
            ai.d("binder");
            throw null;
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar != null) {
            bVar.k();
        } else {
            ai.d("binder");
            throw null;
        }
    }
}
