package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import defpackage.j3;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class WeekBarView extends View {
    public static final /* synthetic */ int e = 0;
    public final Paint a;
    public final Paint b;
    public final float[] c;
    public final float[] d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public WeekBarView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.a = new Paint(1);
        Paint paint = new Paint(1);
        paint.setColor(context.getColor(R.color.text_secondary));
        paint.setTextAlign(Paint.Align.CENTER);
        this.b = paint;
        this.c = new float[7];
        this.d = new float[7];
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        canvas.getClass();
        super.onDraw(canvas);
        float width = getWidth() / 10.0f;
        float width2 = (getWidth() - (7.0f * width)) / 8.0f;
        float height = getHeight();
        Resources resources = getResources();
        resources.getClass();
        float fP = height - j3.p(resources, 24.0f);
        int color = getContext().getColor(R.color.colorAccent);
        Paint paint = this.a;
        paint.setColor(color);
        Resources resources2 = getResources();
        resources2.getClass();
        float fP2 = j3.p(resources2, 11.0f);
        Paint paint2 = this.b;
        paint2.setTextSize(fP2);
        int i = 0;
        while (i < 7) {
            float f = ((width + width2) * i) + width2;
            float f2 = this.d[i] * fP;
            float height2 = getHeight();
            Resources resources3 = getResources();
            resources3.getClass();
            float height3 = getHeight();
            Resources resources4 = getResources();
            resources4.getClass();
            float fP3 = height3 - j3.p(resources4, 18.0f);
            Resources resources5 = getResources();
            resources5.getClass();
            float fP4 = j3.p(resources5, 6.0f);
            Resources resources6 = getResources();
            resources6.getClass();
            Canvas canvas2 = canvas;
            canvas2.drawRoundRect(f, (height2 - j3.p(resources3, 18.0f)) - f2, f + width, fP3, fP4, j3.p(resources6, 6.0f), paint);
            i++;
            String strValueOf = String.valueOf(i);
            float f3 = (width / 2.0f) + f;
            float height4 = getHeight();
            Resources resources7 = getResources();
            resources7.getClass();
            canvas2.drawText(strValueOf, f3, height4 - j3.p(resources7, 4.0f), paint2);
            canvas = canvas2;
        }
    }
}
