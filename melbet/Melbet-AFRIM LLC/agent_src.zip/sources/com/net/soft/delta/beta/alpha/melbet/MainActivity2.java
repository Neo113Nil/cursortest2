package com.net.soft.delta.beta.alpha.melbet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.net.soft.delta.beta.alpha.melbet.AchievementsActivity;
import com.net.soft.delta.beta.alpha.melbet.BubbleActivity;
import com.net.soft.delta.beta.alpha.melbet.ColorActivity;
import com.net.soft.delta.beta.alpha.melbet.DailyActivity;
import com.net.soft.delta.beta.alpha.melbet.KnifeActivity;
import com.net.soft.delta.beta.alpha.melbet.LeaderboardActivity;
import com.net.soft.delta.beta.alpha.melbet.MainActivity2;
import com.net.soft.delta.beta.alpha.melbet.PianoActivity;
import com.net.soft.delta.beta.alpha.melbet.SettingsActivity;
import com.net.soft.delta.beta.alpha.melbet.ShopActivity;
import com.net.soft.delta.beta.alpha.melbet.StatsActivity;
import defpackage.ai;
import defpackage.d2;
import defpackage.k0;
import defpackage.ko;
import defpackage.q7;
import defpackage.qm;
import defpackage.tf;
import defpackage.uf;
import defpackage.v6;
import defpackage.y;
import defpackage.z2;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class MainActivity2 extends d2 {
    public static final /* synthetic */ int F = 0;
    public k0 C;
    public uf D;
    public z2 E;

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main2, (ViewGroup) null, false);
        int i2 = R.id.btnAchievements;
        Button button = (Button) ko.i(viewInflate, R.id.btnAchievements);
        if (button != null) {
            i2 = R.id.btnDaily;
            Button button2 = (Button) ko.i(viewInflate, R.id.btnDaily);
            if (button2 != null) {
                i2 = R.id.btnPlayBubble;
                Button button3 = (Button) ko.i(viewInflate, R.id.btnPlayBubble);
                if (button3 != null) {
                    i2 = R.id.btnPlayColor;
                    Button button4 = (Button) ko.i(viewInflate, R.id.btnPlayColor);
                    if (button4 != null) {
                        i2 = R.id.btnPlayKnife;
                        Button button5 = (Button) ko.i(viewInflate, R.id.btnPlayKnife);
                        if (button5 != null) {
                            i2 = R.id.btnPlayPiano;
                            Button button6 = (Button) ko.i(viewInflate, R.id.btnPlayPiano);
                            if (button6 != null) {
                                i2 = R.id.btnRecords;
                                Button button7 = (Button) ko.i(viewInflate, R.id.btnRecords);
                                if (button7 != null) {
                                    i2 = R.id.btnSettings;
                                    Button button8 = (Button) ko.i(viewInflate, R.id.btnSettings);
                                    if (button8 != null) {
                                        i2 = R.id.btnShop;
                                        Button button9 = (Button) ko.i(viewInflate, R.id.btnShop);
                                        if (button9 != null) {
                                            i2 = R.id.btnStats;
                                            Button button10 = (Button) ko.i(viewInflate, R.id.btnStats);
                                            if (button10 != null) {
                                                i2 = R.id.cardBubble;
                                                CardView cardView = (CardView) ko.i(viewInflate, R.id.cardBubble);
                                                if (cardView != null) {
                                                    i2 = R.id.cardColor;
                                                    CardView cardView2 = (CardView) ko.i(viewInflate, R.id.cardColor);
                                                    if (cardView2 != null) {
                                                        i2 = R.id.cardKnife;
                                                        CardView cardView3 = (CardView) ko.i(viewInflate, R.id.cardKnife);
                                                        if (cardView3 != null) {
                                                            i2 = R.id.cardPiano;
                                                            CardView cardView4 = (CardView) ko.i(viewInflate, R.id.cardPiano);
                                                            if (cardView4 != null) {
                                                                i2 = R.id.imgLogo;
                                                                if (((ImageView) ko.i(viewInflate, R.id.imgLogo)) != null) {
                                                                    i2 = R.id.tvBubbleRecord;
                                                                    TextView textView = (TextView) ko.i(viewInflate, R.id.tvBubbleRecord);
                                                                    if (textView != null) {
                                                                        i2 = R.id.tvColorRecord;
                                                                        TextView textView2 = (TextView) ko.i(viewInflate, R.id.tvColorRecord);
                                                                        if (textView2 != null) {
                                                                            i2 = R.id.tvHubCoins;
                                                                            TextView textView3 = (TextView) ko.i(viewInflate, R.id.tvHubCoins);
                                                                            if (textView3 != null) {
                                                                                i2 = R.id.tvHubRecord;
                                                                                TextView textView4 = (TextView) ko.i(viewInflate, R.id.tvHubRecord);
                                                                                if (textView4 != null) {
                                                                                    i2 = R.id.tvHubStreak;
                                                                                    TextView textView5 = (TextView) ko.i(viewInflate, R.id.tvHubStreak);
                                                                                    if (textView5 != null) {
                                                                                        i2 = R.id.tvKnifeRecord;
                                                                                        TextView textView6 = (TextView) ko.i(viewInflate, R.id.tvKnifeRecord);
                                                                                        if (textView6 != null) {
                                                                                            i2 = R.id.tvPianoRecord;
                                                                                            TextView textView7 = (TextView) ko.i(viewInflate, R.id.tvPianoRecord);
                                                                                            if (textView7 != null) {
                                                                                                FrameLayout frameLayout = (FrameLayout) viewInflate;
                                                                                                this.C = new k0(frameLayout, button, button2, button3, button4, button5, button6, button7, button8, button9, button10, cardView, cardView2, cardView3, cardView4, textView, textView2, textView3, textView4, textView5, textView6, textView7);
                                                                                                setContentView(frameLayout);
                                                                                                uf ufVar = new uf(this);
                                                                                                this.D = ufVar;
                                                                                                z2 z2Var = new z2(ufVar);
                                                                                                this.E = z2Var;
                                                                                                z2Var.e();
                                                                                                k0 k0Var = this.C;
                                                                                                if (k0Var == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                k0Var.f.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i3 = i;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i3) {
                                                                                                            case 0:
                                                                                                                int i4 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i5 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i6 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i7 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var2 = this.C;
                                                                                                if (k0Var2 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i3 = 9;
                                                                                                k0Var2.c.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i3;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i4 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i5 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i6 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i7 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var3 = this.C;
                                                                                                if (k0Var3 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i4 = 10;
                                                                                                k0Var3.e.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i4;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i5 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i6 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i7 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var4 = this.C;
                                                                                                if (k0Var4 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i5 = 11;
                                                                                                k0Var4.d.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i5;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i6 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i7 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var5 = this.C;
                                                                                                if (k0Var5 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i6 = 12;
                                                                                                k0Var5.n.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i6;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i7 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var6 = this.C;
                                                                                                if (k0Var6 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i7 = 13;
                                                                                                k0Var6.k.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i7;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i8 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var7 = this.C;
                                                                                                if (k0Var7 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i8 = 1;
                                                                                                k0Var7.m.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i8;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i9 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var8 = this.C;
                                                                                                if (k0Var8 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i9 = 2;
                                                                                                k0Var8.l.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i9;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i10 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var9 = this.C;
                                                                                                if (k0Var9 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i10 = 3;
                                                                                                k0Var9.g.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i10;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i11 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var10 = this.C;
                                                                                                if (k0Var10 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i11 = 4;
                                                                                                k0Var10.a.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i11;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i112 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i12 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var11 = this.C;
                                                                                                if (k0Var11 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i12 = 5;
                                                                                                k0Var11.i.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i12;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i112 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i122 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i13 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var12 = this.C;
                                                                                                if (k0Var12 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i13 = 6;
                                                                                                k0Var12.j.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i13;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i112 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i122 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i132 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i14 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var13 = this.C;
                                                                                                if (k0Var13 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i14 = 7;
                                                                                                k0Var13.b.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i14;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i112 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i122 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i132 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i142 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i15 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                k0 k0Var14 = this.C;
                                                                                                if (k0Var14 == null) {
                                                                                                    ai.d("binding");
                                                                                                    throw null;
                                                                                                }
                                                                                                final int i15 = 8;
                                                                                                k0Var14.h.setOnClickListener(new View.OnClickListener(this) { // from class: pj
                                                                                                    public final /* synthetic */ MainActivity2 b;

                                                                                                    {
                                                                                                        this.b = this;
                                                                                                    }

                                                                                                    @Override // android.view.View.OnClickListener
                                                                                                    public final void onClick(View view) {
                                                                                                        int i32 = i15;
                                                                                                        MainActivity2 mainActivity2 = this.b;
                                                                                                        switch (i32) {
                                                                                                            case 0:
                                                                                                                int i42 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                int i52 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                int i62 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                int i72 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) LeaderboardActivity.class));
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                int i82 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) AchievementsActivity.class));
                                                                                                                break;
                                                                                                            case 5:
                                                                                                                int i92 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) ShopActivity.class));
                                                                                                                break;
                                                                                                            case 6:
                                                                                                                int i102 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) StatsActivity.class));
                                                                                                                break;
                                                                                                            case 7:
                                                                                                                int i112 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) DailyActivity.class));
                                                                                                                break;
                                                                                                            case 8:
                                                                                                                int i122 = MainActivity2.F;
                                                                                                                mainActivity2.startActivity(new Intent(mainActivity2, (Class<?>) SettingsActivity.class));
                                                                                                                break;
                                                                                                            case 9:
                                                                                                                int i132 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                            case 10:
                                                                                                                int i142 = MainActivity2.F;
                                                                                                                mainActivity2.x(KnifeActivity.class);
                                                                                                                break;
                                                                                                            case 11:
                                                                                                                int i152 = MainActivity2.F;
                                                                                                                mainActivity2.x(ColorActivity.class);
                                                                                                                break;
                                                                                                            case 12:
                                                                                                                int i16 = MainActivity2.F;
                                                                                                                mainActivity2.x(PianoActivity.class);
                                                                                                                break;
                                                                                                            default:
                                                                                                                int i17 = MainActivity2.F;
                                                                                                                mainActivity2.x(BubbleActivity.class);
                                                                                                                break;
                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                                uf ufVar2 = this.D;
                                                                                                if (ufVar2 == null) {
                                                                                                    ai.d("prefs");
                                                                                                    throw null;
                                                                                                }
                                                                                                if (ufVar2.a.getBoolean("menu_animations", true)) {
                                                                                                    k0 k0Var15 = this.C;
                                                                                                    if (k0Var15 == null) {
                                                                                                        ai.d("binding");
                                                                                                        throw null;
                                                                                                    }
                                                                                                    for (Object obj : q7.Q(k0Var15.n, k0Var15.k, k0Var15.m, k0Var15.l)) {
                                                                                                        int i16 = i + 1;
                                                                                                        if (i < 0) {
                                                                                                            q7.R();
                                                                                                            throw null;
                                                                                                        }
                                                                                                        CardView cardView5 = (CardView) obj;
                                                                                                        cardView5.setAlpha(0.0f);
                                                                                                        cardView5.setScaleX(0.85f);
                                                                                                        cardView5.setScaleY(0.85f);
                                                                                                        cardView5.animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setStartDelay(i * 80).setDuration(350L).start();
                                                                                                        i = i16;
                                                                                                    }
                                                                                                    return;
                                                                                                }
                                                                                                return;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        z2 z2Var = this.E;
        if (z2Var != null) {
            z2Var.f();
        } else {
            ai.d("sound");
            throw null;
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        k0 k0Var = this.C;
        if (k0Var == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView = k0Var.r;
        List<y> list = v6.a;
        uf ufVar = this.D;
        if (ufVar == null) {
            ai.d("prefs");
            throw null;
        }
        Iterator<T> it = tf.m.iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException();
        }
        int iD = ufVar.d((String) it.next());
        while (it.hasNext()) {
            int iD2 = ufVar.d((String) it.next());
            if (iD < iD2) {
                iD = iD2;
            }
        }
        textView.setText(getString(R.string.record_label, Integer.valueOf(iD)));
        k0 k0Var2 = this.C;
        if (k0Var2 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView2 = k0Var2.q;
        uf ufVar2 = this.D;
        if (ufVar2 == null) {
            ai.d("prefs");
            throw null;
        }
        textView2.setText(getString(R.string.coins_label, Integer.valueOf(ufVar2.a.getInt("total_coins", 0))));
        k0 k0Var3 = this.C;
        if (k0Var3 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView3 = k0Var3.s;
        uf ufVar3 = this.D;
        if (ufVar3 == null) {
            ai.d("prefs");
            throw null;
        }
        textView3.setText(getString(R.string.streak_label, Integer.valueOf(ufVar3.a.getInt("streak_days", 0))));
        uf ufVar4 = this.D;
        if (ufVar4 == null) {
            ai.d("prefs");
            throw null;
        }
        int iD3 = ufVar4.d(tf.b);
        uf ufVar5 = this.D;
        if (ufVar5 == null) {
            ai.d("prefs");
            throw null;
        }
        int iMax = Math.max(iD3, ufVar5.d(tf.c));
        k0 k0Var4 = this.C;
        if (k0Var4 == null) {
            ai.d("binding");
            throw null;
        }
        k0Var4.u.setText(getString(R.string.game_record, Integer.valueOf(iMax)));
        k0 k0Var5 = this.C;
        if (k0Var5 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView4 = k0Var5.o;
        uf ufVar6 = this.D;
        if (ufVar6 == null) {
            ai.d("prefs");
            throw null;
        }
        textView4.setText(getString(R.string.game_record, Integer.valueOf(ufVar6.d(tf.d))));
        k0 k0Var6 = this.C;
        if (k0Var6 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView5 = k0Var6.t;
        uf ufVar7 = this.D;
        if (ufVar7 == null) {
            ai.d("prefs");
            throw null;
        }
        textView5.setText(getString(R.string.game_record, Integer.valueOf(ufVar7.d(tf.e))));
        k0 k0Var7 = this.C;
        if (k0Var7 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView6 = k0Var7.p;
        uf ufVar8 = this.D;
        if (ufVar8 != null) {
            textView6.setText(getString(R.string.game_record, Integer.valueOf(ufVar8.d(tf.f))));
        } else {
            ai.d("prefs");
            throw null;
        }
    }

    public final void x(Class<?> cls) {
        z2 z2Var = this.E;
        if (z2Var == null) {
            ai.d("sound");
            throw null;
        }
        z2Var.d(1, 40);
        startActivity(new Intent(this, cls));
    }
}
