package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.net.soft.delta.beta.alpha.melbet.c;
import defpackage.c4;
import defpackage.cp;
import defpackage.dp;
import defpackage.ed;
import defpackage.j3;
import defpackage.k;
import defpackage.nn;
import defpackage.q7;
import defpackage.sf;
import defpackage.tf;
import defpackage.v4;
import defpackage.v5;
import defpackage.v6;
import defpackage.y;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class BubbleView extends com.net.soft.delta.beta.alpha.melbet.a {
    public static final /* synthetic */ int c0 = 0;
    public boolean A;
    public int B;
    public int C;
    public int D;
    public int E;
    public boolean F;
    public float G;
    public int H;
    public int I;
    public int J;
    public boolean K;
    public boolean L;
    public int M;
    public int N;
    public float O;
    public float P;
    public float Q;
    public float R;
    public final Paint S;
    public final Path T;
    public final RectF U;
    public final int V;
    public final int W;
    public final int a0;
    public final int b0;
    public final ArrayList w;
    public final ArrayList x;
    public c y;
    public float z;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final b a;
        public static final b b;
        public static final b c;
        public static final b d;
        public static final /* synthetic */ b[] e;

        static {
            b bVar = new b("NORMAL", 0);
            a = bVar;
            b bVar2 = new b("BOMB", 1);
            b = bVar2;
            b bVar3 = new b("RAINBOW", 2);
            c = bVar3;
            b bVar4 = new b("ICE", 3);
            d = bVar4;
            e = new b[]{bVar, bVar2, bVar3, bVar4};
        }

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) e.clone();
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c {
        public float a;
        public float b;
        public float c;
        public float d;
        public int e;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return Float.compare(this.a, cVar.a) == 0 && Float.compare(this.b, cVar.b) == 0 && Float.compare(this.c, cVar.c) == 0 && Float.compare(this.d, cVar.d) == 0 && this.e == cVar.e;
        }

        public final int hashCode() {
            return b.a.hashCode() + ed.c(this.e, ed.a(this.d, ed.a(this.c, ed.a(this.b, Float.hashCode(this.a) * 31, 31), 31), 31), 31);
        }

        public final String toString() {
            return "Shot(posX=" + this.a + ", posY=" + this.b + ", velX=" + this.c + ", velY=" + this.d + ", colorIndex=" + this.e + ", kind=" + b.a + ")";
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public BubbleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.w = new ArrayList();
        this.x = new ArrayList();
        this.z = -1.5707964f;
        this.C = 1;
        this.D = 30;
        this.E = 1;
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        paint.setPathEffect(new DashPathEffect(new float[]{16.0f, 12.0f}, 0.0f));
        this.S = paint;
        this.T = new Path();
        this.U = new RectF();
        this.V = context.getColor(R.color.colorPrimary);
        this.W = context.getColor(R.color.colorAim);
        this.a0 = context.getColor(R.color.colorRed);
        this.b0 = context.getColor(R.color.colorStar);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void b() {
        this.F = false;
        setPaused(false);
        int i = this.E;
        this.E = i + 1;
        this.D += 8;
        r(Math.min(10, i + 6));
        g();
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final int e() {
        return this.D;
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void h(Canvas canvas) {
        Integer num;
        Canvas canvas2;
        canvas.drawColor(this.V);
        float width = getWidth() > 0 ? getWidth() / 10.0f : 40.0f;
        this.O = width;
        this.P = width / 2.0f;
        this.R = getWidth() / 2.0f;
        this.Q = getHeight() - (52.0f * ed.d(this).density);
        float fN = n(10);
        getStrokePaint().setColor(this.a0);
        Paint strokePaint = getStrokePaint();
        ArrayList arrayList = this.w;
        Iterator it = arrayList.iterator();
        if (it.hasNext()) {
            Integer numValueOf = Integer.valueOf(((a) it.next()).b);
            while (it.hasNext()) {
                Integer numValueOf2 = Integer.valueOf(((a) it.next()).b);
                if (numValueOf.compareTo(numValueOf2) < 0) {
                    numValueOf = numValueOf2;
                }
            }
            num = numValueOf;
        } else {
            num = null;
        }
        int i = 0;
        strokePaint.setAlpha((num != null ? num.intValue() : 0) >= 8 ? (int) (((Math.sin(this.G) * 0.4d) + 0.6d) * 255.0d) : 80);
        getStrokePaint().setStrokeWidth(3.0f * ed.d(this).density);
        canvas.drawLine(0.0f, fN, getWidth(), fN, getStrokePaint());
        getStrokePaint().setAlpha(255);
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            int i3 = i2 + 1;
            a aVar = (a) arrayList.get(i2);
            int i4 = aVar.a;
            int i5 = aVar.b;
            q(canvas, m(i4, i5), n(i5), this.P * 0.92f, o(aVar.c), aVar.d);
            i2 = i3;
        }
        ArrayList arrayList2 = this.x;
        int size2 = arrayList2.size();
        int i6 = 0;
        while (i6 < size2) {
            int i7 = i6 + 1;
            a aVar2 = (a) arrayList2.get(i6);
            Paint fillPaint = getFillPaint();
            float f = aVar2.h;
            int i8 = aVar2.b;
            fillPaint.setAlpha(dp.p((int) (f * 255.0f), 255));
            q(canvas, m(aVar2.a, i8), n(i8) + aVar2.g, this.P * 0.92f, o(aVar2.c), aVar2.d);
            getFillPaint().setAlpha(255);
            i6 = i7;
        }
        c cVar = this.y;
        b bVar = b.a;
        if (cVar != null) {
            float f2 = cVar.a;
            float f3 = cVar.b;
            float f4 = this.P;
            int iO = o(cVar.e);
            canvas2 = canvas;
            q(canvas2, f2, f3, f4, iO, bVar);
        } else {
            canvas2 = canvas;
        }
        canvas2.save();
        canvas2.translate(this.R, this.Q);
        canvas2.rotate(((float) Math.toDegrees(this.z)) + 90.0f);
        getFillPaint().setColor(getContext().getColor(R.color.colorCardElevated));
        float f5 = -(ed.d(this).density * 22.0f);
        float f6 = -(ed.d(this).density * 16.0f);
        float f7 = 22.0f * ed.d(this).density;
        float f8 = 18.0f * ed.d(this).density;
        RectF rectF = this.U;
        rectF.set(f5, f6, f7, f8);
        canvas2.drawRoundRect(rectF, ed.d(this).density * 8.0f, ed.d(this).density * 8.0f, getFillPaint());
        Path path = this.T;
        path.reset();
        Resources resources = getResources();
        resources.getClass();
        path.moveTo(-(resources.getDisplayMetrics().density * 8.0f), -(ed.d(this).density * 16.0f));
        Resources resources2 = getResources();
        resources2.getClass();
        path.lineTo(0.0f, -(resources2.getDisplayMetrics().density * 38.0f));
        Resources resources3 = getResources();
        resources3.getClass();
        path.lineTo(8.0f * resources3.getDisplayMetrics().density, -(16.0f * ed.d(this).density));
        path.close();
        getFillPaint().setColor(getContext().getColor(R.color.colorAccent));
        canvas2.drawPath(path, getFillPaint());
        canvas2.restore();
        q(canvas2, this.R, this.Q - (ed.d(this).density * 38.0f), this.P * 0.85f, o(this.B), bVar);
        q(canvas, (42.0f * ed.d(this).density) + this.R, (4.0f * ed.d(this).density) + this.Q, 0.45f * this.P, o(this.C), bVar);
        if (this.A && getPrefs().a.getBoolean("aim_line", true) && this.y == null) {
            int i9 = this.W;
            Paint paint = this.S;
            paint.setColor(i9);
            paint.setAlpha(153);
            Resources resources4 = getResources();
            resources4.getClass();
            paint.setStrokeWidth(2.0f * resources4.getDisplayMetrics().density);
            float f9 = this.R;
            float f10 = this.Q - (38.0f * ed.d(this).density);
            float fCos = (float) Math.cos(this.z);
            float fSin = (float) Math.sin(this.z);
            float f11 = 12.0f * ed.d(this).density;
            float f12 = f9;
            float fAbs = fCos;
            float f13 = f10;
            while (i < 70) {
                float width2 = (fAbs * f11) + f12;
                float f14 = (fSin * f11) + f13;
                float f15 = this.P;
                if (width2 < f15) {
                    fAbs = Math.abs(fAbs);
                    width2 = f15;
                } else if (width2 > getWidth() - this.P) {
                    width2 = getWidth() - this.P;
                    fAbs = -Math.abs(fAbs);
                }
                float f16 = fAbs;
                canvas.drawLine(f12, f13, width2, f14, paint);
                f12 = width2;
                a aVarT = t(f12, f14);
                if (f14 <= this.P) {
                    return;
                }
                if (aVarT != null && p(f12, f14, aVarT) < this.O * 0.9f) {
                    return;
                }
                i++;
                f13 = f14;
                fAbs = f16;
            }
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void i() {
        k();
        this.w.clear();
        this.x.clear();
        getParticles().a.clear();
        this.y = null;
        setScore(0);
        setSessionCoins(0);
        this.D = 30;
        this.E = 1;
        this.F = false;
        this.H = 0;
        this.I = 0;
        this.J = 0;
        this.K = false;
        this.L = false;
        this.M = 0;
        this.N = 0;
        setGameOver(false);
        setPaused(false);
        setFlashAlpha(0.0f);
        cp.a.getClass();
        k kVar = cp.b;
        this.B = kVar.e(5);
        this.C = kVar.e(5);
        r(Math.min(10, this.E + 5));
        g();
        j();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x024b  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0265  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x02bb  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x02fd A[LOOP:8: B:126:0x02fb->B:127:0x02fd, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:130:0x033a  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x0352 A[LOOP:10: B:134:0x0350->B:135:0x0352, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:138:0x0367  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x0396  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x03af A[LOOP:14: B:149:0x03ad->B:150:0x03af, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:153:0x0415  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x0441  */
    /* JADX WARN: Removed duplicated region for block: B:180:0x0152 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0144  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x01f9  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x0208  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0220 A[LOOP:7: B:94:0x021e->B:95:0x0220, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x023f  */
    @Override // com.net.soft.delta.beta.alpha.melbet.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void l(float f) {
        float f2;
        int i;
        boolean z;
        int size;
        int i2;
        int size2;
        int i3;
        ArrayList arrayList;
        int size3;
        int i4;
        int i5;
        int size4;
        int i6;
        c4 c4Var;
        int size5;
        int i7;
        int size6;
        int i8;
        int size7;
        int i9;
        int size8;
        int score;
        int i10;
        float f3;
        float f4;
        float fHypot;
        c.a aVar = c.a.a;
        b bVar = b.d;
        b bVar2 = b.b;
        if (getWidth() <= 0 || getHeight() <= 0 || this.F) {
            return;
        }
        float width = getWidth() / 10.0f;
        this.O = width;
        float f5 = 2.0f;
        this.P = width / 2.0f;
        this.R = getWidth() / 2.0f;
        this.Q = getHeight() - (52.0f * ed.d(this).density);
        this.G = (4.0f * f) + this.G;
        c cVar = this.y;
        if (cVar != null) {
            float f6 = cVar.a;
            float f7 = cVar.c;
            float f8 = (f7 * f) + f6;
            cVar.a = f8;
            cVar.b = (cVar.d * f) + cVar.b;
            float f9 = this.P;
            if (f8 < f9) {
                cVar.a = f9;
                cVar.c = Math.abs(f7);
            } else if (f8 > getWidth() - this.P) {
                cVar.a = getWidth() - this.P;
                cVar.c = -Math.abs(cVar.c);
            }
            float f10 = cVar.b;
            int i11 = 1;
            int i12 = 0;
            boolean z2 = f10 <= this.P;
            a aVarT = t(cVar.a, f10);
            if (z2 || (aVarT != null && p(cVar.a, cVar.b, aVarT) < this.O * 0.92f)) {
                ArrayList arrayList2 = this.w;
                float f11 = cVar.a;
                float f12 = cVar.b;
                nn nnVar = new nn(0, 0);
                float f13 = Float.MAX_VALUE;
                int i13 = 0;
                while (true) {
                    f2 = f5;
                    if (i13 >= 13) {
                        break;
                    }
                    i = i13 % 2 == i11 ? 9 : 10;
                    int i14 = i12;
                    while (i14 < i) {
                        if (arrayList2 == null || !arrayList2.isEmpty()) {
                            int size9 = arrayList2.size();
                            while (i12 < size9) {
                                Object obj = arrayList2.get(i12);
                                i12++;
                                a aVar2 = (a) obj;
                                f3 = f11;
                                if (aVar2.a == i14 && aVar2.b == i13) {
                                    f4 = f12;
                                    break;
                                }
                                f11 = f3;
                            }
                            f3 = f11;
                            f4 = f12;
                            fHypot = (float) Math.hypot(f3 - m(i14, i13), f12 - n(i13));
                            if (fHypot >= f13) {
                                nnVar = new nn(Integer.valueOf(i14), Integer.valueOf(i13));
                                f13 = fHypot;
                            }
                        } else {
                            f3 = f11;
                            f4 = f12;
                            fHypot = (float) Math.hypot(f3 - m(i14, i13), f12 - n(i13));
                            if (fHypot >= f13) {
                            }
                        }
                        i14++;
                        f12 = f4;
                        f11 = f3;
                        i12 = 0;
                    }
                    i13++;
                    f5 = f2;
                    i11 = 1;
                    i12 = 0;
                }
                int iIntValue = ((Number) nnVar.a).intValue();
                int iIntValue2 = ((Number) nnVar.b).intValue();
                a aVar3 = new a(iIntValue, iIntValue2, cVar.e, b.a);
                arrayList2.add(aVar3);
                if (iIntValue2 >= 10) {
                    s();
                } else {
                    int i15 = aVar3.c;
                    aVar3.c = i15;
                    LinkedHashSet linkedHashSet = new LinkedHashSet();
                    c4 c4Var2 = new c4();
                    c4Var2.addLast(aVar3);
                    linkedHashSet.add(aVar3);
                    while (!c4Var2.isEmpty()) {
                        a aVar4 = (a) c4Var2.removeFirst();
                        ArrayList arrayListU = u(aVar4);
                        int size10 = arrayListU.size();
                        int i16 = 0;
                        while (i16 < size10) {
                            Object obj2 = arrayListU.get(i16);
                            i16++;
                            a aVar5 = (a) obj2;
                            if (aVar5.c != i15) {
                                b bVar3 = aVar5.d;
                                b bVar4 = b.c;
                                if (bVar3 == bVar4 || aVar4.d == bVar4) {
                                }
                            }
                            if (linkedHashSet.add(aVar5)) {
                                c4Var2.addLast(aVar5);
                            }
                        }
                    }
                    ArrayList arrayList3 = new ArrayList(linkedHashSet);
                    if (arrayList3.isEmpty()) {
                        z = false;
                        if (z) {
                            this.K = true;
                        }
                        ArrayList arrayList4 = new ArrayList();
                        size = arrayList3.size();
                        i2 = 0;
                        while (i2 < size) {
                            Object obj3 = arrayList3.get(i2);
                            i2++;
                            if (((a) obj3).d == bVar) {
                                arrayList4.add(obj3);
                            }
                        }
                        size2 = arrayList4.size();
                        i3 = 0;
                        while (i3 < size2) {
                            Object obj4 = arrayList4.get(i3);
                            i3++;
                            a aVar6 = (a) obj4;
                            aVar6.e--;
                        }
                        arrayList = new ArrayList();
                        int i17 = 3;
                        if (arrayList3.size() < 3 || z) {
                            ArrayList arrayList5 = new ArrayList();
                            size3 = arrayList3.size();
                            i4 = 0;
                            while (i4 < size3) {
                                Object obj5 = arrayList3.get(i4);
                                i4++;
                                a aVar7 = (a) obj5;
                                if (aVar7.d != bVar || aVar7.e <= 0) {
                                    arrayList5.add(obj5);
                                }
                            }
                            arrayList.addAll(arrayList5);
                            if (z) {
                                ArrayList arrayList6 = new ArrayList();
                                int size11 = arrayList3.size();
                                int i18 = 0;
                                while (i18 < size11) {
                                    Object obj6 = arrayList3.get(i18);
                                    i18++;
                                    if (((a) obj6).d == bVar2) {
                                        arrayList6.add(obj6);
                                    }
                                }
                                ArrayList arrayList7 = new ArrayList(arrayList6);
                                int size12 = arrayList7.size();
                                int i19 = 0;
                                while (i19 < size12) {
                                    Object obj7 = arrayList7.get(i19);
                                    i19++;
                                    ArrayList arrayListU2 = u((a) obj7);
                                    int size13 = arrayListU2.size();
                                    int i20 = 0;
                                    while (i20 < size13) {
                                        Object obj8 = arrayListU2.get(i20);
                                        i20++;
                                        a aVar8 = (a) obj8;
                                        if (!arrayList.contains(aVar8)) {
                                            arrayList.add(aVar8);
                                        }
                                    }
                                }
                            }
                        }
                        if (arrayList.size() < 3 || z) {
                            i5 = 0;
                            setScore((Math.max(0, arrayList.size() - 3) * 5) + (arrayList.size() * 10) + getScore());
                            this.J = arrayList.size() + this.J;
                            int i21 = this.H + 1;
                            this.H = i21;
                            this.I = Math.max(this.I, i21);
                            size4 = arrayList.size();
                            i6 = 0;
                            while (i6 < size4) {
                                int i22 = i6 + 1;
                                a aVar9 = (a) arrayList.get(i6);
                                int i23 = aVar9.a;
                                int i24 = aVar9.b;
                                d(m(i23, i24), n(i24), 8, o(aVar9.c), 240.0f, aVar);
                                arrayList2.remove(aVar9);
                                i6 = i22;
                            }
                            LinkedHashSet linkedHashSet2 = new LinkedHashSet();
                            c4Var = new c4();
                            ArrayList arrayList8 = new ArrayList();
                            size5 = arrayList2.size();
                            i7 = 0;
                            while (i7 < size5) {
                                Object obj9 = arrayList2.get(i7);
                                i7++;
                                if (((a) obj9).b == 0) {
                                    arrayList8.add(obj9);
                                }
                            }
                            size6 = arrayList8.size();
                            i8 = 0;
                            while (i8 < size6) {
                                Object obj10 = arrayList8.get(i8);
                                i8++;
                                a aVar10 = (a) obj10;
                                c4Var.addLast(aVar10);
                                linkedHashSet2.add(aVar10);
                            }
                            while (!c4Var.isEmpty()) {
                                ArrayList arrayListU3 = u((a) c4Var.removeFirst());
                                int size14 = arrayListU3.size();
                                int i25 = 0;
                                while (i25 < size14) {
                                    Object obj11 = arrayListU3.get(i25);
                                    i25++;
                                    a aVar11 = (a) obj11;
                                    if (linkedHashSet2.add(aVar11)) {
                                        c4Var.addLast(aVar11);
                                    }
                                }
                            }
                            ArrayList arrayList9 = new ArrayList();
                            size7 = arrayList2.size();
                            i9 = 0;
                            while (i9 < size7) {
                                Object obj12 = arrayList2.get(i9);
                                i9++;
                                if (!linkedHashSet2.contains((a) obj12)) {
                                    arrayList9.add(obj12);
                                }
                            }
                            size8 = arrayList9.size();
                            while (i5 < size8) {
                                Object obj13 = arrayList9.get(i5);
                                i5++;
                                a aVar12 = (a) obj13;
                                setScore(getScore() + 5);
                                this.J++;
                                aVar12.f = true;
                                ArrayList arrayList10 = this.x;
                                int i26 = aVar12.a;
                                int i27 = aVar12.b;
                                int i28 = aVar12.c;
                                b bVar5 = aVar12.d;
                                int i29 = aVar12.e;
                                float f14 = aVar12.g;
                                int i30 = i;
                                float f15 = aVar12.h;
                                bVar5.getClass();
                                arrayList10.add(new a(i26, i27, i28, bVar5, i29, true, f14, f15));
                                arrayList2.remove(aVar12);
                                i = i30;
                            }
                            setSessionCoins(getScore() / 10);
                            score = getScore() / 1000;
                            i10 = this.N;
                            if (score > i10) {
                                this.D = ((score - i10) * 5) + this.D;
                                this.N = score;
                            }
                            post(new v5(this, 1));
                            post(new v5(this, 2));
                        } else {
                            this.H = 0;
                        }
                        setSessionCoins(getScore() / 10);
                        if (arrayList2.isEmpty()) {
                            this.F = true;
                            setPaused(true);
                            this.M++;
                            setScore(getScore() + 100);
                            setSessionCoins(getScore() / 10);
                            d(getWidth() / f2, getHeight() / 3.0f, 30, this.b0, 360.0f, aVar);
                            post(new v4(this, this.E + 1, 8));
                            post(new v5(this, i17));
                        }
                    } else {
                        int size15 = arrayList3.size();
                        int i31 = 0;
                        while (i31 < size15) {
                            Object obj14 = arrayList3.get(i31);
                            i31++;
                            if (((a) obj14).d == bVar2) {
                                z = true;
                                break;
                            }
                        }
                        z = false;
                        if (z) {
                        }
                        ArrayList arrayList42 = new ArrayList();
                        size = arrayList3.size();
                        i2 = 0;
                        while (i2 < size) {
                        }
                        size2 = arrayList42.size();
                        i3 = 0;
                        while (i3 < size2) {
                        }
                        arrayList = new ArrayList();
                        int i172 = 3;
                        if (arrayList3.size() < 3) {
                            ArrayList arrayList52 = new ArrayList();
                            size3 = arrayList3.size();
                            i4 = 0;
                            while (i4 < size3) {
                            }
                            arrayList.addAll(arrayList52);
                            if (z) {
                            }
                            if (arrayList.size() < 3) {
                                i5 = 0;
                                setScore((Math.max(0, arrayList.size() - 3) * 5) + (arrayList.size() * 10) + getScore());
                                this.J = arrayList.size() + this.J;
                                int i212 = this.H + 1;
                                this.H = i212;
                                this.I = Math.max(this.I, i212);
                                size4 = arrayList.size();
                                i6 = 0;
                                while (i6 < size4) {
                                }
                                LinkedHashSet linkedHashSet22 = new LinkedHashSet();
                                c4Var = new c4();
                                ArrayList arrayList82 = new ArrayList();
                                size5 = arrayList2.size();
                                i7 = 0;
                                while (i7 < size5) {
                                }
                                size6 = arrayList82.size();
                                i8 = 0;
                                while (i8 < size6) {
                                }
                                while (!c4Var.isEmpty()) {
                                }
                                ArrayList arrayList92 = new ArrayList();
                                size7 = arrayList2.size();
                                i9 = 0;
                                while (i9 < size7) {
                                }
                                size8 = arrayList92.size();
                                while (i5 < size8) {
                                }
                                setSessionCoins(getScore() / 10);
                                score = getScore() / 1000;
                                i10 = this.N;
                                if (score > i10) {
                                }
                                post(new v5(this, 1));
                                post(new v5(this, 2));
                                setSessionCoins(getScore() / 10);
                                if (arrayList2.isEmpty()) {
                                }
                            }
                        }
                    }
                }
                this.y = null;
            } else if (cVar.b > getHeight() + this.O) {
                this.y = null;
                this.H = 0;
                if (this.D <= 0 && !this.w.isEmpty()) {
                    s();
                }
            }
        }
        Iterator it = this.x.iterator();
        while (it.hasNext()) {
            a aVar13 = (a) it.next();
            aVar13.g = (520.0f * ed.d(this).density * f) + aVar13.g;
            float f16 = aVar13.h - (1.6f * f);
            aVar13.h = f16;
            if (f16 <= 0.0f) {
                it.remove();
            }
        }
        if (this.D <= 0 && this.y == null && !this.w.isEmpty() && !this.h) {
            s();
        }
        g();
        a();
    }

    public final float m(int i, int i2) {
        return (i * this.O) + (i2 % 2 == 1 ? this.O / 2.0f : 0.0f) + this.P;
    }

    public final float n(int i) {
        float f = (i * this.O * 0.866f) + this.P;
        Resources resources = getResources();
        resources.getClass();
        return j3.p(resources, 8.0f) + f;
    }

    public final int o(int i) {
        List<y> list = v6.a;
        int[] iArr = v6.d(getPrefs().b(tf.d)).g;
        if (iArr.length == 0) {
            iArr = new int[]{Color.parseColor(defpackage.c.b(defpackage.c.e)), Color.parseColor(defpackage.c.b(defpackage.c.f)), Color.parseColor(defpackage.c.b(defpackage.c.g)), Color.parseColor(defpackage.c.b(defpackage.c.h)), Color.parseColor(defpackage.c.b(defpackage.c.i))};
        }
        return iArr[dp.p(i, iArr.length - 1)];
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00a6  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        if (!this.g && !this.h && !this.F) {
            this.R = getWidth() / 2.0f;
            this.Q = getHeight() - (52.0f * ed.d(this).density);
            int action = motionEvent.getAction();
            if (action == 0) {
                this.A = true;
                float fAtan2 = (float) Math.atan2(motionEvent.getY() - this.Q, motionEvent.getX() - this.R);
                this.z = fAtan2;
                if (fAtan2 > -0.2f) {
                    this.z = -0.2f;
                }
                if (this.z < -2.9415927f) {
                    this.z = -2.9415927f;
                }
            } else if (action == 1) {
                int i = 0;
                this.A = false;
                if (this.y == null && this.D > 0) {
                    float f = 860.0f * ed.d(this).density;
                    float f2 = this.R;
                    float f3 = this.Q - (28.0f * ed.d(this).density);
                    float fCos = ((float) Math.cos(this.z)) * f;
                    float fSin = ((float) Math.sin(this.z)) * f;
                    int i2 = this.B;
                    c cVar = new c();
                    cVar.a = f2;
                    cVar.b = f3;
                    cVar.c = fCos;
                    cVar.d = fSin;
                    cVar.e = i2;
                    this.y = cVar;
                    this.B = this.C;
                    cp.a.getClass();
                    this.C = cp.b.e(5);
                    this.D--;
                    post(new v5(this, i));
                    g();
                    return true;
                }
            } else if (action == 2) {
            }
        }
        return true;
    }

    public final float p(float f, float f2, a aVar) {
        int i = aVar.a;
        int i2 = aVar.b;
        return (float) Math.hypot(f - m(i, i2), f2 - n(i2));
    }

    public final void q(Canvas canvas, float f, float f2, float f3, int i, b bVar) {
        Paint fillPaint = getFillPaint();
        if (bVar == b.b) {
            i = Color.parseColor("#212121");
        }
        fillPaint.setColor(i);
        canvas.drawCircle(f, f2, f3, getFillPaint());
        getFillPaint().setColor(Color.argb(90, 255, 255, 255));
        float f4 = 0.28f * f3;
        float f5 = 0.32f * f3;
        canvas.drawCircle(f - f4, f2 - f4, f5, getFillPaint());
        getTextPaint().setTextSize(0.9f * f3);
        getTextPaint().setColor(-1);
        int iOrdinal = bVar.ordinal();
        if (iOrdinal == 1) {
            canvas.drawText("💀", f, f2 + f5, getTextPaint());
            return;
        }
        if (iOrdinal == 2) {
            canvas.drawText("🌈", f, f2 + f5, getTextPaint());
        } else {
            if (iOrdinal != 3) {
                return;
            }
            getFillPaint().setColor(Color.argb(90, 180, 230, 255));
            canvas.drawCircle(f, f2, f3, getFillPaint());
        }
    }

    public final void r(int i) {
        ArrayList arrayList = this.w;
        arrayList.clear();
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = i2 % 2 == 1 ? 9 : 10;
            for (int i4 = 0; i4 < i3; i4++) {
                float fD = cp.a.d();
                arrayList.add(new a(i4, i2, cp.b.e(5), fD < 0.03f ? b.b : fD < 0.06f ? b.c : fD < 0.1f ? b.d : b.a));
            }
        }
    }

    public final void s() {
        this.l = this.a0;
        this.k = 0.5f;
        post(new v5(this, 4));
        f(new sf(0, 0, false, this.J, this.K, this.L, this.I, this.M, 0, 0, false, 0, 0, 0, 0, null, 65287));
    }

    public final a t(float f, float f2) {
        Object obj;
        Iterator it = this.w.iterator();
        if (it.hasNext()) {
            Object next = it.next();
            if (it.hasNext()) {
                float fP = p(f, f2, (a) next);
                do {
                    Object next2 = it.next();
                    float fP2 = p(f, f2, (a) next2);
                    if (Float.compare(fP, fP2) > 0) {
                        next = next2;
                        fP = fP2;
                    }
                } while (it.hasNext());
            }
            obj = next;
        } else {
            obj = null;
        }
        return (a) obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final ArrayList u(a aVar) {
        List<nn> listQ;
        Object obj;
        int i = aVar.a;
        int i2 = aVar.b;
        if (i2 % 2 == 1) {
            nn nnVar = new nn(Integer.valueOf(i - 1), Integer.valueOf(i2));
            int i3 = i + 1;
            int i4 = i2 - 1;
            int i5 = i2 + 1;
            listQ = q7.Q(nnVar, new nn(Integer.valueOf(i3), Integer.valueOf(i2)), new nn(Integer.valueOf(i), Integer.valueOf(i4)), new nn(Integer.valueOf(i3), Integer.valueOf(i4)), new nn(Integer.valueOf(i), Integer.valueOf(i5)), new nn(Integer.valueOf(i3), Integer.valueOf(i5)));
        } else {
            int i6 = i - 1;
            nn nnVar2 = new nn(Integer.valueOf(i6), Integer.valueOf(i2));
            nn nnVar3 = new nn(Integer.valueOf(i + 1), Integer.valueOf(i2));
            int i7 = i2 - 1;
            int i8 = i2 + 1;
            listQ = q7.Q(nnVar2, nnVar3, new nn(Integer.valueOf(i6), Integer.valueOf(i7)), new nn(Integer.valueOf(i), Integer.valueOf(i7)), new nn(Integer.valueOf(i6), Integer.valueOf(i8)), new nn(Integer.valueOf(i), Integer.valueOf(i8)));
        }
        ArrayList arrayList = new ArrayList();
        for (nn nnVar4 : listQ) {
            ArrayList arrayList2 = this.w;
            int size = arrayList2.size();
            int i9 = 0;
            while (true) {
                if (i9 >= size) {
                    obj = null;
                    break;
                }
                obj = arrayList2.get(i9);
                i9++;
                a aVar2 = (a) obj;
                if (aVar2.a == ((Number) nnVar4.a).intValue() && aVar2.b == ((Number) nnVar4.b).intValue()) {
                    break;
                }
            }
            a aVar3 = (a) obj;
            if (aVar3 != null) {
                arrayList.add(aVar3);
            }
        }
        return arrayList;
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public final int a;
        public final int b;
        public int c;
        public final b d;
        public int e;
        public boolean f;
        public float g;
        public float h;

        public a(int i, int i2, int i3, b bVar, int i4, boolean z, float f, float f2) {
            bVar.getClass();
            this.a = i;
            this.b = i2;
            this.c = i3;
            this.d = bVar;
            this.e = i4;
            this.f = z;
            this.g = f;
            this.h = f2;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && this.b == aVar.b && this.c == aVar.c && this.d == aVar.d && this.e == aVar.e && this.f == aVar.f && Float.compare(this.g, aVar.g) == 0 && Float.compare(this.h, aVar.h) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.h) + ed.a(this.g, (Boolean.hashCode(this.f) + ed.c(this.e, (this.d.hashCode() + ed.c(this.c, ed.c(this.b, Integer.hashCode(this.a) * 31, 31), 31)) * 31, 31)) * 31, 31);
        }

        public final String toString() {
            return "GridBubble(col=" + this.a + ", row=" + this.b + ", colorIndex=" + this.c + ", kind=" + this.d + ", iceHits=" + this.e + ", falling=" + this.f + ", fallY=" + this.g + ", fallAlpha=" + this.h + ")";
        }

        public /* synthetic */ a(int i, int i2, int i3, b bVar) {
            this(i, i2, i3, bVar, 2, false, 0.0f, 1.0f);
        }
    }
}
