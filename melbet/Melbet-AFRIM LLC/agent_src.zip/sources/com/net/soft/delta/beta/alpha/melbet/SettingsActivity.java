package com.net.soft.delta.beta.alpha.melbet;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;
import com.net.soft.delta.beta.alpha.melbet.R;
import com.net.soft.delta.beta.alpha.melbet.SettingsActivity;
import defpackage.ai;
import defpackage.b1;
import defpackage.d2;
import defpackage.d6;
import defpackage.ko;
import defpackage.mr;
import defpackage.qe;
import defpackage.qm;
import defpackage.uf;
import defpackage.x4;
import defpackage.z2;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class SettingsActivity extends d2 {
    public static final /* synthetic */ int F = 0;
    public b1 C;
    public uf D;
    public z2 E;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ int a = 0;

        static {
            new LinkedHashMap();
        }
    }

    public SettingsActivity() {
        String.valueOf(9);
        Math.abs(5);
        Math.min(71, 3);
        int i = a.a;
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) throws Resources.NotFoundException {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_settings, (ViewGroup) null, false);
        int i2 = R.id.btnAbout;
        Button button = (Button) ko.i(viewInflate, R.id.btnAbout);
        if (button != null) {
            i2 = R.id.btnResetAchievements;
            Button button2 = (Button) ko.i(viewInflate, R.id.btnResetAchievements);
            if (button2 != null) {
                i2 = R.id.btnResetCoins;
                Button button3 = (Button) ko.i(viewInflate, R.id.btnResetCoins);
                if (button3 != null) {
                    i2 = R.id.btnResetRecords;
                    Button button4 = (Button) ko.i(viewInflate, R.id.btnResetRecords);
                    if (button4 != null) {
                        i2 = R.id.sliderVolume;
                        Slider slider = (Slider) ko.i(viewInflate, R.id.sliderVolume);
                        if (slider != null) {
                            i2 = R.id.switchAim;
                            MaterialSwitch materialSwitch = (MaterialSwitch) ko.i(viewInflate, R.id.switchAim);
                            if (materialSwitch != null) {
                                i2 = R.id.switchAnim;
                                MaterialSwitch materialSwitch2 = (MaterialSwitch) ko.i(viewInflate, R.id.switchAnim);
                                if (materialSwitch2 != null) {
                                    i2 = R.id.switchFps;
                                    MaterialSwitch materialSwitch3 = (MaterialSwitch) ko.i(viewInflate, R.id.switchFps);
                                    if (materialSwitch3 != null) {
                                        i2 = R.id.switchParticles;
                                        MaterialSwitch materialSwitch4 = (MaterialSwitch) ko.i(viewInflate, R.id.switchParticles);
                                        if (materialSwitch4 != null) {
                                            i2 = R.id.switchSound;
                                            MaterialSwitch materialSwitch5 = (MaterialSwitch) ko.i(viewInflate, R.id.switchSound);
                                            if (materialSwitch5 != null) {
                                                i2 = R.id.switchVibrate;
                                                MaterialSwitch materialSwitch6 = (MaterialSwitch) ko.i(viewInflate, R.id.switchVibrate);
                                                if (materialSwitch6 != null) {
                                                    i2 = R.id.toolbarSettings;
                                                    View viewI = ko.i(viewInflate, R.id.toolbarSettings);
                                                    if (viewI != null) {
                                                        ScrollView scrollView = (ScrollView) viewInflate;
                                                        this.C = new b1(scrollView, button, button2, button3, button4, slider, materialSwitch, materialSwitch2, materialSwitch3, materialSwitch4, materialSwitch5, materialSwitch6, d6.a(viewI));
                                                        setContentView(scrollView);
                                                        uf ufVar = new uf(this);
                                                        this.D = ufVar;
                                                        z2 z2Var = new z2(ufVar);
                                                        this.E = z2Var;
                                                        z2Var.e();
                                                        b1 b1Var = this.C;
                                                        if (b1Var == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((TextView) ((d6) b1Var.l).c).setText(R.string.title_settings);
                                                        b1 b1Var2 = this.C;
                                                        if (b1Var2 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((ImageButton) ((d6) b1Var2.l).a).setOnClickListener(new View.OnClickListener(this) { // from class: jr
                                                            public final /* synthetic */ SettingsActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i3 = i;
                                                                final SettingsActivity settingsActivity = this.b;
                                                                switch (i3) {
                                                                    case 0:
                                                                        int i4 = SettingsActivity.F;
                                                                        settingsActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i5 = SettingsActivity.F;
                                                                        final int i6 = 0;
                                                                        settingsActivity.x(R.string.reset_records, R.string.reset_records_msg, R.string.reset_records_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i7 = i6;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i7) {
                                                                                    case 0:
                                                                                        uf ufVar2 = settingsActivity2.D;
                                                                                        if (ufVar2 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar2.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar3 = settingsActivity2.D;
                                                                                        if (ufVar3 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar3.a.edit();
                                                                                        for (int i8 = 1; i8 < 25; i8++) {
                                                                                            editorEdit2.remove("ach_" + i8);
                                                                                            editorEdit2.remove("ach_date_" + i8);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar4 = settingsActivity2.D;
                                                                                        if (ufVar4 != null) {
                                                                                            ufVar4.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 2:
                                                                        int i7 = SettingsActivity.F;
                                                                        final int i8 = 2;
                                                                        settingsActivity.x(R.string.reset_coins, R.string.reset_coins_msg, R.string.reset_coins_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i8;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar2 = settingsActivity2.D;
                                                                                        if (ufVar2 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar2.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar3 = settingsActivity2.D;
                                                                                        if (ufVar3 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar3.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar4 = settingsActivity2.D;
                                                                                        if (ufVar4 != null) {
                                                                                            ufVar4.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 3:
                                                                        int i9 = SettingsActivity.F;
                                                                        final int i10 = 1;
                                                                        settingsActivity.x(R.string.reset_achievements, R.string.reset_achievements_msg, R.string.reset_achievements_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i10;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar2 = settingsActivity2.D;
                                                                                        if (ufVar2 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar2.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar3 = settingsActivity2.D;
                                                                                        if (ufVar3 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar3.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar4 = settingsActivity2.D;
                                                                                        if (ufVar4 != null) {
                                                                                            ufVar4.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    default:
                                                                        int i11 = SettingsActivity.F;
                                                                        b.a aVar = new b.a(settingsActivity);
                                                                        aVar.c(R.string.about);
                                                                        AlertController.b bVar = aVar.a;
                                                                        bVar.f = bVar.a.getText(R.string.about_message);
                                                                        aVar.b(R.string.ok, null);
                                                                        aVar.d();
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        b1 b1Var3 = this.C;
                                                        if (b1Var3 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch7 = (MaterialSwitch) b1Var3.j;
                                                        uf ufVar2 = this.D;
                                                        if (ufVar2 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        final int i3 = 1;
                                                        materialSwitch7.setChecked(ufVar2.a.getBoolean("sound_enabled", true));
                                                        b1 b1Var4 = this.C;
                                                        if (b1Var4 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch8 = (MaterialSwitch) b1Var4.k;
                                                        uf ufVar3 = this.D;
                                                        if (ufVar3 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        materialSwitch8.setChecked(ufVar3.a.getBoolean("vibrate_enabled", true));
                                                        b1 b1Var5 = this.C;
                                                        if (b1Var5 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        Slider slider2 = (Slider) b1Var5.e;
                                                        if (this.D == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        slider2.setValue(r5.a.getInt("sound_volume", 80));
                                                        b1 b1Var6 = this.C;
                                                        if (b1Var6 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch9 = (MaterialSwitch) b1Var6.h;
                                                        uf ufVar4 = this.D;
                                                        if (ufVar4 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        materialSwitch9.setChecked(ufVar4.a.getBoolean("show_fps", false));
                                                        b1 b1Var7 = this.C;
                                                        if (b1Var7 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch10 = (MaterialSwitch) b1Var7.g;
                                                        uf ufVar5 = this.D;
                                                        if (ufVar5 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        materialSwitch10.setChecked(ufVar5.a.getBoolean("menu_animations", true));
                                                        b1 b1Var8 = this.C;
                                                        if (b1Var8 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch11 = (MaterialSwitch) b1Var8.i;
                                                        uf ufVar6 = this.D;
                                                        if (ufVar6 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        materialSwitch11.setChecked(ufVar6.a.getBoolean("particles_enabled", true));
                                                        b1 b1Var9 = this.C;
                                                        if (b1Var9 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        MaterialSwitch materialSwitch12 = (MaterialSwitch) b1Var9.f;
                                                        uf ufVar7 = this.D;
                                                        if (ufVar7 == null) {
                                                            ai.d("prefs");
                                                            throw null;
                                                        }
                                                        materialSwitch12.setChecked(ufVar7.a.getBoolean("aim_line", true));
                                                        b1 b1Var10 = this.C;
                                                        if (b1Var10 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((MaterialSwitch) b1Var10.j).setOnCheckedChangeListener(new mr(this, 0));
                                                        b1 b1Var11 = this.C;
                                                        if (b1Var11 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((MaterialSwitch) b1Var11.k).setOnCheckedChangeListener(new mr(this, 1));
                                                        b1 b1Var12 = this.C;
                                                        if (b1Var12 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((Slider) b1Var12.e).m.add(new x4() { // from class: nr
                                                            @Override // defpackage.x4
                                                            public final void a(c5 c5Var, float f) {
                                                                int i4 = SettingsActivity.F;
                                                                SettingsActivity settingsActivity = this.a;
                                                                uf ufVar8 = settingsActivity.D;
                                                                if (ufVar8 == null) {
                                                                    ai.d("prefs");
                                                                    throw null;
                                                                }
                                                                ufVar8.a.edit().putInt("sound_volume", dp.p((int) f, 100)).apply();
                                                                z2 z2Var2 = settingsActivity.E;
                                                                if (z2Var2 == null) {
                                                                    ai.d("sound");
                                                                    throw null;
                                                                }
                                                                z2Var2.f();
                                                                z2 z2Var3 = settingsActivity.E;
                                                                if (z2Var3 != null) {
                                                                    z2Var3.e();
                                                                } else {
                                                                    ai.d("sound");
                                                                    throw null;
                                                                }
                                                            }
                                                        });
                                                        b1 b1Var13 = this.C;
                                                        if (b1Var13 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        final int i4 = 2;
                                                        ((MaterialSwitch) b1Var13.h).setOnCheckedChangeListener(new mr(this, 2));
                                                        b1 b1Var14 = this.C;
                                                        if (b1Var14 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        final int i5 = 3;
                                                        ((MaterialSwitch) b1Var14.g).setOnCheckedChangeListener(new mr(this, 3));
                                                        b1 b1Var15 = this.C;
                                                        if (b1Var15 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        final int i6 = 4;
                                                        ((MaterialSwitch) b1Var15.i).setOnCheckedChangeListener(new mr(this, 4));
                                                        b1 b1Var16 = this.C;
                                                        if (b1Var16 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((MaterialSwitch) b1Var16.f).setOnCheckedChangeListener(new mr(this, 5));
                                                        b1 b1Var17 = this.C;
                                                        if (b1Var17 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((Button) b1Var17.d).setOnClickListener(new View.OnClickListener(this) { // from class: jr
                                                            public final /* synthetic */ SettingsActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i32 = i3;
                                                                final SettingsActivity settingsActivity = this.b;
                                                                switch (i32) {
                                                                    case 0:
                                                                        int i42 = SettingsActivity.F;
                                                                        settingsActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i52 = SettingsActivity.F;
                                                                        final int i62 = 0;
                                                                        settingsActivity.x(R.string.reset_records, R.string.reset_records_msg, R.string.reset_records_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i62;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 2:
                                                                        int i7 = SettingsActivity.F;
                                                                        final int i8 = 2;
                                                                        settingsActivity.x(R.string.reset_coins, R.string.reset_coins_msg, R.string.reset_coins_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i8;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 3:
                                                                        int i9 = SettingsActivity.F;
                                                                        final int i10 = 1;
                                                                        settingsActivity.x(R.string.reset_achievements, R.string.reset_achievements_msg, R.string.reset_achievements_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i10;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    default:
                                                                        int i11 = SettingsActivity.F;
                                                                        b.a aVar = new b.a(settingsActivity);
                                                                        aVar.c(R.string.about);
                                                                        AlertController.b bVar = aVar.a;
                                                                        bVar.f = bVar.a.getText(R.string.about_message);
                                                                        aVar.b(R.string.ok, null);
                                                                        aVar.d();
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        b1 b1Var18 = this.C;
                                                        if (b1Var18 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((Button) b1Var18.c).setOnClickListener(new View.OnClickListener(this) { // from class: jr
                                                            public final /* synthetic */ SettingsActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i32 = i4;
                                                                final SettingsActivity settingsActivity = this.b;
                                                                switch (i32) {
                                                                    case 0:
                                                                        int i42 = SettingsActivity.F;
                                                                        settingsActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i52 = SettingsActivity.F;
                                                                        final int i62 = 0;
                                                                        settingsActivity.x(R.string.reset_records, R.string.reset_records_msg, R.string.reset_records_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i62;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 2:
                                                                        int i7 = SettingsActivity.F;
                                                                        final int i8 = 2;
                                                                        settingsActivity.x(R.string.reset_coins, R.string.reset_coins_msg, R.string.reset_coins_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i8;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 3:
                                                                        int i9 = SettingsActivity.F;
                                                                        final int i10 = 1;
                                                                        settingsActivity.x(R.string.reset_achievements, R.string.reset_achievements_msg, R.string.reset_achievements_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i10;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    default:
                                                                        int i11 = SettingsActivity.F;
                                                                        b.a aVar = new b.a(settingsActivity);
                                                                        aVar.c(R.string.about);
                                                                        AlertController.b bVar = aVar.a;
                                                                        bVar.f = bVar.a.getText(R.string.about_message);
                                                                        aVar.b(R.string.ok, null);
                                                                        aVar.d();
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        b1 b1Var19 = this.C;
                                                        if (b1Var19 == null) {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                        ((Button) b1Var19.b).setOnClickListener(new View.OnClickListener(this) { // from class: jr
                                                            public final /* synthetic */ SettingsActivity b;

                                                            {
                                                                this.b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                int i32 = i5;
                                                                final SettingsActivity settingsActivity = this.b;
                                                                switch (i32) {
                                                                    case 0:
                                                                        int i42 = SettingsActivity.F;
                                                                        settingsActivity.finish();
                                                                        break;
                                                                    case 1:
                                                                        int i52 = SettingsActivity.F;
                                                                        final int i62 = 0;
                                                                        settingsActivity.x(R.string.reset_records, R.string.reset_records_msg, R.string.reset_records_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i62;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 2:
                                                                        int i7 = SettingsActivity.F;
                                                                        final int i8 = 2;
                                                                        settingsActivity.x(R.string.reset_coins, R.string.reset_coins_msg, R.string.reset_coins_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i8;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    case 3:
                                                                        int i9 = SettingsActivity.F;
                                                                        final int i10 = 1;
                                                                        settingsActivity.x(R.string.reset_achievements, R.string.reset_achievements_msg, R.string.reset_achievements_msg2, new qe() { // from class: kr
                                                                            @Override // defpackage.qe
                                                                            public final Object a() {
                                                                                int i72 = i10;
                                                                                SettingsActivity settingsActivity2 = settingsActivity;
                                                                                switch (i72) {
                                                                                    case 0:
                                                                                        uf ufVar22 = settingsActivity2.D;
                                                                                        if (ufVar22 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                        for (String str : tf.m) {
                                                                                            str.getClass();
                                                                                            editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                            editorEdit.remove("record_date_".concat(str));
                                                                                            editorEdit.remove("history_".concat(str));
                                                                                        }
                                                                                        editorEdit.putInt("stat_records_beaten", 0);
                                                                                        editorEdit.apply();
                                                                                        return c.m0;
                                                                                    case 1:
                                                                                        uf ufVar32 = settingsActivity2.D;
                                                                                        if (ufVar32 == null) {
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                        }
                                                                                        SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                        for (int i82 = 1; i82 < 25; i82++) {
                                                                                            editorEdit2.remove("ach_" + i82);
                                                                                            editorEdit2.remove("ach_date_" + i82);
                                                                                        }
                                                                                        editorEdit2.apply();
                                                                                        return c.m0;
                                                                                    default:
                                                                                        uf ufVar42 = settingsActivity2.D;
                                                                                        if (ufVar42 != null) {
                                                                                            ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                            return c.m0;
                                                                                        }
                                                                                        ai.d("prefs");
                                                                                        throw null;
                                                                                }
                                                                            }
                                                                        });
                                                                        break;
                                                                    default:
                                                                        int i11 = SettingsActivity.F;
                                                                        b.a aVar = new b.a(settingsActivity);
                                                                        aVar.c(R.string.about);
                                                                        AlertController.b bVar = aVar.a;
                                                                        bVar.f = bVar.a.getText(R.string.about_message);
                                                                        aVar.b(R.string.ok, null);
                                                                        aVar.d();
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        b1 b1Var20 = this.C;
                                                        if (b1Var20 != null) {
                                                            ((Button) b1Var20.a).setOnClickListener(new View.OnClickListener(this) { // from class: jr
                                                                public final /* synthetic */ SettingsActivity b;

                                                                {
                                                                    this.b = this;
                                                                }

                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view) {
                                                                    int i32 = i6;
                                                                    final SettingsActivity settingsActivity = this.b;
                                                                    switch (i32) {
                                                                        case 0:
                                                                            int i42 = SettingsActivity.F;
                                                                            settingsActivity.finish();
                                                                            break;
                                                                        case 1:
                                                                            int i52 = SettingsActivity.F;
                                                                            final int i62 = 0;
                                                                            settingsActivity.x(R.string.reset_records, R.string.reset_records_msg, R.string.reset_records_msg2, new qe() { // from class: kr
                                                                                @Override // defpackage.qe
                                                                                public final Object a() {
                                                                                    int i72 = i62;
                                                                                    SettingsActivity settingsActivity2 = settingsActivity;
                                                                                    switch (i72) {
                                                                                        case 0:
                                                                                            uf ufVar22 = settingsActivity2.D;
                                                                                            if (ufVar22 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                            for (String str : tf.m) {
                                                                                                str.getClass();
                                                                                                editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                                editorEdit.remove("record_date_".concat(str));
                                                                                                editorEdit.remove("history_".concat(str));
                                                                                            }
                                                                                            editorEdit.putInt("stat_records_beaten", 0);
                                                                                            editorEdit.apply();
                                                                                            return c.m0;
                                                                                        case 1:
                                                                                            uf ufVar32 = settingsActivity2.D;
                                                                                            if (ufVar32 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                            for (int i82 = 1; i82 < 25; i82++) {
                                                                                                editorEdit2.remove("ach_" + i82);
                                                                                                editorEdit2.remove("ach_date_" + i82);
                                                                                            }
                                                                                            editorEdit2.apply();
                                                                                            return c.m0;
                                                                                        default:
                                                                                            uf ufVar42 = settingsActivity2.D;
                                                                                            if (ufVar42 != null) {
                                                                                                ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                                return c.m0;
                                                                                            }
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                    }
                                                                                }
                                                                            });
                                                                            break;
                                                                        case 2:
                                                                            int i7 = SettingsActivity.F;
                                                                            final int i8 = 2;
                                                                            settingsActivity.x(R.string.reset_coins, R.string.reset_coins_msg, R.string.reset_coins_msg2, new qe() { // from class: kr
                                                                                @Override // defpackage.qe
                                                                                public final Object a() {
                                                                                    int i72 = i8;
                                                                                    SettingsActivity settingsActivity2 = settingsActivity;
                                                                                    switch (i72) {
                                                                                        case 0:
                                                                                            uf ufVar22 = settingsActivity2.D;
                                                                                            if (ufVar22 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                            for (String str : tf.m) {
                                                                                                str.getClass();
                                                                                                editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                                editorEdit.remove("record_date_".concat(str));
                                                                                                editorEdit.remove("history_".concat(str));
                                                                                            }
                                                                                            editorEdit.putInt("stat_records_beaten", 0);
                                                                                            editorEdit.apply();
                                                                                            return c.m0;
                                                                                        case 1:
                                                                                            uf ufVar32 = settingsActivity2.D;
                                                                                            if (ufVar32 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                            for (int i82 = 1; i82 < 25; i82++) {
                                                                                                editorEdit2.remove("ach_" + i82);
                                                                                                editorEdit2.remove("ach_date_" + i82);
                                                                                            }
                                                                                            editorEdit2.apply();
                                                                                            return c.m0;
                                                                                        default:
                                                                                            uf ufVar42 = settingsActivity2.D;
                                                                                            if (ufVar42 != null) {
                                                                                                ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                                return c.m0;
                                                                                            }
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                    }
                                                                                }
                                                                            });
                                                                            break;
                                                                        case 3:
                                                                            int i9 = SettingsActivity.F;
                                                                            final int i10 = 1;
                                                                            settingsActivity.x(R.string.reset_achievements, R.string.reset_achievements_msg, R.string.reset_achievements_msg2, new qe() { // from class: kr
                                                                                @Override // defpackage.qe
                                                                                public final Object a() {
                                                                                    int i72 = i10;
                                                                                    SettingsActivity settingsActivity2 = settingsActivity;
                                                                                    switch (i72) {
                                                                                        case 0:
                                                                                            uf ufVar22 = settingsActivity2.D;
                                                                                            if (ufVar22 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit = ufVar22.a.edit();
                                                                                            for (String str : tf.m) {
                                                                                                str.getClass();
                                                                                                editorEdit.remove(lt.t(str, "record_", false) ? str : "record_".concat(str));
                                                                                                editorEdit.remove("record_date_".concat(str));
                                                                                                editorEdit.remove("history_".concat(str));
                                                                                            }
                                                                                            editorEdit.putInt("stat_records_beaten", 0);
                                                                                            editorEdit.apply();
                                                                                            return c.m0;
                                                                                        case 1:
                                                                                            uf ufVar32 = settingsActivity2.D;
                                                                                            if (ufVar32 == null) {
                                                                                                ai.d("prefs");
                                                                                                throw null;
                                                                                            }
                                                                                            SharedPreferences.Editor editorEdit2 = ufVar32.a.edit();
                                                                                            for (int i82 = 1; i82 < 25; i82++) {
                                                                                                editorEdit2.remove("ach_" + i82);
                                                                                                editorEdit2.remove("ach_date_" + i82);
                                                                                            }
                                                                                            editorEdit2.apply();
                                                                                            return c.m0;
                                                                                        default:
                                                                                            uf ufVar42 = settingsActivity2.D;
                                                                                            if (ufVar42 != null) {
                                                                                                ufVar42.a.edit().putInt("total_coins", 0).apply();
                                                                                                return c.m0;
                                                                                            }
                                                                                            ai.d("prefs");
                                                                                            throw null;
                                                                                    }
                                                                                }
                                                                            });
                                                                            break;
                                                                        default:
                                                                            int i11 = SettingsActivity.F;
                                                                            b.a aVar = new b.a(settingsActivity);
                                                                            aVar.c(R.string.about);
                                                                            AlertController.b bVar = aVar.a;
                                                                            bVar.f = bVar.a.getText(R.string.about_message);
                                                                            aVar.b(R.string.ok, null);
                                                                            aVar.d();
                                                                            break;
                                                                    }
                                                                }
                                                            });
                                                            return;
                                                        } else {
                                                            ai.d("binding");
                                                            throw null;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        z2 z2Var = this.E;
        if (z2Var != null) {
            z2Var.f();
        } else {
            ai.d("sound");
            throw null;
        }
    }

    public final void x(final int i, int i2, final int i3, final qe<defpackage.c> qeVar) {
        b.a aVar = new b.a(this);
        aVar.c(i);
        AlertController.b bVar = aVar.a;
        bVar.f = bVar.a.getText(i2);
        bVar.i = bVar.a.getText(R.string.cancel);
        aVar.b(R.string.confirm, new DialogInterface.OnClickListener() { // from class: lr
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i4) {
                int i5 = SettingsActivity.F;
                b.a aVar2 = new b.a(this.a);
                aVar2.c(i);
                AlertController.b bVar2 = aVar2.a;
                bVar2.f = bVar2.a.getText(i3);
                bVar2.i = bVar2.a.getText(R.string.cancel);
                aVar2.b(R.string.confirm, new sn(1, qeVar));
                aVar2.d();
            }
        });
        aVar.d();
    }
}
