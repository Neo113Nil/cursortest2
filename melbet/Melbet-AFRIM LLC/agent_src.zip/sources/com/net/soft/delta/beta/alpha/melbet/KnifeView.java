package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.net.soft.delta.beta.alpha.melbet.KnifeView;
import com.net.soft.delta.beta.alpha.melbet.a;
import com.net.soft.delta.beta.alpha.melbet.c;
import defpackage.c8;
import defpackage.cp;
import defpackage.dp;
import defpackage.ed;
import defpackage.fs;
import defpackage.j3;
import defpackage.jq;
import defpackage.r7;
import defpackage.sf;
import defpackage.tf;
import defpackage.u7;
import defpackage.uf;
import defpackage.ui;
import defpackage.v4;
import defpackage.v6;
import defpackage.y;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class KnifeView extends com.net.soft.delta.beta.alpha.melbet.a {
    public static final /* synthetic */ int e0 = 0;
    public int A;
    public float B;
    public int C;
    public int D;
    public int E;
    public boolean F;
    public float G;
    public float H;
    public float I;
    public float J;
    public boolean K;
    public int L;
    public int M;
    public int N;
    public boolean O;
    public boolean P;
    public final Path Q;
    public final RectF R;
    public final int S;
    public final int T;
    public final int U;
    public final int V;
    public final int W;
    public final int a0;
    public final int b0;
    public final int c0;
    public final int d0;
    public final ArrayList w;
    public final ArrayList x;
    public final ArrayList y;
    public float z;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public float a;
        public boolean b;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return Float.compare(this.a, aVar.a) == 0 && this.b == aVar.b;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.b) + (Float.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "Apple(angle=" + this.a + ", taken=" + this.b + ")";
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public String a;
        public float b;
        public float c;
        public float d;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.a.equals(bVar.a) && Float.compare(this.b, bVar.b) == 0 && Float.compare(this.c, bVar.c) == 0 && Float.compare(this.d, bVar.d) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.d) + ed.a(this.c, ed.a(this.b, this.a.hashCode() * 31, 31), 31);
        }

        public final String toString() {
            return "Popup(text=" + this.a + ", posY=" + this.b + ", alpha=" + this.c + ", posX=" + this.d + ")";
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public KnifeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.w = new ArrayList();
        this.x = new ArrayList();
        this.y = new ArrayList();
        this.C = 1;
        this.D = 5;
        this.E = 5;
        this.H = 1.0f;
        this.O = true;
        this.Q = new Path();
        this.R = new RectF();
        this.S = context.getColor(R.color.colorPrimary);
        this.T = context.getColor(R.color.colorLog);
        this.U = context.getColor(R.color.colorLogRing1);
        this.V = context.getColor(R.color.colorLogRing2);
        this.W = context.getColor(R.color.colorLogGrain);
        this.a0 = context.getColor(R.color.colorApple);
        this.b0 = context.getColor(R.color.colorRed);
        this.c0 = context.getColor(R.color.colorStar);
        this.d0 = Color.parseColor(defpackage.c.f(defpackage.c.T));
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void b() {
        this.K = false;
        setPaused(false);
        this.C++;
        n();
        this.H = 0.0f;
        this.I = 1.0f;
        g();
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final int e() {
        return this.C;
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void h(Canvas canvas) {
        Canvas canvas2;
        float f;
        canvas.drawColor(this.S);
        float width = getWidth() / 2.0f;
        float height = getHeight() * 0.38f;
        float f2 = 100.0f * ed.f(this).density;
        float f3 = this.H;
        if (f3 == 0.0f) {
            f3 = 1.0f;
        }
        float f4 = f2 * f3;
        canvas.save();
        canvas.rotate(this.z, width, height);
        List<y> list = v6.a;
        getFillPaint().setColor(v6.d(getPrefs().b(tf.e)).f);
        canvas.drawCircle(width, height, f4, getFillPaint());
        getStrokePaint().setStyle(Paint.Style.STROKE);
        getStrokePaint().setStrokeWidth(6.0f * ed.f(this).density);
        getStrokePaint().setColor(this.U);
        canvas.drawCircle(width, height, 0.72f * f4, getStrokePaint());
        Paint strokePaint = getStrokePaint();
        int i = this.V;
        strokePaint.setColor(i);
        canvas.drawCircle(width, height, 0.44f * f4, getStrokePaint());
        getStrokePaint().setColor(this.W);
        getStrokePaint().setAlpha(76);
        getStrokePaint().setStrokeWidth(1.5f * ed.f(this).density);
        for (int i2 = 0; i2 < 8; i2++) {
            double radians = Math.toRadians(i2 * 45.0d);
            canvas.drawLine((((float) Math.cos(radians)) * f4 * 0.2f) + width, (((float) Math.sin(radians)) * f4 * 0.2f) + height, (((float) Math.cos(radians)) * f4) + width, (((float) Math.sin(radians)) * f4) + height, getStrokePaint());
        }
        getStrokePaint().setAlpha(255);
        getFillPaint().setColor(i);
        canvas.drawCircle(width, height, 0.12f * f4, getFillPaint());
        List<y> list2 = v6.a;
        fs fsVarD = v6.d(getPrefs().b(tf.e));
        ArrayList arrayList = this.w;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            int i4 = i3 + 1;
            float fFloatValue = ((Number) arrayList.get(i3)).floatValue();
            canvas.save();
            canvas.rotate(fFloatValue, width, height);
            float f5 = width;
            m(canvas, f5, height - f4, fsVarD.e, ed.f(this).density * 60.0f);
            canvas.restore();
            width = f5;
            i3 = i4;
        }
        float f6 = 60.0f;
        float f7 = width;
        ArrayList arrayList2 = this.x;
        int size2 = arrayList2.size();
        int i5 = 0;
        while (i5 < size2) {
            Object obj = arrayList2.get(i5);
            i5++;
            a aVar = (a) obj;
            if (aVar.b) {
                f = f6;
            } else {
                canvas.save();
                canvas.rotate(aVar.a, f7, height);
                getFillPaint().setColor(this.a0);
                f = f6;
                canvas.drawCircle(f7, height - f4, ed.f(this).density * 10.0f, getFillPaint());
                canvas.restore();
            }
            f6 = f;
        }
        float f8 = f6;
        canvas.restore();
        float height2 = getHeight();
        Resources resources = getResources();
        resources.getClass();
        float fP = (200.0f * ed.f(this).density * (1.0f - this.J)) + (height2 - j3.p(resources, 90.0f));
        if (this.F) {
            canvas2 = canvas;
            m(canvas2, f7, fP + this.G, fsVarD.e, f8 * ed.f(this).density);
        } else {
            m(canvas, f7, fP, fsVarD.e, f8 * ed.f(this).density);
            canvas2 = canvas;
        }
        getTextPaint().setColor(this.c0);
        getTextPaint().setTextSize(16.0f * ed.f(this).density);
        ArrayList arrayList3 = this.y;
        int size3 = arrayList3.size();
        int i6 = 0;
        while (i6 < size3) {
            Object obj2 = arrayList3.get(i6);
            i6++;
            b bVar = (b) obj2;
            getTextPaint().setAlpha((int) (dp.o(bVar.c, 0.0f, 1.0f) * 255.0f));
            canvas2.drawText(bVar.a, bVar.d, bVar.b, getTextPaint());
            getTextPaint().setAlpha(255);
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void i() {
        k();
        getParticles().a.clear();
        setScore(0);
        setSessionCoins(0);
        this.C = 1;
        this.L = 0;
        this.M = 0;
        this.N = 0;
        this.P = false;
        setGameOver(false);
        setPaused(false);
        this.K = false;
        n();
        g();
        j();
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x0161  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x01d0  */
    @Override // com.net.soft.delta.beta.alpha.melbet.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void l(float f) {
        boolean z;
        float f2;
        Object obj;
        if (getWidth() <= 0 || getHeight() <= 0 || this.K) {
            return;
        }
        List<List<jq>> list = ui.a;
        int i = this.C;
        final int i2 = 1;
        if (i < 1) {
            i = 1;
        }
        int i3 = i - 1;
        int i4 = i3 % 10;
        float f3 = ((i3 / 10.0f) * 0.4f) + 1.0f;
        List<jq> list2 = ui.a.get(i4);
        ArrayList arrayList = new ArrayList(r7.S(list2));
        for (jq jqVar : list2) {
            arrayList.add(new jq(jqVar.a * f3, jqVar.b));
        }
        jq jqVar2 = (jq) arrayList.get(this.A % arrayList.size());
        float f4 = 360.0f;
        float f5 = ((jqVar2.a * f) + this.z) % 360.0f;
        this.z = f5;
        if (f5 < 0.0f) {
            this.z = f5 + 360.0f;
        }
        float f6 = this.B + f;
        this.B = f6;
        if (f6 >= jqVar2.b) {
            this.B = 0.0f;
            this.A = (this.A + 1) % arrayList.size();
        }
        float f7 = this.I;
        if (f7 != 0.0f) {
            float f8 = (f7 * f * 4.0f) + this.H;
            this.H = f8;
            if (f7 > 0.0f && f8 >= 1.2f) {
                this.H = 1.2f;
                this.I = -1.0f;
            } else if (f7 < 0.0f && f8 <= 1.0f) {
                this.H = 1.0f;
                this.I = 0.0f;
            }
        }
        float f9 = this.J;
        if (f9 < 1.0f) {
            float f10 = (f / 0.2f) + f9;
            if (f10 > 1.0f) {
                f10 = 1.0f;
            }
            this.J = f10;
        }
        boolean z2 = this.F;
        ArrayList arrayList2 = this.y;
        final int i5 = 0;
        if (z2) {
            this.G -= (800.0f * ed.f(this).density) * f;
            float height = getHeight() * 0.38f;
            float f11 = 100.0f;
            float f12 = ed.f(this).density * 100.0f;
            float height2 = getHeight();
            Resources resources = getResources();
            resources.getClass();
            if ((height2 - j3.p(resources, 90.0f)) + this.G <= height + f12) {
                this.F = false;
                float f13 = (this.z + 270.0f) % 360.0f;
                ArrayList arrayList3 = this.w;
                if (arrayList3 == null || !arrayList3.isEmpty()) {
                    int size = arrayList3.size();
                    int i6 = 0;
                    while (i6 < size) {
                        Object obj2 = arrayList3.get(i6);
                        i6++;
                        float fAbs = Math.abs(((Number) obj2).floatValue() - f13);
                        if (Math.min(fAbs, 360.0f - fAbs) < 15.0f) {
                            z = true;
                            break;
                        }
                    }
                    z = false;
                    float height3 = getHeight() * 0.38f;
                    float width = getWidth() / 2.0f;
                    if (z) {
                        arrayList3.add(Float.valueOf(f13));
                        this.L++;
                        this.E--;
                        this.J = 0.0f;
                        getPrefs().e("stat_total_knives", 1);
                        final int i7 = 2;
                        post(new Runnable(this) { // from class: li
                            public final /* synthetic */ KnifeView b;

                            {
                                this.b = this;
                            }

                            @Override // java.lang.Runnable
                            public final void run() {
                                int i8 = i7;
                                KnifeView knifeView = this.b;
                                switch (i8) {
                                    case 0:
                                        int i9 = KnifeView.e0;
                                        a.InterfaceC0035a listener = knifeView.getListener();
                                        if (listener != null) {
                                            listener.e(200L);
                                            break;
                                        }
                                        break;
                                    case 1:
                                        int i10 = KnifeView.e0;
                                        a.InterfaceC0035a listener2 = knifeView.getListener();
                                        if (listener2 != null) {
                                            listener2.f(c.f(c.U));
                                            break;
                                        }
                                        break;
                                    case 2:
                                        int i11 = KnifeView.e0;
                                        a.InterfaceC0035a listener3 = knifeView.getListener();
                                        if (listener3 != null) {
                                            listener3.f(c.f(c.V));
                                            break;
                                        }
                                        break;
                                    case 3:
                                        int i12 = KnifeView.e0;
                                        a.InterfaceC0035a listener4 = knifeView.getListener();
                                        if (listener4 != null) {
                                            listener4.e(30L);
                                            break;
                                        }
                                        break;
                                    default:
                                        int i13 = KnifeView.e0;
                                        a.InterfaceC0035a listener5 = knifeView.getListener();
                                        if (listener5 != null) {
                                            listener5.f(c.f(c.X));
                                            break;
                                        }
                                        break;
                                }
                            }
                        });
                        final int i8 = 3;
                        post(new Runnable(this) { // from class: li
                            public final /* synthetic */ KnifeView b;

                            {
                                this.b = this;
                            }

                            @Override // java.lang.Runnable
                            public final void run() {
                                int i82 = i8;
                                KnifeView knifeView = this.b;
                                switch (i82) {
                                    case 0:
                                        int i9 = KnifeView.e0;
                                        a.InterfaceC0035a listener = knifeView.getListener();
                                        if (listener != null) {
                                            listener.e(200L);
                                            break;
                                        }
                                        break;
                                    case 1:
                                        int i10 = KnifeView.e0;
                                        a.InterfaceC0035a listener2 = knifeView.getListener();
                                        if (listener2 != null) {
                                            listener2.f(c.f(c.U));
                                            break;
                                        }
                                        break;
                                    case 2:
                                        int i11 = KnifeView.e0;
                                        a.InterfaceC0035a listener3 = knifeView.getListener();
                                        if (listener3 != null) {
                                            listener3.f(c.f(c.V));
                                            break;
                                        }
                                        break;
                                    case 3:
                                        int i12 = KnifeView.e0;
                                        a.InterfaceC0035a listener4 = knifeView.getListener();
                                        if (listener4 != null) {
                                            listener4.e(30L);
                                            break;
                                        }
                                        break;
                                    default:
                                        int i13 = KnifeView.e0;
                                        a.InterfaceC0035a listener5 = knifeView.getListener();
                                        if (listener5 != null) {
                                            listener5.f(c.f(c.X));
                                            break;
                                        }
                                        break;
                                }
                            }
                        });
                        ArrayList arrayList4 = this.x;
                        int size2 = arrayList4.size();
                        int i9 = 0;
                        while (true) {
                            if (i9 >= size2) {
                                f2 = f11;
                                obj = null;
                                break;
                            }
                            obj = arrayList4.get(i9);
                            i9++;
                            float f14 = f4;
                            a aVar = (a) obj;
                            f2 = f11;
                            if (!aVar.b) {
                                float fAbs2 = Math.abs(((aVar.a + this.z) % f14) - f13);
                                if (Math.min(fAbs2, f14 - fAbs2) < 18.0f) {
                                    break;
                                }
                            }
                            f4 = f14;
                            f11 = f2;
                        }
                        a aVar2 = (a) obj;
                        c.a aVar3 = c.a.a;
                        if (aVar2 != null) {
                            aVar2.b = true;
                            this.M++;
                            setScore(getScore() + 50);
                            String strF = defpackage.c.f(defpackage.c.W);
                            float f15 = (20.0f * ed.f(this).density) + width;
                            b bVar = new b();
                            bVar.a = strF;
                            bVar.b = height3;
                            bVar.c = 1.0f;
                            bVar.d = f15;
                            arrayList2.add(bVar);
                            Resources resources2 = getResources();
                            resources2.getClass();
                            d(width, height3 - (f2 * resources2.getDisplayMetrics().density), 8, this.a0, 260.0f, aVar3);
                        }
                        setScore((this.D - this.E) + ((this.C - 1) * 100) + (this.M * 50) + (this.N * 100));
                        setSessionCoins(getScore() / 10);
                        if (this.E <= 0) {
                            this.K = true;
                            setPaused(true);
                            this.N++;
                            if (this.O) {
                                this.P = true;
                            }
                            uf prefs = getPrefs();
                            int i10 = this.C + 1;
                            SharedPreferences sharedPreferences = prefs.a;
                            if (i10 > sharedPreferences.getInt("stat_knife_max_level", 0)) {
                                sharedPreferences.edit().putInt("stat_knife_max_level", i10).apply();
                            }
                            d(getWidth() / 2.0f, getHeight() * 0.38f, 30, this.T, 380.0f, aVar3);
                            d(getWidth() / 2.0f, getHeight() * 0.38f, 16, this.c0, 280.0f, aVar3);
                            post(new v4(this, this.C + 1, i5));
                            final int i11 = 4;
                            post(new Runnable(this) { // from class: li
                                public final /* synthetic */ KnifeView b;

                                {
                                    this.b = this;
                                }

                                @Override // java.lang.Runnable
                                public final void run() {
                                    int i82 = i11;
                                    KnifeView knifeView = this.b;
                                    switch (i82) {
                                        case 0:
                                            int i92 = KnifeView.e0;
                                            a.InterfaceC0035a listener = knifeView.getListener();
                                            if (listener != null) {
                                                listener.e(200L);
                                                break;
                                            }
                                            break;
                                        case 1:
                                            int i102 = KnifeView.e0;
                                            a.InterfaceC0035a listener2 = knifeView.getListener();
                                            if (listener2 != null) {
                                                listener2.f(c.f(c.U));
                                                break;
                                            }
                                            break;
                                        case 2:
                                            int i112 = KnifeView.e0;
                                            a.InterfaceC0035a listener3 = knifeView.getListener();
                                            if (listener3 != null) {
                                                listener3.f(c.f(c.V));
                                                break;
                                            }
                                            break;
                                        case 3:
                                            int i12 = KnifeView.e0;
                                            a.InterfaceC0035a listener4 = knifeView.getListener();
                                            if (listener4 != null) {
                                                listener4.e(30L);
                                                break;
                                            }
                                            break;
                                        default:
                                            int i13 = KnifeView.e0;
                                            a.InterfaceC0035a listener5 = knifeView.getListener();
                                            if (listener5 != null) {
                                                listener5.f(c.f(c.X));
                                                break;
                                            }
                                            break;
                                    }
                                }
                            });
                        }
                        g();
                        a();
                    } else {
                        this.O = false;
                        d(width, (100.0f * ed.f(this).density) + height3, 14, this.d0, 320.0f, c.a.b);
                        this.l = this.b0;
                        this.k = 0.55f;
                        post(new Runnable(this) { // from class: li
                            public final /* synthetic */ KnifeView b;

                            {
                                this.b = this;
                            }

                            @Override // java.lang.Runnable
                            public final void run() {
                                int i82 = i5;
                                KnifeView knifeView = this.b;
                                switch (i82) {
                                    case 0:
                                        int i92 = KnifeView.e0;
                                        a.InterfaceC0035a listener = knifeView.getListener();
                                        if (listener != null) {
                                            listener.e(200L);
                                            break;
                                        }
                                        break;
                                    case 1:
                                        int i102 = KnifeView.e0;
                                        a.InterfaceC0035a listener2 = knifeView.getListener();
                                        if (listener2 != null) {
                                            listener2.f(c.f(c.U));
                                            break;
                                        }
                                        break;
                                    case 2:
                                        int i112 = KnifeView.e0;
                                        a.InterfaceC0035a listener3 = knifeView.getListener();
                                        if (listener3 != null) {
                                            listener3.f(c.f(c.V));
                                            break;
                                        }
                                        break;
                                    case 3:
                                        int i12 = KnifeView.e0;
                                        a.InterfaceC0035a listener4 = knifeView.getListener();
                                        if (listener4 != null) {
                                            listener4.e(30L);
                                            break;
                                        }
                                        break;
                                    default:
                                        int i13 = KnifeView.e0;
                                        a.InterfaceC0035a listener5 = knifeView.getListener();
                                        if (listener5 != null) {
                                            listener5.f(c.f(c.X));
                                            break;
                                        }
                                        break;
                                }
                            }
                        });
                        post(new Runnable(this) { // from class: li
                            public final /* synthetic */ KnifeView b;

                            {
                                this.b = this;
                            }

                            @Override // java.lang.Runnable
                            public final void run() {
                                int i82 = i2;
                                KnifeView knifeView = this.b;
                                switch (i82) {
                                    case 0:
                                        int i92 = KnifeView.e0;
                                        a.InterfaceC0035a listener = knifeView.getListener();
                                        if (listener != null) {
                                            listener.e(200L);
                                            break;
                                        }
                                        break;
                                    case 1:
                                        int i102 = KnifeView.e0;
                                        a.InterfaceC0035a listener2 = knifeView.getListener();
                                        if (listener2 != null) {
                                            listener2.f(c.f(c.U));
                                            break;
                                        }
                                        break;
                                    case 2:
                                        int i112 = KnifeView.e0;
                                        a.InterfaceC0035a listener3 = knifeView.getListener();
                                        if (listener3 != null) {
                                            listener3.f(c.f(c.V));
                                            break;
                                        }
                                        break;
                                    case 3:
                                        int i12 = KnifeView.e0;
                                        a.InterfaceC0035a listener4 = knifeView.getListener();
                                        if (listener4 != null) {
                                            listener4.e(30L);
                                            break;
                                        }
                                        break;
                                    default:
                                        int i13 = KnifeView.e0;
                                        a.InterfaceC0035a listener5 = knifeView.getListener();
                                        if (listener5 != null) {
                                            listener5.f(c.f(c.X));
                                            break;
                                        }
                                        break;
                                }
                            }
                        });
                        f(new sf(0, 0, false, 0, false, false, 0, 0, this.L, this.M, this.P, this.N, getPrefs().a.getInt("stat_total_knives", 0), 0, 0, null, 57599));
                    }
                } else {
                    z = false;
                    float height32 = getHeight() * 0.38f;
                    float width2 = getWidth() / 2.0f;
                    if (z) {
                    }
                }
            }
        }
        int size3 = arrayList2.size();
        while (i5 < size3) {
            Object obj3 = arrayList2.get(i5);
            i5++;
            b bVar2 = (b) obj3;
            bVar2.b -= (40.0f * ed.f(this).density) * f;
            bVar2.c -= f / 0.7f;
        }
        u7.U(arrayList2, new c8(1));
        g();
        a();
    }

    public final void m(Canvas canvas, float f, float f2, int i, float f3) {
        float f4 = 6.0f * ed.f(this).density;
        getFillPaint().setColor(i);
        float f5 = f4 / 2.0f;
        float f6 = f - f5;
        float f7 = f5 + f;
        float f8 = (0.62f * f3) + f2;
        RectF rectF = this.R;
        rectF.set(f6, f2, f7, f8);
        canvas.drawRoundRect(rectF, ed.f(this).density * 2.0f, 2.0f * ed.f(this).density, getFillPaint());
        getFillPaint().setColor(getContext().getColor(R.color.colorKnifeEdge));
        Path path = this.Q;
        path.reset();
        Resources resources = getResources();
        resources.getClass();
        path.moveTo(f, f2 - (8.0f * resources.getDisplayMetrics().density));
        path.lineTo(f6, (ed.f(this).density * 4.0f) + f2);
        path.lineTo(f7, (4.0f * ed.f(this).density) + f2);
        path.close();
        canvas.drawPath(path, getFillPaint());
        getFillPaint().setColor(getContext().getColor(R.color.colorLog));
        float f9 = f4 * 0.7f;
        rectF.set(f - f9, f8, f + f9, f2 + f3);
        canvas.drawRoundRect(rectF, ed.f(this).density * 3.0f, 3.0f * ed.f(this).density, getFillPaint());
    }

    public final void n() {
        this.w.clear();
        ArrayList arrayList = this.x;
        arrayList.clear();
        this.y.clear();
        this.z = 0.0f;
        this.A = 0;
        this.B = 0.0f;
        this.F = false;
        int iMin = Math.min(15, this.C + 4);
        this.D = iMin;
        this.E = iMin;
        this.O = true;
        this.J = 1.0f;
        this.G = 0.0f;
        cp.a.getClass();
        int iE = cp.b.e(2) + 2;
        for (int i = 0; i < iE; i++) {
            float fD = (cp.a.d() * 20.0f) + ((360.0f / iE) * i);
            a aVar = new a();
            aVar.a = fD;
            aVar.b = false;
            arrayList.add(aVar);
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        if (motionEvent.getAction() == 0 && !this.g && !this.h && !this.K && !this.F && this.E > 0) {
            this.F = true;
            this.G = 0.0f;
        }
        return true;
    }
}
