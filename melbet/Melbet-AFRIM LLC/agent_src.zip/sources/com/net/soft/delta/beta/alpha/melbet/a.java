package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.net.soft.delta.beta.alpha.melbet.c;
import defpackage.p2;
import defpackage.qm;
import defpackage.sf;
import defpackage.u4;
import defpackage.uf;
import java.util.ArrayList;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public abstract class a extends SurfaceView implements SurfaceHolder.Callback {
    public final uf a;
    public final d b;
    public final Paint c;
    public final Paint d;
    public final Paint e;
    public volatile boolean f;
    public volatile boolean g;
    public volatile boolean h;
    public Thread i;
    public long j;
    public float k;
    public int l;
    public int m;
    public int n;
    public int o;
    public int p;
    public float q;
    public String r;
    public InterfaceC0035a s;
    public boolean t;
    public int u;
    public boolean v;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    /* renamed from: com.net.soft.delta.beta.alpha.melbet.a$a, reason: collision with other inner class name */
    public interface InterfaceC0035a {
        void a(int i);

        void b(int i, int i2);

        void c(int i);

        void d(int i, int i2);

        void e(long j);

        void f(String str);

        void g(int i, int i2, sf sfVar);

        void h();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.a = new uf(context);
        this.b = new d();
        this.c = new Paint(1);
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.d = paint;
        Paint paint2 = new Paint(1);
        paint2.setColor(-1);
        paint2.setTextAlign(Paint.Align.CENTER);
        this.e = paint2;
        this.l = -1;
        this.r = "";
        getHolder().addCallback(this);
        setFocusable(true);
    }

    public final void a() {
        if (!this.t || this.v) {
            return;
        }
        int i = this.m;
        int i2 = this.u;
        if (i < i2 || i2 <= 0) {
            return;
        }
        this.v = true;
        post(new u4(this, 1));
    }

    public final void c(Canvas canvas) {
        if (this.a.a.getBoolean("show_fps", false)) {
            Paint.Align align = Paint.Align.LEFT;
            Paint paint = this.e;
            paint.setTextAlign(align);
            Resources resources = getResources();
            resources.getClass();
            paint.setTextSize(resources.getDisplayMetrics().density * 12.0f);
            paint.setColor(-1);
            String strB = qm.b("FPS: ", this.o);
            Resources resources2 = getResources();
            resources2.getClass();
            float f = 12.0f * resources2.getDisplayMetrics().density;
            float height = getHeight();
            Resources resources3 = getResources();
            resources3.getClass();
            canvas.drawText(strB, f, height - (16.0f * resources3.getDisplayMetrics().density), paint);
            paint.setTextAlign(Paint.Align.CENTER);
        }
    }

    public final void d(float f, float f2, int i, int i2, float f3, c.a aVar) {
        if (this.a.a.getBoolean("particles_enabled", true)) {
            d dVar = this.b;
            dVar.getClass();
            for (int i3 = 0; i3 < i; i3++) {
                double dRandom = Math.random() * 3.141592653589793d * 2.0d;
                ArrayList arrayList = dVar.a;
                double d = f3;
                float fRandom = (float) (((Math.random() * 0.5d) + 0.5d) * Math.cos(dRandom) * d);
                float fRandom2 = (float) (((Math.random() * 0.5d) + 0.5d) * Math.sin(dRandom) * d);
                float fRandom3 = (float) ((Math.random() * 12.0d) + 8.0d);
                float fRandom4 = (float) ((Math.random() * 720.0d) - 360.0d);
                c cVar = new c();
                cVar.a = f;
                cVar.b = f2;
                cVar.c = fRandom;
                cVar.d = fRandom2;
                cVar.e = 1.0f;
                cVar.f = fRandom3;
                cVar.g = i2;
                cVar.h = 0.0f;
                cVar.i = fRandom4;
                cVar.j = aVar;
                arrayList.add(cVar);
            }
        }
    }

    public int e() {
        return 0;
    }

    public final void f(sf sfVar) {
        if (this.h) {
            return;
        }
        this.h = true;
        post(new p2(this, sfVar, 1));
    }

    public final void g() {
        String str = this.m + ":" + e() + ":" + this.n;
        if (str.equals(this.r)) {
            return;
        }
        this.r = str;
        post(new u4(this, 2));
    }

    public final int getDailyTarget() {
        return this.u;
    }

    public final Paint getFillPaint() {
        return this.c;
    }

    public final float getFlashAlpha() {
        return this.k;
    }

    public final int getFlashColor() {
        return this.l;
    }

    public final int getFpsFrames() {
        return this.p;
    }

    public final float getFpsTimer() {
        return this.q;
    }

    public final int getFpsValue() {
        return this.o;
    }

    public final Thread getGameThread() {
        return this.i;
    }

    public final long getLastTime() {
        return this.j;
    }

    public final InterfaceC0035a getListener() {
        return this.s;
    }

    public final d getParticles() {
        return this.b;
    }

    public final uf getPrefs() {
        return this.a;
    }

    public final int getScore() {
        return this.m;
    }

    public final int getSessionCoins() {
        return this.n;
    }

    public final Paint getStrokePaint() {
        return this.d;
    }

    public final Paint getTextPaint() {
        return this.e;
    }

    public abstract void h(Canvas canvas);

    public abstract void i();

    public final void j() {
        if (!this.f && getWidth() > 0 && getHeight() > 0) {
            this.f = true;
            this.r = "";
            this.j = System.nanoTime();
            Thread thread = new Thread(new u4(this, 0));
            thread.start();
            this.i = thread;
        }
    }

    public final void k() {
        this.f = false;
        try {
            Thread thread = this.i;
            if (thread != null) {
                thread.join(250L);
            }
        } catch (InterruptedException unused) {
        }
        this.i = null;
    }

    public abstract void l(float f);

    public final void setDailyMode(boolean z) {
        this.t = z;
    }

    public final void setDailyTarget(int i) {
        this.u = i;
    }

    public final void setFlashAlpha(float f) {
        this.k = f;
    }

    public final void setFlashColor(int i) {
        this.l = i;
    }

    public final void setFpsFrames(int i) {
        this.p = i;
    }

    public final void setFpsTimer(float f) {
        this.q = f;
    }

    public final void setFpsValue(int i) {
        this.o = i;
    }

    public final void setGameOver(boolean z) {
        this.h = z;
    }

    public final void setGameThread(Thread thread) {
        this.i = thread;
    }

    public final void setLastTime(long j) {
        this.j = j;
    }

    public final void setListener(InterfaceC0035a interfaceC0035a) {
        this.s = interfaceC0035a;
    }

    public final void setPaused(boolean z) {
        this.g = z;
    }

    public final void setRunning(boolean z) {
        this.f = z;
    }

    public final void setScore(int i) {
        this.m = i;
    }

    public final void setSessionCoins(int i) {
        this.n = i;
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        surfaceHolder.getClass();
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        surfaceHolder.getClass();
        j();
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        surfaceHolder.getClass();
        k();
    }

    public void b() {
    }
}
