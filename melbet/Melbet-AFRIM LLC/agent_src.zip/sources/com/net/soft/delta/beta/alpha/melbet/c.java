package com.net.soft.delta.beta.alpha.melbet;

import defpackage.ed;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class c {
    public float a;
    public float b;
    public float c;
    public float d;
    public float e;
    public float f;
    public int g;
    public float h;
    public float i;
    public a j;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final a a;
        public static final a b;
        public static final /* synthetic */ a[] c;

        static {
            a aVar = new a("CIRCLE", 0);
            a = aVar;
            a aVar2 = new a("RECT", 1);
            b = aVar2;
            c = new a[]{aVar, aVar2};
        }

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) c.clone();
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return Float.compare(this.a, cVar.a) == 0 && Float.compare(this.b, cVar.b) == 0 && Float.compare(this.c, cVar.c) == 0 && Float.compare(this.d, cVar.d) == 0 && Float.compare(this.e, cVar.e) == 0 && Float.compare(this.f, cVar.f) == 0 && this.g == cVar.g && Float.compare(this.h, cVar.h) == 0 && Float.compare(this.i, cVar.i) == 0 && this.j == cVar.j;
    }

    public final int hashCode() {
        return this.j.hashCode() + ed.a(this.i, ed.a(this.h, ed.c(this.g, ed.a(this.f, ed.a(this.e, ed.a(this.d, ed.a(this.c, ed.a(this.b, Float.hashCode(this.a) * 31, 31), 31), 31), 31), 31), 31), 31), 31);
    }

    public final String toString() {
        return "Particle(posX=" + this.a + ", posY=" + this.b + ", velX=" + this.c + ", velY=" + this.d + ", alpha=" + this.e + ", size=" + this.f + ", color=" + this.g + ", rotation=" + this.h + ", rotSpeed=" + this.i + ", shape=" + this.j + ")";
    }
}
