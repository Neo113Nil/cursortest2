package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import defpackage.ai;
import defpackage.fs;
import defpackage.j3;
import defpackage.oc;
import defpackage.q7;
import defpackage.tf;
import defpackage.v6;
import defpackage.y;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class SkinPreviewView extends View {
    public final Paint a;
    public String b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SkinPreviewView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.a = new Paint(1);
        this.b = defpackage.c.h(defpackage.c.f0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v50, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r1v51, types: [java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r1v54, types: [oc] */
    /* JADX WARN: Type inference failed for: r1v57, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r1v58, types: [java.util.ArrayList] */
    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        ?? arrayList;
        canvas.getClass();
        super.onDraw(canvas);
        List<y> list = v6.a;
        fs fsVarD = v6.d(this.b);
        float width = getWidth() / 2.0f;
        float height = getHeight() / 2.0f;
        int color = getContext().getColor(R.color.colorCardElevated);
        Paint paint = this.a;
        paint.setColor(color);
        float width2 = getWidth();
        float height2 = getHeight();
        Resources resources = getResources();
        resources.getClass();
        float f = 12.0f * resources.getDisplayMetrics().density;
        Resources resources2 = getResources();
        resources2.getClass();
        canvas.drawRoundRect(0.0f, 0.0f, width2, height2, f, 12.0f * resources2.getDisplayMetrics().density, paint);
        String str = fsVarD.b;
        int[] iArr = fsVarD.g;
        int i = fsVarD.f;
        int i2 = fsVarD.e;
        if (ai.a(str, tf.a)) {
            paint.setColor(i2);
            Resources resources3 = getResources();
            resources3.getClass();
            float f2 = width - (resources3.getDisplayMetrics().density * 14.0f);
            Resources resources4 = getResources();
            resources4.getClass();
            float f3 = height - (resources4.getDisplayMetrics().density * 24.0f);
            Resources resources5 = getResources();
            resources5.getClass();
            float f4 = (14.0f * resources5.getDisplayMetrics().density) + width;
            Resources resources6 = getResources();
            resources6.getClass();
            float f5 = (24.0f * resources6.getDisplayMetrics().density) + height;
            Resources resources7 = getResources();
            resources7.getClass();
            float f6 = 6.0f * resources7.getDisplayMetrics().density;
            Resources resources8 = getResources();
            resources8.getClass();
            canvas.drawRoundRect(f2, f3, f4, f5, f6, 6.0f * resources8.getDisplayMetrics().density, paint);
            paint.setColor(i);
            Resources resources9 = getResources();
            resources9.getClass();
            canvas.drawCircle(width, height, 6.0f * resources9.getDisplayMetrics().density, paint);
            return;
        }
        int i3 = 0;
        if (ai.a(str, tf.d)) {
            if (iArr.length == 0) {
                iArr = new int[]{i2};
            }
            if (5 >= iArr.length) {
                int length = iArr.length;
                if (length == 0) {
                    arrayList = oc.a;
                } else if (length != 1) {
                    arrayList = new ArrayList(iArr.length);
                    for (int i4 : iArr) {
                        arrayList.add(Integer.valueOf(i4));
                    }
                } else {
                    arrayList = j3.D(Integer.valueOf(iArr[0]));
                }
            } else {
                arrayList = new ArrayList(5);
                int i5 = 0;
                for (int i6 : iArr) {
                    arrayList.add(Integer.valueOf(i6));
                    i5++;
                    if (i5 == 5) {
                        break;
                    }
                }
            }
            for (Object obj : arrayList) {
                int i7 = i3 + 1;
                if (i3 < 0) {
                    q7.R();
                    throw null;
                }
                paint.setColor(((Number) obj).intValue());
                double d = i3 * 72.0d;
                float fCos = (float) Math.cos(Math.toRadians(d));
                Resources resources10 = getResources();
                resources10.getClass();
                float f7 = (resources10.getDisplayMetrics().density * 16.0f * fCos) + width;
                float fSin = (float) Math.sin(Math.toRadians(d));
                Resources resources11 = getResources();
                resources11.getClass();
                float f8 = (resources11.getDisplayMetrics().density * 16.0f * fSin) + height;
                Resources resources12 = getResources();
                resources12.getClass();
                canvas.drawCircle(f7, f8, resources12.getDisplayMetrics().density * 8.0f, paint);
                i3 = i7;
            }
            return;
        }
        if (!ai.a(str, tf.e)) {
            if (iArr.length < 4) {
                iArr = new int[]{Color.parseColor(defpackage.c.h(defpackage.c.g0)), Color.parseColor(defpackage.c.h(defpackage.c.h0)), Color.parseColor(defpackage.c.h(defpackage.c.i0)), Color.parseColor(defpackage.c.h(defpackage.c.j0))};
            }
            int[] iArr2 = iArr;
            for (int i8 = 0; i8 < 4; i8++) {
                paint.setColor(iArr2[i8]);
                Resources resources13 = getResources();
                resources13.getClass();
                float f9 = width - (resources13.getDisplayMetrics().density * 22.0f);
                Resources resources14 = getResources();
                resources14.getClass();
                float f10 = height - (resources14.getDisplayMetrics().density * 22.0f);
                Resources resources15 = getResources();
                resources15.getClass();
                float f11 = (resources15.getDisplayMetrics().density * 22.0f) + width;
                Resources resources16 = getResources();
                resources16.getClass();
                Paint paint2 = paint;
                canvas.drawArc(f9, f10, f11, (22.0f * resources16.getDisplayMetrics().density) + height, 90.0f * i8, 88.0f, true, paint2);
                paint = paint2;
            }
            return;
        }
        paint.setColor(i);
        Resources resources17 = getResources();
        resources17.getClass();
        float f12 = height - (8.0f * resources17.getDisplayMetrics().density);
        Resources resources18 = getResources();
        resources18.getClass();
        canvas.drawCircle(width, f12, 16.0f * resources18.getDisplayMetrics().density, paint);
        paint.setColor(i2);
        Resources resources19 = getResources();
        resources19.getClass();
        float f13 = width - (resources19.getDisplayMetrics().density * 4.0f);
        Resources resources20 = getResources();
        resources20.getClass();
        float f14 = height - (resources20.getDisplayMetrics().density * 4.0f);
        Resources resources21 = getResources();
        resources21.getClass();
        float f15 = (4.0f * resources21.getDisplayMetrics().density) + width;
        Resources resources22 = getResources();
        resources22.getClass();
        float f16 = (26.0f * resources22.getDisplayMetrics().density) + height;
        Resources resources23 = getResources();
        resources23.getClass();
        float f17 = resources23.getDisplayMetrics().density * 2.0f;
        Resources resources24 = getResources();
        resources24.getClass();
        canvas.drawRoundRect(f13, f14, f15, f16, f17, 2.0f * resources24.getDisplayMetrics().density, paint);
    }
}
