package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.net.soft.delta.beta.alpha.melbet.ColorView;
import com.net.soft.delta.beta.alpha.melbet.c;
import defpackage.a8;
import defpackage.bf;
import defpackage.c4;
import defpackage.c8;
import defpackage.cp;
import defpackage.dp;
import defpackage.ed;
import defpackage.jm;
import defpackage.q7;
import defpackage.sf;
import defpackage.tf;
import defpackage.u7;
import defpackage.v6;
import defpackage.wh;
import defpackage.xh;
import defpackage.y;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class ColorView extends com.net.soft.delta.beta.alpha.melbet.a {
    public static final /* synthetic */ int Q = 0;
    public final ArrayList A;
    public float B;
    public float C;
    public float D;
    public int E;
    public float F;
    public float G;
    public float H;
    public int I;
    public int J;
    public boolean K;
    public final RectF L;
    public final Path M;
    public final int N;
    public final int O;
    public final int P;
    public final ArrayList w;
    public final ArrayList x;
    public final ArrayList y;
    public final c4<f> z;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public float a;
        public float b;
        public float c;
        public int d;
        public float e;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return Float.compare(this.a, aVar.a) == 0 && Float.compare(this.b, aVar.b) == 0 && Float.compare(this.c, aVar.c) == 0 && this.d == aVar.d && Float.compare(this.e, aVar.e) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.e) + ed.c(this.d, ed.a(this.c, ed.a(this.b, Float.hashCode(this.a) * 31, 31), 31), 31);
        }

        public final String toString() {
            return "BgStar(posX=" + this.a + ", posY=" + this.b + ", size=" + this.c + ", color=" + this.d + ", speed=" + this.e + ")";
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public String a;
        public float b;
        public float c;
        public float d;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.a.equals(bVar.a) && Float.compare(this.b, bVar.b) == 0 && Float.compare(this.c, bVar.c) == 0 && Float.compare(this.d, bVar.d) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.d) + ed.a(this.c, ed.a(this.b, this.a.hashCode() * 31, 31), 31);
        }

        public final String toString() {
            return "FloatText(text=" + this.a + ", posY=" + this.b + ", alpha=" + this.c + ", posX=" + this.d + ")";
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c {
        public static final c a;
        public static final /* synthetic */ c[] b;

        /* JADX INFO: Fake field, exist only in values array */
        c EF0;

        static {
            c cVar = new c("RING", 0);
            c cVar2 = new c("SPINNER", 1);
            c cVar3 = new c("TRIANGLE", 2);
            c cVar4 = new c("DOUBLE_RING", 3);
            a = cVar4;
            b = new c[]{cVar, cVar2, cVar3, cVar4};
        }

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) b.clone();
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class d {
        public final c a;
        public final float b;
        public float c;
        public boolean d;

        public d(c cVar, float f, float f2) {
            cVar.getClass();
            this.a = cVar;
            this.b = f;
            this.c = f2;
            this.d = false;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof d)) {
                return false;
            }
            d dVar = (d) obj;
            return this.a == dVar.a && Float.compare(this.b, dVar.b) == 0 && Float.compare(this.c, dVar.c) == 0 && this.d == dVar.d;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.d) + ed.a(this.c, ed.a(this.b, this.a.hashCode() * 31, 31), 31);
        }

        public final String toString() {
            return "Obstacle(kind=" + this.a + ", worldY=" + this.b + ", rotation=" + this.c + ", passed=" + this.d + ")";
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class e {
        public float a;
        public boolean b;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            return Float.compare(this.a, eVar.a) == 0 && this.b == eVar.b;
        }

        public final int hashCode() {
            return Boolean.hashCode(this.b) + (Float.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "StarDust(worldY=" + this.a + ", taken=" + this.b + ")";
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class f {
        public float a;
        public float b;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof f)) {
                return false;
            }
            f fVar = (f) obj;
            return Float.compare(this.a, fVar.a) == 0 && Float.compare(this.b, fVar.b) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.b) + (Float.hashCode(this.a) * 31);
        }

        public final String toString() {
            return "TrailPoint(posX=" + this.a + ", posY=" + this.b + ")";
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ColorView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.w = new ArrayList();
        this.x = new ArrayList();
        this.y = new ArrayList();
        this.z = new c4<>();
        this.A = new ArrayList();
        this.F = 1.0f;
        this.H = 70.0f;
        this.L = new RectF();
        this.M = new Path();
        this.N = context.getColor(R.color.colorSwitchBg);
        this.O = context.getColor(R.color.colorStar);
        this.P = context.getColor(R.color.colorRed);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final int e() {
        return 0;
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void h(Canvas canvas) {
        int i;
        float f2;
        ArrayList arrayList;
        int[] iArr;
        ColorView colorView;
        ColorView colorView2 = this;
        Canvas canvas2 = canvas;
        canvas2.drawColor(colorView2.N);
        ArrayList arrayList2 = colorView2.y;
        int size = arrayList2.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList2.get(i2);
            i2++;
            a aVar = (a) obj;
            colorView2.getFillPaint().setColor(aVar.d);
            colorView2.getFillPaint().setAlpha(140);
            canvas2.drawCircle(aVar.a * colorView2.getWidth(), aVar.b, aVar.c, colorView2.getFillPaint());
            colorView2.getFillPaint().setAlpha(255);
        }
        float f3 = 2.0f;
        float width = colorView2.getWidth() / 2.0f;
        float f4 = colorView2.B - colorView2.D;
        int[] iArrO = colorView2.o();
        Iterator<f> it = colorView2.z.iterator();
        int i3 = 0;
        while (it.hasNext()) {
            f next = it.next();
            int i4 = i3 + 1;
            if (i3 < 0) {
                q7.R();
                throw null;
            }
            f fVar = next;
            colorView2.getFillPaint().setColor(iArrO[colorView2.E]);
            float f5 = i3;
            colorView2.getFillPaint().setAlpha((int) ((1.0f - (f5 / 8.0f)) * 140.0f));
            canvas2.drawCircle(fVar.a, fVar.b, (1.0f - (f5 / 10.0f)) * 8.0f * ed.e(colorView2).density, colorView2.getFillPaint());
            colorView2.getFillPaint().setAlpha(255);
            i3 = i4;
        }
        ArrayList arrayList3 = colorView2.w;
        int size2 = arrayList3.size();
        int i5 = 0;
        while (i5 < size2) {
            int i6 = i5 + 1;
            d dVar = (d) arrayList3.get(i5);
            float width2 = colorView2.getWidth() / f3;
            float f6 = dVar.b - colorView2.D;
            int iOrdinal = dVar.a.ordinal();
            if (iOrdinal != 0) {
                if (iOrdinal != 1) {
                    f2 = f3;
                    if (iOrdinal == 2) {
                        iArr = iArrO;
                        colorView = colorView2;
                        float f7 = 70.0f * ed.e(colorView).density;
                        int i7 = 0;
                        for (int i8 = 3; i7 < i8; i8 = 3) {
                            double radians = Math.toRadians((i7 * 120.0f) + dVar.c);
                            float fCos = (((float) Math.cos(radians)) * f7) + width2;
                            float fSin = (((float) Math.sin(radians)) * f7) + f6;
                            colorView.getFillPaint().setColor(iArr[i7]);
                            Path path = colorView.M;
                            path.reset();
                            Resources resources = colorView.getResources();
                            resources.getClass();
                            path.moveTo(fCos, fSin - (16.0f * resources.getDisplayMetrics().density));
                            path.lineTo(fCos - (ed.e(colorView).density * 14.0f), (ed.e(colorView).density * 12.0f) + fSin);
                            path.lineTo((14.0f * ed.e(colorView).density) + fCos, (12.0f * ed.e(colorView).density) + fSin);
                            path.close();
                            canvas2.drawPath(path, colorView.getFillPaint());
                            i7++;
                            arrayList3 = arrayList3;
                        }
                        arrayList = arrayList3;
                    } else {
                        if (iOrdinal != 3) {
                            throw new jm();
                        }
                        colorView2.n(canvas2, width2, f6, 92.0f * ed.e(colorView2).density, dVar.c, iArrO);
                        colorView2 = this;
                        canvas2 = canvas;
                        colorView2.n(canvas2, width2, f6, 58.0f * ed.e(this).density, -dVar.c, iArrO);
                        arrayList = arrayList3;
                    }
                } else {
                    iArr = iArrO;
                    f2 = f3;
                    arrayList = arrayList3;
                    colorView = colorView2;
                    float f8 = f6;
                    canvas2.save();
                    canvas2.rotate(dVar.c, width2, f8);
                    float width3 = colorView.getWidth() * 0.7f;
                    float f9 = 20.0f * ed.e(colorView).density;
                    float f10 = width2 - (width3 / f2);
                    int i9 = 0;
                    while (i9 < 4) {
                        colorView.getFillPaint().setColor(iArr[i9]);
                        float f11 = f9 / f2;
                        int i10 = i9 + 1;
                        canvas2.drawRect(((i9 * width3) / 4.0f) + f10, f8 - f11, ((i10 * width3) / 4.0f) + f10, f8 + f11, colorView.getFillPaint());
                        canvas2 = canvas;
                        i9 = i10;
                        f8 = f8;
                    }
                    canvas.restore();
                    canvas2 = canvas;
                }
                colorView2 = colorView;
                iArrO = iArr;
            } else {
                int[] iArr2 = iArrO;
                f2 = f3;
                arrayList = arrayList3;
                ColorView colorView3 = colorView2;
                canvas2 = canvas;
                colorView2 = colorView3;
                iArrO = iArr2;
                colorView2.n(canvas2, width2, f6, 92.0f * ed.e(colorView3).density, dVar.c, iArrO);
            }
            i5 = i6;
            f3 = f2;
            arrayList3 = arrayList;
        }
        ArrayList arrayList4 = colorView2.x;
        int size3 = arrayList4.size();
        int i11 = 0;
        while (true) {
            i = colorView2.O;
            if (i11 >= size3) {
                break;
            }
            Object obj2 = arrayList4.get(i11);
            i11++;
            e eVar = (e) obj2;
            if (!eVar.b) {
                colorView2.getTextPaint().setColor(i);
                colorView2.getTextPaint().setTextSize(24.0f * ed.e(colorView2).density);
                canvas2.drawText("★", width, eVar.a - colorView2.D, colorView2.getTextPaint());
            }
        }
        colorView2.getFillPaint().setColor(iArrO[colorView2.E]);
        Resources resources2 = colorView2.getResources();
        resources2.getClass();
        canvas2.drawCircle(width, f4, 9.0f * resources2.getDisplayMetrics().density * colorView2.F, colorView2.getFillPaint());
        colorView2.getTextPaint().setColor(i);
        ArrayList arrayList5 = colorView2.A;
        int size4 = arrayList5.size();
        int i12 = 0;
        while (i12 < size4) {
            Object obj3 = arrayList5.get(i12);
            i12++;
            b bVar = (b) obj3;
            colorView2.getTextPaint().setAlpha((int) (dp.o(bVar.c, 0.0f, 1.0f) * 255.0f));
            colorView2.getTextPaint().setTextSize(ed.e(colorView2).density * 20.0f);
            canvas2.drawText(bVar.a, bVar.d, bVar.b, colorView2.getTextPaint());
            colorView2.getTextPaint().setAlpha(255);
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void i() {
        k();
        this.w.clear();
        this.x.clear();
        this.z.clear();
        this.A.clear();
        getParticles().a.clear();
        setScore(0);
        setSessionCoins(0);
        this.I = 0;
        this.J = 0;
        this.K = false;
        setGameOver(false);
        setPaused(false);
        this.E = 0;
        this.F = 1.0f;
        this.C = 0.0f;
        this.H = 70.0f;
        this.B = 0.0f;
        this.D = 0.0f;
        this.G = 0.0f;
        ArrayList arrayList = this.y;
        if (arrayList.isEmpty()) {
            for (int i = 0; i < 50; i++) {
                cp.a aVar = cp.a;
                float fD = aVar.d();
                float fD2 = aVar.d() * 2000.0f;
                float fD3 = (aVar.d() * 2.5f) + 1.5f;
                int[] iArrO = o();
                if (iArrO.length == 0) {
                    throw new NoSuchElementException("Array is empty.");
                }
                int i2 = iArrO[cp.b.e(iArrO.length)];
                float fD4 = (aVar.d() * 28.0f) + 12.0f;
                a aVar2 = new a();
                aVar2.a = fD;
                aVar2.b = fD2;
                aVar2.c = fD3;
                aVar2.d = i2;
                aVar2.e = fD4;
                arrayList.add(aVar2);
            }
        }
        g();
        j();
    }

    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r14v4 */
    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void l(float f2) {
        c cVar;
        c.a aVar;
        c.a aVar2;
        float f3;
        int i;
        float f4;
        ArrayList arrayList;
        boolean z;
        float f5;
        float f6;
        char c2;
        ArrayList arrayList2;
        int i2;
        final ColorView colorView = this;
        if (colorView.getWidth() <= 0 || colorView.getHeight() <= 0 || colorView.K) {
            return;
        }
        char c3 = 4;
        final int i3 = 0;
        if (colorView.B == 0.0f) {
            float height = colorView.getHeight() * 0.62f;
            colorView.B = height;
            colorView.D = height - (colorView.getHeight() * 0.62f);
            colorView.G = colorView.B - (280.0f * ed.e(colorView).density);
            float f7 = ed.e(colorView).density * 250.0f;
            for (int i4 = 0; i4 < 4; i4++) {
                colorView.q((colorView.B - (220.0f * ed.e(colorView).density)) - (i4 * f7));
            }
        }
        float f8 = (980.0f * ed.e(colorView).density * f2) + colorView.C;
        colorView.C = f8;
        float f9 = (f8 * f2) + colorView.B;
        colorView.B = f9;
        float f10 = colorView.D;
        colorView.D = (Math.min(1.0f, 8.0f * f2) * ((f9 - (colorView.getHeight() * 0.62f)) - f10)) + f10;
        colorView.H = (1.1999999f * f2) + colorView.H;
        Resources resources = colorView.getResources();
        resources.getClass();
        float score = 250.0f - (colorView.getScore() * 1.2f);
        if (score < 180.0f) {
            score = 180.0f;
        }
        float f11 = score * resources.getDisplayMetrics().density;
        while (colorView.G > colorView.D - colorView.getHeight()) {
            colorView.q(colorView.G);
            colorView.G -= f11;
        }
        ArrayList arrayList3 = colorView.w;
        int size = arrayList3.size();
        int i5 = 0;
        while (true) {
            cVar = c.a;
            if (i5 >= size) {
                break;
            }
            Object obj = arrayList3.get(i5);
            i5++;
            d dVar = (d) obj;
            dVar.c = (colorView.H * (dVar.a == cVar ? -1.0f : 1.0f) * f2) + dVar.c;
        }
        u7.U(arrayList3, new bf(colorView) { // from class: b8
            public final /* synthetic */ ColorView b;

            {
                this.b = colorView;
            }

            @Override // defpackage.bf
            public final Object f(Object obj2) {
                int i6 = i3;
                ColorView colorView2 = this.b;
                switch (i6) {
                    case 0:
                        ColorView.d dVar2 = (ColorView.d) obj2;
                        int i7 = ColorView.Q;
                        dVar2.getClass();
                        return Boolean.valueOf(dVar2.b - colorView2.D > (80.0f * ed.e(colorView2).density) + ((float) colorView2.getHeight()));
                    default:
                        ColorView.e eVar = (ColorView.e) obj2;
                        int i8 = ColorView.Q;
                        eVar.getClass();
                        if (!eVar.b) {
                            if (eVar.a - colorView2.D <= (80.0f * ed.e(colorView2).density) + colorView2.getHeight()) {
                                z = false;
                            }
                        }
                        return Boolean.valueOf(z);
                }
            }
        });
        ?? r14 = 1;
        char c4 = 1;
        final char c5 = 1 == true ? 1 : 0;
        bf bfVar = new bf(colorView) { // from class: b8
            public final /* synthetic */ ColorView b;

            {
                this.b = colorView;
            }

            @Override // defpackage.bf
            public final Object f(Object obj2) {
                int i6 = c5;
                ColorView colorView2 = this.b;
                switch (i6) {
                    case 0:
                        ColorView.d dVar2 = (ColorView.d) obj2;
                        int i7 = ColorView.Q;
                        dVar2.getClass();
                        return Boolean.valueOf(dVar2.b - colorView2.D > (80.0f * ed.e(colorView2).density) + ((float) colorView2.getHeight()));
                    default:
                        ColorView.e eVar = (ColorView.e) obj2;
                        int i8 = ColorView.Q;
                        eVar.getClass();
                        if (!eVar.b) {
                            if (eVar.a - colorView2.D <= (80.0f * ed.e(colorView2).density) + colorView2.getHeight()) {
                                z = false;
                            }
                        }
                        return Boolean.valueOf(z);
                }
            }
        };
        ArrayList arrayList4 = colorView.x;
        u7.U(arrayList4, bfVar);
        ArrayList arrayList5 = colorView.y;
        int size2 = arrayList5.size();
        int i6 = 0;
        while (i6 < size2) {
            Object obj2 = arrayList5.get(i6);
            i6++;
            a aVar3 = (a) obj2;
            float f12 = aVar3.b - (aVar3.e * f2);
            aVar3.b = f12;
            if (f12 < 0.0f) {
                aVar3.b = colorView.getHeight();
            }
        }
        float f13 = 2.0f;
        float f14 = colorView.B - colorView.D;
        f fVar = new f();
        fVar.a = colorView.getWidth() / 2.0f;
        fVar.b = f14;
        c4<f> c4Var = colorView.z;
        c4Var.addFirst(fVar);
        while (c4Var.c > 8) {
            c4Var.removeLast();
        }
        float f15 = colorView.F;
        if (f15 > 1.0f) {
            float f16 = f15 - (f2 / 0.2f);
            if (f16 < 1.0f) {
                f16 = 1.0f;
            }
            colorView.F = f16;
        }
        ArrayList arrayList6 = colorView.A;
        int size3 = arrayList6.size();
        int i7 = 0;
        while (i7 < size3) {
            Object obj3 = arrayList6.get(i7);
            i7++;
            b bVar = (b) obj3;
            bVar.b -= (50.0f * ed.e(colorView).density) * f2;
            bVar.c -= f2 / 0.6f;
        }
        u7.U(arrayList6, new c8(0));
        if (colorView.B - colorView.D > (30.0f * ed.e(colorView).density) + colorView.getHeight()) {
            colorView.m();
            return;
        }
        float width = colorView.getWidth() / 2.0f;
        float f17 = 9.0f * ed.e(colorView).density;
        int size4 = arrayList4.size();
        int i8 = 0;
        while (true) {
            aVar = c.a.a;
            if (i8 >= size4) {
                break;
            }
            int i9 = i8 + 1;
            e eVar = (e) arrayList4.get(i8);
            boolean z2 = eVar.b;
            float f18 = eVar.a;
            if (z2) {
                c2 = c3;
                arrayList2 = arrayList3;
            } else {
                c2 = c3;
                arrayList2 = arrayList3;
                if (((float) Math.hypot(0.0d, f18 - colorView.B)) < (16.0f * ed.e(colorView).density) + f17) {
                    eVar.b = true;
                    colorView.J++;
                    colorView.setSessionCoins(colorView.getSessionCoins() + 1);
                    colorView.getPrefs().e("stat_stars", 1);
                    i2 = size4;
                    colorView.d(width, f18 - colorView.D, 8, colorView.O, 220.0f, aVar);
                    colorView.post(new a8(colorView, c4 == true ? 1 : 0));
                }
                size4 = i2;
                i8 = i9;
                c3 = c2;
                arrayList3 = arrayList2;
            }
            i2 = size4;
            size4 = i2;
            i8 = i9;
            c3 = c2;
            arrayList3 = arrayList2;
        }
        ArrayList arrayList7 = arrayList3;
        float width2 = colorView.getWidth() / 2.0f;
        float f19 = colorView.B - colorView.D;
        float f20 = 9.0f * ed.e(colorView).density;
        int size5 = arrayList7.size();
        int i10 = 0;
        while (i10 < size5) {
            ArrayList arrayList8 = arrayList7;
            int i11 = i10 + 1;
            d dVar2 = (d) arrayList8.get(i10);
            float f21 = dVar2.b;
            c cVar2 = dVar2.a;
            float f22 = f21 - colorView.D;
            if (dVar2.d || colorView.B >= f21) {
                aVar2 = aVar;
                f3 = f13;
                i = 3;
            } else {
                dVar2.d = r14;
                colorView.I += r14;
                colorView.setScore(colorView.getScore() + r14);
                colorView.setSessionCoins(colorView.getScore() / 4);
                int i12 = colorView.E;
                f3 = f13;
                xh xhVar = new xh(0, 3, r14);
                ArrayList arrayList9 = new ArrayList();
                Iterator<Integer> it = xhVar.iterator();
                while (((wh) it).c) {
                    Object next = ((wh) it).next();
                    if (((Number) next).intValue() != i12) {
                        arrayList9.add(next);
                    }
                }
                cp.a.getClass();
                if (arrayList9.isEmpty()) {
                    throw new NoSuchElementException("Collection is empty.");
                }
                colorView.E = ((Number) arrayList9.get(cp.b.e(arrayList9.size()))).intValue();
                colorView.F = 1.4f;
                String strC = defpackage.c.c(defpackage.c.t);
                b bVar2 = new b();
                bVar2.a = strC;
                bVar2.b = f19;
                bVar2.c = 1.0f;
                bVar2.d = width2;
                arrayList6.add(bVar2);
                float f23 = f19;
                float f24 = width2;
                i = 3;
                colorView.d(f24, f23, 6, colorView.o()[colorView.E], 200.0f, aVar);
                f19 = f23;
                aVar2 = aVar;
                width2 = f24;
                colorView.post(new a8(colorView, i));
            }
            int iOrdinal = cVar2.ordinal();
            if (iOrdinal == 0) {
                float f25 = width2;
                f4 = 92.0f * ed.e(colorView).density;
                float f26 = 58.0f * ed.e(colorView).density;
                arrayList = arrayList6;
                z = true;
                width2 = f25;
                f5 = f20;
                if (colorView.p(dVar2, width2, f19, f5, colorView.getWidth() / f3, f22, f4, false)) {
                    m();
                    break;
                    break;
                } else {
                    m();
                    break;
                    break;
                }
            }
            boolean z3 = true;
            if (iOrdinal == 1) {
                f6 = width2;
                int i13 = i;
                float width3 = colorView.getWidth() * 0.7f;
                float f27 = 20.0f * ed.e(colorView).density;
                double radians = Math.toRadians(-dVar2.c);
                double width4 = f6 - (colorView.getWidth() / f3);
                double dCos = Math.cos(radians) * width4;
                double d2 = f19 - f22;
                float fSin = (float) (dCos - (Math.sin(radians) * d2));
                float fCos = (float) ((Math.cos(radians) * d2) + (Math.sin(radians) * width4));
                float f28 = width3 / f3;
                if (Math.abs(fSin) > f28 + f20 || Math.abs(fCos) > (f27 / f3) + f20 || dp.p((int) (((fSin + f28) / width3) * 4.0f), i13) == colorView.E) {
                    width2 = f6;
                    arrayList = arrayList6;
                    f5 = f20;
                    z = true;
                }
                width2 = f6;
                arrayList = arrayList6;
                f5 = f20;
                z = true;
            } else if (iOrdinal != 2) {
                if (iOrdinal != i) {
                    throw new jm();
                }
                float f252 = width2;
                f4 = 92.0f * ed.e(colorView).density;
                float f262 = 58.0f * ed.e(colorView).density;
                arrayList = arrayList6;
                z = true;
                width2 = f252;
                f5 = f20;
                if (colorView.p(dVar2, width2, f19, f5, colorView.getWidth() / f3, f22, f4, false) || (cVar2 == cVar && p(dVar2, width2, f19, f5, getWidth() / f3, f22, f262, true))) {
                }
            } else {
                float width5 = colorView.getWidth() / f3;
                float f29 = 70.0f * ed.e(colorView).density;
                int i14 = 0;
                while (i14 < i) {
                    int i15 = i;
                    double radians2 = Math.toRadians((i14 * 120.0f) + dVar2.c);
                    float f30 = width5;
                    f6 = width2;
                    if (((float) Math.hypot(f6 - ((((float) Math.cos(radians2)) * f29) + f30), f19 - ((((float) Math.sin(radians2)) * f29) + f22))) >= (ed.e(colorView).density * 16.0f) + f20 || i14 == colorView.E % 3) {
                        i14++;
                        i = i15;
                        width2 = f6;
                        width5 = f30;
                        z3 = true;
                    } else {
                        width2 = f6;
                        arrayList = arrayList6;
                        f5 = f20;
                        z = true;
                    }
                }
                z = z3;
                arrayList = arrayList6;
                f5 = f20;
            }
            m();
            break;
            colorView = this;
            f20 = f5;
            arrayList7 = arrayList8;
            i10 = i11;
            arrayList6 = arrayList;
            f13 = f3;
            aVar = aVar2;
            r14 = z;
        }
        g();
        a();
    }

    public final void m() {
        if (this.K) {
            return;
        }
        this.K = true;
        d(getWidth() / 2.0f, this.B - this.D, 12, o()[this.E], 280.0f, c.a.a);
        this.l = this.P;
        this.k = 0.5f;
        post(new a8(this, 2));
        f(new sf(0, 0, false, 0, false, false, 0, 0, 0, 0, false, 0, 0, this.I, this.J, null, 40959));
    }

    public final void n(Canvas canvas, float f2, float f3, float f4, float f5, int[] iArr) {
        float f6 = 16.0f * ed.e(this).density;
        getStrokePaint().setStyle(Paint.Style.STROKE);
        getStrokePaint().setStrokeWidth(f6);
        getStrokePaint().setStrokeCap(Paint.Cap.BUTT);
        RectF rectF = this.L;
        rectF.set(f2 - f4, f3 - f4, f2 + f4, f3 + f4);
        for (int i = 0; i < 4; i++) {
            getStrokePaint().setColor(iArr[i]);
            canvas.drawArc(rectF, (i * 90.0f) + f5, 88.0f, false, getStrokePaint());
        }
    }

    public final int[] o() {
        List<y> list = v6.a;
        int[] iArr = v6.d(getPrefs().b(tf.f)).g;
        return iArr.length >= 4 ? iArr : new int[]{getContext().getColor(R.color.colorSwRed), getContext().getColor(R.color.colorSwBlue), getContext().getColor(R.color.colorSwGreen), getContext().getColor(R.color.colorSwYellow)};
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        if (motionEvent.getAction() == 0 && !this.g && !this.h && !this.K) {
            this.C = -(600.0f * ed.e(this).density);
            post(new a8(this, 0));
        }
        return true;
    }

    public final boolean p(d dVar, float f2, float f3, float f4, float f5, float f6, float f7, boolean z) {
        double d2 = f2 - f5;
        double d3 = f3 - f6;
        if (Math.abs(((float) Math.hypot(d2, d3)) - f7) > f4 + (8.0f * ed.e(this).density)) {
            return false;
        }
        float degrees = (float) Math.toDegrees(Math.atan2(d3, d2));
        float f8 = dVar.c;
        if (z) {
            f8 = -f8;
        }
        float f9 = ((degrees - f8) + 360.0f) % 360.0f;
        if (f9 < 0.0f) {
            f9 += 360.0f;
        }
        return f9 % 90.0f <= 88.0f && dp.p((int) (f9 / 90.0f), 3) != this.E;
    }

    public final void q(float f2) {
        c[] cVarArrValues = c.values();
        cp.a aVar = cp.a;
        cVarArrValues.getClass();
        aVar.getClass();
        if (cVarArrValues.length == 0) {
            throw new NoSuchElementException("Array is empty.");
        }
        this.w.add(new d(cVarArrValues[cp.b.e(cVarArrValues.length)], f2, aVar.d() * 360.0f));
        float f3 = f2 - (90.0f * ed.e(this).density);
        e eVar = new e();
        eVar.a = f3;
        eVar.b = false;
        this.x.add(eVar);
    }
}
