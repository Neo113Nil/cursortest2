package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.net.soft.delta.beta.alpha.melbet.c;
import defpackage.ai;
import defpackage.b4;
import defpackage.cp;
import defpackage.dp;
import defpackage.ed;
import defpackage.fs;
import defpackage.g;
import defpackage.p2;
import defpackage.sf;
import defpackage.tf;
import defpackage.tn;
import defpackage.u7;
import defpackage.v6;
import defpackage.w7;
import defpackage.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class PianoView extends com.net.soft.delta.beta.alpha.melbet.a {
    public static final /* synthetic */ int S = 0;
    public float A;
    public float B;
    public float C;
    public float D;
    public float E;
    public int F;
    public int G;
    public int H;
    public int I;
    public boolean J;
    public float K;
    public int L;
    public boolean M;
    public float N;
    public final int O;
    public final int P;
    public final int Q;
    public final int R;
    public String w;
    public final ArrayList x;
    public final RectF y;
    public float z;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public final int a;
        public float b;
        public boolean c = false;
        public float d = 0.0f;
        public float e = 1.0f;
        public float f = 0.0f;

        public a(int i, float f) {
            this.a = i;
            this.b = f;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.a == aVar.a && Float.compare(this.b, aVar.b) == 0 && this.c == aVar.c && Float.compare(this.d, aVar.d) == 0 && Float.compare(this.e, aVar.e) == 0 && Float.compare(this.f, aVar.f) == 0;
        }

        public final int hashCode() {
            return Float.hashCode(this.f) + ed.a(this.e, ed.a(this.d, (Boolean.hashCode(this.c) + ed.a(this.b, Integer.hashCode(this.a) * 31, 31)) * 31, 31), 31);
        }

        public final String toString() {
            return "Tile(column=" + this.a + ", posY=" + this.b + ", isPressed=" + this.c + ", flash=" + this.d + ", scale=" + this.e + ", deadFlash=" + this.f + ")";
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PianoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        context.getClass();
        this.w = tf.k;
        this.x = new ArrayList();
        this.y = new RectF();
        this.F = -1;
        this.O = context.getColor(R.color.colorPianoBg);
        this.P = context.getColor(R.color.colorGridLine);
        this.Q = context.getColor(R.color.colorStar);
        this.R = context.getColor(R.color.colorRed);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final int e() {
        return this.G;
    }

    public final String getMode() {
        return this.w;
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void h(Canvas canvas) {
        Canvas canvas2 = canvas;
        canvas2.drawColor(this.O);
        float f = 1.0f;
        this.z = getWidth() > 0 ? getWidth() / 4.0f : 1.0f;
        getStrokePaint().setColor(this.P);
        Paint strokePaint = getStrokePaint();
        Resources resources = getResources();
        resources.getClass();
        strokePaint.setStrokeWidth(resources.getDisplayMetrics().density * 1.0f);
        int i = 1;
        while (i < 4) {
            float f2 = this.z * i;
            canvas2.drawLine(f2, 0.0f, f2, getHeight(), getStrokePaint());
            i++;
            canvas2 = canvas;
        }
        int i2 = 40;
        getFillPaint().setColor(Color.argb(40, 255, 255, 255));
        canvas.drawRect(0.0f, getHeight() - this.B, getWidth(), getHeight(), getFillPaint());
        getStrokePaint().setColor(Color.argb(90, 255, 255, 255));
        canvas.drawLine(0.0f, getHeight() - this.B, getWidth(), getHeight() - this.B, getStrokePaint());
        List<y> list = v6.a;
        fs fsVarD = v6.d(getPrefs().b(tf.a));
        ArrayList arrayList = this.x;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            a aVar = (a) obj;
            float f3 = aVar.a;
            float f4 = this.z;
            float f5 = (f4 / 2.0f) + (f3 * f4);
            float f6 = f4 * 0.48f * aVar.e;
            float f7 = f5 - f6;
            float f8 = f6 + f5;
            float f9 = aVar.b;
            float f10 = this.A + f9;
            RectF rectF = this.y;
            rectF.set(f7, f9, f8, f10);
            Resources resources2 = getResources();
            resources2.getClass();
            float f11 = resources2.getDisplayMetrics().density * 6.0f;
            float f12 = aVar.f;
            int iRgb = f12 > 0.0f ? Color.rgb(255, (int) (((f - f12) * 40.0f) + 40.0f), i2) : fsVarD.e;
            int iRed = Color.red(iRgb) + 28;
            if (iRed > 255) {
                iRed = 255;
            }
            int iGreen = Color.green(iRgb) + 28;
            if (iGreen > 255) {
                iGreen = 255;
            }
            float f13 = f;
            int iBlue = Color.blue(iRgb) + 36;
            if (iBlue > 255) {
                iBlue = 255;
            }
            getFillPaint().setShader(new LinearGradient(f7, f9, f7, f10, Color.rgb(iRed, iGreen, iBlue), iRgb, Shader.TileMode.CLAMP));
            canvas.drawRoundRect(rectF, f11, f11, getFillPaint());
            getFillPaint().setShader(null);
            if (aVar.d > 0.0f) {
                getFillPaint().setColor(fsVarD.f);
                getFillPaint().setAlpha(dp.p((int) (aVar.d * 180.0f), 255));
                canvas.drawRoundRect(rectF, f11, f11, getFillPaint());
                getFillPaint().setAlpha(255);
            }
            f = f13;
            i2 = 40;
        }
        float f14 = f;
        float f15 = this.K;
        if (f15 <= 0.0f || this.L < 5) {
            return;
        }
        float f16 = f15 > 0.5f ? (f14 - f15) * 2.0f : f15 * 2.0f;
        getTextPaint().setColor(this.Q);
        getTextPaint().setAlpha((int) (dp.o(f16, 0.0f, f14) * 255.0f));
        Paint textPaint = getTextPaint();
        Resources resources3 = getResources();
        resources3.getClass();
        textPaint.setTextSize(28.0f * resources3.getDisplayMetrics().density);
        canvas.drawText(ed.h("COMBO ×", this.L, "!"), getWidth() / 2.0f, getHeight() / 2.0f, getTextPaint());
        getTextPaint().setAlpha(255);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void i() {
        k();
        this.x.clear();
        getParticles().a.clear();
        setScore(0);
        setSessionCoins(0);
        this.G = 0;
        this.H = 0;
        this.I = 0;
        this.J = false;
        this.K = 0.0f;
        this.M = false;
        this.N = 0.0f;
        setGameOver(false);
        setPaused(false);
        setFlashAlpha(0.0f);
        Resources resources = getResources();
        resources.getClass();
        this.D = 300.0f * resources.getDisplayMetrics().density;
        this.E = 0.0f;
        this.F = -1;
        if (getWidth() > 0) {
            m(-this.A);
            m((-this.A) * 2.0f);
            m((-this.A) * 3.0f);
        }
        g();
        j();
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a
    public final void l(float f) {
        if (getWidth() <= 0 || getHeight() <= 0) {
            return;
        }
        this.z = getWidth() / 4.0f;
        Resources resources = getResources();
        resources.getClass();
        this.A = 120.0f * resources.getDisplayMetrics().density;
        Resources resources2 = getResources();
        resources2.getClass();
        this.B = 80.0f * resources2.getDisplayMetrics().density;
        Resources resources3 = getResources();
        resources3.getClass();
        this.C = 36.0f * resources3.getDisplayMetrics().density;
        boolean z = this.M;
        int i = 0;
        ArrayList arrayList = this.x;
        if (z) {
            this.N += f;
            int size = arrayList.size();
            while (i < size) {
                Object obj = arrayList.get(i);
                i++;
                a aVar = (a) obj;
                float f2 = aVar.f;
                if (f2 > 0.0f) {
                    float f3 = f2 - (f / 0.4f);
                    if (f3 < 0.0f) {
                        f3 = 0.0f;
                    }
                    aVar.f = f3;
                }
            }
            if (this.N >= 0.45f) {
                f(new sf(this.H, this.I, this.J, 0, false, false, 0, 0, 0, 0, false, 0, 0, 0, 0, this.w, 32760));
                return;
            }
            return;
        }
        float fMax = this.A / Math.max(this.D, 1.0f);
        float f4 = this.E + f;
        this.E = f4;
        if (f4 >= fMax) {
            this.E = f4 - fMax;
            m(-this.A);
        }
        int size2 = arrayList.size();
        int i2 = 0;
        while (i2 < size2) {
            Object obj2 = arrayList.get(i2);
            i2++;
            a aVar2 = (a) obj2;
            aVar2.b = (this.D * f) + aVar2.b;
            float f5 = aVar2.d;
            if (f5 > 0.0f) {
                float f6 = f5 - (f / 0.15f);
                if (f6 < 0.0f) {
                    f6 = 0.0f;
                }
                aVar2.d = f6;
            }
            float f7 = aVar2.e;
            if (f7 < 1.0f) {
                float f8 = (f / 0.12f) + f7;
                if (f8 > 1.0f) {
                    f8 = 1.0f;
                }
                aVar2.e = f8;
            }
        }
        u7.U(arrayList, new g(1, this));
        int size3 = arrayList.size();
        while (i < size3) {
            Object obj3 = arrayList.get(i);
            i++;
            a aVar3 = (a) obj3;
            if (!aVar3.c && aVar3.b + this.A >= getHeight()) {
                aVar3.f = 1.0f;
                this.M = true;
                this.N = 0.0f;
                this.l = this.R;
                this.k = 0.55f;
                post(new tn(this, 3));
                post(new tn(this, 4));
            }
        }
        float f9 = this.K;
        if (f9 > 0.0f) {
            float f10 = f9 - (f / 0.6f);
            this.K = f10 >= 0.0f ? f10 : 0.0f;
        }
        g();
        a();
    }

    public final void m(float f) {
        int i = (!ai.a(this.w, tf.l) || cp.a.d() >= 0.25f) ? 1 : 2;
        ArrayList arrayList = new ArrayList(new b4(new Integer[]{0, 1, 2, 3}, true));
        int i2 = this.F;
        if (i2 >= 0 && i == 1) {
            arrayList.remove(Integer.valueOf(i2));
        }
        Collections.shuffle(arrayList);
        List listA0 = w7.a0(i, arrayList);
        this.F = ((Number) w7.V(listA0)).intValue();
        Iterator it = listA0.iterator();
        while (it.hasNext()) {
            this.x.add(new a(((Number) it.next()).intValue(), f));
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        Object obj;
        motionEvent.getClass();
        if (motionEvent.getAction() == 0 && !this.g && !this.h && !this.M && this.z > 0.0f) {
            int i = 3;
            int iP = dp.p((int) (motionEvent.getX() / this.z), 3);
            ArrayList arrayList = this.x;
            ArrayList arrayList2 = new ArrayList();
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj2 = arrayList.get(i2);
                i2++;
                a aVar = (a) obj2;
                if (aVar.a == iP && !aVar.c) {
                    arrayList2.add(obj2);
                }
            }
            Iterator it = arrayList2.iterator();
            if (it.hasNext()) {
                Object next = it.next();
                if (it.hasNext()) {
                    float f = ((a) next).b;
                    do {
                        Object next2 = it.next();
                        float f2 = ((a) next2).b;
                        if (Float.compare(f, f2) < 0) {
                            next = next2;
                            f = f2;
                        }
                    } while (it.hasNext());
                }
                obj = next;
            } else {
                obj = null;
            }
            a aVar2 = (a) obj;
            float height = (getHeight() - this.B) - this.C;
            if (aVar2 != null && aVar2.b + this.A > height) {
                aVar2.c = true;
                aVar2.d = 1.0f;
                aVar2.e = 0.95f;
                int i3 = this.G + 1;
                this.G = i3;
                this.I = Math.max(this.I, i3);
                this.H++;
                int i4 = this.G;
                if (i4 >= 50) {
                    i = 5;
                } else if (i4 < 20) {
                    i = i4 >= 10 ? 2 : 1;
                }
                setScore(getScore() + i);
                if (this.H % 10 == 0) {
                    float f3 = this.D;
                    Resources resources = getResources();
                    resources.getClass();
                    float f4 = (15.0f * resources.getDisplayMetrics().density) + f3;
                    Resources resources2 = getResources();
                    resources2.getClass();
                    float f5 = resources2.getDisplayMetrics().density * 800.0f;
                    if (f4 > f5) {
                        f4 = f5;
                    }
                    this.D = f4;
                    setSessionCoins(getSessionCoins() + 1);
                    float f6 = this.D;
                    Resources resources3 = getResources();
                    resources3.getClass();
                    if (f6 >= (800.0f * resources3.getDisplayMetrics().density) - 0.5f) {
                        this.J = true;
                    }
                }
                this.K = 1.0f;
                this.L = this.G;
                post(new p2(this, aVar2, 5));
                post(new tn(this, 1));
                if (this.G >= 5) {
                    post(new tn(this, 2));
                }
                List<y> list = v6.a;
                fs fsVarD = v6.d(getPrefs().b(tf.a));
                float f7 = aVar2.a;
                float f8 = this.z;
                d((f8 / 2.0f) + (f7 * f8), (this.A / 2.0f) + aVar2.b, 6, fsVarD.f, 180.0f, c.a.a);
                g();
                a();
                return true;
            }
            this.G = 0;
            this.l = this.R;
            this.k = 0.18f;
            post(new tn(this, 0));
            g();
        }
        return true;
    }

    public final void setMode(String str) {
        str.getClass();
        this.w = str;
    }
}
