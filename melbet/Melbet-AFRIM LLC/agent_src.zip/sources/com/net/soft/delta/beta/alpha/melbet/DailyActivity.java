package com.net.soft.delta.beta.alpha.melbet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import com.net.soft.delta.beta.alpha.melbet.BubbleActivity;
import com.net.soft.delta.beta.alpha.melbet.ColorActivity;
import com.net.soft.delta.beta.alpha.melbet.DailyActivity;
import com.net.soft.delta.beta.alpha.melbet.KnifeActivity;
import com.net.soft.delta.beta.alpha.melbet.PianoActivity;
import defpackage.ai;
import defpackage.d2;
import defpackage.d6;
import defpackage.i0;
import defpackage.ko;
import defpackage.qm;
import defpackage.u0;
import defpackage.u9;
import defpackage.uf;
import defpackage.v6;
import defpackage.w9;
import defpackage.x0;
import defpackage.y0;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class DailyActivity extends d2 {
    public static final /* synthetic */ int H = 0;
    public i0 C;
    public uf D;
    public final Handler E = new Handler(Looper.getMainLooper());
    public final a F = new a();
    public final y0 G;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            int i = DailyActivity.H;
            DailyActivity dailyActivity = DailyActivity.this;
            dailyActivity.y();
            dailyActivity.E.postDelayed(this, 1000L);
        }
    }

    public DailyActivity() {
        final u0 u0Var = new u0();
        final u9 u9Var = new u9(this);
        final ComponentActivity.c cVar = this.i;
        cVar.getClass();
        final String str = "activity_rq#" + this.h.getAndIncrement();
        LinkedHashMap linkedHashMap = cVar.c;
        h hVar = this.a;
        if (hVar.c.compareTo(e.b.d) >= 0) {
            StringBuilder sb = new StringBuilder("LifecycleOwner ");
            sb.append(this);
            e.b bVar = hVar.c;
            sb.append(" is attempting to register while current state is ");
            sb.append(bVar);
            sb.append(". LifecycleOwners must call register before they are STARTED.");
            throw new IllegalStateException(sb.toString().toString());
        }
        cVar.d(str);
        x0.b bVar2 = (x0.b) linkedHashMap.get(str);
        bVar2 = bVar2 == null ? new x0.b(hVar) : bVar2;
        g gVar = new g() { // from class: v0
            @Override // androidx.lifecycle.g
            public final void a(xi xiVar, e.a aVar) {
                e.a aVar2 = e.a.ON_START;
                x0 x0Var = cVar;
                String str2 = str;
                if (aVar2 != aVar) {
                    if (e.a.ON_STOP == aVar) {
                        x0Var.e.remove(str2);
                        return;
                    } else {
                        if (e.a.ON_DESTROY == aVar) {
                            x0Var.e(str2);
                            return;
                        }
                        return;
                    }
                }
                LinkedHashMap linkedHashMap2 = x0Var.e;
                Bundle bundle = x0Var.g;
                LinkedHashMap linkedHashMap3 = x0Var.f;
                u9 u9Var2 = u9Var;
                linkedHashMap2.put(str2, new x0.a(u9Var2, u0Var));
                if (linkedHashMap3.containsKey(str2)) {
                    Object obj = linkedHashMap3.get(str2);
                    linkedHashMap3.remove(str2);
                    u9Var2.a(obj);
                }
                if (((q0) b6.a(bundle, str2)) != null) {
                    bundle.remove(str2);
                    DailyActivity dailyActivity = (DailyActivity) u9Var2.a;
                    int i = DailyActivity.H;
                    dailyActivity.x();
                }
            }
        };
        bVar2.a.a(gVar);
        bVar2.b.add(gVar);
        linkedHashMap.put(str, bVar2);
        this.G = new y0(cVar, str, u0Var);
        Math.max(29, 15);
        Math.abs(7);
        String.valueOf(18);
        System.currentTimeMillis();
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final int i = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_daily, (ViewGroup) null, false);
        int i2 = R.id.btnStartDaily;
        Button button = (Button) ko.i(viewInflate, R.id.btnStartDaily);
        if (button != null) {
            i2 = R.id.layoutActive;
            LinearLayout linearLayout = (LinearLayout) ko.i(viewInflate, R.id.layoutActive);
            if (linearLayout != null) {
                i2 = R.id.layoutCalendar;
                LinearLayout linearLayout2 = (LinearLayout) ko.i(viewInflate, R.id.layoutCalendar);
                if (linearLayout2 != null) {
                    i2 = R.id.layoutDone;
                    LinearLayout linearLayout3 = (LinearLayout) ko.i(viewInflate, R.id.layoutDone);
                    if (linearLayout3 != null) {
                        i2 = R.id.progressStreak;
                        ProgressBar progressBar = (ProgressBar) ko.i(viewInflate, R.id.progressStreak);
                        if (progressBar != null) {
                            i2 = R.id.toolbarDaily;
                            View viewI = ko.i(viewInflate, R.id.toolbarDaily);
                            if (viewI != null) {
                                d6 d6VarA = d6.a(viewI);
                                i2 = R.id.tvCountdown;
                                TextView textView = (TextView) ko.i(viewInflate, R.id.tvCountdown);
                                if (textView != null) {
                                    i2 = R.id.tvDailyEmoji;
                                    TextView textView2 = (TextView) ko.i(viewInflate, R.id.tvDailyEmoji);
                                    if (textView2 != null) {
                                        i2 = R.id.tvDailyGame;
                                        TextView textView3 = (TextView) ko.i(viewInflate, R.id.tvDailyGame);
                                        if (textView3 != null) {
                                            i2 = R.id.tvDailyGoal;
                                            TextView textView4 = (TextView) ko.i(viewInflate, R.id.tvDailyGoal);
                                            if (textView4 != null) {
                                                i2 = R.id.tvDailyReward;
                                                TextView textView5 = (TextView) ko.i(viewInflate, R.id.tvDailyReward);
                                                if (textView5 != null) {
                                                    i2 = R.id.tvDailyStreak;
                                                    TextView textView6 = (TextView) ko.i(viewInflate, R.id.tvDailyStreak);
                                                    if (textView6 != null) {
                                                        i2 = R.id.tvDoneResult;
                                                        TextView textView7 = (TextView) ko.i(viewInflate, R.id.tvDoneResult);
                                                        if (textView7 != null) {
                                                            i2 = R.id.tvDoneReward;
                                                            TextView textView8 = (TextView) ko.i(viewInflate, R.id.tvDoneReward);
                                                            if (textView8 != null) {
                                                                ScrollView scrollView = (ScrollView) viewInflate;
                                                                this.C = new i0(scrollView, button, linearLayout, linearLayout2, linearLayout3, progressBar, d6VarA, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8);
                                                                setContentView(scrollView);
                                                                this.D = new uf(this);
                                                                i0 i0Var = this.C;
                                                                if (i0Var == null) {
                                                                    ai.d("binding");
                                                                    throw null;
                                                                }
                                                                ((TextView) i0Var.f.c).setText(R.string.title_daily);
                                                                i0 i0Var2 = this.C;
                                                                if (i0Var2 == null) {
                                                                    ai.d("binding");
                                                                    throw null;
                                                                }
                                                                ((ImageButton) i0Var2.f.a).setOnClickListener(new View.OnClickListener(this) { // from class: v9
                                                                    public final /* synthetic */ DailyActivity b;

                                                                    {
                                                                        this.b = this;
                                                                    }

                                                                    @Override // android.view.View.OnClickListener
                                                                    public final void onClick(View view) throws Exception {
                                                                        int i3 = i;
                                                                        DailyActivity dailyActivity = this.b;
                                                                        switch (i3) {
                                                                            case 0:
                                                                                int i4 = DailyActivity.H;
                                                                                dailyActivity.finish();
                                                                                return;
                                                                            default:
                                                                                uf ufVar = dailyActivity.D;
                                                                                if (ufVar == null) {
                                                                                    ai.d("prefs");
                                                                                    throw null;
                                                                                }
                                                                                w9 w9VarC = ufVar.c();
                                                                                String str = w9VarC.a;
                                                                                String str2 = tf.a;
                                                                                Intent intent = new Intent(dailyActivity, (Class<?>) (ai.a(str, str2) ? PianoActivity.class : ai.a(str, tf.d) ? BubbleActivity.class : ai.a(str, tf.e) ? KnifeActivity.class : ColorActivity.class));
                                                                                intent.putExtra(tf.g, true);
                                                                                intent.putExtra(tf.h, w9VarC.b);
                                                                                intent.putExtra(tf.i, w9VarC.c);
                                                                                if (ai.a(str, str2)) {
                                                                                    intent.putExtra(tf.j, tf.k);
                                                                                }
                                                                                y0 y0Var = dailyActivity.G;
                                                                                x0 x0Var = y0Var.a;
                                                                                LinkedHashMap linkedHashMap = x0Var.b;
                                                                                ArrayList arrayList = x0Var.d;
                                                                                String str3 = y0Var.b;
                                                                                Object obj = linkedHashMap.get(str3);
                                                                                u0 u0Var = y0Var.c;
                                                                                if (obj == null) {
                                                                                    throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + u0Var + " and input " + intent + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
                                                                                }
                                                                                int iIntValue = ((Number) obj).intValue();
                                                                                arrayList.add(str3);
                                                                                try {
                                                                                    x0Var.b(iIntValue, u0Var, intent);
                                                                                    return;
                                                                                } catch (Exception e) {
                                                                                    arrayList.remove(str3);
                                                                                    throw e;
                                                                                }
                                                                        }
                                                                    }
                                                                });
                                                                x();
                                                                i0 i0Var3 = this.C;
                                                                if (i0Var3 == null) {
                                                                    ai.d("binding");
                                                                    throw null;
                                                                }
                                                                final int i3 = 1;
                                                                i0Var3.a.setOnClickListener(new View.OnClickListener(this) { // from class: v9
                                                                    public final /* synthetic */ DailyActivity b;

                                                                    {
                                                                        this.b = this;
                                                                    }

                                                                    @Override // android.view.View.OnClickListener
                                                                    public final void onClick(View view) throws Exception {
                                                                        int i32 = i3;
                                                                        DailyActivity dailyActivity = this.b;
                                                                        switch (i32) {
                                                                            case 0:
                                                                                int i4 = DailyActivity.H;
                                                                                dailyActivity.finish();
                                                                                return;
                                                                            default:
                                                                                uf ufVar = dailyActivity.D;
                                                                                if (ufVar == null) {
                                                                                    ai.d("prefs");
                                                                                    throw null;
                                                                                }
                                                                                w9 w9VarC = ufVar.c();
                                                                                String str = w9VarC.a;
                                                                                String str2 = tf.a;
                                                                                Intent intent = new Intent(dailyActivity, (Class<?>) (ai.a(str, str2) ? PianoActivity.class : ai.a(str, tf.d) ? BubbleActivity.class : ai.a(str, tf.e) ? KnifeActivity.class : ColorActivity.class));
                                                                                intent.putExtra(tf.g, true);
                                                                                intent.putExtra(tf.h, w9VarC.b);
                                                                                intent.putExtra(tf.i, w9VarC.c);
                                                                                if (ai.a(str, str2)) {
                                                                                    intent.putExtra(tf.j, tf.k);
                                                                                }
                                                                                y0 y0Var = dailyActivity.G;
                                                                                x0 x0Var = y0Var.a;
                                                                                LinkedHashMap linkedHashMap = x0Var.b;
                                                                                ArrayList arrayList = x0Var.d;
                                                                                String str3 = y0Var.b;
                                                                                Object obj = linkedHashMap.get(str3);
                                                                                u0 u0Var = y0Var.c;
                                                                                if (obj == null) {
                                                                                    throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + u0Var + " and input " + intent + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
                                                                                }
                                                                                int iIntValue = ((Number) obj).intValue();
                                                                                arrayList.add(str3);
                                                                                try {
                                                                                    x0Var.b(iIntValue, u0Var, intent);
                                                                                    return;
                                                                                } catch (Exception e) {
                                                                                    arrayList.remove(str3);
                                                                                    throw e;
                                                                                }
                                                                        }
                                                                    }
                                                                });
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onPause() {
        super.onPause();
        this.E.removeCallbacks(this.F);
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        this.E.post(this.F);
        x();
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x01d0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void x() {
        uf ufVar = this.D;
        if (ufVar == null) {
            ai.d("prefs");
            throw null;
        }
        w9 w9VarC = ufVar.c();
        int i = w9VarC.c;
        String str = w9VarC.a;
        uf ufVar2 = this.D;
        if (ufVar2 == null) {
            ai.d("prefs");
            throw null;
        }
        SharedPreferences sharedPreferences = ufVar2.a;
        Locale locale = Locale.US;
        String str2 = new SimpleDateFormat("yyyy-MM-dd", locale).format(new Date());
        str2.getClass();
        boolean z = sharedPreferences.getBoolean("daily_".concat(str2), false);
        i0 i0Var = this.C;
        if (i0Var == null) {
            ai.d("binding");
            throw null;
        }
        i0Var.d.setVisibility(z ? 0 : 8);
        i0 i0Var2 = this.C;
        if (i0Var2 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var2.b.setVisibility(z ? 8 : 0);
        i0 i0Var3 = this.C;
        if (i0Var3 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var3.h.setText(v6.a(str));
        i0 i0Var4 = this.C;
        if (i0Var4 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var4.i.setText(v6.c(str));
        i0 i0Var5 = this.C;
        if (i0Var5 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var5.j.setText(getString(R.string.daily_goal, Integer.valueOf(w9VarC.b)));
        i0 i0Var6 = this.C;
        if (i0Var6 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var6.k.setText(getString(R.string.daily_reward, Integer.valueOf(i)));
        i0 i0Var7 = this.C;
        if (i0Var7 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView = i0Var7.m;
        uf ufVar3 = this.D;
        if (ufVar3 == null) {
            ai.d("prefs");
            throw null;
        }
        SharedPreferences sharedPreferences2 = ufVar3.a;
        String str3 = new SimpleDateFormat("yyyy-MM-dd", locale).format(new Date());
        str3.getClass();
        textView.setText(getString(R.string.daily_result, Integer.valueOf(sharedPreferences2.getInt("daily_score_".concat(str3), 0))));
        i0 i0Var8 = this.C;
        if (i0Var8 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var8.n.setText(getString(R.string.daily_reward_got, Integer.valueOf(i)));
        i0 i0Var9 = this.C;
        if (i0Var9 == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView2 = i0Var9.l;
        uf ufVar4 = this.D;
        if (ufVar4 == null) {
            ai.d("prefs");
            throw null;
        }
        textView2.setText(getString(R.string.daily_streak, Integer.valueOf(ufVar4.a.getInt("streak_days", 0))));
        i0 i0Var10 = this.C;
        if (i0Var10 == null) {
            ai.d("binding");
            throw null;
        }
        ProgressBar progressBar = i0Var10.e;
        uf ufVar5 = this.D;
        if (ufVar5 == null) {
            ai.d("prefs");
            throw null;
        }
        int i2 = ufVar5.a.getInt("streak_days", 0);
        if (i2 > 7) {
            i2 = 7;
        }
        progressBar.setProgress(i2);
        i0 i0Var11 = this.C;
        if (i0Var11 == null) {
            ai.d("binding");
            throw null;
        }
        i0Var11.c.removeAllViews();
        for (int i3 = 6; -1 < i3; i3--) {
            Calendar calendar = Calendar.getInstance();
            calendar.add(6, -i3);
            Locale locale2 = Locale.US;
            String str4 = new SimpleDateFormat("yyyy-MM-dd", locale2).format(calendar.getTime());
            str4.getClass();
            TextView textView3 = new TextView(this);
            Resources resources = getResources();
            resources.getClass();
            int i4 = (int) (36.0f * resources.getDisplayMetrics().density);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i4, i4);
            Resources resources2 = getResources();
            resources2.getClass();
            layoutParams.setMarginEnd((int) (8.0f * resources2.getDisplayMetrics().density));
            textView3.setLayoutParams(layoutParams);
            textView3.setGravity(17);
            textView3.setText(String.valueOf(7 - i3));
            textView3.setTextColor(getColor(R.color.white));
            String str5 = new SimpleDateFormat("yyyy-MM-dd", locale2).format(new Date());
            str5.getClass();
            if (str4.equals(str5)) {
                uf ufVar6 = this.D;
                if (ufVar6 == null) {
                    ai.d("prefs");
                    throw null;
                }
                if (!ufVar6.a.getBoolean("daily_".concat(str4), false)) {
                    textView3.setBackgroundResource(R.drawable.daily_pending);
                }
            } else {
                uf ufVar7 = this.D;
                if (ufVar7 == null) {
                    ai.d("prefs");
                    throw null;
                }
                if (ufVar7.a.getBoolean("daily_".concat(str4), false)) {
                    textView3.setBackgroundResource(R.drawable.daily_done);
                } else {
                    textView3.setBackgroundResource(R.drawable.daily_missed);
                }
            }
            i0 i0Var12 = this.C;
            if (i0Var12 == null) {
                ai.d("binding");
                throw null;
            }
            i0Var12.c.addView(textView3);
        }
        y();
    }

    public final void y() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(6, 1);
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
        long timeInMillis = calendar.getTimeInMillis() - System.currentTimeMillis();
        if (timeInMillis < 0) {
            timeInMillis = 0;
        }
        String str = String.format("%02d:%02d:%02d", Arrays.copyOf(new Object[]{Long.valueOf(timeInMillis / 3600000), Long.valueOf((timeInMillis / 60000) % 60), Long.valueOf((timeInMillis / 1000) % 60)}, 3));
        i0 i0Var = this.C;
        if (i0Var != null) {
            i0Var.g.setText(getString(R.string.daily_next, str));
        } else {
            ai.d("binding");
            throw null;
        }
    }
}
