package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.d2;
import defpackage.d6;
import defpackage.di;
import defpackage.ko;
import defpackage.qm;
import defpackage.uf;
import defpackage.v6;
import defpackage.y;
import defpackage.z;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class AchievementsActivity extends d2 {
    public static final /* synthetic */ int C = 0;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public final class a extends RecyclerView.f<C0034a> {
        public final uf d;

        /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
        /* renamed from: com.net.soft.delta.beta.alpha.melbet.AchievementsActivity$a$a, reason: collision with other inner class name */
        public final class C0034a extends RecyclerView.e0 {
            public final di u;

            public C0034a(di diVar) {
                super((CardView) diVar.e);
                this.u = diVar;
            }
        }

        public a(uf ufVar) {
            this.d = ufVar;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.f
        public final int c() {
            List<y> list = v6.a;
            return v6.a.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.f
        public final void f(RecyclerView.e0 e0Var, int i) throws ParseException {
            SimpleDateFormat simpleDateFormat;
            Date date;
            y yVar = v6.a.get(i);
            int i2 = yVar.a;
            uf ufVar = this.d;
            boolean zF = ufVar.f(i2);
            di diVar = ((C0034a) e0Var).u;
            TextView textView = diVar.c;
            TextView textView2 = diVar.b;
            textView.setText(yVar.e);
            ((TextView) diVar.d).setText(yVar.c);
            LinearLayout linearLayout = diVar.a;
            linearLayout.setBackgroundResource(zF ? v6.b(yVar.b) : R.drawable.achievement_card);
            if (!zF) {
                linearLayout.setAlpha(0.4f);
                textView2.setText(AchievementsActivity.this.getString(R.string.locked));
                return;
            }
            linearLayout.setAlpha(1.0f);
            int i3 = yVar.a;
            String str = "";
            String string = ufVar.a.getString("ach_date_" + i3, "");
            if (string == null) {
                string = "";
            }
            if (string.length() != 0) {
                try {
                    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                    simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
                    date = simpleDateFormat2.parse(string);
                } catch (Exception unused) {
                }
                if (date == null) {
                    str = string;
                } else {
                    str = simpleDateFormat.format(date);
                    str.getClass();
                }
            }
            textView2.setText(str);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.f
        public final RecyclerView.e0 g(ViewGroup viewGroup) {
            View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_achievement, viewGroup, false);
            int i = R.id.layoutAchievement;
            LinearLayout linearLayout = (LinearLayout) ko.i(viewInflate, R.id.layoutAchievement);
            if (linearLayout != null) {
                i = R.id.tvAchDate;
                TextView textView = (TextView) ko.i(viewInflate, R.id.tvAchDate);
                if (textView != null) {
                    i = R.id.tvAchEmoji;
                    TextView textView2 = (TextView) ko.i(viewInflate, R.id.tvAchEmoji);
                    if (textView2 != null) {
                        i = R.id.tvAchTitle;
                        TextView textView3 = (TextView) ko.i(viewInflate, R.id.tvAchTitle);
                        if (textView3 != null) {
                            return new C0034a(new di((CardView) viewInflate, linearLayout, textView, textView2, textView3));
                        }
                    }
                }
            }
            qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
            return null;
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("IDLE", 0), new b("LOADING", 1), new b("SUCCESS", 2), new b("ERROR", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_achievements, (ViewGroup) null, false);
        int i = R.id.recyclerAchievements;
        RecyclerView recyclerView = (RecyclerView) ko.i(viewInflate, R.id.recyclerAchievements);
        if (recyclerView != null) {
            i = R.id.toolbarAchievements;
            View viewI = ko.i(viewInflate, R.id.toolbarAchievements);
            if (viewI != null) {
                d6 d6VarA = d6.a(viewI);
                setContentView((LinearLayout) viewInflate);
                ((TextView) d6VarA.c).setText(R.string.title_achievements);
                ((ImageButton) d6VarA.a).setOnClickListener(new z(0, this));
                uf ufVar = new uf(this);
                recyclerView.setLayoutManager(new GridLayoutManager());
                recyclerView.setAdapter(new a(ufVar));
                return;
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
