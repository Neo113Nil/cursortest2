package com.net.soft.delta.beta.alpha.melbet;

import android.animation.ValueAnimator;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.net.soft.delta.beta.alpha.melbet.R;
import com.net.soft.delta.beta.alpha.melbet.StatsActivity;
import com.net.soft.delta.beta.alpha.melbet.WeekBarView;
import defpackage.ai;
import defpackage.b1;
import defpackage.bf;
import defpackage.d2;
import defpackage.d6;
import defpackage.ko;
import defpackage.qm;
import defpackage.tf;
import defpackage.uf;
import defpackage.v6;
import defpackage.y;
import defpackage.z;
import defpackage.z4;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class StatsActivity extends d2 {
    public static final /* synthetic */ int C = 0;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("NONE", 0), new a("DEFAULT", 1), new a("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    public StatsActivity() {
        System.currentTimeMillis();
        Math.abs(-44);
        ((7 & 2) != 0 ? "" : null).getClass();
        ((7 & 2) != 0 ? "" : null).getClass();
        ((3 & 1) == 0 ? null : "").getClass();
    }

    public static void x(int i, bf bfVar) {
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(0, i);
        valueAnimatorOfInt.setDuration(1200L);
        valueAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfInt.addUpdateListener(new z4(3, bfVar));
        valueAnimatorOfInt.start();
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        final int i2 = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_stats, (ViewGroup) null, false);
        int i3 = R.id.layoutGames;
        LinearLayout linearLayout = (LinearLayout) ko.i(viewInflate, R.id.layoutGames);
        if (linearLayout != null) {
            i3 = R.id.toolbarStats;
            View viewI = ko.i(viewInflate, R.id.toolbarStats);
            if (viewI != null) {
                d6 d6VarA = d6.a(viewI);
                i3 = R.id.tvAchCount;
                TextView textView = (TextView) ko.i(viewInflate, R.id.tvAchCount);
                if (textView != null) {
                    i3 = R.id.tvBestCombo;
                    TextView textView2 = (TextView) ko.i(viewInflate, R.id.tvBestCombo);
                    if (textView2 != null) {
                        i3 = R.id.tvBestScore;
                        TextView textView3 = (TextView) ko.i(viewInflate, R.id.tvBestScore);
                        if (textView3 != null) {
                            i3 = R.id.tvBubbleBest;
                            TextView textView4 = (TextView) ko.i(viewInflate, R.id.tvBubbleBest);
                            if (textView4 != null) {
                                i3 = R.id.tvCoinsEarned;
                                TextView textView5 = (TextView) ko.i(viewInflate, R.id.tvCoinsEarned);
                                if (textView5 != null) {
                                    i3 = R.id.tvGamesPlayed;
                                    TextView textView6 = (TextView) ko.i(viewInflate, R.id.tvGamesPlayed);
                                    if (textView6 != null) {
                                        i3 = R.id.tvKnifeLevel;
                                        TextView textView7 = (TextView) ko.i(viewInflate, R.id.tvKnifeLevel);
                                        if (textView7 != null) {
                                            i3 = R.id.tvRecordsBeaten;
                                            TextView textView8 = (TextView) ko.i(viewInflate, R.id.tvRecordsBeaten);
                                            if (textView8 != null) {
                                                i3 = R.id.tvStreak;
                                                TextView textView9 = (TextView) ko.i(viewInflate, R.id.tvStreak);
                                                if (textView9 != null) {
                                                    i3 = R.id.tvTimePlayed;
                                                    TextView textView10 = (TextView) ko.i(viewInflate, R.id.tvTimePlayed);
                                                    if (textView10 != null) {
                                                        i3 = R.id.tvWallet;
                                                        TextView textView11 = (TextView) ko.i(viewInflate, R.id.tvWallet);
                                                        if (textView11 != null) {
                                                            i3 = R.id.weekBars;
                                                            WeekBarView weekBarView = (WeekBarView) ko.i(viewInflate, R.id.weekBars);
                                                            if (weekBarView != null) {
                                                                ScrollView scrollView = (ScrollView) viewInflate;
                                                                final b1 b1Var = new b1(scrollView, linearLayout, d6VarA, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, weekBarView);
                                                                setContentView(scrollView);
                                                                ((TextView) d6VarA.c).setText(R.string.title_stats);
                                                                int i4 = 7;
                                                                ((ImageButton) d6VarA.a).setOnClickListener(new z(7, this));
                                                                uf ufVar = new uf(this);
                                                                SharedPreferences sharedPreferences = ufVar.a;
                                                                x(sharedPreferences.getInt("stat_total_games", 0), new bf() { // from class: ct
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i5 = i2;
                                                                        StatsActivity statsActivity = this;
                                                                        b1 b1Var2 = b1Var;
                                                                        Integer num = (Integer) obj;
                                                                        num.getClass();
                                                                        switch (i5) {
                                                                            case 0:
                                                                                int i6 = StatsActivity.C;
                                                                                b1Var2.f.setText(statsActivity.getString(R.string.games_played, num));
                                                                                break;
                                                                            default:
                                                                                int i7 = StatsActivity.C;
                                                                                ((TextView) b1Var2.e).setText(statsActivity.getString(R.string.total_coins_earned, num));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                final int i5 = 1;
                                                                x(sharedPreferences.getInt("stat_total_coins_earned", 0), new bf() { // from class: ct
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i52 = i5;
                                                                        StatsActivity statsActivity = this;
                                                                        b1 b1Var2 = b1Var;
                                                                        Integer num = (Integer) obj;
                                                                        num.getClass();
                                                                        switch (i52) {
                                                                            case 0:
                                                                                int i6 = StatsActivity.C;
                                                                                b1Var2.f.setText(statsActivity.getString(R.string.games_played, num));
                                                                                break;
                                                                            default:
                                                                                int i7 = StatsActivity.C;
                                                                                ((TextView) b1Var2.e).setText(statsActivity.getString(R.string.total_coins_earned, num));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                Iterator<T> it = tf.m.iterator();
                                                                if (!it.hasNext()) {
                                                                    throw new NoSuchElementException();
                                                                }
                                                                int iD = ufVar.d((String) it.next());
                                                                while (it.hasNext()) {
                                                                    int iD2 = ufVar.d((String) it.next());
                                                                    if (iD < iD2) {
                                                                        iD = iD2;
                                                                    }
                                                                }
                                                                x(iD, new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i6 = i2;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i6) {
                                                                            case 0:
                                                                                int i7 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i8 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i9 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i10 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i11 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                x(sharedPreferences.getInt("total_coins", 0), new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i6 = i5;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i6) {
                                                                            case 0:
                                                                                int i7 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i8 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i9 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i10 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i11 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                int i6 = 0;
                                                                for (int i7 = 1; i7 < 25; i7++) {
                                                                    if (ufVar.f(i7)) {
                                                                        i6++;
                                                                    }
                                                                }
                                                                final int i8 = 2;
                                                                x(i6, new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i62 = i8;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i62) {
                                                                            case 0:
                                                                                int i72 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i82 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i9 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i10 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i11 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                final int i9 = 3;
                                                                x(sharedPreferences.getInt("stat_time_played_min", 0), new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i62 = i9;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i62) {
                                                                            case 0:
                                                                                int i72 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i82 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i92 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i10 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i11 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                final int i10 = 4;
                                                                x(sharedPreferences.getInt("streak_days", 0), new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i62 = i10;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i62) {
                                                                            case 0:
                                                                                int i72 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i82 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i92 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i102 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i11 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                final int i11 = 5;
                                                                x(sharedPreferences.getInt("stat_records_beaten", 0), new bf() { // from class: dt
                                                                    @Override // defpackage.bf
                                                                    public final Object f(Object obj) {
                                                                        int i62 = i11;
                                                                        b1 b1Var2 = b1Var;
                                                                        int iIntValue = ((Integer) obj).intValue();
                                                                        switch (i62) {
                                                                            case 0:
                                                                                int i72 = StatsActivity.C;
                                                                                b1Var2.c.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 1:
                                                                                int i82 = StatsActivity.C;
                                                                                b1Var2.k.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 2:
                                                                                int i92 = StatsActivity.C;
                                                                                b1Var2.a.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 3:
                                                                                int i102 = StatsActivity.C;
                                                                                b1Var2.j.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            case 4:
                                                                                int i112 = StatsActivity.C;
                                                                                b1Var2.i.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                            default:
                                                                                int i12 = StatsActivity.C;
                                                                                b1Var2.h.setText(String.valueOf(iIntValue));
                                                                                break;
                                                                        }
                                                                        return c.m0;
                                                                    }
                                                                });
                                                                for (String str : tf.n) {
                                                                    View viewInflate2 = LayoutInflater.from(this).inflate(R.layout.item_game_stat, (ViewGroup) linearLayout, false);
                                                                    int i12 = R.id.progressRow;
                                                                    ProgressBar progressBar = (ProgressBar) ko.i(viewInflate2, R.id.progressRow);
                                                                    if (progressBar != null) {
                                                                        i12 = R.id.tvRowEmoji;
                                                                        TextView textView12 = (TextView) ko.i(viewInflate2, R.id.tvRowEmoji);
                                                                        if (textView12 != null) {
                                                                            TextView textView13 = (TextView) ko.i(viewInflate2, R.id.tvRowGames);
                                                                            if (textView13 != null) {
                                                                                TextView textView14 = (TextView) ko.i(viewInflate2, R.id.tvRowName);
                                                                                if (textView14 != null) {
                                                                                    TextView textView15 = (TextView) ko.i(viewInflate2, R.id.tvRowRecord);
                                                                                    if (textView15 != null) {
                                                                                        LinearLayout linearLayout2 = (LinearLayout) viewInflate2;
                                                                                        textView12.setText(v6.a(str));
                                                                                        textView14.setText(v6.c(str));
                                                                                        textView15.setText(getString(R.string.game_record, Integer.valueOf(str.equals(tf.a) ? Math.max(ufVar.d(tf.b), ufVar.d(tf.c)) : ufVar.d(str))));
                                                                                        textView13.setText(getString(R.string.stats_games_count, Integer.valueOf(sharedPreferences.getInt("stat_games_".concat(str), 0))));
                                                                                        List<y> list = v6.a;
                                                                                        ArrayList arrayList = new ArrayList();
                                                                                        for (Object obj : list) {
                                                                                            if (ai.a(((y) obj).b, str)) {
                                                                                                arrayList.add(obj);
                                                                                            }
                                                                                        }
                                                                                        if (arrayList.isEmpty()) {
                                                                                            i = 0;
                                                                                        } else {
                                                                                            int size = arrayList.size();
                                                                                            i = 0;
                                                                                            int i13 = 0;
                                                                                            while (i13 < size) {
                                                                                                Object obj2 = arrayList.get(i13);
                                                                                                i13++;
                                                                                                if (ufVar.f(((y) obj2).a) && (i = i + 1) < 0) {
                                                                                                    throw new ArithmeticException("Count overflow has happened.");
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        progressBar.setProgress(i);
                                                                                        linearLayout.addView(linearLayout2);
                                                                                        i4 = 7;
                                                                                    } else {
                                                                                        i12 = R.id.tvRowRecord;
                                                                                    }
                                                                                } else {
                                                                                    i12 = R.id.tvRowName;
                                                                                }
                                                                            } else {
                                                                                i12 = R.id.tvRowGames;
                                                                            }
                                                                        }
                                                                    }
                                                                    qm.f("Missing required view with ID: ".concat(viewInflate2.getResources().getResourceName(i12)));
                                                                    return;
                                                                }
                                                                int i14 = i4;
                                                                int[] iArr = new int[i14];
                                                                int i15 = 0;
                                                                while (i15 < i14) {
                                                                    Calendar calendar = Calendar.getInstance();
                                                                    calendar.add(6, -(6 - i15));
                                                                    String str2 = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.getTime());
                                                                    str2.getClass();
                                                                    iArr[i15] = sharedPreferences.getInt("stat_activity_".concat(str2), 0);
                                                                    i15++;
                                                                    i14 = 7;
                                                                }
                                                                final WeekBarView weekBarView2 = (WeekBarView) b1Var.l;
                                                                float[] fArr = weekBarView2.c;
                                                                int i16 = iArr[0];
                                                                int i17 = 1;
                                                                while (true) {
                                                                    int i18 = iArr[i17];
                                                                    if (i16 < i18) {
                                                                        i16 = i18;
                                                                    }
                                                                    if (i17 == 6) {
                                                                        break;
                                                                    } else {
                                                                        i17++;
                                                                    }
                                                                }
                                                                if (i16 < 1) {
                                                                    i16 = 1;
                                                                }
                                                                int i19 = 0;
                                                                while (i19 < 7) {
                                                                    fArr[i19] = ((i19 < 0 || i19 >= 7) ? 0 : iArr[i19]) / i16;
                                                                    i19++;
                                                                }
                                                                for (final int i20 = 0; i20 < 7; i20++) {
                                                                    ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, fArr[i20]);
                                                                    valueAnimatorOfFloat.setDuration(700L);
                                                                    valueAnimatorOfFloat.setStartDelay(i20 * 80);
                                                                    valueAnimatorOfFloat.setInterpolator(new DecelerateInterpolator());
                                                                    valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: hy
                                                                        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                                                                        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                                                                            int i21 = WeekBarView.e;
                                                                            valueAnimator.getClass();
                                                                            WeekBarView weekBarView3 = weekBarView2;
                                                                            float[] fArr2 = weekBarView3.d;
                                                                            Object animatedValue = valueAnimator.getAnimatedValue();
                                                                            animatedValue.getClass();
                                                                            fArr2[i20] = ((Float) animatedValue).floatValue();
                                                                            weekBarView3.invalidate();
                                                                        }
                                                                    });
                                                                    valueAnimatorOfFloat.start();
                                                                }
                                                                b1Var.b.setText(getString(R.string.stats_best_combo, Integer.valueOf(sharedPreferences.getInt("stat_best_combo", 0))));
                                                                b1Var.g.setText(getString(R.string.stats_knife_level, Integer.valueOf(sharedPreferences.getInt("stat_knife_max_level", 0))));
                                                                b1Var.d.setText(getString(R.string.stats_bubble_record, Integer.valueOf(ufVar.d(tf.d))));
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i3)));
    }
}
