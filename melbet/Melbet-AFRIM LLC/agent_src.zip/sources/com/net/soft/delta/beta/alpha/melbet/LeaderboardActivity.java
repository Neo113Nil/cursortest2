package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import defpackage.ai;
import defpackage.d2;
import defpackage.d6;
import defpackage.j0;
import defpackage.ko;
import defpackage.nt;
import defpackage.oi;
import defpackage.qm;
import defpackage.si;
import defpackage.tf;
import defpackage.z;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class LeaderboardActivity extends d2 {
    public static final /* synthetic */ int D = 0;
    public j0 C;

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a extends FragmentStateAdapter {
        @Override // androidx.recyclerview.widget.RecyclerView.f
        public final int c() {
            return 4;
        }

        @Override // androidx.viewpager2.adapter.FragmentStateAdapter
        public final androidx.fragment.app.d n(int i) {
            String str = si.Y;
            String str2 = tf.a;
            String str3 = tf.n.get(i);
            str3.getClass();
            si siVar = new si();
            Bundle bundle = new Bundle();
            bundle.putString(si.Y, str3);
            siVar.L(bundle);
            return siVar;
        }
    }

    public LeaderboardActivity() {
        System.currentTimeMillis();
        System.currentTimeMillis();
        System.identityHashCode(this);
        Math.max(85, 57);
        System.currentTimeMillis();
        nt.H("value").toString();
        Math.abs(-53);
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_leaderboard, (ViewGroup) null, false);
        int i = R.id.tabLayout;
        TabLayout tabLayout = (TabLayout) ko.i(viewInflate, R.id.tabLayout);
        if (tabLayout != null) {
            i = R.id.toolbarRecords;
            View viewI = ko.i(viewInflate, R.id.toolbarRecords);
            if (viewI != null) {
                d6 d6VarA = d6.a(viewI);
                ViewPager2 viewPager2 = (ViewPager2) ko.i(viewInflate, R.id.viewPager);
                if (viewPager2 != null) {
                    LinearLayout linearLayout = (LinearLayout) viewInflate;
                    this.C = new j0(linearLayout, tabLayout, d6VarA, viewPager2);
                    setContentView(linearLayout);
                    j0 j0Var = this.C;
                    if (j0Var == null) {
                        ai.d("binding");
                        throw null;
                    }
                    ((TextView) j0Var.b.c).setText(R.string.title_records);
                    j0 j0Var2 = this.C;
                    if (j0Var2 == null) {
                        ai.d("binding");
                        throw null;
                    }
                    ((ImageButton) j0Var2.b.a).setOnClickListener(new z(3, this));
                    j0 j0Var3 = this.C;
                    if (j0Var3 == null) {
                        ai.d("binding");
                        throw null;
                    }
                    j0Var3.c.setAdapter(new a(this));
                    int[] iArr = {R.string.tab_piano, R.string.tab_bubble, R.string.tab_knife, R.string.tab_color};
                    j0 j0Var4 = this.C;
                    if (j0Var4 != null) {
                        new com.google.android.material.tabs.c(j0Var4.a, j0Var4.c, new oi(iArr, 0)).a();
                        return;
                    } else {
                        ai.d("binding");
                        throw null;
                    }
                }
                i = R.id.viewPager;
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
