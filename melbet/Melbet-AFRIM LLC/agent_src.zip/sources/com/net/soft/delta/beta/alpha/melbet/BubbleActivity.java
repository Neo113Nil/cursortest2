package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import defpackage.ai;
import defpackage.d2;
import defpackage.f0;
import defpackage.ko;
import defpackage.qm;
import defpackage.tf;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class BubbleActivity extends d2 {
    public f0 C;
    public com.net.soft.delta.beta.alpha.melbet.b D;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("INIT", 0), new a("READY", 1), new a("RUNNING", 2), new a("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("INIT", 0), new b("READY", 1), new b("RUNNING", 2), new b("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c {
        public static final /* synthetic */ c[] a = {new c("AUTO", 0), new c("MANUAL", 1), new c("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        c EF5;

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) a.clone();
        }
    }

    public BubbleActivity() {
        ((3 & 2) != 0 ? "" : null).getClass();
        ((3 & 1) != 0 ? "" : null).getClass();
        ((7 & 2) == 0 ? null : "").getClass();
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_bubble, (ViewGroup) null, false);
        BubbleView bubbleView = (BubbleView) ko.i(viewInflate, R.id.bubbleView);
        if (bubbleView == null) {
            qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.bubbleView)));
            return;
        }
        FrameLayout frameLayout = (FrameLayout) viewInflate;
        this.C = new f0(frameLayout, bubbleView);
        setContentView(frameLayout);
        f0 f0Var = this.C;
        if (f0Var == null) {
            ai.d("binding");
            throw null;
        }
        BubbleView bubbleView2 = (BubbleView) f0Var.a;
        String str = tf.d;
        com.net.soft.delta.beta.alpha.melbet.b bVar = new com.net.soft.delta.beta.alpha.melbet.b(this, bubbleView2, str, str);
        this.D = bVar;
        bVar.i();
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar == null) {
            ai.d("binder");
            throw null;
        }
        bVar.b.k();
        bVar.f.f();
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onPause() {
        super.onPause();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar != null) {
            bVar.j();
        } else {
            ai.d("binder");
            throw null;
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
        if (bVar != null) {
            bVar.k();
        } else {
            ai.d("binder");
            throw null;
        }
    }
}
