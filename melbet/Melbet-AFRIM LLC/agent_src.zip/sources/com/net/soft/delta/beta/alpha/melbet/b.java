package com.net.soft.delta.beta.alpha.melbet;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.snackbar.Snackbar;
import com.net.soft.delta.beta.alpha.melbet.ShopActivity;
import com.net.soft.delta.beta.alpha.melbet.a;
import com.net.soft.delta.beta.alpha.melbet.b;
import defpackage.d2;
import defpackage.lt;
import defpackage.nt;
import defpackage.r3;
import defpackage.rf;
import defpackage.sf;
import defpackage.tf;
import defpackage.uf;
import defpackage.w7;
import defpackage.yj;
import defpackage.z2;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class b implements a.InterfaceC0035a {
    public final boolean A;
    public final int B;
    public final int C;
    public boolean D;
    public int E;
    public final d2 a;
    public final a b;
    public final String c;
    public final String d;
    public final uf e;
    public final z2 f;
    public final TextView g;
    public final TextView h;
    public final TextView i;
    public final TextView j;
    public final TextView k;
    public final TextView l;
    public final TextView m;
    public final LinearLayout n;
    public final LinearLayout o;
    public final LinearLayout p;
    public final TextView q;
    public final TextView r;
    public final Button s;
    public final Button t;
    public final Button u;
    public final Button v;
    public final Button w;
    public final Button x;
    public final Button y;
    public final long z;

    public b(d2 d2Var, a aVar, String str, String str2) {
        str.getClass();
        str2.getClass();
        this.a = d2Var;
        this.b = aVar;
        this.c = str;
        this.d = str2;
        uf ufVar = new uf(d2Var);
        this.e = ufVar;
        this.f = new z2(ufVar);
        View viewFindViewById = d2Var.findViewById(R.id.tvScore);
        viewFindViewById.getClass();
        this.g = (TextView) viewFindViewById;
        View viewFindViewById2 = d2Var.findViewById(R.id.tvCenter);
        viewFindViewById2.getClass();
        this.h = (TextView) viewFindViewById2;
        View viewFindViewById3 = d2Var.findViewById(R.id.tvExtra);
        viewFindViewById3.getClass();
        this.i = (TextView) viewFindViewById3;
        View viewFindViewById4 = d2Var.findViewById(R.id.tvGameOverScore);
        viewFindViewById4.getClass();
        this.j = (TextView) viewFindViewById4;
        View viewFindViewById5 = d2Var.findViewById(R.id.tvGameOverRecord);
        viewFindViewById5.getClass();
        this.k = (TextView) viewFindViewById5;
        View viewFindViewById6 = d2Var.findViewById(R.id.tvGameOverCoins);
        viewFindViewById6.getClass();
        this.l = (TextView) viewFindViewById6;
        View viewFindViewById7 = d2Var.findViewById(R.id.tvGameOverTitle);
        viewFindViewById7.getClass();
        this.m = (TextView) viewFindViewById7;
        View viewFindViewById8 = d2Var.findViewById(R.id.layoutGameOver);
        viewFindViewById8.getClass();
        this.n = (LinearLayout) viewFindViewById8;
        View viewFindViewById9 = d2Var.findViewById(R.id.layoutPaused);
        viewFindViewById9.getClass();
        this.o = (LinearLayout) viewFindViewById9;
        this.p = (LinearLayout) d2Var.findViewById(R.id.layoutLevel);
        this.q = (TextView) d2Var.findViewById(R.id.tvLevelTitle);
        this.r = (TextView) d2Var.findViewById(R.id.tvLevelBonus);
        View viewFindViewById10 = d2Var.findViewById(R.id.btnPause);
        viewFindViewById10.getClass();
        this.s = (Button) viewFindViewById10;
        View viewFindViewById11 = d2Var.findViewById(R.id.btnRetry);
        viewFindViewById11.getClass();
        this.t = (Button) viewFindViewById11;
        View viewFindViewById12 = d2Var.findViewById(R.id.btnMenu);
        viewFindViewById12.getClass();
        this.u = (Button) viewFindViewById12;
        this.v = (Button) d2Var.findViewById(R.id.btnResume);
        this.w = (Button) d2Var.findViewById(R.id.btnSkins);
        this.x = (Button) d2Var.findViewById(R.id.btnNewGame);
        this.y = (Button) d2Var.findViewById(R.id.btnNextLevel);
        this.z = System.currentTimeMillis();
        this.A = d2Var.getIntent().getBooleanExtra(tf.g, false);
        this.B = d2Var.getIntent().getIntExtra(tf.h, 0);
        this.C = d2Var.getIntent().getIntExtra(tf.i, 0);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void a(int i) {
        z2 z2Var = this.f;
        if (((uf) z2Var.a).a.getBoolean("sound_enabled", true)) {
            new Thread(new yj(z2Var, i != 0 ? i != 1 ? i != 2 ? 523 : 392 : 329 : 261, 3)).start();
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void b(int i, int i2) {
        ViewPropertyAnimator viewPropertyAnimatorAnimate;
        ViewPropertyAnimator viewPropertyAnimatorScaleX;
        ViewPropertyAnimator viewPropertyAnimatorScaleY;
        ViewPropertyAnimator duration;
        ViewPropertyAnimator viewPropertyAnimatorWithEndAction;
        this.f.d(27, 120);
        d2 d2Var = this.a;
        TextView textView = this.q;
        if (textView != null) {
            textView.setText(d2Var.getString(R.string.level_complete, Integer.valueOf(i)));
        }
        TextView textView2 = this.r;
        if (textView2 != null) {
            textView2.setText(i2 > 0 ? d2Var.getString(R.string.level_bonus, Integer.valueOf(i2)) : "");
        }
        LinearLayout linearLayout = this.p;
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
        }
        if (linearLayout != null) {
            linearLayout.setScaleX(0.0f);
        }
        if (linearLayout != null) {
            linearLayout.setScaleY(0.0f);
        }
        if (linearLayout == null || (viewPropertyAnimatorAnimate = linearLayout.animate()) == null || (viewPropertyAnimatorScaleX = viewPropertyAnimatorAnimate.scaleX(1.1f)) == null || (viewPropertyAnimatorScaleY = viewPropertyAnimatorScaleX.scaleY(1.1f)) == null || (duration = viewPropertyAnimatorScaleY.setDuration(280L)) == null || (viewPropertyAnimatorWithEndAction = duration.withEndAction(new rf(this, 0))) == null) {
            return;
        }
        viewPropertyAnimatorWithEndAction.start();
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void c(int i) {
        if (this.D) {
            return;
        }
        this.D = true;
        int i2 = this.C;
        uf ufVar = this.e;
        ufVar.a(i2);
        SharedPreferences sharedPreferences = ufVar.a;
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        Locale locale = Locale.US;
        String str = new SimpleDateFormat("yyyy-MM-dd", locale).format(new Date());
        str.getClass();
        editorEdit.putInt("daily_score_".concat(str), i).apply();
        String str2 = new SimpleDateFormat("yyyy-MM-dd", locale).format(new Date());
        str2.getClass();
        sharedPreferences.edit().putBoolean("daily_".concat(str2), true).apply();
        ufVar.h();
        this.a.setResult(-1);
        a aVar = this.b;
        Snackbar.g(aVar, R.string.daily_complete).h();
        aVar.postDelayed(new rf(this, 2), 700L);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void d(int i, int i2) {
        this.g.setText(String.valueOf(i));
        a aVar = this.b;
        boolean z = aVar instanceof PianoView;
        d2 d2Var = this.a;
        TextView textView = this.i;
        if (z) {
            textView.setText(i2 > 1 ? d2Var.getString(R.string.combo_label, Integer.valueOf(i2)) : "");
            if (i2 == this.E || i2 < 5) {
                return;
            }
            this.E = i2;
            return;
        }
        if (aVar instanceof BubbleView) {
            textView.setText(d2Var.getString(R.string.shots_left, Integer.valueOf(i2)));
            return;
        }
        boolean z2 = aVar instanceof KnifeView;
        TextView textView2 = this.h;
        if (z2) {
            textView2.setText(d2Var.getString(R.string.level_label, Integer.valueOf(i2)));
        } else if (aVar instanceof ColorView) {
            textView2.setText(String.valueOf(i));
        } else {
            textView.setText("");
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void e(long j) {
        Vibrator defaultVibrator;
        uf ufVar = this.e;
        ufVar.getClass();
        if (ufVar.a.getBoolean("vibrate_enabled", true)) {
            try {
                int i = Build.VERSION.SDK_INT;
                d2 d2Var = this.a;
                if (i >= 31) {
                    Object systemService = d2Var.getSystemService("vibrator_manager");
                    systemService.getClass();
                    defaultVibrator = r3.k(systemService).getDefaultVibrator();
                } else {
                    Object systemService2 = d2Var.getSystemService("vibrator");
                    systemService2.getClass();
                    defaultVibrator = (Vibrator) systemService2;
                }
                defaultVibrator.getClass();
                defaultVibrator.vibrate(VibrationEffect.createOneShot(j, -1));
            } catch (Exception unused) {
            }
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void f(String str) {
        boolean zEquals = str.equals(defpackage.c.d(defpackage.c.z));
        z2 z2Var = this.f;
        if (zEquals) {
            z2Var.d(1, 40);
            return;
        }
        if (str.equals(defpackage.c.d(defpackage.c.A))) {
            z2Var.d(24, 50);
            return;
        }
        if (str.equals(defpackage.c.d(defpackage.c.B))) {
            z2Var.d(25, 70);
            return;
        }
        if (str.equals(defpackage.c.d(defpackage.c.C))) {
            z2Var.d(93, 180);
            return;
        }
        if (str.equals(defpackage.c.d(defpackage.c.D))) {
            z2Var.d(27, 120);
            return;
        }
        if (str.equals(defpackage.c.d(defpackage.c.E))) {
            z2Var.d(7, 40);
        } else if (str.equals(defpackage.c.d(defpackage.c.F))) {
            z2Var.d(28, 40);
        } else if (str.equals(defpackage.c.d(defpackage.c.G))) {
            z2Var.d(24, 50);
        }
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void g(int i, int i2, sf sfVar) {
        int i3;
        boolean z;
        Vibrator defaultVibrator;
        int i4 = sfVar.l;
        int i5 = sfVar.b;
        z2 z2Var = this.f;
        z2Var.d(93, 180);
        int i6 = i / 10;
        if (i2 >= i6) {
            i6 = i2;
        }
        uf ufVar = this.e;
        ufVar.a(i6);
        SharedPreferences sharedPreferences = ufVar.a;
        String str = this.c;
        str.getClass();
        if (i > ufVar.d(str)) {
            SharedPreferences.Editor editorPutInt = sharedPreferences.edit().putInt(lt.t(str, "record_", false) ? str : "record_".concat(str), i);
            String strConcat = "record_date_".concat(str);
            i3 = 1;
            String str2 = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            str2.getClass();
            editorPutInt.putString(strConcat, str2).putInt("stat_records_beaten", sharedPreferences.getInt("stat_records_beaten", 0) + 1).apply();
            z = true;
        } else {
            i3 = 1;
            z = false;
        }
        String str3 = i + ":" + i6 + ":" + System.currentTimeMillis();
        String string = sharedPreferences.getString("history_".concat(str), "");
        String str4 = string != null ? string : "";
        int i7 = i6;
        ArrayList arrayList = str4.length() == 0 ? new ArrayList() : new ArrayList(nt.G(str4, new String[]{"|"}));
        arrayList.add(0, str3);
        while (arrayList.size() > 10) {
            arrayList.remove(arrayList.size() - 1);
        }
        boolean z2 = z;
        sharedPreferences.edit().putString("history_".concat(str), w7.Y(arrayList, "|", null, 62)).apply();
        String str5 = this.d;
        str5.getClass();
        int i8 = i3;
        ufVar.e("stat_total_games", i8);
        ufVar.e("stat_games_".concat(str5), i8);
        String str6 = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        str6.getClass();
        ufVar.e("stat_activity_".concat(str6), i8);
        ufVar.h();
        int iCurrentTimeMillis = (int) ((System.currentTimeMillis() - this.z) / 60000);
        if (iCurrentTimeMillis < i8) {
            iCurrentTimeMillis = 1;
        }
        if (iCurrentTimeMillis > 0) {
            ufVar.e("stat_time_played_min", iCurrentTimeMillis);
        }
        a aVar = this.b;
        if (aVar instanceof PianoView) {
            if (i5 > sharedPreferences.getInt("stat_best_combo", 0)) {
                sharedPreferences.edit().putInt("stat_best_combo", i5).apply();
            }
        } else if ((aVar instanceof KnifeView) && i4 > sharedPreferences.getInt("stat_knife_max_level", 0)) {
            sharedPreferences.edit().putInt("stat_knife_max_level", i4).apply();
        }
        int i9 = sfVar.a;
        int i10 = sfVar.n;
        ArrayList arrayList2 = new ArrayList();
        if (str5.equals(tf.a) || str5.equals(tf.b) || str5.equals(tf.c)) {
            defpackage.c.l(ufVar, arrayList2, 1, i9 >= 1);
            defpackage.c.l(ufVar, arrayList2, 2, i5 >= 5);
            defpackage.c.l(ufVar, arrayList2, 3, i5 >= 20);
            defpackage.c.l(ufVar, arrayList2, 4, i9 >= 100);
            defpackage.c.l(ufVar, arrayList2, 5, sfVar.c);
            defpackage.c.l(ufVar, arrayList2, 6, i >= 200);
        } else if (str5.equals(tf.d)) {
            defpackage.c.l(ufVar, arrayList2, 7, sfVar.d >= 3);
            defpackage.c.l(ufVar, arrayList2, 8, sfVar.e);
            defpackage.c.l(ufVar, arrayList2, 9, sfVar.f);
            defpackage.c.l(ufVar, arrayList2, 10, sfVar.g >= 5);
            defpackage.c.l(ufVar, arrayList2, 11, sfVar.h >= 1);
            defpackage.c.l(ufVar, arrayList2, 12, i >= 2000);
        } else if (str5.equals(tf.e)) {
            defpackage.c.l(ufVar, arrayList2, 13, sfVar.i >= 1);
            defpackage.c.l(ufVar, arrayList2, 14, sfVar.j >= 1);
            defpackage.c.l(ufVar, arrayList2, 15, sfVar.k);
            defpackage.c.l(ufVar, arrayList2, 16, i4 >= 5);
            defpackage.c.l(ufVar, arrayList2, 17, sharedPreferences.getInt("stat_total_knives", 0) >= 50);
            defpackage.c.l(ufVar, arrayList2, 18, i >= 2000);
        } else if (str5.equals(tf.f)) {
            defpackage.c.l(ufVar, arrayList2, 19, i10 >= 1);
            defpackage.c.l(ufVar, arrayList2, 20, i10 >= 10);
            defpackage.c.l(ufVar, arrayList2, 21, sharedPreferences.getInt("stat_stars", 0) >= 20);
            defpackage.c.l(ufVar, arrayList2, 22, i10 >= 25);
            defpackage.c.l(ufVar, arrayList2, 23, i >= 50);
            defpackage.c.l(ufVar, arrayList2, 24, i >= 100);
        }
        if (!arrayList2.isEmpty()) {
            z2Var.d(28, 160);
            if (sharedPreferences.getBoolean("vibrate_enabled", true)) {
                Context context = aVar.getContext();
                context.getClass();
                try {
                    if (Build.VERSION.SDK_INT >= 31) {
                        Object systemService = context.getSystemService("vibrator_manager");
                        systemService.getClass();
                        defaultVibrator = r3.k(systemService).getDefaultVibrator();
                    } else {
                        Object systemService2 = context.getSystemService("vibrator");
                        systemService2.getClass();
                        defaultVibrator = (Vibrator) systemService2;
                    }
                    defaultVibrator.getClass();
                    defaultVibrator.vibrate(VibrationEffect.createOneShot(40L, -1));
                } catch (Exception unused) {
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    aVar.performHapticFeedback(16);
                } else {
                    aVar.performHapticFeedback(3);
                }
            }
            Snackbar.g(aVar, R.string.achievement_unlocked).h();
        }
        this.m.setText(z2 ? R.string.new_record : R.string.game_over);
        Object[] objArr = {Integer.valueOf(i)};
        d2 d2Var = this.a;
        this.j.setText(d2Var.getString(R.string.score_label, objArr));
        this.k.setText(d2Var.getString(R.string.game_record, Integer.valueOf(ufVar.d(str))));
        this.l.setText(d2Var.getString(R.string.coins_earned, Integer.valueOf(i7)));
        LinearLayout linearLayout = this.n;
        linearLayout.setAlpha(0.0f);
        linearLayout.setVisibility(0);
        linearLayout.animate().alpha(1.0f).setDuration(300L).start();
        if (!this.A || i < this.B || this.D) {
            return;
        }
        c(i);
    }

    @Override // com.net.soft.delta.beta.alpha.melbet.a.InterfaceC0035a
    public final void h() {
        TextView textView = this.i;
        textView.animate().cancel();
        textView.setScaleX(1.0f);
        textView.setScaleY(1.0f);
        textView.animate().scaleX(1.3f).scaleY(1.3f).setDuration(90L).withEndAction(new rf(this, 1)).start();
    }

    public final void i() {
        this.f.e();
        a aVar = this.b;
        aVar.setListener(this);
        aVar.setDailyMode(this.A);
        aVar.setDailyTarget(this.B);
        this.n.setVisibility(8);
        LinearLayout linearLayout = this.o;
        linearLayout.setVisibility(8);
        LinearLayout linearLayout2 = this.p;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(8);
        }
        boolean z = aVar instanceof PianoView;
        final int i = 0;
        d2 d2Var = this.a;
        TextView textView = this.g;
        TextView textView2 = this.h;
        TextView textView3 = this.i;
        if (z) {
            textView.setTextSize(32.0f);
            textView2.setVisibility(8);
            textView3.setTextColor(d2Var.getColor(R.color.colorStar));
            textView3.setTextSize(24.0f);
        } else if (aVar instanceof BubbleView) {
            textView.setTextSize(28.0f);
            textView2.setVisibility(8);
            textView3.setTextColor(d2Var.getColor(R.color.white));
            textView3.setTextSize(16.0f);
        } else if (aVar instanceof KnifeView) {
            textView.setTextSize(28.0f);
            textView2.setVisibility(0);
            textView3.setVisibility(8);
        } else if (aVar instanceof ColorView) {
            textView.setVisibility(8);
            textView2.setVisibility(0);
            textView2.setTextSize(36.0f);
            textView3.setVisibility(8);
        }
        this.s.setOnClickListener(new View.OnClickListener(this) { // from class: qf
            public final /* synthetic */ b b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Vibrator defaultVibrator;
                int i2 = i;
                b bVar = this.b;
                switch (i2) {
                    case 0:
                        a aVar2 = bVar.b;
                        if (!aVar2.h) {
                            aVar2.g = !aVar2.g;
                        }
                        bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                        view.getClass();
                        uf ufVar = bVar.e;
                        ufVar.getClass();
                        if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                            Context context = view.getContext();
                            context.getClass();
                            try {
                                if (Build.VERSION.SDK_INT >= 31) {
                                    Object systemService = context.getSystemService("vibrator_manager");
                                    systemService.getClass();
                                    defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                } else {
                                    Object systemService2 = context.getSystemService("vibrator");
                                    systemService2.getClass();
                                    defaultVibrator = (Vibrator) systemService2;
                                }
                                defaultVibrator.getClass();
                                defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                            } catch (Exception unused) {
                            }
                            view.performHapticFeedback(3);
                            break;
                        }
                        break;
                    case 1:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 2:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 3:
                        bVar.n.setVisibility(8);
                        a aVar3 = bVar.b;
                        aVar3.i();
                        if (!aVar3.h) {
                            aVar3.j();
                            break;
                        }
                        break;
                    case 4:
                        bVar.a.finish();
                        break;
                    case 5:
                        d2 d2Var2 = bVar.a;
                        d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                        break;
                    case 6:
                        bVar.o.setVisibility(8);
                        a aVar4 = bVar.b;
                        aVar4.setPaused(false);
                        aVar4.i();
                        break;
                    default:
                        LinearLayout linearLayout3 = bVar.p;
                        if (linearLayout3 != null) {
                            linearLayout3.setVisibility(8);
                        }
                        bVar.b.b();
                        break;
                }
            }
        });
        Button button = this.v;
        if (button != null) {
            final int i2 = 1;
            button.setOnClickListener(new View.OnClickListener(this) { // from class: qf
                public final /* synthetic */ b b;

                {
                    this.b = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    Vibrator defaultVibrator;
                    int i22 = i2;
                    b bVar = this.b;
                    switch (i22) {
                        case 0:
                            a aVar2 = bVar.b;
                            if (!aVar2.h) {
                                aVar2.g = !aVar2.g;
                            }
                            bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                            view.getClass();
                            uf ufVar = bVar.e;
                            ufVar.getClass();
                            if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                                Context context = view.getContext();
                                context.getClass();
                                try {
                                    if (Build.VERSION.SDK_INT >= 31) {
                                        Object systemService = context.getSystemService("vibrator_manager");
                                        systemService.getClass();
                                        defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                    } else {
                                        Object systemService2 = context.getSystemService("vibrator");
                                        systemService2.getClass();
                                        defaultVibrator = (Vibrator) systemService2;
                                    }
                                    defaultVibrator.getClass();
                                    defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                                } catch (Exception unused) {
                                }
                                view.performHapticFeedback(3);
                                break;
                            }
                            break;
                        case 1:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 2:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 3:
                            bVar.n.setVisibility(8);
                            a aVar3 = bVar.b;
                            aVar3.i();
                            if (!aVar3.h) {
                                aVar3.j();
                                break;
                            }
                            break;
                        case 4:
                            bVar.a.finish();
                            break;
                        case 5:
                            d2 d2Var2 = bVar.a;
                            d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                            break;
                        case 6:
                            bVar.o.setVisibility(8);
                            a aVar4 = bVar.b;
                            aVar4.setPaused(false);
                            aVar4.i();
                            break;
                        default:
                            LinearLayout linearLayout3 = bVar.p;
                            if (linearLayout3 != null) {
                                linearLayout3.setVisibility(8);
                            }
                            bVar.b.b();
                            break;
                    }
                }
            });
        }
        final int i3 = 2;
        linearLayout.setOnClickListener(new View.OnClickListener(this) { // from class: qf
            public final /* synthetic */ b b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Vibrator defaultVibrator;
                int i22 = i3;
                b bVar = this.b;
                switch (i22) {
                    case 0:
                        a aVar2 = bVar.b;
                        if (!aVar2.h) {
                            aVar2.g = !aVar2.g;
                        }
                        bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                        view.getClass();
                        uf ufVar = bVar.e;
                        ufVar.getClass();
                        if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                            Context context = view.getContext();
                            context.getClass();
                            try {
                                if (Build.VERSION.SDK_INT >= 31) {
                                    Object systemService = context.getSystemService("vibrator_manager");
                                    systemService.getClass();
                                    defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                } else {
                                    Object systemService2 = context.getSystemService("vibrator");
                                    systemService2.getClass();
                                    defaultVibrator = (Vibrator) systemService2;
                                }
                                defaultVibrator.getClass();
                                defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                            } catch (Exception unused) {
                            }
                            view.performHapticFeedback(3);
                            break;
                        }
                        break;
                    case 1:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 2:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 3:
                        bVar.n.setVisibility(8);
                        a aVar3 = bVar.b;
                        aVar3.i();
                        if (!aVar3.h) {
                            aVar3.j();
                            break;
                        }
                        break;
                    case 4:
                        bVar.a.finish();
                        break;
                    case 5:
                        d2 d2Var2 = bVar.a;
                        d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                        break;
                    case 6:
                        bVar.o.setVisibility(8);
                        a aVar4 = bVar.b;
                        aVar4.setPaused(false);
                        aVar4.i();
                        break;
                    default:
                        LinearLayout linearLayout3 = bVar.p;
                        if (linearLayout3 != null) {
                            linearLayout3.setVisibility(8);
                        }
                        bVar.b.b();
                        break;
                }
            }
        });
        final int i4 = 3;
        this.t.setOnClickListener(new View.OnClickListener(this) { // from class: qf
            public final /* synthetic */ b b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Vibrator defaultVibrator;
                int i22 = i4;
                b bVar = this.b;
                switch (i22) {
                    case 0:
                        a aVar2 = bVar.b;
                        if (!aVar2.h) {
                            aVar2.g = !aVar2.g;
                        }
                        bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                        view.getClass();
                        uf ufVar = bVar.e;
                        ufVar.getClass();
                        if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                            Context context = view.getContext();
                            context.getClass();
                            try {
                                if (Build.VERSION.SDK_INT >= 31) {
                                    Object systemService = context.getSystemService("vibrator_manager");
                                    systemService.getClass();
                                    defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                } else {
                                    Object systemService2 = context.getSystemService("vibrator");
                                    systemService2.getClass();
                                    defaultVibrator = (Vibrator) systemService2;
                                }
                                defaultVibrator.getClass();
                                defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                            } catch (Exception unused) {
                            }
                            view.performHapticFeedback(3);
                            break;
                        }
                        break;
                    case 1:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 2:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 3:
                        bVar.n.setVisibility(8);
                        a aVar3 = bVar.b;
                        aVar3.i();
                        if (!aVar3.h) {
                            aVar3.j();
                            break;
                        }
                        break;
                    case 4:
                        bVar.a.finish();
                        break;
                    case 5:
                        d2 d2Var2 = bVar.a;
                        d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                        break;
                    case 6:
                        bVar.o.setVisibility(8);
                        a aVar4 = bVar.b;
                        aVar4.setPaused(false);
                        aVar4.i();
                        break;
                    default:
                        LinearLayout linearLayout3 = bVar.p;
                        if (linearLayout3 != null) {
                            linearLayout3.setVisibility(8);
                        }
                        bVar.b.b();
                        break;
                }
            }
        });
        final int i5 = 4;
        this.u.setOnClickListener(new View.OnClickListener(this) { // from class: qf
            public final /* synthetic */ b b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Vibrator defaultVibrator;
                int i22 = i5;
                b bVar = this.b;
                switch (i22) {
                    case 0:
                        a aVar2 = bVar.b;
                        if (!aVar2.h) {
                            aVar2.g = !aVar2.g;
                        }
                        bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                        view.getClass();
                        uf ufVar = bVar.e;
                        ufVar.getClass();
                        if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                            Context context = view.getContext();
                            context.getClass();
                            try {
                                if (Build.VERSION.SDK_INT >= 31) {
                                    Object systemService = context.getSystemService("vibrator_manager");
                                    systemService.getClass();
                                    defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                } else {
                                    Object systemService2 = context.getSystemService("vibrator");
                                    systemService2.getClass();
                                    defaultVibrator = (Vibrator) systemService2;
                                }
                                defaultVibrator.getClass();
                                defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                            } catch (Exception unused) {
                            }
                            view.performHapticFeedback(3);
                            break;
                        }
                        break;
                    case 1:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 2:
                        bVar.b.setPaused(false);
                        bVar.o.setVisibility(8);
                        break;
                    case 3:
                        bVar.n.setVisibility(8);
                        a aVar3 = bVar.b;
                        aVar3.i();
                        if (!aVar3.h) {
                            aVar3.j();
                            break;
                        }
                        break;
                    case 4:
                        bVar.a.finish();
                        break;
                    case 5:
                        d2 d2Var2 = bVar.a;
                        d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                        break;
                    case 6:
                        bVar.o.setVisibility(8);
                        a aVar4 = bVar.b;
                        aVar4.setPaused(false);
                        aVar4.i();
                        break;
                    default:
                        LinearLayout linearLayout3 = bVar.p;
                        if (linearLayout3 != null) {
                            linearLayout3.setVisibility(8);
                        }
                        bVar.b.b();
                        break;
                }
            }
        });
        Button button2 = this.w;
        if (button2 != null) {
            final int i6 = 5;
            button2.setOnClickListener(new View.OnClickListener(this) { // from class: qf
                public final /* synthetic */ b b;

                {
                    this.b = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    Vibrator defaultVibrator;
                    int i22 = i6;
                    b bVar = this.b;
                    switch (i22) {
                        case 0:
                            a aVar2 = bVar.b;
                            if (!aVar2.h) {
                                aVar2.g = !aVar2.g;
                            }
                            bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                            view.getClass();
                            uf ufVar = bVar.e;
                            ufVar.getClass();
                            if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                                Context context = view.getContext();
                                context.getClass();
                                try {
                                    if (Build.VERSION.SDK_INT >= 31) {
                                        Object systemService = context.getSystemService("vibrator_manager");
                                        systemService.getClass();
                                        defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                    } else {
                                        Object systemService2 = context.getSystemService("vibrator");
                                        systemService2.getClass();
                                        defaultVibrator = (Vibrator) systemService2;
                                    }
                                    defaultVibrator.getClass();
                                    defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                                } catch (Exception unused) {
                                }
                                view.performHapticFeedback(3);
                                break;
                            }
                            break;
                        case 1:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 2:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 3:
                            bVar.n.setVisibility(8);
                            a aVar3 = bVar.b;
                            aVar3.i();
                            if (!aVar3.h) {
                                aVar3.j();
                                break;
                            }
                            break;
                        case 4:
                            bVar.a.finish();
                            break;
                        case 5:
                            d2 d2Var2 = bVar.a;
                            d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                            break;
                        case 6:
                            bVar.o.setVisibility(8);
                            a aVar4 = bVar.b;
                            aVar4.setPaused(false);
                            aVar4.i();
                            break;
                        default:
                            LinearLayout linearLayout3 = bVar.p;
                            if (linearLayout3 != null) {
                                linearLayout3.setVisibility(8);
                            }
                            bVar.b.b();
                            break;
                    }
                }
            });
        }
        Button button3 = this.x;
        if (button3 != null) {
            final int i7 = 6;
            button3.setOnClickListener(new View.OnClickListener(this) { // from class: qf
                public final /* synthetic */ b b;

                {
                    this.b = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    Vibrator defaultVibrator;
                    int i22 = i7;
                    b bVar = this.b;
                    switch (i22) {
                        case 0:
                            a aVar2 = bVar.b;
                            if (!aVar2.h) {
                                aVar2.g = !aVar2.g;
                            }
                            bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                            view.getClass();
                            uf ufVar = bVar.e;
                            ufVar.getClass();
                            if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                                Context context = view.getContext();
                                context.getClass();
                                try {
                                    if (Build.VERSION.SDK_INT >= 31) {
                                        Object systemService = context.getSystemService("vibrator_manager");
                                        systemService.getClass();
                                        defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                    } else {
                                        Object systemService2 = context.getSystemService("vibrator");
                                        systemService2.getClass();
                                        defaultVibrator = (Vibrator) systemService2;
                                    }
                                    defaultVibrator.getClass();
                                    defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                                } catch (Exception unused) {
                                }
                                view.performHapticFeedback(3);
                                break;
                            }
                            break;
                        case 1:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 2:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 3:
                            bVar.n.setVisibility(8);
                            a aVar3 = bVar.b;
                            aVar3.i();
                            if (!aVar3.h) {
                                aVar3.j();
                                break;
                            }
                            break;
                        case 4:
                            bVar.a.finish();
                            break;
                        case 5:
                            d2 d2Var2 = bVar.a;
                            d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                            break;
                        case 6:
                            bVar.o.setVisibility(8);
                            a aVar4 = bVar.b;
                            aVar4.setPaused(false);
                            aVar4.i();
                            break;
                        default:
                            LinearLayout linearLayout3 = bVar.p;
                            if (linearLayout3 != null) {
                                linearLayout3.setVisibility(8);
                            }
                            bVar.b.b();
                            break;
                    }
                }
            });
        }
        Button button4 = this.y;
        if (button4 != null) {
            final int i8 = 7;
            button4.setOnClickListener(new View.OnClickListener(this) { // from class: qf
                public final /* synthetic */ b b;

                {
                    this.b = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    Vibrator defaultVibrator;
                    int i22 = i8;
                    b bVar = this.b;
                    switch (i22) {
                        case 0:
                            a aVar2 = bVar.b;
                            if (!aVar2.h) {
                                aVar2.g = !aVar2.g;
                            }
                            bVar.o.setVisibility(bVar.b.g ? 0 : 8);
                            view.getClass();
                            uf ufVar = bVar.e;
                            ufVar.getClass();
                            if (ufVar.a.getBoolean("vibrate_enabled", true)) {
                                Context context = view.getContext();
                                context.getClass();
                                try {
                                    if (Build.VERSION.SDK_INT >= 31) {
                                        Object systemService = context.getSystemService("vibrator_manager");
                                        systemService.getClass();
                                        defaultVibrator = r3.k(systemService).getDefaultVibrator();
                                    } else {
                                        Object systemService2 = context.getSystemService("vibrator");
                                        systemService2.getClass();
                                        defaultVibrator = (Vibrator) systemService2;
                                    }
                                    defaultVibrator.getClass();
                                    defaultVibrator.vibrate(VibrationEffect.createOneShot(20L, -1));
                                } catch (Exception unused) {
                                }
                                view.performHapticFeedback(3);
                                break;
                            }
                            break;
                        case 1:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 2:
                            bVar.b.setPaused(false);
                            bVar.o.setVisibility(8);
                            break;
                        case 3:
                            bVar.n.setVisibility(8);
                            a aVar3 = bVar.b;
                            aVar3.i();
                            if (!aVar3.h) {
                                aVar3.j();
                                break;
                            }
                            break;
                        case 4:
                            bVar.a.finish();
                            break;
                        case 5:
                            d2 d2Var2 = bVar.a;
                            d2Var2.startActivity(new Intent(d2Var2, (Class<?>) ShopActivity.class));
                            break;
                        case 6:
                            bVar.o.setVisibility(8);
                            a aVar4 = bVar.b;
                            aVar4.setPaused(false);
                            aVar4.i();
                            break;
                        default:
                            LinearLayout linearLayout3 = bVar.p;
                            if (linearLayout3 != null) {
                                linearLayout3.setVisibility(8);
                            }
                            bVar.b.b();
                            break;
                    }
                }
            });
        }
        aVar.i();
    }

    public final void j() {
        this.b.k();
        if (this.b.h) {
            return;
        }
        this.b.setPaused(true);
        this.o.setVisibility(0);
    }

    public final void k() {
        if (this.b.h) {
            return;
        }
        a aVar = this.b;
        if (aVar.h) {
            return;
        }
        aVar.j();
    }
}
