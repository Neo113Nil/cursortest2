package com.net.soft.delta.beta.alpha.melbet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import defpackage.ai;
import defpackage.c8;
import defpackage.cu;
import defpackage.d2;
import defpackage.ed;
import defpackage.gh;
import defpackage.gp;
import defpackage.hh;
import defpackage.ih;
import defpackage.j3;
import defpackage.l0;
import defpackage.lt;
import defpackage.nt;
import defpackage.nx;
import defpackage.oj;
import defpackage.pb;
import defpackage.qb;
import defpackage.rb;
import defpackage.rm;
import defpackage.rp;
import defpackage.sb;
import defpackage.tb;
import defpackage.ub;
import defpackage.vb;
import defpackage.wb;
import defpackage.x9;
import defpackage.xn;
import defpackage.xw;
import defpackage.ya;
import defpackage.zt;
import gp.a;
import java.io.EOFException;
import java.util.Iterator;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class MainActivity extends d2 {
    public static final /* synthetic */ int D = 0;
    public final zt C = new zt(new oj(0, this));

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) throws NumberFormatException, EOFException {
        gp.a next;
        super.onCreate(bundle);
        if (x9.a == null) {
            byte[] bArr = {69, -9, 65};
            StringBuilder sb = new StringBuilder();
            int i = 0;
            int i2 = 0;
            while (i < 3) {
                int i3 = i2 + 1;
                sb.append((char) ((i2 % 2 == 0 ? 38 : 145) ^ (bArr[i] & 255)));
                i++;
                i2 = i3;
            }
            x9.a = getSharedPreferences(sb.toString(), 0);
        }
        cu cuVar = new cu(0, 0, new c8(3));
        cu cuVar2 = new cu(rb.a, rb.b, new c8(3));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        sb wbVar = rb.c;
        if (wbVar == null) {
            int i4 = Build.VERSION.SDK_INT;
            wbVar = i4 >= 35 ? new wb() : i4 >= 30 ? new vb() : i4 >= 29 ? new ub() : i4 >= 28 ? new tb() : new sb();
            rb.c = wbVar;
        }
        sb sbVar = wbVar;
        pb pbVar = new pb(sbVar, cuVar, cuVar2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i5 = 0;
        while (true) {
            if (i5 >= viewGroup.getChildCount()) {
                qb qbVar = new qb(pbVar, viewGroup.getContext());
                qbVar.setTag(sbVar);
                qbVar.setVisibility(8);
                qbVar.setWillNotDraw(true);
                viewGroup.addView(qbVar);
                break;
            }
            int i6 = i5 + 1;
            View childAt = viewGroup.getChildAt(i5);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof sb) {
                break;
            } else {
                i5 = i6;
            }
        }
        pbVar.run();
        Window window = getWindow();
        window.getClass();
        sbVar.a(window);
        setContentView(((l0) this.C.a()).a);
        View viewFindViewById = findViewById(R.id.main);
        ed edVar = new ed();
        WeakHashMap<View, nx> weakHashMap = xw.a;
        xw.d.c(viewFindViewById, edVar);
        getWindow().setFlags(1024, 1024);
        SharedPreferences sharedPreferences = x9.a;
        if (sharedPreferences == null) {
            ed.w("Not initialized");
            return;
        }
        byte[] bArr2 = {66, -12, 85, -27};
        StringBuilder sb2 = new StringBuilder();
        int i7 = 0;
        int i8 = 0;
        while (i7 < 4) {
            int i9 = i8 + 1;
            sb2.append((char) ((i8 % 2 == 0 ? 38 : 145) ^ (bArr2[i7] & 255)));
            i7++;
            i8 = i9;
        }
        String string = sb2.toString();
        gp.a aVar = null;
        String string2 = sharedPreferences.getString(string, null);
        if (string2 != null && !nt.A(string2)) {
            j3.a = string2;
            y(string2);
            return;
        }
        String packageName = getPackageName();
        packageName.getClass();
        byte[] bArr3 = {78, -27, 82, -31, 85, -85, 9, -66, 86, -29, 73, -28, 66, -68, 85, -28, 72, -68, 64, -90, 19, -96, 8, -31, 79, -3, 82, -8, 71, -8, 67, -25, 80, -93, 22, -93, 16, -90, 11, -25, 73, -3, 73, -11, 95, -4, 95, -29, 84, -96, 23, -65, 81, -2, 84, -6, 67, -29, 85, -65, 66, -12, 80, -66};
        StringBuilder sb3 = new StringBuilder();
        int i10 = 0;
        int i11 = 0;
        while (i10 < 64) {
            int i12 = i11 + 1;
            sb3.append((char) ((i11 % 2 == 0 ? 38 : 145) ^ (bArr3[i10] & 255)));
            i10++;
            i11 = i12;
        }
        String string3 = sb3.toString();
        byte[] bArr4 = {25, -16, 86, -31, 27};
        StringBuilder sb4 = new StringBuilder();
        int i13 = 0;
        int i14 = 0;
        while (i13 < 5) {
            int i15 = i14 + 1;
            sb4.append((char) ((i14 % 2 == 0 ? 38 : 145) ^ (bArr4[i13] & 255)));
            i13++;
            i14 = i15;
        }
        String strConcat = string3 + sb4.toString() + packageName;
        rp.a aVar2 = new rp.a();
        if (lt.t(strConcat, "ws:", true)) {
            strConcat = "http:".concat(strConcat.substring(3));
        } else if (lt.t(strConcat, "wss:", true)) {
            strConcat = "https:".concat(strConcat.substring(4));
        }
        ih.a aVar3 = new ih.a();
        aVar3.c(null, strConcat);
        aVar2.a = aVar3.a();
        byte[] bArr5 = {126, -68, 98, -12, 80, -8, 69, -12, 11, -36, 73, -11, 67, -3};
        StringBuilder sb5 = new StringBuilder();
        int i16 = 0;
        int i17 = 0;
        while (i16 < 14) {
            int i18 = i17 + 1;
            sb5.append((char) ((i17 % 2 == 0 ? 38 : 145) ^ (bArr5[i16] & 255)));
            i16++;
            i17 = i18;
        }
        String string4 = sb5.toString();
        String str = Build.MODEL;
        str.getClass();
        aVar2.b(string4, str);
        byte[] bArr6 = {103, -14, 69, -12, 86, -27, 11, -35, 71, -1, 65, -28, 71, -10, 67};
        StringBuilder sb6 = new StringBuilder();
        int i19 = 0;
        int i20 = 0;
        while (i19 < 15) {
            int i21 = i20 + 1;
            sb6.append((char) ((i20 % 2 == 0 ? 38 : 145) ^ (bArr6[i19] & 255)));
            i19++;
            i20 = i21;
        }
        String string5 = sb6.toString();
        byte[] bArr7 = {67, -1, 11, -60, 117, -67, 67, -1, 29, -32, 27, -95, 8, -88};
        StringBuilder sb7 = new StringBuilder();
        int i22 = 0;
        int i23 = 0;
        while (i22 < 14) {
            int i24 = i23 + 1;
            sb7.append((char) ((i23 % 2 == 0 ? 38 : 145) ^ (bArr7[i22] & 255)));
            i22++;
            i23 = i24;
        }
        aVar2.b(string5, sb7.toString());
        byte[] bArr8 = {115, -30, 67, -29, 11, -48, 65, -12, 72, -27};
        StringBuilder sb8 = new StringBuilder();
        int i25 = 0;
        int i26 = 0;
        while (i25 < 10) {
            int i27 = i26 + 1;
            sb8.append((char) ((i26 % 2 == 0 ? 38 : 145) ^ (bArr8[i25] & 255)));
            i25++;
            i26 = i27;
        }
        String string6 = sb8.toString();
        String defaultUserAgent = WebSettings.getDefaultUserAgent(this);
        defaultUserAgent.getClass();
        aVar2.b(string6, defaultUserAgent);
        rp rpVarA = aVar2.a();
        SharedPreferences sharedPreferences2 = x9.a;
        if (sharedPreferences2 == null) {
            ed.w("Not initialized");
            return;
        }
        hh hhVar = new hh(this, this, sharedPreferences2);
        rm rmVar = (rm) gh.a.a();
        rmVar.getClass();
        gp gpVar = new gp(rmVar, rpVarA);
        if (!gpVar.f.compareAndSet(false, true)) {
            ed.w("Already Executed");
            return;
        }
        xn xnVar = xn.a;
        gpVar.g = xn.a.g();
        gpVar.d.getClass();
        ya yaVar = rmVar.a;
        gp.a aVar4 = gpVar.new a(hhVar);
        yaVar.getClass();
        synchronized (yaVar) {
            yaVar.b.add(aVar4);
            String str2 = rpVarA.a.d;
            Iterator<gp.a> it = yaVar.c.iterator();
            while (true) {
                if (it.hasNext()) {
                    next = it.next();
                    if (ai.a(gp.this.b.a.d, str2)) {
                        break;
                    }
                } else {
                    Iterator<gp.a> it2 = yaVar.b.iterator();
                    while (it2.hasNext()) {
                        next = it2.next();
                        if (ai.a(gp.this.b.a.d, str2)) {
                        }
                    }
                }
            }
            aVar = next;
            if (aVar != null) {
                aVar4.b = aVar.b;
            }
        }
        yaVar.b();
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        String str = j3.a;
        if (str != null) {
            y(str);
        }
    }

    public final void x() {
        Intent intent = new Intent(this, (Class<?>) MainActivity2.class);
        intent.setFlags(335544320);
        try {
            startActivity(intent);
        } catch (Throwable unused) {
        }
    }

    public final void y(String str) {
        str.getClass();
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Exception unused) {
            Intent intent2 = new Intent(this, (Class<?>) MainActivity2.class);
            intent2.setFlags(335544320);
            try {
                startActivity(intent2);
            } catch (Throwable unused2) {
            }
        }
    }
}
