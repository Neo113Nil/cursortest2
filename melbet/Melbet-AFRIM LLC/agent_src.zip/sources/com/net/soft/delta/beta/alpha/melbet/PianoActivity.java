package com.net.soft.delta.beta.alpha.melbet;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import com.net.soft.delta.beta.alpha.melbet.PianoActivity;
import com.net.soft.delta.beta.alpha.melbet.R;
import defpackage.ai;
import defpackage.d2;
import defpackage.f0;
import defpackage.ko;
import defpackage.qm;
import defpackage.tf;
import defpackage.uf;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class PianoActivity extends d2 {
    public static final /* synthetic */ int F = 0;
    public f0 C;
    public com.net.soft.delta.beta.alpha.melbet.b D;
    public boolean E;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("AUTO", 0), new a("MANUAL", 1), new a("DISABLED", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("IDLE", 0), new b("LOADING", 1), new b("SUCCESS", 2), new b("ERROR", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c {
        public static final /* synthetic */ c[] a = {new c("INIT", 0), new c("READY", 1), new c("RUNNING", 2), new c("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        c EF5;

        public c() {
            throw null;
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) a.clone();
        }
    }

    public PianoActivity() {
        System.currentTimeMillis();
        Math.min(87, 29);
        ((7 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) != 0 ? "" : null).getClass();
        ((3 & 2) == 0 ? null : "").getClass();
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_piano, (ViewGroup) null, false);
        PianoView pianoView = (PianoView) ko.i(viewInflate, R.id.pianoView);
        if (pianoView == null) {
            qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.pianoView)));
            return;
        }
        FrameLayout frameLayout = (FrameLayout) viewInflate;
        this.C = new f0(frameLayout, pianoView);
        setContentView(frameLayout);
        boolean booleanExtra = getIntent().getBooleanExtra(tf.g, false);
        String stringExtra = getIntent().getStringExtra(tf.j);
        if (stringExtra == null) {
            stringExtra = "";
        }
        if (booleanExtra || stringExtra.length() > 0) {
            if (stringExtra.length() == 0) {
                stringExtra = tf.k;
            }
            x(stringExtra);
            return;
        }
        final uf ufVar = new uf(this);
        b.a aVar = new b.a(this);
        aVar.c(R.string.piano_mode_title);
        String[] strArr = {getString(R.string.piano_classic), getString(R.string.piano_arcade)};
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() { // from class: rn
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                int i2 = PianoActivity.F;
                PianoActivity pianoActivity = this;
                if (i == 1) {
                    String str = tf.b;
                    uf ufVar2 = ufVar;
                    if (ufVar2.d(str) < 50 && ufVar2.d(tf.c) <= 0) {
                        b.a aVar2 = new b.a(pianoActivity);
                        AlertController.b bVar = aVar2.a;
                        bVar.f = bVar.a.getText(R.string.piano_arcade_locked);
                        aVar2.b(R.string.ok, new sn(0, pianoActivity));
                        bVar.j = false;
                        aVar2.d();
                        return;
                    }
                }
                pianoActivity.x(i == 1 ? tf.l : tf.k);
            }
        };
        AlertController.b bVar = aVar.a;
        bVar.l = strArr;
        bVar.n = onClickListener;
        bVar.j = false;
        aVar.d();
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        if (this.E) {
            com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
            if (bVar == null) {
                ai.d("binder");
                throw null;
            }
            bVar.b.k();
            bVar.f.f();
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onPause() {
        super.onPause();
        if (this.E) {
            com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
            if (bVar != null) {
                bVar.j();
            } else {
                ai.d("binder");
                throw null;
            }
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        if (this.E) {
            com.net.soft.delta.beta.alpha.melbet.b bVar = this.D;
            if (bVar != null) {
                bVar.k();
            } else {
                ai.d("binder");
                throw null;
            }
        }
    }

    public final void x(String str) {
        f0 f0Var = this.C;
        if (f0Var == null) {
            ai.d("binding");
            throw null;
        }
        ((PianoView) f0Var.a).setMode(str);
        String str2 = ai.a(str, tf.l) ? tf.c : tf.b;
        f0 f0Var2 = this.C;
        if (f0Var2 == null) {
            ai.d("binding");
            throw null;
        }
        com.net.soft.delta.beta.alpha.melbet.b bVar = new com.net.soft.delta.beta.alpha.melbet.b(this, (PianoView) f0Var2.a, str2, tf.a);
        this.D = bVar;
        bVar.i();
        this.E = true;
    }
}
