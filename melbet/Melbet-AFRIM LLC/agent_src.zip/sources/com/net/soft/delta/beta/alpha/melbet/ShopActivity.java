package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import defpackage.ai;
import defpackage.as;
import defpackage.d2;
import defpackage.d6;
import defpackage.j0;
import defpackage.ko;
import defpackage.oi;
import defpackage.qm;
import defpackage.tf;
import defpackage.uf;
import defpackage.z;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class ShopActivity extends d2 {
    public static final /* synthetic */ int E = 0;
    public j0 C;
    public uf D;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class a {
        public static final /* synthetic */ a[] a = {new a("NONE", 0), new a("DEFAULT", 1), new a("CUSTOM", 2)};

        /* JADX INFO: Fake field, exist only in values array */
        a EF5;

        public a() {
            throw null;
        }

        public static a valueOf(String str) {
            return (a) Enum.valueOf(a.class, str);
        }

        public static a[] values() {
            return (a[]) a.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class b {
        public static final /* synthetic */ b[] a = {new b("INIT", 0), new b("READY", 1), new b("RUNNING", 2), new b("STOPPED", 3)};

        /* JADX INFO: Fake field, exist only in values array */
        b EF5;

        public b() {
            throw null;
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) a.clone();
        }
    }

    /* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
    public static final class c extends FragmentStateAdapter {
        @Override // androidx.recyclerview.widget.RecyclerView.f
        public final int c() {
            return 4;
        }

        @Override // androidx.viewpager2.adapter.FragmentStateAdapter
        public final androidx.fragment.app.d n(int i) {
            String str = as.X;
            String str2 = tf.a;
            String str3 = tf.n.get(i);
            str3.getClass();
            as asVar = new as();
            Bundle bundle = new Bundle();
            bundle.putString(as.X, str3);
            asVar.L(bundle);
            return asVar;
        }
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_shop, (ViewGroup) null, false);
        int i = R.id.tabLayout;
        TabLayout tabLayout = (TabLayout) ko.i(viewInflate, R.id.tabLayout);
        if (tabLayout != null) {
            i = R.id.toolbarShop;
            View viewI = ko.i(viewInflate, R.id.toolbarShop);
            if (viewI != null) {
                d6 d6VarA = d6.a(viewI);
                ViewPager2 viewPager2 = (ViewPager2) ko.i(viewInflate, R.id.viewPager);
                if (viewPager2 != null) {
                    LinearLayout linearLayout = (LinearLayout) viewInflate;
                    this.C = new j0(linearLayout, tabLayout, d6VarA, viewPager2);
                    setContentView(linearLayout);
                    this.D = new uf(this);
                    j0 j0Var = this.C;
                    if (j0Var == null) {
                        ai.d("binding");
                        throw null;
                    }
                    ((TextView) j0Var.b.c).setText(R.string.title_shop);
                    j0 j0Var2 = this.C;
                    if (j0Var2 == null) {
                        ai.d("binding");
                        throw null;
                    }
                    ((TextView) j0Var2.b.b).setVisibility(0);
                    j0 j0Var3 = this.C;
                    if (j0Var3 == null) {
                        ai.d("binding");
                        throw null;
                    }
                    ((ImageButton) j0Var3.b.a).setOnClickListener(new z(6, this));
                    x();
                    j0 j0Var4 = this.C;
                    if (j0Var4 == null) {
                        ai.d("binding");
                        throw null;
                    }
                    j0Var4.c.setAdapter(new c(this));
                    int[] iArr = {R.string.tab_piano, R.string.tab_bubble, R.string.tab_knife, R.string.tab_color};
                    j0 j0Var5 = this.C;
                    if (j0Var5 != null) {
                        new com.google.android.material.tabs.c(j0Var5.a, j0Var5.c, new oi(iArr, 1)).a();
                        return;
                    } else {
                        ai.d("binding");
                        throw null;
                    }
                }
                i = R.id.viewPager;
            }
        }
        qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    public final void x() {
        j0 j0Var = this.C;
        if (j0Var == null) {
            ai.d("binding");
            throw null;
        }
        TextView textView = (TextView) j0Var.b.b;
        uf ufVar = this.D;
        if (ufVar != null) {
            textView.setText(getString(R.string.shop_coins, Integer.valueOf(ufVar.a.getInt("total_coins", 0))));
        } else {
            ai.d("prefs");
            throw null;
        }
    }
}
