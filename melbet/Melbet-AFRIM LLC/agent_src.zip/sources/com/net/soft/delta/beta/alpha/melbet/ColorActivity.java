package com.net.soft.delta.beta.alpha.melbet;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import defpackage.ai;
import defpackage.d2;
import defpackage.f0;
import defpackage.ko;
import defpackage.nt;
import defpackage.qm;
import defpackage.tf;

/* compiled from: r8-map-id-129b8b6a61890c9ac60a6f65f06bf5060975caa8ec39da38f571bea48a5eda92 */
/* loaded from: classes.dex */
public final class ColorActivity extends d2 {
    public f0 C;
    public b D;

    public ColorActivity() {
        String.valueOf(5);
        Math.min(26, 12);
        nt.H("sample").toString();
        nt.H("sample").toString();
        System.identityHashCode(this);
    }

    @Override // defpackage.ae, androidx.activity.ComponentActivity, defpackage.m8, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_color, (ViewGroup) null, false);
        ColorView colorView = (ColorView) ko.i(viewInflate, R.id.colorView);
        if (colorView == null) {
            qm.f("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.colorView)));
            return;
        }
        FrameLayout frameLayout = (FrameLayout) viewInflate;
        this.C = new f0(frameLayout, colorView);
        setContentView(frameLayout);
        f0 f0Var = this.C;
        if (f0Var == null) {
            ai.d("binding");
            throw null;
        }
        ColorView colorView2 = (ColorView) f0Var.a;
        String str = tf.f;
        b bVar = new b(this, colorView2, str, str);
        this.D = bVar;
        bVar.i();
    }

    @Override // defpackage.d2, defpackage.ae, android.app.Activity
    public final void onDestroy() throws Exception {
        super.onDestroy();
        b bVar = this.D;
        if (bVar == null) {
            ai.d("binder");
            throw null;
        }
        bVar.b.k();
        bVar.f.f();
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onPause() {
        super.onPause();
        b bVar = this.D;
        if (bVar != null) {
            bVar.j();
        } else {
            ai.d("binder");
            throw null;
        }
    }

    @Override // defpackage.ae, android.app.Activity
    public final void onResume() {
        super.onResume();
        b bVar = this.D;
        if (bVar != null) {
            bVar.k();
        } else {
            ai.d("binder");
            throw null;
        }
    }
}
