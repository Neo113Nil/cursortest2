package com.civis.melbet.galba;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import com.civis.melbet.galba.MainActivity;
import com.civis.melbet.galba.databinding.ActivityMainBinding;
import defpackage.ax;
import defpackage.b70;
import defpackage.b8;
import defpackage.c30;
import defpackage.cg;
import defpackage.dx;
import defpackage.e60;
import defpackage.eo;
import defpackage.g8;
import defpackage.hz;
import defpackage.is;
import defpackage.j70;
import defpackage.j8;
import defpackage.jz;
import defpackage.k3;
import defpackage.ke;
import defpackage.lo;
import defpackage.n30;
import defpackage.ou;
import defpackage.p9;
import defpackage.pu;
import defpackage.qa;
import defpackage.r8;
import defpackage.rh;
import defpackage.rn;
import defpackage.s8;
import defpackage.sh;
import defpackage.sv;
import defpackage.u20;
import defpackage.vy;
import defpackage.wd;
import defpackage.xo;
import defpackage.z1;
import defpackage.z90;
import defpackage.zk;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class MainActivity extends k3 {
    public static final int BUILD_CODE = 3931;
    public static final Companion Companion = new Companion(null);
    private final xo _blvdaskd_cb7a$delegate;
    private final xo _ch5uylc5j_394f$delegate;
    private final int[] _keysj6ji2wlq_1523 = {56697, 27436, 53807, 46709, 11414, 30484, 12137, 25823, 50783, 46084};
    private final xo _pjw53o01_a063$delegate;
    private final xo _pkjxllhxa2_c7c3$delegate;
    private final xo _pndu4xe_580b$delegate;
    private String _rtoot5_9ff1;

    /* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
    public final class FetchCallback implements s8 {
        private final String prefsKey;
        final /* synthetic */ MainActivity this$0;

        public FetchCallback(MainActivity mainActivity, String str) {
            str.getClass();
            this.this$0 = mainActivity;
            this.prefsKey = str;
        }

        @Override // defpackage.s8
        public void onFailure(r8 r8Var, IOException iOException) {
            r8Var.getClass();
            iOException.getClass();
            final MainActivity mainActivity = this.this$0;
            mainActivity.runOnUiThread(new Runnable() { // from class: com.civis.melbet.galba.a
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.access$_fbe2weww_f9d8(mainActivity);
                }
            });
        }

        @Override // defpackage.s8
        public void onResponse(r8 r8Var, hz hzVar) throws IOException {
            r8Var.getClass();
            hzVar.getClass();
            this.this$0._hrgdyu555n_0084(hzVar, this.prefsKey);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
    public static final class RunState {
        private static final /* synthetic */ rh $ENTRIES;
        private static final /* synthetic */ RunState[] $VALUES;
        public static final RunState IDLE = new RunState("IDLE", 0);
        public static final RunState LOADING = new RunState("LOADING", 1);
        public static final RunState DONE = new RunState("DONE", 2);

        private static final /* synthetic */ RunState[] $values() {
            return new RunState[]{IDLE, LOADING, DONE};
        }

        static {
            RunState[] runStateArr$values = $values();
            $VALUES = runStateArr$values;
            runStateArr$values.getClass();
            $ENTRIES = new sh(runStateArr$values);
        }

        private RunState(String str, int i) {
        }

        public static rh getEntries() {
            return $ENTRIES;
        }

        public static RunState valueOf(String str) {
            return (RunState) Enum.valueOf(RunState.class, str);
        }

        public static RunState[] values() {
            return (RunState[]) $VALUES.clone();
        }
    }

    public MainActivity() {
        final int i = 0;
        this._blvdaskd_cb7a$delegate = new n30(new zk(this) { // from class: rq
            public final /* synthetic */ MainActivity g;

            {
                this.g = this;
            }

            @Override // defpackage.zk
            public final Object a() {
                int i2 = i;
                MainActivity mainActivity = this.g;
                switch (i2) {
                    case 0:
                        return MainActivity._blvdaskd_cb7a_delegate$lambda$0(mainActivity);
                    case 1:
                        return MainActivity._pndu4xe_580b_delegate$lambda$1(mainActivity);
                    case 2:
                        return MainActivity._pkjxllhxa2_c7c3_delegate$lambda$2(mainActivity);
                    default:
                        return MainActivity._pjw53o01_a063_delegate$lambda$3(mainActivity);
                }
            }
        });
        final int i2 = 1;
        this._pndu4xe_580b$delegate = new n30(new zk(this) { // from class: rq
            public final /* synthetic */ MainActivity g;

            {
                this.g = this;
            }

            @Override // defpackage.zk
            public final Object a() {
                int i22 = i2;
                MainActivity mainActivity = this.g;
                switch (i22) {
                    case 0:
                        return MainActivity._blvdaskd_cb7a_delegate$lambda$0(mainActivity);
                    case 1:
                        return MainActivity._pndu4xe_580b_delegate$lambda$1(mainActivity);
                    case 2:
                        return MainActivity._pkjxllhxa2_c7c3_delegate$lambda$2(mainActivity);
                    default:
                        return MainActivity._pjw53o01_a063_delegate$lambda$3(mainActivity);
                }
            }
        });
        final int i3 = 2;
        this._pkjxllhxa2_c7c3$delegate = new n30(new zk(this) { // from class: rq
            public final /* synthetic */ MainActivity g;

            {
                this.g = this;
            }

            @Override // defpackage.zk
            public final Object a() {
                int i22 = i3;
                MainActivity mainActivity = this.g;
                switch (i22) {
                    case 0:
                        return MainActivity._blvdaskd_cb7a_delegate$lambda$0(mainActivity);
                    case 1:
                        return MainActivity._pndu4xe_580b_delegate$lambda$1(mainActivity);
                    case 2:
                        return MainActivity._pkjxllhxa2_c7c3_delegate$lambda$2(mainActivity);
                    default:
                        return MainActivity._pjw53o01_a063_delegate$lambda$3(mainActivity);
                }
            }
        });
        final int i4 = 3;
        this._pjw53o01_a063$delegate = new n30(new zk(this) { // from class: rq
            public final /* synthetic */ MainActivity g;

            {
                this.g = this;
            }

            @Override // defpackage.zk
            public final Object a() {
                int i22 = i4;
                MainActivity mainActivity = this.g;
                switch (i22) {
                    case 0:
                        return MainActivity._blvdaskd_cb7a_delegate$lambda$0(mainActivity);
                    case 1:
                        return MainActivity._pndu4xe_580b_delegate$lambda$1(mainActivity);
                    case 2:
                        return MainActivity._pkjxllhxa2_c7c3_delegate$lambda$2(mainActivity);
                    default:
                        return MainActivity._pjw53o01_a063_delegate$lambda$3(mainActivity);
                }
            }
        });
        this._ch5uylc5j_394f$delegate = new n30(new z1(i3));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActivityMainBinding _blvdaskd_cb7a_delegate$lambda$0(MainActivity mainActivity) {
        return ActivityMainBinding.inflate(mainActivity.getLayoutInflater());
    }

    private final String _burqwsaorl1_27a9() {
        String str = Build.BRAND;
        str.getClass();
        str.toUpperCase(Locale.ROOT).getClass();
        String packageName = getPackageName();
        packageName.getClass();
        return new LaunchHelper(packageName, this).buildEndpoint() + _dt322q4_8cd6(new byte[]{91, -66, 20, -81, 89}, 7) + getPackageName();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final pu _ch5uylc5j_394f_delegate$lambda$4() {
        return new pu(new ou());
    }

    private final String _dt322q4_8cd6(byte[] bArr, int i) {
        int i2 = this._keysj6ji2wlq_1523[i];
        int i3 = (i2 >> 8) & 255;
        int i4 = i2 & 255;
        ArrayList arrayList = new ArrayList(bArr.length);
        int length = bArr.length;
        int i5 = 0;
        int i6 = 0;
        while (i5 < length) {
            int i7 = i6 + 1;
            arrayList.add(Byte.valueOf((byte) ((i6 % 2 == 0 ? i3 : i4) ^ (bArr[i5] & 255))));
            i5++;
            i6 = i7;
        }
        return new String(qa.n0(arrayList), p9.a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ee, code lost:
    
        r7 = r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void _fbb5zj_1cbf() {
        ax axVar;
        String str_dt322q4_8cd6 = _dt322q4_8cd6(new byte[]{-96, 90, -96, 67}, 2);
        String str_burqwsaorl1_27a9 = _burqwsaorl1_27a9();
        String str_dt322q4_8cd62 = _dt322q4_8cd6(new byte[]{-18, 88, -14, 16, -64, 28, -43, 16, -101, 56, -39, 17, -45, 25}, 3);
        String str_dt322q4_8cd63 = _dt322q4_8cd6(new byte[]{109, -11, 79, -13, 92, -30, 1, -38, 77, -8, 75, -29, 77, -15, 73}, 4);
        String str_dt322q4_8cd64 = _dt322q4_8cd6(new byte[]{18, 122, 90, 65, 36, 56, 18, 122, 76, 101, 74, 36, 89, 45}, 5);
        String str_dt322q4_8cd65 = _dt322q4_8cd6(new byte[]{122, 26, 74, 27, 2, 40, 72, 12, 65, 29}, 6);
        ke keVar = new ke(5);
        str_burqwsaorl1_27a9.getClass();
        if (c30.i0(str_burqwsaorl1_27a9, "ws:", true)) {
            str_burqwsaorl1_27a9 = "http:".concat(str_burqwsaorl1_27a9.substring(3));
        } else if (c30.i0(str_burqwsaorl1_27a9, "wss:", true)) {
            str_burqwsaorl1_27a9 = "https:".concat(str_burqwsaorl1_27a9.substring(4));
        }
        rn rnVar = new rn(0);
        ax axVar2 = null;
        rnVar.f(null, str_burqwsaorl1_27a9);
        keVar.f = rnVar.b();
        String str = Build.MODEL;
        str.getClass();
        keVar.q(str_dt322q4_8cd62, str);
        keVar.q(str_dt322q4_8cd63, str_dt322q4_8cd64);
        String defaultUserAgent = WebSettings.getDefaultUserAgent(this);
        defaultUserAgent.getClass();
        keVar.q(str_dt322q4_8cd65, defaultUserAgent);
        vy vyVarF = keVar.f();
        pu puVar = get_ch5uylc5j_394f();
        puVar.getClass();
        dx dxVar = new dx(puVar, vyVarF);
        FetchCallback fetchCallback = new FetchCallback(this, str_dt322q4_8cd6);
        if (!dxVar.j.compareAndSet(false, true)) {
            g8.u("Already Executed");
            return;
        }
        sv svVar = sv.a;
        dxVar.k = sv.a.g();
        ke keVar2 = puVar.f;
        ax axVar3 = new ax(dxVar, fetchCallback);
        keVar2.getClass();
        synchronized (keVar2) {
            ((ArrayDeque) keVar2.g).add(axVar3);
            String str2 = vyVarF.a.d;
            Iterator it = ((ArrayDeque) keVar2.h).iterator();
            while (true) {
                if (it.hasNext()) {
                    axVar = (ax) it.next();
                    if (lo.b(axVar.h.g.a.d, str2)) {
                        break;
                    }
                } else {
                    Iterator it2 = ((ArrayDeque) keVar2.g).iterator();
                    while (it2.hasNext()) {
                        axVar = (ax) it2.next();
                        if (lo.b(axVar.h.g.a.d, str2)) {
                        }
                    }
                }
            }
            if (axVar2 != null) {
                axVar3.g = axVar2.g;
            }
        }
        keVar2.w();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void _fbe2weww_f9d8() {
        Math.random();
        startActivity(new Intent(this, (Class<?>) MainActivity2.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005b A[Catch: all -> 0x006a, TRY_ENTER, TryCatch #1 {all -> 0x006a, blocks: (B:5:0x0028, B:7:0x002e, B:9:0x003f, B:11:0x0047, B:18:0x0055, B:21:0x005d, B:20:0x005b), top: B:41:0x0028 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0055 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void _hrgdyu555n_0084(hz hzVar, final String str) throws IOException {
        String strL;
        String str2;
        final String str_dt322q4_8cd6 = _dt322q4_8cd6(new byte[]{-79, 48, -76, 52, -93, 45, -75, 113, -94, 58, -80}, 8);
        final String str_dt322q4_8cd62 = _dt322q4_8cd6(new byte[]{-106, 119, -64, 101, -64, 113, -57, 38, -114, 38, -37, 111, -106}, 9);
        final String str3 = hzVar.f.a.h;
        jz jzVar = hzVar.l;
        if (jzVar != null) {
            j8 j8VarO = jzVar.o();
            try {
                is isVarN = jzVar.n();
                if (isVarN != null) {
                    Charset charsetForName = p9.a;
                    String[] strArr = isVarN.b;
                    int i = 0;
                    int iW = lo.w(0, strArr.length - 1, 2);
                    if (iW >= 0) {
                        while (!c30.f0(strArr[i], "charset")) {
                            if (i == iW) {
                                str2 = null;
                                break;
                            }
                            i += 2;
                        }
                        str2 = strArr[i + 1];
                        if (str2 != null) {
                            try {
                                charsetForName = Charset.forName(str2);
                            } catch (IllegalArgumentException unused) {
                            }
                        }
                        if (charsetForName == null) {
                            charsetForName = p9.a;
                        }
                        strL = j8VarO.l(e60.p(j8VarO, charsetForName));
                        j8VarO.close();
                    } else {
                        str2 = null;
                        if (str2 != null) {
                        }
                        if (charsetForName == null) {
                        }
                        strL = j8VarO.l(e60.p(j8VarO, charsetForName));
                        j8VarO.close();
                    }
                }
            } finally {
            }
        } else {
            strL = "";
        }
        final String str4 = strL;
        runOnUiThread(new Runnable() { // from class: sq
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity._hrgdyu555n_0084$lambda$8(str3, str_dt322q4_8cd6, this, str4, str_dt322q4_8cd62, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _hrgdyu555n_0084$lambda$8(String str, String str2, MainActivity mainActivity, String str3, String str4, String str5) {
        if (u20.k0(str, str2)) {
            if (u20.k0(str3, str4)) {
                mainActivity._fbe2weww_f9d8();
                return;
            } else {
                mainActivity._fbe2weww_f9d8();
                return;
            }
        }
        SharedPreferences sharedPreferences = mainActivity.get_pjw53o01_a063();
        sharedPreferences.getClass();
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        editorEdit.getClass();
        editorEdit.putString(str5, str);
        editorEdit.apply();
        mainActivity._rtoot5_9ff1 = str;
        mainActivity._ope038_e055(str);
    }

    private final String _manyqrjla_dd6d() {
        getPackageName().getClass();
        return Build.MODEL + "_3106";
    }

    private final void _memf8f0jqt_01ab() {
        String str = Build.VERSION.RELEASE;
        String str2 = Build.MODEL;
        str2.getClass();
        str2.toLowerCase(Locale.ROOT).getClass();
    }

    private final String _mhfefeq_8be7() {
        getPackageName().getClass();
        Math.random();
        String str = Build.VERSION.RELEASE;
        getPackageName().getClass();
        Build.FINGERPRINT.getClass();
        return Build.MODEL + "_4760";
    }

    private final boolean _mu8aqd9q_5484() {
        getPackageName().getClass();
        String str = Build.DEVICE;
        str.getClass();
        new StringBuilder((CharSequence) str).reverse().getClass();
        String str2 = Build.MODEL;
        str2.getClass();
        str2.toLowerCase(Locale.ROOT).getClass();
        return true;
    }

    private final int _mwmiiy5azo_32be() {
        System.currentTimeMillis();
        System.currentTimeMillis();
        String str = Build.BRAND;
        str.getClass();
        str.toUpperCase(Locale.ROOT).getClass();
        return getPackageName().length() + 41;
    }

    private final void _ope038_e055(String str) {
        try {
            Math.random();
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Exception unused) {
            _fbe2weww_f9d8();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final SharedPreferences _pjw53o01_a063_delegate$lambda$3(MainActivity mainActivity) {
        return mainActivity.getSharedPreferences(mainActivity.get_pndu4xe_580b(), 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String _pkjxllhxa2_c7c3_delegate$lambda$2(MainActivity mainActivity) {
        return mainActivity._dt322q4_8cd6(new byte[]{-96, 90, -96, 67}, 2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String _pndu4xe_580b_delegate$lambda$1(MainActivity mainActivity) {
        return mainActivity._dt322q4_8cd6(new byte[]{8, 74, 12}, 1);
    }

    public static final /* synthetic */ void access$_fbe2weww_f9d8(MainActivity mainActivity) {
        mainActivity._fbe2weww_f9d8();
    }

    private final ActivityMainBinding get_blvdaskd_cb7a() {
        return (ActivityMainBinding) ((n30) this._blvdaskd_cb7a$delegate).a();
    }

    private final pu get_ch5uylc5j_394f() {
        return (pu) ((n30) this._ch5uylc5j_394f$delegate).a();
    }

    private final SharedPreferences get_pjw53o01_a063() {
        return (SharedPreferences) ((n30) this._pjw53o01_a063$delegate).a();
    }

    private final String get_pkjxllhxa2_c7c3() {
        return (String) ((n30) this._pkjxllhxa2_c7c3$delegate).a();
    }

    private final String get_pndu4xe_580b() {
        return (String) ((n30) this._pndu4xe_580b$delegate).a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final z90 onCreate$lambda$5(View view, z90 z90Var) {
        view.getClass();
        z90Var.getClass();
        eo eoVarH = z90Var.a.h(519);
        eoVarH.getClass();
        view.setPadding(eoVarH.a, eoVarH.b, eoVarH.c, eoVarH.d);
        return z90Var;
    }

    @Override // defpackage.yj, defpackage.nb, defpackage.mb, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String str = Build.VERSION.RELEASE;
        cg.a(this);
        if (RunState.IDLE != null) {
            setContentView(get_blvdaskd_cb7a().getRoot());
        }
        View viewFindViewById = findViewById(R.id.main);
        g8 g8Var = new g8(17);
        WeakHashMap weakHashMap = j70.a;
        b70.c(viewFindViewById, g8Var);
        getWindow().setFlags(1024, 1024);
        String string = get_pjw53o01_a063().getString(get_pkjxllhxa2_c7c3(), null);
        if (string != null && !u20.o0(string)) {
            this._rtoot5_9ff1 = string;
            _ope038_e055(string);
        } else if (b8.L(1).isEmpty()) {
            _fbb5zj_1cbf();
        } else {
            _fbb5zj_1cbf();
        }
    }

    @Override // defpackage.yj, android.app.Activity
    public void onResume() {
        super.onResume();
        String str = this._rtoot5_9ff1;
        if (str != null) {
            _ope038_e055(str);
        }
    }

    /* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
    public static final class Companion {
        public /* synthetic */ Companion(wd wdVar) {
            this();
        }

        private Companion() {
        }
    }
}
