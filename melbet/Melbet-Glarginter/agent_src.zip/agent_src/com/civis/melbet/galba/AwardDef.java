package com.civis.melbet.galba;

import defpackage.lo;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class AwardDef {
    private final int desc;
    private final int icon;
    private final String id;
    private final int title;

    public AwardDef(String str, int i, int i2, int i3) {
        str.getClass();
        this.id = str;
        this.title = i;
        this.desc = i2;
        this.icon = i3;
    }

    public static /* synthetic */ AwardDef copy$default(AwardDef awardDef, String str, int i, int i2, int i3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            str = awardDef.id;
        }
        if ((i4 & 2) != 0) {
            i = awardDef.title;
        }
        if ((i4 & 4) != 0) {
            i2 = awardDef.desc;
        }
        if ((i4 & 8) != 0) {
            i3 = awardDef.icon;
        }
        return awardDef.copy(str, i, i2, i3);
    }

    public final String component1() {
        return this.id;
    }

    public final int component2() {
        return this.title;
    }

    public final int component3() {
        return this.desc;
    }

    public final int component4() {
        return this.icon;
    }

    public final AwardDef copy(String str, int i, int i2, int i3) {
        str.getClass();
        return new AwardDef(str, i, i2, i3);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AwardDef)) {
            return false;
        }
        AwardDef awardDef = (AwardDef) obj;
        return lo.b(this.id, awardDef.id) && this.title == awardDef.title && this.desc == awardDef.desc && this.icon == awardDef.icon;
    }

    public final int getDesc() {
        return this.desc;
    }

    public final int getIcon() {
        return this.icon;
    }

    public final String getId() {
        return this.id;
    }

    public final int getTitle() {
        return this.title;
    }

    public int hashCode() {
        return Integer.hashCode(this.icon) + ((Integer.hashCode(this.desc) + ((Integer.hashCode(this.title) + (this.id.hashCode() * 31)) * 31)) * 31);
    }

    public String toString() {
        return "AwardDef(id=" + this.id + ", title=" + this.title + ", desc=" + this.desc + ", icon=" + this.icon + ")";
    }
}
