package com.civis.melbet.galba.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.civis.melbet.galba.R;
import defpackage.fv;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class ActivityMainBinding {
    public final ConstraintLayout main;
    public final ProgressBar progressBar;
    private final ConstraintLayout rootView;

    private ActivityMainBinding(ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2, ProgressBar progressBar) {
        this.rootView = constraintLayout;
        this.main = constraintLayout2;
        this.progressBar = progressBar;
    }

    public static ActivityMainBinding bind(View view) {
        ConstraintLayout constraintLayout = (ConstraintLayout) view;
        int i = R.id.progressBar;
        ProgressBar progressBar = (ProgressBar) fv.p(view, i);
        if (progressBar != null) {
            return new ActivityMainBinding(constraintLayout, constraintLayout, progressBar);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_main, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }
}
