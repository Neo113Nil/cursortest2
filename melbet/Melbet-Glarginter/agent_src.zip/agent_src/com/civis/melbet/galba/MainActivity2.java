package com.civis.melbet.galba;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Property;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.civis.melbet.galba.MainActivity2;
import com.civis.melbet.galba.databinding.ActivityMain2Binding;
import com.civis.melbet.galba.databinding.ItemAwardBinding;
import com.civis.melbet.galba.databinding.ItemHabitBinding;
import com.civis.melbet.galba.databinding.ItemTopBinding;
import com.google.android.material.snackbar.SnackbarContentLayout;
import defpackage.b70;
import defpackage.cg;
import defpackage.eo;
import defpackage.f6;
import defpackage.g8;
import defpackage.ho;
import defpackage.io;
import defpackage.j70;
import defpackage.k3;
import defpackage.lo;
import defpackage.o10;
import defpackage.qa;
import defpackage.r50;
import defpackage.ra;
import defpackage.u20;
import defpackage.uq;
import defpackage.vq;
import defpackage.vu;
import defpackage.wd;
import defpackage.wq;
import defpackage.xq;
import defpackage.z90;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class MainActivity2 extends k3 {
    private static final String CAT_HEALTH = "health";
    private static final String CAT_HOME = "home";
    private static final String CAT_MIND = "mind";
    private static final String CAT_OTHER = "other";
    private static final String CAT_SPORT = "sport";
    private static final String CAT_WORK = "work";
    public static final Companion Companion = new Companion(null);
    private boolean bannerBusy;
    private ActivityMain2Binding binding;
    private int currentTab;
    private int formColor;
    private String formEditId;
    private HabitStore store;
    private final List<HabitItem> habits = new ArrayList();
    private final Map<String, Long> unlocked = new LinkedHashMap();
    private final List<Animator> liveAnimators = new ArrayList();
    private final f6 awardQueue = new f6();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private final SimpleDateFormat headerFormat = new SimpleDateFormat("d MMMM, EEEE", Locale.forLanguageTag("ru"));
    private String formCategory = CAT_HEALTH;

    private final void animateProgress(ProgressBar progressBar, int i) {
        ObjectAnimator objectAnimatorOfInt = ObjectAnimator.ofInt(progressBar, "progress", progressBar.getProgress(), r50.n(i, 100));
        objectAnimatorOfInt.setDuration(420L);
        objectAnimatorOfInt.start();
    }

    private final void applyInsets() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        CoordinatorLayout coordinatorLayout = activityMain2Binding.root;
        g8 g8Var = new g8(18);
        WeakHashMap weakHashMap = j70.a;
        b70.c(coordinatorLayout, g8Var);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final z90 applyInsets$lambda$1(View view, z90 z90Var) {
        view.getClass();
        z90Var.getClass();
        eo eoVarH = z90Var.a.h(519);
        eoVarH.getClass();
        view.setPadding(eoVarH.a, eoVarH.b, eoVarH.c, eoVarH.d);
        return z90Var;
    }

    private final void bindBack() {
        getOnBackPressedDispatcher().a(this, new vu() { // from class: com.civis.melbet.galba.MainActivity2.bindBack.1
            {
                super(true);
            }

            @Override // defpackage.vu
            public void handleOnBackPressed() {
                ActivityMain2Binding activityMain2Binding = MainActivity2.this.binding;
                if (activityMain2Binding == null) {
                    lo.V("binding");
                    throw null;
                }
                int visibility = activityMain2Binding.overlayForm.getVisibility();
                MainActivity2 mainActivity2 = MainActivity2.this;
                if (visibility == 0) {
                    mainActivity2.hideForm();
                } else {
                    mainActivity2.finish();
                }
            }
        });
    }

    private final void bindClicks() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        final int i = 0;
        activityMain2Binding.tabToday.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i2 = i;
                MainActivity2 mainActivity2 = this.g;
                switch (i2) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        final int i2 = 2;
        activityMain2Binding2.tabStats.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i2;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        final int i3 = 8;
        activityMain2Binding3.tabAwards.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i3;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        final int i4 = 9;
        activityMain2Binding4.navToday.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i4;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        final int i5 = 10;
        activityMain2Binding5.navStats.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i5;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding6 = this.binding;
        if (activityMain2Binding6 == null) {
            lo.V("binding");
            throw null;
        }
        final int i6 = 12;
        activityMain2Binding6.navAwards.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i6;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding7 = this.binding;
        if (activityMain2Binding7 == null) {
            lo.V("binding");
            throw null;
        }
        final int i7 = 13;
        activityMain2Binding7.fabAdd.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i7;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding8 = this.binding;
        if (activityMain2Binding8 == null) {
            lo.V("binding");
            throw null;
        }
        final int i8 = 14;
        activityMain2Binding8.buttonEmptyAdd.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i8;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding9 = this.binding;
        if (activityMain2Binding9 == null) {
            lo.V("binding");
            throw null;
        }
        final int i9 = 15;
        activityMain2Binding9.scrim.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i9;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding10 = this.binding;
        if (activityMain2Binding10 == null) {
            lo.V("binding");
            throw null;
        }
        final int i10 = 16;
        activityMain2Binding10.buttonCancel.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i10;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding11 = this.binding;
        if (activityMain2Binding11 == null) {
            lo.V("binding");
            throw null;
        }
        final int i11 = 11;
        activityMain2Binding11.buttonSave.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i11;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding12 = this.binding;
        if (activityMain2Binding12 == null) {
            lo.V("binding");
            throw null;
        }
        final int i12 = 17;
        activityMain2Binding12.buttonDelete.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i12;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding13 = this.binding;
        if (activityMain2Binding13 == null) {
            lo.V("binding");
            throw null;
        }
        final int i13 = 18;
        activityMain2Binding13.chipHealth.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i13;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding14 = this.binding;
        if (activityMain2Binding14 == null) {
            lo.V("binding");
            throw null;
        }
        final int i14 = 19;
        activityMain2Binding14.chipSport.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i14;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding15 = this.binding;
        if (activityMain2Binding15 == null) {
            lo.V("binding");
            throw null;
        }
        final int i15 = 20;
        activityMain2Binding15.chipMind.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i15;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding16 = this.binding;
        if (activityMain2Binding16 == null) {
            lo.V("binding");
            throw null;
        }
        final int i16 = 21;
        activityMain2Binding16.chipHome.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i16;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding17 = this.binding;
        if (activityMain2Binding17 == null) {
            lo.V("binding");
            throw null;
        }
        final int i17 = 22;
        activityMain2Binding17.chipWork.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i17;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding18 = this.binding;
        if (activityMain2Binding18 == null) {
            lo.V("binding");
            throw null;
        }
        final int i18 = 23;
        activityMain2Binding18.chipOther.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i18;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding19 = this.binding;
        if (activityMain2Binding19 == null) {
            lo.V("binding");
            throw null;
        }
        final int i19 = 24;
        activityMain2Binding19.wrapColor0.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i19;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding20 = this.binding;
        if (activityMain2Binding20 == null) {
            lo.V("binding");
            throw null;
        }
        final int i20 = 1;
        activityMain2Binding20.wrapColor1.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i20;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding21 = this.binding;
        if (activityMain2Binding21 == null) {
            lo.V("binding");
            throw null;
        }
        final int i21 = 3;
        activityMain2Binding21.wrapColor2.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i22 = i21;
                MainActivity2 mainActivity2 = this.g;
                switch (i22) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding22 = this.binding;
        if (activityMain2Binding22 == null) {
            lo.V("binding");
            throw null;
        }
        final int i22 = 4;
        activityMain2Binding22.wrapColor3.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i222 = i22;
                MainActivity2 mainActivity2 = this.g;
                switch (i222) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding23 = this.binding;
        if (activityMain2Binding23 == null) {
            lo.V("binding");
            throw null;
        }
        final int i23 = 5;
        activityMain2Binding23.wrapColor4.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i222 = i23;
                MainActivity2 mainActivity2 = this.g;
                switch (i222) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding24 = this.binding;
        if (activityMain2Binding24 == null) {
            lo.V("binding");
            throw null;
        }
        final int i24 = 6;
        activityMain2Binding24.wrapColor5.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i222 = i24;
                MainActivity2 mainActivity2 = this.g;
                switch (i222) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
        ActivityMain2Binding activityMain2Binding25 = this.binding;
        if (activityMain2Binding25 == null) {
            lo.V("binding");
            throw null;
        }
        final int i25 = 7;
        activityMain2Binding25.wrapColor6.setOnClickListener(new View.OnClickListener(this) { // from class: tq
            public final /* synthetic */ MainActivity2 g;

            {
                this.g = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Resources.NotFoundException {
                int i222 = i25;
                MainActivity2 mainActivity2 = this.g;
                switch (i222) {
                    case 0:
                        mainActivity2.selectTab(0);
                        break;
                    case 1:
                        mainActivity2.selectColor(1);
                        break;
                    case 2:
                        mainActivity2.selectTab(1);
                        break;
                    case 3:
                        mainActivity2.selectColor(2);
                        break;
                    case 4:
                        mainActivity2.selectColor(3);
                        break;
                    case 5:
                        mainActivity2.selectColor(4);
                        break;
                    case 6:
                        mainActivity2.selectColor(5);
                        break;
                    case 7:
                        mainActivity2.selectColor(6);
                        break;
                    case 8:
                        mainActivity2.selectTab(2);
                        break;
                    case 9:
                        mainActivity2.selectTab(0);
                        break;
                    case 10:
                        mainActivity2.selectTab(1);
                        break;
                    case 11:
                        mainActivity2.saveForm();
                        break;
                    case 12:
                        mainActivity2.selectTab(2);
                        break;
                    case 13:
                        mainActivity2.openCreate();
                        break;
                    case 14:
                        mainActivity2.openCreate();
                        break;
                    case 15:
                        mainActivity2.hideForm();
                        break;
                    case 16:
                        mainActivity2.hideForm();
                        break;
                    case 17:
                        mainActivity2.deleteEditing();
                        break;
                    case 18:
                        mainActivity2.selectCategory(MainActivity2.CAT_HEALTH);
                        break;
                    case 19:
                        mainActivity2.selectCategory(MainActivity2.CAT_SPORT);
                        break;
                    case 20:
                        mainActivity2.selectCategory(MainActivity2.CAT_MIND);
                        break;
                    case 21:
                        mainActivity2.selectCategory(MainActivity2.CAT_HOME);
                        break;
                    case 22:
                        mainActivity2.selectCategory(MainActivity2.CAT_WORK);
                        break;
                    case 23:
                        mainActivity2.selectCategory(MainActivity2.CAT_OTHER);
                        break;
                    default:
                        mainActivity2.selectColor(0);
                        break;
                }
            }
        });
    }

    private final List<AwardDef> catalog() {
        return ra.h0(new AwardDef("first_habit", R.string.award_first_habit_title, R.string.award_first_habit_desc, R.drawable.ic_sprout), new AwardDef("three_habits", R.string.award_three_habits_title, R.string.award_three_habits_desc, R.drawable.ic_other), new AwardDef("five_habits", R.string.award_five_habits_title, R.string.award_five_habits_desc, R.drawable.ic_other), new AwardDef("first_check", R.string.award_first_check_title, R.string.award_first_check_desc, R.drawable.ic_flame), new AwardDef("five_checks", R.string.award_five_checks_title, R.string.award_five_checks_desc, R.drawable.ic_today), new AwardDef("thirty_checks", R.string.award_thirty_checks_title, R.string.award_thirty_checks_desc, R.drawable.ic_stats), new AwardDef("hundred_checks", R.string.award_hundred_checks_title, R.string.award_hundred_checks_desc, R.drawable.ic_award), new AwardDef("streak_3", R.string.award_streak_3_title, R.string.award_streak_3_desc, R.drawable.ic_flame), new AwardDef("streak_7", R.string.award_streak_7_title, R.string.award_streak_7_desc, R.drawable.ic_flame), new AwardDef("streak_21", R.string.award_streak_21_title, R.string.award_streak_21_desc, R.drawable.ic_award), new AwardDef("streak_30", R.string.award_streak_30_title, R.string.award_streak_30_desc, R.drawable.ic_award), new AwardDef("perfect_day", R.string.award_perfect_day_title, R.string.award_perfect_day_desc, R.drawable.ic_health), new AwardDef("week_hero", R.string.award_week_hero_title, R.string.award_week_hero_desc, R.drawable.ic_stats));
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue
    java.lang.NullPointerException: Cannot invoke "java.util.List.iterator()" because the return value of "jadx.core.dex.visitors.regions.SwitchOverStringVisitor$SwitchData.getNewCases()" is null
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(SwitchOverStringVisitor.java:109)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(SwitchOverStringVisitor.java:66)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:77)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:82)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterative(DepthRegionTraversal.java:31)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visit(SwitchOverStringVisitor.java:60)
     */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0040  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.String categoryName(java.lang.String r2) {
        /*
            r1 = this;
            int r0 = r2.hashCode()
            switch(r0) {
                case -1221262756: goto L38;
                case 3208415: goto L2c;
                case 3351634: goto L20;
                case 3655441: goto L14;
                case 109651828: goto L8;
                default: goto L7;
            }
        L7:
            goto L40
        L8:
            java.lang.String r0 = "sport"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L11
            goto L40
        L11:
            int r2 = com.civis.melbet.galba.R.string.cat_sport
            goto L45
        L14:
            java.lang.String r0 = "work"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L1d
            goto L40
        L1d:
            int r2 = com.civis.melbet.galba.R.string.cat_work
            goto L45
        L20:
            java.lang.String r0 = "mind"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L29
            goto L40
        L29:
            int r2 = com.civis.melbet.galba.R.string.cat_mind
            goto L45
        L2c:
            java.lang.String r0 = "home"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L35
            goto L40
        L35:
            int r2 = com.civis.melbet.galba.R.string.cat_home
            goto L45
        L38:
            java.lang.String r0 = "health"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L43
        L40:
            int r2 = com.civis.melbet.galba.R.string.cat_other
            goto L45
        L43:
            int r2 = com.civis.melbet.galba.R.string.cat_health
        L45:
            java.lang.String r1 = r1.getString(r2)
            r1.getClass()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.civis.melbet.galba.MainActivity2.categoryName(java.lang.String):java.lang.String");
    }

    private final int colorOf(int i) {
        return getColor(new int[]{R.color.coral, R.color.sage, R.color.lavender, R.color.gold, R.color.sky, R.color.rose, R.color.teal}[r50.n(i, 6)]);
    }

    private final String dayKey(int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(6, i);
        String str = this.dateFormat.format(calendar.getTime());
        str.getClass();
        return str;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void deleteEditing() throws Resources.NotFoundException {
        String str = this.formEditId;
        if (str == null) {
            return;
        }
        Iterator<HabitItem> it = this.habits.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            } else if (lo.b(it.next().getId(), str)) {
                break;
            } else {
                i++;
            }
        }
        if (i < 0) {
            return;
        }
        HabitItem habitItemRemove = this.habits.remove(i);
        persist();
        hideForm();
        refreshAll();
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        o10 o10VarH = o10.h(activityMain2Binding.root, R.string.habit_deleted, 0);
        int i2 = R.string.undo;
        vq vqVar = new vq(this, i, habitItemRemove);
        CharSequence text = o10VarH.h.getText(i2);
        Button actionView = ((SnackbarContentLayout) o10VarH.i.getChildAt(0)).getActionView();
        if (TextUtils.isEmpty(text)) {
            actionView.setVisibility(8);
            actionView.setOnClickListener(null);
            o10VarH.D = false;
        } else {
            o10VarH.D = true;
            actionView.setVisibility(0);
            actionView.setText(text);
            actionView.setOnClickListener(new xq(o10VarH, vqVar, 2));
        }
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        o10VarH.e(activityMain2Binding2.fabAdd);
        o10VarH.i();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void deleteEditing$lambda$53(MainActivity2 mainActivity2, int i, HabitItem habitItem, View view) throws Resources.NotFoundException {
        List<HabitItem> list = mainActivity2.habits;
        int size = list.size();
        if (i > size) {
            i = size;
        }
        list.add(i, habitItem);
        mainActivity2.persist();
        mainActivity2.refreshAll();
    }

    private final void drainBanner() {
        if (this.bannerBusy || this.awardQueue.isEmpty()) {
            return;
        }
        int i = 1;
        this.bannerBusy = true;
        AwardDef awardDef = (AwardDef) this.awardQueue.removeFirst();
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.bannerAward.setText(getString(R.string.banner_award, getString(awardDef.getTitle())));
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.bannerAward.setVisibility(0);
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.bannerAward.setAlpha(0.0f);
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding4.bannerAward.setTranslationY(-24.0f);
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding5.bannerAward.animate().alpha(1.0f).translationY(0.0f).setDuration(280L).start();
        this.handler.postDelayed(new uq(this, i), 2600L);
        renderAwards();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void drainBanner$lambda$49(MainActivity2 mainActivity2) {
        ActivityMain2Binding activityMain2Binding = mainActivity2.binding;
        if (activityMain2Binding != null) {
            activityMain2Binding.bannerAward.animate().alpha(0.0f).translationY(-24.0f).setDuration(240L).withEndAction(new uq(mainActivity2, 0)).start();
        } else {
            lo.V("binding");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void drainBanner$lambda$49$lambda$48(MainActivity2 mainActivity2) {
        ActivityMain2Binding activityMain2Binding = mainActivity2.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.bannerAward.setVisibility(8);
        mainActivity2.bannerBusy = false;
        mainActivity2.drainBanner();
    }

    private final void evaluateAwards() {
        Integer numValueOf;
        boolean z;
        int size = this.habits.size();
        Iterator<T> it = this.habits.iterator();
        int size2 = 0;
        while (it.hasNext()) {
            size2 += ((HabitItem) it.next()).getDays().size();
        }
        Iterator<T> it2 = this.habits.iterator();
        if (it2.hasNext()) {
            numValueOf = Integer.valueOf(streakOf((HabitItem) it2.next()));
            while (it2.hasNext()) {
                Integer numValueOf2 = Integer.valueOf(streakOf((HabitItem) it2.next()));
                if (numValueOf.compareTo(numValueOf2) < 0) {
                    numValueOf = numValueOf2;
                }
            }
        } else {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : 0;
        if (size <= 0) {
            z = false;
            break;
        }
        List<HabitItem> list = this.habits;
        if (list == null || !list.isEmpty()) {
            Iterator<T> it3 = list.iterator();
            while (it3.hasNext()) {
                if (!((HabitItem) it3.next()).getDays().contains(todayKey())) {
                    z = false;
                    break;
                }
            }
        }
        z = true;
        int iWeekCompletions = weekCompletions();
        unlockIf("first_habit", size >= 1);
        unlockIf("three_habits", size >= 3);
        unlockIf("five_habits", size >= 5);
        unlockIf("first_check", size2 >= 1);
        unlockIf("five_checks", size2 >= 5);
        unlockIf("thirty_checks", size2 >= 30);
        unlockIf("hundred_checks", size2 >= 100);
        unlockIf("streak_3", iIntValue >= 3);
        unlockIf("streak_7", iIntValue >= 7);
        unlockIf("streak_21", iIntValue >= 21);
        unlockIf("streak_30", iIntValue >= 30);
        unlockIf("perfect_day", z);
        unlockIf("week_hero", iWeekCompletions >= 20);
        HabitStore habitStore = this.store;
        if (habitStore == null) {
            lo.V("store");
            throw null;
        }
        habitStore.saveAwards(this.unlocked);
        drainBanner();
    }

    private final void floatOrb(View view, float f, long j) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.TRANSLATION_Y, 0.0f, f);
        objectAnimatorOfFloat.setDuration(j);
        objectAnimatorOfFloat.setRepeatCount(-1);
        objectAnimatorOfFloat.setRepeatMode(2);
        objectAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
        objectAnimatorOfFloat.start();
        this.liveAnimators.add(objectAnimatorOfFloat);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void hideForm() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(InputMethodManager.class);
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        inputMethodManager.hideSoftInputFromWindow(activityMain2Binding.inputTitle.getWindowToken(), 0);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.overlayForm.setVisibility(8);
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 != null) {
            activityMain2Binding3.fabAdd.f(true);
        } else {
            lo.V("binding");
            throw null;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final int iconOf(String str) {
        switch (str.hashCode()) {
            case -1221262756:
                if (str.equals(CAT_HEALTH)) {
                    return R.drawable.ic_health;
                }
                break;
            case 3208415:
                if (str.equals(CAT_HOME)) {
                    return R.drawable.ic_home;
                }
                break;
            case 3351634:
                if (str.equals(CAT_MIND)) {
                    return R.drawable.ic_mind;
                }
                break;
            case 3655441:
                if (str.equals(CAT_WORK)) {
                    return R.drawable.ic_work;
                }
                break;
            case 109651828:
                if (str.equals(CAT_SPORT)) {
                    return R.drawable.ic_sport;
                }
                break;
        }
        return R.drawable.ic_other;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openCreate() {
        if (this.habits.size() >= 20) {
            ActivityMain2Binding activityMain2Binding = this.binding;
            if (activityMain2Binding == null) {
                lo.V("binding");
                throw null;
            }
            o10 o10VarH = o10.h(activityMain2Binding.root, R.string.limit_habits, -1);
            ActivityMain2Binding activityMain2Binding2 = this.binding;
            if (activityMain2Binding2 == null) {
                lo.V("binding");
                throw null;
            }
            o10VarH.e(activityMain2Binding2.fabAdd);
            o10VarH.i();
            return;
        }
        this.formEditId = null;
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.textFormTitle.setText(R.string.form_add_title);
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding4.inputTitle.setText("");
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding5.buttonDelete.setVisibility(8);
        selectCategory(CAT_HEALTH);
        selectColor(0);
        showForm();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openEdit(HabitItem habitItem) {
        this.formEditId = habitItem.getId();
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.textFormTitle.setText(R.string.form_edit_title);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.inputTitle.setText(habitItem.getTitle());
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.buttonDelete.setVisibility(0);
        selectCategory(habitItem.getCategory());
        selectColor(habitItem.getColorIndex());
        showForm();
    }

    private final void paintCheck(ItemHabitBinding itemHabitBinding, boolean z) {
        if (z) {
            itemHabitBinding.buttonCheck.setBackgroundResource(R.drawable.bg_check_on);
            itemHabitBinding.buttonCheck.setImageTintList(ColorStateList.valueOf(getColor(R.color.white)));
            itemHabitBinding.buttonCheck.setContentDescription(getString(R.string.check_done));
        } else {
            itemHabitBinding.buttonCheck.setBackgroundResource(R.drawable.bg_check_off);
            itemHabitBinding.buttonCheck.setImageTintList(ColorStateList.valueOf(getColor(R.color.coral)));
            itemHabitBinding.buttonCheck.setContentDescription(getString(R.string.check_todo));
        }
    }

    private final void paintChip(TextView textView, boolean z) {
        textView.setBackgroundResource(z ? R.drawable.bg_chip_on : R.drawable.bg_chip_off);
        textView.setTextColor(getColor(z ? R.color.white : R.color.ink));
    }

    private final void persist() {
        HabitStore habitStore = this.store;
        if (habitStore == null) {
            lo.V("store");
            throw null;
        }
        habitStore.saveHabits(this.habits);
        HabitStore habitStore2 = this.store;
        if (habitStore2 != null) {
            habitStore2.saveAwards(this.unlocked);
        } else {
            lo.V("store");
            throw null;
        }
    }

    private final void refreshAll() throws Resources.NotFoundException {
        renderHabits();
        renderSummary();
        renderStats();
        renderAwards();
        evaluateAwards();
    }

    private final void renderAwards() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.listAwards.removeAllViews();
        for (AwardDef awardDef : catalog()) {
            LayoutInflater layoutInflater = getLayoutInflater();
            ActivityMain2Binding activityMain2Binding2 = this.binding;
            if (activityMain2Binding2 == null) {
                lo.V("binding");
                throw null;
            }
            ItemAwardBinding itemAwardBindingInflate = ItemAwardBinding.inflate(layoutInflater, activityMain2Binding2.listAwards, false);
            itemAwardBindingInflate.getClass();
            itemAwardBindingInflate.textAwardTitle.setText(awardDef.getTitle());
            itemAwardBindingInflate.textAwardDesc.setText(awardDef.getDesc());
            itemAwardBindingInflate.imageAward.setImageResource(awardDef.getIcon());
            boolean zContainsKey = this.unlocked.containsKey(awardDef.getId());
            itemAwardBindingInflate.imageLock.setVisibility(zContainsKey ? 8 : 0);
            itemAwardBindingInflate.cardAward.setAlpha(zContainsKey ? 1.0f : 0.55f);
            itemAwardBindingInflate.textAwardState.setText(zContainsKey ? R.string.award_unlocked : R.string.award_locked);
            itemAwardBindingInflate.textAwardState.setTextColor(getColor(zContainsKey ? R.color.sage : R.color.ink_faint));
            ActivityMain2Binding activityMain2Binding3 = this.binding;
            if (activityMain2Binding3 == null) {
                lo.V("binding");
                throw null;
            }
            activityMain2Binding3.listAwards.addView(itemAwardBindingInflate.getRoot());
        }
    }

    private final void renderHabits() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.listHabits.removeAllViews();
        boolean zIsEmpty = this.habits.isEmpty();
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        int i = 0;
        activityMain2Binding2.emptyHabits.setVisibility(zIsEmpty ? 0 : 8);
        if (zIsEmpty) {
            return;
        }
        for (HabitItem habitItem : this.habits) {
            LayoutInflater layoutInflater = getLayoutInflater();
            ActivityMain2Binding activityMain2Binding3 = this.binding;
            if (activityMain2Binding3 == null) {
                lo.V("binding");
                throw null;
            }
            ItemHabitBinding itemHabitBindingInflate = ItemHabitBinding.inflate(layoutInflater, activityMain2Binding3.listHabits, false);
            itemHabitBindingInflate.getClass();
            itemHabitBindingInflate.textTitle.setText(habitItem.getTitle());
            int iStreakOf = streakOf(habitItem);
            String string = iStreakOf > 0 ? getString(R.string.habit_streak, Integer.valueOf(iStreakOf)) : getString(R.string.habit_fresh);
            string.getClass();
            itemHabitBindingInflate.textMeta.setText(getString(R.string.habit_meta, categoryName(habitItem.getCategory()), string));
            itemHabitBindingInflate.imageCategory.setImageResource(iconOf(habitItem.getCategory()));
            itemHabitBindingInflate.wrapCategory.setBackgroundTintList(ColorStateList.valueOf(softOf(habitItem.getColorIndex())));
            itemHabitBindingInflate.viewAccent.setBackgroundTintList(ColorStateList.valueOf(colorOf(habitItem.getColorIndex())));
            paintCheck(itemHabitBindingInflate, habitItem.getDays().contains(todayKey()));
            int i2 = 0;
            for (Object obj : ra.h0(itemHabitBindingInflate.dot0, itemHabitBindingInflate.dot1, itemHabitBindingInflate.dot2, itemHabitBindingInflate.dot3, itemHabitBindingInflate.dot4, itemHabitBindingInflate.dot5, itemHabitBindingInflate.dot6)) {
                int i3 = i2 + 1;
                if (i2 < 0) {
                    ra.i0();
                    throw null;
                }
                ((View) obj).setBackgroundResource(habitItem.getDays().contains(dayKey(i2 + (-6))) ? R.drawable.bg_dot_on : R.drawable.bg_dot_off);
                i2 = i3;
            }
            itemHabitBindingInflate.buttonCheck.setOnClickListener(new xq(this, habitItem, i));
            itemHabitBindingInflate.cardHabit.setOnClickListener(new xq(this, habitItem, 1));
            ActivityMain2Binding activityMain2Binding4 = this.binding;
            if (activityMain2Binding4 == null) {
                lo.V("binding");
                throw null;
            }
            activityMain2Binding4.listHabits.addView(itemHabitBindingInflate.getRoot());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void renderHabits$lambda$30$lambda$28(MainActivity2 mainActivity2, HabitItem habitItem, View view) throws Resources.NotFoundException {
        view.getClass();
        mainActivity2.toggleHabit(habitItem, view);
    }

    private final void renderHeader() throws Resources.NotFoundException {
        int i = Calendar.getInstance().get(11);
        int i2 = (5 > i || i >= 12) ? (12 > i || i >= 18) ? (18 > i || i >= 23) ? R.string.greeting_night : R.string.greeting_evening : R.string.greeting_day : R.string.greeting_morning;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.textGreeting.setText(i2);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.textDate.setText(this.headerFormat.format(new Date()));
        String[] stringArray = getResources().getStringArray(R.array.daily_quotes);
        stringArray.getClass();
        int length = Calendar.getInstance().get(6) % stringArray.length;
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 != null) {
            activityMain2Binding3.textQuote.setText(stringArray[length]);
        } else {
            lo.V("binding");
            throw null;
        }
    }

    private final void renderStats() throws Resources.NotFoundException {
        Integer numValueOf;
        List listAsList;
        Integer numValueOf2;
        int i;
        int size = this.habits.size();
        Iterator<T> it = this.habits.iterator();
        int size2 = 0;
        while (it.hasNext()) {
            size2 += ((HabitItem) it.next()).getDays().size();
        }
        Iterator<T> it2 = this.habits.iterator();
        if (it2.hasNext()) {
            numValueOf = Integer.valueOf(streakOf((HabitItem) it2.next()));
            while (it2.hasNext()) {
                Integer numValueOf3 = Integer.valueOf(streakOf((HabitItem) it2.next()));
                if (numValueOf.compareTo(numValueOf3) < 0) {
                    numValueOf = numValueOf3;
                }
            }
        } else {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : 0;
        int iWeekCompletions = weekCompletions();
        int i2 = size * 7;
        if (i2 < 1) {
            i2 = 1;
        }
        int i3 = 100;
        int i4 = size == 0 ? 0 : (iWeekCompletions * 100) / i2;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.textStatHabits.setText(String.valueOf(size));
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.textStatDone.setText(String.valueOf(size2));
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.textStatBest.setText(getString(R.string.streak_days, Integer.valueOf(iIntValue)));
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding4.textStatRate.setText(getString(R.string.percent_value, Integer.valueOf(i4)));
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding5.textStatsPercent.setText(getString(R.string.percent_value, Integer.valueOf(i4)));
        ActivityMain2Binding activityMain2Binding6 = this.binding;
        if (activityMain2Binding6 == null) {
            lo.V("binding");
            throw null;
        }
        ProgressBar progressBar = activityMain2Binding6.progressWeek;
        progressBar.getClass();
        animateProgress(progressBar, i4);
        ActivityMain2Binding activityMain2Binding7 = this.binding;
        if (activityMain2Binding7 == null) {
            lo.V("binding");
            throw null;
        }
        List listH0 = ra.h0(activityMain2Binding7.bar0, activityMain2Binding7.bar1, activityMain2Binding7.bar2, activityMain2Binding7.bar3, activityMain2Binding7.bar4, activityMain2Binding7.bar5, activityMain2Binding7.bar6);
        ActivityMain2Binding activityMain2Binding8 = this.binding;
        if (activityMain2Binding8 == null) {
            lo.V("binding");
            throw null;
        }
        List listH02 = ra.h0(activityMain2Binding8.label0, activityMain2Binding8.label1, activityMain2Binding8.label2, activityMain2Binding8.label3, activityMain2Binding8.label4, activityMain2Binding8.label5, activityMain2Binding8.label6);
        int dimensionPixelSize = getResources().getDimensionPixelSize(R.dimen.bar_max);
        int i5 = (int) (8.0f * getResources().getDisplayMetrics().density);
        int i6 = 0;
        for (Object obj : listH0) {
            int i7 = i6 + 1;
            if (i6 < 0) {
                ra.i0();
                throw null;
            }
            View view = (View) obj;
            int i8 = i6 - 6;
            List<HabitItem> list = this.habits;
            if (list == null || !list.isEmpty()) {
                Iterator<T> it3 = list.iterator();
                int i9 = 0;
                while (it3.hasNext()) {
                    int i10 = i3;
                    if (((HabitItem) it3.next()).getDays().contains(dayKey(i8)) && (i9 = i9 + 1) < 0) {
                        throw new ArithmeticException("Count overflow has happened.");
                    }
                    i3 = i10;
                }
                i = i9;
            } else {
                i = 0;
            }
            int i11 = i3;
            float f = size == 0 ? 0.0f : i / size;
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.height = ((int) ((dimensionPixelSize - i5) * f)) + i5;
            view.setLayoutParams(layoutParams);
            ((TextView) listH02.get(i6)).setText(weekLabel(i8));
            i6 = i7;
            i3 = i11;
        }
        int i12 = i3;
        ActivityMain2Binding activityMain2Binding9 = this.binding;
        if (activityMain2Binding9 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding9.listTopHabits.removeAllViews();
        List<HabitItem> list2 = this.habits;
        Comparator comparator = new Comparator() { // from class: com.civis.melbet.galba.MainActivity2$renderStats$$inlined$sortedByDescending$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                Integer numValueOf4 = Integer.valueOf(((HabitItem) t2).getDays().size());
                Integer numValueOf5 = Integer.valueOf(((HabitItem) t).getDays().size());
                if (numValueOf4 == numValueOf5) {
                    return 0;
                }
                return numValueOf4.compareTo(numValueOf5);
            }
        };
        list2.getClass();
        if (list2.size() <= 1) {
            listAsList = qa.o0(list2);
        } else {
            Object[] array = list2.toArray(new Object[0]);
            array.getClass();
            if (array.length > 1) {
                Arrays.sort(array, comparator);
            }
            listAsList = Arrays.asList(array);
            listAsList.getClass();
        }
        List listM0 = qa.m0(listAsList, 5);
        ArrayList arrayList = new ArrayList();
        for (Object obj2 : listM0) {
            if (!((HabitItem) obj2).getDays().isEmpty()) {
                arrayList.add(obj2);
            }
        }
        ActivityMain2Binding activityMain2Binding10 = this.binding;
        if (activityMain2Binding10 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding10.textTopEmpty.setVisibility(arrayList.isEmpty() ? 0 : 8);
        Iterator it4 = arrayList.iterator();
        if (it4.hasNext()) {
            numValueOf2 = Integer.valueOf(((HabitItem) it4.next()).getDays().size());
            while (it4.hasNext()) {
                Integer numValueOf4 = Integer.valueOf(((HabitItem) it4.next()).getDays().size());
                if (numValueOf2.compareTo(numValueOf4) < 0) {
                    numValueOf2 = numValueOf4;
                }
            }
        } else {
            numValueOf2 = null;
        }
        int iIntValue2 = numValueOf2 != null ? numValueOf2.intValue() : 1;
        int size3 = arrayList.size();
        int i13 = 0;
        while (i13 < size3) {
            Object obj3 = arrayList.get(i13);
            i13++;
            HabitItem habitItem = (HabitItem) obj3;
            LayoutInflater layoutInflater = getLayoutInflater();
            ActivityMain2Binding activityMain2Binding11 = this.binding;
            if (activityMain2Binding11 == null) {
                lo.V("binding");
                throw null;
            }
            ItemTopBinding itemTopBindingInflate = ItemTopBinding.inflate(layoutInflater, activityMain2Binding11.listTopHabits, false);
            itemTopBindingInflate.getClass();
            itemTopBindingInflate.textTopName.setText(getString(R.string.top_row, habitItem.getTitle(), Integer.valueOf(habitItem.getDays().size())));
            itemTopBindingInflate.viewTopAccent.setBackgroundTintList(ColorStateList.valueOf(colorOf(habitItem.getColorIndex())));
            int i14 = i12;
            itemTopBindingInflate.progressTop.setProgress(r50.n((habitItem.getDays().size() * 100) / iIntValue2, i14));
            ActivityMain2Binding activityMain2Binding12 = this.binding;
            if (activityMain2Binding12 == null) {
                lo.V("binding");
                throw null;
            }
            activityMain2Binding12.listTopHabits.addView(itemTopBindingInflate.getRoot());
            i12 = i14;
        }
    }

    private final void renderSummary() {
        Integer numValueOf;
        int i;
        Iterator<T> it = this.habits.iterator();
        if (it.hasNext()) {
            numValueOf = Integer.valueOf(streakOf((HabitItem) it.next()));
            while (it.hasNext()) {
                Integer numValueOf2 = Integer.valueOf(streakOf((HabitItem) it.next()));
                if (numValueOf.compareTo(numValueOf2) < 0) {
                    numValueOf = numValueOf2;
                }
            }
        } else {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : 0;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.textStreakValue.setText(getString(R.string.streak_days, Integer.valueOf(iIntValue)));
        List<HabitItem> list = this.habits;
        if (list == null || !list.isEmpty()) {
            Iterator<T> it2 = list.iterator();
            i = 0;
            while (it2.hasNext()) {
                if (((HabitItem) it2.next()).getDays().contains(todayKey()) && (i = i + 1) < 0) {
                    throw new ArithmeticException("Count overflow has happened.");
                }
            }
        } else {
            i = 0;
        }
        int size = this.habits.size();
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.textTodayValue.setText(size == 0 ? getString(R.string.value_zero) : getString(R.string.today_progress, Integer.valueOf(i), Integer.valueOf(size)));
        int i2 = size != 0 ? (i * 100) / size : 0;
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        ProgressBar progressBar = activityMain2Binding3.progressToday;
        progressBar.getClass();
        animateProgress(progressBar, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void saveForm() throws Resources.NotFoundException {
        String string;
        ActivityMain2Binding activityMain2Binding = this.binding;
        Object obj = null;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        Editable text = activityMain2Binding.inputTitle.getText();
        String string2 = (text == null || (string = text.toString()) == null) ? null : u20.t0(string).toString();
        if (string2 == null) {
            string2 = "";
        }
        String str = string2;
        if (str.length() == 0) {
            ActivityMain2Binding activityMain2Binding2 = this.binding;
            if (activityMain2Binding2 != null) {
                o10.h(activityMain2Binding2.root, R.string.error_empty_title, -1).i();
                return;
            } else {
                lo.V("binding");
                throw null;
            }
        }
        String str2 = this.formEditId;
        List<HabitItem> list = this.habits;
        if (str2 == null) {
            String string3 = UUID.randomUUID().toString();
            string3.getClass();
            list.add(new HabitItem(string3, str, this.formCategory, this.formColor, System.currentTimeMillis(), new LinkedHashSet()));
        } else {
            Iterator<T> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (lo.b(((HabitItem) next).getId(), str2)) {
                    obj = next;
                    break;
                }
            }
            HabitItem habitItem = (HabitItem) obj;
            if (habitItem != null) {
                habitItem.setTitle(str);
                habitItem.setCategory(this.formCategory);
                habitItem.setColorIndex(this.formColor);
            }
        }
        persist();
        hideForm();
        refreshAll();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void selectCategory(String str) {
        this.formCategory = str;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView = activityMain2Binding.chipHealth;
        textView.getClass();
        paintChip(textView, lo.b(str, CAT_HEALTH));
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView2 = activityMain2Binding2.chipSport;
        textView2.getClass();
        paintChip(textView2, lo.b(str, CAT_SPORT));
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView3 = activityMain2Binding3.chipMind;
        textView3.getClass();
        paintChip(textView3, lo.b(str, CAT_MIND));
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView4 = activityMain2Binding4.chipHome;
        textView4.getClass();
        paintChip(textView4, lo.b(str, CAT_HOME));
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView5 = activityMain2Binding5.chipWork;
        textView5.getClass();
        paintChip(textView5, lo.b(str, CAT_WORK));
        ActivityMain2Binding activityMain2Binding6 = this.binding;
        if (activityMain2Binding6 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView6 = activityMain2Binding6.chipOther;
        textView6.getClass();
        paintChip(textView6, lo.b(str, CAT_OTHER));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void selectColor(int i) {
        this.formColor = i;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout = activityMain2Binding.wrapColor0;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout2 = activityMain2Binding.wrapColor1;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout3 = activityMain2Binding.wrapColor2;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout4 = activityMain2Binding.wrapColor3;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout5 = activityMain2Binding.wrapColor4;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        FrameLayout frameLayout6 = activityMain2Binding.wrapColor5;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        int i2 = 0;
        for (Object obj : ra.h0(frameLayout, frameLayout2, frameLayout3, frameLayout4, frameLayout5, frameLayout6, activityMain2Binding.wrapColor6)) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                ra.i0();
                throw null;
            }
            ((FrameLayout) obj).setBackgroundResource(i2 == i ? R.drawable.bg_color_selected : 0);
            i2 = i3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void selectTab(int i) {
        this.currentTab = i;
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.panelToday.setVisibility(i == 0 ? 0 : 8);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.panelStats.setVisibility(i == 1 ? 0 : 8);
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.panelAwards.setVisibility(i == 2 ? 0 : 8);
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView = activityMain2Binding4.tabToday;
        textView.getClass();
        styleTab(textView, i == 0);
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView2 = activityMain2Binding5.tabStats;
        textView2.getClass();
        styleTab(textView2, i == 1);
        ActivityMain2Binding activityMain2Binding6 = this.binding;
        if (activityMain2Binding6 == null) {
            lo.V("binding");
            throw null;
        }
        TextView textView3 = activityMain2Binding6.tabAwards;
        textView3.getClass();
        styleTab(textView3, i == 2);
        ActivityMain2Binding activityMain2Binding7 = this.binding;
        if (activityMain2Binding7 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding7.navToday.setBackgroundResource(i == 0 ? R.drawable.bg_nav_item_on : R.drawable.bg_nav_item_off);
        ActivityMain2Binding activityMain2Binding8 = this.binding;
        if (activityMain2Binding8 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding8.navStats.setBackgroundResource(i == 1 ? R.drawable.bg_nav_item_on : R.drawable.bg_nav_item_off);
        ActivityMain2Binding activityMain2Binding9 = this.binding;
        if (activityMain2Binding9 != null) {
            activityMain2Binding9.navAwards.setBackgroundResource(i == 2 ? R.drawable.bg_nav_item_on : R.drawable.bg_nav_item_off);
        } else {
            lo.V("binding");
            throw null;
        }
    }

    private final void showForm() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding.overlayForm.setVisibility(0);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding2.fabAdd.d(true);
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding3.formCard.setTranslationY(80.0f);
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding4.formCard.setAlpha(0.0f);
        ActivityMain2Binding activityMain2Binding5 = this.binding;
        if (activityMain2Binding5 == null) {
            lo.V("binding");
            throw null;
        }
        activityMain2Binding5.formCard.animate().translationY(0.0f).alpha(1.0f).setDuration(260L).start();
        ActivityMain2Binding activityMain2Binding6 = this.binding;
        if (activityMain2Binding6 != null) {
            activityMain2Binding6.inputTitle.requestFocus();
        } else {
            lo.V("binding");
            throw null;
        }
    }

    private final int softOf(int i) {
        return getColor(new int[]{R.color.coral_soft, R.color.sage_soft, R.color.lavender_soft, R.color.gold_soft, R.color.sky_soft, R.color.rose_soft, R.color.teal_soft}[r50.n(i, 6)]);
    }

    private final void startLivingMotion() {
        ActivityMain2Binding activityMain2Binding = this.binding;
        if (activityMain2Binding == null) {
            lo.V("binding");
            throw null;
        }
        View view = activityMain2Binding.orbOne;
        view.getClass();
        floatOrb(view, 18.0f, 4200L);
        ActivityMain2Binding activityMain2Binding2 = this.binding;
        if (activityMain2Binding2 == null) {
            lo.V("binding");
            throw null;
        }
        View view2 = activityMain2Binding2.orbTwo;
        view2.getClass();
        floatOrb(view2, -14.0f, 3600L);
        ActivityMain2Binding activityMain2Binding3 = this.binding;
        if (activityMain2Binding3 == null) {
            lo.V("binding");
            throw null;
        }
        View view3 = activityMain2Binding3.orbThree;
        view3.getClass();
        floatOrb(view3, 12.0f, 5000L);
        ActivityMain2Binding activityMain2Binding4 = this.binding;
        if (activityMain2Binding4 == null) {
            lo.V("binding");
            throw null;
        }
        ObjectAnimator objectAnimatorOfPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(activityMain2Binding4.fabAdd, PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_X, 1.0f, 1.08f, 1.0f), PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_Y, 1.0f, 1.08f, 1.0f));
        objectAnimatorOfPropertyValuesHolder.getClass();
        objectAnimatorOfPropertyValuesHolder.setDuration(2200L);
        objectAnimatorOfPropertyValuesHolder.setRepeatCount(-1);
        objectAnimatorOfPropertyValuesHolder.setInterpolator(new AccelerateDecelerateInterpolator());
        objectAnimatorOfPropertyValuesHolder.start();
        this.liveAnimators.add(objectAnimatorOfPropertyValuesHolder);
    }

    private final int streakOf(HabitItem habitItem) {
        Calendar calendar = Calendar.getInstance();
        String str = this.dateFormat.format(calendar.getTime());
        if (!habitItem.getDays().contains(str)) {
            calendar.add(6, -1);
            str = this.dateFormat.format(calendar.getTime());
        }
        int i = 0;
        while (habitItem.getDays().contains(str)) {
            i++;
            calendar.add(6, -1);
            str = this.dateFormat.format(calendar.getTime());
        }
        return i;
    }

    private final void styleTab(TextView textView, boolean z) {
        textView.setBackgroundResource(z ? R.drawable.bg_tab_active : R.drawable.bg_tab_idle);
        textView.setTextColor(getColor(z ? R.color.coral_deep : R.color.ink_soft));
    }

    private final String todayKey() {
        String str = this.dateFormat.format(new Date());
        str.getClass();
        return str;
    }

    private final void toggleHabit(HabitItem habitItem, View view) throws Resources.NotFoundException {
        String str = todayKey();
        if (habitItem.getDays().contains(str)) {
            habitItem.getDays().remove(str);
        } else {
            habitItem.getDays().add(str);
        }
        view.performHapticFeedback(1);
        view.animate().scaleX(0.82f).scaleY(0.82f).setDuration(80L).withEndAction(new wq(view, 0)).start();
        persist();
        refreshAll();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void toggleHabit$lambda$31(View view) {
        view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160L).start();
    }

    private final void unlockIf(String str, boolean z) {
        Object next;
        if (!z || this.unlocked.containsKey(str)) {
            return;
        }
        this.unlocked.put(str, Long.valueOf(System.currentTimeMillis()));
        Iterator<T> it = catalog().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (lo.b(((AwardDef) next).getId(), str)) {
                    break;
                }
            }
        }
        AwardDef awardDef = (AwardDef) next;
        if (awardDef != null) {
            this.awardQueue.addLast(awardDef);
        }
    }

    private final int weekCompletions() {
        int i;
        Iterator it = new io(-6, 0, 1).iterator();
        int i2 = 0;
        while (true) {
            ho hoVar = (ho) it;
            boolean z = hoVar.h;
            if (!z) {
                return i2;
            }
            int i3 = hoVar.i;
            if (i3 != hoVar.g) {
                hoVar.i = hoVar.f + i3;
            } else {
                if (!z) {
                    throw new NoSuchElementException();
                }
                hoVar.h = false;
            }
            List<HabitItem> list = this.habits;
            if (list == null || !list.isEmpty()) {
                Iterator<T> it2 = list.iterator();
                i = 0;
                while (it2.hasNext()) {
                    if (((HabitItem) it2.next()).getDays().contains(dayKey(i3)) && (i = i + 1) < 0) {
                        throw new ArithmeticException("Count overflow has happened.");
                    }
                }
            } else {
                i = 0;
            }
            i2 += i;
        }
    }

    private final String weekLabel(int i) throws Resources.NotFoundException {
        Calendar calendar = Calendar.getInstance();
        calendar.add(6, i);
        String[] stringArray = getResources().getStringArray(R.array.week_short);
        stringArray.getClass();
        String str = stringArray[(calendar.get(7) + 5) % 7];
        str.getClass();
        return str;
    }

    @Override // defpackage.yj, defpackage.nb, defpackage.mb, android.app.Activity
    public void onCreate(Bundle bundle) throws Resources.NotFoundException {
        super.onCreate(bundle);
        cg.a(this);
        ActivityMain2Binding activityMain2BindingInflate = ActivityMain2Binding.inflate(getLayoutInflater());
        activityMain2BindingInflate.getClass();
        this.binding = activityMain2BindingInflate;
        setContentView(activityMain2BindingInflate.root);
        HabitStore habitStore = new HabitStore(this);
        this.store = habitStore;
        this.habits.addAll(habitStore.loadHabits());
        Map<String, Long> map = this.unlocked;
        HabitStore habitStore2 = this.store;
        if (habitStore2 == null) {
            lo.V("store");
            throw null;
        }
        map.putAll(habitStore2.loadAwards());
        applyInsets();
        bindClicks();
        bindBack();
        renderHeader();
        selectTab(0);
        refreshAll();
        startLivingMotion();
    }

    @Override // defpackage.k3, defpackage.yj, android.app.Activity
    public void onDestroy() {
        Iterator<T> it = this.liveAnimators.iterator();
        while (it.hasNext()) {
            ((Animator) it.next()).cancel();
        }
        this.liveAnimators.clear();
        this.handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    /* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
    public static final class Companion {
        public /* synthetic */ Companion(wd wdVar) {
            this();
        }

        private Companion() {
        }
    }
}
