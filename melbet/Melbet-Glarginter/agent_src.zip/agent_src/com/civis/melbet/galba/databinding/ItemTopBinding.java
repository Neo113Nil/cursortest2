package com.civis.melbet.galba.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.civis.melbet.galba.R;
import defpackage.fv;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class ItemTopBinding {
    public final ProgressBar progressTop;
    private final LinearLayout rootView;
    public final TextView textTopName;
    public final View viewTopAccent;

    private ItemTopBinding(LinearLayout linearLayout, ProgressBar progressBar, TextView textView, View view) {
        this.rootView = linearLayout;
        this.progressTop = progressBar;
        this.textTopName = textView;
        this.viewTopAccent = view;
    }

    public static ItemTopBinding bind(View view) {
        View viewP;
        int i = R.id.progressTop;
        ProgressBar progressBar = (ProgressBar) fv.p(view, i);
        if (progressBar != null) {
            i = R.id.textTopName;
            TextView textView = (TextView) fv.p(view, i);
            if (textView != null && (viewP = fv.p(view, (i = R.id.viewTopAccent))) != null) {
                return new ItemTopBinding((LinearLayout) view, progressBar, textView, viewP);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static ItemTopBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_top, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static ItemTopBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }
}
