package com.civis.melbet.galba.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.civis.melbet.galba.R;
import com.google.android.material.card.MaterialCardView;
import defpackage.fv;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class ItemAwardBinding {
    public final MaterialCardView cardAward;
    public final ImageView imageAward;
    public final ImageView imageLock;
    private final MaterialCardView rootView;
    public final TextView textAwardDesc;
    public final TextView textAwardState;
    public final TextView textAwardTitle;

    private ItemAwardBinding(MaterialCardView materialCardView, MaterialCardView materialCardView2, ImageView imageView, ImageView imageView2, TextView textView, TextView textView2, TextView textView3) {
        this.rootView = materialCardView;
        this.cardAward = materialCardView2;
        this.imageAward = imageView;
        this.imageLock = imageView2;
        this.textAwardDesc = textView;
        this.textAwardState = textView2;
        this.textAwardTitle = textView3;
    }

    public static ItemAwardBinding bind(View view) {
        MaterialCardView materialCardView = (MaterialCardView) view;
        int i = R.id.imageAward;
        ImageView imageView = (ImageView) fv.p(view, i);
        if (imageView != null) {
            i = R.id.imageLock;
            ImageView imageView2 = (ImageView) fv.p(view, i);
            if (imageView2 != null) {
                i = R.id.textAwardDesc;
                TextView textView = (TextView) fv.p(view, i);
                if (textView != null) {
                    i = R.id.textAwardState;
                    TextView textView2 = (TextView) fv.p(view, i);
                    if (textView2 != null) {
                        i = R.id.textAwardTitle;
                        TextView textView3 = (TextView) fv.p(view, i);
                        if (textView3 != null) {
                            return new ItemAwardBinding(materialCardView, materialCardView, imageView, imageView2, textView, textView2, textView3);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static ItemAwardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_award, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ItemAwardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }
}
