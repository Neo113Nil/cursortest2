package com.civis.melbet.galba.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.civis.melbet.galba.R;
import com.google.android.material.card.MaterialCardView;
import defpackage.fv;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class ItemHabitBinding {
    public final ImageButton buttonCheck;
    public final MaterialCardView cardHabit;
    public final View dot0;
    public final View dot1;
    public final View dot2;
    public final View dot3;
    public final View dot4;
    public final View dot5;
    public final View dot6;
    public final ImageView imageCategory;
    private final MaterialCardView rootView;
    public final LinearLayout rowDays;
    public final TextView textMeta;
    public final TextView textTitle;
    public final View viewAccent;
    public final FrameLayout wrapCategory;

    private ItemHabitBinding(MaterialCardView materialCardView, ImageButton imageButton, MaterialCardView materialCardView2, View view, View view2, View view3, View view4, View view5, View view6, View view7, ImageView imageView, LinearLayout linearLayout, TextView textView, TextView textView2, View view8, FrameLayout frameLayout) {
        this.rootView = materialCardView;
        this.buttonCheck = imageButton;
        this.cardHabit = materialCardView2;
        this.dot0 = view;
        this.dot1 = view2;
        this.dot2 = view3;
        this.dot3 = view4;
        this.dot4 = view5;
        this.dot5 = view6;
        this.dot6 = view7;
        this.imageCategory = imageView;
        this.rowDays = linearLayout;
        this.textMeta = textView;
        this.textTitle = textView2;
        this.viewAccent = view8;
        this.wrapCategory = frameLayout;
    }

    public static ItemHabitBinding bind(View view) {
        View viewP;
        View viewP2;
        View viewP3;
        View viewP4;
        View viewP5;
        View viewP6;
        View viewP7;
        int i = R.id.buttonCheck;
        ImageButton imageButton = (ImageButton) fv.p(view, i);
        if (imageButton != null) {
            MaterialCardView materialCardView = (MaterialCardView) view;
            i = R.id.dot0;
            View viewP8 = fv.p(view, i);
            if (viewP8 != null && (viewP = fv.p(view, (i = R.id.dot1))) != null && (viewP2 = fv.p(view, (i = R.id.dot2))) != null && (viewP3 = fv.p(view, (i = R.id.dot3))) != null && (viewP4 = fv.p(view, (i = R.id.dot4))) != null && (viewP5 = fv.p(view, (i = R.id.dot5))) != null && (viewP6 = fv.p(view, (i = R.id.dot6))) != null) {
                i = R.id.imageCategory;
                ImageView imageView = (ImageView) fv.p(view, i);
                if (imageView != null) {
                    i = R.id.rowDays;
                    LinearLayout linearLayout = (LinearLayout) fv.p(view, i);
                    if (linearLayout != null) {
                        i = R.id.textMeta;
                        TextView textView = (TextView) fv.p(view, i);
                        if (textView != null) {
                            i = R.id.textTitle;
                            TextView textView2 = (TextView) fv.p(view, i);
                            if (textView2 != null && (viewP7 = fv.p(view, (i = R.id.viewAccent))) != null) {
                                i = R.id.wrapCategory;
                                FrameLayout frameLayout = (FrameLayout) fv.p(view, i);
                                if (frameLayout != null) {
                                    return new ItemHabitBinding(materialCardView, imageButton, materialCardView, viewP8, viewP, viewP2, viewP3, viewP4, viewP5, viewP6, imageView, linearLayout, textView, textView2, viewP7, frameLayout);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static ItemHabitBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_habit, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public MaterialCardView getRoot() {
        return this.rootView;
    }

    public static ItemHabitBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }
}
