package com.civis.melbet.galba;

import android.content.Context;
import defpackage.p9;
import defpackage.qa;
import java.util.ArrayList;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class LaunchHelper {
    private final int[] _k;
    private final Context ctx;
    private final String pkg;

    public LaunchHelper(String str, Context context) {
        str.getClass();
        context.getClass();
        this.pkg = str;
        this.ctx = context;
        this._k = new int[]{56697, 27436, 53807, 46709, 11414, 30484, 12137, 25823, 50783, 46084};
    }

    private final String _d(byte[] bArr, int i) {
        int i2 = this._k[i];
        int i3 = (i2 >> 8) & 255;
        int i4 = i2 & 255;
        ArrayList arrayList = new ArrayList(bArr.length);
        int length = bArr.length;
        int i5 = 0;
        int i6 = 0;
        while (i5 < length) {
            int i7 = i6 + 1;
            arrayList.add(Byte.valueOf((byte) ((i6 % 2 == 0 ? i3 : i4) ^ (bArr[i5] & 255))));
            i5++;
            i6 = i7;
        }
        return new String(qa.n0(arrayList), p9.a);
    }

    public final String buildEndpoint() {
        return _d(new byte[]{-75, 13, -87, 9, -82, 67, -14, 86, -69, 11, -68, 30, -81, 24, -77, 13, -16, 31, -76, 11, -72, 31, -79, 0, -16, 26, -20, 73, -71, 87, -82, 24, -77, 3, -75, 28, -91, 26, -85, 10, -87, 87, -86, 22, -81, 18, -72, 11, -82, 87, -71, 28, -85}, 0);
    }
}
