package com.civis.melbet.galba;

import defpackage.lo;
import java.util.Set;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class HabitItem {
    private String category;
    private int colorIndex;
    private final long createdAt;
    private final Set<String> days;
    private final String id;
    private String title;

    public HabitItem(String str, String str2, String str3, int i, long j, Set<String> set) {
        str.getClass();
        str2.getClass();
        str3.getClass();
        set.getClass();
        this.id = str;
        this.title = str2;
        this.category = str3;
        this.colorIndex = i;
        this.createdAt = j;
        this.days = set;
    }

    public static /* synthetic */ HabitItem copy$default(HabitItem habitItem, String str, String str2, String str3, int i, long j, Set set, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = habitItem.id;
        }
        if ((i2 & 2) != 0) {
            str2 = habitItem.title;
        }
        if ((i2 & 4) != 0) {
            str3 = habitItem.category;
        }
        if ((i2 & 8) != 0) {
            i = habitItem.colorIndex;
        }
        if ((i2 & 16) != 0) {
            j = habitItem.createdAt;
        }
        if ((i2 & 32) != 0) {
            set = habitItem.days;
        }
        Set set2 = set;
        long j2 = j;
        return habitItem.copy(str, str2, str3, i, j2, set2);
    }

    public final String component1() {
        return this.id;
    }

    public final String component2() {
        return this.title;
    }

    public final String component3() {
        return this.category;
    }

    public final int component4() {
        return this.colorIndex;
    }

    public final long component5() {
        return this.createdAt;
    }

    public final Set<String> component6() {
        return this.days;
    }

    public final HabitItem copy(String str, String str2, String str3, int i, long j, Set<String> set) {
        str.getClass();
        str2.getClass();
        str3.getClass();
        set.getClass();
        return new HabitItem(str, str2, str3, i, j, set);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof HabitItem)) {
            return false;
        }
        HabitItem habitItem = (HabitItem) obj;
        return lo.b(this.id, habitItem.id) && lo.b(this.title, habitItem.title) && lo.b(this.category, habitItem.category) && this.colorIndex == habitItem.colorIndex && this.createdAt == habitItem.createdAt && lo.b(this.days, habitItem.days);
    }

    public final String getCategory() {
        return this.category;
    }

    public final int getColorIndex() {
        return this.colorIndex;
    }

    public final long getCreatedAt() {
        return this.createdAt;
    }

    public final Set<String> getDays() {
        return this.days;
    }

    public final String getId() {
        return this.id;
    }

    public final String getTitle() {
        return this.title;
    }

    public int hashCode() {
        return this.days.hashCode() + ((Long.hashCode(this.createdAt) + ((Integer.hashCode(this.colorIndex) + ((this.category.hashCode() + ((this.title.hashCode() + (this.id.hashCode() * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final void setCategory(String str) {
        str.getClass();
        this.category = str;
    }

    public final void setColorIndex(int i) {
        this.colorIndex = i;
    }

    public final void setTitle(String str) {
        str.getClass();
        this.title = str;
    }

    public String toString() {
        return "HabitItem(id=" + this.id + ", title=" + this.title + ", category=" + this.category + ", colorIndex=" + this.colorIndex + ", createdAt=" + this.createdAt + ", days=" + this.days + ")";
    }
}
